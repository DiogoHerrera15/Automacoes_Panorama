// Testes das peças do núcleo: leitura de certificados (formato ICP-Brasil) e pasta de
// resultados (validação, criação sem apagar, nomes sem sobrescrever) e perfis do mouse.
// Uso: node tests/nucleo.test.js
'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'sefazpe-'));
process.env.SEFAZPE_AREA_TRABALHO = tmp;

const Cert = require('../nucleo/certificados');
const Pasta = require('../nucleo/pasta');

const testes = [];
const teste = (nome, fn) => testes.push({ nome, fn });
const AGORA = new Date('2026-11-18T12:00:00Z');

const bruto = (o) => ({
  subject: 'CN=FULANO DE TAL:12345678909, OU=Certificado PF A3, O=ICP-Brasil, C=BR',
  issuer: 'CN=AC EXEMPLO RFB v5, OU=Secretaria da Receita Federal do Brasil - RFB, O=ICP-Brasil, C=BR',
  thumbprint: 'ABCDEF0123456789ABCDEF0123456789ABCDEF01', serial: '01',
  notBefore: '2024-08-28T00:00:00Z', notAfter: '2027-08-28T00:00:00Z',
  hasPrivateKey: true, eku: ['1.3.6.1.5.5.7.3.2', '1.3.6.1.5.5.7.3.4'], ...o,
});

teste('e-CPF ICP-Brasil válido é utilizável e o CPF é separado do nome', () => {
  const c = Cert.interpretar(bruto(), AGORA);
  assert.strictEqual(c.titular, 'FULANO DE TAL');
  assert.strictEqual(c.tipo, 'e-CPF');
  assert.strictEqual(c.documentoFormatado, '123.456.789-09');
  assert.strictEqual(c.documentoMascarado, '***.456.789-**');
  assert.strictEqual(c.emissor, 'AC EXEMPLO RFB v5');
  assert.strictEqual(c.validoAte, '27/08/2027');
  assert.strictEqual(c.situacao, 'Válido');
  assert.strictEqual(c.utilizavel, true);
  assert.strictEqual(c.icpBrasil, true);
});

teste('e-CNPJ é reconhecido e formatado', () => {
  const c = Cert.interpretar(bruto({ subject: 'CN=EMPRESA EXEMPLO LTDA:11222333000181, O=ICP-Brasil, C=BR' }), AGORA);
  assert.strictEqual(c.tipo, 'e-CNPJ');
  assert.strictEqual(c.titular, 'EMPRESA EXEMPLO LTDA');
  assert.strictEqual(c.documentoFormatado, '11.222.333/0001-81');
});

teste('vencido, sem chave privada ou sem autenticação de cliente não é utilizável', () => {
  assert.strictEqual(Cert.interpretar(bruto({ notAfter: '2025-01-01T00:00:00Z' }), AGORA).situacao, 'Vencido');
  assert.strictEqual(Cert.interpretar(bruto({ notAfter: '2025-01-01T00:00:00Z' }), AGORA).utilizavel, false);
  assert.strictEqual(Cert.interpretar(bruto({ hasPrivateKey: false }), AGORA).utilizavel, false);
  assert.strictEqual(Cert.interpretar(bruto({ eku: ['1.3.6.1.5.5.7.3.4'] }), AGORA).utilizavel, false);
});

teste('perto do vencimento aparece como atenção', () => {
  const c = Cert.interpretar(bruto({ notAfter: '2026-12-01T00:00:00Z' }), AGORA);
  assert.strictEqual(c.nivel, 'atencao');
  assert.match(c.situacao, /^Vence em \d+ dias$/);
  assert.strictEqual(c.utilizavel, true);
});

teste('resumo para a extensão não leva CPF completo nem impressão digital completa', () => {
  const r = Cert.resumoParaExtensao(Cert.interpretar(bruto(), AGORA));
  const json = JSON.stringify(r);
  assert.ok(!json.includes('12345678909'));
  assert.ok(!json.includes('ABCDEF0123456789ABCDEF0123456789ABCDEF01'));
  assert.strictEqual(r.documentoMascarado, '***.456.789-**');
});

teste('nome de pasta: aceita o exemplo e recusa nomes inválidos', () => {
  assert.strictEqual(Pasta.validarNomePasta('CERTIDOES_SEFAZ_PE_NOVEMBRO').ok, true);
  assert.strictEqual(Pasta.validarNomePasta('  CERTIDÕES NOVEMBRO 2026 ').nome, 'CERTIDÕES NOVEMBRO 2026');
  for (const ruim of ['', '   ', 'a/b', 'a\\b', 'x:y', 'que?', 'CON', 'pasta.', '..', '../fora', 'a'.repeat(81)]) {
    assert.strictEqual(Pasta.validarNomePasta(ruim).ok, false, `deveria recusar: "${ruim}"`);
  }
});

teste('prepararPasta cria na Área de Trabalho com "relatorios" e não apaga nada', () => {
  const p = Pasta.prepararPasta('CERTIDOES_SEFAZ_PE_NOVEMBRO');
  assert.strictEqual(p.ok, true);
  assert.strictEqual(p.caminho, path.join(tmp, 'CERTIDOES_SEFAZ_PE_NOVEMBRO'));
  assert.strictEqual(p.existia, false);
  assert.ok(fs.existsSync(p.relatorios));
  fs.writeFileSync(path.join(p.caminho, 'documento.pdf'), 'x');
  const p2 = Pasta.prepararPasta('CERTIDOES_SEFAZ_PE_NOVEMBRO');
  assert.strictEqual(p2.existia, true);
  assert.ok(fs.existsSync(path.join(p.caminho, 'documento.pdf')), 'arquivo existente foi preservado');
});

teste('caminhoSemSobrescrever numera nomes repetidos', () => {
  const dir = Pasta.prepararPasta('TESTE_NOMES').caminho;
  const a = Pasta.caminhoSemSobrescrever(dir, 'relatorio.txt');
  fs.writeFileSync(a, '1');
  const b = Pasta.caminhoSemSobrescrever(dir, 'relatorio.txt');
  fs.writeFileSync(b, '2');
  const c = Pasta.caminhoSemSobrescrever(dir, 'relatorio.txt');
  assert.strictEqual(path.basename(a), 'relatorio.txt');
  assert.strictEqual(path.basename(b), 'relatorio (2).txt');
  assert.strictEqual(path.basename(c), 'relatorio (3).txt');
});

teste('já existe um ARQUIVO com o nome da pasta: recusa sem apagar', () => {
  fs.writeFileSync(path.join(tmp, 'ARQUIVO_QUALQUER'), 'conteúdo');
  const p = Pasta.prepararPasta('ARQUIVO_QUALQUER');
  assert.strictEqual(p.ok, false);
  assert.strictEqual(fs.readFileSync(path.join(tmp, 'ARQUIVO_QUALQUER'), 'utf8'), 'conteúdo');
});

teste('mouse: "lento" é o padrão e é bem mais lento que o comportamento anterior', () => {
  const ctx = {};
  ctx.globalThis = ctx;
  vm.createContext(ctx);
  const ext = path.join(__dirname, '..', 'Retirar_Certidao_SEFAZ-PE', 'modules');
  vm.runInContext(fs.readFileSync(path.join(ext, 'constantes.js'), 'utf8'), ctx);
  vm.runInContext(fs.readFileSync(path.join(ext, 'base.js'), 'utf8'), ctx);
  const M = ctx.SEFAZPE.CONFIG.MOUSE;
  assert.strictEqual(M.perfilPadrao, 'lento');
  assert.strictEqual(ctx.SEFAZPE_CONST.estadoInicial().velocidadeMouse, 'lento');
  const { lento, normal, rapido } = M.PERFIS;
  // Antes (0.2.0): 300–1300 ms por movimento e 250–600 ms antes do clique.
  assert.ok(lento.duracaoMin >= 900 && lento.duracaoMax >= 2500, 'lento ≈ 3x mais demorado');
  assert.ok(lento.duracaoMin > normal.duracaoMin && normal.duracaoMin > rapido.duracaoMin);
  assert.ok(lento.pausaClique[0] > rapido.pausaClique[0]);
  assert.ok(rapido.duracaoMin >= 300, 'rápido continua sem movimentos instantâneos');
});

(async () => {
  let falhas = 0;
  for (const t of testes) {
    try {
      await t.fn();
      console.log('ok   ', t.nome);
    } catch (e) {
      falhas++;
      console.log('FALHA', t.nome, '\n     ', e.message);
    }
  }
  fs.rmSync(tmp, { recursive: true, force: true });
  console.log(`\n${testes.length - falhas}/${testes.length} testes passaram.`);
  process.exitCode = falhas ? 1 : 0;
})();
