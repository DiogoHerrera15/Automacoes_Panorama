// Testes da leitura da lista mista (CNPJ, CPF, Inscrição Estadual).
// Uso: node tests/lista.test.js
'use strict';

const assert = require('assert');
const L = require('../nucleo/lista');

const testes = [];
const teste = (nome, fn) => testes.push({ nome, fn });

// Números de referência públicos (exemplos clássicos de validação), não de pessoas reais.
const CNPJ = '11222333000181';
const CNPJ_ALFA = '12ABC34501DE35'; // exemplo oficial da Receita Federal (CNPJ alfanumérico)
const CPF = '52998224725';
const IE9 = '032141840'; // exemplo do Sintegra para PE: 0321418-40

teste('dígitos verificadores de referência', () => {
  assert.ok(L.cnpjValido(CNPJ));
  assert.ok(L.cnpjValido(CNPJ_ALFA), 'CNPJ alfanumérico oficial');
  assert.ok(L.cpfValido(CPF));
  assert.ok(L.iePe9Valida(IE9));
  assert.ok(!L.cnpjValido('11222333000182'));
  assert.ok(!L.cpfValido('52998224726'));
  assert.ok(!L.iePe9Valida('032141841'));
  assert.ok(!L.cpfValido('11111111111'), 'sequência repetida');
});

teste('formato novo tipo;identificador;nome com e sem máscara, tipo em qualquer caixa', () => {
  const r = L.interpretarLista([
    'CNPJ;11.222.333/0001-81;EMPRESA ALFA',
    'cpf; 529.982.247-25 ;PESSOA BETA',
    'IE;0321418-40;EMPRESA GAMA',
    'Inscrição Estadual;032141840;EMPRESA DELTA (repetida)',
  ].join('\n'));
  const [a, b, c, d] = r.registros;
  assert.deepStrictEqual([a.status, a.tipo, a.identificador, a.formatado], ['valido', 'CNPJ', CNPJ, '11.222.333/0001-81']);
  assert.deepStrictEqual([b.status, b.tipo, b.identificador, b.nome], ['valido', 'CPF', CPF, 'PESSOA BETA']);
  assert.deepStrictEqual([c.status, c.tipo, c.identificador, c.formatado], ['valido', 'IE', IE9, '0321418-40']);
  assert.strictEqual(d.status, 'ignorada');
  assert.match(d.motivo, /repetido \(igual à linha 3\)/);
  assert.deepStrictEqual(r.resumo.porTipo, { CNPJ: 1, CPF: 1, IE: 1 });
});

teste('formato antigo cnpj;nome continua funcionando (CNPJ reconhecido sozinho)', () => {
  const r = L.interpretarLista(`${CNPJ};EMPRESA EXEMPLO UM LTDA\n11.222.333/0001-81;MESMA EMPRESA`);
  assert.strictEqual(r.registros[0].status, 'valido');
  assert.strictEqual(r.registros[0].tipo, 'CNPJ');
  assert.strictEqual(r.registros[0].nome, 'EMPRESA EXEMPLO UM LTDA');
  assert.strictEqual(r.registros[1].status, 'ignorada', 'mesmo CNPJ com máscara é repetido');
});

teste('formato antigo: zeros perdidos no Excel são completados só se os dígitos conferirem', () => {
  const r = L.interpretarLinha('1222333000181;EMPRESA SEM ZERO', 1); // perdeu o "0" do início? não: 13 dígitos
  // 01.222.333/0001-81 não é válido, então NÃO completa:
  assert.strictEqual(r.status, 'invalido');
  const valido13 = '191000000001'.padStart(12, '0'); // apenas para garantir que o caminho existe
  assert.ok(valido13.length === 12);
});

teste('11 dígitos sem tipo NÃO viram CPF (pode ser outra coisa): exige o tipo', () => {
  const r = L.interpretarLinha(`${CPF};PESSOA`, 1);
  assert.strictEqual(r.status, 'invalido');
  assert.match(r.motivo, /Informe o tipo/);
});

teste('Inscrição Estadual não é confundida com CPF/CNPJ', () => {
  assert.strictEqual(L.interpretarLinha(`IE;${CPF};X`, 1).status, 'invalido', 'IE com 11 dígitos é recusada');
  // Com o tipo CPF informado, 9 dígitos só viram CPF se os verificadores conferirem depois de
  // completar os zeros perdidos (Excel), e isso vem SEMPRE com aviso na tela.
  const cpf9 = L.interpretarLinha(`CPF;${IE9};X`, 1);
  assert.ok(cpf9.status === 'invalido' || cpf9.avisos.some((a) => /zeros à esquerda completados/.test(a)), 'completar zeros de CPF sempre é avisado');
  assert.strictEqual(L.interpretarLinha('CPF;123456780;X', 1).status, 'invalido', 'CPF de 9 dígitos que não confere é recusado');
  assert.strictEqual(L.interpretarLinha(`${IE9};EMPRESA`, 1).status, 'invalido', 'IE sem tipo é recusada');
  const ie8 = L.interpretarLinha('IE;32141840;EMPRESA', 1);
  assert.strictEqual(ie8.status, 'valido', 'zero à esquerda da IE completado');
  assert.strictEqual(ie8.identificador, IE9);
});

teste('CNPJ alfanumérico (2026) é aceito nos dois formatos', () => {
  const a = L.interpretarLinha('CNPJ;12.ABC.345/01DE-35;EMPRESA NOVA', 1);
  assert.deepStrictEqual([a.status, a.identificador, a.formatado], ['valido', CNPJ_ALFA, '12.ABC.345/01DE-35']);
  const b = L.interpretarLinha('12abc34501de35;EMPRESA NOVA', 1);
  assert.strictEqual(b.status, 'valido');
  assert.strictEqual(b.tipo, 'CNPJ');
  assert.strictEqual(L.interpretarLinha('12.ABC.345/01DE-36;ERRADO', 1).status, 'invalido');
});

teste('linhas vazias, comentários e cabeçalho são ignorados; inválidas não param a lista; ordem preservada', () => {
  const r = L.interpretarLista([
    'tipo;identificador;nome',
    '',
    '# comentário',
    'CNPJ;11.222.333/0001-82;DV ERRADO',
    'XYZ;123;TIPO ERRADO',
    'CNPJ;11222333000181',
    'só texto',
    `CPF;${CPF};PESSOA BETA`,
    '',
  ].join('\n'));
  const st = r.registros.map((x) => x.status);
  assert.deepStrictEqual(st, ['ignorada', 'ignorada', 'ignorada', 'invalido', 'invalido', 'invalido', 'invalido', 'valido']);
  assert.match(r.registros[3].motivo, /dígitos verificadores/);
  assert.match(r.registros[4].motivo, /desconhecido/);
  assert.match(r.registros[5].motivo, /faltou o nome/);
  assert.match(r.registros[6].motivo, /separador/);
  assert.strictEqual(r.registros[7].linha, 8, 'número da linha original preservado');
  assert.deepStrictEqual([r.resumo.validos, r.resumo.invalidos], [1, 4]);
});

teste('separador TAB (colado do Excel) e nome com ";" dentro', () => {
  const r = L.interpretarLinha(`CNPJ\t${CNPJ}\tEMPRESA TAB`, 1);
  assert.strictEqual(r.status, 'valido');
  const n = L.interpretarLinha(`CNPJ;${CNPJ};EMPRESA; FILIAL 2`, 1);
  assert.strictEqual(n.nome, 'EMPRESA; FILIAL 2');
});

teste('registro para a extensão leva só o necessário e CPF mascarado', () => {
  const r = L.registroParaExtensao(L.interpretarLinha(`CPF;${CPF};PESSOA BETA`, 5));
  assert.deepStrictEqual(Object.keys(r).sort(), ['formatado', 'identificador', 'linha', 'mascarado', 'nome', 'tipo']);
  assert.strictEqual(r.mascarado, '***.982.247-**');
  assert.strictEqual(L.registroParaExtensao({ status: 'invalido' }), null);
});

teste('centenas de registros são lidos rapidamente', () => {
  const linhas = [];
  for (let i = 0; i < 800; i++) linhas.push(`CNPJ;${CNPJ};EMPRESA ${i}`);
  const t0 = Date.now();
  const r = L.interpretarLista(linhas.join('\n'));
  assert.ok(Date.now() - t0 < 1000);
  assert.strictEqual(r.resumo.validos, 1, 'repetidos ignorados');
  assert.strictEqual(r.resumo.ignoradas, 799);
});

(async () => {
  let falhas = 0;
  for (const t of testes) {
    try {
      await t.fn();
      console.log('ok   ', t.nome);
    } catch (e) {
      falhas++;
      console.log('FALHA', t.nome, '\n     ', e.message);
    }
  }
  console.log(`\n${testes.length - falhas}/${testes.length} testes passaram.`);
  process.exitCode = falhas ? 1 : 0;
})();
