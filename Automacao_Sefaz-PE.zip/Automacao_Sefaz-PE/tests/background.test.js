// Teste do background.js com uma API "chrome" simulada (Node, sem dependências).
// Uso: node tests/background.test.js   (a partir da pasta Automacao_Sefaz-PE)
'use strict';

const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const EXT = path.join(__dirname, '..', 'Retirar_Certidao_SEFAZ-PE');
const PORTAL = 'https://atendimento.sefaz.pe.gov.br/lowcode/public/form/frm_psfz_home/default#!/?form=frm_psfz_default';

// terminal: null = iniciador desligado (fetch falha, como no uso normal pelo popup);
// { token, modo } = iniciador com sessão pendente.
function criarAmbiente({ contentResponde = true, terminal = null } = {}) {
  const dados = {};
  const ouvintes = { msg: null, removida: null, instalada: null };
  const enviadosAba = [];
  const abasFechadas = [];
  const terminalRecebeu = [];
  let reivindicada = false;
  const fetch = async (url, opcoes = {}) => {
    if (!terminal) throw new Error('connection refused');
    const caminho = new URL(url).pathname;
    const corpo = opcoes.body ? JSON.parse(opcoes.body) : null;
    terminalRecebeu.push({ caminho, corpo });
    let resposta = { ok: false };
    if (caminho === '/sessao') resposta = reivindicada ? { ativa: false } : { ativa: true, token: terminal.token, modo: terminal.modo, origem: terminal.origem, config: terminal.config };
    if (caminho === '/reivindicar') { resposta = { ok: !reivindicada && corpo.token === terminal.token }; reivindicada = true; }
    if (caminho === '/evento') resposta = { ok: true };
    if (caminho === '/registro') resposta = corpo.situacao === 'nao_encontrado' ? { ok: true, proximo: null, resumo: { total: 2, sucesso: 1, erro: 0, naoEncontrado: 1 }, planilha: 'C:\\Pasta\\resultado.xlsx' } : { ok: true, proximo: { linha: 2, tipo: 'CPF', identificador: '52998224725', formatado: '529.982.247-25', mascarado: '***.982.247-**', nome: 'PESSOA GAMA' }, lote: { total: 2, posicao: 2, intervaloMs: 5000 }, intervaloMs: 5000 };
    if (caminho === '/arquivo') resposta = corpo.token === terminal.token ? { ok: true, caminho: 'C:\\Pasta\\36.690.216_0001-73_NOME.pdf', arquivo: '36.690.216_0001-73_NOME.pdf', bytes: 52000 } : { ok: false, erro: 'token' };
    return { ok: true, json: async () => resposta };
  };
  const chrome = {
    storage: { local: {
      get: async (k) => { const ks = Array.isArray(k) ? k : [k]; const r = {}; ks.forEach((x) => { if (x in dados) r[x] = JSON.parse(JSON.stringify(dados[x])); }); return r; },
      set: async (o) => { Object.assign(dados, JSON.parse(JSON.stringify(o))); },
    } },
    action: { setBadgeText: async () => {}, setBadgeBackgroundColor: async () => {} },
    runtime: {
      onMessage: { addListener: (f) => { ouvintes.msg = f; } },
      onInstalled: { addListener: (f) => { ouvintes.instalada = f; } },
      onStartup: { addListener: () => {} },
      getManifest: () => JSON.parse(fs.readFileSync(path.join(EXT, 'manifest.json'), 'utf8')),
    },
    tabs: {
      sendMessage: async (tabId, msg) => {
        enviadosAba.push({ tabId, msg });
        if (!contentResponde) throw new Error('Receiving end does not exist.');
        return { ok: true };
      },
      onRemoved: { addListener: (f) => { ouvintes.removida = f; } },
      remove: async (id) => { abasFechadas.push(id); },
    },
    scripting: { executeScript: async () => { throw new Error('sem permissão no teste'); } },
    extension: { isAllowedIncognitoAccess: async () => true },
  };
  const ctx = { chrome, console, setTimeout, clearTimeout, setInterval: (fn, ms) => { const h = setInterval(fn, ms); h.unref(); return h; }, clearInterval, Date, Math, JSON, Promise, URL, fetch, AbortController };
  ctx.self = ctx;
  ctx.globalThis = ctx;
  ctx.importScripts = (f) => vm.runInContext(fs.readFileSync(path.join(EXT, f), 'utf8'), ctx);
  vm.createContext(ctx);
  vm.runInContext(fs.readFileSync(path.join(EXT, 'background.js'), 'utf8'), ctx);

  const enviar = (msg, sender = {}) => new Promise((resolve) => ouvintes.msg(msg, sender, resolve));
  const estado = () => dados.sefazpe_estado;
  const logs = () => dados.sefazpe_logs || [];
  return { enviar, estado, logs, ouvintes, enviadosAba, terminalRecebeu, abasFechadas };
}

const ABA_ANONIMA = { tab: { id: 9, incognito: true, url: PORTAL } };
const esperarFila = () => new Promise((r) => setTimeout(r, 30));

const testes = [];
const teste = (nome, fn) => testes.push({ nome, fn });

teste('iniciar recusa aba que não é o portal', async () => {
  const a = criarAmbiente();
  const r = await a.enviar({ tipo: 'comando', comando: 'iniciar', tabId: 5, url: 'https://www.google.com/' });
  assert.strictEqual(r.ok, false);
  assert.strictEqual(a.estado(), undefined);
});

teste('iniciar cria execução e manda executar na aba', async () => {
  const a = criarAmbiente();
  const r = await a.enviar({ tipo: 'comando', comando: 'iniciar', tabId: 7, url: PORTAL });
  assert.strictEqual(r.ok, true);
  assert.strictEqual(a.estado().status, 'executando');
  assert.strictEqual(a.estado().tabId, 7);
  assert.ok(a.estado().execId);
  assert.ok(a.enviadosAba.some((e) => e.msg.tipo === 'executar' && e.tabId === 7));
  assert.match(a.logs()[0].acao, /Automação iniciada/);
});

teste('iniciar duas vezes na mesma aba é recusado', async () => {
  const a = criarAmbiente();
  await a.enviar({ tipo: 'comando', comando: 'iniciar', tabId: 7, url: PORTAL });
  const r = await a.enviar({ tipo: 'comando', comando: 'iniciar', tabId: 7, url: PORTAL });
  assert.strictEqual(r.ok, false);
});

teste('atualização de execução antiga é ignorada', async () => {
  const a = criarAmbiente();
  await a.enviar({ tipo: 'comando', comando: 'iniciar', tabId: 7, url: PORTAL });
  const r = await a.enviar({ tipo: 'estado:atualizar', execId: 'velho', parcial: { etapa: 'concluida' } });
  assert.strictEqual(r.ignorado, true);
  assert.strictEqual(a.estado().etapa, 'verificar_portal');
});

teste('pausa do usuário prevalece sobre status vindo da página', async () => {
  const a = criarAmbiente();
  await a.enviar({ tipo: 'comando', comando: 'iniciar', tabId: 7, url: PORTAL });
  const execId = a.estado().execId;
  await a.enviar({ tipo: 'comando', comando: 'pausar' });
  await a.enviar({ tipo: 'estado:atualizar', execId, parcial: { status: 'aguardando_login', etapa: 'verificar_login' } });
  assert.strictEqual(a.estado().status, 'pausado');
  assert.strictEqual(a.estado().statusAntesPausa, 'aguardando_login');
  assert.strictEqual(a.estado().etapa, 'verificar_login');
  await a.enviar({ tipo: 'comando', comando: 'continuar' });
  assert.strictEqual(a.estado().status, 'aguardando_login');
});

teste('continuar após LOGIN_INDETERMINADO marca confirmação manual', async () => {
  const a = criarAmbiente();
  await a.enviar({ tipo: 'comando', comando: 'iniciar', tabId: 7, url: PORTAL });
  const execId = a.estado().execId;
  await a.enviar({ tipo: 'estado:atualizar', execId, parcial: { status: 'erro', aguardandoConfirmacaoLogin: true, recargas: 2 } });
  await a.enviar({ tipo: 'comando', comando: 'continuar' });
  assert.strictEqual(a.estado().status, 'executando');
  assert.strictEqual(a.estado().loginConfirmadoManual, true);
  assert.strictEqual(a.estado().aguardandoConfirmacaoLogin, false);
  assert.strictEqual(a.estado().recargas, 0);
});

teste('parar encerra e continuar depois é recusado', async () => {
  const a = criarAmbiente();
  await a.enviar({ tipo: 'comando', comando: 'iniciar', tabId: 7, url: PORTAL });
  await a.enviar({ tipo: 'comando', comando: 'parar' });
  assert.strictEqual(a.estado().status, 'parado');
  const r = await a.enviar({ tipo: 'comando', comando: 'continuar' });
  assert.strictEqual(r.ok, false);
});

teste('fechar a aba encerra a execução', async () => {
  const a = criarAmbiente();
  await a.enviar({ tipo: 'comando', comando: 'iniciar', tabId: 7, url: PORTAL });
  await a.ouvintes.removida(7);
  assert.strictEqual(a.estado().status, 'parado');
});

teste('aba sem content script e sem injeção vira erro de comunicação', async () => {
  const a = criarAmbiente({ contentResponde: false });
  const r = await a.enviar({ tipo: 'comando', comando: 'iniciar', tabId: 7, url: PORTAL });
  assert.strictEqual(r.ok, false);
  assert.strictEqual(a.estado().status, 'erro');
});

teste('logs não guardam parâmetros sensíveis', async () => {
  const a = criarAmbiente();
  await a.enviar({ tipo: 'comando', comando: 'iniciar', tabId: 7, url: PORTAL });
  const execId = a.estado().execId;
  await a.enviar({ tipo: 'log', execId, entrada: { acao: 'Voltou de https://sso.exemplo/auth?code=ABC123&state=XYZ e token=abc senha: 123' } });
  const ultimo = a.logs().at(-1).acao;
  assert.ok(!/ABC123|XYZ|abc\b|123$/.test(ultimo), ultimo);
  assert.match(ultimo, /token=\[omitido\]/);
});

teste('registrar devolve o tabId do remetente', async () => {
  const a = criarAmbiente();
  const r = await a.enviar({ tipo: 'registrar' }, { tab: { id: 42 } });
  assert.strictEqual(r.tabId, 42);
  assert.strictEqual(r.estado.status, 'ocioso');
});

teste('atualização da extensão pausa uma execução em andamento', async () => {
  const a = criarAmbiente();
  await a.enviar({ tipo: 'comando', comando: 'iniciar', tabId: 7, url: PORTAL });
  await a.ouvintes.instalada({ reason: 'update' });
  assert.strictEqual(a.estado().status, 'pausado');
});

// ---- Integração com o terminal -------------------------------------------------------------------

teste('terminal: aba anônima do portal pega a sessão e inicia no modo acesso', async () => {
  const a = criarAmbiente({ terminal: { token: 'tok-1', modo: 'acesso' } });
  const r = await a.enviar({ tipo: 'registrar' }, ABA_ANONIMA);
  assert.strictEqual(r.iniciadoPeloTerminal, true);
  assert.strictEqual(r.estado.status, 'executando');
  assert.strictEqual(r.estado.modo, 'acesso');
  assert.strictEqual(r.estado.origem, 'terminal');
  assert.strictEqual(r.estado.tabId, 9);
  assert.ok(a.terminalRecebeu.some((x) => x.caminho === '/reivindicar' && x.corpo.tabId === 9));
  // Sem "executar" enviado: a própria aba começa ao receber a resposta (evita dupla execução).
  assert.ok(!a.enviadosAba.some((e) => e.msg.tipo === 'executar'));
});

teste('terminal: sessão é de uso único (segunda aba anônima não inicia outra)', async () => {
  const a = criarAmbiente({ terminal: { token: 'tok-1', modo: 'acesso' } });
  await a.enviar({ tipo: 'registrar' }, ABA_ANONIMA);
  const r2 = await a.enviar({ tipo: 'registrar' }, { tab: { id: 10, incognito: true, url: PORTAL } });
  assert.ok(!r2.iniciadoPeloTerminal);
  assert.strictEqual(a.estado().tabId, 9);
});

teste('terminal: janela normal (não anônima) não pega a sessão', async () => {
  const a = criarAmbiente({ terminal: { token: 'tok-1', modo: 'acesso' } });
  const r = await a.enviar({ tipo: 'registrar' }, { tab: { id: 9, incognito: false, url: PORTAL } });
  assert.ok(!r.iniciadoPeloTerminal);
  assert.strictEqual(r.estado.status, 'ocioso');
});

teste('terminal desligado: registrar funciona normalmente', async () => {
  const a = criarAmbiente();
  const r = await a.enviar({ tipo: 'registrar' }, ABA_ANONIMA);
  assert.ok(!r.iniciadoPeloTerminal);
  assert.strictEqual(r.estado.status, 'ocioso');
});

teste('terminal: registros e mudanças de status vão para o terminal com o token', async () => {
  const a = criarAmbiente({ terminal: { token: 'tok-1', modo: 'acesso' } });
  await a.enviar({ tipo: 'registrar' }, ABA_ANONIMA);
  const execId = a.estado().execId;
  await a.enviar({ tipo: 'log', execId, entrada: { acao: 'Procurando botão Login com gov.br...', tag: 'LOGIN' } });
  await a.enviar({ tipo: 'estado:atualizar', execId, parcial: { status: 'concluido', mensagem: 'Etapa de autenticação concluída.' } });
  await esperarFila();
  const eventos = a.terminalRecebeu.filter((x) => x.caminho === '/evento').map((x) => x.corpo);
  assert.ok(eventos.every((e) => e.token === 'tok-1'));
  assert.ok(eventos.some((e) => e.tipo === 'log' && e.tag === 'LOGIN' && /Login com gov\.br/.test(e.mensagem)));
  assert.ok(eventos.some((e) => e.tipo === 'status' && e.status === 'concluido'));
});

teste('execução do popup não envia nada ao terminal', async () => {
  const a = criarAmbiente({ terminal: { token: 'tok-1', modo: 'acesso' } });
  await a.enviar({ tipo: 'comando', comando: 'iniciar', tabId: 7, url: PORTAL });
  const execId = a.estado().execId;
  await a.enviar({ tipo: 'log', execId, entrada: { acao: 'teste' } });
  await esperarFila();
  assert.strictEqual(a.estado().origem, 'popup');
  assert.ok(!a.terminalRecebeu.some((x) => x.caminho === '/evento'));
});

teste('não inicia segunda execução enquanto outra aba está executando', async () => {
  const a = criarAmbiente();
  await a.enviar({ tipo: 'comando', comando: 'iniciar', tabId: 7, url: PORTAL });
  const r = await a.enviar({ tipo: 'comando', comando: 'iniciar', tabId: 8, url: PORTAL });
  assert.strictEqual(r.ok, false);
  assert.strictEqual(a.estado().tabId, 7);
});

teste('continuar após erro zera os contadores de login e autorização', async () => {
  const a = criarAmbiente();
  await a.enviar({ tipo: 'comando', comando: 'iniciar', tabId: 7, url: PORTAL });
  const execId = a.estado().execId;
  await a.enviar({ tipo: 'estado:atualizar', execId, parcial: { status: 'erro', loginAcionamentos: 2, autorizacaoCliques: 2 } });
  await a.enviar({ tipo: 'comando', comando: 'continuar' });
  assert.strictEqual(a.estado().loginAcionamentos, 0);
  assert.strictEqual(a.estado().autorizacaoCliques, 0);
});

// ---- Consulta de Certidão Negativa (0.4.0) -------------------------------------------------------

teste('interface: o registro da lista chega ao estado (modo certidao_negativa)', async () => {
  const registro = { linha: 3, tipo: 'IE', identificador: '0321418-40', formatado: '0321418-40', mascarado: '0321418-40', nome: 'EMPRESA GAMA' };
  const a = criarAmbiente({ terminal: { token: 'tok-2', modo: 'certidao_negativa', origem: 'interface', config: { velocidadeMouse: 'normal', registro } } });
  const r = await a.enviar({ tipo: 'registrar' }, ABA_ANONIMA);
  assert.strictEqual(r.estado.modo, 'certidao_negativa');
  assert.strictEqual(r.estado.origem, 'interface');
  assert.strictEqual(r.estado.velocidadeMouse, 'normal');
  assert.strictEqual(r.estado.registro.tipo, 'IE');
  assert.strictEqual(r.estado.registro.identificador, '032141840', 'identificador chega só com dígitos');
  assert.strictEqual(r.estado.registro.linha, 3);
  assert.strictEqual(r.estado.pesquisaEnviada, false);
});

teste('registro com tipo desconhecido é descartado', async () => {
  const a = criarAmbiente({ terminal: { token: 'tok-4', modo: 'certidao_negativa', origem: 'interface', config: { registro: { tipo: 'RG', identificador: '123', nome: 'X' } } } });
  const r = await a.enviar({ tipo: 'registrar' }, ABA_ANONIMA);
  assert.strictEqual(r.estado.registro, null);
});

teste('estados da automação: nomes calculados a partir do status e da etapa', async () => {
  const ctx = {};
  ctx.globalThis = ctx;
  vm.createContext(ctx);
  vm.runInContext(fs.readFileSync(path.join(EXT, 'modules', 'constantes.js'), 'utf8'), ctx);
  const K = ctx.SEFAZPE_CONST;
  const e = (o) => K.estadoAutomacao({ execId: 'x', status: 'executando', ...o });
  assert.strictEqual(e({ etapa: 'verificar_portal' }), 'INICIANDO');
  assert.strictEqual(e({ etapa: 'autenticacao_govbr', paginaAutenticacao: 'login_govbr', status: 'aguardando_login' }), 'AGUARDANDO_LOGIN');
  assert.strictEqual(e({ etapa: 'autenticacao_govbr', paginaAutenticacao: 'autorizacao', status: 'aguardando_login' }), 'AGUARDANDO_AUTORIZACAO');
  assert.strictEqual(e({ etapa: 'autenticacao_govbr', paginaAutenticacao: 'autorizacao' }), 'AUTORIZANDO_GOVBR');
  assert.strictEqual(e({ etapa: 'autenticacao_govbr', paginaAutenticacao: 'login_govbr' }), 'AUTENTICANDO_GOVBR');
  assert.strictEqual(e({ etapa: 'identificar_tela_sefaz' }), 'ACESSANDO_SEFAZ');
  assert.strictEqual(e({ etapa: 'localizar_certidao_negativa' }), 'LOCALIZANDO_CERTIDAO_NEGATIVA');
  assert.strictEqual(e({ etapa: 'abrir_certidao_negativa' }), 'ABRINDO_CONSULTA');
  assert.strictEqual(e({ etapa: 'selecionar_tipo_documento' }), 'IDENTIFICANDO_TIPO_DOCUMENTO');
  assert.strictEqual(e({ etapa: 'preencher_identificador' }), 'PREENCHENDO_IDENTIFICADOR');
  assert.strictEqual(e({ etapa: 'preencher_identificador', subestado: 'VALIDANDO_PREENCHIMENTO' }), 'VALIDANDO_PREENCHIMENTO');
  assert.strictEqual(e({ etapa: 'clicar_pesquisar' }), 'CLICANDO_PESQUISAR');
  assert.strictEqual(e({ etapa: 'aguardar_resposta' }), 'AGUARDANDO_RESPOSTA');
  assert.strictEqual(e({ etapa: 'preencher_identificador', recuperando: true }), 'ERRO_RECUPERAVEL');
  assert.strictEqual(e({ status: 'erro' }), 'AGUARDANDO_INTERVENCAO');
  assert.strictEqual(e({ status: 'concluido' }), 'ETAPA_CONCLUIDA');
  // Todo estado pedido existe com um rótulo:
  for (const nome of ['INICIANDO', 'AGUARDANDO_LOGIN', 'AUTENTICANDO_GOVBR', 'AGUARDANDO_AUTORIZACAO', 'AUTORIZANDO_GOVBR', 'ACESSANDO_SEFAZ', 'LOCALIZANDO_CERTIDAO_NEGATIVA', 'ABRINDO_CONSULTA', 'IDENTIFICANDO_TIPO_DOCUMENTO', 'PREENCHENDO_IDENTIFICADOR', 'VALIDANDO_PREENCHIMENTO', 'CLICANDO_PESQUISAR', 'AGUARDANDO_RESPOSTA', 'ETAPA_CONCLUIDA', 'ERRO_RECUPERAVEL', 'AGUARDANDO_INTERVENCAO']) {
    assert.ok(K.ESTADOS_AUTOMACAO[nome], `falta o estado ${nome}`);
  }
});

teste('eventos ao terminal levam o nome do estado da automação', async () => {
  const a = criarAmbiente({ terminal: { token: 'tok-3', modo: 'acesso' } });
  await a.enviar({ tipo: 'registrar' }, ABA_ANONIMA);
  const execId = a.estado().execId;
  await a.enviar({ tipo: 'estado:atualizar', execId, parcial: { etapa: 'autenticacao_govbr', paginaAutenticacao: 'autorizacao', status: 'aguardando_login' } });
  await esperarFila();
  const ev = a.terminalRecebeu.filter((x) => x.caminho === '/evento').map((x) => x.corpo).find((e) => e.tipo === 'status');
  assert.strictEqual(ev.estadoAutomacao, 'AGUARDANDO_AUTORIZACAO');
});

teste('Continuar após erro NUNCA zera "pesquisa enviada" (sem pesquisa duplicada)', async () => {
  const a = criarAmbiente();
  await a.enviar({ tipo: 'comando', comando: 'iniciar', tabId: 7, url: PORTAL });
  const execId = a.estado().execId;
  await a.enviar({ tipo: 'estado:atualizar', execId, parcial: { pesquisaEnviada: true, status: 'erro', erroCodigo: 'SESSAO_EXPIRADA' } });
  await a.enviar({ tipo: 'comando', comando: 'continuar' });
  assert.strictEqual(a.estado().pesquisaEnviada, true);
  assert.strictEqual(a.estado().erroCodigo, null);
});

teste('PDF capturado após "Visualizar Certidão" vai ao computador e só então "arquivo" é gravado', async () => {
  const a = criarAmbiente({ terminal: { token: 'tok-pdf', modo: 'certidao_negativa', origem: 'interface', config: {} } });
  await a.enviar({ tipo: 'registrar' }, ABA_ANONIMA);
  const negado = await a.enviar({ tipo: 'arquivo:capturado', via: 'blob', base64: 'JVBERi0x' }, ABA_ANONIMA);
  assert.strictEqual(negado.ok, false, 'sem captura armada nada é enviado');
  const arm = await a.enviar({ tipo: 'captura:armar', ms: 60000 }, ABA_ANONIMA);
  assert.strictEqual(arm.ok, true, 'armar: ' + JSON.stringify(arm));
  assert.ok(a.enviadosAba.some((e) => e.msg.tipo === 'captura:armar' && e.tabId === 9), 'todos os quadros da aba são armados');
  assert.strictEqual(a.estado().arquivo, null);
  const outraAba = await a.enviar({ tipo: 'arquivo:capturado', via: 'blob', base64: 'JVBERi0x' }, { tab: { id: 55, incognito: true, url: PORTAL } });
  assert.strictEqual(outraAba.ok, false, 'aba que não é da execução nem aberta por ela é ignorada');
  const r = await a.enviar({ tipo: 'arquivo:capturado', via: 'blob', base64: 'JVBERi0x' }, ABA_ANONIMA);
  assert.strictEqual(r.ok, true, 'enviar: ' + JSON.stringify(r));
  const env = a.terminalRecebeu.find((x) => x.caminho === '/arquivo');
  assert.strictEqual(env.corpo.token, 'tok-pdf');
  assert.strictEqual(a.estado().arquivo.arquivo, '36.690.216_0001-73_NOME.pdf');
});

teste('Continuar após ARQUIVO_NAO_RECEBIDO libera novo "Visualizar" mas NUNCA nova emissão', async () => {
  const a = criarAmbiente();
  await a.enviar({ tipo: 'comando', comando: 'iniciar', tabId: 7, url: PORTAL });
  const execId = a.estado().execId;
  await a.enviar({ tipo: 'estado:atualizar', execId, parcial: { pesquisaEnviada: true, emissaoSolicitada: true, emissaoConfirmada: true, visualizarClicado: true, visualizarCliques: 1, status: 'erro', erroCodigo: 'ARQUIVO_NAO_RECEBIDO' } });
  await a.enviar({ tipo: 'comando', comando: 'continuar' });
  assert.strictEqual(a.estado().emissaoSolicitada, true);
  assert.strictEqual(a.estado().pesquisaEnviada, true);
  assert.strictEqual(a.estado().visualizarClicado, false);
});

teste('lista: próximo registro zera SÓ os campos do registro e fecha só a aba do PDF', async () => {
  const a = criarAmbiente({ terminal: { token: 'tok-l', modo: 'certidao_negativa', origem: 'interface', config: { registro: { linha: 1, tipo: 'CNPJ', identificador: '36690216000173', formatado: '36.690.216/0001-73', nome: 'X' }, lote: { total: 2, posicao: 1, intervaloMs: 5000 } } } });
  await a.enviar({ tipo: 'registrar' }, ABA_ANONIMA);
  const execId = a.estado().execId;
  assert.strictEqual(a.estado().lote.total, 2);
  await a.enviar({ tipo: 'estado:atualizar', execId, parcial: { pesquisaEnviada: true, emissaoSolicitada: true, emissaoConfirmada: true, visualizarClicado: true, arquivo: { caminho: 'C:\\a.pdf' }, capturaAbas: [77, 9], usuarioLogado: 'RENATO' } });
  const f = await a.enviar({ tipo: 'captura:fechar_abas' }, ABA_ANONIMA);
  assert.deepStrictEqual(a.abasFechadas, [77], 'a aba da execução (9) nunca é fechada');
  assert.strictEqual(f.fechadas, 1);
  const r = await a.enviar({ tipo: 'lote:registro', situacao: 'sucesso' }, ABA_ANONIMA);
  assert.strictEqual(r.ok, true);
  assert.strictEqual(r.proximo.tipo, 'CPF');
  const e = a.estado();
  assert.strictEqual(e.registro.identificador, '52998224725');
  assert.strictEqual(e.lote.posicao, 2);
  for (const c of ['pesquisaEnviada', 'emissaoSolicitada', 'emissaoConfirmada', 'visualizarClicado']) assert.strictEqual(e[c], false, c);
  assert.strictEqual(e.arquivo, null);
  assert.strictEqual(e.trocandoRegistro, true);
  assert.strictEqual(e.usuarioLogado, 'RENATO', 'a sessão/login não é zerada');
  assert.strictEqual(e.status, 'executando');
  const fim = await a.enviar({ tipo: 'lote:registro', situacao: 'nao_encontrado' }, ABA_ANONIMA);
  assert.strictEqual(fim.fim, true);
  assert.strictEqual(fim.planilha, 'C:\\Pasta\\resultado.xlsx');
});

teste('REGRESSÃO 15:54:59: a passagem ao próximo registro não vira "Nenhum PDF chegou" durante o intervalo', async () => {
  const a = criarAmbiente({ terminal: { token: 'tok-r', modo: 'certidao_negativa', origem: 'interface', config: { registro: { linha: 1, tipo: 'CNPJ', identificador: '36690216000173', formatado: '36.690.216/0001-73', nome: 'X' }, lote: { total: 7, posicao: 1, intervaloMs: 5000 } } } });
  await a.enviar({ tipo: 'registrar' }, ABA_ANONIMA);
  const execId = a.estado().execId;
  await a.enviar({ tipo: 'estado:atualizar', execId, parcial: { etapa: 'aguardar_arquivo', visualizarClicado: true } });
  await a.enviar({ tipo: 'captura:armar', ms: 60000 }, ABA_ANONIMA);
  await a.enviar({ tipo: 'arquivo:capturado', via: 'blob', base64: 'JVBERi0x' }, ABA_ANONIMA);
  assert.ok(a.estado().arquivo, 'PDF do 1º registro salvo');
  // Como na execução real: próximo registro (zera arquivo e captura) com a etapa ainda em
  // "aguardar_arquivo", e a página esperando o intervalo de 5 s.
  await a.enviar({ tipo: 'lote:registro', situacao: 'sucesso' }, ABA_ANONIMA);
  assert.strictEqual(a.estado().arquivo, null);
  assert.strictEqual(a.estado().etapa, 'aguardar_arquivo');
  await new Promise((r) => setTimeout(r, 3600)); // passa um ciclo da varredura (3 s)
  assert.strictEqual(a.estado().status, 'executando', `não pode pausar sozinho: ${a.estado().mensagem}`);
  assert.strictEqual(a.estado().erroCodigo, null);
});

teste('ocorrência de recuperação vai ao computador com etapa, problema, ação e tentativa', async () => {
  const a = criarAmbiente({ terminal: { token: 'tok-o', modo: 'certidao_negativa', origem: 'interface', config: { lote: { total: 2, posicao: 1, intervaloMs: 0, maxTentativas: 3, limiteEtapaMs: 90000 } } } });
  await a.enviar({ tipo: 'registrar' }, ABA_ANONIMA);
  assert.strictEqual(a.estado().lote.maxTentativas, 3);
  assert.strictEqual(a.estado().lote.limiteEtapaMs, 90000);
  await a.enviar({ tipo: 'lote:ocorrencia', ocorrencia: { etapa: 'Clicar em "Pesquisar"', codigo: 'ETAPA_DEMORADA', problema: 'passou de 120 s', acao: 'Recarregando a página', tentativa: '2/3', decorridoSeg: 130 } }, ABA_ANONIMA);
  await esperarFila();
  const ev = a.terminalRecebeu.filter((x) => x.caminho === '/evento').map((x) => x.corpo).find((e) => e.tipo === 'ocorrencia');
  assert.ok(ev && ev.ocorrencia.tentativa === '2/3' && ev.ocorrencia.codigo === 'ETAPA_DEMORADA' && ev.token === 'tok-o');
});

(async () => {
  let falhas = 0;
  for (const t of testes) {
    try {
      await t.fn();
      console.log('ok   ', t.nome);
    } catch (e) {
      falhas++;
      console.log('FALHA', t.nome, '\n     ', e.message);
    }
  }
  console.log(`\n${testes.length - falhas}/${testes.length} testes passaram.`);
  process.exitCode = falhas ? 1 : 0;
})();
