// Nome, conferência e salvamento do PDF da certidão (nucleo/arquivo_certidao.js) e a rota
// /arquivo do controle. Usa uma pasta temporária (nada da Área de Trabalho é tocado).
// Uso: node tests/arquivo_certidao.test.js
'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const http = require('http');
const A = require('../nucleo/arquivo_certidao');
const { criarControle } = require('../nucleo/controle');

// PDF mínimo válido (uma página), com tamanho realista.
function pdfDeTeste(texto = 'Certidao de teste') {
  const corpo = [
    '%PDF-1.4',
    '1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj',
    '2 0 obj << /Type /Pages /Kids [3 0 R] /Count 1 >> endobj',
    `3 0 obj << /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Contents 4 0 R >> endobj`,
    `4 0 obj << /Length ${texto.length + 30} >> stream`,
    `BT /F1 12 Tf 72 720 Td (${texto}) Tj ET`,
    'endstream endobj',
    '% ' + 'x'.repeat(1500),
    'trailer << /Root 1 0 R >>',
    '%%EOF',
  ].join('\n');
  return Buffer.from(corpo, 'latin1');
}

const CNPJ = { linha: 1, tipo: 'CNPJ', identificador: '36690216000173', formatado: '36.690.216/0001-73', mascarado: '36.690.216/0001-73', nome: '36.690.216 SERGIO HENRIQUE CASSIANO DA SILVA' };
const CPF = { linha: 2, tipo: 'CPF', identificador: '12345678900', formatado: '123.456.789-00', mascarado: '***.456.789-**', nome: 'Nome do Titular' };
const IE = { linha: 3, tipo: 'IE', identificador: '012345678', formatado: '0123456-78', mascarado: '0123456-78', nome: 'Nome da Empresa' };

(async () => {
  const checks = [];
  const ok = (nome, cond) => checks.push([nome, !!cond]);
  const base = fs.mkdtempSync(path.join(os.tmpdir(), 'sefazpe-arquivo-'));
  const pasta = path.join(base, 'Resultados');
  const downloads = path.join(base, 'Downloads');
  fs.mkdirSync(pasta); fs.mkdirSync(downloads);
  const sobras = () => fs.readdirSync(pasta).filter((f) => /\.parcial$|\.crdownload$/.test(f));

  try {
    // ---- Nomes -----------------------------------------------------------------------------------
    ok('CNPJ: exemplo do pedido (36.690.216_0001-73_SERGIO_HENRIQUE_CASSIANO_DA_SILVA.pdf)',
      A.nomeDoArquivo(CNPJ, '36.690.216 SERGIO HENRIQUE CASSIANO DA SILVA').arquivo === '36.690.216_0001-73_SERGIO_HENRIQUE_CASSIANO_DA_SILVA.pdf');
    ok('CPF: CPF_12345678900_NOME_DO_TITULAR.pdf', A.nomeDoArquivo(CPF, '').arquivo === 'CPF_12345678900_Nome_do_Titular.pdf');
    ok('IE: IE_012345678_NOME_DA_EMPRESA.pdf', A.nomeDoArquivo(IE, 'NOME DA EMPRESA').arquivo === 'IE_012345678_Nome_da_Empresa.pdf');
    const semNome = A.nomeDoArquivo({ ...CNPJ, nome: '' }, 'EMPRESA DO SITE LTDA');
    ok('sem nome na lista: usa o Nome/Razão Social do site', semNome.arquivo === '36.690.216_0001-73_EMPRESA_DO_SITE_LTDA.pdf' && semNome.origemNome === 'site');
    const diverge = A.nomeDoArquivo({ ...CNPJ, nome: 'OUTRA EMPRESA QUALQUER' }, '36.690.216 SERGIO HENRIQUE CASSIANO DA SILVA');
    ok('nome da lista diferente do site: usa o do site e avisa', diverge.origemNome === 'site' && /não confere/.test(diverge.aviso || ''));
    ok('nome da lista com pequena diferença (LTDA/acentos) continua sendo o da lista', A.nomeDoArquivo({ ...CNPJ, nome: 'Padaria São João' }, 'PADARIA SAO JOAO LTDA').origemNome === 'lista');
    const proibidos = A.nomeDoArquivo({ ...CNPJ, nome: 'A/B:C*D?"E<F>G|H\\I.' }, '');
    ok('caracteres inválidos no Windows são removidos', !/[<>:"/\\|?*]/.test(proibidos.arquivo.replace(/\.pdf$/, '')) && proibidos.arquivo.startsWith('36.690.216_0001-73_A_B_C_D_E_F_G_H_I'));
    ok('nome muito longo é encurtado (≤ 150 caracteres)', A.nomeDoArquivo({ ...CNPJ, nome: 'X'.repeat(400) }, '').arquivo.length <= 150);
    ok('sem nome em lugar nenhum: só o identificador', A.nomeDoArquivo({ ...CNPJ, nome: '' }, '').arquivo === '36.690.216_0001-73.pdf');

    // ---- Conferência do PDF --------------------------------------------------------------------------
    ok('PDF válido passa (1 página)', A.validarPdf(pdfDeTeste()).ok && A.validarPdf(pdfDeTeste()).paginas === 1);
    ok('página HTML (erro do site) é recusada', /HTML/.test(A.validarPdf(Buffer.from('<!DOCTYPE html><html>' + 'x'.repeat(2000))).motivo));
    const cortado = pdfDeTeste().subarray(0, 1500);
    ok('PDF cortado (download incompleto) é recusado', /incompleto/.test(A.validarPdf(cortado).motivo || ''));

    // ---- Identificador dentro do PDF (conteúdo comprimido, como nos PDFs reais) --------------------------
    const comprimido = (texto) => {
      const z = require('zlib').deflateSync(Buffer.from(`BT /F1 10 Tf 50 700 Td (${texto}) Tj ET`, 'latin1'));
      return Buffer.concat([
        Buffer.from('%PDF-1.5\n1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj\n2 0 obj << /Type /Pages /Kids [3 0 R] /Count 1 >> endobj\n3 0 obj << /Type /Page /Parent 2 0 R /Contents 4 0 R >> endobj\n', 'latin1'),
        Buffer.from(`4 0 obj << /Length ${z.length} /Filter /FlateDecode >>\nstream\n`, 'latin1'), z,
        Buffer.from('\nendstream endobj\n% ' + 'x'.repeat(1500) + '\ntrailer << /Root 1 0 R >>\n%%EOF\n', 'latin1'),
      ]);
    };
    ok('identificador: CNPJ achado no texto comprimido da certidão', A.conferirIdentificador(comprimido('CERTIDAO NEGATIVA DE DEBITOS - CNPJ: 36.690.216/0001-73'), CNPJ).situacao === 'confere');
    ok('identificador: certidão de OUTRO CNPJ é apontada', A.conferirIdentificador(comprimido('CERTIDAO NEGATIVA - CNPJ: 11.222.333/0001-81'), CNPJ).situacao === 'diverge');
    ok('identificador: texto ilegível (fonte codificada) fica indeterminado, sem bloquear', A.conferirIdentificador(pdfDeTeste('xyz'), { ...CNPJ, identificador: '99999999000199' }).situacao !== 'diverge');
    const outro = await A.salvarCertidao({ pasta, registro: CNPJ, nomeSite: CNPJ.nome, bytes: comprimido('CERTIDAO NEGATIVA - CNPJ: 11.222.333/0001-81') });
    ok('certidão de outro CNPJ: guardada como _CONFERIR e NÃO dada como salva', !outro.ok && /_CONFERIR\.pdf$/.test(outro.caminho) && fs.existsSync(outro.caminho));
    fs.unlinkSync(outro.caminho);

    // ---- Salvamento a partir dos bytes -----------------------------------------------------------------
    const r1 = await A.salvarCertidao({ pasta, registro: CNPJ, nomeSite: CNPJ.nome, bytes: pdfDeTeste('um') });
    ok('PDF salvo na pasta com o nome certo', r1.ok && r1.arquivo === '36.690.216_0001-73_SERGIO_HENRIQUE_CASSIANO_DA_SILVA.pdf' && fs.existsSync(r1.caminho));
    const r2 = await A.salvarCertidao({ pasta, registro: CNPJ, nomeSite: CNPJ.nome, bytes: pdfDeTeste('dois') });
    ok('nome repetido: _2, sem sobrescrever o primeiro', r2.ok && r2.arquivo === '36.690.216_0001-73_SERGIO_HENRIQUE_CASSIANO_DA_SILVA_2.pdf' && fs.readFileSync(r1.caminho).toString('latin1').includes('(um)'));
    const ruim = await A.salvarCertidao({ pasta, registro: CNPJ, nomeSite: '', bytes: Buffer.from('<html>erro</html>'.repeat(100)) });
    ok('conteúdo que não é PDF não é salvo', !ruim.ok && fs.readdirSync(pasta).length === 2);
    ok('nenhum temporário (.parcial) fica na pasta', sobras().length === 0);
    const semPasta = await A.salvarCertidao({ pasta: path.join(base, 'nao-existe'), registro: CNPJ, bytes: pdfDeTeste() });
    ok('pasta inexistente: erro claro, nada criado fora', !semPasta.ok && /não existe/.test(semPasta.erro));

    // ---- Salvamento a partir de um download do Chrome ----------------------------------------------------
    const baixado = path.join(downloads, 'certidao.pdf');
    fs.writeFileSync(`${baixado}.crdownload`, pdfDeTeste('baixado').subarray(0, 800));
    setTimeout(() => { fs.writeFileSync(baixado, pdfDeTeste('baixado')); fs.unlinkSync(`${baixado}.crdownload`); }, 1200);
    const r3 = await A.salvarCertidao({ pasta, registro: IE, nomeSite: 'NOME DA EMPRESA', caminhoDownload: baixado });
    ok('download: espera terminar (.crdownload), move para a pasta e não deixa cópia no Downloads', r3.ok && r3.arquivo === 'IE_012345678_Nome_da_Empresa.pdf' && !fs.existsSync(baixado) && fs.readFileSync(r3.caminho).toString('latin1').includes('(baixado)'));
    const baixadoRuim = path.join(downloads, 'erro.pdf');
    fs.writeFileSync(baixadoRuim, '<!DOCTYPE html>' + 'x'.repeat(3000));
    const r4 = await A.salvarCertidao({ pasta, registro: IE, caminhoDownload: baixadoRuim });
    ok('download que não é PDF: recusado e o arquivo original fica onde estava', !r4.ok && fs.existsSync(baixadoRuim));

    // ---- Rota /arquivo do controle (ponta a ponta, com HTTP) -----------------------------------------------
    const linhas = [];
    const registro = { escrever: (tag, mensagem, nivel) => linhas.push({ tag, mensagem, nivel }), adicionarArquivo() {}, removerArquivo() {} };
    const pasta2 = path.join(base, 'Resultados2');
    fs.mkdirSync(pasta2);
    const controle = criarControle({ registro, abrirNavegador: false, selecionarCertificado: () => ({ fim: new Promise(() => {}), parar() {} }) });
    const srv = http.createServer((req, res) => { if (!controle.tratarPonte(req, res)) { res.writeHead(404); res.end(); } });
    await new Promise((r) => srv.listen(47995, '127.0.0.1', r));
    const pedir = (caminho, corpo) => fetch('http://127.0.0.1:47995' + caminho, { method: corpo ? 'POST' : 'GET', headers: { 'Content-Type': 'application/json', Origin: 'chrome-extension://abc' }, body: corpo ? JSON.stringify(corpo) : undefined }).then((r) => r.json());
    try {
      controle.iniciar({ modo: 'certidao_negativa', config: { pastaResultados: pasta2, registro: CNPJ } });
      const s = await pedir('/sessao');
      await pedir('/reivindicar', { token: s.token, tabId: 9 });
      const negado = await pedir('/arquivo', { token: 'errado', via: 'blob', base64: pdfDeTeste().toString('base64') }).catch(() => ({ ok: false }));
      ok('/arquivo sem o token da sessão é recusado', !negado.ok && fs.readdirSync(pasta2).length === 0);
      const pdf = pdfDeTeste('rota');
      const a1 = await pedir('/arquivo', { token: s.token, via: 'blob', base64: pdf.toString('base64'), nomeSite: '36.690.216 SERGIO HENRIQUE CASSIANO DA SILVA' });
      ok('/arquivo salva o PDF capturado e devolve o caminho', a1.ok && a1.arquivo === '36.690.216_0001-73_SERGIO_HENRIQUE_CASSIANO_DA_SILVA.pdf' && fs.existsSync(path.join(pasta2, a1.arquivo)));
      ok('registros [PDF], [VALIDAÇÃO], [SALVAMENTO], [VERIFICAÇÃO] e [ARQUIVO] com o caminho final', linhas.some((l) => l.tag === 'PDF' && /Documento recebido/.test(l.mensagem)) && ['VALIDAÇÃO', 'SALVAMENTO', 'VERIFICAÇÃO'].every((tg) => linhas.some((l) => l.tag === tg)) && linhas.some((l) => l.tag === 'ARQUIVO' && /PDF salvo na pasta configurada/.test(l.mensagem) && l.mensagem.includes(pasta2)));
      // O mesmo documento chega de novo pelo download do Chrome: não vira outro arquivo e a
      // cópia do Downloads é removida.
      const dup = path.join(downloads, 'duplicado.pdf');
      fs.writeFileSync(dup, pdf);
      const a2 = await pedir('/arquivo', { token: s.token, via: 'download', caminhoDownload: dup });
      ok('mesmo documento por outro caminho: reconhecido como duplicado, sem 2º arquivo', a2.ok && a2.duplicado && fs.readdirSync(pasta2).length === 1 && !fs.existsSync(dup));
      ok('estado da interface mostra o PDF salvo', controle.estado().arquivo && controle.estado().arquivo.arquivo === a1.arquivo);
      await pedir('/evento', { token: s.token, tipo: 'status', status: 'parado' });
    } finally {
      srv.close();
    }
  } finally {
    fs.rmSync(base, { recursive: true, force: true });
  }

  let falhas = 0;
  for (const [nome, passou] of checks) { console.log(passou ? 'ok   ' : 'FALHA', nome); if (!passou) falhas++; }
  console.log(`\n${checks.length - falhas}/${checks.length} verificações passaram.`);
  process.exit(falhas ? 1 : 0);
})();
