// Teste do servidor da interface sem abrir janelas: validação, criação da pasta, início da
// execução, ponte com a extensão (sessão com a configuração), comandos e conclusão.
// Uso: node tests/interface.test.js
'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawn } = require('child_process');

const PORTA = 47998;
const BASE = `http://127.0.0.1:${PORTA}`;
const EXT = 'chrome-extension://abcdefghijklmnop';
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'sefazpe-ui-'));

const pedir = (caminho, corpo, cab = {}) => fetch(BASE + caminho, {
  method: corpo ? 'POST' : 'GET',
  headers: { ...(corpo ? { 'Content-Type': 'application/json' } : {}), ...cab },
  body: corpo ? JSON.stringify(corpo) : undefined,
}).then(async (r) => ({ status: r.status, corpo: await r.json().catch(() => ({})) }));

const esperar = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  const filho = spawn(process.execPath, [path.join(__dirname, '..', 'interface', 'servidor.js'), '--sem-navegador', '--sem-chrome', '--porta', String(PORTA)], {
    env: { ...process.env, NO_COLOR: '1', SEFAZPE_AREA_TRABALHO: tmp, SEFAZPE_CONFIG: path.join(tmp, 'config.json') },
  });
  let saida = '';
  filho.stdout.on('data', (d) => { saida += d; });
  filho.stderr.on('data', (d) => { saida += d; });
  const checks = [];
  const ok = (nome, cond) => checks.push([nome, !!cond]);

  try {
    for (let i = 0; i < 50; i++) {
      try { await pedir('/api/estado'); break; } catch (e) { await esperar(100); }
    }
    const pagina = await fetch(BASE + '/').then((r) => r.text());
    ok('página da interface é servida', /Selecionar certificado digital/.test(pagina) && /Nome da pasta de resultados/.test(pagina) && /Velocidade do mouse/.test(pagina));
    // fetch ignora um cabeçalho Host próprio; http.request envia o que pedirmos.
    const statusHostFalso = await new Promise((resolve) => {
      const req = require('http').request({ host: '127.0.0.1', port: PORTA, path: '/api/estado', headers: { Host: 'site-malicioso.com' } }, (r) => { r.resume(); resolve(r.statusCode); });
      req.on('error', () => resolve(0));
      req.end();
    });
    ok('Host diferente é recusado (proteção do servidor local)', statusHostFalso === 403);
    ok('site de outra origem não usa a API', (await pedir('/api/parar', {}, { Origin: 'https://site.com' })).status === 403);

    const e0 = (await pedir('/api/estado')).corpo;
    ok('estado inicial: parada, mouse lento', e0.execucao.fase === 'parada' && e0.config.velocidadeMouse === 'lento');

    ok('nome de pasta inválido é apontado', (await pedir('/api/pasta', { nome: 'a/b' })).corpo.ok === false);
    const pv = (await pedir('/api/pasta', { nome: 'CERTIDOES_SEFAZ_PE_NOVEMBRO' })).corpo;
    ok('pré-visualização mostra o caminho completo na Área de Trabalho', pv.ok && pv.caminho === path.join(tmp, 'CERTIDOES_SEFAZ_PE_NOVEMBRO'));

    const semPasta = await pedir('/api/iniciar', { certificadoId: null, pasta: '', velocidadeMouse: 'lento' });
    ok('iniciar sem pasta é recusado com o campo indicado', semPasta.status === 422 && semPasta.corpo.erros && semPasta.corpo.erros.pasta);
    const certFalso = await pedir('/api/iniciar', { certificadoId: 'NAOEXISTE', pasta: 'X', velocidadeMouse: 'lento' });
    ok('certificado inexistente é recusado', certFalso.status === 422 && certFalso.corpo.erros.certificado);

    const ini = await pedir('/api/iniciar', { certificadoId: null, pasta: 'CERTIDOES_SEFAZ_PE_NOVEMBRO', velocidadeMouse: 'normal' });
    ok('iniciar cria a pasta e a subpasta relatorios', ini.corpo.ok && fs.existsSync(path.join(tmp, 'CERTIDOES_SEFAZ_PE_NOVEMBRO', 'relatorios')));
    ok('configuração foi salva para a próxima vez', JSON.parse(fs.readFileSync(path.join(tmp, 'config.json'), 'utf8')).pasta === 'CERTIDOES_SEFAZ_PE_NOVEMBRO');
    ok('segundo iniciar é recusado (uma execução por vez)', (await pedir('/api/iniciar', { pasta: 'OUTRA', velocidadeMouse: 'lento' })).status === 409);

    const s = (await pedir('/sessao', null, { Origin: EXT })).corpo;
    ok('sessão leva a configuração para a extensão', s.ativa && s.origem === 'interface' && s.modo === 'acesso' && s.config.velocidadeMouse === 'normal' && s.config.metodoLogin === 'manual' && s.config.pastaResultados.endsWith('CERTIDOES_SEFAZ_PE_NOVEMBRO'));
    ok('pausar antes de a extensão conectar é recusado', (await pedir('/api/pausar', {})).status === 409);

    ok('extensão reivindica a sessão', (await pedir('/reivindicar', { token: s.token, tabId: 7, versao: '0.3.0' }, { Origin: EXT })).corpo.ok);
    await pedir('/evento', { token: s.token, tipo: 'status', status: 'aguardando_login', mensagem: 'Na janela "Selecionar um certificado" do Chrome, escolha: FULANO.' }, { Origin: EXT });
    const e1 = (await pedir('/api/estado')).corpo.execucao;
    ok('interface mostra "aguardando você" com a instrução', e1.fase === 'aguardando_voce' && e1.aguardandoVoce && /Selecionar um certificado/.test(e1.mensagem));

    ok('pausar pela interface fica pendente', (await pedir('/api/pausar', {})).corpo.ok);
    const c1 = (await pedir(`/comando?token=${s.token}`, null, { Origin: EXT })).corpo;
    const c2 = (await pedir(`/comando?token=${s.token}`, null, { Origin: EXT })).corpo;
    ok('extensão recebe "pausar" uma única vez', c1.comando === 'pausar' && c2.comando === null);
    ok('comando com token errado é recusado', (await pedir('/comando?token=x', null, { Origin: EXT })).status === 403);

    await pedir('/evento', { token: s.token, tipo: 'log', tag: 'SUCESSO', mensagem: 'Autenticação concluída. Aguardando próxima etapa.' }, { Origin: EXT });
    await pedir('/evento', { token: s.token, tipo: 'status', status: 'concluido', mensagem: 'Autenticação concluída. Aguardando próxima etapa.' }, { Origin: EXT });
    const e2 = (await pedir('/api/estado')).corpo;
    ok('conclusão aparece na interface', e2.execucao.fase === 'concluida');
    ok('registros chegam à interface com [SUCESSO]', e2.logs.some((l) => l.tag === 'SUCESSO' && /Autenticação concluída/.test(l.mensagem)));
    const rel = fs.readdirSync(path.join(tmp, 'CERTIDOES_SEFAZ_PE_NOVEMBRO', 'relatorios'));
    const conteudo = rel.length ? fs.readFileSync(path.join(tmp, 'CERTIDOES_SEFAZ_PE_NOVEMBRO', 'relatorios', rel[0]), 'utf8') : '';
    ok('relatório da execução foi gravado na pasta de resultados', rel.length === 1 && /\[SUCESSO\] Autenticação concluída/.test(conteudo));
    ok('terminal também mostra os registros', /\[SUCESSO\] Autenticação concluída/.test(saida));
    ok('nova execução pode começar depois da conclusão', (await pedir('/api/iniciar', { pasta: 'CERTIDOES_SEFAZ_PE_NOVEMBRO', velocidadeMouse: 'lento' })).corpo.ok);
    ok('a pasta reaproveitada mantém o relatório anterior', fs.readdirSync(path.join(tmp, 'CERTIDOES_SEFAZ_PE_NOVEMBRO', 'relatorios')).length === 2);

    // ---- Lista mista e registro para a consulta (0.4.0) ----
    const s2 = (await pedir('/sessao', null, { Origin: EXT })).corpo;
    await pedir('/reivindicar', { token: s2.token, tabId: 8 }, { Origin: EXT });
    await pedir('/evento', { token: s2.token, tipo: 'status', status: 'concluido' }, { Origin: EXT });

    const LISTA = 'CNPJ;11.222.333/0001-81;EMPRESA ALFA\nCPF;529.982.247-25;PESSOA BETA\nIE;0321418-40;EMPRESA GAMA\n52998224725;SEM TIPO\n11222333000181;FORMATO ANTIGO';
    const li = (await pedir('/api/lista', { texto: LISTA })).corpo;
    ok('lista mista: 3 tipos válidos, 11 dígitos sem tipo inválido, formato antigo repetido ignorado',
      li.resumo.validos === 3 && li.resumo.porTipo.IE === 1 && li.registros[3].status === 'invalido' && li.registros[4].status === 'ignorada');

    // 0.6.0: não há mais escolha de UM registro: a lista inteira é processada, em ordem.
    const ini2 = await pedir('/api/iniciar', { pasta: 'CERTIDOES_SEFAZ_PE_NOVEMBRO', velocidadeMouse: 'lento', lista: LISTA, intervaloSegundos: 5 });
    const s3 = (await pedir('/sessao', null, { Origin: EXT })).corpo;
    ok('sem escolher registro: inicia com a lista inteira, a partir do 1º válido (linha 1)', ini2.corpo.ok && s3.modo === 'certidao_negativa'
      && s3.config.registro.tipo === 'CNPJ' && s3.config.registro.linha === 1 && s3.config.lote.total === 3 && s3.config.lote.posicao === 1);
    ok('intervalo de 5 s entre registros vai para a extensão', s3.config.lote.intervaloMs === 5000);
    ok('a lista foi preservada em arquivo para as próximas etapas', fs.readFileSync(path.join(tmp, 'lista_documentos.txt'), 'utf8') === LISTA);
    ok('o intervalo foi salvo na configuração', JSON.parse(fs.readFileSync(path.join(tmp, 'config.json'), 'utf8')).intervaloSegundos === 5);
    const est3 = (await pedir('/api/estado')).corpo.execucao.lote;
    ok('a interface recebe total, pendentes, inválidos e a tabela da execução', est3 && est3.total === 3 && est3.processando === 1 && est3.pendente === 2 && est3.invalido === 1 && est3.itens.length === 4);
    ok('o terminal mostra o total, a linha inválida e o registro 1/3', /Total de registros: 3 válidos/.test(saida) && /Linha 4 inválida \(não será processada\): 11 dígitos sem tipo/.test(saida) && /Registro 1\/3: CNPJ 11\.222\.333\/0001-81 — EMPRESA ALFA/.test(saida));
    const e3 = (await pedir('/api/estado')).corpo;
    ok('a lista salva volta na primeira leitura da interface', e3.listaSalva === LISTA);

    await pedir('/reivindicar', { token: s3.token, tabId: 9 }, { Origin: EXT });
    await pedir('/evento', { token: s3.token, tipo: 'status', status: 'executando', estadoAutomacao: 'PREENCHENDO_IDENTIFICADOR' }, { Origin: EXT });
    ok('a interface mostra o estado da automação', (await pedir('/api/estado')).corpo.execucao.estadoAutomacao === 'PREENCHENDO_IDENTIFICADOR');
    ok('mudança de estado aparece no terminal', /\[ESTADO\] PREENCHENDO_IDENTIFICADOR/.test(saida));
  } finally {
    filho.kill();
  }

  let falhas = 0;
  for (const [nome, passou] of checks) {
    console.log(passou ? 'ok   ' : 'FALHA', nome);
    if (!passou) falhas++;
  }
  if (falhas) console.log('\n--- saída do servidor ---\n' + saida);
  await esperar(200);
  fs.rmSync(tmp, { recursive: true, force: true });
  console.log(`\n${checks.length - falhas}/${checks.length} verificações passaram.`);
  process.exitCode = falhas ? 1 : 0;
})();
