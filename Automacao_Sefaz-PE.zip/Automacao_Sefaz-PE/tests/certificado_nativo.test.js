// Teste do Modo 2 (janela nativa de certificados), SEM mover o mouse:
//   - a correspondência (qual linha é o certificado escolhido) com linhas simuladas;
//   - o script carrega UI Automation e procura a janela (sem janela aberta: "não encontrada").
// Uso: node tests/certificado_nativo.test.js   (Windows)
'use strict';

const N = require('../nucleo/certificado_nativo');

const CERT = { serial: '7783968EB8D0D6F3', titular: 'RENATO FERNANDES VILELA', emissor: 'AC SAFEWEB RFB v5' };
const casos = [
  ['serial na linha certa (2ª posição da lista)', [
    { textos: ['FULANO DE TAL:12345678900', 'AC OUTRA v5', '1111222233334444'] },
    { textos: ['RENATO FERNANDES VILELA:87912345678', 'AC SAFEWEB RFB v5', '7783968EB8D0D6F3'] },
  ], (r) => r.indice === 1 && r.criterio === 'número de série'],
  ['serial com dois-pontos e zeros à esquerda', [
    { textos: ['RENATO FERNANDES VILELA:879', 'AC SAFEWEB RFB v5', '00:77:83:96:8E:B8:D0:D6:F3'] },
  ], (r) => r.indice === 0],
  ['mesmo titular e emissor, mas OUTRO serial: não seleciona', [
    { textos: ['RENATO FERNANDES VILELA:879', 'AC SAFEWEB RFB v5', 'AAAABBBBCCCCDDDD'] },
  ], (r) => r.indice === -1 && /série/.test(r.motivo)],
  ['janela sem serial visível: titular + emissor únicos', [
    { textos: ['RENATO FERNANDES VILELA:879 / AC SAFEWEB RFB v5'] },
    { textos: ['FULANO:111 / AC OUTRA'] },
  ], (r) => r.indice === 0 && /titular \+ emissor/.test(r.criterio)],
  ['sem serial e dois iguais: ambíguo, não seleciona', [
    { textos: ['RENATO FERNANDES VILELA:879', 'AC SAFEWEB RFB v5'] },
    { textos: ['RENATO FERNANDES VILELA:879', 'AC SAFEWEB RFB v5'] },
  ], (r) => r.indice === -1],
  ['só outro certificado: não seleciona', [
    { textos: ['FULANO:111', 'AC OUTRA', '1111222233334444'] },
  ], (r) => r.indice === -1],
  ['acentos e caixa diferentes no titular', [
    { textos: ['Renato Fernandes Vilela:879', 'AC Safeweb RFB V5'] },
  ], (r) => r.indice === 0],
];

(async () => {
  let falhas = 0;
  const ok = (nome, passou, extra = '') => { console.log(passou ? 'ok   ' : 'FALHA', nome, passou ? '' : extra); if (!passou) falhas++; };
  if (process.platform !== 'win32') { console.log('Teste só no Windows.'); return; }

  for (const [nome, linhas, confere] of casos) {
    const r = await N.testarCorrespondencia(linhas, CERT);
    ok(nome, r && confere(r), JSON.stringify(r));
  }

  // ---- Busca com rolagem (0.6.2): lista simulada com 10 certificados, 3 visíveis por vez ----
  const outro = (i) => ({ textos: [`PESSOA ${i}:${String(10000000000 + i)}`, i % 2 ? 'AC SOLUTI v5' : 'AC SERASA RFB v5', `${String(1000 + i)}AABBCCDD0000`] });
  const meu = { textos: ['RENATO FERNANDES VILELA:87927080482', 'AC SAFEWEB RFB v5', '7783968EB8D0D6F3'] };
  const lista = (pos) => { const l = Array.from({ length: 10 }, (_, i) => outro(i)); l[pos] = meu; return l; };
  const CERT2 = { ...CERT, documento: '87927080482' };
  let extra = 0;
  const b = async (nome, sim, confere) => { extra++; const r = await N.testarBusca(sim, CERT2); ok(nome, r && confere(r), JSON.stringify(r)); };
  await b('certificado mais ABAIXO (8º de 10, 3 visíveis): rola para baixo até achar e seleciona a linha exata',
    { linhas: lista(7), visiveis: 3, inicio: 0, passo: 2 }, (r) => r.encontrado && r.indice === 7 && /^1(,1)+$/.test(r.rolagens) && r.criterio === 'número de série');
  await b('certificado mais ACIMA (2º, lista começando no meio): desce até o fim, depois sobe e acha',
    { linhas: lista(1), visiveis: 3, inicio: 5, passo: 2 }, (r) => r.encontrado && r.indice === 1 && r.rolagens.includes('-1') && r.rolagens.startsWith('1'));
  await b('certificado visível logo de início: nenhuma rolagem',
    { linhas: lista(0), visiveis: 3, inicio: 0, passo: 2 }, (r) => r.encontrado && r.indice === 0 && r.rolagens === '');
  await b('certificado AUSENTE: percorre a lista inteira (10 analisados, sem repetir), para no início/fim e pede seleção manual',
    { linhas: Array.from({ length: 10 }, (_, i) => outro(i)), visiveis: 3, inicio: 4, passo: 2 }, (r) => !r.encontrado && r.analisados === 10 && r.rolagens.split(',').length < 14 && /lista inteira percorrida/.test(r.motivo));
  await b('mesma série com OUTRO CPF no titular: recusado (não seleciona por aproximação) e para na hora',
    { linhas: [outro(0), { textos: ['RENATO FERNANDES VILELA:11111111111', 'AC SAFEWEB RFB v5', '7783968EB8D0D6F3'] }, outro(2)], visiveis: 3, inicio: 0, passo: 2 }, (r) => !r.encontrado && /CPF\/CNPJ/.test(r.motivo) && r.rolagens === '');
  await b('mesma série com OUTRO emissor: recusado',
    { linhas: [{ textos: ['RENATO FERNANDES VILELA:87927080482', 'AC OUTRA AUTORIDADE', '7783968EB8D0D6F3'] }], visiveis: 3, inicio: 0, passo: 2 }, (r) => !r.encontrado && /emissor/.test(r.motivo));
  await b('lista de 1 certificado (caso real do seu computador): acha sem rolar',
    { linhas: [meu], visiveis: 3, inicio: 0, passo: 2 }, (r) => r.encontrado && r.indice === 0 && r.rolagens === '');

  // Script completo (UI Automation + DPI + mouse compilados), sem janela aberta: não clica.
  const eventos = [];
  const t0 = Date.now();
  const r = await N.verificarJanela({ esperaJanela: 2, aoEvento: (e) => eventos.push(e) });
  ok('script carrega UI Automation e procura a janela (sem janela: "não encontrada", nada clicado)', r.resultado === 'nao_encontrada' && eventos[0] && /Aguardando a janela/.test(eventos[0].mensagem), JSON.stringify(r));
  ok('a espera respeita o limite pedido', Date.now() - t0 < 15000);

  console.log(`\n${casos.length + 2 + extra - falhas}/${casos.length + 2 + extra} verificações passaram.`);
  process.exitCode = falhas ? 1 : 0;
})();
