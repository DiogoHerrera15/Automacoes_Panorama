// Escada de recuperação de um registro (Retirar_Certidao_SEFAZ-PE/modules/recuperacao.js).
// Uso: node tests/recuperacao.test.js
'use strict';

const fs = require('fs');
const path = require('path');
const vm = require('vm');

const ctx = { console };
ctx.globalThis = ctx;
vm.createContext(ctx);
vm.runInContext(fs.readFileSync(path.join(__dirname, '..', 'Retirar_Certidao_SEFAZ-PE', 'modules', 'recuperacao.js'), 'utf8'), ctx);
const R = ctx.SEFAZPE.Recuperacao;

const checks = [];
const ok = (nome, cond, extra) => checks.push([nome, !!cond, extra]);
const erro = (codigo) => ({ codigo, message: codigo });
const d = (est, codigo, tela, max = 3) => R.decidir(est, erro(codigo), tela || {}, { maxTentativas: max });

// Antes da emissão: 1ª sem recarga, 2ª e 3ª com recarga (refaz a pesquisa), depois próximo.
let r = d({ tentativaRegistro: 1, pesquisaEnviada: true }, 'ETAPA_DEMORADA');
ok('1ª falha: confere e repete SEM recarregar', r.acao === 'repetir' && !r.recarregar && r.parcial.tentativaRegistro === 2 && r.parcial.pesquisaEnviada === undefined);
r = d({ tentativaRegistro: 2, pesquisaEnviada: true }, 'ELEMENTO_NAO_ENCONTRADO');
ok('2ª falha: recarrega e refaz o MESMO registro (pesquisa refeita, pois a resposta some com a página)', r.acao === 'repetir' && r.recarregar && r.parcial.tentativaRegistro === 3 && r.parcial.pesquisaEnviada === false);
r = d({ tentativaRegistro: 3 }, 'ELEMENTO_NAO_ENCONTRADO');
ok('3ª falha (máximo 3): registra o erro e segue para o próximo', r.acao === 'proximo');
r = d({ tentativaRegistro: 3 }, 'ELEMENTO_NAO_ENCONTRADO', {}, 5);
ok('máximo configurável (5): na 3ª ainda tenta de novo, com recarga', r.acao === 'repetir' && r.recarregar);
r = d({ tentativaRegistro: 1 }, 'ELEMENTO_NAO_ENCONTRADO', {}, 1);
ok('máximo 1: a primeira falha já segue para o próximo', r.acao === 'proximo');

// Nada é repetido se o PDF já está salvo.
r = d({ tentativaRegistro: 2, emissaoConfirmada: true, arquivo: { caminho: 'C:\\x.pdf' } }, 'ETAPA_DEMORADA');
ok('PDF deste registro já salvo: conclui como sucesso, sem repetir nada', r.acao === 'sucesso');

// Emissão pedida sem confirmação: nunca pede outra.
r = d({ tentativaRegistro: 1, emissaoSolicitada: true }, 'EMISSAO_SEM_CONFIRMACAO');
ok('emissão sem confirmação, 1ª falha: só confere de novo (sem nova emissão, sem recarga)', r.acao === 'repetir' && !r.recarregar && r.parcial.emissaoSolicitada === undefined);
r = d({ tentativaRegistro: 2, emissaoSolicitada: true }, 'EMISSAO_SEM_CONFIRMACAO');
ok('emissão sem confirmação, 2ª falha: NÃO emite de novo; erro "confira no portal" e próximo', r.acao === 'proximo' && /não é seguro/.test(r.descricao));

// Emissão confirmada, PDF não salvo: recupera o documento antes de emitir de novo.
r = d({ tentativaRegistro: 1, emissaoSolicitada: true, emissaoConfirmada: true, visualizarClicado: true, visualizarCliques: 1 }, 'ARQUIVO_NAO_RECEBIDO', { confirmacaoVisivel: true });
ok('emitida e sem PDF, confirmação na tela: abre o documento de novo (Visualizar), sem emitir', r.acao === 'repetir' && !r.recarregar && r.parcial.visualizarClicado === false && r.parcial.emissaoSolicitada === undefined);
r = d({ tentativaRegistro: 2, emissaoSolicitada: true, emissaoConfirmada: true, visualizarCliques: 2 }, 'ARQUIVO_NAO_RECEBIDO', { confirmacaoVisivel: true });
ok('documento não recuperado: UMA nova emissão, com recarga (a anterior comprovadamente terminou)', r.acao === 'repetir' && r.recarregar && r.parcial.emissaoSolicitada === false && r.parcial.reemissoes === 1);
r = d({ tentativaRegistro: 2, emissaoSolicitada: true, emissaoConfirmada: true, visualizarCliques: 2, reemissoes: 1 }, 'ARQUIVO_NAO_RECEBIDO', { confirmacaoVisivel: false });
ok('já houve uma nova emissão: não emite uma terceira vez; erro e próximo', r.acao === 'proximo');

// Erros gerais e sessão.
ok('erro geral (comunicação/login): pausa a lista, não marca o registro', d({ tentativaRegistro: 1 }, 'ERRO_COMUNICACAO').acao === 'pausar' && d({ tentativaRegistro: 1 }, 'LOGIN_NAO_CONCLUIDO').acao === 'pausar');
r = d({ tentativaRegistro: 1, pesquisaEnviada: true }, 'SESSAO_EXPIRADA');
ok('sessão expirada antes da emissão: novo login e o MESMO registro', r.acao === 'relogar' && r.parcial.retomarEm === 'verificar_login' && r.parcial.pesquisaEnviada === false);
ok('sessão expirada depois de pedir a emissão: não refaz a emissão (segue a regra da emissão)', d({ tentativaRegistro: 2, emissaoSolicitada: true }, 'SESSAO_EXPIRADA').acao === 'proximo');
ok('resultado de outro documento: não adianta repetir; próximo', d({ tentativaRegistro: 1 }, 'RESULTADO_DIVERGENTE').acao === 'proximo');

// Limite por etapa.
ok('limite por etapa: login, certificado, emissão e documento não têm limite aqui', ['autenticacao_govbr', 'acionar_login_govbr', 'aguardar_emissao', 'aguardar_arquivo'].every((e) => R.limiteDaEtapa(e, 120000) === null));
ok('limite por etapa: as demais usam o configurado (mínimo 30 s)', R.limiteDaEtapa('clicar_pesquisar', 120000) === 120000 && R.limiteDaEtapa('selecionar_tipo_documento', 5000) === 30000);

let falhas = 0;
for (const [nome, passou, extra] of checks) { console.log(passou ? 'ok   ' : 'FALHA', nome, passou || !extra ? '' : `→ ${extra}`); if (!passou) falhas++; }
console.log(`\n${checks.length - falhas}/${checks.length} verificações passaram.`);
process.exit(falhas ? 1 : 0);
