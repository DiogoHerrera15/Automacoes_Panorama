// Teste do iniciador pelo terminal (ponte local), sem abrir o Chrome.
// Uso: node tests/iniciar.test.js   (a partir da pasta Automacao_Sefaz-PE)
'use strict';

const path = require('path');
const assert = require('assert');
const { spawn } = require('child_process');

const PORTA = 47999; // diferente da porta real, para não conflitar com uma execução aberta
const BASE = `http://127.0.0.1:${PORTA}`;
const ORIGEM_EXT = 'chrome-extension://abcdefghijklmnop';

const pedir = (caminho, corpo, origem = ORIGEM_EXT) => fetch(BASE + caminho, {
  method: corpo ? 'POST' : 'GET',
  headers: { ...(corpo ? { 'Content-Type': 'application/json' } : {}), ...(origem ? { Origin: origem } : {}) },
  body: corpo ? JSON.stringify(corpo) : undefined,
}).then(async (r) => ({ status: r.status, corpo: await r.json() }));

async function esperarPorta() {
  for (let i = 0; i < 50; i++) {
    try { await pedir('/sessao'); return; } catch (e) { await new Promise((r) => setTimeout(r, 100)); }
  }
  throw new Error('a ponte não abriu');
}

(async () => {
  const filho = spawn(process.execPath, [path.join(__dirname, '..', 'iniciar.js'), '--sem-chrome', '--porta', String(PORTA), '--espera-extensao', '30', '--modo', 'acesso'], {
    env: { ...process.env, NO_COLOR: '1' },
  });
  let saida = '';
  filho.stdout.on('data', (d) => { saida += d; });
  const fim = new Promise((r) => filho.on('exit', (codigo) => r(codigo)));
  const checks = [];
  const ok = (nome, cond) => { checks.push([nome, !!cond]); };
  const { lerArgumentos } = require('../iniciar');
  ok('sem --modo, INICIAR.cmd faz o fluxo completo (certidao_negativa), como a interface', lerArgumentos([]).modo === 'certidao_negativa' && lerArgumentos(['--modo', 'acesso']).modo === 'acesso');

  try {
    await esperarPorta();
    const s = await pedir('/sessao');
    ok('sessão pendente com token', s.corpo.ativa === true && typeof s.corpo.token === 'string' && s.corpo.modo === 'acesso');
    const token = s.corpo.token;

    ok('página web (outra origem) é recusada', (await pedir('/sessao', null, 'https://site-qualquer.com')).status === 403);
    ok('reivindicar com token errado é recusado', (await pedir('/reivindicar', { token: 'errado', tabId: 1 })).status === 403);
    ok('reivindicar com token certo funciona', (await pedir('/reivindicar', { token, tabId: 42, versao: '0.2.0', incognitoPermitido: true })).corpo.ok === true);
    ok('sessão não fica mais disponível', (await pedir('/sessao')).corpo.ativa === false);
    ok('segunda reivindicação é recusada', (await pedir('/reivindicar', { token, tabId: 43 })).status === 409);
    ok('evento com token errado é recusado', (await pedir('/evento', { token: 'x', tipo: 'log', mensagem: 'falso' })).status === 403);

    await pedir('/evento', { token, tipo: 'log', tag: 'LOGIN', mensagem: 'Procurando botão Login com gov.br...' });
    await pedir('/evento', { token, tipo: 'log', tag: 'GOV.BR', mensagem: 'Página de autorização identificada.' });
    await pedir('/evento', { token, tipo: 'status', status: 'erro', mensagem: 'Botão não encontrado.' });
    await pedir('/evento', { token, tipo: 'status', status: 'concluido' });
    const codigo = await Promise.race([fim, new Promise((r) => setTimeout(() => r('timeout'), 5000))]);

    ok('terminal mostra [INICIANDO]', /\[INICIANDO\] Automacao_Sefaz-PE/.test(saida));
    ok('terminal mostra a conexão da extensão', /\[EXTENSÃO\] Extensão conectada na janela anônima \(versão 0\.2\.0; aba 42\)/.test(saida));
    ok('terminal mostra [LOGIN] com a mensagem', /\[LOGIN\] Procurando botão Login com gov\.br\.\.\./.test(saida));
    ok('terminal mostra [GOV.BR]', /\[GOV\.BR\] Página de autorização identificada\./.test(saida));
    ok('erro aparece como [ERRO] e o terminal continua', /\[ERRO\] Botão não encontrado\./.test(saida));
    ok('evento falso não apareceu', !/falso/.test(saida));
    ok('conclusão encerra o terminal com código 0', codigo === 0);
  } finally {
    if (filho.exitCode === null) filho.kill();
  }

  let falhas = 0;
  for (const [nome, passou] of checks) {
    console.log(passou ? 'ok   ' : 'FALHA', nome);
    if (!passou) falhas++;
  }
  if (falhas) console.log('\n--- saída do iniciador ---\n' + saida);
  console.log(`\n${checks.length - falhas}/${checks.length} verificações passaram.`);
  process.exitCode = falhas ? 1 : 0;
})();
