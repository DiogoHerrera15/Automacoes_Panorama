// Integração Modo 1 (extensão) ↔ Modo 2 (janela nativa) no nucleo/controle.js, com um
// seletor nativo SIMULADO (nenhum mouse é movido). Uso: node tests/controle.test.js
'use strict';

const http = require('http');
const { criarControle } = require('../nucleo/controle');

const EXT = 'chrome-extension://abcdefghijklmnop';

function registroFalso() {
  const linhas = [];
  return { linhas, escrever: (tag, mensagem, nivel = 'info') => linhas.push({ tag, mensagem, nivel }), adicionarArquivo() {}, removerArquivo() {} };
}

(async () => {
  const checks = [];
  const ok = (nome, cond) => checks.push([nome, !!cond]);
  const chamadas = [];
  let resolver;
  let parados = 0;
  const seletorFalso = ({ cert, velocidade, aoEvento }) => {
    chamadas.push({ cert, velocidade });
    aoEvento({ tipo: 'progresso', mensagem: 'Janela de certificados identificada: 1 certificado(s) listado(s).' });
    return { fim: new Promise((r) => { resolver = r; }), parar() { parados++; resolver({ resultado: 'interrompido', mensagem: 'parado' }); } };
  };
  const reg = registroFalso();
  const controle = criarControle({ registro: reg, abrirNavegador: false, selecionarCertificado: seletorFalso });
  const srv = http.createServer((req, res) => { if (!controle.tratarPonte(req, res)) { res.writeHead(404); res.end(); } });
  await new Promise((r) => srv.listen(47996, '127.0.0.1', r));
  const pedir = (caminho, corpo) => fetch('http://127.0.0.1:47996' + caminho, { method: corpo ? 'POST' : 'GET', headers: { 'Content-Type': 'application/json', Origin: EXT }, body: corpo ? JSON.stringify(corpo) : undefined }).then((r) => r.json());

  try {
    controle.iniciar({
      modo: 'certidao_negativa', origem: 'interface',
      config: { velocidadeMouse: 'normal', metodoLogin: 'certificado', selecaoNativa: true, certificado: { titular: 'RENATO FERNANDES VILELA' } },
      nativo: { serial: '7783968EB8D0D6F3', titular: 'RENATO FERNANDES VILELA', emissor: 'AC SAFEWEB RFB v5' },
    });
    const s = await pedir('/sessao');
    ok('a sessão enviada à extensão NÃO contém o número de série', !JSON.stringify(s).includes('7783968EB8D0D6F3') && s.config.selecaoNativa === true);
    await pedir('/reivindicar', { token: s.token, tabId: 1 });

    await pedir('/evento', { token: s.token, tipo: 'log', tag: 'CERTIFICADO', mensagem: 'Opção localizada. Realizando clique...' });
    ok('Modo 2 não começa antes do sinal da extensão', chamadas.length === 0);

    await pedir('/evento', { token: s.token, tipo: 'log', tag: 'CERTIFICADO', mensagem: 'Janela de certificados: seleção nativa pelo Windows.', acaoNativa: 'selecionar_certificado' });
    ok('Modo 2 começa quando a extensão clica em "Seu certificado digital"', chamadas.length === 1 && chamadas[0].cert.serial === '7783968EB8D0D6F3' && chamadas[0].velocidade === 'normal');
    ok('os passos do Modo 2 aparecem nos registros como [CERTIFICADO]', reg.linhas.some((l) => l.tag === 'CERTIFICADO' && /identificada/.test(l.mensagem)) && reg.linhas.some((l) => l.tag === 'CERTIFICADO' && /Detectando janela de certificados/.test(l.mensagem)));

    await pedir('/evento', { token: s.token, tipo: 'log', mensagem: 'de novo', acaoNativa: 'selecionar_certificado' });
    ok('não abre um segundo controle do mouse enquanto o primeiro está ativo', chamadas.length === 1);

    controle.comando('parar');
    await new Promise((r) => setTimeout(r, 30));
    ok('Parar encerra o controle do mouse do Windows na hora', parados === 1 && reg.linhas.some((l) => /Controle do mouse do Windows encerrado/.test(l.mensagem)));

    // Nova execução: resultado "ok" e resultado "manual".
    await pedir('/evento', { token: s.token, tipo: 'status', status: 'parado' });
    controle.iniciar({ modo: 'acesso', config: { selecaoNativa: true }, nativo: { serial: 'AB', titular: 'X', emissor: 'Y' } });
    const s2 = await pedir('/sessao');
    await pedir('/reivindicar', { token: s2.token, tabId: 2 });
    await pedir('/evento', { token: s2.token, tipo: 'log', mensagem: 'x', acaoNativa: 'selecionar_certificado' });
    resolver({ resultado: 'manual', mensagem: 'Identificação não segura (nenhuma linha com o número de série). Selecione manualmente.', diagnostico: 'DataItem:"..."' });
    await new Promise((r) => setTimeout(r, 30));
    ok('identificação não segura vira "aguardando você" com diagnóstico, sem clicar', reg.linhas.some((l) => l.tag === 'AGUARDANDO' && /não segura/.test(l.mensagem)) && reg.linhas.some((l) => /Diagnóstico da janela/.test(l.mensagem)));

    await pedir('/evento', { token: s2.token, tipo: 'log', mensagem: 'x', acaoNativa: 'selecionar_certificado' });
    resolver({ resultado: 'ok', mensagem: 'Certificado confirmado na janela do Chrome (número de série).' });
    await new Promise((r) => setTimeout(r, 30));
    ok('depois de terminar, um novo sinal (página recarregada) pode iniciar outra seleção', chamadas.length === 3);
    ok('sucesso aparece como [CERTIFICADO]', reg.linhas.some((l) => l.tag === 'CERTIFICADO' && /confirmado/.test(l.mensagem)));

    // Sem certificado/nativo: o sinal é ignorado.
    await pedir('/evento', { token: s2.token, tipo: 'status', status: 'parado' });
    controle.iniciar({ modo: 'acesso', config: {} });
    const s3 = await pedir('/sessao');
    await pedir('/reivindicar', { token: s3.token, tabId: 3 });
    await pedir('/evento', { token: s3.token, tipo: 'log', mensagem: 'x', acaoNativa: 'selecionar_certificado' });
    ok('sem seleção nativa configurada, nada acontece', chamadas.length === 3);
    await pedir('/evento', { token: s3.token, tipo: 'status', status: 'parado' }); // encerra os temporizadores
  } finally {
    srv.close();
  }

  let falhas = 0;
  for (const [nome, passou] of checks) { console.log(passou ? 'ok   ' : 'FALHA', nome); if (!passou) falhas++; }
  console.log(`\n${checks.length - falhas}/${checks.length} verificações passaram.`);
  process.exit(falhas ? 1 : 0);
})();
