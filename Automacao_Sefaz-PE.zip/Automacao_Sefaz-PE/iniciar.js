#!/usr/bin/env node
// Automacao_Sefaz-PE — iniciador pela LINHA DE COMANDO (sem janela).
//
// Faz o mesmo que o botão INICIAR AUTOMAÇÃO da interface (INTERFACE.cmd), usando a
// configuração salva por ela em dados\config.json (certificado, pasta de resultados,
// velocidade do mouse). Sem configuração salva: login manual, mouse lento, sem pasta.
//
// Uso:  node iniciar.js [--perfil "Default"] [--velocidade lento|normal|rapido]
//                       [--sem-certificado] [--modo certidao_negativa|acesso|certidoes] [--chrome "caminho"]
//        padrão: certidao_negativa (fluxo completo com o registro escolhido na interface)
//
// A extensão faz o trabalho na página; este script não controla o navegador, não lê páginas,
// não digita nada e não toca em CAPTCHA, senha, PIN ou certificado.

'use strict';

const http = require('http');
const path = require('path');
const C = require('./nucleo/comum');
const { criarControle } = require('./nucleo/controle');
const Cert = require('./nucleo/certificados');
const Pasta = require('./nucleo/pasta');
const Lista = require('./nucleo/lista');
const Lote = require('./nucleo/lote');

const { K } = C;

function lerArgumentos(argv) {
  const cfg = C.lerConfig();
  // Sem --modo: o fluxo completo (pesquisa, emissão e PDF) com o registro escolhido na
  // interface, como o botão INICIAR da interface. Sem registro escolhido, volta para "acesso".
  const a = { modo: 'certidao_negativa', perfil: process.env.CHROME_PERFIL || cfg.perfil, chrome: null, semChrome: false, porta: K.TERMINAL.porta, esperaExtensao: 300, velocidade: cfg.velocidadeMouse, semCertificado: false };
  for (let i = 0; i < argv.length; i++) {
    const v = argv[i];
    if (v === '--modo') a.modo = argv[++i];
    else if (v === '--perfil') a.perfil = argv[++i];
    else if (v === '--chrome') a.chrome = argv[++i];
    else if (v === '--velocidade') a.velocidade = argv[++i];
    else if (v === '--sem-certificado') a.semCertificado = true;
    else if (v === '--porta') a.porta = Number(argv[++i]); // só para testes: a extensão usa a porta fixa
    else if (v === '--espera-extensao') a.esperaExtensao = Number(argv[++i]);
    else if (v === '--sem-chrome') a.semChrome = true; // testes: não abre o navegador
    else if (v === '--ajuda' || v === '-h') a.ajuda = true;
  }
  if (!K.MODOS[a.modo]) a.modo = 'acesso';
  if (!K.VELOCIDADES[a.velocidade]) a.velocidade = 'lento';
  return a;
}

// Monta a configuração da execução a partir de dados\config.json.
async function montarConfig(args, registro) {
  const salvo = C.lerConfig();
  const config = { velocidadeMouse: args.velocidade, metodoLogin: 'manual', certificado: null, pastaResultados: null };

  if (!args.semCertificado && salvo.certificadoId && !args.semChrome) {
    const r = await Cert.listarCertificados();
    const cert = r.ok && r.certificados.find((c) => c.id === salvo.certificadoId);
    if (cert && cert.utilizavel) {
      config.metodoLogin = 'certificado';
      config.certificado = Cert.resumoParaExtensao(cert);
      if (salvo.selecaoNativa !== false && process.platform === 'win32') {
        config.selecaoNativa = true;
        config.__nativo = { serial: cert.serial, titular: cert.titular, emissor: cert.emissor, documento: cert.documento };
      }
      registro.escrever('CERTIFICADO', `Certificado escolhido: ${cert.titular} (${cert.tipo} ${cert.documentoMascarado}, válido até ${cert.validoAte}).`);
    } else {
      registro.escrever('AVISO', 'O certificado salvo na interface não está disponível ou não pode ser usado; o login será manual.', 'aviso');
    }
  } else {
    registro.escrever('CERTIFICADO', 'Sem certificado escolhido: o login no gov.br será manual.');
  }

  if (salvo.pasta && !args.semChrome) {
    const p = Pasta.prepararPasta(salvo.pasta);
    if (p.ok) {
      config.pastaResultados = p.caminho;
      registro.adicionarArquivo(Pasta.caminhoSemSobrescrever(p.relatorios, `execucao_${Pasta.carimbo()}.txt`));
      registro.escrever('PASTA', `${p.existia ? 'Usando' : 'Criada'} a pasta de resultados: ${p.caminho}`);
    } else {
      registro.escrever('AVISO', `Pasta de resultados não preparada: ${p.erro}`, 'aviso');
    }
  }

  // Lista inteira salva pela interface (dados\lista_documentos.txt), um registro por vez.
  if (args.modo === 'certidao_negativa') {
    const lista = Lista.interpretarLista(C.lerLista());
    if (lista.resumo.validos && config.pastaResultados) {
      config.__lote = Lote.criarLote({ pasta: config.pastaResultados, registros: lista.registros });
      config.__intervalo = salvo.intervaloSegundos;
      config.__tentativas = salvo.maxTentativas;
      config.__limite = salvo.limiteEtapaSegundos;
      registro.escrever('LISTA', `Total de registros: ${lista.resumo.validos} válidos, ${lista.resumo.invalidos} com problema de preenchimento.`);
    } else {
      registro.escrever('AVISO', lista.resumo.validos ? 'Sem pasta de resultados configurada na interface; a execução vai só até a autenticação.' : 'A lista da interface está vazia; a execução vai só até a autenticação.', 'aviso');
      args.modo = 'acesso';
    }
  }
  return config;
}

async function main() {
  const args = lerArgumentos(process.argv.slice(2));
  if (args.ajuda) {
    console.log('Uso: node iniciar.js [--perfil "Default"] [--velocidade lento|normal|rapido] [--sem-certificado] [--modo acesso|certidoes|certidao_negativa] [--chrome "caminho\\chrome.exe"]');
    return;
  }
  const registro = new C.Registro();
  const arquivo = registro.adicionarArquivo(C.arquivoLogTerminal('terminal'));
  registro.escrever('INICIANDO', `Automacao_Sefaz-PE (extensão ${C.VERSAO_EXTENSAO}, modo: ${K.MODOS[args.modo]}, mouse: ${K.VELOCIDADES[args.velocidade]})`);

  let servidor = null;
  const encerrar = (codigo) => {
    if (arquivo) registro.escrever('FIM', `Registro salvo em ${arquivo}`);
    if (servidor) servidor.close();
    setTimeout(() => process.exit(codigo), 200);
  };

  const controle = criarControle({
    registro,
    abrirNavegador: !args.semChrome,
    perfil: args.perfil,
    chrome: args.chrome,
    esperaExtensao: args.esperaExtensao,
    aoTerminar: (fase) => {
      if (fase === 'concluida') registro.escrever('FIM', 'Pode fechar este terminal.');
      encerrar(fase === 'concluida' ? 0 : fase === 'interrompida' ? 1 : 2);
    },
  });

  servidor = http.createServer((req, res) => {
    if (controle.tratarPonte(req, res)) return;
    res.writeHead(404);
    res.end();
  });
  servidor.on('error', (e) => {
    registro.escrever('ERRO', e.code === 'EADDRINUSE'
      ? `A porta ${args.porta} já está em uso: a interface ou outra Automacao_Sefaz-PE já está aberta. Feche-a e tente de novo.`
      : `Não foi possível abrir a ponte local: ${e.message}`, 'erro');
    process.exit(1);
  });
  servidor.listen(args.porta, '127.0.0.1', async () => {
    const config = await montarConfig(args, registro);
    const nativo = config.__nativo || null; // dados do Modo 2: ficam no computador
    const lote = config.__lote || null;
    const intervaloSegundos = config.__intervalo;
    const maxTentativas = config.__tentativas;
    const limiteEtapaSegundos = config.__limite;
    delete config.__nativo; delete config.__lote; delete config.__intervalo; delete config.__tentativas; delete config.__limite;
    const r = controle.iniciar({ modo: args.modo, origem: 'terminal', config, nativo, lote, intervaloSegundos, maxTentativas, limiteEtapaSegundos });
    if (!r.ok) registro.escrever('AVISO', r.erro, 'aviso');
    if (!r.ok) encerrar(1);
  });
  process.on('SIGINT', () => {
    registro.escrever('FIM', 'Encerrado pelo usuário (Ctrl+C). O navegador continua aberto.', 'aviso');
    encerrar(130);
  });
}

if (require.main === module) main();
module.exports = { lerArgumentos, PASTA_EXTENSAO: C.PASTA_EXTENSAO, verificarInstalacao: C.verificarInstalacao, caminhoChrome: C.caminhoChrome };
