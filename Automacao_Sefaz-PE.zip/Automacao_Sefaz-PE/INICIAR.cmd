@echo off
rem Automacao_Sefaz-PE: abre o Chrome em janela anonima no portal SEFAZ-PE e acompanha
rem a extensao Retirar_Certidao_SEFAZ-PE: login, Certidao Negativa, emissao e PDF do registro
rem escolhido na interface (sem registro escolhido: so ate o login).
rem Opcoes: --perfil "Profile 1"   --modo acesso   --chrome "C:\caminho\chrome.exe"
chcp 65001 >nul
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo O Node.js nao esta instalado. Instale a versao LTS com:  winget install OpenJS.NodeJS.LTS
  echo ou em https://nodejs.org , feche e abra esta janela de novo.
  pause
  exit /b 1
)
node iniciar.js %*
set CODIGO=%ERRORLEVEL%
echo.
pause
exit /b %CODIGO%
