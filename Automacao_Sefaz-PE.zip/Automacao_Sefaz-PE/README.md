# Automacao_Sefaz-PE — extensão `Retirar_Certidao_SEFAZ-PE`

Automação do **Portal de Atendimento da SEFAZ-PE** (<https://atendimento.sefaz.pe.gov.br/>), em três partes:

- uma **interface** para configurar e controlar a execução;
- uma **extensão do Google Chrome** (Manifest V3), que trabalha nas páginas;
- uma **linha de comando**, opcional.

Versão **0.6.1** (18/11/2026). Você cola a lista, escolhe o certificado e a pasta e clica **uma vez** em INICIAR. A
automação processa **todos** os registros válidos, na ordem:

1. Abre o Chrome anônimo e faz o login no gov.br uma vez (o certificado é selecionado na janela do Chrome com o mouse
   do Windows).
2. Para cada registro: Certidão Negativa → tipo (CNPJ, CPF ou IE) → apaga o identificador anterior e confere o campo
   vazio → digita o novo → **Pesquisar** → confere o resultado → **Emitir Certidão** (um clique) → **Visualizar
   Certidão** → salva e confere o PDF na pasta.
3. Fecha só a aba do PDF, espera o intervalo (padrão 5 s) e recarrega só o formulário da consulta (a sessão continua).
   Depois segue para o próximo registro.
4. No fim: resumo na interface e planilha `resultado_certidoes_<data-hora>.xlsx` na pasta.

> **0.6.1 (correção da pausa de 15:54:59 e recuperação por registro):**
> - **Causa comprovada:** não foi o site nem o clique. A varredura do PDF, no background da extensão, conferia a cada 3 s
>   "etapa aguardando o PDF, sem PDF, captura encerrada". Ao passar para o 2º registro, a automação zera exatamente
>   esses campos antes de a etapa mudar, durante o intervalo de 5 s. A varredura achou que o PDF do 1º não tinha
>   chegado e pausou. Provas no registro: a mensagem é a do background, a "reação: nenhuma" vem da lista recém-zerada,
>   e o erro saiu 2 s após a troca. O teste de regressão reproduz o erro com a regra antiga e passa com a nova.
>   Correção: a varredura pertence a uma única captura e nunca declara erro; quem decide é a etapa da página.
> - **Limite por etapa** (padrão 120 s, configurável): passou do limite e a página não está carregando nem esperando
>   você, a etapa é encerrada no próximo ponto seguro (nunca no meio de um clique). Login, certificado, PIN, CAPTCHA,
>   emissão e documento não entram nesse limite.
> - **Tentativas por registro** (padrão 3, configurável): 1ª falha, confere e repete sem recarregar; 2ª e 3ª, recarrega
>   a página e refaz o mesmo registro. Esgotou: registra o erro (com captura da página em
>   `relatorios\falhas`) e segue para o próximo.
> - **Sem duplicidade:** com o PDF já salvo, conclui sem repetir nada. Emissão pedida sem confirmação nunca é pedida de
>   novo. Emissão confirmada sem PDF: primeiro abre o documento de novo; só se não der, faz uma única nova emissão.
> - **Histórico** de cada recuperação (horário, etapa, problema, ação, tentativa, tempo) na interface, no
>   `controle_execucao.json` e na planilha.
> **0.6.0 (lista inteira):**
> - **Sem escolher registro:** a interface mostra "Total de registros", válidos e com problema. As linhas inválidas
>   vão para o relatório e não são processadas.
> - **Painel "Processamento de certidões":** total, sucesso, erros, não encontrados, pendentes e processando; barra de
>   progresso; registro atual (posição, identificador, nome, etapa); tabela da execução com o detalhe de cada erro.
> - **Sucesso só com o PDF:** o computador marca sucesso apenas quando ele mesmo salvou e conferiu o PDF **daquele**
>   registro. Se a página disser "sucesso" sem PDF, o registro fica como erro.
> - **Erro de um registro não para a lista:** ele é anotado (código, etapa, mensagem) e a lista segue. A emissão nunca
>   é repetida. Se o documento não abrir, "Visualizar Certidão" é tentado mais uma vez.
> - **Pausa:** a lista inteira pausa em erros gerais (login, autorização, comunicação, portal) e depois de 3 registros
>   seguidos com erro.
> - **Sessão expirada antes da emissão:** a automação faz o login de novo e continua no mesmo registro.
> - **Retomada:** `controle_execucao.json` na pasta guarda tipo, identificador, nome, status, tentativas, mensagem,
>   etapa, caminho do PDF e data de cada registro. No próximo INICIAR, os concluídos são pulados **só se o PDF
>   existir e for válido**. Os não encontrados também são pulados; os com erro e o interrompido são refeitos.
> - **Intervalo** configurável no bloco 4 (0 a 120 s; padrão 5 s), contado depois que o PDF anterior está salvo.
> - Os nomes dos PDFs continuam no formato validado: `36.690.216_0001-73_NOME.pdf`, `CPF_..._NOME.pdf`,
>   `IE_..._NOME.pdf`.
> **0.5.0:**
> 1. **Certificado: causa do travamento encontrada e corrigida.** O registro de 14:25 mostrou o processo do Windows
>    iniciando e "achando" uma janela com 104 itens: era a **página da própria interface**, que tem o texto
>    "Selecione um certificado". Na janela real do Chrome (lida no seu computador), o diálogo fica **dentro** da janela
>    do Chrome, as linhas são tabelas com células, e a consulta "o que está sob o cursor" do Windows devolve a página
>    que fica embaixo do diálogo. Também havia um erro de variável que quebraria o movimento do mouse. Correções:
>    - o diálogo só é aceito se for do Chrome (nunca texto de página) **e** tiver a tabela de certificados e o botão OK;
>    - as linhas são as da tabela, com titular, emissor e série nas células; a escolha é pelo número de série;
>    - antes de cada clique: a janela do Windows no ponto tem de ser a do Chrome com o diálogo, e o ponto tem de estar
>      no botão; o Chrome é trazido para a frente;
>    - **validado no seu computador**, com a janela real e o seu certificado: janela achada, certificado identificado
>      pela série, mouse movido e clique feito; a janela fechou (o teste terminou em **Cancelar** de propósito, para
>      não autenticar). As mensagens saem como `[CERTIFICADO]`.
> 2. **Emissão e PDF.** Resultado conferido (nada é emitido para registro diferente ou ausente); "Emitir Certidão"
>    reconhecido pelo texto principal, com qualquer número entre parênteses; um único clique na emissão, nunca
>    repetido sozinho; **Visualizar Certidão**; documento pego em nova aba, na aba atual, embutido na página ou por
>    download; sem PDF original, o PDF é gerado da página HTML da certidão; identificador conferido dentro do PDF;
>    nome `36.690.216_0001-73_NOME.pdf` / `CPF_..._NOME.pdf` / `IE_..._NOME.pdf`; sem sobrescrever (`_2`, `_3`).

> **0.4.2 (duas correções):**
> 1. **"Certidão Negativa" não era encontrada.** O registro da execução de 18/11, 13:17, mostrou a página de Certidões
>    carregada (rota `frm_psfz_cert_index` e os títulos na tela). Mesmo assim, a automação dizia "a página de Certidões
>    não carregou". Causa: a regra que separa o caminho "Início > Certidões" do título grande descartava qualquer
>    elemento cujo contêiner começasse com "Início >". Na página real, o título "Certidões" fica no mesmo contêiner do
>    caminho, então era descartado e a busca nem começava. Correção:
>    - um elemento só é do caminho se for **exatamente um dos trechos** separados por ">";
>    - a página de Certidões vale por título + blocos, **ou** pela rota + blocos, **ou** por 4 blocos;
>    - o bloco é procurado em camadas: texto exato; texto normalizado (inclusive caracteres invisíveis); inspeção dos
>      pais (ação de clique, cursor de mão ou o contêiner só deste título);
>    - falha pausa com diagnóstico completo (endereço, carregamento, camadas, quantidades, estrutura), sem F5;
>    - 2 tentativas de 15 s, em vez de 3 de 30 s.
> 2. **Janela nativa "Selecione um certificado" (Modo 2 do mouse).** A janela é do Chrome, fora da página. Agora a
>    automação usa a **API de acessibilidade do Windows (UI Automation)** e o **cursor real**: identifica o certificado
>    pelo **número de série** e clica em **OK** (seção 3).
>
> **0.4.1 (correção do travamento após o login):** o portal logado (`/portalsefaz/...?headless`) é uma "casca" que mostra
> o conteúdo num **quadro interno (iframe)**. A extensão só olhava a página de fora, vazia. Por isso dava "a página não
> terminou o carregamento inicial (cabeçalho=não, blocos=não)" com a página visível na tela.
> - A extensão agora roda em todos os quadros (`all_frames`), mas só **um** age: no portal logado, o quadro grande do
>   portal; nas páginas de login, a página de fora. Quadros pequenos ou de outros sites são ignorados.
> - O login é conferido dentro do quadro e também na página de fora.
> - Se a página travar de novo, o registro lista os quadros encontrados (endereço, tamanho, se é de outro site).
>
> **0.4.0:**
> - Correção da tela de autorização: espera no gov.br sem limite que vire erro, e retomada automática.
> - Fluxo Certidões → Certidão Negativa → tipo → identificador → Pesquisar.
> - Lista mista (CNPJ, CPF, IE e CNPJ alfanumérico).
> - Estados nomeados da automação.
>
> **0.3.0:** interface, mouse configurável, certificado digital. **0.2.0:** login gov.br, terminal e janela anônima.

---

## 1. Atualizar e usar

1. `chrome://extensions` > na extensão **Retirar_Certidao_SEFAZ-PE**, clique na **setinha de recarregar** e confira a
   versão **0.6.1**. Ela deve estar ligada, com **Permitir no modo anônimo** ativado.
2. Feche as janelas anônimas abertas.
3. Dois cliques em **`INTERFACE.cmd`**. A janela preta precisa ficar aberta. A interface abre sozinha; se não abrir,
   acesse <http://127.0.0.1:47831/>.
4. Preencha os blocos:

   | Bloco | O que preencher |
   |---|---|
   | 1. Certificado digital | O seu certificado, ou "Sem certificado (login manual)" |
   | 2. Pasta de resultados | Por exemplo, `CERTIDOES_SEFAZ_PE_NOVEMBRO` |
   | 3. Velocidade do mouse | Lento (padrão) |
   | 4. Lista de empresas / documentos | Cole a lista e marque em **Testar** o registro desta execução |

5. Clique em **INICIAR AUTOMAÇÃO**.

Sem lista, a execução vai só até a autenticação, como na 0.3.0.

## 2. Lista de empresas / documentos para consulta

Uma linha por registro. Separador `;` ou TAB (colado do Excel). Maiúsculas, espaços e máscaras não importam.

```
CNPJ;12.345.678/0001-00;EMPRESA ALFA
CPF;123.456.789-00;PESSOA BETA
IE;0123456-78;EMPRESA GAMA
12345678000100;EMPRESA NO FORMATO ANTIGO
```

(números ilustrativos)

| Regra | Como funciona |
|---|---|
| Formato novo `tipo;identificador;nome` | Tipo `CNPJ`, `CPF` ou `IE` (também "Inscrição Estadual"), em qualquer caixa |
| Formato antigo `cnpj;nome` | **Continua funcionando**: o tipo CNPJ é reconhecido quando há 14 dígitos com verificadores corretos |
| 11 dígitos **sem** tipo | **Não** viram CPF automaticamente: a linha é apontada pedindo `CPF;...` ou `IE;...` |
| Inscrição Estadual | **Sempre** com o tipo `IE`. PE: 9 dígitos com verificadores conferidos (ex. `0321418-40`), ou 14 no formato antigo (só aviso) |
| CNPJ alfanumérico | Aceito: são os CNPJs com letras emitidos pela Receita desde jul/2026 (ex. `12.ABC.345/01DE-35`) |
| Zeros perdidos no Excel | Completados **só** se os verificadores conferirem, e sempre com aviso na tela |
| Vazias, `#comentário`, cabeçalho | Ignoradas |
| Repetidas (mesmo tipo e número) | Ignoradas; vale a primeira |
| Inválidas | Mostradas em vermelho com o motivo; **não impedem** as demais |
| Ordem | A da lista, com o número da linha original |

A interface mostra uma tabela com cada linha: tipo, identificador formatado, nome e situação. Mostra também o resumo
(válidos por tipo, inválidos e ignorados). Marque em **Testar** o registro desta execução; por padrão vem marcado o
primeiro válido. A lista fica salva em `dados\lista_documentos.txt`, e o registro escolhido em `dados\config.json`.
O leitor foi testado com 800 linhas.

## 3. Os dois modos do mouse e a janela de certificados

| Modo | Onde age | Como |
|---|---|---|
| **1 — Navegação web** (extensão) | Tudo o que é página: botões, blocos, opções, campos, rolagem | Cursor visual + eventos do DOM, mouse humanizado (`mouse_humano.js`) |
| **2 — Janela nativa do Windows** | Só a janela **"Selecione um certificado"** do Chrome | **Windows UI Automation** + **cursor real** (`nucleo/selecionar_certificado.ps1`) |

A troca é automática. Ao clicar em "Seu certificado digital", a extensão avisa o computador e o Modo 2 assume. O Modo 2
termina quando a janela fecha (ou se for cancelado). Nenhuma biblioteca extra é instalada: PowerShell e .NET já vêm no
Windows, e não são usados PyAutoGUI nem pywinauto.

O que o Modo 2 faz:

1. Espera até 60 s pela janela com o título "Selecione um certificado".
2. Lê as linhas da janela: titular, emissor e número de série.
3. Identifica o certificado escolhido na interface **pelo número de série**. Se a janela não mostrar números de série,
   usa **titular + emissor**, desde que só uma linha corresponda. **Nunca pela posição na lista.**
4. Se a linha certa não estiver selecionada, move o cursor real até ela e clica. Depois confere que ficou selecionada.
5. Move o cursor até **OK**. Antes de clicar, confere que o elemento sob o cursor é o OK e que a linha certa continua
   selecionada.
6. Espera a janela fechar. **PIN ou senha, se pedidos, são digitados por você.**

Quando não é seguro, ele **não clica** e pede a seleção manual, com um diagnóstico da janela no registro. Isso vale para:
nenhuma linha com o número de série, mais de uma possível, linhas ilegíveis, OK desabilitado ou janela coberta.

**Mexer o mouse ou apertar ESC** cancela o controle na hora; **PARAR** e **PAUSAR** também. As coordenadas vêm da própria
janela, já considerando escala de exibição, resolução e posição. Não há coordenadas fixas.

Para desligar e escolher você mesmo: desmarque, no bloco 1 da interface, **"Selecionar este certificado na janela do
Chrome automaticamente"**.

## 3b. O fluxo e os estados da automação

```
INICIANDO → [sem sessão] AUTENTICANDO_GOVBR / AGUARDANDO_LOGIN (você) / AGUARDANDO_AUTORIZACAO → AUTORIZANDO_GOVBR
         → ACESSANDO_SEFAZ (identifica a tela: inicial, Certidões ou Certidão Negativa)
         → LOCALIZANDO_CERTIDAO_NEGATIVA → ABRINDO_CONSULTA
         → IDENTIFICANDO_TIPO_DOCUMENTO → PREENCHENDO_IDENTIFICADOR → VALIDANDO_PREENCHIMENTO
         → CLICANDO_PESQUISAR → AGUARDANDO_RESPOSTA → ETAPA_CONCLUIDA (para aqui)
         (a qualquer momento: ERRO_RECUPERAVEL, tentando de novo · AGUARDANDO_INTERVENCAO · PAUSADA)
```

O estado aparece na interface (Execução > Estado), na janela preta (`[ESTADO] ...`), no popup e no painel da página.
A automação não supõe que sempre começa pela página inicial. Depois do login, o portal costuma abrir direto em
**Certidões**, e a etapa "Identificar a tela da SEFAZ" escolhe o caminho a partir da tela real.

| Etapa | O que a automação faz |
|---|---|
| Certidões → **Certidão Negativa** | Bloco com o título **exatamente** "Certidão Negativa". Rola até ele se preciso. Ignora o caminho "Início > Certidões" e o menu lateral. Nunca clica em "Regularidade Fiscal" ou em outro serviço. Se houver mais de um bloco com esse título, não clica |
| Confirma a consulta | Título "Certidão Negativa", as opções e o botão "Pesquisar" na tela |
| Tipo | Clica na opção do registro (**CNPJ**, **CPF** ou **Inscrição Estadual**) e confere que só ela ficou marcada. Espera o formulário atualizar |
| Identificador | Clica no campo **"Pesquise pelo ..."** (nunca na busca geral "Qual outro serviço você procura?"). Digita tecla a tecla no ritmo do perfil do mouse e confere o valor sem a máscara do site. Se a máscara recusar, aplica o valor já formatado e confere de novo |
| Pesquisar | Confere tipo e valor, espera o botão ficar disponível e dá **um único clique**. Antes do clique grava "pesquisa enviada": nenhuma retomada (F5, erro, Continuar) clica de novo |
| Resposta | Espera até 45 s por uma mudança: aviso, tabela, nova área ou outro endereço. Registra **qual** mudança apareceu, sem ler o conteúdo, e **para**. Sem mudança visível, avisa e também para, sem repetir |

Final: **"Pesquisa enviada (linha N: TIPO número — NOME). A resposta está na tela; a automação parou aqui para você
analisar."** O navegador fica aberto.

## 4. Correção da tela de autorização (o erro da sua imagem)

O que aconteceu: a execução de 11:52 (versão 0.2.0) esperou o login no gov.br por 20 min e, às 12:13, desistiu com "O
login não foi concluído dentro do tempo de espera". Quando o login foi concluído depois, na mesma janela, a execução já
estava "pausada por erro" e **não retomou** nas páginas novas. Por isso o aviso antigo ficou por cima da tela de
autorização.

O que mudou:

- **Esperar você no gov.br não tem mais limite que vire erro.** Login, certificado, PIN, CAPTCHA e autorização: a
  automação espera e reclassifica a página a cada segundo. A cada 5 min só registra "continuo aguardando".
- **A tela de autorização é tratada sempre que aparecer**: logo após "Login com gov.br", depois do certificado ou
  num redirecionamento. Antes do clique, a automação confere três coisas: domínio `sso.acesso.gov.br`, serviço "e-Fisco
  \- Sefaz PE" e botões "Autorizar" e "Negar" visíveis. Nunca clica em "Negar".
- **Retomada automática:** se a execução parou por um erro do tipo "a página não avançou" (login, autorização,
  redirecionamento, sessão) e depois uma página nova carrega na aba, a automação confere o estado real e retoma
  sozinha, até 5 vezes por execução.
- **Nada é recarregado** nas páginas do gov.br. No portal, antes de qualquer F5, a automação espera o carregamento
  pendente terminar.

## 5. Tratamento de erros

| Situação | O que a automação faz |
|---|---|
| Elemento ainda não carregado / não encontrado | Até 3 tentativas com espera crescente e nova rolagem. Se não achar, registra um **mapa curto da tela** (títulos, botões, opções e campos visíveis) para ajuste |
| Opção não ficou marcada / campo com valor diferente | Nova tentativa controlada (seleciona e digita de novo) |
| Botão temporariamente indisponível | Espera habilitar, sem clicar repetidamente |
| Portal pede login no meio do caminho | Volta para a autenticação. **Depois da pesquisa enviada**, para e avisa: não repete a pesquisa |
| Carregamento lento | Espera terminar; F5 só no portal, no máximo 2 vezes, e nunca no gov.br |
| Erro sem recuperação automática | Pausa com o motivo, a etapa e o registro. **Continuar** faz uma nova tentativa (a pesquisa já enviada não é repetida) |

Cada registro mostra a etapa, a mensagem e o registro da lista. O CPF aparece mascarado fora da interface:
`***.982.247-**`.

## 6. Mouse

O mesmo mecanismo central é usado na rolagem, no Autorizar, na Certidão Negativa, nas opções de tipo, no campo e no
Pesquisar. No perfil **Lento** (padrão), as pausas foram encurtadas um pouco: 0,4 a 0,8 s antes do clique. A digitação
segue o perfil: Lento 0,09 a 0,19 s por tecla, Normal 0,06 a 0,13 s, Rápido 0,04 a 0,09 s. A seta azul é visual: o
ponteiro real do Windows não se move.

## 7. Arquivos alterados nesta versão (0.5.0)

| Arquivo | Mudança |
|---|---|
| `nucleo/selecionar_certificado.ps1` | Diálogo só aceito se for do Chrome, com tabela e OK; linhas da tabela; conferência do clique por `WindowFromPoint`; Chrome trazido à frente; correção da variável do mouse; `-BotaoFinal Cancelar` só para teste |
| `nucleo/arquivo_certidao.js` (**novo**) | Nome do arquivo, conferência do PDF, identificador dentro do PDF, gravação sem sobrescrever, download movido do Downloads |
| `nucleo/controle.js` | Rota `/arquivo`; mensagens `[CERTIFICADO]`, `[PDF]`, `[VALIDAÇÃO]`, `[SALVAMENTO]`, `[VERIFICAÇÃO]`, `[ARQUIVO]`; duplicados reconhecidos |
| `Retirar_Certidao_SEFAZ-PE/modules/emissao_certidao.js` (**novo**) | Resultado da pesquisa, "Emitir Certidão (N)", confirmação, "Visualizar Certidão", ponte da captura |
| `Retirar_Certidao_SEFAZ-PE/modules/captura_pagina.js` (**novo**) | Roda no mundo da página: PDF gerado pela página, aba nova, link, quadro embutido |
| `Retirar_Certidao_SEFAZ-PE/content.js` | Etapas `analisar_resultado`, `clicar_emitir`, `aguardar_emissao`, `clicar_visualizar`, `aguardar_arquivo`; [SUCESSO] só com o PDF salvo |
| `Retirar_Certidao_SEFAZ-PE/background.js` | Captura armada, varredura de abas/quadros, downloads, PDF gerado da página HTML, conclusão se a página navegou |
| `manifest.json` (0.5.0), `modules/constantes.js`, `base.js`, `tratamento_erros.js` | Permissões `downloads` e `debugger`; etapas, estados e códigos de erro novos |
| `interface/*` | Mensagens novas; linha "PDF salvo" na área Execução |
| `tests/arquivo_certidao.test.js` (**novo**), `tests/pagina/emissao.html` (**novo**), `background.test.js`, `controle.test.js` | Testes novos |

## 8. O que foi testado e o que depende do navegador real

**Testado (18/11/2026):**

- **Janela real de certificados, no seu computador** (Chrome temporário em `certificado.sso.acesso.gov.br`, sem login):
  a janela foi achada, o seu certificado identificado pela série `...D6F3`, o **mouse real** foi movido e o clique foi
  feito. A janela fechou. Por segurança, o teste terminou em **Cancelar**; na automação o mesmo caminho termina em **OK**.
- **Estrutura real da tela logada** (lida na sua janela anônima, só leitura): tabela, "Emitir Certidão (1)", confirmação e
  os ids dos botões.
- Testes automáticos: **143 verificações, todas passando** (`arquivo_certidao` 28, `background` 27, `controle` 10,
  `certificado_nativo` 9, `lista` 11, `nucleo` 10, `iniciar` 14, `interface` 34).
- **Página de teste no navegador** (`tests/pagina/emissao.html`) com os módulos reais da extensão: **27 verificações**
  passaram. Elas cobrem:
  - o resultado (certo, divergente, vazio, CPF mascarado);
  - "Emitir Certidão" com número variável, "Visualizar" achado e "Imprimir" nunca clicado;
  - a captura em nova aba, embutida e por download.

  Mais 3 verificações da varredura: certidão em HTML reconhecida, tela da consulta ignorada e outro CNPJ ignorado.

**Depende da execução real, com login (não pude fazer daqui):**

- O clique em **OK** na janela de certificados durante o login de verdade.
- O que **"Visualizar Certidão"** faz de fato no portal e o PDF salvo no final.
- PDF aberto direto na aba (visualizador do Chrome): o código busca os bytes originais, mas o navegador de teste não abre PDF.
- PDF gerado de página HTML: só acontece se o site não oferecer o PDF. Nesse caso o Chrome mostra por instantes a barra
  "a extensão está depurando este navegador".

Envie `<sua pasta>\relatorios\execucao_*.txt` depois do teste.

## 9. Manutenção

```powershell
cd "C:\Users\PANORAMA-PC\Desktop\Automacao_Sefaz-PE"; foreach ($t in 'recuperacao','lote','arquivo_certidao','controle','certificado_nativo','lista','nucleo','background','iniciar','interface') { node "tests/$t.test.js" | Select-Object -Last 1 }
```

Linha de comando (`INICIAR.cmd` ou `node iniciar.js`): **por padrão** faz o fluxo completo (pesquisa, emissão e PDF) com a lista e o registro salvos pela interface; sem registro escolhido, para no login. `--modo acesso` só faz o login. Ao mudar
a extensão, suba a versão no `manifest.json` e recarregue-a em `chrome://extensions`.