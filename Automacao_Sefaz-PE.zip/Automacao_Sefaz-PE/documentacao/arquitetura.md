# Arquitetura — Retirar_Certidao_SEFAZ-PE

## Iniciador pelo terminal (0.2.0)

```
 iniciar.js (Node)                                         extensão (background.js)
 ├─ lê Preferences do perfil (só leitura): instalada? pasta? anônimo?
 ├─ ponte http://127.0.0.1:47831  ◄── GET /sessao ───────── aba ANÔNIMA do portal se apresenta (registrar)
 │   sessão {token, modo, uso único} ◄── POST /reivindicar ─ pega a sessão → iniciar(modo "acesso", origem "terminal")
 │                                  ◄── POST /evento ────── cada registro (tag) e cada mudança de status
 └─ chrome.exe --incognito --new-window --profile-directory=<perfil> <portal>
```

- A ponte aceita só chamadas sem origem ou de `chrome-extension://`, exige o token da sessão e recusa segunda
  reivindicação. Um segundo iniciador falha ao abrir a porta (uma automação por vez).
- Execuções do popup (`origem: "popup"`) não falam com o terminal. Com o terminal desligado, a extensão funciona
  igual (a consulta à ponte falha em silêncio).
- Páginas de autenticação (`sso.acesso.gov.br`, `sso.transdigital.ati.pe.gov.br`) rodam o mesmo content script;
  a retomada vai direto para `autenticacao_govbr` (`modules/autenticacao_govbr.js` classifica a página a cada
  leitura). Nessas páginas não há recarga automática.

## Partes e responsabilidades

```
 popup (popup.js)            painel na página (painel_pagina.js)
      │ comando                    │ comando
      ▼                            ▼
 ┌──────────────────── background.js (service worker) ────────────────────┐
 │ único ESCRITOR de chrome.storage.local:                                 │
 │   sefazpe_estado  (status, etapa, indicadores, execId, tabId, flags)    │
 │   sefazpe_logs    (últimos 500 registros, já sanitizados)               │
 │ comandos: iniciar · pausar · continuar · parar · limpar_logs · redefinir│
 │ garante o content script na aba (ping → scripting.executeScript)        │
 └───────────────▲─────────────────────────────────┬───────────────────────┘
   estado:atualizar / log / registrar               │ executar / ping
                 │                                  ▼
 ┌──────────────── content scripts (aba do portal) ───────────────────────┐
 │ content.js          fluxo: ETAPAS em ordem, retomada, tratarFalha       │
 │ controle_execucao   cópia do estado (storage.onChanged), checkpoint()   │
 │ detector_* / scroll / mouse / navegador   ações e leituras da página    │
 └─────────────────────────────────────────────────────────────────────────┘
 popup e painel LEEM o estado direto do storage (onChanged) — não guardam nada.
```

## Estado e execução

- `execId` identifica a execução. Mensagens da página com `execId` diferente são ignoradas (ex.: um script antigo
  depois de F5).
- `tabId` amarra a execução a uma aba. O content script pergunta ao background quem ele é (`registrar`).
- `status`: `ocioso` → `executando` ⇄ `aguardando_login` → `concluido`; a qualquer momento `pausado`, `erro`
  (pausa por erro) ou `parado`.
- Regra de precedência: uma atualização vinda da página **não** desfaz pausa/parada do usuário. O status que a
  página queria fica em `statusAntesPausa` e é restaurado no Continuar.
- `checkpoint()` é chamado entre todas as ações: bloqueia em `pausado`/`erro`, encerra em
  `parado`/`ocioso`/`concluido`, ou quando o contexto da extensão é invalidado (extensão recarregada).

## Retomada (F5, login, recarga de recuperação)

1. A página carrega e `content.js` chama `registrar`.
2. Se o estado é desta aba e está `executando`/`aguardando_login`, executa de novo.
3. Ponto de partida: `cliqueRealizado` ? `aguardar_proxima_tela` : `verificar_portal`.
   As etapas anteriores ao clique só observam a página, então podem ser refeitas.
4. `cliqueRealizado` é gravado **imediatamente antes** de disparar o clique (`antesDoDisparo`), para valer mesmo se
   a página navegar na hora.

## Como acrescentar uma etapa

1. `modules/constantes.js`: inclua `{ id, rotulo }` em `ETAPAS`, na posição certa (antes de `concluida`).
2. `content.js`: escreva `async function etapaX()` e inclua no mapa `ETAPAS`. Retorne `null` para seguir ou
   `{ irPara: 'id' }` para desviar. Lance `ErroAutomacao(codigo, detalhe)` para falhas.
3. Ajuste `indiceInicial()` se a nova etapa tiver uma ação não repetível (como o clique de hoje).
4. Seletores e textos novos vão para `CONFIG` em `modules/base.js`.
5. Permissões novas (ex.: `downloads`) só quando a etapa precisar delas.
