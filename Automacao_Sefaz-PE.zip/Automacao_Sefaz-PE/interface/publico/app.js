// Página da interface: lê o estado do servidor local a cada segundo e envia as ações.
// Nada aqui toca no navegador da automação: quem age no portal é a extensão.
(function () {
  'use strict';

  const $ = (id) => document.getElementById(id);
  const FASES = {
    parada: 'Pronta', abrindo: 'Abrindo o Chrome', executando: 'Em execução', aguardando_voce: 'Aguardando você',
    pausada: 'Pausada', erro: 'Pausada por erro', concluida: 'Concluída', interrompida: 'Interrompida',
  };
  const ETAPAS = {
    verificar_portal: 'Verificar portal', verificar_login: 'Verificar autenticação', acionar_login_govbr: 'Clicar em "Login com gov.br"',
    autenticacao_govbr: 'Autenticação no gov.br', confirmar_acesso: 'Confirmar acesso', concluida: 'Concluída',
    identificar_tela_sefaz: 'Identificar a tela da SEFAZ', localizar_acesso_rapido: 'Localizar "Acesso Rápido"',
    localizar_certidoes: 'Localizar bloco "Certidões"', clicar_certidoes: 'Acessar "Certidões"', aguardar_proxima_tela: 'Aguardar a página de Certidões',
    localizar_certidao_negativa: 'Localizar "Certidão Negativa"', abrir_certidao_negativa: 'Abrir a consulta de Certidão Negativa',
    selecionar_tipo_documento: 'Selecionar CNPJ / CPF / Inscrição Estadual', preencher_identificador: 'Preencher e conferir o identificador',
    clicar_pesquisar: 'Clicar em "Pesquisar"', aguardar_resposta: 'Aguardar a resposta da pesquisa',
    analisar_resultado: 'Conferir o resultado', clicar_emitir: 'Clicar em "Emitir Certidão"',
    aguardar_emissao: 'Aguardar a confirmação da emissão', clicar_visualizar: 'Clicar em "Visualizar Certidão"',
    aguardar_arquivo: 'Salvar o PDF na pasta',
  };
  const ROTULO_TIPO = { CNPJ: 'CNPJ', CPF: 'CPF', IE: 'Inscrição Estadual' };
  const VELOCIDADES = { lento: 'Lento', normal: 'Normal', rapido: 'Rápido' };

  let certificados = [];
  let fase = 'parada';
  let ultimoSeq = 0;
  let carregouConfig = false;
  let salvarTimer = null;
  let pastaTimer = null;
  let listaTimer = null;
  let registros = [];
  let registroLinha = null;

  // ---- Tema --------------------------------------------------------------------------------------
  function aplicarTema(t) {
    if (t) document.documentElement.dataset.theme = t;
    else delete document.documentElement.dataset.theme;
  }
  try { aplicarTema(localStorage.getItem('sefazpe_tema')); } catch (e) { /* sem armazenamento: segue o sistema */ }
  $('btTema').addEventListener('click', () => {
    const escuroAgora = document.documentElement.dataset.theme
      ? document.documentElement.dataset.theme === 'dark'
      : matchMedia('(prefers-color-scheme: dark)').matches;
    const novo = escuroAgora ? 'light' : 'dark';
    aplicarTema(novo);
    try { localStorage.setItem('sefazpe_tema', novo); } catch (e) { /* ignora */ }
  });

  // ---- Utilitários -------------------------------------------------------------------------------
  async function pedir(caminho, corpo) {
    const r = await fetch(caminho, corpo === undefined ? {} : { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(corpo) });
    let dados = {};
    try { dados = await r.json(); } catch (e) { dados = {}; }
    return { status: r.status, ...dados };
  }

  const certSelecionado = () => {
    const el = document.querySelector('input[name="cert"]:checked');
    return el && el.value ? el.value : null;
  };
  const velocidade = () => (document.querySelector('input[name="velocidade"]:checked') || {}).value || 'lento';
  const dadosFormulario = () => ({
    certificadoId: certSelecionado(), pasta: $('inPasta').value.trim(), velocidadeMouse: velocidade(),
    lista: $('inLista').value, registroLinha: null, selecaoNativa: $('chkNativa').checked,
    intervaloSegundos: Math.min(120, Math.max(0, Number($('inIntervalo').value) || 0)),
    maxTentativas: Math.min(6, Math.max(1, Math.round(Number($('inTentativas').value) || 3))),
    limiteEtapaSegundos: Math.min(600, Math.max(30, Number($('inLimite').value) || 120)),
  });
  $('chkNativa').addEventListener('change', () => salvarDepois());
  $('inIntervalo').addEventListener('input', () => salvarDepois());
  $('inTentativas').addEventListener('input', () => salvarDepois());
  $('inLimite').addEventListener('input', () => salvarDepois());

  function mostrarErro(id, texto) {
    $(id).hidden = !texto;
    $(id).textContent = texto || '';
  }

  // ---- Certificados ------------------------------------------------------------------------------
  function seloSituacao(c) {
    const classe = c.nivel === 'ok' ? 'selo-ok' : c.nivel === 'atencao' ? 'selo-atencao' : 'selo-erro';
    return `<span class="selo ${classe}">${c.utilizavel ? c.situacao : 'Não utilizável'}</span>`;
  }

  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));

  function renderCertificados(escolhido) {
    const lista = $('listaCert');
    const itens = certificados.map((c) => `
      <label class="cert${c.utilizavel ? '' : ' desabilitado'}" title="${esc(c.problemas.join('; '))}">
        <input type="radio" name="cert" value="${esc(c.id)}" ${c.utilizavel ? '' : 'disabled'} ${c.id === escolhido ? 'checked' : ''}>
        <span class="cert-nome">${esc(c.titular)}</span>
        ${seloSituacao(c)}
        <span class="cert-det">
          <span>${esc(c.tipo)} ${esc(c.documentoFormatado)}</span>
          <span>Válido até ${esc(c.validoAte)}</span>
          <span>${esc(c.emissor)}</span>
          <span>Série ${esc(c.serial)}</span>
          ${c.utilizavel ? '' : `<span>${esc(c.problemas.join('; '))}</span>`}
        </span>
      </label>`).join('');
    lista.innerHTML = itens + `
      <label class="cert">
        <input type="radio" name="cert" value="" ${!escolhido ? 'checked' : ''}>
        <span class="cert-nome">Sem certificado (login manual)</span>
        <span></span>
        <span class="cert-det"><span>A automação clica em "Login com gov.br" e espera você entrar do jeito que preferir.</span></span>
      </label>`;
    lista.querySelectorAll('input[name="cert"]').forEach((i) => i.addEventListener('change', () => { mostrarErro('erroCert', ''); salvarDepois(); atualizarResumo(); }));
    atualizarResumo();
  }

  async function carregarCertificados(atualizar) {
    $('btAtualizarCert').disabled = true;
    const escolhido = certSelecionado() || (window.__configInicial && window.__configInicial.certificadoId);
    const r = await pedir(`/api/certificados${atualizar ? '?atualizar=1' : ''}`).catch(() => ({ ok: false, erro: 'Sem conexão com o servidor da interface.' }));
    certificados = r.certificados || [];
    if (!r.ok) {
      $('listaCert').innerHTML = `<p class="vazio">${esc(r.erro || 'Não foi possível ler os certificados.')}</p>`;
    } else if (!certificados.length) {
      $('listaCert').innerHTML = '<p class="vazio">Nenhum certificado encontrado no Windows. Conecte o token (A3) ou instale o certificado (A1) e clique em "Atualizar lista".</p>';
      renderCertificados(null);
    } else {
      const existe = certificados.some((c) => c.id === escolhido && c.utilizavel);
      renderCertificados(existe ? escolhido : null);
    }
    $('btAtualizarCert').disabled = false;
  }

  // ---- Pasta -------------------------------------------------------------------------------------
  async function validarPasta() {
    const nome = $('inPasta').value.trim();
    if (!nome) {
      $('caminhoPasta').textContent = '—';
      $('pastaExiste').hidden = true;
      $('inPasta').classList.remove('invalido');
      mostrarErro('erroPasta', '');
      atualizarResumo();
      return;
    }
    const r = await pedir('/api/pasta', { nome }).catch(() => ({ ok: false, erro: 'Sem conexão com o servidor da interface.' }));
    $('inPasta').classList.toggle('invalido', !r.ok);
    $('caminhoPasta').textContent = r.ok ? r.caminho : '—';
    $('pastaExiste').hidden = !(r.ok && r.existe);
    mostrarErro('erroPasta', r.ok ? '' : r.erro);
    atualizarResumo();
  }

  $('inPasta').addEventListener('input', () => {
    clearTimeout(pastaTimer);
    pastaTimer = setTimeout(validarPasta, 250);
    salvarDepois();
  });
  document.querySelectorAll('input[name="velocidade"]').forEach((i) => i.addEventListener('change', () => { salvarDepois(); atualizarResumo(); }));

  // ---- Lista de documentos --------------------------------------------------------------------------
  function registroEscolhido() {
    return registros.find((r) => r.linha === registroLinha && r.status === 'valido') || null;
  }

  function renderLista(res) {
    registros = res.registros || [];
    const s = res.resumo || { total: 0 };
    const temLinhas = registros.some((r) => r.motivo !== 'linha vazia');
    $('resumoLista').hidden = !temLinhas;
    $('caixaTabela').hidden = !temLinhas;
    if (!temLinhas) {
      registroLinha = null;
      $('corpoLista').innerHTML = '';
      atualizarResumo();
      return;
    }
    $('resumoLista').innerHTML = `
      <span class="selo selo-ok">${s.validos} válido${s.validos === 1 ? '' : 's'}</span>
      <span class="selo selo-info">CNPJ ${s.porTipo.CNPJ} · CPF ${s.porTipo.CPF} · IE ${s.porTipo.IE}</span>
      ${s.invalidos ? `<span class="selo selo-erro">${s.invalidos} inválido${s.invalidos === 1 ? '' : 's'}</span>` : ''}
      ${s.ignoradas ? `<span class="selo selo-atencao">${s.ignoradas} ignorado${s.ignoradas === 1 ? '' : 's'}</span>` : ''}`;
    // Todos os registros válidos são processados, na ordem: não há escolha de um só.
    $('resumoLista').insertAdjacentHTML('afterbegin', `<span class="selo selo-info"><b>Total de registros: ${s.validos}</b></span>`);
    $('corpoLista').innerHTML = registros.filter((r) => r.motivo !== 'linha vazia').map((r) => {
      const valido = r.status === 'valido';
      const situacao = valido ? (r.avisos && r.avisos.length ? `Válido (${esc(r.avisos.join('; '))})` : 'Válido') : esc(r.motivo);
      return `<tr class="${r.status}">
        <td class="num">${r.linha}</td>
        <td>${esc(r.tipo ? ROTULO_TIPO[r.tipo] : '—')}</td>
        <td class="id">${esc(r.formatado || '')}</td>
        <td>${esc(r.nome || '')}</td>
        <td>${situacao}</td>
      </tr>`;
    }).join('');
    atualizarResumo();
  }

  async function analisarLista() {
    const r = await pedir('/api/lista', { texto: $('inLista').value }).catch(() => null);
    if (r && r.ok) renderLista(r);
  }

  $('inLista').addEventListener('input', () => {
    clearTimeout(listaTimer);
    listaTimer = setTimeout(() => { analisarLista().then(salvarDepois); }, 350);
  });

  // Configuração salva automaticamente (não precisa preencher de novo da próxima vez).
  function salvarDepois() {
    if (!carregouConfig) return;
    clearTimeout(salvarTimer);
    salvarTimer = setTimeout(() => pedir('/api/config', dadosFormulario()).catch(() => {}), 500);
  }

  function atualizarResumo() {
    const id = certSelecionado();
    const c = certificados.find((x) => x.id === id);
    $('resCert').textContent = c ? `${c.titular} · ${c.tipo} ${c.documentoFormatado} · até ${c.validoAte}` : 'Sem certificado (login manual)';
    $('resPasta').textContent = $('caminhoPasta').textContent;
    $('resMouse').textContent = VELOCIDADES[velocidade()];
    const validos = registros.filter((r) => r.status === 'valido').length;
    $('resRegistro').textContent = validos ? `Todos os ${validos} registro(s) válido(s), em ordem` : 'Lista vazia (vai só até a autenticação)';
  }

  // ---- Controles ---------------------------------------------------------------------------------
  function atualizarBotoes() {
    const ativa = ['abrindo', 'executando', 'aguardando_voce', 'pausada', 'erro'].includes(fase);
    $('btIniciar').disabled = ativa;
    $('btPausar').disabled = !['executando', 'aguardando_voce'].includes(fase);
    $('btContinuar').disabled = !['pausada', 'erro'].includes(fase);
    $('btParar').disabled = !ativa;
    document.querySelectorAll('#listaCert input, #inPasta, #inLista, #chkNativa, #inIntervalo, #inTentativas, #inLimite, input[name="velocidade"], #btAtualizarCert').forEach((el) => {
      if (el.name === 'velocidade') return; // a velocidade pode mudar a qualquer momento
      if (el.closest('.cert.desabilitado')) return;
      el.disabled = ativa;
    });
  }

  $('btIniciar').addEventListener('click', async () => {
    $('retorno').textContent = '';
    mostrarErro('erroCert', '');
    mostrarErro('erroPasta', '');
    mostrarErro('erroLista', '');
    $('btIniciar').disabled = true;
    const r = await pedir('/api/iniciar', dadosFormulario()).catch(() => ({ ok: false, erro: 'Sem conexão com o servidor da interface.' }));
    if (!r.ok) {
      if (r.erros && r.erros.lista) mostrarErro('erroLista', r.erros.lista);
      if (r.erros && r.erros.certificado) mostrarErro('erroCert', r.erros.certificado);
      if (r.erros && r.erros.pasta) { mostrarErro('erroPasta', r.erros.pasta); $('inPasta').classList.add('invalido'); }
      $('retorno').textContent = r.erro || 'Não foi possível iniciar.';
      $('btIniciar').disabled = false;
    } else {
      $('pastaExiste').hidden = false;
      $('pastaExiste').textContent = r.existia ? 'já existia' : 'criada';
    }
  });

  for (const [id, rota] of [['btPausar', 'pausar'], ['btContinuar', 'continuar'], ['btParar', 'parar']]) {
    $(id).addEventListener('click', async () => {
      $('retorno').textContent = '';
      const r = await pedir(`/api/${rota}`, {}).catch(() => ({ ok: false, erro: 'Sem conexão com o servidor da interface.' }));
      if (!r.ok) $('retorno').textContent = r.erro || 'Não foi possível.';
    });
  }

  // ---- Estado e registros ------------------------------------------------------------------------
  function classeLog(l) {
    if (l.nivel === 'erro' || l.tag === 'ERRO') return 'erro';
    if (l.nivel === 'aviso' || ['AVISO', 'AGUARDANDO', 'PAUSA'].includes(l.tag)) return 'aviso';
    if (l.tag === 'SUCESSO') return 'sucesso';
    return '';
  }

  function adicionarLogs(linhas) {
    const lista = $('listaLogs');
    for (const l of linhas) {
      const li = document.createElement('li');
      li.className = classeLog(l);
      const hora = new Date(l.t).toLocaleTimeString('pt-BR', { hour12: false });
      li.innerHTML = `<span class="hora">${hora}</span><span class="tag">[${esc(l.tag)}]</span>${esc(l.mensagem)}`;
      lista.appendChild(li);
      ultimoSeq = Math.max(ultimoSeq, l.seq);
    }
    while (lista.children.length > 600) lista.removeChild(lista.firstChild);
    if (linhas.length && $('chkRolar').checked) lista.scrollTop = lista.scrollHeight;
  }

  // ---- Processamento da lista -----------------------------------------------------------------
  const STATUS_LOTE = {
    pendente: ['Pendente', ''], processando: ['Processando', 'selo-info'], sucesso: ['Sucesso', 'selo-ok'],
    nao_encontrado: ['Não encontrado', 'selo-atencao'], erro: ['Erro', 'selo-erro'], invalido: ['Inválido', 'selo-erro'],
  };
  let assinaturaTabela = '';

  function renderLote(l, e) {
    $('cartaoLote').hidden = !l;
    if (!l) return;
    $('ltTotal').textContent = l.total;
    $('ltSucesso').textContent = l.sucesso;
    $('ltErro').textContent = l.erro;
    $('ltNaoEnc').textContent = l.naoEncontrado;
    $('ltPendente').textContent = l.pendente;
    $('ltProc').textContent = l.processando;
    const pct = Number(l.percentual) || 0;
    $('ltBarraCheia').style.width = `${pct}%`;
    $('ltBarra').setAttribute('aria-valuenow', String(pct));
    $('ltPct').textContent = `${pct.toLocaleString('pt-BR')}%`;
    $('ltPctTexto').textContent = `${l.finalizados} de ${l.total} finalizado(s)${l.invalido ? ` · ${l.invalido} linha(s) inválida(s) fora do processamento` : ''}`;
    const a = l.atual;
    $('ltAtualCaixa').hidden = !a;
    if (a) {
      $('ltPosicao').textContent = `${a.posicao}/${l.total}`;
      $('ltAtualNome').textContent = a.nome || '—';
      $('ltAtualId').textContent = `${ROTULO_TIPO[a.tipo] || a.tipo}: ${a.formatado}`;
      $('ltEtapa').textContent = `${ETAPAS[e.etapa] || e.etapa || '—'}${e.mensagem ? ` — ${e.mensagem}` : ''}`;
      const oc = a.ultimaOcorrencia;
      $('ltTentativa').hidden = !oc;
      if (oc) $('ltTentativa').textContent = `Tentativa ${oc.tentativa || '?'} · Problema: ${oc.problema || '—'} · Ação: ${oc.acao || '—'}`;
    }
    const terminou = !a && l.pendente === 0 && l.processando === 0 && e.fase === 'concluida';
    $('ltFinal').hidden = !terminou;
    if (terminou) {
      $('ltFinal').textContent = `PROCESSAMENTO FINALIZADO\nTotal de registros: ${l.total}\nCertidões salvas: ${l.sucesso}\nRegistros com erro: ${l.erro}\nRegistros não encontrados: ${l.naoEncontrado}\nPasta de resultados: ${(e.config && e.config.pastaResultados) || '—'}${e.planilha ? `\nPlanilha: ${e.planilha}` : ''}`;
    }
    // A tabela só é redesenhada quando algo muda (não fecha os detalhes abertos a cada segundo).
    const assinatura = JSON.stringify(l.itens.map((i) => [i.status, i.mensagem, i.tentativas, (i.historico || []).length, i.evidencia]));
    if (assinatura === assinaturaTabela) return;
    assinaturaTabela = assinatura;
    $('ltCorpo').innerHTML = l.itens.map((i) => {
      const [rot, classe] = STATUS_LOTE[i.status] || [i.status, ''];
      let detalhe = '';
      if (i.status === 'sucesso') detalhe = `<span title="${esc(i.caminho)}">${esc(String(i.caminho || '').split(/[\\/]/).pop())}</span>`;
      else if (['erro', 'nao_encontrado', 'invalido'].includes(i.status) || i.mensagem) {
        const hist = (i.historico || []).map((o) => `<br>• ${esc(new Date(o.hora).toLocaleTimeString('pt-BR'))} — ${esc(o.etapa || '?')}: ${esc(o.problema || '')} → ${esc(o.acao || '')}${o.tentativa ? ` (tentativa ${esc(o.tentativa)})` : ''}`).join('');
        detalhe = `<details><summary>ver detalhe</summary><p>${esc(i.mensagem || '—')}${i.codigo ? `<br>Código: ${esc(i.codigo)}` : ''}${i.etapa ? `<br>Etapa: ${esc(i.etapa)}` : ''}${i.tentativas ? `<br>Execuções: ${i.tentativas}` : ''}${i.duracaoSeg != null ? `<br>Tempo: ${i.duracaoSeg} s` : ''}${hist ? `<br>Recuperações:${hist}` : ''}${i.evidencia ? `<br>Captura: ${esc(i.evidencia)}` : ''}</p></details>`;
      }
      return `<tr class="st-${i.status}"><td class="num">${i.linha}</td><td>${esc(ROTULO_TIPO[i.tipo] || i.tipo || '—')}</td><td class="id">${esc(i.formatado || '')}</td><td>${esc(i.nome || '')}</td><td><span class="selo ${classe}">${rot}</span></td><td>${detalhe}</td></tr>`;
    }).join('');
  }

  async function atualizarEstado() {
    let r;
    try {
      r = await pedir(`/api/estado?desde=${ultimoSeq}`);
    } catch (e) {
      $('chipFase').textContent = 'Sem conexão';
      $('chipFase').dataset.fase = 'erro';
      $('mensagem').textContent = 'A janela do servidor (INTERFACE.cmd) foi fechada? Abra-a de novo.';
      return;
    }
    if (!carregouConfig) {
      window.__configInicial = r.config;
      $('versao').textContent = `v${r.versaoExtensao}`;
      $('inPasta').value = r.config.pasta || '';
      const v = document.querySelector(`input[name="velocidade"][value="${r.config.velocidadeMouse || 'lento'}"]`);
      if (v) v.checked = true;
      $('inLista').value = r.listaSalva || '';
      $('chkNativa').checked = r.config.selecaoNativa !== false;
      $('inIntervalo').value = Number.isFinite(r.config.intervaloSegundos) ? r.config.intervaloSegundos : 5;
      $('inTentativas').value = Number.isInteger(r.config.maxTentativas) ? r.config.maxTentativas : 3;
      $('inLimite').value = Number.isFinite(r.config.limiteEtapaSegundos) ? r.config.limiteEtapaSegundos : 120;
      registroLinha = Number.isInteger(r.config.registroLinha) ? r.config.registroLinha : null;
      carregouConfig = true;
      validarPasta();
      analisarLista();
      carregarCertificados(false);
    }
    const e = r.execucao;
    fase = e.fase;
    $('chipFase').textContent = FASES[fase] || fase;
    $('chipFase').dataset.fase = fase;
    $('mensagem').textContent = e.mensagem || '—';
    $('resEtapa').textContent = ETAPAS[e.etapa] || (e.etapa ? e.etapa : '—');
    $('resEstado').textContent = e.estadoAutomacao || '—';
    $('resArquivo').textContent = e.arquivo && e.arquivo.caminho ? e.arquivo.caminho : (fase === 'parada' ? '—' : 'ainda não');
    const regExec = e.config && e.config.registro;
    if (regExec && ['abrindo', 'executando', 'aguardando_voce', 'pausada', 'erro'].includes(fase)) {
      $('resRegistro').textContent = `Linha ${regExec.linha}: ${ROTULO_TIPO[regExec.tipo]} ${regExec.formatado} — ${regExec.nome}`;
    }
    renderLote(e.lote, e);
    const aguarda = !!e.aguardandoVoce;
    $('aguardando').hidden = !aguarda;
    $('aguardandoTexto').textContent = aguarda ? (e.mensagem || '') : '';
    if (fase === 'concluida' && e.modo === 'acesso') $('mensagem').textContent = 'Autenticação concluída. Aguardando próxima etapa.';
    adicionarLogs(r.logs || []);
    atualizarBotoes();
  }

  async function verificarInstalacao() {
    const r = await pedir('/api/instalacao').catch(() => null);
    if (!r) return;
    const ul = $('listaInstalacao');
    ul.innerHTML = '';
    const msgs = r.mensagens || [];
    for (const m of msgs) {
      const li = document.createElement('li');
      li.className = m.nivel === 'aviso' ? 'aviso' : '';
      li.textContent = m.texto;
      ul.appendChild(li);
    }
    if (msgs.some((m) => m.nivel === 'aviso')) $('instalacao').open = true;
  }

  atualizarEstado();
  verificarInstalacao();
  $('btAtualizarCert').addEventListener('click', () => carregarCertificados(true));
  setInterval(atualizarEstado, 1000);
  setInterval(verificarInstalacao, 15000);
})();
