#!/usr/bin/env node
// Interface da Automacao_Sefaz-PE: servidor local (http://127.0.0.1:47831) que mostra a
// janela de controle e conversa com a extensão pela mesma ponte da linha de comando.
//
//   /                      a página da interface (interface/publico)
//   /api/...               ações da página (certificados, pasta, iniciar, pausar, parar...)
//   /sessao, /evento...    ponte com a extensão (nucleo/controle.js)
//
// Só aceita conexões desta máquina (127.0.0.1) e confere o cabeçalho Host (proteção contra
// sites tentando falar com o servidor local). Uso: INTERFACE.cmd  ou  node interface/servidor.js

'use strict';

const http = require('http');
const fs = require('fs');
const path = require('path');
const C = require('../nucleo/comum');
const Cert = require('../nucleo/certificados');
const Pasta = require('../nucleo/pasta');
const Lista = require('../nucleo/lista');
const Lote = require('../nucleo/lote');
const { criarControle } = require('../nucleo/controle');

const { K } = C;
const PUBLICO = path.join(__dirname, 'publico');

function lerArgumentos(argv) {
  const a = { porta: K.TERMINAL.porta, semNavegador: false, semChrome: false, perfil: null, chrome: null };
  for (let i = 0; i < argv.length; i++) {
    const v = argv[i];
    if (v === '--porta') a.porta = Number(argv[++i]); // só para testes
    else if (v === '--sem-navegador') a.semNavegador = true; // não abre a janela da interface
    else if (v === '--sem-chrome') a.semChrome = true; // testes: Iniciar não abre o Chrome anônimo
    else if (v === '--perfil') a.perfil = argv[++i];
    else if (v === '--chrome') a.chrome = argv[++i];
  }
  return a;
}

const TIPOS = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png' };

function main() {
  const args = lerArgumentos(process.argv.slice(2));
  const config = C.lerConfig();
  const perfil = args.perfil || config.perfil || 'Default';
  const registro = new C.Registro();
  const arquivoTerminal = registro.adicionarArquivo(C.arquivoLogTerminal('interface'));
  let relatorioAtual = null;
  let cacheCertificados = null;

  const controle = criarControle({
    registro,
    abrirNavegador: !args.semChrome,
    perfil,
    chrome: args.chrome,
    aoTerminar: () => {
      if (relatorioAtual) {
        registro.escrever('PASTA', `Relatório desta execução: ${relatorioAtual}`);
        registro.removerArquivo(relatorioAtual);
        relatorioAtual = null;
      }
    },
  });

  async function certificados(atualizar) {
    if (!cacheCertificados || atualizar) cacheCertificados = await Cert.listarCertificados();
    return cacheCertificados;
  }

  function responder(res, codigo, corpo) {
    res.writeHead(codigo, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
    res.end(JSON.stringify(corpo));
  }

  function lerCorpo(req) {
    return new Promise((resolve, reject) => {
      let corpo = '';
      req.on('data', (p) => { corpo += p; if (corpo.length > 2 * 1024 * 1024) { req.destroy(); reject(new Error('grande demais')); } });
      req.on('end', () => { try { resolve(JSON.parse(corpo || '{}')); } catch (e) { reject(e); } });
      req.on('error', reject);
    });
  }

  // Validação comum a "salvar" e "iniciar". Devolve { ok, erros: {campo: msg}, cert, pasta }.
  async function validar(dados, { exigirPasta }) {
    const erros = {};
    let cert = null;
    if (dados.certificadoId) {
      const lista = await certificados(false);
      cert = lista.ok ? lista.certificados.find((c) => c.id === dados.certificadoId) : null;
      if (!cert) erros.certificado = 'O certificado escolhido não foi encontrado. Clique em "Atualizar lista" (token conectado?).';
      else if (!cert.utilizavel) erros.certificado = `Este certificado não pode ser usado: ${cert.problemas.join('; ')}.`;
    }
    const pasta = Pasta.caminhoDaPasta(dados.pasta);
    if (!pasta.ok && (exigirPasta || String(dados.pasta || '').trim())) erros.pasta = pasta.erro;
    if (!K.VELOCIDADES[dados.velocidadeMouse]) erros.velocidade = 'Escolha a velocidade do mouse.';

    // Lista: TODOS os registros válidos são processados, na ordem (linhas inválidas não
    // impedem os demais; ficam no relatório como "inválido").
    const lista = Lista.interpretarLista(dados.lista || '');
    const intervalo = Number(dados.intervaloSegundos);
    if (dados.intervaloSegundos !== undefined && (!Number.isFinite(intervalo) || intervalo < 0 || intervalo > 120)) erros.intervalo = 'Use um intervalo entre 0 e 120 segundos.';
    const tentativas = Number(dados.maxTentativas);
    if (dados.maxTentativas !== undefined && (!Number.isInteger(tentativas) || tentativas < 1 || tentativas > 6)) erros.tentativas = 'Use de 1 a 6 tentativas por registro.';
    const limite = Number(dados.limiteEtapaSegundos);
    if (dados.limiteEtapaSegundos !== undefined && (!Number.isFinite(limite) || limite < 30 || limite > 600)) erros.limite = 'Use um limite por etapa entre 30 e 600 segundos.';
    return { ok: Object.keys(erros).length === 0, erros, cert, pasta, lista, intervalo: Number.isFinite(intervalo) ? intervalo : 5, tentativas: Number.isInteger(tentativas) ? tentativas : 3, limite: Number.isFinite(limite) ? limite : 120 };
  }

  async function api(req, res, rota) {
    if (req.method === 'GET' && rota === '/api/estado') {
      const desde = Number(new URL(req.url, 'http://x').searchParams.get('desde') || 0);
      return responder(res, 200, {
        versaoExtensao: C.VERSAO_EXTENSAO,
        config: C.lerConfig(),
        listaSalva: desde === 0 ? C.lerLista() : undefined,
        execucao: controle.estado(),
        logs: registro.linhas.filter((l) => l.seq > desde),
        areaDeTrabalho: Pasta.areaDeTrabalho(),
        perfil,
      });
    }
    if (req.method === 'GET' && rota === '/api/certificados') {
      const atualizar = new URL(req.url, 'http://x').searchParams.get('atualizar') === '1';
      return responder(res, 200, await certificados(atualizar));
    }
    if (req.method === 'GET' && rota === '/api/instalacao') {
      const r = C.verificarInstalacao(perfil);
      return responder(res, 200, { ...r, mensagens: C.mensagensInstalacao(r) });
    }
    if (req.method !== 'POST') return responder(res, 404, { ok: false });
    const dados = await lerCorpo(req).catch(() => null);
    if (!dados) return responder(res, 400, { ok: false, erro: 'Pedido inválido.' });

    if (rota === '/api/pasta') {
      const p = Pasta.caminhoDaPasta(dados.nome);
      return responder(res, 200, p.ok ? { ok: true, caminho: p.caminho, existe: p.existe } : { ok: false, erro: p.erro, base: Pasta.areaDeTrabalho() });
    }
    if (rota === '/api/lista') {
      return responder(res, 200, { ok: true, ...Lista.interpretarLista(dados.texto || '') });
    }
    if (rota === '/api/config') {
      const v = await validar(dados, { exigirPasta: false });
      const salvo = C.salvarConfig({
        certificadoId: dados.certificadoId || null, pasta: dados.pasta || '', velocidadeMouse: dados.velocidadeMouse,
        registroLinha: null,
        lista: typeof dados.lista === 'string' ? dados.lista : undefined,
        selecaoNativa: typeof dados.selecaoNativa === 'boolean' ? dados.selecaoNativa : undefined,
        intervaloSegundos: v.intervalo, maxTentativas: v.tentativas, limiteEtapaSegundos: v.limite,
      });
      return responder(res, 200, { ok: true, config: salvo, erros: v.erros });
    }
    if (rota === '/api/iniciar') {
      if (controle.ativa()) return responder(res, 409, { ok: false, erro: 'Já existe uma execução em andamento.' });
      const v = await validar(dados, { exigirPasta: true });
      if (!v.ok) return responder(res, 422, { ok: false, erros: v.erros, erro: 'Corrija os campos indicados.' });
      C.salvarConfig({
        certificadoId: dados.certificadoId || null, pasta: v.pasta.nome, velocidadeMouse: dados.velocidadeMouse,
        registroLinha: null,
        lista: typeof dados.lista === 'string' ? dados.lista : undefined,
        selecaoNativa: typeof dados.selecaoNativa === 'boolean' ? dados.selecaoNativa : undefined,
        intervaloSegundos: v.intervalo, maxTentativas: v.tentativas, limiteEtapaSegundos: v.limite,
      });
      const nativa = !!v.cert && dados.selecaoNativa !== false && process.platform === 'win32';

      const p = Pasta.prepararPasta(v.pasta.nome);
      if (!p.ok) return responder(res, 422, { ok: false, erros: { pasta: p.erro }, erro: p.erro });
      relatorioAtual = registro.adicionarArquivo(Pasta.caminhoSemSobrescrever(p.relatorios, `execucao_${Pasta.carimbo()}.txt`));
      registro.escrever('INICIANDO', `Automacao_Sefaz-PE (extensão ${C.VERSAO_EXTENSAO}) pela interface.`);
      registro.escrever('PASTA', `${p.existia ? 'Usando' : 'Criada'} a pasta de resultados: ${p.caminho}`);
      registro.escrever('CERTIFICADO', v.cert
        ? `Certificado escolhido: ${v.cert.titular} (${v.cert.tipo} ${v.cert.documentoMascarado}, válido até ${v.cert.validoAte}, ${v.cert.emissor}).`
        : 'Sem certificado escolhido: o login no gov.br será manual.');
      registro.escrever('MOUSE', `Velocidade do mouse: ${K.VELOCIDADES[dados.velocidadeMouse]}.`);
      const res_ = v.lista.resumo;
      let lote = null;
      if (res_.validos) {
        registro.escrever('LISTA', `Total de registros: ${res_.validos} válidos (CNPJ ${res_.porTipo.CNPJ}, CPF ${res_.porTipo.CPF}, IE ${res_.porTipo.IE}), ${res_.invalidos} com problema de preenchimento, ${res_.ignoradas} ignorados.`);
        for (const r of v.lista.registros.filter((x) => x.status === 'invalido')) {
          registro.escrever('LISTA', `Linha ${r.linha} inválida (não será processada): ${r.motivo}.`, 'aviso');
        }
        lote = Lote.criarLote({ pasta: p.caminho, registros: v.lista.registros });
        const rt = lote.resumo().retomada;
        if (rt.sucessoMantido || rt.naoEncontradoMantido || rt.erroDeNovo || rt.interrompidoDeNovo || rt.sucessoSemPdf) {
          registro.escrever('LOTE', `Retomada (${Lote.NOME_CONTROLE}): ${rt.sucessoMantido} já concluído(s) com PDF conferido (pulados), ${rt.naoEncontradoMantido} não encontrado(s) (pulados), ${rt.erroDeNovo} com erro e ${rt.interrompidoDeNovo} interrompido(s) serão tentados de novo${rt.sucessoSemPdf ? `, ${rt.sucessoSemPdf} sem o PDF na pasta serão emitidos de novo` : ''}.`);
        }
        registro.escrever('LOTE', `Processamento da lista: ${lote.resumo().pendente} pendente(s), um por vez, com ${v.intervalo} s entre um registro e o seguinte, até ${v.tentativas} tentativa(s) por registro e limite de ${v.limite} s por etapa. PDFs em ${p.caminho}.`);
      } else {
        registro.escrever('LISTA', 'Lista vazia: a execução vai só até a autenticação.');
      }

      const r = controle.iniciar({
        modo: lote ? 'certidao_negativa' : 'acesso',
        origem: 'interface',
        config: {
          velocidadeMouse: dados.velocidadeMouse,
          metodoLogin: v.cert ? 'certificado' : 'manual',
          certificado: Cert.resumoParaExtensao(v.cert),
          pastaResultados: p.caminho,
          selecaoNativa: nativa,
        },
        lote,
        intervaloSegundos: v.intervalo,
        maxTentativas: v.tentativas,
        limiteEtapaSegundos: v.limite,
        // Modo 2: dados do certificado para a janela nativa (ficam no computador).
        nativo: nativa ? { serial: v.cert.serial, titular: v.cert.titular, emissor: v.cert.emissor, documento: v.cert.documento } : null,
      });
      if (!r.ok) {
        registro.escrever('AVISO', r.erro, 'aviso');
        registro.removerArquivo(relatorioAtual);
        relatorioAtual = null;
        return responder(res, 409, { ok: false, erro: r.erro });
      }
      registro.escrever('WINDOWS', nativa
        ? `Seleção do certificado na janela do Chrome: automática (Modo 2, mouse do Windows), pelo número de série ${v.cert.serial.slice(0, 4)}…${v.cert.serial.slice(-4)}.`
        : 'Seleção do certificado na janela do Chrome: manual.');
      return responder(res, 200, { ok: true, pasta: p.caminho, existia: p.existia });
    }
    if (['/api/pausar', '/api/continuar', '/api/parar'].includes(rota)) {
      const r = controle.comando(rota.replace('/api/', ''));
      return responder(res, r.ok ? 200 : 409, r);
    }
    return responder(res, 404, { ok: false });
  }

  const hostsValidos = new Set([`127.0.0.1:${args.porta}`, `localhost:${args.porta}`]);
  const origemPagina = new Set([`http://127.0.0.1:${args.porta}`, `http://localhost:${args.porta}`]);

  const servidor = http.createServer(async (req, res) => {
    try {
      if (!hostsValidos.has(String(req.headers.host || ''))) { res.writeHead(403); res.end(); return; }
      if (controle.tratarPonte(req, res)) return;
      const rota = new URL(req.url, 'http://127.0.0.1').pathname;
      if (rota.startsWith('/api/')) {
        const origem = req.headers.origin;
        if (origem && !origemPagina.has(origem)) return responder(res, 403, { ok: false });
        return await api(req, res, rota);
      }
      // Arquivos da página
      const nome = rota === '/' ? 'index.html' : rota.slice(1);
      const arquivo = path.join(PUBLICO, nome);
      if (!arquivo.startsWith(PUBLICO + path.sep) || !fs.existsSync(arquivo)) { res.writeHead(404); res.end(); return; }
      res.writeHead(200, { 'Content-Type': TIPOS[path.extname(arquivo)] || 'application/octet-stream', 'Cache-Control': 'no-store' });
      fs.createReadStream(arquivo).pipe(res);
    } catch (e) {
      registro.escrever('ERRO', `Erro na interface: ${e.message}`, 'erro');
      if (!res.headersSent) responder(res, 500, { ok: false, erro: e.message });
    }
  });

  servidor.on('error', (e) => {
    registro.escrever('ERRO', e.code === 'EADDRINUSE'
      ? `A porta ${args.porta} já está em uso: a interface (ou a linha de comando) já está aberta. Use a janela que já existe ou feche-a.`
      : `Não foi possível abrir a interface: ${e.message}`, 'erro');
    process.exit(1);
  });

  servidor.listen(args.porta, '127.0.0.1', () => {
    const url = `http://127.0.0.1:${args.porta}/`;
    registro.escrever('INTERFACE', `Interface aberta em ${url} (registro: ${arquivoTerminal}).`);
    registro.escrever('INTERFACE', 'Mantenha esta janela aberta enquanto usar a automação. Para encerrar: Ctrl+C.');
    if (!args.semNavegador) {
      const exe = C.caminhoChrome(args.chrome);
      if (exe) C.abrirJanelaApp(exe, perfil, url, () => registro.escrever('AVISO', `Abra no navegador: ${url}`, 'aviso'));
      else registro.escrever('AVISO', `Abra no navegador: ${url}`, 'aviso');
    }
  });

  process.on('SIGINT', () => {
    registro.escrever('FIM', 'Interface encerrada. O navegador continua aberto.');
    servidor.close();
    setTimeout(() => process.exit(0), 200);
  });
}

if (require.main === module) main();
module.exports = { lerArgumentos };
