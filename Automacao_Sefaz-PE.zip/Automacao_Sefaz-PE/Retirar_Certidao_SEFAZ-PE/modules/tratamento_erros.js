// Classificação de falhas e tentativas limitadas com intervalo progressivo.
//
// Cada falha recebe um código. O código diz se vale tentar de novo (recuperavel) e se, depois
// de esgotadas as tentativas da etapa, vale recarregar a página (recarregar). Recarga é a
// última opção e tem limite por execução (CONFIG.RECUPERACAO.maxRecargas).

(function (raiz) {
  'use strict';

  const S = raiz.SEFAZPE;
  const { CONFIG, util } = S;
  const R = CONFIG.RECUPERACAO;

  const CODIGOS = Object.freeze({
    PORTAL_INCORRETO: { recuperavel: false, recarregar: false, texto: 'A aba não é o Portal de Atendimento da SEFAZ-PE.' },
    PAGINA_SEM_RESPOSTA: { recuperavel: true, recarregar: true, texto: 'A página não respondeu dentro do tempo limite.' },
    ELEMENTO_NAO_CARREGADO: { recuperavel: true, recarregar: true, texto: 'O elemento ainda não foi carregado.' },
    ELEMENTO_NAO_ENCONTRADO: { recuperavel: true, recarregar: true, texto: 'O elemento não foi encontrado na página.' },
    ELEMENTO_INVISIVEL: { recuperavel: true, recarregar: false, texto: 'O elemento existe, mas não está visível ou está coberto.' },
    CLIQUE_SEM_RESULTADO: { recuperavel: true, recarregar: true, texto: 'O clique não produziu mudança na página.' },
    CLIQUE_DUPLICADO: { recuperavel: false, recarregar: false, texto: 'Clique repetido bloqueado para evitar ação em duplicidade.' },
    SESSAO_EXPIRADA: { recuperavel: false, recarregar: false, texto: 'A sessão do portal parece ter expirado.' },
    ERRO_COMUNICACAO: { recuperavel: true, recarregar: false, texto: 'Falha de comunicação entre as partes da extensão.' },
    REDIRECIONAMENTO_INESPERADO: { recuperavel: false, recarregar: false, texto: 'A página foi para um endereço inesperado.' },
    LAYOUT_ALTERADO: { recuperavel: false, recarregar: false, texto: 'A estrutura da página está diferente do esperado.' },
    AMBIGUIDADE: { recuperavel: false, recarregar: false, texto: 'Mais de um elemento corresponde ao alvo; não é seguro clicar.' },
    LOGIN_INDETERMINADO: { recuperavel: false, recarregar: false, texto: 'Não foi possível confirmar se há login no portal.' },
    TEMPO_LOGIN_ESGOTADO: { recuperavel: false, recarregar: false, texto: 'O login não foi concluído dentro do tempo de espera.' },
    PRIMEIRO_ACESSO: { recuperavel: false, recarregar: false, texto: 'O portal pediu a confirmação de primeiro acesso.' },
    BLOCO_NAO_ENCONTRADO: { recuperavel: true, recarregar: false, texto: 'O bloco procurado não foi encontrado na página.' },
    REGISTRO_AUSENTE: { recuperavel: false, recarregar: false, texto: 'Nenhum registro da lista foi escolhido para a consulta. Escolha um na interface e inicie de novo.' },
    TIPO_NAO_SELECIONADO: { recuperavel: true, recarregar: false, texto: 'A opção de tipo de documento não ficou marcada.' },
    CAMPO_NAO_PREENCHIDO: { recuperavel: true, recarregar: false, texto: 'O campo de pesquisa não ficou com o valor esperado.' },
    LOGIN_NAO_CONCLUIDO: { recuperavel: false, recarregar: false, texto: 'Falha de sessão: o login pelo gov.br não foi concluído.' },
    AUTORIZACAO_SEM_RESULTADO: { recuperavel: false, recarregar: false, texto: 'O clique em "Autorizar" não avançou a autenticação.' },
    AUTORIZACAO_OUTRO_SERVICO: { recuperavel: false, recarregar: false, texto: 'A tela de autorização do gov.br é de outro serviço (não é "e-Fisco - Sefaz PE"); a automação não autoriza.' },
    // Emissão e salvamento (0.5.0). Nenhum deles recarrega a página nem repete cliques: a
    // emissão e a impressão são ações que não se repetem sem saber o resultado da anterior.
    RESULTADO_NAO_ENCONTRADO: { recuperavel: false, recarregar: false, texto: 'A pesquisa não retornou registro para o identificador consultado; nada foi emitido.' },
    RESULTADO_DIVERGENTE: { recuperavel: false, recarregar: false, texto: 'A pesquisa retornou registro(s) diferente(s) do identificador consultado; nada foi emitido.' },
    BOTAO_EMITIR_AUSENTE: { recuperavel: false, recarregar: false, texto: 'O botão "Emitir Certidão" não está disponível na tela.' },
    ERRO_EMISSAO: { recuperavel: false, recarregar: false, texto: 'O site informou um erro na emissão da certidão.' },
    EMISSAO_SEM_CONFIRMACAO: { recuperavel: false, recarregar: false, texto: 'A confirmação "Certidão emitida com sucesso!" não apareceu; a emissão NÃO será repetida automaticamente.' },
    BOTAO_VISUALIZAR_AUSENTE: { recuperavel: false, recarregar: false, texto: 'O botão "Visualizar Certidão" não foi encontrado na confirmação.' },
    ARQUIVO_NAO_RECEBIDO: { recuperavel: false, recarregar: false, texto: 'O clique em "Visualizar Certidão" não produziu um documento que a automação pudesse salvar em PDF.' },
    ARQUIVO_NAO_SALVO: { recuperavel: false, recarregar: false, texto: 'O PDF foi recebido, mas não foi salvo na pasta de resultados.' },
    ETAPA_DEMORADA: { recuperavel: false, recarregar: false, texto: 'A etapa passou do tempo limite sem concluir.' },
    DESCONHECIDO: { recuperavel: true, recarregar: false, texto: 'Erro inesperado.' },
  });

  class ErroAutomacao extends Error {
    constructor(codigo, detalhe) {
      const def = CODIGOS[codigo] || CODIGOS.DESCONHECIDO;
      super(detalhe || def.texto);
      this.name = 'ErroAutomacao';
      this.codigo = CODIGOS[codigo] ? codigo : 'DESCONHECIDO';
      this.recuperavel = def.recuperavel;
      this.recarregar = def.recarregar;
      this.textoPadrao = def.texto;
    }
  }

  // Pausa/parada pedida pelo usuário, outra execução assumiu, ou extensão recarregada.
  // Não é falha: o fluxo apenas termina em silêncio.
  class ExecucaoInterrompida extends Error {
    constructor(motivo) {
      super(motivo || 'Execução interrompida.');
      this.name = 'ExecucaoInterrompida';
    }
  }

  function normalizarErro(e) {
    if (e instanceof ErroAutomacao || e instanceof ExecucaoInterrompida) return e;
    const msg = (e && e.message) || String(e);
    if (/Extension context invalidated|Receiving end does not exist|message port closed/i.test(msg)) {
      return new ErroAutomacao('ERRO_COMUNICACAO', msg);
    }
    return new ErroAutomacao('DESCONHECIDO', msg);
  }

  // Executa fn até dar certo, no máximo `max` vezes, com espera progressiva (1,2s, 2,4s,
  // 4,8s..., com variação de ±15%). Erros não recuperáveis e interrupções passam direto.
  async function comTentativas(nome, fn, { ctrl, max = R.tentativasPorEtapa } = {}) {
    let ultimo = null;
    for (let tentativa = 1; tentativa <= max; tentativa++) {
      await ctrl.checkpoint();
      try {
        return await fn(tentativa);
      } catch (e) {
        if (e instanceof ExecucaoInterrompida) throw e;
        const erro = normalizarErro(e);
        ultimo = erro;
        if (!erro.recuperavel || tentativa === max) break;
        const espera = Math.min(R.esperaMax, R.esperaBase * Math.pow(2, tentativa - 1)) * util.aleatorio(0.85, 1.15);
        await ctrl.registrarRecuperacao(nome, erro, tentativa, espera);
        await ctrl.esperar(espera);
      }
    }
    throw ultimo;
  }

  Object.assign(S, { ErroAutomacao, ExecucaoInterrompida });
  S.Erros = { CODIGOS, ErroAutomacao, ExecucaoInterrompida, normalizarErro, comTentativas };
})(globalThis);
