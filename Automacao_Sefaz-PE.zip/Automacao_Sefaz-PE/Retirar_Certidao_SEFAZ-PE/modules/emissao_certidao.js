// Emissão da Certidão Negativa: resultado da pesquisa, "Emitir Certidão (N)", confirmação
// "Certidão emitida com sucesso!", "Imprimir Certidão" e o recebimento do PDF.
//
// Estrutura REAL (tela logada, 18/11/2026, lida pela acessibilidade do Chrome):
//   table.tabela-arredondada — cabeçalho CPF/CNPJ | Inscrição Estadual | Nome/Razão Social
//   button "Emitir Certidão (1)"  (o número muda: o texto é conferido por padrão, não literal)
//   "Certidão emitida com sucesso!" + button#avancarBtn "Imprimir Certidão"
//                                   + button#idFecharModal "Visualizar Certidão" (nunca clicado)
//
// S.Captura: ponte entre o script do mundo da página (captura_pagina.js) e o background.

(function (raiz) {
  'use strict';

  const S = raiz.SEFAZPE;
  const { CONFIG, util } = S;
  const E = CONFIG.EMISSAO;
  const D = S.Detector;
  const norm = util.normalizar;

  const textoDe = (el) => String((el && (el.innerText || el.textContent || el.value)) || '').replace(/\s+/g, ' ').trim();
  const limpo = (s) => String(s || '').toUpperCase().replace(/[^0-9A-Z*]/g, '');
  const semZeros = (s) => s.replace(/^0+/, '');
  const foraDoPainel = (el) => !el.closest('#sefazpe-painel');

  // ---- Resultado da pesquisa -----------------------------------------------------------------

  function tabelaResultado() {
    const C = E.colunasResultado;
    for (const t of document.querySelectorAll('table')) {
      if (!D.visivel(t) || !foraDoPainel(t)) continue;
      const linhas = [...t.rows];
      const iCab = linhas.findIndex((tr) => {
        const c = [...tr.cells].map((x) => norm(textoDe(x)));
        return c.some((x) => C.nome.includes(x)) && c.some((x) => C.documento.includes(x));
      });
      if (iCab < 0) continue;
      const cab = [...linhas[iCab].cells].map((x) => norm(textoDe(x)));
      const col = (lista) => cab.findIndex((x) => lista.includes(x));
      const iDoc = col(C.documento);
      const iIe = col(C.ie);
      const iNome = col(C.nome);
      const dados = linhas.slice(iCab + 1)
        .filter((tr) => D.visivel(tr))
        .map((tr) => {
          const txt = [...tr.cells].map(textoDe);
          return { el: tr, documento: txt[iDoc] || '', ie: iIe >= 0 ? (txt[iIe] || '') : '', nome: iNome >= 0 ? (txt[iNome] || '') : '', textos: txt, unica: tr.cells.length === 1 };
        })
        .filter((l) => l.textos.some(Boolean));
      return { tabela: t, cabecalho: cab, linhas: dados };
    }
    return null;
  }

  // Compara o identificador da linha com o pesquisado. Aceita documento mascarado pelo site
  // (***.270.804-**) se todos os dígitos visíveis conferirem e houver ao menos 5 visíveis.
  function confere(valor, reg) {
    const id = limpo(reg.identificador).replace(/\*/g, '');
    const v = limpo(valor);
    if (!v || !id) return { ok: false };
    if (reg.tipo === 'IE') return { ok: v === id || semZeros(v) === semZeros(id) };
    if (v === id) return { ok: true };
    if (v.includes('*') && v.length === id.length) {
      let visiveis = 0;
      for (let i = 0; i < v.length; i++) {
        if (v[i] === '*') continue;
        if (v[i] !== id[i]) return { ok: false };
        visiveis++;
      }
      return { ok: visiveis >= 5, mascarado: true };
    }
    return { ok: false };
  }

  // Mensagem de "nenhum registro" na tela (aviso, linha única da tabela ou texto da página).
  function mensagemSemResultado(tab) {
    const contem = (t) => E.textosSemResultado.some((m) => norm(t).includes(m));
    if (tab && tab.linhas.length && tab.linhas.every((l) => l.unica || !l.documento)) {
      const t = tab.linhas.map((l) => l.textos.join(' ')).join(' ');
      if (contem(t)) return t.slice(0, 200);
    }
    const avisos = [...document.querySelectorAll('.modal, [role="dialog"], [role="alert"], .alert, [class*="toast"], [class*="swal"], [class*="notification"], [class*="mensagem"]')]
      .filter((el) => D.visivel(el) && foraDoPainel(el));
    for (const a of avisos) { const t = textoDe(a); if (contem(t)) return t.slice(0, 200); }
    return null;
  }

  // situacao: encontrado | nao_encontrado | divergente | sem_tabela
  function analisar(reg) {
    const tab = tabelaResultado();
    const semResultado = mensagemSemResultado(tab);
    if (!tab || !tab.linhas.length || tab.linhas.every((l) => l.unica)) {
      if (semResultado) return { situacao: 'nao_encontrado', mensagem: semResultado, linhas: 0 };
      if (tab && !tab.linhas.length) return { situacao: 'nao_encontrado', mensagem: 'tabela de resultado vazia', linhas: 0 };
      return { situacao: 'sem_tabela', linhas: 0 };
    }
    const campo = reg.tipo === 'IE' ? 'ie' : 'documento';
    const certas = [];
    const outras = [];
    for (const l of tab.linhas) {
      const c = confere(l[campo], reg);
      (c.ok ? certas : outras).push({ documento: l.documento, ie: l.ie, nome: l.nome, mascarado: !!c.mascarado });
    }
    const base = { linhas: tab.linhas.length, correspondentes: certas, divergentes: outras, cabecalho: tab.cabecalho.join(' | ') };
    if (!certas.length) return { ...base, situacao: outras.length ? 'divergente' : 'nao_encontrado', mensagem: semResultado };
    if (outras.length) return { ...base, situacao: 'divergente' };
    return { ...base, situacao: 'encontrado', nomeSite: certas[0].nome, ie: certas[0].ie, documento: certas[0].documento };
  }

  // ---- Botões -----------------------------------------------------------------------------------

  const CLICAVEIS = 'button, [role="button"], a, input[type="button"], input[type="submit"]';

  // "Emitir Certidão" com ou sem "(N)". Precisa ser único na tela.
  function botaoEmitir() {
    const achados = [...document.querySelectorAll(CLICAVEIS)]
      .filter((b) => D.visivel(b) && foraDoPainel(b))
      .map((b) => ({ b, m: norm(textoDe(b)).match(E.textoEmitir) }))
      .filter((x) => x.m)
      // só o mais interno (um <span> dentro do <button> não conta duas vezes)
      .filter((x, _i, todos) => !todos.some((o) => o.b !== x.b && x.b.contains(o.b)));
    if (achados.length !== 1) return { botao: null, total: achados.length };
    const { b, m } = achados[0];
    return { botao: b, quantidade: m[1] ? Number(m[1]) : null, texto: textoDe(b), total: 1, habilitado: D.habilitado(b) };
  }

  // Confirmação "Certidão emitida com sucesso!" visível. Devolve o texto e o contêiner.
  function confirmacao() {
    const cands = [...document.querySelectorAll('body *')]
      // textContent primeiro (barato); innerText e visibilidade só nos poucos candidatos
      .filter((el) => el.childElementCount <= 2 && (el.textContent || '').length <= 160 && norm(el.textContent).includes(E.textoSucesso))
      .filter((el) => foraDoPainel(el) && textoDe(el).length <= 80 && D.visivel(el));
    if (!cands.length) return null;
    const el = cands[cands.length - 1];
    const caixa = el.closest('.modal, [role="dialog"], .modal-content, .modal-dialog') || el.parentElement;
    return { elemento: el, caixa, texto: textoDe(el) };
  }

  // "Imprimir Certidão": pelo id real (#avancarBtn) conferindo o texto, ou pelo texto. Nunca
  // devolve "Visualizar Certidão".
  function botaoImprimir() {
    const ok = (b) => b && D.visivel(b) && foraDoPainel(b) && norm(textoDe(b)) === E.textoImprimir;
    const porId = document.getElementById(E.idImprimir);
    if (ok(porId)) return porId;
    const achados = [...document.querySelectorAll(CLICAVEIS)].filter(ok)
      .filter((b, _i, todos) => !todos.some((o) => o !== b && b.contains(o)));
    return achados.length === 1 ? achados[0] : null;
  }

  // "Visualizar Certidão": pelo id real (#idFecharModal) conferindo o texto, ou pelo texto.
  // Nunca devolve "Imprimir Certidão".
  function botaoVisualizar() {
    const ok = (b) => b && D.visivel(b) && foraDoPainel(b) && norm(textoDe(b)) === E.textoVisualizar;
    const porId = document.getElementById(E.idVisualizar);
    if (ok(porId)) return porId;
    const achados = [...document.querySelectorAll(CLICAVEIS)].filter(ok)
      .filter((b, _i, todos) => !todos.some((o) => o !== b && b.contains(o)));
    return achados.length === 1 ? achados[0] : null;
  }

  // ---- Volta ao formulário sem recarregar (0.6.2) ---------------------------------------------

  const CONTROLE = 'a, button, input, select, textarea, label, [ng-click], [onclick], [role="button"], [role="link"], [tabindex]';

  // Painel sobreposto aberto depois da emissão ("Certidão emitida com sucesso!" com Imprimir /
  // Visualizar / avaliação). Devolve { caixa, ponto: {x, y}, fundo } com um ponto SEGURO fora
  // do painel: dentro da janela, longe da borda do painel, e cujo elemento no ponto é o fundo
  // escurecido do painel (nunca um link, botão ou campo da página). null = sem painel ou sem
  // ponto seguro.
  function pontoForaDoPainel() {
    const c = confirmacao();
    if (!c) return null;
    const caixa = c.elemento.closest('.modal-content, .modal-dialog, [role="dialog"]') || c.caixa;
    const r = caixa.getBoundingClientRect();
    const W = window.innerWidth;
    const H = window.innerHeight;
    const m = 24;
    const candidatos = [
      [r.left / 2, r.top + r.height * 0.35], [(r.right + W) / 2, r.top + r.height * 0.35],
      [r.left / 2, r.top + r.height * 0.7], [(r.right + W) / 2, r.top + r.height * 0.7],
      [r.left + r.width / 2, r.top / 2], [r.left + r.width / 2, (r.bottom + H) / 2],
    ];
    for (const [x, y] of candidatos) {
      if (x < m || y < m || x > W - m || y > H - m) continue;
      if (x > r.left - m && x < r.right + m && y > r.top - m && y < r.bottom + m) continue;
      const hit = document.elementFromPoint(x, y);
      if (!hit || caixa.contains(hit) || hit.closest('#sefazpe-painel')) continue;
      if (hit.closest(CONTROLE) && !hit.matches('.modal, .modal-backdrop, [class*="overlay"], [class*="backdrop"]')) continue;
      // O fundo cobre a janela (é a camada do painel, não o conteúdo da página).
      const f = hit.getBoundingClientRect();
      if (f.width < W * 0.6 || f.height < H * 0.6) continue;
      return { caixa, ponto: { x: Math.round(x), y: Math.round(y) }, fundo: hit };
    }
    return { caixa, ponto: null, fundo: null };
  }

  // O formulário da consulta está livre (nada por cima do campo e do botão Pesquisar)?
  function formularioLivre() {
    const Q = S.Consulta;
    if (!Q.telaCertidaoNegativa().confirmada || confirmacao()) return false;
    const livre = (el) => {
      if (!el || !D.visivel(el)) return false;
      const r = el.getBoundingClientRect();
      const x = r.left + r.width / 2;
      const y = r.top + r.height / 2;
      if (x < 0 || y < 0 || x > window.innerWidth || y > window.innerHeight) return true; // fora da tela: rola depois
      const hit = document.elementFromPoint(x, y);
      return !!hit && (hit === el || el.contains(hit) || hit.contains(el));
    };
    return livre(Q.campoPesquisa()) && livre(Q.botaoPesquisar());
  }

  // Assinatura do conteúdo da tabela de resultado (para não ler a tabela do registro ANTERIOR
  // como se fosse a resposta da nova pesquisa).
  function assinaturaTabela() {
    const t = tabelaResultado();
    return t ? t.linhas.map((l) => l.textos.join('|')).join('||') : null;
  }

  // Documento HTML da certidão (sem PDF): página com o texto "certid" e o identificador.
  function pareceCertidaoHtml(reg) {
    const t = String(document.body ? document.body.innerText : '');
    if (!/certid/i.test(util.normalizar(t))) return false;
    const id = limpo(reg && reg.identificador);
    return !!id && limpo(t).includes(id);
  }

  // Mensagem de erro visível do site (aviso/janela), para registrar o que ele disse.
  function erroNaTela() {
    const avisos = [...document.querySelectorAll('.modal, [role="dialog"], [role="alert"], .alert, [class*="toast"], [class*="swal"], [class*="notification"], .text-danger, .error, [class*="erro"]')]
      .filter((el) => D.visivel(el) && foraDoPainel(el));
    for (const a of avisos) {
      const t = textoDe(a);
      if (!t || norm(t).includes(E.textoSucesso)) continue;
      if (E.textosErro.some((m) => norm(t).includes(m))) return t.slice(0, 240);
    }
    return null;
  }

  // ---- Captura do PDF ---------------------------------------------------------------------------

  function base64DeBytes(buf) {
    const bytes = new Uint8Array(buf);
    let s = '';
    for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
    return btoa(s);
  }

  let armadoAte = 0;
  const vistos = new Set();

  function armar(ms) {
    armadoAte = Date.now() + ms;
    vistos.clear();
    window.dispatchEvent(new CustomEvent('sefazpe:captura-armar', { detail: JSON.stringify({ ms }) }));
  }

  const paraBackground = (msg) => chrome.runtime.sendMessage(msg).catch(() => {});

  // Item vindo do mundo da página.
  window.addEventListener('sefazpe:captura-item', async (ev) => {
    if (Date.now() > armadoAte) return;
    let item;
    try { item = JSON.parse(ev.detail || '{}'); } catch (e) { return; }
    if (item.via === 'evento') {
      paraBackground({ tipo: 'captura:evento', evento: String(item.evento || '').slice(0, 40), url: String(item.urlSegura || '').slice(0, 300) });
      return;
    }
    if (item.erro || item.naoPdf) {
      paraBackground({ tipo: 'captura:evento', evento: item.naoPdf ? `documento que não é PDF (${item.tipo})` : `erro: ${item.erro}`, url: '' });
      return;
    }
    if (item.base64) {
      const chave = `${item.tamanho}:${item.base64.slice(0, 64)}:${item.base64.slice(-64)}`;
      if (vistos.has(chave)) return;
      vistos.add(chave);
      paraBackground({ tipo: 'arquivo:capturado', via: item.via, origem: String(item.origem || '').slice(0, 40), base64: item.base64 });
      return;
    }
    if (item.via === 'url' && item.url) {
      // Endereço do documento: busca aqui, com a sessão desta aba anônima (o background não
      // tem os cookies da janela anônima).
      if (vistos.has(item.url)) return;
      vistos.add(item.url);
      try {
        const r = await fetch(item.url, { credentials: 'include', cache: 'no-store' });
        const buf = await r.arrayBuffer();
        const inicio = String.fromCharCode.apply(null, new Uint8Array(buf.slice(0, 5)));
        if (!r.ok || inicio !== '%PDF-') {
          paraBackground({ tipo: 'captura:evento', evento: `endereço sem PDF (HTTP ${r.status}, ${r.headers.get('content-type') || '?'})`, url: item.urlSegura || '' });
          return;
        }
        paraBackground({ tipo: 'arquivo:capturado', via: 'url', origem: String(item.origem || '').slice(0, 40), base64: base64DeBytes(buf), url: item.urlSegura || '' });
      } catch (e) {
        paraBackground({ tipo: 'captura:evento', evento: `não foi possível buscar o documento (${e.message})`, url: item.urlSegura || '' });
      }
    }
  });

  // O background pede para buscar um endereço (o documento abriu numa aba nova ou no quadro):
  // a busca é feita aqui, com a sessão da janela anônima.
  async function buscarEndereco(url, origem) {
    try {
      const r = await fetch(url, { credentials: 'include', cache: 'no-store' });
      const buf = await r.arrayBuffer();
      const inicio = String.fromCharCode.apply(null, new Uint8Array(buf.slice(0, 5)));
      if (!r.ok || inicio !== '%PDF-') return { ok: false, motivo: `HTTP ${r.status}, ${r.headers.get('content-type') || '?'}` };
      paraBackground({ tipo: 'arquivo:capturado', via: 'url', origem: String(origem || '').slice(0, 40), base64: base64DeBytes(buf), url: String(url).replace(/[?#].*$/, '') });
      return { ok: true };
    } catch (e) {
      return { ok: false, motivo: e.message };
    }
  }

  S.Emissao = { tabelaResultado, analisar, confere, botaoEmitir, confirmacao, botaoImprimir, botaoVisualizar, pareceCertidaoHtml, erroNaTela, mensagemSemResultado, pontoForaDoPainel, formularioLivre, assinaturaTabela };
  S.Captura = { armar, base64DeBytes, buscarEndereco };
})(globalThis);
