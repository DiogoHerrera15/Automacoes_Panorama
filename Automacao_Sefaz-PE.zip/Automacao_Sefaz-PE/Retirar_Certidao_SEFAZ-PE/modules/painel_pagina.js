// Painel flutuante na própria página do portal (canto inferior esquerdo), para acompanhar
// a automação com o portal em primeiro plano (o popup da extensão fecha ao clicar na
// página). Usa Shadow DOM: o CSS do portal não afeta o painel e vice-versa.
// Só aparece quando existe uma execução nesta aba.

(function (raiz) {
  'use strict';

  const S = raiz.SEFAZPE;
  const { CONST } = S;
  const ctrl = S.Controle;
  const ID = 'sefazpe-painel';

  let host = null;
  let raizShadow = null;
  let minimizado = false;

  const CORES = {
    executando: '#1351b4', aguardando_login: '#b46a00', pausado: '#5c6b7a',
    concluido: '#168821', erro: '#c4161c', parado: '#5c6b7a', ocioso: '#5c6b7a',
  };

  const CSS = `
    :host { all: initial; }
    .p { position: fixed; left: 16px; bottom: 16px; z-index: 2147483640; width: 300px; max-width: calc(100vw - 32px);
         font: 13px/1.4 "Segoe UI", system-ui, sans-serif; color: #1b1b1b; background: #fff; border-radius: 10px;
         box-shadow: 0 6px 24px rgba(0,0,0,.22); border-left: 5px solid var(--cor, #1351b4); overflow: hidden; }
    .cab { display: flex; align-items: center; gap: 8px; padding: 8px 10px; background: #f3f6fb; cursor: pointer; }
    .ponto { width: 9px; height: 9px; border-radius: 50%; background: var(--cor); flex: none; }
    .tit { font-weight: 600; flex: 1; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .st { font-size: 12px; color: var(--cor); font-weight: 600; }
    .corpo { padding: 8px 10px 10px; }
    .etapa { font-size: 12px; color: #555; }
    .msg { margin: 4px 0 8px; font-weight: 500; }
    .bts { display: flex; gap: 6px; }
    button { font: 600 12px "Segoe UI", system-ui, sans-serif; border: 1px solid #c5d0de; background: #fff; color: #1b1b1b;
             border-radius: 6px; padding: 4px 10px; cursor: pointer; }
    button:hover:not(:disabled) { background: #eef3fb; }
    button:disabled { opacity: .45; cursor: default; }
    .min .corpo { display: none; }
  `;

  function criar() {
    const antigo = document.getElementById(ID);
    if (antigo && antigo !== host) antigo.remove();
    if (host && host.isConnected) return;
    host = document.createElement('div');
    host.id = ID;
    raizShadow = host.attachShadow({ mode: 'closed' });
    raizShadow.innerHTML = `<style>${CSS}</style>
      <div class="p" part="painel">
        <div class="cab" title="Clique para recolher/expandir">
          <span class="ponto"></span><span class="tit">Retirar Certidão SEFAZ-PE</span><span class="st"></span>
        </div>
        <div class="corpo">
          <div class="etapa"></div>
          <div class="msg"></div>
          <div class="bts">
            <button data-c="pausar">Pausar</button>
            <button data-c="continuar">Continuar</button>
            <button data-c="parar">Parar</button>
          </div>
        </div>
      </div>`;
    raizShadow.querySelector('.cab').addEventListener('click', () => {
      minimizado = !minimizado;
      raizShadow.querySelector('.p').classList.toggle('min', minimizado);
    });
    raizShadow.querySelectorAll('button').forEach((b) => b.addEventListener('click', async () => {
      b.disabled = true;
      try {
        await ctrl.enviarComando(b.dataset.c);
      } catch (e) {
        console.warn('[Retirar_Certidao_SEFAZ-PE] Comando não enviado:', e);
      }
    }));
    (document.body || document.documentElement).appendChild(host);
  }

  function atualizar(estado) {
    try {
      // Só no quadro que está agindo (no portal logado, o quadro interno; não a "casca").
      const daAba = estado.tabId === ctrl.tabId() && estado.execId && estado.status !== 'ocioso' && S.Navegador.devoAtuar();
      if (!daAba) {
        if (host) host.remove();
        host = null;
        return;
      }
      criar();
      const p = raizShadow.querySelector('.p');
      p.style.setProperty('--cor', CORES[estado.status] || CORES.ocioso);
      raizShadow.querySelector('.st').textContent = CONST.STATUS[estado.status] || estado.status;
      const nomeEstado = CONST.ESTADOS_AUTOMACAO[CONST.estadoAutomacao(estado)] || '';
      const reg = estado.registro ? ` · ${CONST.TIPOS_DOCUMENTO[estado.registro.tipo] || estado.registro.tipo} ${estado.registro.mascarado}` : '';
      raizShadow.querySelector('.etapa').textContent = `${nomeEstado ? nomeEstado + ' — ' : ''}${CONST.rotuloEtapa(estado.etapa)}${reg}`;
      raizShadow.querySelector('.msg').textContent = estado.mensagem || '';
      const ativo = ['executando', 'aguardando_login'].includes(estado.status);
      const retomavel = ['pausado', 'erro'].includes(estado.status);
      raizShadow.querySelector('[data-c="pausar"]').disabled = !ativo;
      raizShadow.querySelector('[data-c="continuar"]').disabled = !retomavel;
      raizShadow.querySelector('[data-c="parar"]').disabled = !(ativo || retomavel);
    } catch (e) {
      console.warn('[Retirar_Certidao_SEFAZ-PE] Painel da página falhou:', e);
    }
  }

  ctrl.aoMudarEstado(atualizar);
  S.Painel = { atualizar };
})(globalThis);
