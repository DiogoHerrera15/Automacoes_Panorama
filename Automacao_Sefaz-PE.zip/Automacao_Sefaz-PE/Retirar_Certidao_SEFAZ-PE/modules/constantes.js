// Constantes compartilhadas por TODAS as partes da extensão: background (importScripts),
// popup (<script>) e content scripts (manifest). Sem dependências e sem acesso ao DOM.
//
// Para acrescentar etapas futuras (lista de empresas, formulário, emissão, download),
// inclua-as em ETAPAS na ordem em que acontecem e implemente o "executar" no content.js.

(function (raiz) {
  'use strict';

  const ORIGEM_PORTAL = 'https://atendimento.sefaz.pe.gov.br';
  const URL_INICIAL = ORIGEM_PORTAL + '/lowcode/public/form/frm_psfz_home/default#!/?form=frm_psfz_default';

  // Ordem do fluxo. "rotulo" é o texto mostrado no popup e no painel da página.
  const ETAPAS = Object.freeze([
    { id: 'verificar_portal', rotulo: 'Verificar portal' },
    { id: 'verificar_login', rotulo: 'Verificar autenticação' },
    { id: 'acionar_login_govbr', rotulo: 'Clicar em "Login com gov.br"' },
    { id: 'autenticacao_govbr', rotulo: 'Autenticação no gov.br' },
    { id: 'confirmar_acesso', rotulo: 'Confirmar acesso' },
    { id: 'identificar_tela_sefaz', rotulo: 'Identificar a tela da SEFAZ' },
    { id: 'localizar_acesso_rapido', rotulo: 'Localizar "Acesso Rápido"' },
    { id: 'localizar_certidoes', rotulo: 'Localizar bloco "Certidões"' },
    { id: 'clicar_certidoes', rotulo: 'Acessar "Certidões"' },
    { id: 'aguardar_proxima_tela', rotulo: 'Aguardar a página de Certidões' },
    { id: 'localizar_certidao_negativa', rotulo: 'Localizar "Certidão Negativa"' },
    { id: 'abrir_certidao_negativa', rotulo: 'Abrir a consulta de Certidão Negativa' },
    { id: 'selecionar_tipo_documento', rotulo: 'Selecionar CNPJ / CPF / Inscrição Estadual' },
    { id: 'preencher_identificador', rotulo: 'Preencher e conferir o identificador' },
    { id: 'clicar_pesquisar', rotulo: 'Clicar em "Pesquisar"' },
    { id: 'aguardar_resposta', rotulo: 'Aguardar a resposta da pesquisa' },
    { id: 'analisar_resultado', rotulo: 'Conferir o resultado da pesquisa' },
    { id: 'clicar_emitir', rotulo: 'Clicar em "Emitir Certidão"' },
    { id: 'aguardar_emissao', rotulo: 'Aguardar "Certidão emitida com sucesso!"' },
    { id: 'clicar_visualizar', rotulo: 'Clicar em "Visualizar Certidão"' },
    { id: 'aguardar_arquivo', rotulo: 'Salvar o PDF na pasta' },
    { id: 'concluida', rotulo: 'Etapa concluída' },
  ]);

  // Estados da automação (nomes mostrados na interface, no terminal e no popup). São
  // calculados a partir do status + etapa: ver estadoAutomacao().
  const ESTADOS_AUTOMACAO = Object.freeze({
    INICIANDO: 'Iniciando',
    AGUARDANDO_LOGIN: 'Aguardando login',
    AUTENTICANDO_GOVBR: 'Autenticando no gov.br',
    AGUARDANDO_AUTORIZACAO: 'Aguardando autorização',
    AUTORIZANDO_GOVBR: 'Autorizando no gov.br',
    ACESSANDO_SEFAZ: 'Acessando a SEFAZ',
    LOCALIZANDO_CERTIDAO_NEGATIVA: 'Localizando Certidão Negativa',
    ABRINDO_CONSULTA: 'Abrindo a consulta',
    IDENTIFICANDO_TIPO_DOCUMENTO: 'Identificando o tipo de documento',
    PREENCHENDO_IDENTIFICADOR: 'Preenchendo o identificador',
    VALIDANDO_PREENCHIMENTO: 'Validando o preenchimento',
    CLICANDO_PESQUISAR: 'Clicando em Pesquisar',
    AGUARDANDO_RESPOSTA: 'Aguardando a resposta',
    ANALISANDO_RESULTADO: 'Conferindo o resultado',
    EMITINDO_CERTIDAO: 'Emitindo a certidão',
    AGUARDANDO_EMISSAO: 'Aguardando a confirmação da emissão',
    ABRINDO_DOCUMENTO: 'Abrindo o documento da certidão',
    SALVANDO_ARQUIVO: 'Salvando o PDF',
    ETAPA_CONCLUIDA: 'Etapa concluída',
    ERRO_RECUPERAVEL: 'Erro recuperável (tentando de novo)',
    AGUARDANDO_INTERVENCAO: 'Aguardando intervenção',
    PAUSADA: 'Pausada',
  });

  const ESTADO_POR_ETAPA = Object.freeze({
    verificar_portal: 'INICIANDO', verificar_login: 'INICIANDO', acionar_login_govbr: 'AUTENTICANDO_GOVBR',
    autenticacao_govbr: 'AUTENTICANDO_GOVBR', confirmar_acesso: 'ACESSANDO_SEFAZ', identificar_tela_sefaz: 'ACESSANDO_SEFAZ',
    localizar_acesso_rapido: 'ACESSANDO_SEFAZ', localizar_certidoes: 'ACESSANDO_SEFAZ', clicar_certidoes: 'ACESSANDO_SEFAZ',
    aguardar_proxima_tela: 'ACESSANDO_SEFAZ', localizar_certidao_negativa: 'LOCALIZANDO_CERTIDAO_NEGATIVA',
    abrir_certidao_negativa: 'ABRINDO_CONSULTA', selecionar_tipo_documento: 'IDENTIFICANDO_TIPO_DOCUMENTO',
    preencher_identificador: 'PREENCHENDO_IDENTIFICADOR', clicar_pesquisar: 'CLICANDO_PESQUISAR',
    aguardar_resposta: 'AGUARDANDO_RESPOSTA', analisar_resultado: 'ANALISANDO_RESULTADO',
    clicar_emitir: 'EMITINDO_CERTIDAO', aguardar_emissao: 'AGUARDANDO_EMISSAO',
    clicar_visualizar: 'ABRINDO_DOCUMENTO', aguardar_arquivo: 'SALVANDO_ARQUIVO', concluida: 'ETAPA_CONCLUIDA',
  });

  // Nome do estado atual a partir do estado salvo. "subestado" (gravado pela etapa) refina o
  // padrão da etapa, por exemplo VALIDANDO_PREENCHIMENTO dentro de preencher_identificador.
  function estadoAutomacao(e) {
    if (!e || !e.execId || e.status === 'ocioso') return null;
    if (e.status === 'concluido') return 'ETAPA_CONCLUIDA';
    if (e.status === 'pausado') return 'PAUSADA';
    if (e.status === 'erro' || e.status === 'parado') return 'AGUARDANDO_INTERVENCAO';
    if (e.recuperando) return 'ERRO_RECUPERAVEL';
    if (e.etapa === 'autenticacao_govbr' && e.paginaAutenticacao === 'autorizacao') {
      return e.status === 'aguardando_login' ? 'AGUARDANDO_AUTORIZACAO' : 'AUTORIZANDO_GOVBR';
    }
    if (e.status === 'aguardando_login') return 'AGUARDANDO_LOGIN';
    if (e.subestado && ESTADOS_AUTOMACAO[e.subestado]) return e.subestado;
    return ESTADO_POR_ETAPA[e.etapa] || 'INICIANDO';
  }

  // Tipos de documento da consulta (mesmos códigos da lista: nucleo/lista.js).
  const TIPOS_DOCUMENTO = Object.freeze({ CNPJ: 'CNPJ', CPF: 'CPF', IE: 'Inscrição Estadual' });

  const STATUS = Object.freeze({
    ocioso: 'Parada',
    executando: 'Em execução',
    aguardando_login: 'Aguardando login',
    pausado: 'Pausada',
    concluido: 'Concluída',
    erro: 'Pausada por erro',
    parado: 'Interrompida',
  });

  // Status em que existe uma execução "viva" (que pode ser pausada ou parada).
  const STATUS_ATIVOS = Object.freeze(['executando', 'aguardando_login', 'pausado', 'erro']);

  const CHAVES = Object.freeze({
    estado: 'sefazpe_estado',
    logs: 'sefazpe_logs',
    preferencias: 'sefazpe_preferencias', // escolhas do popup (velocidade, login por certificado)
  });

  const VELOCIDADES = Object.freeze({ lento: 'Lento', normal: 'Normal', rapido: 'Rápido' });

  // Como entrar no gov.br:
  //   certificado → a automação clica em "Seu certificado digital" e você escolhe o certificado
  //                 indicado na janela do Chrome (e digita o PIN, se pedir)
  //   manual      → a automação espera você fazer todo o login
  const METODOS_LOGIN = Object.freeze({ certificado: 'Certificado digital', manual: 'Manual' });

  const MAX_LOGS = 500;

  // Modos de execução:
  //   acesso            → para depois de confirmar o login
  //   certidoes         → segue até a página de Certidões (popup)
  //   certidao_negativa → Certidões > Certidão Negativa > tipo > identificador > Pesquisar >
  //                       conferir resultado > Emitir Certidão > Imprimir Certidão > PDF salvo
  //                       na pasta (interface, com UM registro da lista)
  const MODOS = Object.freeze({
    acesso: 'Acesso e autenticação',
    certidoes: 'Acesso até Certidões',
    certidao_negativa: 'Certidão Negativa: pesquisa, emissão e PDF',
  });

  // Ponte com o iniciador do terminal (Automacao_Sefaz-PE/iniciar.js). Só 127.0.0.1.
  const TERMINAL = Object.freeze({
    porta: 47831,
    url: 'http://127.0.0.1:47831',
  });

  function estadoInicial() {
    return {
      versao: 1,
      execId: null,
      tabId: null,
      modo: 'certidoes',
      origem: 'popup', // popup | terminal | interface
      tokenTerminal: null,
      velocidadeMouse: 'lento',
      metodoLogin: 'manual',
      // Resumo do certificado escolhido na interface (nunca a chave): { titular, tipo,
      // documentoMascarado, validade, emissor, impressaoCurta }.
      certificado: null,
      pastaResultados: null,
      certificadoCliques: 0,
      certificadoEm: null,
      usuarioLogado: null,
      cursor: null,
      loginAcionamentos: 0,
      loginAcionadoEm: null,
      autorizacaoCliques: 0,
      autorizacaoEm: null,
      paginaAutenticacao: null,
      // Registro da lista em consulta: { linha, tipo: CNPJ|CPF|IE, identificador (só dígitos,
      // ou letras+dígitos no CNPJ alfanumérico), formatado, mascarado, nome }.
      registro: null,
      // Lista inteira: { total, posicao, intervaloMs, fim? }. O registro atual fica em "registro".
      lote: null,
      trocandoRegistro: false, // acabou de passar para o próximo registro (página recarregada)
      errosSeguidos: 0,        // registros seguidos com erro (3 = provável problema geral → pausa)
      retomarEm: null,         // etapa onde retomar depois de uma recuperação (ex.: verificar_login)
      telaSefaz: null,
      negativaClicada: false,
      negativaCliques: 0,
      tipoSelecionado: null,
      identificadorConferido: false,
      pesquisaEnviada: false,
      pesquisaEm: null,
      // Emissão: { linhas, correspondentes, nomeSite, ie, quantidadeBotao } da tabela conferida.
      resultado: null,
      // Ações que NUNCA se repetem automaticamente (gravadas imediatamente antes do clique).
      emissaoSolicitada: false,
      emissaoEm: null,
      emissaoConfirmada: false,
      visualizarClicado: false,
      visualizarEm: null,
      // Captura do PDF depois do clique em Imprimir (até este instante) e o resultado.
      capturaAte: null,
      capturaVias: [],
      arquivo: null, // { caminho, arquivo, bytes } quando o PDF foi salvo e conferido
      arquivoErro: null,
      subestado: null,
      recuperando: false,
      erroCodigo: null,
      retomadasAutomaticas: 0,
      status: 'ocioso',
      etapa: null,
      mensagem: 'Pronta para iniciar.',
      statusPagina: '—',
      statusLogin: '—',
      elementoProcurado: '—',
      ultimaAcao: '—',
      tentativasRecuperacao: 0,
      recargas: 0,
      cliqueRealizado: false,
      cliquesFeitos: 0,
      cliqueEm: null,
      instantaneoAntes: null,
      erro: null,
      aguardandoConfirmacaoLogin: false,
      loginConfirmadoManual: false,
      recuperacoesUsadas: {},
      statusAntesPausa: null,
      iniciadoEm: null,
      atualizadoEm: null,
    };
  }

  function rotuloEtapa(id) {
    const e = ETAPAS.find((x) => x.id === id);
    return e ? e.rotulo : '—';
  }

  function indiceEtapa(id) {
    return ETAPAS.findIndex((x) => x.id === id);
  }

  function urlDoPortal(url) {
    try {
      return new URL(url).origin === ORIGEM_PORTAL;
    } catch (e) {
      return false;
    }
  }

  raiz.SEFAZPE_CONST = Object.freeze({
    ORIGEM_PORTAL, URL_INICIAL, ETAPAS, STATUS, STATUS_ATIVOS, CHAVES, MAX_LOGS, MODOS, TERMINAL,
    VELOCIDADES, METODOS_LOGIN, ESTADOS_AUTOMACAO, TIPOS_DOCUMENTO,
    estadoInicial, rotuloEtapa, indiceEtapa, urlDoPortal, estadoAutomacao,
  });
})(globalThis);
