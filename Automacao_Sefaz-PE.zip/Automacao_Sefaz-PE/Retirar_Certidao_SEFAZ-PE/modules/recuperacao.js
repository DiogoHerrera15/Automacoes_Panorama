// Recuperação de falhas de UM registro da lista (0.6.1). Função pura: recebe o estado salvo,
// o erro e o que está na tela agora; devolve a ação. Testada em tests/recuperacao.test.js.
//
// Escada de tentativas por registro (máximo configurável, padrão 3):
//   1ª falha → confere o estado e tenta de novo SEM recarregar (a partir da etapa segura)
//   2ª falha → recarrega a página (F5 do quadro do portal) e refaz o MESMO registro
//   3ª falha → última tentativa, também com recarga
//   esgotou  → registra o erro e passa para o próximo registro
//
// O que NUNCA se repete às cegas:
//   - PDF já salvo para este registro → conclui como sucesso, sem repetir nada;
//   - emissão pedida e SEM confirmação → não pede outra (não dá para saber se o servidor
//     processou); só espera/confere de novo; esgotou → erro "confira no portal";
//   - emissão CONFIRMADA e PDF não salvo → primeiro tenta recuperar o documento
//     ("Visualizar Certidão" de novo, se a confirmação ainda estiver na tela); só se não der,
//     uma única nova emissão (a anterior comprovadamente terminou);
//   - pesquisa: é uma consulta (não gera nada); depois de uma recarga é refeita, porque a
//     resposta anterior some com a página.
// Nunca recarrega em páginas de login/certificado/PIN/CAPTCHA/autorização (essas não chegam
// aqui) nem com download em andamento.

(function (raiz) {
  'use strict';

  const S = raiz.SEFAZPE || (raiz.SEFAZPE = {});

  // Erros que não são de um registro: pausam a lista (login, autorização, comunicação...).
  const ERROS_GERAIS = Object.freeze(['LOGIN_INDETERMINADO', 'TEMPO_LOGIN_ESGOTADO', 'LOGIN_NAO_CONCLUIDO', 'AUTORIZACAO_SEM_RESULTADO', 'AUTORIZACAO_OUTRO_SERVICO', 'PORTAL_INCORRETO', 'ERRO_COMUNICACAO', 'PRIMEIRO_ACESSO', 'REGISTRO_AUSENTE', 'CLIQUE_DUPLICADO', 'REDIRECIONAMENTO_INESPERADO']);
  // Erros que são o RESULTADO do registro (não adianta tentar de novo).
  const DEFINITIVOS = Object.freeze(['RESULTADO_DIVERGENTE']);

  // Campos zerados para refazer o registro desde a pesquisa (depois de uma recarga).
  const REFAZER_PESQUISA = Object.freeze({ pesquisaEnviada: false, pesquisaEm: null, resultado: null, tipoSelecionado: null, identificadorConferido: false, negativaClicada: false, negativaCliques: 0, cliqueRealizado: false, cliquesFeitos: 0, instantaneoAntes: null, recargas: 0, recuperacoesUsadas: {} });
  const REFAZER_EMISSAO = Object.freeze({ ...REFAZER_PESQUISA, emissaoSolicitada: false, emissaoEm: null, emissaoConfirmada: false, visualizarClicado: false, visualizarEm: null, visualizarCliques: 0, capturaId: null, capturaAte: null, arquivoErro: null });

  // est: estado salvo; erro: { codigo, message }; tela: { confirmacaoVisivel, carregando }
  // opcoes: { maxTentativas }
  // Devolve { acao, parcial?, recarregar?, descricao }
  //   acao: 'sucesso' | 'pausar' | 'relogar' | 'repetir' | 'proximo'
  function decidir(est, erro, tela = {}, { maxTentativas = 3 } = {}) {
    const codigo = erro && erro.codigo;
    const t = Math.max(1, Number(est.tentativaRegistro) || 1);
    const max = Math.min(Math.max(Number(maxTentativas) || 3, 1), 6);
    const proxTentativa = { tentativaRegistro: t + 1 };

    if (est.arquivo && est.arquivo.caminho) {
      return { acao: 'sucesso', descricao: 'O PDF deste registro já está salvo e conferido; nada é repetido.' };
    }
    if (ERROS_GERAIS.includes(codigo)) return { acao: 'pausar', descricao: 'Erro geral (não é deste registro): a lista pausa até você resolver.' };
    if (codigo === 'SESSAO_EXPIRADA' && !est.emissaoSolicitada) {
      return { acao: 'relogar', parcial: { ...REFAZER_PESQUISA, retomarEm: 'verificar_login' }, descricao: 'Sessão expirada antes da emissão: novo login e o mesmo registro continua.' };
    }
    if (DEFINITIVOS.includes(codigo)) return { acao: 'proximo', descricao: 'Resultado da pesquisa diferente do identificador: nada é emitido; segue para o próximo.' };
    if (t >= max) return { acao: 'proximo', descricao: `Tentativas esgotadas (${t}/${max}): o erro é registrado e a lista segue.` };

    // Emissão confirmada, PDF não salvo: recuperar o documento antes de emitir de novo.
    if (est.emissaoConfirmada) {
      if (tela.confirmacaoVisivel && (est.visualizarCliques || 0) < 2) {
        return { acao: 'repetir', parcial: { ...proxTentativa, visualizarClicado: false, capturaId: null, capturaAte: null, arquivoErro: null }, descricao: 'A certidão foi emitida: abrindo o documento de novo ("Visualizar Certidão"), sem nova emissão.' };
      }
      if ((est.reemissoes || 0) < 1) {
        return { acao: 'repetir', recarregar: true, parcial: { ...proxTentativa, ...REFAZER_EMISSAO, reemissoes: (est.reemissoes || 0) + 1 }, descricao: 'A certidão foi emitida, mas o documento não pôde ser recuperado: recarregando e emitindo UMA nova vez (a anterior comprovadamente terminou).' };
      }
      return { acao: 'proximo', descricao: 'O documento não pôde ser recuperado nem com uma nova emissão: o erro é registrado.' };
    }
    // Emissão pedida e sem confirmação: não pede outra; só confere de novo.
    if (est.emissaoSolicitada) {
      if (t === 1) return { acao: 'repetir', parcial: { ...proxTentativa }, descricao: 'Emissão pedida sem confirmação: conferindo de novo a resposta (a emissão NÃO é repetida).' };
      return { acao: 'proximo', descricao: 'A emissão foi pedida e a confirmação não apareceu: não é seguro pedir outra; confira este registro no portal.' };
    }
    // Antes da emissão: 1ª falha sem recarga; depois, com recarga (refaz a pesquisa).
    if (t === 1) return { acao: 'repetir', parcial: { ...proxTentativa }, descricao: 'Conferindo o estado da página e repetindo a etapa (sem recarregar).' };
    return { acao: 'repetir', recarregar: true, parcial: { ...proxTentativa, ...REFAZER_PESQUISA }, descricao: `Recarregando a página e refazendo este registro (tentativa ${t + 1}/${max}).` };
  }

  // Limite de tempo por etapa (ms). null = sem limite aqui (a etapa tem espera própria ou
  // depende de você: login, certificado, PIN, CAPTCHA, autorização, documento em download).
  const SEM_LIMITE = ['autenticacao_govbr', 'acionar_login_govbr', 'aguardar_emissao', 'aguardar_arquivo'];
  function limiteDaEtapa(etapa, padraoMs) {
    if (SEM_LIMITE.includes(etapa)) return null;
    return Math.max(Number(padraoMs) || 120000, 30000);
  }

  S.Recuperacao = { decidir, limiteDaEtapa, ERROS_GERAIS, REFAZER_PESQUISA, REFAZER_EMISSAO };
})(globalThis);
