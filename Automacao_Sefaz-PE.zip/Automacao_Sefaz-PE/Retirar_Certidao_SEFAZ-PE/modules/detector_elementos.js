// Localização e validação de elementos REAIS do DOM (texto normalizado, hierarquia,
// atributos, visibilidade). Nenhuma coordenada fixa. Não clica e não rola.

(function (raiz) {
  'use strict';

  const S = raiz.SEFAZPE;
  const { CONFIG, util } = S;
  const SEL = CONFIG.SELETORES;
  const TX = CONFIG.TEXTOS;

  // Opacidade NÃO entra na conta: os avisos do portal (Bootstrap "modal fade") começam com
  // opacidade 0 durante a animação de entrada e precisam ser detectados já nesse momento.
  function visivel(el) {
    if (!el || !el.isConnected || el.nodeType !== 1) return false;
    if (el.closest('.ng-hide')) return false;
    if (typeof el.checkVisibility === 'function') {
      if (!el.checkVisibility({ checkVisibilityCSS: true })) return false;
    } else {
      const st = getComputedStyle(el);
      if (st.display === 'none' || st.visibility === 'hidden') return false;
    }
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0;
  }

  function habilitado(el) {
    if (!el) return false;
    if (el.disabled || el.closest('[disabled], [aria-disabled="true"]')) return false;
    return getComputedStyle(el).pointerEvents !== 'none';
  }

  // Elemento inteiro (ou a parte indicada) dentro da área visível da janela.
  function naTela(el, margem = 0) {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    return r.top >= -margem && r.left >= -margem && r.bottom <= window.innerHeight + margem && r.right <= window.innerWidth + margem;
  }

  function textoNormalizado(el) {
    return util.normalizar(el ? el.textContent : '');
  }

  function carregando() {
    return [...document.querySelectorAll(SEL.carregando)].some(visivel);
  }

  // DOM pronto, sem "carregando" na tela e com conteúdo do portal montado. Aceita qualquer
  // um destes sinais, porque a página logada (/portalsefaz/...?headless) pode ter estrutura
  // diferente da pública: formulário "[id$=Page]", cabeçalho do portal ou blocos.
  function sinaisDePagina() {
    return {
      formulario: [...document.querySelectorAll(SEL.paginaForm)].some(visivel),
      cabecalho: [...document.querySelectorAll(SEL.cabecalho)].some(visivel),
      blocos: [...document.querySelectorAll(SEL.card)].some(visivel),
      carregando: carregando(),
      readyState: document.readyState,
    };
  }

  function paginaPronta() {
    const s = sinaisDePagina();
    if (s.readyState === 'loading' || s.carregando) return false;
    return s.formulario || s.cabecalho || s.blocos;
  }

  // Repete "teste" até devolver algo verdadeiro ou estourar o limite (respeita pausa).
  async function esperar(teste, { limite, intervalo = CONFIG.TEMPOS.intervalo, ctrl } = {}) {
    const fim = Date.now() + limite;
    for (;;) {
      if (ctrl) await ctrl.checkpoint();
      try {
        const r = teste();
        if (r) return r;
      } catch (e) {
        console.warn(CONFIG.PREFIXO_LOG, 'Erro durante a espera (segue tentando):', e);
      }
      if (Date.now() >= fim) return null;
      await util.dormir(intervalo);
    }
  }

  // Espera o DOM ficar "quieto" (nenhum elemento entrando/saindo por `quieto` ms) e sem
  // indicador de carregamento. Só conta inclusão/remoção de elementos: mudanças de texto e
  // de atributo (relógios, contadores de sessão, animações, nosso próprio cursor e painel)
  // não significam que a página ainda está montando.
  async function esperarEstabilidade({ quieto = CONFIG.TEMPOS.estabilidadeDom, limite = CONFIG.TEMPOS.limiteEstabilidade, ctrl, alvo } = {}) {
    let ultima = Date.now();
    const nossos = /^sefazpe-/;
    const obs = new MutationObserver((lista) => {
      const relevante = lista.some((m) => [...m.addedNodes, ...m.removedNodes].some((n) => n.nodeType === 1 && !nossos.test(n.id || '')));
      if (relevante) ultima = Date.now();
    });
    obs.observe(alvo || document.body || document.documentElement, { childList: true, subtree: true });
    const fim = Date.now() + limite;
    try {
      for (;;) {
        if (ctrl) await ctrl.checkpoint();
        if (Date.now() - ultima >= quieto && !carregando()) return true;
        if (Date.now() >= fim) return false;
        await util.dormir(100);
      }
    } finally {
      obs.disconnect();
    }
  }

  // Remove candidatos que estão dentro de outro candidato (fica o mais externo).
  function maisExternos(lista) {
    return lista.filter((el) => !lista.some((outro) => outro !== el && outro.contains(el)));
  }

  // ---- Seção "Acesso Rápido" -------------------------------------------------------------

  function localizarTituloAcessoRapido() {
    let candidatos = [...document.querySelectorAll(SEL.tituloSecao)]
      .filter((el) => textoNormalizado(el) === TX.acessoRapido);
    if (!candidatos.length) {
      // Reserva: qualquer elemento folha cujo texto seja exatamente "Acesso Rápido".
      const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
      for (let n = walker.nextNode(); n; n = walker.nextNode()) {
        if (util.normalizar(n.nodeValue) === TX.acessoRapido && n.parentElement) candidatos.push(n.parentElement);
      }
    }
    candidatos = maisExternos(candidatos.filter(visivel));
    // Entre vários, vale o título que tem blocos logo abaixo (a seção de verdade).
    return candidatos.find((t) => secaoDoTitulo(t)) || null;
  }

  // Sobe a partir do título até o primeiro ancestral que contém blocos clicáveis.
  function secaoDoTitulo(titulo) {
    let n = titulo && titulo.parentElement;
    for (let i = 0; n && i < 6; i++, n = n.parentElement) {
      if (n.querySelector(SEL.card)) return n;
    }
    return null;
  }

  // ---- Blocos da seção ---------------------------------------------------------------------

  function tituloDoCard(card) {
    const t = [...card.querySelectorAll(SEL.tituloCard)].find(visivel);
    if (t) return t;
    // Reserva: o primeiro elemento folha visível com texto.
    return [...card.querySelectorAll('*')].find((el) => !el.children.length && visivel(el) && textoNormalizado(el)) || null;
  }

  function clicavel(card) {
    if (card.matches('a[href], button, [role="button"], [role="link"], [ng-click], [onclick]')) return true;
    return getComputedStyle(card).cursor === 'pointer';
  }

  function cardsDaSecao(secao) {
    return maisExternos([...secao.querySelectorAll(SEL.card)])
      .filter(visivel)
      .map((card) => {
        const titulo = tituloDoCard(card);
        return { card, titulo, nome: titulo ? titulo.textContent.trim().replace(/\s+/g, ' ') : '', chave: textoNormalizado(titulo) };
      });
  }

  // Devolve { card, titulo, nomes, total } ou null. Lança AMBIGUIDADE se houver mais de um.
  function localizarCertidoes(secao) {
    if (!secao || !secao.isConnected) return null;
    const cards = cardsDaSecao(secao);
    const alvos = cards.filter((c) => c.chave === TX.certidoes && clicavel(c.card) && secao.contains(c.card));
    if (alvos.length > 1) {
      throw new S.ErroAutomacao('AMBIGUIDADE', `Encontrados ${alvos.length} blocos "Certidões" na seção Acesso Rápido.`);
    }
    if (!alvos.length) return { card: null, nomes: cards.map((c) => c.nome), total: cards.length };
    return { card: alvos[0].card, titulo: alvos[0].titulo, nomes: cards.map((c) => c.nome), total: cards.length };
  }

  S.Detector = {
    visivel, habilitado, naTela, textoNormalizado, carregando, paginaPronta, sinaisDePagina,
    esperar, esperarEstabilidade, localizarTituloAcessoRapido, secaoDoTitulo,
    cardsDaSecao, localizarCertidoes,
  };
})(globalThis);
