// Estado de autenticação do portal. NUNCA preenche CPF/senha, nunca clica em "Login com
// gov.br", não mexe em CAPTCHA nem em certificado: só observa a página.
//
// Evidências (conferidas no portal):
//   autenticado      -> a área do usuário logado (.psfz-container-logged) está visível
//   nao_autenticado  -> essa área existe mas está oculta E o botão "Login com gov.br" está visível
//   indeterminado    -> nenhuma das duas situações (página diferente, layout alterado...)
// A presença do botão de login, sozinha, NÃO conta como "sem login".
// Confirmação final: se o portal abrir "Necessário estar logado" após o clique.

(function (raiz) {
  'use strict';

  const S = raiz.SEFAZPE;
  const { CONFIG, util } = S;
  const SEL = CONFIG.SELETORES;
  const L = CONFIG.LOGIN;
  const D = S.Detector;

  // No portal logado, o conteúdo pode estar num quadro interno e o cabeçalho ("Olá, NOME") na
  // página de fora (ou o contrário). Dentro de um quadro, a avaliação também olha a página de
  // fora quando o navegador permite (mesma origem).
  function documentoDeFora() {
    try {
      if (window.top === window) return null;
      const doc = window.top.document; // lança se a página de fora for de outra origem
      return doc && doc.body ? { doc, caminho: window.top.location.pathname } : null;
    } catch (e) {
      return null;
    }
  }

  // Saudação do usuário logado ("Olá, NOME"), fora de avisos.
  function saudacaoVisivel(doc = document) {
    const raizBusca = doc.querySelector(SEL.cabecalho) || doc.body;
    if (!raizBusca) return false;
    const walker = doc.createTreeWalker(raizBusca, NodeFilter.SHOW_TEXT);
    for (let n = walker.nextNode(); n; n = walker.nextNode()) {
      const pai = n.parentElement;
      if (/^ola\b/.test(util.normalizar(n.nodeValue)) && pai && !pai.closest('.modal') && D.visivel(pai)) return true;
    }
    return false;
  }

  // Nome do usuário logado, a partir da saudação "Olá, NOME" do cabeçalho (o nome pode estar
  // num elemento ao lado do "Olá,"). Devolve o texto como aparece na página, ou null.
  function nomeUsuarioLogado(doc = document) {
    const nome = nomeNoDocumento(doc);
    if (nome || doc !== document) return nome;
    const fora = documentoDeFora();
    return fora ? nomeNoDocumento(fora.doc) : null;
  }

  function nomeNoDocumento(doc) {
    const raizBusca = doc.querySelector(SEL.cabecalho) || doc.body;
    if (!raizBusca) return null;
    const walker = doc.createTreeWalker(raizBusca, NodeFilter.SHOW_TEXT);
    for (let n = walker.nextNode(); n; n = walker.nextNode()) {
      const pai = n.parentElement;
      if (!/^ola\b/.test(util.normalizar(n.nodeValue)) || !pai || pai.closest('.modal') || !D.visivel(pai)) continue;
      for (let el = pai, i = 0; el && i < 3; el = el.parentElement, i++) {
        const texto = (el.textContent || '').replace(/\s+/g, ' ').trim();
        const m = texto.match(/^ol[áa],?\s*(.+)$/i);
        if (m && m[1].trim().length > 2) return m[1].trim();
      }
    }
    return null;
  }

  function avaliar() {
    const aqui = avaliarDocumento(document, location.pathname);
    if (aqui.estado !== 'indeterminado') return aqui;
    const fora = documentoDeFora();
    if (!fora) return aqui;
    const r = avaliarDocumento(fora.doc, fora.caminho);
    return r.estado === 'indeterminado' ? aqui : { ...r, evidencia: `${r.evidencia} (na página de fora do quadro)` };
  }

  function avaliarDocumento(doc, caminho) {
    const area = doc.querySelector(SEL.areaLogado);
    const areaVisivel = D.visivel(area);
    const botoesLogin = [...doc.querySelectorAll(SEL.botaoLogin)]
      .filter((b) => !b.closest('.modal') && D.visivel(b) && /gov ?\.?br/.test(D.textoNormalizado(b)));
    const saudacao = saudacaoVisivel(doc);
    const rotaAutenticada = String(caminho || '').includes(SEL.caminhoAutenticado);

    if (areaVisivel) {
      return { estado: 'autenticado', evidencia: 'área do usuário logado visível' };
    }
    if (saudacao && !botoesLogin.length) {
      return { estado: 'autenticado', evidencia: 'saudação "Olá, ..." visível no cabeçalho' };
    }
    if (rotaAutenticada && !botoesLogin.length && (area || doc.querySelector(SEL.cabecalho))) {
      return { estado: 'autenticado', evidencia: 'endereço autenticado (/portalsefaz/) sem botão de login' };
    }
    if (botoesLogin.length && !saudacao) {
      return { estado: 'nao_autenticado', evidencia: 'botão "Login com gov.br" visível e nenhum sinal de usuário logado' };
    }
    const sinais = `área ${area ? 'oculta' : 'ausente'}, saudação ${saudacao ? 'sim' : 'não'}, botões de login ${botoesLogin.length}, rota ${rotaAutenticada ? '/portalsefaz/' : 'pública'}`;
    return { estado: 'indeterminado', evidencia: sinais };
  }

  // Exige leituras iguais consecutivas (o Angular pode estar no meio da montagem).
  async function avaliarEstavel(ctrl) {
    const fim = Date.now() + L.limiteAvaliacao;
    let anterior = null;
    let iguais = 0;
    let ultima = avaliar();
    while (Date.now() < fim) {
      await ctrl.checkpoint();
      ultima = avaliar();
      iguais = anterior && anterior.estado === ultima.estado ? iguais + 1 : 1;
      if (iguais >= L.leiturasConfirmacao && ultima.estado !== 'indeterminado') return ultima;
      anterior = ultima;
      await util.dormir(500);
    }
    return ultima.estado === 'indeterminado' ? ultima : { estado: 'indeterminado', evidencia: 'leituras instáveis' };
  }

  // Monitora até o login aparecer. Se a pessoa sair para o gov.br, a página muda e este
  // script termina; ao voltar, o content.js retoma pelo estado salvo. Sem limite de tempo
  // que vire erro (o login é seu): só um lembrete periódico no registro.
  async function aguardarLogin(ctrl) {
    let confirmacoes = 0;
    let proximoLembrete = Date.now() + L.lembreteEspera;
    for (;;) {
      await ctrl.checkpoint();
      confirmacoes = avaliar().estado === 'autenticado' ? confirmacoes + 1 : 0;
      if (confirmacoes >= L.leiturasConfirmacao) return true;
      if (Date.now() >= proximoLembrete) {
        proximoLembrete = Date.now() + L.lembreteEspera;
        await ctrl.log('Continuo aguardando o login no portal.', { tag: 'LOGIN', nivel: 'aviso' });
      }
      await util.dormir(L.intervaloVerificacao);
    }
  }

  function modalLoginNecessario() {
    return D.visivel(document.querySelector(SEL.modalLoginNecessario));
  }

  function modalPrimeiroAcesso() {
    return D.visivel(document.querySelector(SEL.modalPrimeiroAcesso));
  }

  // Fecha o aviso "Necessário estar logado" pelo botão "Voltar" (data-dismiss do próprio
  // portal). Não clica no botão de login do aviso.
  function fecharModalLogin() {
    const modal = document.querySelector(SEL.modalLoginNecessario);
    if (!modal) return false;
    const voltar = [...modal.querySelectorAll('button, a')].find((b) => D.textoNormalizado(b) === CONFIG.TEXTOS.voltar);
    if (!voltar) return false;
    voltar.click();
    return true;
  }

  S.Login = { avaliar, avaliarEstavel, aguardarLogin, modalLoginNecessario, modalPrimeiroAcesso, fecharModalLogin, nomeUsuarioLogado };
})(globalThis);
