// Mouse humanizado: um CURSOR VISUAL desenhado sobre a página + o clique no elemento.
//
// IMPORTANTE: uma extensão do Chrome não move o ponteiro real do Windows. A seta azul é só
// uma representação na página (pointer-events: none, nunca recebe cliques). O clique é
// feito com a sequência de eventos de mouse do DOM (pointerover → mouseover → pointerdown →
// mousedown → pointerup → mouseup → click), disparada exatamente no ponto onde a seta parou,
// sobre o elemento que de fato está naquele ponto (elementFromPoint).
//
// Trajetória: curva Bézier cúbica com pontos de controle deslocados para o lado
// (proporcionais à distância), pequeno tremor que diminui perto do alvo, perfil de
// velocidade "minimum-jerk" (acelera e desacelera suavemente), quadros com intervalos não
// uniformes, duração pela lei de Fitts (limitada) e, às vezes, uma leve passada do ponto
// seguida de correção.
//
// Velocidade: perfis "lento" (padrão), "normal" e "rapido" em CONFIG.MOUSE.PERFIS, lidos do
// estado da execução (velocidadeMouse) a cada movimento. Este é o ÚNICO mecanismo de mouse
// do projeto: todas as etapas (portal, gov.br e as futuras) passam por clicar()/moverAte().
// Movimentos longos (nos perfis lento/normal) são feitos em dois trechos com uma breve
// hesitação, e o cursor começa onde parou na página anterior (sem saltos entre páginas).

(function (raiz) {
  'use strict';

  const S = raiz.SEFAZPE;
  const { CONFIG, util } = S;
  const M = CONFIG.MOUSE;
  const D = S.Detector;
  const ID = 'sefazpe-cursor';

  let caixa = null;
  let x = null;
  let y = null;
  let parado = null; // { el, dx, dy }: cursor acompanha o elemento se a página rolar
  let movendo = false;
  let cliqueEmAndamento = false;
  const ultimosCliques = new WeakMap();

  function falhaVisual(onde, e) {
    console.warn(CONFIG.PREFIXO_LOG, `Cursor visual (${onde}) falhou; a automação segue sem ele.`, e);
  }

  function posicionar(nx, ny) {
    x = nx;
    y = ny;
    if (caixa) caixa.style.transform = `translate(${Math.round(x)}px, ${Math.round(y)}px)`;
  }

  function acompanhar() {
    if (movendo || !parado || !parado.el.isConnected) return;
    const r = parado.el.getBoundingClientRect();
    posicionar(r.left + parado.dx, r.top + parado.dy);
  }

  function criar() {
    const antigo = document.getElementById(ID);
    if (antigo && antigo !== caixa) antigo.remove(); // sobra de uma versão anterior
    if (caixa && caixa.isConnected) return caixa;
    caixa = document.createElement('div');
    caixa.id = ID;
    caixa.setAttribute('aria-hidden', 'true');
    Object.assign(caixa.style, {
      position: 'fixed', left: '0', top: '0', width: '0', height: '0',
      zIndex: '2147483646', pointerEvents: 'none', transition: 'opacity .25s', opacity: '0',
    });
    caixa.innerHTML =
      '<svg width="26" height="30" viewBox="0 0 26 30" style="position:absolute;left:-3px;top:-2px;overflow:visible;' +
      'filter:drop-shadow(1px 2px 2px rgba(0,0,0,.35));transition:transform .09s">' +
      `<path d="M3 2 L3 24 L9 18.5 L13 27.5 L17 25.8 L13 17 L21 17 Z" fill="${M.cor}" stroke="#fff" stroke-width="1.6" stroke-linejoin="round"/></svg>`;
    (document.body || document.documentElement).appendChild(caixa);
    window.addEventListener('scroll', acompanhar, { passive: true, capture: true });
    window.addEventListener('resize', acompanhar, { passive: true });
    return caixa;
  }

  // Perfil de velocidade atual (pode mudar durante a execução, pelo popup).
  function perfil() {
    const nome = (S.Controle && S.Controle.estado().velocidadeMouse) || M.perfilPadrao;
    return M.PERFIS[nome] || M.PERFIS[M.perfilPadrao];
  }

  // Posição inicial: onde o cursor parou na página anterior (fração da janela), senão um
  // ponto na parte superior direita.
  function posicaoInicial() {
    const salvo = S.Controle && S.Controle.estado().cursor;
    if (salvo && typeof salvo.fx === 'number' && typeof salvo.fy === 'number') {
      return { x: util.limitar(salvo.fx, 0.02, 0.98) * window.innerWidth, y: util.limitar(salvo.fy, 0.02, 0.98) * window.innerHeight };
    }
    return { x: window.innerWidth * util.aleatorio(0.6, 0.8), y: window.innerHeight * util.aleatorio(0.15, 0.3) };
  }

  function lembrarPosicao() {
    try {
      if (S.Controle && x !== null) {
        S.Controle.atualizar({ cursor: { fx: x / window.innerWidth, fy: y / window.innerHeight } }).catch(() => {});
      }
    } catch (e) { /* só conforto visual */ }
  }

  function mostrar() {
    if (!M.ativo) return;
    try {
      criar();
      if (x === null) {
        const p = posicaoInicial();
        posicionar(p.x, p.y);
      }
      caixa.style.opacity = '1';
    } catch (e) {
      falhaVisual('mostrar', e);
    }
  }

  function esconder() {
    try {
      if (caixa) caixa.style.opacity = '0';
      parado = null;
    } catch (e) {
      falhaVisual('esconder', e);
    }
  }

  // ---- Geometria do movimento -------------------------------------------------------------

  const bezier = (p0, p1, p2, p3, t) => {
    const u = 1 - t;
    return u * u * u * p0 + 3 * u * u * t * p1 + 3 * u * t * t * p2 + t * t * t * p3;
  };
  const minimumJerk = (t) => t * t * t * (10 + t * (-15 + 6 * t));

  function duracaoFitts(distancia, largura, P = perfil()) {
    const bits = Math.log2(distancia / Math.max(8, largura) + 1);
    return util.limitar((P.fittsA + P.fittsB * bits) * util.aleatorio(0.88, 1.12), P.duracaoMin, P.duracaoMax);
  }

  function trajeto(x0, y0, x1, y1) {
    const dx = x1 - x0;
    const dy = y1 - y0;
    const dist = Math.hypot(dx, dy) || 1;
    const nx = -dy / dist;
    const ny = dx / dist;
    const amp = Math.min(110, dist * util.aleatorio(0.06, 0.2)) * (Math.random() < 0.5 ? -1 : 1);
    const a = util.aleatorio(0.2, 0.35);
    const b = util.aleatorio(0.62, 0.8);
    const c1 = { x: x0 + dx * a + nx * amp, y: y0 + dy * a + ny * amp };
    const c2 = { x: x0 + dx * b + nx * amp * util.aleatorio(0.25, 0.7), y: y0 + dy * b + ny * amp * util.aleatorio(0.25, 0.7) };
    return (t) => ({ x: bezier(x0, c1.x, c2.x, x1, t), y: bezier(y0, c1.y, c2.y, y1, t) });
  }

  // Um trecho contínuo: curva Bézier, perfil minimum-jerk (acelera e desacelera), tremor que
  // some perto do fim e quadros com intervalos irregulares. Nunca há salto: cada quadro fica
  // perto do anterior.
  async function percorrer(x1, y1, duracao, P) {
    const x0 = x;
    const y0 = y;
    const curva = trajeto(x0, y0, x1, y1);
    const t0 = performance.now();
    for (;;) {
      const t = Math.min(1, (performance.now() - t0) / duracao);
      const p = curva(minimumJerk(t));
      const tremor = (1 - t) * M.tremor;
      posicionar(p.x + (Math.random() - 0.5) * 2 * tremor, p.y + (Math.random() - 0.5) * 2 * tremor);
      if (t >= 1) break;
      await util.dormir(util.aleatorioEm(P.intervaloQuadro));
    }
    posicionar(x1, y1);
  }

  // Leva o cursor até o ponto (coordenadas da janela) sobre "el", no perfil de velocidade atual.
  async function moverAte(el, ponto) {
    if (!M.ativo) return;
    const P = perfil();
    try {
      mostrar();
      parado = null;
      movendo = true;
      await util.dormir(util.aleatorioEm(P.pausaAntes)); // "olha" o alvo antes de mover
      const largura = el.getBoundingClientRect().width;
      let dist = Math.hypot(ponto.x - x, ponto.y - y);

      // Distância longa: primeiro trecho até ~55–70% do caminho (levemente fora da reta),
      // breve hesitação e só então o trecho final, mais curto e preciso.
      if (dist > P.distanciaPausa) {
        const f = util.aleatorio(0.55, 0.7);
        const nx = -(ponto.y - y) / dist;
        const ny = (ponto.x - x) / dist;
        const desvio = util.aleatorio(-0.06, 0.06) * dist;
        const mx = x + (ponto.x - x) * f + nx * desvio;
        const my = y + (ponto.y - y) * f + ny * desvio;
        await percorrer(mx, my, duracaoFitts(dist * f, largura * 3, P) * util.aleatorio(0.9, 1.05), P);
        await util.dormir(util.aleatorioEm(P.hesitacao));
        dist = Math.hypot(ponto.x - x, ponto.y - y);
      }

      if (dist > M.distanciaParaCorrecao && Math.random() < M.chanceCorrecao) {
        // Passa um pouco do ponto e corrige (como a mão de uma pessoa).
        const ux = (ponto.x - x) / dist;
        const uy = (ponto.y - y) / dist;
        const passa = util.aleatorio(5, 12);
        await percorrer(ponto.x + ux * passa + util.aleatorio(-4, 4), ponto.y + uy * passa + util.aleatorio(-4, 4), duracaoFitts(dist, largura, P), P);
        await util.dormir(util.aleatorio(60, 160));
        await percorrer(ponto.x, ponto.y, util.aleatorioEm(P.correcao), P);
      } else {
        await percorrer(ponto.x, ponto.y, duracaoFitts(dist, largura, P), P);
      }
    } catch (e) {
      falhaVisual('mover', e);
    } finally {
      movendo = false;
      lembrarPosicao();
    }
  }

  function animarClique(px, py) {
    if (!M.ativo) return;
    try {
      const onda = document.createElement('div');
      onda.setAttribute('aria-hidden', 'true');
      Object.assign(onda.style, {
        position: 'fixed', left: `${px - 14}px`, top: `${py - 14}px`, width: '28px', height: '28px',
        borderRadius: '50%', border: `3px solid ${M.cor}`, pointerEvents: 'none', zIndex: '2147483645',
        opacity: '0.9', transform: 'scale(0.3)', transition: 'transform .45s ease-out, opacity .45s ease-out',
      });
      (document.body || document.documentElement).appendChild(onda);
      setTimeout(() => { onda.style.transform = 'scale(1.6)'; onda.style.opacity = '0'; }, 16);
      setTimeout(() => onda.remove(), 650);
      const svg = caixa && caixa.firstElementChild;
      if (svg) {
        svg.style.transform = 'scale(0.82)';
        setTimeout(() => { svg.style.transform = ''; }, 140);
      }
    } catch (e) {
      falhaVisual('clique', e);
    }
  }

  // ---- Ponto seguro e clique ----------------------------------------------------------------

  function atinge(el, px, py) {
    const hit = document.elementFromPoint(px, py);
    return hit && (hit === el || el.contains(hit)) ? hit : null;
  }

  // Um ponto dentro da região central do elemento que não esteja coberto por outra coisa
  // (ex.: o botão flutuante "CHAT" do portal). Primeiro perto do centro, depois sorteios.
  function pontoSeguro(el) {
    const r = el.getBoundingClientRect();
    const candidatos = [[0.5 + util.aleatorio(-0.06, 0.06), 0.5 + util.aleatorio(-0.06, 0.06)]];
    for (let i = 0; i < 14; i++) candidatos.push([util.aleatorio(0.25, 0.75), util.aleatorio(0.25, 0.75)]);
    for (const [fx, fy] of candidatos) {
      const px = r.left + r.width * fx;
      const py = r.top + r.height * fy;
      if (px < 0 || py < 0 || px > window.innerWidth || py > window.innerHeight) continue;
      const hit = atinge(el, px, py);
      if (hit) return { x: px, y: py, dx: px - r.left, dy: py - r.top, hit };
    }
    return null;
  }

  function disparar(alvo, px, py) {
    const base = { bubbles: true, cancelable: true, composed: true, view: window, clientX: px, clientY: py, screenX: px, screenY: py, button: 0 };
    const ponteiro = { ...base, pointerId: 1, pointerType: 'mouse', isPrimary: true };
    return {
      passar() {
        alvo.dispatchEvent(new PointerEvent('pointerover', ponteiro));
        alvo.dispatchEvent(new MouseEvent('mouseover', base));
        alvo.dispatchEvent(new MouseEvent('mouseenter', { ...base, bubbles: false }));
        alvo.dispatchEvent(new PointerEvent('pointermove', ponteiro));
        alvo.dispatchEvent(new MouseEvent('mousemove', base));
      },
      apertar() {
        alvo.dispatchEvent(new PointerEvent('pointerdown', { ...ponteiro, buttons: 1 }));
        alvo.dispatchEvent(new MouseEvent('mousedown', { ...base, buttons: 1 }));
      },
      soltar() {
        alvo.dispatchEvent(new PointerEvent('pointerup', ponteiro));
        alvo.dispatchEvent(new MouseEvent('mouseup', base));
        alvo.dispatchEvent(new MouseEvent('click', base));
      },
    };
  }

  // Clica em "el" com segurança. antesDoDisparo() roda depois de todas as verificações e
  // imediatamente antes do clique (usado para gravar "clique realizado" antes de a página
  // poder navegar). Devolve { x, y, alvo }.
  // aoPosicionar() roda logo antes de o cursor começar a se mover até o alvo.
  async function clicar(el, { ctrl, antesDoDisparo, aoPosicionar } = {}) {
    if (cliqueEmAndamento) throw new S.ErroAutomacao('CLIQUE_DUPLICADO');
    const ultimo = ultimosCliques.get(el);
    if (ultimo && Date.now() - ultimo < M.bloqueioRepeticao) throw new S.ErroAutomacao('CLIQUE_DUPLICADO');
    if (!D.visivel(el) || !D.habilitado(el)) throw new S.ErroAutomacao('ELEMENTO_INVISIVEL', 'O alvo não está visível ou habilitado.');

    await S.Scroll.trazerParaVisao(el, { ctrl, posicao: 'centro' });
    let ponto = pontoSeguro(el);
    if (!ponto) throw new S.ErroAutomacao('ELEMENTO_INVISIVEL', 'O alvo está coberto por outro elemento ou fora da tela.');

    if (aoPosicionar) await aoPosicionar();
    await moverAte(el, ponto);
    parado = { el, dx: ponto.dx, dy: ponto.dy };
    // O cursor chegou: o elemento recebe o "passar por cima" agora (como um mouse real) e o
    // clique só vem depois de uma parada natural, do tamanho do perfil de velocidade.
    const P = perfil();
    try {
      const rc = el.getBoundingClientRect();
      const sob = atinge(el, rc.left + ponto.dx, rc.top + ponto.dy);
      if (sob) disparar(sob, rc.left + ponto.dx, rc.top + ponto.dy).passar();
    } catch (e) { /* só aparência (hover) */ }
    await util.dormir(util.aleatorioEm(P.pausaClique));
    await ctrl.checkpoint();

    // Confirmação imediatamente antes do clique: o elemento ainda existe, está visível e é
    // ele que está sob o cursor.
    if (!el.isConnected || !D.visivel(el)) throw new S.ErroAutomacao('ELEMENTO_INVISIVEL', 'O alvo desapareceu antes do clique.');
    const r = el.getBoundingClientRect();
    let px = r.left + ponto.dx;
    let py = r.top + ponto.dy;
    let hit = atinge(el, px, py);
    if (!hit) {
      ponto = pontoSeguro(el);
      if (!ponto) throw new S.ErroAutomacao('ELEMENTO_INVISIVEL', 'O alvo ficou coberto antes do clique.');
      await moverAte(el, ponto);
      ({ x: px, y: py, hit } = ponto);
    }

    cliqueEmAndamento = true;
    try {
      if (antesDoDisparo) await antesDoDisparo();
      ultimosCliques.set(el, Date.now());
      const ev = disparar(hit, px, py);
      ev.apertar();
      animarClique(px, py);
      await util.dormir(util.aleatorioEm(P.botao));
      ev.soltar();
      return { x: px, y: py, alvo: util.descrever(hit) };
    } finally {
      cliqueEmAndamento = false;
    }
  }

  // Clica num PONTO da janela (não num elemento): usado para clicar FORA de um painel
  // sobreposto. conferir(elementoNoPonto) é chamado imediatamente antes do clique; se devolver
  // falso, o clique não acontece. Devolve { x, y, alvo } ou null (cancelado).
  async function clicarPonto(px, py, { ctrl, conferir } = {}) {
    if (cliqueEmAndamento) throw new S.ErroAutomacao('CLIQUE_DUPLICADO');
    const alvoInicial = document.elementFromPoint(px, py);
    if (!alvoInicial) return null;
    await moverAte(alvoInicial, { x: px, y: py });
    await util.dormir(util.aleatorioEm(perfil().pausaClique));
    if (ctrl) await ctrl.checkpoint();
    const hit = document.elementFromPoint(px, py);
    if (!hit || (conferir && !conferir(hit))) return null;
    cliqueEmAndamento = true;
    try {
      const ev = disparar(hit, px, py);
      ev.passar();
      ev.apertar();
      animarClique(px, py);
      await util.dormir(util.aleatorioEm(perfil().botao));
      ev.soltar();
      return { x: px, y: py, alvo: util.descrever(hit) };
    } finally {
      cliqueEmAndamento = false;
    }
  }

  S.Mouse = { mostrar, esconder, moverAte, clicar, clicarPonto, pontoSeguro, duracaoFitts, animarClique, perfil };
})(globalThis);
