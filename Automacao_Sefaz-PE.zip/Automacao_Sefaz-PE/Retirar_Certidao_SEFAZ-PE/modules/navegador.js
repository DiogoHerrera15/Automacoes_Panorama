// Onde a página está e o que mudou depois de um clique.
//
// O portal é uma aplicação AngularJS de página única: a troca de tela costuma mudar só o
// trecho "#!/?form=..." do endereço e montar um novo <div id="<form>Page">, sem recarregar.
// Por isso a confirmação de navegação olha a rota (form) E o conteúdo (páginas visíveis).

(function (raiz) {
  'use strict';

  const S = raiz.SEFAZPE;
  const { CONFIG, util } = S;
  const SEL = CONFIG.SELETORES;
  const P = CONFIG.PORTAL;
  const T = CONFIG.TEMPOS;
  const D = S.Detector;

  function ehPortal() {
    return location.origin === P.origem;
  }

  // ---- Quadros (iframes) ----------------------------------------------------------------------
  //
  // Depois do login, o portal (/portalsefaz/...?headless) é uma "casca" que mostra o conteúdo
  // real num quadro interno. A extensão roda em todos os quadros da aba, mas só UM age:
  //   - páginas de login (gov.br/SSO): só o quadro do topo;
  //   - topo do portal SEM quadro grande do portal: o topo;
  //   - topo do portal COM quadro grande do portal: o quadro (o topo só observa);
  //   - quadro do portal grande: ele; quadros pequenos/de outros sites: nunca.

  const ehTopo = () => window.top === window;
  const AREA_MINIMA = 0.35; // fração da janela que um quadro precisa ocupar para ser "o conteúdo"

  function origemDoQuadro(iframe) {
    try {
      const src = iframe.getAttribute('src');
      if (!src || src === 'about:blank') {
        return iframe.contentWindow && iframe.contentWindow.location ? iframe.contentWindow.location.origin : null;
      }
      return new URL(src, location.href).origin;
    } catch (e) {
      return null; // quadro de outra origem (sem acesso)
    }
  }

  function quadrosVisiveis() {
    const area = window.innerWidth * window.innerHeight || 1;
    return [...document.querySelectorAll('iframe, frame')].map((f) => {
      const r = f.getBoundingClientRect();
      return { el: f, fracao: (r.width * r.height) / area, largura: Math.round(r.width), altura: Math.round(r.height), origem: origemDoQuadro(f), visivel: D.visivel(f) };
    });
  }

  // No topo: o quadro grande que contém o portal (onde a automação deve agir), ou null.
  function quadroDoPortal() {
    if (!ehTopo()) return null;
    return quadrosVisiveis().find((q) => q.visivel && q.fracao >= AREA_MINIMA && q.origem === P.origem) || null;
  }

  // Este quadro é o conteúdo principal do portal?
  function ehQuadroPrincipal() {
    if (ehTopo() || !ehPortal()) return false;
    if (window.innerWidth < 400 || window.innerHeight < 250) return false;
    try {
      const areaTopo = window.top.innerWidth * window.top.innerHeight || 1;
      return (window.innerWidth * window.innerHeight) / areaTopo >= AREA_MINIMA;
    } catch (e) {
      return true; // sem acesso ao topo: já passou do tamanho mínimo
    }
  }

  // Este quadro deve executar a automação (e mostrar o painel)?
  function devoAtuar() {
    const login = S.GovBr && S.GovBr.ehDominioAutenticacao();
    if (ehTopo()) return login || !quadroDoPortal();
    return !login && ehQuadroPrincipal();
  }

  // Para os registros: os quadros desta página (endereço sem consulta, tamanho, acesso).
  function descreverQuadros() {
    const qs = quadrosVisiveis();
    if (!qs.length) return 'nenhum quadro (iframe) na página';
    return qs.slice(0, 5).map((q) => {
      let end = q.origem || 'outra origem';
      try {
        const src = q.el.getAttribute('src');
        if (src && src !== 'about:blank') { const u = new URL(src, location.href); end = u.origin + u.pathname; }
      } catch (e) { /* mantém a origem */ }
      return `${end} (${q.largura}x${q.altura}, ${Math.round(q.fracao * 100)}% da janela${q.visivel ? '' : ', oculto'})`;
    }).join('; ');
  }

  function formAtual() {
    const m = (location.hash || '').match(/[?&]form=([^&]+)/) || (location.search || '').match(/[?&]form=([^&]+)/);
    return m ? decodeURIComponent(m[1]) : null;
  }

  function ehPaginaInicial() {
    const f = formAtual();
    return location.pathname.includes(P.caminhoPaginaInicial) && (!f || f === P.formInicial);
  }

  function paginasVisiveis() {
    return [...document.querySelectorAll(SEL.paginaForm)].filter((el) => el.id && D.visivel(el)).map((el) => el.id);
  }

  // Endereço sem parâmetros de consulta (o retorno do login pode trazer códigos).
  function enderecoSeguro() {
    return location.origin + location.pathname + (formAtual() ? ` (form=${formAtual()})` : '');
  }

  function instantaneo() {
    return { href: location.href, form: formAtual(), paginas: paginasVisiveis() };
  }

  // A tela de Certidões está aberta? Devolve as evidências encontradas.
  function telaCertidoes() {
    const evidencias = [];
    if (formAtual() === P.formCertidoes) evidencias.push(`rota form=${P.formCertidoes}`);
    if (D.visivel(document.getElementById(P.formCertidoes + 'Page'))) evidencias.push(`#${P.formCertidoes}Page visível`);
    return { confirmada: evidencias.length > 0, evidencias };
  }

  // Espera alguma reação ao clique. Enquanto houver "carregando" na tela, o prazo é estendido
  // (até T.extensaoPorCarregamento a mais).
  async function aguardarMudanca(antes, { ctrl, limite = T.aguardarNavegacao } = {}) {
    let fim = Date.now() + limite;
    const fimMaximo = fim + T.extensaoPorCarregamento;
    for (;;) {
      await ctrl.checkpoint();
      if (S.Login.modalLoginNecessario()) return { tipo: 'login_necessario' };
      if (S.Login.modalPrimeiroAcesso()) return { tipo: 'primeiro_acesso' };
      const form = formAtual();
      if (location.href !== antes.href && form && form !== P.formInicial) return { tipo: 'rota', form };
      const novas = paginasVisiveis().filter((id) => !antes.paginas.includes(id));
      if (novas.length) return { tipo: 'conteudo', paginas: novas };
      if (D.carregando()) fim = Math.min(fimMaximo, Math.max(fim, Date.now() + 2000));
      if (Date.now() >= fim) return { tipo: 'sem_mudanca', carregando: D.carregando() };
      await util.dormir(T.intervalo);
    }
  }

  async function aguardarEstabilizacao(ctrl) {
    const semCarregar = await D.esperar(() => !D.carregando(), { limite: T.extensaoPorCarregamento, ctrl });
    const quieto = await D.esperarEstabilidade({ ctrl });
    return !!semCarregar && quieto;
  }

  // Volta para a tela inicial dentro da mesma aplicação (só troca o trecho após o #).
  function voltarParaInicio() {
    if (!location.pathname.includes(P.caminhoPaginaInicial)) return false;
    location.hash = '#!/?form=' + P.formInicial;
    return true;
  }

  function recarregar() {
    location.reload();
  }

  S.Navegador = {
    ehPortal, formAtual, ehPaginaInicial, paginasVisiveis, enderecoSeguro, instantaneo,
    telaCertidoes, aguardarMudanca, aguardarEstabilizacao, voltarParaInicio, recarregar,
    ehTopo, quadroDoPortal, ehQuadroPrincipal, devoAtuar, descreverQuadros,
  };
})(globalThis);
