// Controle de execução do lado da página: estado, logs, pausar/continuar/parar.
//
// O estado "oficial" fica em chrome.storage.local e só o background grava (um único
// escritor, sem corrida). Aqui mantemos uma cópia atualizada pelo storage.onChanged e
// enviamos as mudanças ao background. Assim o estado sobrevive ao fechamento do popup,
// ao F5 e à ida/volta do login gov.br.
//
// checkpoint() é chamado entre as ações: bloqueia enquanto estiver "pausado" e lança
// ExecucaoInterrompida se o usuário parar, se outra execução assumir, ou se a extensão
// for recarregada (contexto invalidado).

(function (raiz) {
  'use strict';

  const S = raiz.SEFAZPE;
  const { CONST, CONFIG, util } = S;
  const { ExecucaoInterrompida } = S;

  let estado = CONST.estadoInicial();
  let tabId = null;
  let execIdAtual = null;
  const ouvintes = new Set();
  const esperas = new Set();

  function contextoValido() {
    try {
      return !!(chrome.runtime && chrome.runtime.id);
    } catch (e) {
      return false;
    }
  }

  async function enviar(msg) {
    if (!contextoValido()) throw new ExecucaoInterrompida('A extensão foi recarregada.');
    try {
      return await chrome.runtime.sendMessage(msg);
    } catch (e) {
      if (!contextoValido()) throw new ExecucaoInterrompida('A extensão foi recarregada.');
      throw new S.ErroAutomacao('ERRO_COMUNICACAO', 'Sem resposta do background: ' + e.message);
    }
  }

  function aplicarEstado(novo) {
    estado = { ...CONST.estadoInicial(), ...(novo || {}) };
    esperas.forEach((f) => f());
    ouvintes.forEach((f) => {
      try { f(estado); } catch (e) { console.warn(CONFIG.PREFIXO_LOG, 'Ouvinte de estado falhou:', e); }
    });
  }

  try {
    chrome.storage.onChanged.addListener((mudancas, area) => {
      if (area !== 'local' || !mudancas[CONST.CHAVES.estado]) return;
      aplicarEstado(mudancas[CONST.CHAVES.estado].newValue);
    });
  } catch (e) {
    console.warn(CONFIG.PREFIXO_LOG, 'Não foi possível acompanhar o estado:', e);
  }

  // Execução iniciada pela interface/terminal: a aba da execução pergunta a cada 2 s se você
  // pediu Pausar, Continuar ou Parar lá (funciona também enquanto está pausada ou esperando
  // você no gov.br). Execuções do popup não consultam nada.
  setInterval(() => {
    try {
      if (!contextoValido() || tabId === null) return;
      if (estado.origem === 'popup' || !estado.tokenTerminal || estado.tabId !== tabId) return;
      if (!CONST.STATUS_ATIVOS.includes(estado.status)) return;
      if (S.Navegador && !S.Navegador.devoAtuar()) return; // só o quadro que age consulta
      chrome.runtime.sendMessage({ tipo: 'terminal:poll' }).catch(() => {});
    } catch (e) { /* a consulta nunca interrompe a automação */ }
  }, 2000);

  // Apresenta esta aba ao background e recebe o tabId e o estado atual (o background pode ter
  // acabado de iniciar uma execução pedida pelo terminal para esta aba).
  async function registrar() {
    const r = await enviar({ tipo: 'registrar' });
    tabId = r && r.tabId;
    aplicarEstado(r && r.estado);
    return { tabId, estado, iniciadoPeloTerminal: !!(r && r.iniciadoPeloTerminal) };
  }

  function assumir(execId) {
    execIdAtual = execId;
  }

  // A execução gravada pertence a esta aba e está viva?
  function execucaoDestaAba() {
    return !!estado.execId && estado.tabId === tabId && CONST.STATUS_ATIVOS.includes(estado.status);
  }

  function aguardarMudanca(limite = 2000) {
    return new Promise((resolve) => {
      const fim = () => { esperas.delete(fim); clearTimeout(t); resolve(); };
      const t = setTimeout(fim, limite);
      esperas.add(fim);
    });
  }

  async function checkpoint() {
    for (;;) {
      if (!contextoValido()) throw new ExecucaoInterrompida('A extensão foi recarregada.');
      if (estado.execId !== execIdAtual || estado.tabId !== tabId) {
        throw new ExecucaoInterrompida('Outra execução assumiu o controle.');
      }
      if (estado.status === 'parado' || estado.status === 'ocioso' || estado.status === 'concluido') {
        throw new ExecucaoInterrompida('Execução parada.');
      }
      if (estado.status === 'pausado' || estado.status === 'erro') {
        await aguardarMudanca();
        continue;
      }
      return;
    }
  }

  // Espera "ms" em fatias, respeitando pausa e parada.
  async function esperar(ms) {
    const fim = Date.now() + ms;
    while (Date.now() < fim) {
      await checkpoint();
      await util.dormir(Math.min(200, fim - Date.now()));
    }
  }

  async function atualizar(parcial) {
    estado = { ...estado, ...parcial };
    await enviar({ tipo: 'estado:atualizar', execId: execIdAtual, parcial });
  }

  // Registro: data/hora é posta pelo background. Nunca envie senha, cookie ou token.
  async function log(acao, extra = {}) {
    const entrada = {
      etapa: estado.etapa,
      acao,
      resultado: extra.resultado || null,
      erro: extra.erro || null,
      tentativa: extra.tentativa || null,
      recuperacao: extra.recuperacao || null,
      nivel: extra.nivel || (extra.erro ? 'erro' : 'info'),
      // Rótulo mostrado no terminal ([LOGIN], [GOV.BR], [MOUSE]...). Opcional.
      tag: extra.tag || null,
      // Pedido ao computador (Modo 2, janela nativa). Hoje: 'selecionar_certificado'.
      acaoNativa: extra.acaoNativa || null,
    };
    console.log(CONFIG.PREFIXO_LOG, acao, extra.erro ? '— ' + extra.erro : '');
    try {
      await enviar({ tipo: 'log', execId: execIdAtual, entrada });
    } catch (e) {
      if (e instanceof ExecucaoInterrompida) throw e;
      console.warn(CONFIG.PREFIXO_LOG, 'Log não registrado:', e.message);
    }
  }

  async function registrarRecuperacao(nome, erro, tentativa, espera) {
    await atualizar({
      tentativasRecuperacao: (estado.tentativasRecuperacao || 0) + 1,
      mensagem: 'Erro identificado. Tentando recuperar...',
      erro: erro.message,
      recuperando: true, // estado ERRO_RECUPERAVEL até a próxima etapa começar
    });
    await log(`Falha em "${nome}": nova tentativa em ${(espera / 1000).toFixed(1)} s.`, {
      resultado: 'nova tentativa',
      erro: `${erro.codigo}: ${erro.message}`,
      tentativa,
      recuperacao: 'repetir a identificação',
      nivel: 'aviso',
    });
  }

  async function enviarComando(comando) {
    return enviar({ tipo: 'comando', comando });
  }

  S.Controle = {
    contextoValido,
    registrar,
    assumir,
    execucaoDestaAba,
    checkpoint,
    esperar,
    atualizar,
    log,
    registrarRecuperacao,
    enviarComando,
    estado: () => estado,
    tabId: () => tabId,
    aoMudarEstado: (fn) => { ouvintes.add(fn); return () => ouvintes.delete(fn); },
  };
})(globalThis);
