// Telas de Certidões e da consulta de Certidão Negativa: identificação por TEXTO EXATO e pela
// estrutura (nunca por coordenadas), digitação humanizada e conferência do valor digitado.
// Não clica (quem clica é mouse_humano.js) e não decide o fluxo (content.js).
//
// Referência: imagens de 18/11/2026.
//   Certidões: título grande "Certidões" + blocos (Certidão de Cadastro, Consultar
//     Autenticidade, Certidão de Baixa, Certidão de Regularidade Fiscal, Certidão Negativa,
//     Certidão de Recolhimento), cada um com "(Necessário Autenticação Pelo gov.br)".
//   Certidão Negativa: título "Certidão Negativa", opções CNPJ | CPF | Inscrição Estadual
//     (botões redondos), campo "Pesquise pelo CNPJ" e botão "Pesquisar".
// O HTML dessas telas só aparece com login e não pôde ser inspecionado antes; por isso, quando
// algo não é encontrado, mapaDiagnostico() descreve o que estava na tela, para ajuste fino.

(function (raiz) {
  'use strict';

  const S = raiz.SEFAZPE;
  const { CONFIG, util } = S;
  const Q = CONFIG.CONSULTA;
  const D = S.Detector;
  const norm = util.normalizar;

  const CLICAVEL = 'a[href], button, [role="button"], [role="link"], [ng-click], [onclick], label';

  // Elementos visíveis cujo texto (normalizado) é EXATAMENTE "texto"; só os mais internos.
  function comTextoExato(texto, base = document.body) {
    if (!base) return [];
    const todos = [...base.querySelectorAll('*')].filter((el) => !/^(SCRIPT|STYLE|NOSCRIPT|svg|path)$/i.test(el.tagName) && norm(el.textContent) === texto);
    return todos.filter((el) => !todos.some((o) => o !== el && el.contains(o)) && D.visivel(el) && !el.closest('#sefazpe-painel'));
  }

  const tamanhoFonte = (el) => parseFloat(getComputedStyle(el).fontSize) || 0;

  // Título grande da página (o mesmo texto aparece em menus e no caminho "Início > ...").
  function tituloGrande(texto) {
    const candidatos = comTextoExato(texto).filter((el) => !emCaminho(el) && tamanhoFonte(el) >= 20);
    candidatos.sort((a, b) => tamanhoFonte(b) - tamanhoFonte(a));
    return candidatos[0] || null;
  }

  // Está no caminho de navegação ("Início > Certidões > Certidão Negativa")? O elemento só é
  // um item do caminho se, num ancestral próximo cujo texto é "Início > ... > ...", ele for
  // EXATAMENTE um dos trechos separados por ">".
  //
  // (Correção 0.4.2: a regra antiga descartava qualquer elemento cujo ancestral começasse com
  // "Início >". Na página real, o título grande "Certidões" fica no mesmo contêiner do
  // caminho; o título era descartado e a página de Certidões nunca era reconhecida.)
  function emCaminho(el) {
    if (el.closest('nav, [class*="breadcrumb" i], [aria-label*="breadcrumb" i]')) return true;
    const proprio = norm(el.textContent);
    for (let n = el.parentElement, i = 0; n && i < 3; n = n.parentElement, i++) {
      const t = norm(n.textContent);
      if (!t.startsWith('inicio') || !t.includes('>')) continue;
      const trechos = t.split('>').map((s) => s.trim());
      if (trechos.every((s) => s.length <= 60) && trechos.slice(1).includes(proprio)) return true;
    }
    return false;
  }

  // ---- Telas ---------------------------------------------------------------------------------

  function telaCertidaoNegativa() {
    const titulo = tituloGrande(Q.tituloNegativa);
    const opcoes = Object.keys(Q.rotulosTipo).filter((t) => opcaoTipo(t));
    const botao = botaoPesquisar();
    const evidencias = [];
    if (titulo) evidencias.push('título "Certidão Negativa"');
    if (opcoes.length) evidencias.push(`opções ${opcoes.join('/')}`);
    if (botao) evidencias.push('botão "Pesquisar"');
    return { confirmada: !!titulo && opcoes.length >= 2 && !!botao, evidencias, opcoes };
  }

  // Página de Certidões, por qualquer uma de três evidências (camadas):
  //   1. título grande "Certidões" + 3 ou mais blocos de certidão;
  //   2. rota do portal (form=frm_psfz_cert_index ou #frm_psfz_cert_indexPage visível) + 2 blocos;
  //   3. 4 ou mais blocos de certidão visíveis (mesmo sem o título).
  function rotaDeCertidoes() {
    const m = (location.hash || '').match(/[?&]form=([^&]+)/);
    return (m && decodeURIComponent(m[1]) === 'frm_psfz_cert_index') || D.visivel(document.getElementById('frm_psfz_cert_indexPage'));
  }

  function telaCertidoes() {
    if (telaCertidaoNegativa().confirmada) return { confirmada: false, evidencias: ['é a consulta de Certidão Negativa'] };
    const titulo = tituloGrande(Q.tituloCertidoes);
    const blocos = Q.blocosCertidoes.filter((b) => comTextoExato(b).some((el) => !emCaminho(el)));
    const rota = rotaDeCertidoes();
    const evidencias = [];
    if (titulo) evidencias.push('título "Certidões"');
    if (rota) evidencias.push('rota frm_psfz_cert_index');
    evidencias.push(`${blocos.length} blocos de certidão visíveis`);
    const confirmada = (!!titulo && blocos.length >= 3) || (rota && blocos.length >= 2) || blocos.length >= 4;
    return { confirmada, evidencias, blocos };
  }

  // ---- Bloco "Certidão Negativa" -------------------------------------------------------------

  // Sobe do título até o bloco clicável: o primeiro ancestral com ação de clique (ng-click,
  // link, botão) ou, sem isso, o maior ancestral com cursor de mão que ainda contém só UM
  // título de certidão (para não pegar a grade inteira).
  // Do título até o bloco (camada 3: inspeção dos pais). Sobe enquanto o ancestral contém um
  // ÚNICO título de certidão e pouco texto (o bloco não engloba os vizinhos):
  //   - ancestral com ação de clique (ng-click, link, botão, onclick) → é o bloco;
  //   - senão, o maior ancestral com cursor de mão;
  //   - senão, o maior ancestral que ainda é só deste título (o clique no centro dele chega,
  //     por propagação, a quem trata o clique).
  function blocoDoTitulo(titulo) {
    let comMao = null;
    let maior = null;
    for (let n = titulo, i = 0; n && n !== document.body && i < 7; n = n.parentElement, i++) {
      const texto = norm(n.textContent);
      const titulos = Q.blocosCertidoes.filter((b) => texto.includes(b)).length;
      if (titulos > 1 || texto.length > 220) break;
      if (n.matches('[ng-click], [data-ng-click], [ng-href], a[href], button, [role="button"], [onclick]')) return n;
      if (getComputedStyle(n).cursor === 'pointer') comMao = n;
      maior = n;
    }
    return comMao || maior;
  }

  // Camadas 1 e 2 para o título: texto exato; depois, texto que CONTÉM "certidão negativa"
  // (após normalizar espaços, acentos e quebras de linha), só em elementos curtos.
  function titulosCertidaoNegativa() {
    const exatos = comTextoExato(Q.tituloNegativa).filter((el) => !emCaminho(el) && tamanhoFonte(el) < 40);
    if (exatos.length) return { titulos: exatos, camada: 'texto exato' };
    const todos = [...document.body.querySelectorAll('*')].filter((el) => {
      const t = norm(el.textContent);
      return t.includes(Q.tituloNegativa) && t.length <= 80 && !/regularidade|baixa|cadastro|recolhimento/.test(t);
    });
    const internos = todos.filter((el) => !todos.some((o) => o !== el && el.contains(o)) && D.visivel(el) && !emCaminho(el) && tamanhoFonte(el) < 40);
    return { titulos: internos, camada: 'texto normalizado (contém)' };
  }

  function blocoCertidaoNegativa() {
    const { titulos, camada } = titulosCertidaoNegativa();
    const blocos = [...new Set(titulos.map(blocoDoTitulo).filter(Boolean))];
    if (blocos.length > 1) throw new S.ErroAutomacao('AMBIGUIDADE', `Encontrados ${blocos.length} blocos "Certidão Negativa"; não é seguro clicar. ${diagnosticoCertidaoNegativa()}`);
    if (blocos[0]) blocos[0].__sefazpeCamada = camada;
    return blocos[0] || null;
  }

  const descreverEl = (el) => {
    if (!el) return '—';
    const cls = typeof el.className === 'string' && el.className.trim() ? '.' + el.className.trim().split(/\s+/).slice(0, 3).join('.') : '';
    const clique = el.getAttribute('ng-click') || el.getAttribute('onclick') ? '[clique]' : '';
    return `${el.tagName.toLowerCase()}${cls}${clique}${getComputedStyle(el).cursor === 'pointer' ? '{mão}' : ''}`;
  };

  // Diagnóstico para os registros quando o bloco não é encontrado: endereço, carregamento,
  // camadas testadas, quantos elementos cada uma achou e a estrutura em volta do título.
  function diagnosticoCertidaoNegativa() {
    const exatos = comTextoExato(Q.tituloNegativa);
    const contem = [...document.body.querySelectorAll('*')].filter((el) => norm(el.textContent).includes(Q.tituloNegativa) && !el.children.length);
    const alvo = exatos[0] || contem[0];
    const cadeia = [];
    for (let n = alvo, i = 0; n && n !== document.body && i < 6; n = n.parentElement, i++) cadeia.push(descreverEl(n));
    return [
      `endereço ${location.origin}${location.pathname}${location.hash ? ' ' + location.hash.slice(0, 60) : ''}`,
      `carregamento ${document.readyState}${D.carregando() ? ' (carregando)' : ''}`,
      `texto exato: ${exatos.length} (no caminho: ${exatos.filter(emCaminho).length}, fonte ${exatos.map((e) => Math.round(tamanhoFonte(e))).join('/') || '-'})`,
      `contém o texto: ${contem.length}`,
      `estrutura: ${cadeia.join(' < ') || 'título não encontrado'}`,
      `trecho: "${alvo ? String(alvo.textContent).replace(/\s+/g, ' ').trim().slice(0, 60) : ''}"`,
    ].join('; ');
  }

  // ---- Opções CNPJ / CPF / Inscrição Estadual -------------------------------------------------

  function rotuloDoRadio(input) {
    if (input.labels && input.labels.length) return norm(input.labels[0].textContent);
    const label = input.closest('label');
    if (label) return norm(label.textContent);
    const prox = input.nextElementSibling || (input.parentElement && input.parentElement.nextElementSibling);
    if (prox) return norm(prox.textContent);
    return norm(input.parentElement ? input.parentElement.textContent : '');
  }

  // Devolve { input, alvo } da opção do tipo ("alvo" é o que se clica: o rótulo ou o próprio
  // botão redondo visível). null se não achou.
  function opcaoTipo(tipo) {
    const rotulos = Q.rotulosTipo[tipo] || [];
    const radios = [...document.querySelectorAll('input[type="radio"]')].filter((r) => rotulos.includes(rotuloDoRadio(r)));
    for (const input of radios) {
      const alvo = [input.labels && input.labels[0], input.closest('label'), input].find((x) => x && D.visivel(x));
      const visual = alvo || (input.parentElement && D.visivel(input.parentElement) ? input.parentElement : null);
      if (visual) return { input, alvo: visual };
    }
    // Reserva: botão redondo desenhado sem <input type="radio"> (só o texto clicável).
    const texto = comTextoExato(rotulos[0] || '__').find((el) => !emCaminho(el));
    if (texto) {
      const alvo = texto.closest(CLICAVEL) || texto;
      return { input: alvo.querySelector('input[type="radio"]') || null, alvo };
    }
    return null;
  }

  // A opção do tipo está marcada? Pelo radio; sem radio, pelo texto de ajuda do campo
  // ("Pesquise pelo CPF").
  function tipoMarcado(tipo) {
    const o = opcaoTipo(tipo);
    if (o && o.input) return o.input.checked;
    const campo = campoPesquisa();
    const dica = norm(campo ? campo.getAttribute('placeholder') : '');
    return (Q.rotulosTipo[tipo] || []).some((r) => dica.endsWith(r));
  }

  // ---- Campo e botão -----------------------------------------------------------------------------

  function botaoPesquisar() {
    const lista = [...document.querySelectorAll('button, input[type="submit"], input[type="button"], a, [role="button"]')]
      .filter((el) => norm(el.tagName === 'INPUT' ? el.value : el.textContent) === Q.textoBotaoPesquisar && D.visivel(el));
    return lista.length === 1 ? lista[0] : lista.find((b) => b.closest('form')) || lista[0] || null;
  }

  function camposDeTexto() {
    return [...document.querySelectorAll('input:not([type]), input[type="text"], input[type="search"], input[type="tel"], input[type="number"]')]
      .filter((i) => D.visivel(i) && !i.disabled && !i.readOnly);
  }

  // O campo de pesquisa: o de texto de ajuda "Pesquise pelo ..."; senão, o que fica junto do
  // botão "Pesquisar". Nunca a busca geral do portal ("Qual outro serviço você procura?").
  function campoPesquisa() {
    const campos = camposDeTexto().filter((i) => !/servico|procura/.test(norm(i.getAttribute('placeholder'))));
    const porDica = campos.find((i) => Q.placeholderPesquisa.test(norm(i.getAttribute('placeholder'))));
    if (porDica) return porDica;
    const botao = botaoPesquisar();
    if (!botao) return null;
    for (let n = botao.parentElement, i = 0; n && i < 4; n = n.parentElement, i++) {
      const c = campos.find((x) => n.contains(x));
      if (c) return c;
    }
    return null;
  }

  // Conteúdo do campo sem máscara (maiúsculas, só letras e números).
  const valorLimpo = (campo) => String(campo ? campo.value : '').toUpperCase().replace(/[^0-9A-Z]/g, '');
  const valorConfere = (campo, esperado) => valorLimpo(campo) === String(esperado).toUpperCase();

  const setterValor = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;

  function definirValor(campo, valor) {
    setterValor.call(campo, valor);
    campo.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: valor }));
    campo.dispatchEvent(new Event('change', { bubbles: true }));
  }

  // Apaga TODO o conteúdo do campo (o identificador anterior) e confere que ficou vazio. Usa
  // seleção + apagar (como Ctrl+A, Delete) e o valor vazio pelo caminho nativo, com os eventos
  // que a máscara do site escuta. Devolve true se o campo ficou vazio.
  async function limparCampo(campo, { ctrl } = {}) {
    for (let tentativa = 0; tentativa < 3; tentativa++) {
      if (ctrl) await ctrl.checkpoint();
      campo.focus({ preventScroll: true });
      try { campo.select(); } catch (e) { /* campo sem seleção */ }
      const base = { key: 'Delete', code: 'Delete', bubbles: true, cancelable: true, composed: true };
      campo.dispatchEvent(new KeyboardEvent('keydown', base));
      setterValor.call(campo, '');
      campo.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'deleteContentBackward', data: null }));
      campo.dispatchEvent(new KeyboardEvent('keyup', base));
      campo.dispatchEvent(new Event('change', { bubbles: true }));
      await util.dormir(250);
      if (!valorLimpo(campo)) return true;
    }
    return !valorLimpo(campo);
  }

  function codigoTecla(ch) {
    if (/[0-9]/.test(ch)) return `Digit${ch}`;
    if (/[a-z]/i.test(ch)) return `Key${ch.toUpperCase()}`;
    return '';
  }

  // Digita tecla por tecla, como uma pessoa, no ritmo do perfil de velocidade. Limpa o campo
  // antes. Os eventos de teclado servem às máscaras do site (que reformatam o valor).
  async function digitar(campo, texto, { ctrl } = {}) {
    const P = S.Mouse.perfil();
    campo.focus({ preventScroll: true });
    definirValor(campo, '');
    await util.dormir(util.aleatorioEm(P.pausaDigitar));
    for (const ch of String(texto)) {
      if (ctrl) await ctrl.checkpoint();
      const base = { key: ch, code: codigoTecla(ch), bubbles: true, cancelable: true, composed: true };
      const seguir = campo.dispatchEvent(new KeyboardEvent('keydown', base));
      campo.dispatchEvent(new KeyboardEvent('keypress', { ...base, charCode: ch.charCodeAt(0) }));
      if (seguir) {
        // Respeita máscara que já tenha reformatado o valor e posição do cursor no fim.
        setterValor.call(campo, campo.value + ch);
        campo.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: ch }));
      }
      campo.dispatchEvent(new KeyboardEvent('keyup', base));
      await util.dormir(util.aleatorioEm(P.tecla));
    }
    campo.dispatchEvent(new Event('change', { bubbles: true }));
  }

  // ---- Resposta da pesquisa --------------------------------------------------------------------

  function instantaneoResposta() {
    const modais = [...document.querySelectorAll('.modal, [role="dialog"], [class*="swal"], [class*="toast"], .alert')].filter(D.visivel).length;
    return {
      href: location.href,
      texto: (document.body ? document.body.innerText : '').length,
      tabelas: document.querySelectorAll('table tr').length,
      modais,
      paginas: [...document.querySelectorAll('[id$="Page"]')].filter(D.visivel).map((e) => e.id).join(','),
      tabelaAss: S.Emissao ? S.Emissao.assinaturaTabela() : null, // conteúdo da tabela de resultado
    };
  }

  // Espera a primeira reação visível ao clique em "Pesquisar". Não lê nem interpreta o
  // resultado (próxima etapa do projeto): só descreve o tipo de mudança.
  async function aguardarResposta(antes, { ctrl, limite = Q.esperaRespostaPesquisa } = {}) {
    const fim = Date.now() + limite;
    let viuCarregando = false;
    for (;;) {
      await ctrl.checkpoint();
      if (S.Login.modalLoginNecessario()) return { tipo: 'login_necessario', descricao: 'o portal pediu login ("Necessário estar logado")' };
      const carregando = D.carregando();
      viuCarregando = viuCarregando || carregando;
      const agora = instantaneoResposta();
      if (!carregando && antes) {
        const mud = [];
        if (agora.href !== antes.href) mud.push('a página mudou de endereço');
        if (agora.modais > antes.modais) mud.push('apareceu um aviso/janela na tela');
        if (agora.tabelas !== antes.tabelas) mud.push(`tabela com ${agora.tabelas} linhas na tela`);
        else if (agora.tabelaAss !== antes.tabelaAss) mud.push('tabela de resultado atualizada');
        if (agora.paginas !== antes.paginas) mud.push('nova área da página');
        if (Math.abs(agora.texto - antes.texto) > 40) mud.push('o conteúdo da página mudou');
        if (mud.length) {
          await D.esperarEstabilidade({ ctrl, quieto: 600, limite: 8000 });
          return { tipo: 'mudanca', descricao: mud.join('; ') };
        }
      }
      if (Date.now() >= fim) return { tipo: 'sem_mudanca', descricao: viuCarregando ? 'o sistema carregou, mas a tela não mudou de forma reconhecível' : 'nenhuma mudança visível' };
      await util.dormir(300);
    }
  }

  // ---- Diagnóstico -------------------------------------------------------------------------------

  // Resumo curto do que está na tela (títulos grandes, botões, opções, campos), para os
  // registros quando algo não é encontrado. Sem valores digitados.
  function mapaDiagnostico() {
    const corta = (s) => String(s || '').replace(/\s+/g, ' ').trim().slice(0, 40);
    const titulos = [...document.querySelectorAll('h1,h2,h3,h4,div,span')].filter((e) => !e.children.length && D.visivel(e) && tamanhoFonte(e) >= 20).map((e) => corta(e.textContent)).filter(Boolean).slice(0, 5);
    const botoes = [...document.querySelectorAll('button, [role="button"], input[type="submit"]')].filter(D.visivel).map((b) => corta(b.textContent || b.value)).filter(Boolean).slice(0, 8);
    const radios = [...document.querySelectorAll('input[type="radio"]')].map((r) => corta(rotuloDoRadio(r))).slice(0, 6);
    const campos = camposDeTexto().map((i) => corta(i.getAttribute('placeholder') || i.name || i.id)).slice(0, 5);
    return `títulos: [${titulos.join(' | ')}]; botões: [${botoes.join(' | ')}]; opções: [${radios.join(' | ')}]; campos: [${campos.join(' | ')}]`;
  }

  S.Consulta = {
    telaCertidoes, telaCertidaoNegativa, blocoCertidaoNegativa, diagnosticoCertidaoNegativa, opcaoTipo, tipoMarcado,
    campoPesquisa, botaoPesquisar, digitar, definirValor, valorConfere, valorLimpo, limparCampo,
    instantaneoResposta, aguardarResposta, mapaDiagnostico, comTextoExato,
  };
})(globalThis);
