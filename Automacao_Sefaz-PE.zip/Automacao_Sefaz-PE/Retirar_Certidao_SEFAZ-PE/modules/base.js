// Namespace SEFAZPE (content scripts), configuração e utilitários comuns.
//
// Toda informação "da página" (seletores, textos, tempos) fica aqui, em CONFIG. Se o
// portal mudar, ajuste primeiro este arquivo. Os seletores foram conferidos no portal
// real em 18/11/2026 (página inicial pública):
//   - Título da seção: <div class="psfz-titulo1"><span class="title-home">Acesso Rápido</span>
//   - Blocos: <div class="menu-card" ng-click="goTo(item)"> com <div class="title-service">
//   - Sessão: <div class="psfz-container-logged" ng-show="showLogOut"> (visível só logado)
//   - Aviso sem login após o clique: <div id="modal_alertaLogin"> "Necessário estar logado"
//   - Bloco Certidões: item.form = "frm_psfz_cert_index" (exige login: código SCA_0002)

(function (raiz) {
  'use strict';

  const CONST = raiz.SEFAZPE_CONST;

  const CONFIG = Object.freeze({
    PREFIXO_LOG: '[Retirar_Certidao_SEFAZ-PE]',

    PORTAL: Object.freeze({
      origem: CONST.ORIGEM_PORTAL,
      caminhoPaginaInicial: 'frm_psfz_home',
      formInicial: 'frm_psfz_default',
      formCertidoes: 'frm_psfz_cert_index',
    }),

    // Textos já normalizados (sem acento, minúsculos, espaços simples).
    TEXTOS: Object.freeze({
      acessoRapido: 'acesso rapido',
      certidoes: 'certidoes',
      voltar: 'voltar',
    }),

    SELETORES: Object.freeze({
      tituloSecao: '.psfz-titulo1, .title-home, h1, h2, h3, h4',
      card: '.menu-card, [ng-click^="goTo("]',
      tituloCard: '.title-service',
      areaLogado: '.psfz-container-logged',
      botaoLogin: '.psfz-btn-login',
      cabecalho: '.psfz-container-header',
      // Caminho das páginas depois do login gov.br (a pública é /lowcode/public/...).
      caminhoAutenticado: '/portalsefaz/',
      modalLoginNecessario: '#modal_alertaLogin',
      modalPrimeiroAcesso: '#modal_alertaPrimeiroAcesso',
      paginaForm: '[id$="Page"]',
      carregando: '.hyper-initial-loading, .hyper-loading, .hyper-loading-block',
    }),

    LOGIN: Object.freeze({
      // Conferido no portal: sem sessão, o clique em "Certidões" abre "Necessário estar logado".
      obrigatorioParaCertidoes: true,
      intervaloVerificacao: 1500,
      leiturasConfirmacao: 2,
      limiteAvaliacao: 10000,
      // Esperar você no gov.br NÃO tem limite que vire erro: a cada "lembreteEspera" a
      // automação só registra que continua aguardando.
      lembreteEspera: 5 * 60 * 1000,
      // true: sem sessão, a automação clica sozinha em "Login com gov.br" (e, no gov.br, em
      // "Autorizar" do e-Fisco). false: volta ao modo antigo, em que você faz o login.
      acionarLoginAutomaticamente: true,
    }),

    // Páginas do caminho de login (conferidas nas imagens enviadas em 18/11/2026).
    GOVBR: Object.freeze({
      hostsGovBr: ['sso.acesso.gov.br', 'certificado.sso.acesso.gov.br'],
      hostCertificado: 'certificado.sso.acesso.gov.br',
      // Opção da tela de identificação (o texto exato; "... em nuvem" é outra opção).
      textoOpcaoCertificado: 'seu certificado digital',
      maxCliquesCertificado: 2,
      // Depois do clique, tempo sem mudança na página até lembrar você de conferir a janela
      // de certificados do Chrome (ela pode ter ficado atrás da janela do navegador).
      lembreteCertificado: 45000,
      hostsSsoSefaz: ['sso.transdigital.ati.pe.gov.br'],
      textoTituloAutorizacao: 'autorizacao para compartilhamento de dados pessoais',
      textosServico: ['e-fisco', 'sefaz pe'],
      textoBotaoAutorizar: 'autorizar',
      textoBotaoNegar: 'negar',
      textoIdentifiquese: 'identifique-se no gov.br',
      seletorCampoCpf: '#accountId, input[name="accountId"]',
      seletoresCaptcha: 'iframe[src*="hcaptcha"], iframe[src*="recaptcha"], .h-captcha, .g-recaptcha, iframe[title*="captcha" i]',
      // false: a automação para na tela de autorização e espera você decidir.
      autorizarAutomaticamente: true,
      intervaloLeitura: 1000,
      esperaHabilitar: 20000,
      esperaNavegacaoLogin: 8000,
      intervaloEntreAutorizacoes: 15000,
      maxCliquesLogin: 2,
      maxCliquesAutorizar: 2,
      avisoRedirecionamentoParado: 30000,
    }),

    TEMPOS: Object.freeze({
      paginaPronta: 30000,
      intervalo: 250,
      estabilidadeDom: 700,
      limiteEstabilidade: 12000,
      aguardarNavegacao: 20000,
      extensaoPorCarregamento: 30000,
      pausaAntesDoClique: [250, 600],
      pausaAposPosicionar: [300, 650],
    }),

    ROLAGEM: Object.freeze({
      maxPassos: 30,
      fracaoPasso: [0.35, 0.6],
      duracaoPasso: [280, 520],
      pausaEntrePassos: [120, 320],
      esperaConteudoDinamico: 1500,
      maxFundoSemCrescer: 2,
      margemTopo: 0.16,
      maxAjustes: 12,
    }),

    MOUSE: Object.freeze({
      ativo: true,
      cor: '#1351b4',
      tremor: 1.2,
      chanceCorrecao: 0.5,
      distanciaParaCorrecao: 220,
      bloqueioRepeticao: 4000,
      perfilPadrao: 'lento',
      // Perfis de velocidade (escolhidos na interface, no popup ou no terminal). Todas as
      // etapas usam o mesmo perfil. Tempos em ms. "rapido" equivale ao comportamento da 0.2.0
      // (que você achou rápido demais); "lento" é o padrão.
      //   duracao*/fitts*  tempo de cada movimento (lei de Fitts, limitada)
      //   pausaAntes       parada antes de começar a mover (olhar o alvo)
      //   pausaClique      parada com o cursor sobre o alvo, antes de apertar
      //   botao            tempo com o botão apertado
      //   distanciaPausa   acima disso, o movimento é feito em dois trechos com uma hesitação
      //   escalaRolagem    multiplica a duração das rolagens
      //   tecla            intervalo entre teclas ao digitar um identificador
      //   pausaDigitar     parada entre clicar no campo e começar a digitar
      PERFIS: Object.freeze({
        lento: Object.freeze({ fittsA: 520, fittsB: 300, duracaoMin: 950, duracaoMax: 2600, intervaloQuadro: [14, 24], pausaAntes: [220, 500], pausaClique: [400, 800], botao: [90, 170], hesitacao: [120, 240], distanciaPausa: 420, correcao: [220, 340], escalaRolagem: 1.5, tecla: [90, 190], pausaDigitar: [300, 600] }),
        normal: Object.freeze({ fittsA: 340, fittsB: 210, duracaoMin: 600, duracaoMax: 1800, intervaloQuadro: [13, 22], pausaAntes: [150, 380], pausaClique: [300, 600], botao: [75, 150], hesitacao: [80, 180], distanciaPausa: 560, correcao: [160, 280], escalaRolagem: 1.25, tecla: [60, 130], pausaDigitar: [200, 400] }),
        rapido: Object.freeze({ fittsA: 200, fittsB: 130, duracaoMin: 340, duracaoMax: 1100, intervaloQuadro: [12, 20], pausaAntes: [60, 180], pausaClique: [200, 420], botao: [60, 120], hesitacao: [0, 0], distanciaPausa: Infinity, correcao: [120, 200], escalaRolagem: 1, tecla: [40, 90], pausaDigitar: [120, 250] }),
      }),
    }),

    // Páginas de Certidões e da consulta de Certidão Negativa (das imagens de 18/11/2026; a
    // estrutura HTML dessas telas só existe com login e ainda não foi vista: a identificação é
    // por texto exato e pela estrutura, nunca por coordenadas).
    CONSULTA: Object.freeze({
      tituloCertidoes: 'certidoes',
      // Blocos que confirmam a página de Certidões (bastam 3 visíveis).
      blocosCertidoes: ['certidao de cadastro', 'consultar autenticidade', 'certidao de baixa', 'certidao de regularidade fiscal', 'certidao negativa', 'certidao de recolhimento'],
      tituloNegativa: 'certidao negativa',
      rotulosTipo: Object.freeze({ CNPJ: ['cnpj'], CPF: ['cpf'], IE: ['inscricao estadual'] }),
      textoBotaoPesquisar: 'pesquisar',
      placeholderPesquisa: /pesquise pelo|pesquisar pelo|informe o|digite o/,
      esperaTela: 30000,
      esperaAtualizacaoCampo: 3000,
      esperaRespostaPesquisa: 45000,
      maxCliquesNegativa: 2,
    }),

    // Emissão (0.5.0). Estrutura REAL lida na tela logada em 18/11/2026 (árvore de
    // acessibilidade do Chrome):
    //   table.tabela-arredondada  cabeçalho: CPF/CNPJ | Inscrição Estadual | Nome/Razão Social
    //   button.button.button-primary  "Emitir Certidão (N)"   (N muda com a quantidade)
    //   confirmação: "Certidão emitida com sucesso!"
    //     button#avancarBtn   " Imprimir Certidão"   (NUNCA clicado; correção de 18/11/2026)
    //     button#idFecharModal " Visualizar Certidão" (é o botão usado para abrir o documento)
    EMISSAO: Object.freeze({
      colunasResultado: Object.freeze({ documento: ['cpf/cnpj', 'cnpj/cpf', 'cnpj', 'cpf'], ie: ['inscricao estadual'], nome: ['nome/razao social', 'razao social', 'nome'] }),
      textoEmitir: /^emitir certidao(?:\s*\(\s*(\d+)\s*\))?$/,
      textoSucesso: 'certidao emitida com sucesso',
      textoImprimir: 'imprimir certidao',
      idImprimir: 'avancarBtn',
      textoVisualizar: 'visualizar certidao',
      idVisualizar: 'idFecharModal',
      esperaCarregarDocumento: 45000, // até o documento (aba/quadro/PDF) carregar
      esperaGerarPdfDeHtml: 12000,    // sem PDF original: espera antes de gerar o PDF da página
      textosSemResultado: ['nenhum registro', 'nenhum resultado', 'nao encontrado', 'nao foram encontrados', 'nao localizado', 'nao existe', 'sem resultado'],
      textosErro: ['erro', 'nao foi possivel', 'falha', 'indisponivel', 'tente novamente', 'pendencia', 'nao e possivel'],
      esperaResultado: 20000,
      esperaConfirmacao: 90000,      // a emissão pode demorar; espera controlada, SEM repetir
      estabilizarDocumento: [2500, 4000], // "aguardar alguns segundos" antes de Imprimir
      esperaArquivo: 90000,          // do clique em Imprimir até o PDF salvo na pasta
      janelaCaptura: 120000,         // por quanto tempo a captura fica armada após o clique
    }),

    RECUPERACAO: Object.freeze({
      tentativasPorEtapa: 3,
      esperaBase: 1200,
      esperaMax: 8000,
      maxRecargas: 2,
      maxCliques: 2,
      maxRepeticoesPorCarregamento: 1,
    }),
  });

  const dormir = (ms) => new Promise((r) => setTimeout(r, Math.max(0, ms)));
  const aleatorio = (min, max) => min + Math.random() * (max - min);
  const aleatorioEm = (par) => aleatorio(par[0], par[1]);
  const limitar = (v, min, max) => Math.min(max, Math.max(min, v));

  // "Certidões " -> "certidoes": sem acento, minúsculo, espaços simples.
  function normalizar(texto) {
    return String(texto || '')
      .normalize('NFD')
      .replace(/[̀-ͯ]/g, '')
      .replace(/[​-‍⁠﻿­]/g, '') // caracteres invisíveis (largura zero, hífen suave)
      .replace(/\s+/g, ' ')
      .trim()
      .toLowerCase();
  }

  // Descrição curta de um elemento para logs (sem conteúdo do usuário).
  function descrever(el) {
    if (!el || !el.tagName) return '(nenhum)';
    const id = el.id ? '#' + el.id : '';
    const cls = typeof el.className === 'string' && el.className.trim()
      ? '.' + el.className.trim().split(/\s+/).slice(0, 2).join('.')
      : '';
    return el.tagName.toLowerCase() + id + cls;
  }

  // Recria o namespace a cada injeção (após recarregar a extensão, o mundo isolado pode
  // manter variáveis antigas; os módulos novos substituem as referências).
  raiz.SEFAZPE = {
    CONST,
    CONFIG,
    util: { dormir, aleatorio, aleatorioEm, limitar, normalizar, descrever },
  };
})(globalThis);
