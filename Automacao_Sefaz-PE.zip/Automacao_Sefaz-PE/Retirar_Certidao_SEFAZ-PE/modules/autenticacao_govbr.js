// Autenticação pelo gov.br: identifica em que página do caminho de login a aba está e
// localiza os DOIS únicos botões em que a automação pode clicar:
//   - "Login com gov.br" no cabeçalho do portal SEFAZ-PE;
//   - "Autorizar" na tela "Autorização para compartilhamento de Dados Pessoais" do gov.br,
//     SOMENTE quando o serviço indicado for "e-Fisco - Sefaz PE".
//
// Nunca digita CPF, senha ou código, nunca toca em CAPTCHA, certificado, aplicativo ou em
// "Negar". Em qualquer outra página do gov.br/SSO, só observa e espera a pessoa concluir.
// O caminho de páginas NÃO é fixo: a cada leitura a página é classificada de novo.

(function (raiz) {
  'use strict';

  const S = raiz.SEFAZPE;
  const { CONFIG, util } = S;
  const G = CONFIG.GOVBR;
  const SEL = CONFIG.SELETORES;
  const D = S.Detector;

  const host = () => location.hostname.toLowerCase();
  const ehGovBr = () => G.hostsGovBr.includes(host());
  const ehSsoSefaz = () => G.hostsSsoSefaz.includes(host());

  function ehDominioAutenticacao() {
    return ehGovBr() || ehSsoSefaz();
  }

  function textoPagina() {
    return util.normalizar(document.body ? document.body.innerText : '');
  }

  // Botões/links clicáveis com texto exato (normalizado), visíveis e fora de avisos ocultos.
  function botoesComTexto(texto) {
    return [...document.querySelectorAll('button, input[type="submit"], input[type="button"], a, [role="button"]')]
      .filter((el) => util.normalizar(el.tagName === 'INPUT' ? el.value : el.textContent) === texto && D.visivel(el));
  }

  function captchaVisivel() {
    return [...document.querySelectorAll(G.seletoresCaptcha)].some(D.visivel);
  }

  // ---- Classificação da página -------------------------------------------------------------
  //
  // Devolve { tipo, descricao, evidencias } com tipo em:
  //   autorizacao          tela de compartilhamento de dados (serviço e-Fisco confirmado)
  //   autorizacao_outro    tela de compartilhamento, mas de OUTRO serviço (não clicar)
  //   verificacao          CAPTCHA ou verificação adicional visível
  //   login_govbr          tela de identificação do gov.br (CPF, senha, banco, QR, certificado...)
  //   govbr_outra          outra página do gov.br (código, aplicativo, erro...)
  //   sso_sefaz            redirecionamento pelo SSO da SEFAZ (sso.transdigital...)
  //   fora                 não é página de autenticação
  function identificarPagina() {
    if (!ehDominioAutenticacao()) return { tipo: 'fora', descricao: 'fora do gov.br', evidencias: [] };
    if (ehSsoSefaz()) {
      return { tipo: 'sso_sefaz', descricao: 'SSO da SEFAZ-PE (redirecionamento)', evidencias: [host()] };
    }

    const texto = textoPagina();
    const evidencias = [host() + location.pathname];

    if (host() === G.hostCertificado) {
      return { tipo: 'certificado_govbr', descricao: 'autenticação por certificado digital (gov.br)', evidencias };
    }

    if (captchaVisivel()) {
      return { tipo: 'verificacao', descricao: 'verificação de segurança (CAPTCHA)', evidencias: [...evidencias, 'CAPTCHA visível'] };
    }

    if (texto.includes(G.textoTituloAutorizacao)) {
      evidencias.push('título "Autorização para compartilhamento de Dados Pessoais"');
      const servicoOk = G.textosServico.every((t) => texto.includes(t));
      if (!servicoOk) return { tipo: 'autorizacao_outro', descricao: 'autorização de OUTRO serviço', evidencias };
      evidencias.push('serviço "e-Fisco - Sefaz PE"');
      return { tipo: 'autorizacao', descricao: 'autorização de compartilhamento (e-Fisco - Sefaz PE)', evidencias };
    }

    const campoCpf = document.querySelector(G.seletorCampoCpf);
    const senha = document.querySelector('input[type="password"]');
    if (location.pathname.startsWith('/login') || D.visivel(campoCpf) || texto.includes(G.textoIdentifiquese)) {
      return { tipo: 'login_govbr', descricao: 'identificação no gov.br (CPF, banco, QR code ou certificado)', evidencias };
    }
    if (D.visivel(senha)) {
      return { tipo: 'login_govbr', descricao: 'senha do gov.br', evidencias: [...evidencias, 'campo de senha'] };
    }
    return { tipo: 'govbr_outra', descricao: 'outra etapa do gov.br (código, aplicativo ou mensagem)', evidencias };
  }

  // ---- Botões ------------------------------------------------------------------------------------

  // "Login com gov.br" do cabeçalho do portal: visível, fora de avisos, dentro de um link que
  // leva ao SSO da SEFAZ. Devolve { botao, link } ou null.
  function botaoLoginPortal() {
    const candidatos = [...document.querySelectorAll(SEL.botaoLogin)]
      .filter((b) => !b.closest('.modal') && D.visivel(b) && /login com gov ?\.?br/.test(D.textoNormalizado(b)));
    for (const botao of candidatos) {
      const link = botao.closest('a[href]');
      let destinoOk = false;
      try {
        destinoOk = !!link && G.hostsSsoSefaz.concat(G.hostsGovBr).includes(new URL(link.href).hostname);
      } catch (e) {
        destinoOk = false;
      }
      if (destinoOk) return { botao, link };
    }
    return null;
  }

  // "Autorizar" na tela de compartilhamento. Exige exatamente um botão com esse texto e que
  // a página tenha também "Negar" (confirma que é a tela de decisão). Nunca devolve "Negar".
  function botaoAutorizar() {
    const autorizar = botoesComTexto(G.textoBotaoAutorizar);
    if (autorizar.length !== 1) return { botao: null, motivo: `${autorizar.length} botões "Autorizar" visíveis` };
    if (!botoesComTexto(G.textoBotaoNegar).length) return { botao: null, motivo: 'o botão "Negar" não está visível (não parece a tela de decisão)' };
    return { botao: autorizar[0], motivo: null };
  }

  // Opção "Seu certificado digital" da tela de identificação do gov.br (texto exato; não
  // confunde com "Seu certificado digital em nuvem"). Devolve o elemento clicável ou null.
  function opcaoCertificadoDigital() {
    const textos = [...document.querySelectorAll('a, button, [role="button"], li, label, span, div')]
      .filter((el) => util.normalizar(el.textContent) === G.textoOpcaoCertificado && D.visivel(el));
    // O mais interno com esse texto; depois sobe até o elemento clicável que o contém.
    const interno = textos.find((el) => !textos.some((o) => o !== el && el.contains(o)));
    if (!interno) return null;
    const clicavel = interno.closest('a[href], button, [role="button"], [onclick]');
    return clicavel && D.visivel(clicavel) && util.normalizar(clicavel.textContent) === G.textoOpcaoCertificado ? clicavel : interno;
  }

  // O botão "Autorizar" está na página, mesmo fora da área visível (para decidir se rola).
  function autorizarNoDom() {
    return [...document.querySelectorAll('button, input[type="submit"], a, [role="button"]')]
      .find((el) => util.normalizar(el.tagName === 'INPUT' ? el.value : el.textContent) === G.textoBotaoAutorizar && !el.closest('.ng-hide')) || null;
  }

  S.GovBr = {
    ehDominioAutenticacao, ehGovBr, ehSsoSefaz, identificarPagina,
    botaoLoginPortal, botaoAutorizar, autorizarNoDom, opcaoCertificadoDigital,
  };
})(globalThis);
