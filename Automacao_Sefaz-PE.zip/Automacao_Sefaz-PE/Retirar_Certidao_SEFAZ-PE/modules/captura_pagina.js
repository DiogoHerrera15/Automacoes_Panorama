// Roda no MUNDO DA PÁGINA (manifest: "world": "MAIN"), só no portal da SEFAZ-PE, desde o
// início do carregamento. Serve para descobrir O QUE o botão "Imprimir Certidão" faz e pegar
// o PDF, qualquer que seja o caminho que o site usa:
//   - gera o PDF na página (Blob + URL.createObjectURL) e abre/baixa/imprime esse blob;
//   - abre o documento numa aba nova (window.open) ou num link;
//   - embute o documento num quadro (iframe/embed/object) — inclusive em base64 (data:);
//   - chama window.print().
//
// Fica PASSIVO até a extensão armar a captura (evento "sefazpe:captura-armar", disparado pelo
// content script imediatamente antes do clique em "Imprimir Certidão") e só durante o tempo
// armado. Não bloqueia nem altera nada do site: as funções originais continuam sendo chamadas.
// Comunicação com o content script: eventos com texto JSON (não há outra ponte entre os mundos).

(function () {
  'use strict';
  if (window.__sefazpeCaptura) return;
  window.__sefazpeCaptura = true;

  const LIMITE = 15 * 1024 * 1024;
  let armadoAte = 0;
  const armado = () => Date.now() < armadoAte;
  const blobs = new Map(); // url "blob:" → Blob (os últimos 20 criados)
  const enviados = new WeakSet();
  const urlsEnviadas = new Set();

  const enviar = (item) => {
    try { window.dispatchEvent(new CustomEvent('sefazpe:captura-item', { detail: JSON.stringify(item) })); } catch (e) { /* nada */ }
  };
  const semConsulta = (u) => String(u || '').replace(/[?#].*$/, '');

  window.addEventListener('sefazpe:captura-armar', (ev) => {
    try {
      const d = JSON.parse(ev.detail || '{}');
      armadoAte = Date.now() + Math.min(Math.max(Number(d.ms) || 0, 0), 300000);
      urlsEnviadas.clear();
    } catch (e) { /* nada */ }
  });

  function lerBase64(blob) {
    return new Promise((resolve, reject) => {
      const r = new FileReader();
      r.onload = () => resolve(String(r.result).replace(/^data:[^,]*,/, ''));
      r.onerror = () => reject(r.error);
      r.readAsDataURL(blob);
    });
  }

  const pareceDocumento = (b) => b && (b.type === '' || /pdf|octet-stream|binary|force-download/i.test(b.type));

  async function enviarBlob(blob, via, origem) {
    if (!blob || enviados.has(blob)) return;
    enviados.add(blob);
    if (blob.size > LIMITE) { enviar({ via, origem, erro: `documento grande demais (${blob.size} bytes)` }); return; }
    try {
      const b64 = await lerBase64(blob);
      const inicio = atob(b64.slice(0, 8));
      if (!inicio.startsWith('%PDF')) { enviar({ via, origem, naoPdf: true, tipo: blob.type || '?' }); return; }
      enviar({ via, origem, base64: b64, tipo: blob.type || 'application/pdf', tamanho: blob.size });
    } catch (e) {
      enviar({ via, origem, erro: `não foi possível ler o documento (${e && e.message})` });
    }
  }

  // Um endereço apareceu depois do clique (aba nova, link, quadro): pega o documento.
  async function tratarEndereco(url, origem) {
    if (!armado() || !url) return;
    let s;
    try { s = new URL(String(url), location.href).href; } catch (e) { return; }
    if (urlsEnviadas.has(s)) return;
    urlsEnviadas.add(s);
    if (s.startsWith('blob:')) {
      const b = blobs.get(s);
      if (b) return enviarBlob(b, 'blob', origem);
      try { const r = await fetch(s); return enviarBlob(await r.blob(), 'blob', origem); } catch (e) { return; }
    }
    if (s.startsWith('data:')) {
      const m = s.match(/^data:([^;,]*)(;base64)?,(.*)$/s);
      if (!m || !m[2]) return;
      if (!/pdf|octet-stream/i.test(m[1] || '')) return;
      const b64 = decodeURIComponent(m[3]);
      if (!atob(b64.slice(0, 8)).startsWith('%PDF')) return;
      enviar({ via: 'data', origem, base64: b64, tipo: m[1] || 'application/pdf', tamanho: Math.floor(b64.length * 0.75) });
      return;
    }
    if (/^https?:/i.test(s)) enviar({ via: 'url', origem, url: s, urlSegura: semConsulta(s) });
  }

  // 1. PDF gerado na página.
  const criarUrl = URL.createObjectURL;
  URL.createObjectURL = function (obj) {
    const u = criarUrl.apply(this, arguments);
    try {
      if (obj instanceof Blob) {
        blobs.set(u, obj);
        if (blobs.size > 20) blobs.delete(blobs.keys().next().value);
        if (armado() && pareceDocumento(obj)) enviarBlob(obj, 'blob', 'URL.createObjectURL');
      }
    } catch (e) { /* nada */ }
    return u;
  };

  // 2. Aba nova.
  const abrir = window.open;
  window.open = function (url) {
    try {
      if (armado()) {
        enviar({ via: 'evento', evento: 'window.open', urlSegura: semConsulta(url) });
        tratarEndereco(url, 'window.open');
      }
    } catch (e) { /* nada */ }
    return abrir.apply(this, arguments);
  };

  // 3. Janela de impressão.
  const imprimir = window.print;
  window.print = function () {
    try { if (armado()) enviar({ via: 'evento', evento: 'print' }); } catch (e) { /* nada */ }
    return imprimir.apply(this, arguments);
  };

  // 4. Links (clicados pela pessoa/site, ou criados e clicados por código).
  const clicarLink = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function () {
    try {
      if (armado() && this.href) {
        enviar({ via: 'evento', evento: this.hasAttribute('download') ? 'link com download' : 'link', urlSegura: semConsulta(this.href) });
        tratarEndereco(this.href, 'link');
      }
    } catch (e) { /* nada */ }
    return clicarLink.apply(this, arguments);
  };
  document.addEventListener('click', (ev) => {
    try {
      if (!armado()) return;
      const a = ev.target && ev.target.closest ? ev.target.closest('a[href]') : null;
      if (a) tratarEndereco(a.href, 'link');
    } catch (e) { /* nada */ }
  }, true);

  // 5. Documento embutido num quadro.
  const ATRIBUTOS = ['src', 'data'];
  const verificarNo = (n) => {
    if (!n || n.nodeType !== 1) return;
    const t = n.tagName;
    if (t === 'IFRAME' || t === 'EMBED' || t === 'OBJECT') {
      for (const a of ATRIBUTOS) if (n.getAttribute(a)) tratarEndereco(n.getAttribute(a), t.toLowerCase());
    }
    if (n.querySelectorAll) n.querySelectorAll('iframe[src], embed[src], object[data]').forEach((f) => verificarNo(f));
  };
  const obs = new MutationObserver((lista) => {
    if (!armado()) return;
    for (const m of lista) {
      if (m.type === 'attributes') verificarNo(m.target);
      else m.addedNodes.forEach(verificarNo);
    }
  });
  obs.observe(document.documentElement || document, { subtree: true, childList: true, attributes: true, attributeFilter: ATRIBUTOS });
})();
