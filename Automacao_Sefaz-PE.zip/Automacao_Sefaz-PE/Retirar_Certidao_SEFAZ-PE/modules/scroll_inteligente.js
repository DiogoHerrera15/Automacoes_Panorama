// Rolagem progressiva e suave, com velocidade variável, pausas curtas e verificação do
// DOM depois de cada deslocamento. Tudo medido em pixels CSS da janela atual
// (getBoundingClientRect / innerHeight), então funciona com qualquer resolução e zoom.
//
// O movimento usa o relógio (setTimeout), não requestAnimationFrame: mesmo com a aba em
// segundo plano a rolagem termina e a automação não trava.

(function (raiz) {
  'use strict';

  const S = raiz.SEFAZPE;
  const { CONFIG, util } = S;
  const R = CONFIG.ROLAGEM;
  const D = S.Detector;

  const suavizar = (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);

  // A rolagem acompanha o perfil de velocidade do mouse (lento = rolagem mais calma).
  function escala() {
    try {
      return (S.Mouse && S.Mouse.perfil().escalaRolagem) || 1;
    } catch (e) {
      return 1;
    }
  }

  function alturaMaxima() {
    const r = document.scrollingElement || document.documentElement;
    return Math.max(0, r.scrollHeight - window.innerHeight);
  }

  function noFundo() {
    return window.scrollY >= alturaMaxima() - 2;
  }

  // Desloca "delta" pixels em "duracao" ms, com aceleração e desaceleração.
  async function rolarSuave(delta, duracao) {
    const inicio = window.scrollY;
    const destino = util.limitar(inicio + delta, 0, alturaMaxima());
    const total = destino - inicio;
    if (Math.abs(total) < 1) return 0;
    const t0 = performance.now();
    for (;;) {
      const t = Math.min(1, (performance.now() - t0) / duracao);
      window.scrollTo({ top: inicio + total * suavizar(t), behavior: 'instant' });
      if (t >= 1) break;
      await util.dormir(util.aleatorio(12, 22));
    }
    return window.scrollY - inicio;
  }

  // Espera a página crescer (conteúdo carregado sob demanda ao chegar no fim).
  async function esperarCrescimento() {
    const altura = alturaMaxima();
    const r = await D.esperar(() => alturaMaxima() > altura + 20, { limite: R.esperaConteudoDinamico, intervalo: 150 });
    return !!r;
  }

  // Rola para baixo aos poucos até `localizar()` devolver um elemento. Limite de passos e
  // de "chegadas ao fundo sem crescer" (impede rolagem infinita).
  async function rolarAteEncontrar(localizar, { ctrl, aoRolar } = {}) {
    let fundoSemCrescer = 0;
    for (let passo = 0; passo <= R.maxPassos; passo++) {
      await ctrl.checkpoint();
      const el = localizar();
      if (el) return { el, passos: passo };
      if (noFundo()) {
        if (await esperarCrescimento()) continue;
        fundoSemCrescer++;
        if (fundoSemCrescer >= R.maxFundoSemCrescer) return { el: null, passos: passo, motivo: 'fim da página' };
        continue;
      }
      const delta = window.innerHeight * util.aleatorioEm(R.fracaoPasso);
      await rolarSuave(delta, util.aleatorioEm(R.duracaoPasso) * escala());
      if (aoRolar) aoRolar(passo + 1);
      await util.dormir(util.aleatorioEm(R.pausaEntrePassos) * escala());
    }
    return { el: null, passos: R.maxPassos, motivo: 'limite de passos' };
  }

  // Traz o elemento para a área visível em movimentos parciais (nunca um salto).
  // posicao: 'topo' (um pouco abaixo do topo da janela) ou 'centro'.
  async function trazerParaVisao(el, { ctrl, posicao = 'centro' } = {}) {
    for (let i = 0; i < R.maxAjustes; i++) {
      await ctrl.checkpoint();
      if (!el.isConnected) return false;
      const r = el.getBoundingClientRect();
      const alto = r.height > window.innerHeight * 0.8;
      const alvoY = posicao === 'centro' && !alto ? (window.innerHeight - r.height) / 2 : window.innerHeight * R.margemTopo;
      const delta = r.top - alvoY;
      const bloqueado = (delta > 0 && noFundo()) || (delta < 0 && window.scrollY <= 0);
      if (Math.abs(delta) < 24 || bloqueado) break;
      const passoMax = window.innerHeight * util.aleatorio(0.55, 0.85);
      const mover = Math.sign(delta) * Math.min(Math.abs(delta), passoMax);
      const duracao = util.limitar(Math.abs(mover) * util.aleatorio(0.7, 1.0), 220, 650) * escala();
      await rolarSuave(mover, duracao);
      await util.dormir(util.aleatorio(90, 220) * escala());
    }
    // Reserva: se o elemento ainda não está visível (ex.: o próprio portal rolou para o topo
    // no meio do caminho), posiciona de uma vez. Usa window.scrollTo porque o portal roda em
    // modo "quirks" (BackCompat), onde scrollIntoView não rolou a página nos testes.
    if (el.isConnected && !D.naTela(el, 4)) {
      const r = el.getBoundingClientRect();
      const alvoY = posicao === 'topo' ? window.innerHeight * R.margemTopo : (window.innerHeight - r.height) / 2;
      window.scrollTo({ top: window.scrollY + r.top - alvoY, behavior: 'instant' });
      await util.dormir(150);
      if (!D.naTela(el, 4)) el.scrollIntoView({ block: posicao === 'topo' ? 'start' : 'center', inline: 'nearest', behavior: 'instant' });
    }
    return el.isConnected && D.naTela(el, Math.max(4, el.getBoundingClientRect().height - window.innerHeight));
  }

  S.Scroll = { rolarSuave, rolarAteEncontrar, trazerParaVisao, noFundo, alturaMaxima };
})(globalThis);
