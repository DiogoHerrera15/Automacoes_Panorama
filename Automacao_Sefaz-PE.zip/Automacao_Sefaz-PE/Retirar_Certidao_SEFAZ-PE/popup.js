// Popup: só mostra o estado (lido do chrome.storage) e envia comandos ao background.
// Nada da execução depende dele: pode fechar a qualquer momento.

(function () {
  'use strict';

  const K = globalThis.SEFAZPE_CONST;
  const $ = (id) => document.getElementById(id);

  let abaAtiva = null; // { id, url } da aba ativa (url só existe se for o portal)
  let estado = K.estadoInicial();

  const hora = (t) => new Date(t).toLocaleTimeString('pt-BR', { hour12: false });

  function linhaLog(l) {
    const partes = [l.acao];
    if (l.resultado) partes.push(`resultado: ${l.resultado}`);
    if (l.erro) partes.push(`erro: ${l.erro}`);
    if (l.tentativa) partes.push(`tentativa ${l.tentativa}`);
    if (l.recuperacao) partes.push(`recuperação: ${l.recuperacao}`);
    return `[${hora(l.t)}] ${partes.join(' · ')}`;
  }

  function abaEhPortal() {
    return !!(abaAtiva && K.urlDoPortal(abaAtiva.url));
  }

  function renderEstado() {
    const s = estado.status;
    $('chipStatus').textContent = K.STATUS[s] || s;
    $('chipStatus').dataset.s = s;
    $('mensagem').textContent = estado.mensagem || '—';
    $('indModo').textContent = estado.execId ? `${K.MODOS[estado.modo] || estado.modo} (pela ${estado.origem === 'interface' ? 'interface' : estado.origem === 'terminal' ? 'linha de comando' : 'extensão'})` : '—';
    $('indPagina').textContent = estado.statusPagina || '—';
    $('indLogin').textContent = estado.statusLogin || '—';
    const nomeEstado = K.ESTADOS_AUTOMACAO[K.estadoAutomacao(estado)];
    $('indEtapa').textContent = nomeEstado ? `${nomeEstado} — ${K.rotuloEtapa(estado.etapa)}` : K.rotuloEtapa(estado.etapa);
    $('indElemento').textContent = estado.elementoProcurado || '—';
    $('indAcao').textContent = estado.ultimaAcao || '—';
    $('indRecuperacoes').textContent = `${estado.tentativasRecuperacao || 0} (recargas: ${estado.recargas || 0})`;
    $('indErro').hidden = !estado.erro;
    $('indErro').textContent = estado.erro || '';

    const ativo = ['executando', 'aguardando_login'].includes(s);
    const retomavel = ['pausado', 'erro'].includes(s);
    $('btIniciar').disabled = ativo || retomavel || !abaEhPortal();
    $('btPausar').disabled = !ativo;
    $('btContinuar').disabled = !retomavel;
    $('btParar').disabled = !(ativo || retomavel);

    const mostrarAviso = !abaEhPortal() && !ativo;
    $('avisoAba').hidden = !mostrarAviso;
  }

  function renderLogs(logs) {
    const lista = $('listaLogs');
    lista.textContent = '';
    if (!logs.length) {
      const li = document.createElement('li');
      li.className = 'vazio';
      li.textContent = 'Nenhum registro ainda.';
      lista.appendChild(li);
      return;
    }
    logs.slice(-80).forEach((l) => {
      const li = document.createElement('li');
      li.className = l.nivel === 'erro' || (l.erro && l.nivel !== 'aviso') ? 'erro' : l.nivel === 'aviso' ? 'aviso' : '';
      li.textContent = linhaLog(l);
      lista.appendChild(li);
    });
    lista.scrollTop = lista.scrollHeight;
  }

  async function carregar() {
    const r = await chrome.storage.local.get([K.CHAVES.estado, K.CHAVES.logs]);
    estado = { ...K.estadoInicial(), ...(r[K.CHAVES.estado] || {}) };
    renderEstado();
    renderLogs(r[K.CHAVES.logs] || []);
  }

  async function enviar(comando, extra = {}) {
    $('retornoComando').textContent = '';
    try {
      const r = await chrome.runtime.sendMessage({ tipo: 'comando', comando, ...extra });
      if (r && r.ok === false && r.erro) $('retornoComando').textContent = r.erro;
      return r;
    } catch (e) {
      $('retornoComando').textContent = 'Erro de comunicação com a extensão: ' + e.message;
      return null;
    }
  }

  function exportarLogs() {
    chrome.storage.local.get(K.CHAVES.logs).then((r) => {
      const logs = r[K.CHAVES.logs] || [];
      const cab = `Retirar_Certidao_SEFAZ-PE — registros exportados em ${new Date().toLocaleString('pt-BR')}\n\n`;
      const texto = cab + logs.map((l) => `${new Date(l.t).toLocaleDateString('pt-BR')} ${linhaLog(l)} [etapa: ${K.rotuloEtapa(l.etapa)}]`).join('\n');
      const blob = new Blob([texto], { type: 'text/plain;charset=utf-8' });
      const a = document.createElement('a');
      const d = new Date();
      const p = (n) => String(n).padStart(2, '0');
      a.href = URL.createObjectURL(blob);
      a.download = `sefazpe_log_${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}_${p(d.getHours())}h${p(d.getMinutes())}.txt`;
      a.click();
      setTimeout(() => URL.revokeObjectURL(a.href), 2000);
    });
  }

  $('versao').textContent = 'v' + chrome.runtime.getManifest().version;

  $('btAjuda').addEventListener('click', () => {
    const p = $('painelAjuda');
    p.hidden = !p.hidden;
    $('btAjuda').setAttribute('aria-expanded', String(!p.hidden));
  });

  $('btIniciar').addEventListener('click', () => enviar('iniciar', { tabId: abaAtiva && abaAtiva.id, url: abaAtiva && abaAtiva.url }));
  $('btPausar').addEventListener('click', () => enviar('pausar'));
  $('btContinuar').addEventListener('click', () => enviar('continuar', { tabId: abaEhPortal() ? abaAtiva.id : undefined }));
  $('btParar').addEventListener('click', () => enviar('parar'));
  $('btLimpar').addEventListener('click', () => enviar('limpar_logs'));
  $('btExportar').addEventListener('click', exportarLogs);
  $('btAbrirPortal').addEventListener('click', () => chrome.tabs.create({ url: K.URL_INICIAL }));

  // Preferências (valem para as execuções iniciadas por aqui; a velocidade vale na hora).
  chrome.runtime.sendMessage({ tipo: 'preferencias:ler' }).then((p) => {
    if (p && p.velocidadeMouse) $('selVelocidade').value = p.velocidadeMouse;
    if (p && p.metodoLogin) $('selMetodo').value = p.metodoLogin;
  }).catch(() => {});
  const salvarPrefs = () => enviar('preferencias', { velocidadeMouse: $('selVelocidade').value, metodoLogin: $('selMetodo').value });
  $('selVelocidade').addEventListener('change', salvarPrefs);
  $('selMetodo').addEventListener('change', salvarPrefs);

  chrome.storage.onChanged.addListener((mud, area) => {
    if (area !== 'local') return;
    if (mud[K.CHAVES.estado]) {
      estado = { ...K.estadoInicial(), ...(mud[K.CHAVES.estado].newValue || {}) };
      renderEstado();
    }
    if (mud[K.CHAVES.logs]) renderLogs(mud[K.CHAVES.logs].newValue || []);
  });

  // A URL só vem preenchida para abas do portal (permissão de host); para as demais, fica vazia.
  chrome.tabs.query({ active: true, currentWindow: true }).then(([aba]) => {
    abaAtiva = aba ? { id: aba.id, url: aba.url || '' } : null;
    if (abaAtiva && !abaEhPortal()) {
      $('avisoAbaTexto').textContent = 'A aba ativa não é o Portal de Atendimento da SEFAZ-PE. Abra o portal e clique de novo no ícone da extensão.';
    }
    return carregar();
  });
})();
