// Fluxo da automação (roda nas páginas do portal SEFAZ-PE e do caminho de login gov.br).
//
// Etapas (constantes.js > ETAPAS):
//   verificar_portal → verificar_login ─(com sessão)──────────────────────────► confirmar_acesso
//                                     └(sem sessão)► acionar_login_govbr → autenticacao_govbr ┘
//   modo "acesso" (terminal): PARA após confirmar_acesso
//   modo "certidoes" (popup): → localizar_acesso_rapido → localizar_certidoes
//                             → clicar_certidoes → aguardar_proxima_tela → PARA
//
// Continuidade: o estado fica salvo fora da página. A cada página carregada (F5, ida e volta
// do gov.br, recarga de recuperação) este script lê o estado e retoma. Nas páginas do
// gov.br/SSO a retomada vai direto para "autenticacao_govbr", que reclassifica a página a
// cada leitura (o caminho de páginas não é fixo). Ações não repetíveis (cliques em
// "Login com gov.br", "Autorizar" e "Certidões") são contadas e não são refeitas sem motivo.

(function (raiz) {
  'use strict';

  const S = raiz.SEFAZPE;
  const { CONST, CONFIG, util } = S;
  const T = CONFIG.TEMPOS;
  const RC = CONFIG.RECUPERACAO;
  const G = CONFIG.GOVBR;
  const ctrl = S.Controle;
  const D = S.Detector;
  const Login = S.Login;
  const GovBr = S.GovBr;
  const Scroll = S.Scroll;
  const Mouse = S.Mouse;
  const Nav = S.Navegador;
  const Consulta = S.Consulta;
  const Q = CONFIG.CONSULTA;
  const { ErroAutomacao, ExecucaoInterrompida } = S;
  const { comTentativas } = S.Erros;

  const ctx = { titulo: null, secao: null, card: null, antes: null, loginExigidoPeloPortal: false };
  let rodando = false;

  const estado = () => ctrl.estado();

  // ---- Vigia de tempo por etapa (lista inteira, 0.6.1) -----------------------------------------
  // Cada etapa tem um prazo. Passou do prazo e a página NÃO está carregando nem esperando você
  // (login, certificado, PIN, CAPTCHA)? No próximo ponto de controle da etapa (entre ações, nunca
  // no meio de um clique), ela é encerrada com ETAPA_DEMORADA e entra na escada de recuperação.
  // Página ainda carregando: o prazo é prorrogado uma vez (pela metade).
  const checkpointOriginal = ctrl.checkpoint;
  ctrl.checkpoint = async function () {
    await checkpointOriginal.apply(ctrl, arguments);
    if (!ctx.prazo || Date.now() < ctx.prazo) return;
    if (estado().status === 'aguardando_login') { ctx.prazo = Date.now() + 30000; return; }
    if (D.carregando() && !ctx.prazoProrrogado) {
      ctx.prazoProrrogado = true;
      ctx.prazo = Date.now() + Math.round((ctx.prazoMs || 120000) / 2);
      return;
    }
    const s = Math.round((Date.now() - ctx.prazoInicio) / 1000);
    ctx.prazo = null;
    throw new ErroAutomacao('ETAPA_DEMORADA', `A etapa "${CONST.rotuloEtapa(ctx.prazoEtapa)}" passou de ${s} s sem concluir (página ${D.carregando() ? 'ainda carregando' : 'sem carregamento em andamento'}).`);
  };

  function armarPrazo(etapa) {
    const est = estado();
    const ms = est.lote ? S.Recuperacao.limiteDaEtapa(etapa, est.lote.limiteEtapaMs) : null;
    Object.assign(ctx, { prazo: ms ? Date.now() + ms : null, prazoMs: ms, prazoInicio: Date.now(), prazoEtapa: etapa, prazoProrrogado: false });
  }

  // ---- Etapas: portal e sessão -------------------------------------------------------------

  async function etapaVerificarPortal() {
    await ctrl.atualizar({ mensagem: 'Verificando portal SEFAZ-PE...', statusPagina: 'Verificando...', elementoProcurado: 'Página do portal' });
    await ctrl.log('Aguardando página inicial...', { tag: 'ACESSO' });
    if (GovBr.ehDominioAutenticacao()) return { irPara: 'autenticacao_govbr' };
    if (!Nav.ehPortal()) throw new ErroAutomacao('PORTAL_INCORRETO');

    // Pronta = elementos do portal aqui OU (no topo) um quadro interno com o portal: nesse
    // caso quem continua é o script daquele quadro, e este (o da "casca") para de agir.
    const pronta = await D.esperar(() => D.paginaPronta() || !Nav.devoAtuar(), { limite: T.paginaPronta, ctrl });
    if (pronta && !Nav.devoAtuar()) {
      await ctrl.log(`O conteúdo do portal está num quadro interno (${Nav.descreverQuadros()}); a automação continua dentro dele.`, { tag: 'ACESSO' });
      throw new ExecucaoInterrompida('Delegado ao quadro do portal.');
    }
    if (!pronta) {
      const s = D.sinaisDePagina();
      const sinais = `estado=${s.readyState}, carregando=${s.carregando ? 'sim' : 'não'}, formulário=${s.formulario ? 'sim' : 'não'}, cabeçalho=${s.cabecalho ? 'sim' : 'não'}, blocos=${s.blocos ? 'sim' : 'não'}`;
      throw new ErroAutomacao('PAGINA_SEM_RESPOSTA', `A página não terminou o carregamento inicial (${sinais}; ${Nav.enderecoSeguro()}${Nav.ehTopo() ? '' : ', dentro de um quadro'}; quadros: ${Nav.descreverQuadros()}).`);
    }
    await D.esperarEstabilidade({ ctrl });
    await ctrl.atualizar({ statusPagina: 'Carregada' });
    await ctrl.log(`Portal SEFAZ-PE carregado: ${Nav.enderecoSeguro()}.`, { resultado: 'ok', tag: 'ACESSO' });

    // Página inicial pelo endereço ou pelo conteúdo (dentro do quadro do portal logado o
    // endereço pode ser outro).
    if (Nav.ehPaginaInicial() || D.localizarTituloAcessoRapido()) return null;

    // Já está em Certidões ou na consulta de Certidão Negativa (o portal costuma voltar do
    // login direto para a última tela): segue, e "identificar_tela_sefaz" decide o caminho.
    if (Nav.telaCertidoes().confirmada || Consulta.telaCertidoes().confirmada || Consulta.telaCertidaoNegativa().confirmada) {
      await ctrl.log('O portal já está na área de Certidões; a tela será identificada depois da conferência do login.', { resultado: 'ok', tag: 'ACESSO' });
      return null;
    }

    // Outra tela do portal: volta à inicial uma única vez por execução.
    const usadas = estado().recuperacoesUsadas || {};
    if (!usadas.voltarInicio && Nav.voltarParaInicio()) {
      await ctrl.atualizar({ recuperacoesUsadas: { ...usadas, voltarInicio: true }, ultimaAcao: 'Voltando à página inicial do portal', tentativasRecuperacao: estado().tentativasRecuperacao + 1 });
      await ctrl.log('Página diferente da inicial: voltando à página inicial.', { recuperacao: 'voltar à página inicial', nivel: 'aviso' });
      await util.dormir(1500);
      return { irPara: 'verificar_portal' };
    }
    throw new ErroAutomacao('REDIRECIONAMENTO_INESPERADO', `A aba está em ${Nav.enderecoSeguro()}, e não na página inicial do portal.`);
  }

  async function etapaVerificarLogin() {
    await ctrl.atualizar({ mensagem: 'Verificando autenticação...', statusLogin: 'Verificando...', elementoProcurado: 'Indicadores de sessão' });
    await ctrl.log('Verificando se já existe sessão autenticada...', { tag: 'LOGIN' });
    const a = await Login.avaliarEstavel(ctrl);

    if (a.estado === 'autenticado' && !ctx.loginExigidoPeloPortal) {
      await ctrl.atualizar({ statusLogin: 'Autenticado', mensagem: 'Sessão autenticada encontrada.' });
      await ctrl.log(`Sessão já autenticada (${a.evidencia}); o login não será repetido.`, { resultado: 'ok', tag: 'LOGIN' });
      return { irPara: 'confirmar_acesso' };
    }
    if (a.estado === 'autenticado' && ctx.loginExigidoPeloPortal) {
      // Página diz "logado", mas o portal pediu login: sessão provavelmente expirada.
      throw new ErroAutomacao('SESSAO_EXPIRADA', 'O portal pediu login apesar de a página indicar sessão ativa. Atualize a página (F5) e clique em Continuar.');
    }
    if (a.estado === 'nao_autenticado') {
      if (!CONFIG.LOGIN.obrigatorioParaCertidoes && !ctx.loginExigidoPeloPortal && estado().modo === 'certidoes') {
        await ctrl.atualizar({ statusLogin: 'Sem login (não exigido)' });
        await ctrl.log('Sem login; o serviço está configurado como acessível sem autenticação.', { resultado: 'ok' });
        return { irPara: 'localizar_acesso_rapido' };
      }
      await ctrl.atualizar({ statusLogin: 'Sem sessão' });
      await ctrl.log(`Sem sessão autenticada (${a.evidencia}).`, { tag: 'LOGIN' });
      if (CONFIG.LOGIN.acionarLoginAutomaticamente) return null; // próxima: acionar_login_govbr
      await esperarLoginManual(a.evidencia);
      return { irPara: 'confirmar_acesso' };
    }
    // Indeterminado: só segue se a pessoa já conferiu e clicou em Continuar.
    if (estado().loginConfirmadoManual) {
      await ctrl.atualizar({ statusLogin: 'Confirmado manualmente' });
      await ctrl.log(`Autenticação indeterminada (${a.evidencia}); seguindo por confirmação manual.`, { nivel: 'aviso' });
      return { irPara: 'confirmar_acesso' };
    }
    throw new ErroAutomacao('LOGIN_INDETERMINADO', `Não foi possível confirmar o login (${a.evidencia}). Confira o portal e clique em Continuar.`);
  }

  // Modo antigo (CONFIG.LOGIN.acionarLoginAutomaticamente = false): a pessoa faz tudo.
  async function esperarLoginManual(evidencia) {
    await ctrl.atualizar({ status: 'aguardando_login', statusLogin: 'Aguardando login manual', mensagem: 'Aguardando login no portal SEFAZ-PE.', ultimaAcao: 'Navegação suspensa até o login' });
    await ctrl.log(`Login necessário (${evidencia}). Aguardando login manual pelo gov.br.`, { nivel: 'aviso', tag: 'LOGIN' });
    await Login.aguardarLogin(ctrl);
    ctx.loginExigidoPeloPortal = false;
    await ctrl.atualizar({ status: 'executando', statusLogin: 'Autenticado', mensagem: 'Login confirmado.' });
    await ctrl.log('Login confirmado. Retomando a navegação.', { resultado: 'ok', tag: 'LOGIN' });
  }

  // ---- Etapas: login gov.br ------------------------------------------------------------------

  async function etapaAcionarLoginGovBr() {
    const feitos = estado().loginAcionamentos || 0;
    if (feitos >= G.maxCliquesLogin) {
      throw new ErroAutomacao('LOGIN_NAO_CONCLUIDO', `O login pelo gov.br já foi acionado ${feitos} vezes e a sessão não foi confirmada. Confira a janela e clique em Continuar para uma nova tentativa.`);
    }
    await ctrl.atualizar({ mensagem: 'Procurando botão Login com gov.br...', elementoProcurado: 'Botão "Login com gov.br"' });
    await ctrl.log('Procurando botão Login com gov.br...', { tag: 'LOGIN' });

    const achado = await comTentativas('Localizar "Login com gov.br"', async () => {
      const a = GovBr.botaoLoginPortal();
      if (!a) throw new ErroAutomacao('ELEMENTO_NAO_ENCONTRADO', 'Botão "Login com gov.br" não encontrado no cabeçalho do portal.');
      if (!D.habilitado(a.botao)) {
        await ctrl.atualizar({ mensagem: 'Aguardando o botão Login com gov.br ficar disponível...' });
        const ok = await D.esperar(() => a.botao.isConnected && D.habilitado(a.botao), { limite: G.esperaHabilitar, ctrl });
        if (!ok) throw new ErroAutomacao('ELEMENTO_INVISIVEL', 'O botão "Login com gov.br" não ficou disponível.');
      }
      return a;
    }, { ctrl });

    let saiu = false;
    const marcarSaida = () => { saiu = true; };
    window.addEventListener('pagehide', marcarSaida, { once: true });
    window.addEventListener('beforeunload', marcarSaida, { once: true });

    Mouse.mostrar();
    await Mouse.clicar(achado.botao, {
      ctrl,
      aoPosicionar: async () => {
        await ctrl.atualizar({ mensagem: 'Movimentando até o botão Login com gov.br...', ultimaAcao: 'Movendo o cursor até "Login com gov.br"' });
        await ctrl.log('Posicionando cursor...', { tag: 'MOUSE' });
      },
      antesDoDisparo: async () => {
        await ctrl.atualizar({
          loginAcionamentos: (estado().loginAcionamentos || 0) + 1,
          loginAcionadoEm: Date.now(),
          autorizacaoCliques: 0,
          autorizacaoEm: null,
          mensagem: 'Abrindo o login do gov.br...',
          ultimaAcao: 'Clique em "Login com gov.br"',
        });
        await ctrl.log('Botão localizado. Realizando clique...', { tag: 'LOGIN' });
      },
    });

    let navegou = await D.esperar(() => saiu, { limite: G.esperaNavegacaoLogin, ctrl, intervalo: 150 });
    if (!navegou && achado.link && achado.link.isConnected) {
      // Reserva: o botão fica dentro de um link para o SSO; se o clique no botão não abriu o
      // link, ativa o próprio link (o mesmo destino do botão).
      await ctrl.log('O clique não iniciou o redirecionamento; ativando o link do botão.', { tag: 'LOGIN', nivel: 'aviso', recuperacao: 'ativar o link do botão' });
      achado.link.click();
      navegou = await D.esperar(() => saiu, { limite: G.esperaNavegacaoLogin, ctrl, intervalo: 150 });
    }
    if (!navegou) throw new ErroAutomacao('CLIQUE_SEM_RESULTADO', 'O clique em "Login com gov.br" não levou à página de autenticação.');
    await ctrl.atualizar({ mensagem: 'Redirecionando para o gov.br...' });
    // A página está saindo: este script termina com ela; a página seguinte retoma o fluxo.
    await ctrl.esperar(60000);
    throw new ErroAutomacao('REDIRECIONAMENTO_INESPERADO', 'A página não saiu do portal depois do clique em "Login com gov.br".');
  }

  const AVISOS_PAGINA = {
    autorizacao: { status: 'executando', tag: 'GOV.BR', texto: 'Página de autorização identificada.', msg: 'Página de autorização do gov.br identificada (e-Fisco - Sefaz PE).' },
    login_govbr: { status: 'aguardando_login', tag: 'GOV.BR', texto: 'Página de login do gov.br identificada. Aguardando você concluir a autenticação (CPF, senha, banco, QR code ou certificado).', msg: 'Aguardando você concluir o login no gov.br. A automação continua sozinha depois.' },
    verificacao: { status: 'aguardando_login', tag: 'GOV.BR', texto: 'Verificação de segurança (CAPTCHA) na tela. Aguardando sua intervenção; a automação não mexe nela.', nivel: 'aviso', msg: 'Verificação de segurança na tela: resolva manualmente. A automação aguarda.' },
    govbr_outra: { status: 'aguardando_login', tag: 'GOV.BR', texto: 'Etapa do gov.br aguardando você (código, aplicativo ou mensagem).', msg: 'Etapa do gov.br aguardando você (código, aplicativo ou mensagem).' },
    sso_sefaz: { status: 'executando', tag: 'REDIRECIONAMENTO', texto: 'Redirecionando pelo SSO da SEFAZ-PE...', msg: 'Redirecionando pelo SSO da SEFAZ-PE...' },
    certificado_govbr: { status: 'aguardando_login', tag: 'CERTIFICADO', texto: 'Autenticação por certificado em andamento no gov.br. Se pedir PIN ou senha do certificado, digite na janela do token.', msg: 'Processando o certificado no gov.br. Se pedir PIN, digite na janela do token.' },
    login_govbr_certificado: { status: 'executando', tag: 'GOV.BR', texto: 'Página de login do gov.br identificada.', msg: 'Página de login do gov.br: procurando "Seu certificado digital"...' },
  };

  // Texto para você reconhecer o certificado na janela "Selecionar um certificado" do Chrome.
  function descricaoCertificado() {
    const c = estado().certificado;
    if (!c) return 'o certificado que você escolheu';
    const partes = [c.titular, c.documentoMascarado, c.validade ? `válido até ${c.validade}` : null, c.emissor ? `emitido por ${c.emissor}` : null];
    return partes.filter(Boolean).join(' — ');
  }

  async function anunciarPagina(p) {
    const usaCertificado = p.tipo === 'login_govbr' && estado().metodoLogin === 'certificado';
    const a = AVISOS_PAGINA[usaCertificado ? 'login_govbr_certificado' : p.tipo];
    if (!a) return;
    await ctrl.atualizar({
      status: a.status,
      statusPagina: p.descricao,
      statusLogin: a.status === 'aguardando_login' ? 'Aguardando você no gov.br' : 'Em andamento',
      paginaAutenticacao: p.tipo,
      elementoProcurado: p.tipo === 'autorizacao' ? 'Botão "Autorizar"' : '—',
      mensagem: a.msg,
    });
    await ctrl.log(a.texto, { tag: a.tag, nivel: a.nivel || 'info' });
  }

  async function tratarAutorizacao() {
    if (!G.autorizarAutomaticamente) {
      if (estado().status !== 'aguardando_login') {
        await ctrl.atualizar({ status: 'aguardando_login', mensagem: 'Tela de autorização: decida você (Autorizar ou Negar). A automação aguarda.' });
        await ctrl.log('Autorização automática desligada; aguardando sua decisão.', { tag: 'AUTORIZAÇÃO' });
      }
      return;
    }
    const est = estado();
    // Clique recente: o gov.br ainda está processando. Não clica de novo.
    if (est.autorizacaoEm && Date.now() - est.autorizacaoEm < G.intervaloEntreAutorizacoes) return;
    if ((est.autorizacaoCliques || 0) >= G.maxCliquesAutorizar) {
      throw new ErroAutomacao('AUTORIZACAO_SEM_RESULTADO', `"Autorizar" já foi clicado ${est.autorizacaoCliques} vezes e a tela continua. Confira a página e clique em Continuar.`);
    }

    await ctrl.atualizar({ status: 'executando', mensagem: 'Procurando botão Autorizar...', elementoProcurado: 'Botão "Autorizar"' });
    await ctrl.log('Procurando botão Autorizar...', { tag: 'ROLAGEM' });

    const botao = await comTentativas('Localizar "Autorizar"', async () => {
      let r = GovBr.botaoAutorizar();
      if (!r.botao) {
        const busca = await Scroll.rolarAteEncontrar(() => GovBr.botaoAutorizar().botao, { ctrl });
        r = busca.el ? { botao: busca.el } : r;
      }
      if (!r.botao) throw new ErroAutomacao('ELEMENTO_NAO_ENCONTRADO', `Botão "Autorizar" não encontrado (${r.motivo || 'fim da página'}).`);
      if (!D.naTela(r.botao, 4)) {
        await ctrl.log('Botão fora da área visível; rolando até ele.', { tag: 'ROLAGEM' });
        await Scroll.trazerParaVisao(r.botao, { ctrl, posicao: 'centro' });
      }
      if (!D.habilitado(r.botao)) {
        await ctrl.atualizar({ mensagem: 'Aguardando o botão Autorizar ficar disponível...' });
        const ok = await D.esperar(() => r.botao.isConnected && D.habilitado(r.botao), { limite: G.esperaHabilitar, ctrl });
        if (!ok) throw new ErroAutomacao('ELEMENTO_INVISIVEL', 'O botão "Autorizar" não ficou disponível.');
      }
      return r.botao;
    }, { ctrl });

    await ctrl.log('Botão localizado.', { tag: 'AUTORIZAÇÃO' });
    Mouse.mostrar();
    await Mouse.clicar(botao, {
      ctrl,
      aoPosicionar: async () => {
        await ctrl.atualizar({ mensagem: 'Movimentando até o botão Autorizar...', ultimaAcao: 'Movendo o cursor até "Autorizar"' });
        await ctrl.log('Posicionando cursor...', { tag: 'MOUSE' });
      },
      antesDoDisparo: async () => {
        // Última conferência: a tela ainda é a autorização do e-Fisco e o alvo é "Autorizar".
        if (GovBr.identificarPagina().tipo !== 'autorizacao' || util.normalizar(botao.textContent || botao.value) !== G.textoBotaoAutorizar) {
          throw new ErroAutomacao('REDIRECIONAMENTO_INESPERADO', 'A tela mudou antes do clique em "Autorizar"; clique cancelado.');
        }
        await ctrl.atualizar({
          autorizacaoCliques: (estado().autorizacaoCliques || 0) + 1,
          autorizacaoEm: Date.now(),
          mensagem: 'Autorizando o compartilhamento para o e-Fisco - Sefaz PE...',
          ultimaAcao: 'Clique em "Autorizar"',
        });
        await ctrl.log('Realizando clique...', { tag: 'AUTORIZAÇÃO' });
      },
    });
    await ctrl.atualizar({ mensagem: 'Aguardando o processamento da autorização...' });
    await ctrl.log('Identificando próxima página...', { tag: 'REDIRECIONAMENTO' });
  }

  // Tela de identificação do gov.br com login por certificado: clica em "Seu certificado
  // digital" e espera você escolher o certificado na janela do Chrome. A janela de seleção é
  // do navegador (não da página): a extensão não a vê nem clica nela, só orienta e espera.
  // "doc" guarda o que já foi feito NESTE carregamento da página (nunca clica duas vezes).
  async function tratarLoginCertificado(doc) {
    if (doc.clicado) {
      if (!doc.lembrado && Date.now() - doc.clicadoEm > G.lembreteCertificado) {
        doc.lembrado = true;
        await ctrl.atualizar({ mensagem: `A janela "Selecionar um certificado" do Chrome está aberta? Ela pode estar atrás do navegador. Escolha: ${descricaoCertificado()}. Se você a fechou, clique de novo em "Seu certificado digital".` });
        await ctrl.log('A página ainda não avançou: confira a janela de seleção de certificado do Chrome (pode estar atrás do navegador).', { tag: 'CERTIFICADO', nivel: 'aviso' });
      }
      return;
    }
    const est = estado();
    if ((est.certificadoCliques || 0) >= G.maxCliquesCertificado) {
      if (!doc.avisouLimite) {
        doc.avisouLimite = true;
        await ctrl.atualizar({ status: 'aguardando_login', mensagem: `"Seu certificado digital" já foi clicado ${est.certificadoCliques} vezes. Conclua o login manualmente; a automação continua depois.` });
        await ctrl.log('Limite de cliques em "Seu certificado digital" atingido; aguardando o login manual.', { tag: 'CERTIFICADO', nivel: 'aviso' });
      }
      return;
    }

    const opcao = GovBr.opcaoCertificadoDigital();
    if (!opcao) {
      if (!doc.avisouSemOpcao && Date.now() - doc.desde > 10000) {
        doc.avisouSemOpcao = true;
        await ctrl.atualizar({ status: 'aguardando_login', mensagem: 'Não encontrei "Seu certificado digital" nesta tela. Clique você nessa opção; a automação continua depois.' });
        await ctrl.log('Opção "Seu certificado digital" não encontrada nesta tela; aguardando você.', { tag: 'CERTIFICADO', nivel: 'aviso', erro: 'ELEMENTO_NAO_ENCONTRADO' });
      }
      return;
    }
    if (!doc.anunciouBusca) {
      doc.anunciouBusca = true;
      await ctrl.atualizar({ mensagem: 'Procurando a opção Seu certificado digital...', elementoProcurado: 'Opção "Seu certificado digital"' });
      await ctrl.log('Procurando opção Seu certificado digital...', { tag: 'CERTIFICADO' });
    }
    if (!D.habilitado(opcao)) return; // espera habilitar (próxima leitura), sem clicar repetidamente

    Mouse.mostrar();
    await Mouse.clicar(opcao, {
      ctrl,
      aoPosicionar: async () => {
        await ctrl.atualizar({ mensagem: 'Movimentando até Seu certificado digital...', ultimaAcao: 'Movendo o cursor até "Seu certificado digital"' });
        await ctrl.log('Posicionando cursor...', { tag: 'MOUSE' });
      },
      antesDoDisparo: async () => {
        if (GovBr.identificarPagina().tipo !== 'login_govbr' || util.normalizar(opcao.textContent) !== G.textoOpcaoCertificado) {
          throw new ErroAutomacao('REDIRECIONAMENTO_INESPERADO', 'A tela mudou antes do clique em "Seu certificado digital"; clique cancelado.');
        }
        await ctrl.atualizar({ certificadoCliques: (estado().certificadoCliques || 0) + 1, certificadoEm: Date.now(), ultimaAcao: 'Clique em "Seu certificado digital"' });
        await ctrl.log('Opção localizada. Realizando clique...', { tag: 'CERTIFICADO' });
      },
    });
    doc.clicado = true;
    doc.clicadoEm = Date.now();
    // A janela "Selecione um certificado" é do Chrome, fora da página. Com a seleção nativa
    // ligada na interface, quem age nela é o Modo 2 (UI Automation + mouse do Windows, no
    // computador); este registro é o sinal para ele começar. Sem ela, a escolha é sua.
    const nativa = !!estado().selecaoNativa;
    await ctrl.atualizar({
      status: 'aguardando_login',
      statusLogin: 'Aguardando a seleção do certificado',
      mensagem: nativa
        ? `A automação vai selecionar ${descricaoCertificado()} na janela do Chrome com o mouse do Windows e clicar em OK. Mexer o mouse ou ESC cancela. Se pedir PIN, digite você.`
        : `Na janela "Selecionar um certificado" do Chrome, escolha: ${descricaoCertificado()} e clique em OK. Se pedir PIN, digite na janela do token.`,
    });
    await ctrl.log(nativa
      ? `Janela de certificados: seleção nativa pelo Windows (${descricaoCertificado()}).`
      : `Aguardando você escolher o certificado na janela do Chrome: ${descricaoCertificado()}.`, { tag: 'CERTIFICADO', acaoNativa: nativa ? 'selecionar_certificado' : null });
  }

  // Roda nas páginas do gov.br e do SSO da SEFAZ. Reclassifica a página a cada leitura e só
  // age na tela de identificação (opção de certificado, se escolhida) e na de autorização
  // do e-Fisco. Quando a aba sai deste domínio, o script termina
  // e a página seguinte retoma. Não recarrega páginas de autenticação.
  async function etapaAutenticacaoGovBr() {
    if (!GovBr.ehDominioAutenticacao()) return { irPara: Nav.ehPortal() ? 'verificar_login' : 'verificar_portal' };
    await ctrl.log(`Identificando próxima página (${location.hostname})...`, { tag: 'REDIRECIONAMENTO' });

    // SEM limite de tempo que vire erro: enquanto a aba estiver numa página de autenticação
    // válida (login, certificado, PIN, CAPTCHA, autorização), a automação espera e reclassifica
    // a página a cada leitura. A tela de autorização é tratada sempre que aparecer, em
    // qualquer momento do caminho. Só registra lembretes periódicos.
    const doc = { desde: Date.now(), clicado: false }; // ações já feitas neste carregamento
    let ultimoTipo = null;
    let desde = Date.now();
    let avisouDemora = false;
    let proximoLembrete = Date.now() + CONFIG.LOGIN.lembreteEspera;
    for (;;) {
      await ctrl.checkpoint();
      if (document.readyState === 'loading') {
        await util.dormir(300);
        continue;
      }
      const p = GovBr.identificarPagina();
      if (p.tipo !== ultimoTipo) {
        ultimoTipo = p.tipo;
        desde = Date.now();
        avisouDemora = false;
        await anunciarPagina(p);
      }
      if (Date.now() >= proximoLembrete) {
        proximoLembrete = Date.now() + CONFIG.LOGIN.lembreteEspera;
        const minutos = Math.round((Date.now() - doc.desde) / 60000);
        await ctrl.log(`Continuo aguardando nesta página do gov.br (${p.descricao}) há ${minutos} min. Nada será recarregado.`, { tag: 'GOV.BR', nivel: 'aviso' });
      }
      if (p.tipo === 'autorizacao') {
        await tratarAutorizacao();
      } else if (p.tipo === 'login_govbr' && estado().metodoLogin === 'certificado') {
        await tratarLoginCertificado(doc);
      } else if (p.tipo === 'autorizacao_outro') {
        throw new ErroAutomacao('AUTORIZACAO_OUTRO_SERVICO');
      } else if (p.tipo === 'sso_sefaz' && !avisouDemora && Date.now() - desde > G.avisoRedirecionamentoParado) {
        avisouDemora = true;
        await ctrl.atualizar({ mensagem: 'O redirecionamento pelo SSO da SEFAZ está demorando. Se a página mostrar um erro, volte ao portal e clique em Continuar.' });
        await ctrl.log('Redirecionamento incompleto: o SSO da SEFAZ está parado há mais de 30 s.', { tag: 'REDIRECIONAMENTO', nivel: 'aviso' });
      }
      await util.dormir(G.intervaloLeitura);
    }
  }

  async function etapaConfirmarAcesso() {
    await ctrl.atualizar({ mensagem: 'Verificando conclusão do acesso...', elementoProcurado: 'Sessão autenticada' });
    await ctrl.log('Verificando conclusão do acesso...', { tag: 'VALIDAÇÃO' });
    if (!Nav.ehPortal()) return { irPara: 'verificar_portal' };
    const a = await Login.avaliarEstavel(ctrl);
    if (a.estado !== 'autenticado' && !estado().loginConfirmadoManual) {
      await ctrl.log(`A sessão não foi confirmada (${a.evidencia}).`, { tag: 'VALIDAÇÃO', nivel: 'aviso' });
      return { irPara: 'verificar_login' };
    }
    const usuario = Login.nomeUsuarioLogado();
    await ctrl.atualizar({ statusLogin: usuario ? `Autenticado: ${usuario}` : 'Autenticado', usuarioLogado: usuario, mensagem: 'Acesso confirmado.', loginAcionamentos: 0, autorizacaoCliques: 0, autorizacaoEm: null, certificadoCliques: 0 });
    await ctrl.log(`Acesso confirmado (${a.evidencia}).`, { tag: 'VALIDAÇÃO', resultado: 'ok' });

    // Login por e-CPF: o nome da saudação deve ser o titular do certificado escolhido.
    const cert = estado().certificado;
    if (usuario && cert && cert.tipo === 'e-CPF' && cert.titular) {
      if (util.normalizar(usuario) === util.normalizar(cert.titular)) {
        await ctrl.log(`Usuário logado confere com o certificado escolhido (${cert.titular}).`, { tag: 'VALIDAÇÃO', resultado: 'ok' });
      } else {
        await ctrl.log(`Atenção: o portal mostra "${usuario}", mas o certificado escolhido é de "${cert.titular}". Confira se o certificado certo foi selecionado.`, { tag: 'VALIDAÇÃO', nivel: 'aviso' });
      }
    }
    return estado().modo === 'acesso' ? { concluir: true } : null;
  }

  // Depois do login: em que tela do portal estamos? Decide o caminho sem supor que sempre se
  // começa pela página inicial (depois do login, o portal costuma abrir direto em Certidões).
  async function etapaIdentificarTelaSefaz() {
    await ctrl.atualizar({ mensagem: 'Identificando a tela da SEFAZ...', elementoProcurado: 'Tela atual do portal' });
    await D.esperar(() => !D.carregando(), { limite: T.extensaoPorCarregamento, ctrl });
    await D.esperarEstabilidade({ ctrl });
    const modo = estado().modo;
    let tela = 'outra';
    if (Consulta.telaCertidaoNegativa().confirmada) tela = 'certidao_negativa';
    else if (Consulta.telaCertidoes().confirmada || Nav.telaCertidoes().confirmada) tela = 'certidoes';
    else if (D.localizarTituloAcessoRapido()) tela = 'inicio';
    const nomes = { certidao_negativa: 'consulta de Certidão Negativa', certidoes: 'página de Certidões', inicio: 'página inicial (Acesso Rápido)', outra: 'outra tela' };
    await ctrl.atualizar({ telaSefaz: tela });
    await ctrl.log(`Tela atual do portal: ${nomes[tela]}.`, { tag: 'ACESSO' });

    if (modo === 'certidao_negativa' && !estado().registro) {
      throw new ErroAutomacao('REGISTRO_AUSENTE');
    }
    if (tela === 'inicio') return { irPara: 'localizar_acesso_rapido' };
    if (tela === 'certidoes') return modo === 'certidoes' ? { concluir: true } : { irPara: 'localizar_certidao_negativa' };
    if (tela === 'certidao_negativa') return modo === 'certidoes' ? { concluir: true } : { irPara: 'selecionar_tipo_documento' };

    // Outra tela: volta à inicial uma vez (só troca o trecho após o #, sem recarregar).
    const usadas = estado().recuperacoesUsadas || {};
    if (!usadas.voltarInicioSefaz && Nav.voltarParaInicio()) {
      await ctrl.atualizar({ recuperacoesUsadas: { ...usadas, voltarInicioSefaz: true } });
      await ctrl.log('Tela não reconhecida; voltando à página inicial do portal.', { tag: 'ACESSO', nivel: 'aviso', recuperacao: 'voltar à página inicial' });
      await util.dormir(1500);
      return { irPara: 'identificar_tela_sefaz' };
    }
    throw new ErroAutomacao('LAYOUT_ALTERADO', `Tela do portal não reconhecida. Na tela: ${Consulta.mapaDiagnostico()}`);
  }

  // ---- Etapas: Certidão Negativa ------------------------------------------------------------------

  const rotuloTipo = (t) => CONST.TIPOS_DOCUMENTO[t] || t;
  const descricaoRegistro = (r) => `linha ${r.linha}: ${rotuloTipo(r.tipo)} ${r.mascarado} — ${r.nome}`;

  async function etapaLocalizarCertidaoNegativa() {
    await ctrl.atualizar({ mensagem: 'Procurando o bloco Certidão Negativa...', elementoProcurado: 'Bloco "Certidão Negativa"' });
    await ctrl.log('Procurando o bloco Certidão Negativa...', { tag: 'CERTIDÃO' });
    if (Consulta.telaCertidaoNegativa().confirmada) return { irPara: 'selecionar_tipo_documento' };

    // Procura o bloco DIRETO (não espera "confirmar a página" antes): o bloco é a melhor
    // evidência. Até 15 s por tentativa, 2 tentativas; se falhar, pausa com diagnóstico
    // completo, sem F5 (na execução de 18/11 o F5 só piorou).
    const bloco = await comTentativas('Localizar "Certidão Negativa"', async () => {
      let b = await D.esperar(() => Consulta.blocoCertidaoNegativa(), { limite: 15000, ctrl, intervalo: 400 });
      if (!b && Consulta.telaCertidoes().confirmada) {
        await ctrl.log('Bloco ainda não visível; rolando a página.', { tag: 'ROLAGEM' });
        const busca = await Scroll.rolarAteEncontrar(() => Consulta.blocoCertidaoNegativa(), { ctrl });
        b = busca.el;
      }
      if (!b) {
        const tela = Consulta.telaCertidoes();
        throw new ErroAutomacao('BLOCO_NAO_ENCONTRADO', `Bloco "Certidão Negativa" não encontrado (página de Certidões: ${tela.confirmada ? 'sim' : 'não'} — ${tela.evidencias.join(', ')}). Diagnóstico: ${Consulta.diagnosticoCertidaoNegativa()}. Na tela: ${Consulta.mapaDiagnostico()}`);
      }
      await Scroll.trazerParaVisao(b, { ctrl, posicao: 'centro' });
      await util.dormir(util.aleatorioEm(T.pausaAposPosicionar));
      await D.esperarEstabilidade({ ctrl, quieto: 400 });
      if (!D.visivel(b)) throw new ErroAutomacao('ELEMENTO_INVISIVEL', 'O bloco "Certidão Negativa" não ficou visível.');
      return b;
    }, { ctrl, max: 2 });

    ctx.blocoNegativa = bloco;
    await ctrl.log(`Bloco "Certidão Negativa" localizado por ${bloco.__sefazpeCamada || 'texto'} (${Consulta.diagnosticoCertidaoNegativa().split('; ').find((s) => s.startsWith('estrutura')) || ''}); os demais serviços foram ignorados.`, { tag: 'CERTIDÃO', resultado: 'ok' });
    return null;
  }

  async function etapaAbrirCertidaoNegativa() {
    if (Consulta.telaCertidaoNegativa().confirmada) {
      await ctrl.log('A consulta de Certidão Negativa já está aberta.', { tag: 'CERTIDÃO', resultado: 'ok' });
      return null;
    }
    const est = estado();
    if (est.negativaClicada) {
      // Retomada depois do clique: só confere a tela, sem clicar de novo.
      const ok = await D.esperar(() => Consulta.telaCertidaoNegativa().confirmada, { limite: Q.esperaTela, ctrl });
      if (ok) return null;
      await ctrl.atualizar({ negativaClicada: false });
      return { irPara: 'localizar_certidao_negativa' };
    }
    if ((est.negativaCliques || 0) >= Q.maxCliquesNegativa) {
      throw new ErroAutomacao('CLIQUE_SEM_RESULTADO', `"Certidão Negativa" já foi clicado ${est.negativaCliques} vezes sem abrir a consulta. Na tela: ${Consulta.mapaDiagnostico()}`);
    }
    if (!ctx.blocoNegativa || !ctx.blocoNegativa.isConnected) return { irPara: 'localizar_certidao_negativa' };

    Mouse.mostrar();
    await Mouse.clicar(ctx.blocoNegativa, {
      ctrl,
      aoPosicionar: async () => {
        await ctrl.atualizar({ mensagem: 'Movimentando até Certidão Negativa...', ultimaAcao: 'Movendo o cursor até "Certidão Negativa"' });
        await ctrl.log('Posicionando cursor...', { tag: 'MOUSE' });
      },
      antesDoDisparo: async () => {
        if (!Consulta.comTextoExato(Q.tituloNegativa, ctx.blocoNegativa).length) {
          throw new ErroAutomacao('REDIRECIONAMENTO_INESPERADO', 'O bloco sob o cursor não é mais "Certidão Negativa"; clique cancelado.');
        }
        await ctrl.atualizar({ negativaClicada: true, negativaCliques: (estado().negativaCliques || 0) + 1, ultimaAcao: 'Clique em "Certidão Negativa"' });
        await ctrl.log('Clicando em Certidão Negativa...', { tag: 'CERTIDÃO' });
      },
    });

    await ctrl.atualizar({ mensagem: 'Aguardando a consulta de Certidão Negativa abrir...' });
    let abriu = await D.esperar(() => Consulta.telaCertidaoNegativa().confirmada || Login.modalLoginNecessario(), { limite: Q.esperaTela, ctrl });
    if (abriu && Login.modalLoginNecessario()) {
      await ctrl.log('O portal pediu login ao abrir a Certidão Negativa (sessão expirada?).', { tag: 'LOGIN', nivel: 'aviso', erro: 'LOGIN_NECESSARIO' });
      Login.fecharModalLogin();
      await ctrl.atualizar({ negativaClicada: false });
      return { irPara: 'verificar_login' };
    }
    if (!abriu && D.carregando()) abriu = await D.esperar(() => Consulta.telaCertidaoNegativa().confirmada, { limite: T.extensaoPorCarregamento, ctrl });
    if (!abriu) {
      await ctrl.atualizar({ negativaClicada: false });
      throw new ErroAutomacao('CLIQUE_SEM_RESULTADO', `A consulta de Certidão Negativa não abriu. Na tela: ${Consulta.mapaDiagnostico()}`);
    }
    await D.esperarEstabilidade({ ctrl, quieto: 500 });
    const t = Consulta.telaCertidaoNegativa();
    await ctrl.log(`Consulta de Certidão Negativa aberta (${t.evidencias.join(', ')}).`, { tag: 'CERTIDÃO', resultado: 'ok' });
    return null;
  }

  async function etapaSelecionarTipoDocumento() {
    const reg = estado().registro;
    if (!reg) throw new ErroAutomacao('REGISTRO_AUSENTE');
    if (!Consulta.telaCertidaoNegativa().confirmada) return { irPara: 'identificar_tela_sefaz' };
    const rotulo = rotuloTipo(reg.tipo);
    await ctrl.atualizar({ mensagem: `Selecionando a opção ${rotulo}...`, elementoProcurado: `Opção "${rotulo}"`, identificadorConferido: false, trocandoRegistro: false, ...(estado().inicioRegistroEm ? {} : { inicioRegistroEm: Date.now() }) });
    const lote = estado().lote;
    await ctrl.log(`Registro em consulta${lote && lote.posicao ? ` ${lote.posicao}/${lote.total}` : ''} (${descricaoRegistro(reg)}).`, { tag: 'REGISTRO' });

    await comTentativas(`Selecionar "${rotulo}"`, async () => {
      const o = Consulta.opcaoTipo(reg.tipo);
      if (!o) throw new ErroAutomacao('ELEMENTO_NAO_ENCONTRADO', `Opção "${rotulo}" não encontrada. Na tela: ${Consulta.mapaDiagnostico()}`);
      if (Consulta.tipoMarcado(reg.tipo)) {
        await ctrl.log(`A opção ${rotulo} já estava selecionada.`, { tag: 'TIPO' });
        return;
      }
      Mouse.mostrar();
      await Mouse.clicar(o.alvo, {
        ctrl,
        aoPosicionar: async () => { await ctrl.log('Posicionando cursor...', { tag: 'MOUSE' }); },
        antesDoDisparo: async () => { await ctrl.log(`Selecionando ${rotulo}...`, { tag: 'TIPO' }); },
      });
      const marcou = await D.esperar(() => Consulta.tipoMarcado(reg.tipo), { limite: Q.esperaAtualizacaoCampo, ctrl });
      if (!marcou) throw new ErroAutomacao('TIPO_NAO_SELECIONADO', `A opção ${rotulo} não ficou marcada.`);
    }, { ctrl, max: 2 });

    // O formulário pode trocar o campo (máscara, texto de ajuda) depois da escolha.
    await D.esperarEstabilidade({ ctrl, quieto: 400, limite: Q.esperaAtualizacaoCampo });
    await ctrl.atualizar({ tipoSelecionado: reg.tipo });
    await ctrl.log(`Opção ${rotulo} selecionada e conferida.`, { tag: 'TIPO', resultado: 'ok' });
    return null;
  }

  async function etapaPreencherIdentificador() {
    const reg = estado().registro;
    if (!reg) throw new ErroAutomacao('REGISTRO_AUSENTE');
    if (!Consulta.tipoMarcado(reg.tipo)) return { irPara: 'selecionar_tipo_documento' };
    const rotulo = rotuloTipo(reg.tipo);

    await comTentativas('Preencher o identificador', async () => {
      const campo = Consulta.campoPesquisa();
      if (!campo) throw new ErroAutomacao('ELEMENTO_NAO_ENCONTRADO', `Campo de pesquisa não encontrado. Na tela: ${Consulta.mapaDiagnostico()}`);
      await ctrl.atualizar({ subestado: 'PREENCHENDO_IDENTIFICADOR', mensagem: `Preenchendo o ${rotulo}...`, elementoProcurado: 'Campo de pesquisa', identificadorConferido: false });
      await ctrl.log(`Preenchendo o campo com o ${rotulo} ${reg.mascarado}...`, { tag: 'PREENCHIMENTO' });
      Mouse.mostrar();
      await Mouse.clicar(campo, { ctrl, aoPosicionar: async () => { await ctrl.log('Posicionando cursor no campo de pesquisa...', { tag: 'MOUSE' }); } });
      // Apaga completamente o identificador anterior e confere o campo vazio antes de digitar.
      const tinha = Consulta.valorLimpo(campo).length;
      if (!(await Consulta.limparCampo(campo, { ctrl }))) {
        throw new ErroAutomacao('CAMPO_NAO_PREENCHIDO', `O campo de pesquisa não ficou vazio antes de digitar (ainda tem ${Consulta.valorLimpo(campo).length} caracteres).`);
      }
      await ctrl.log(tinha ? 'Campo limpo (o identificador anterior foi apagado) e conferido: vazio.' : 'Campo conferido: vazio.', { tag: 'PREENCHIMENTO' });
      await Consulta.digitar(campo, reg.identificador, { ctrl });

      await ctrl.atualizar({ subestado: 'VALIDANDO_PREENCHIMENTO', mensagem: 'Validando o preenchimento...' });
      await util.dormir(400);
      if (!Consulta.valorConfere(campo, reg.identificador)) {
        // A máscara do site pode ter recusado a digitação tecla a tecla: tenta o valor já
        // formatado (como o sistema exibe) e confere de novo.
        await ctrl.log('O campo não ficou igual ao esperado; aplicando o valor no formato do sistema.', { tag: 'PREENCHIMENTO', nivel: 'aviso', recuperacao: 'valor formatado' });
        Consulta.definirValor(campo, reg.formatado);
        await util.dormir(400);
      }
      if (!Consulta.valorConfere(campo, reg.identificador)) {
        throw new ErroAutomacao('CAMPO_NAO_PREENCHIDO', `O campo ficou com ${Consulta.valorLimpo(campo).length} caracteres em vez do ${rotulo} esperado.`);
      }
      if (!Consulta.tipoMarcado(reg.tipo)) throw new ErroAutomacao('TIPO_NAO_SELECIONADO', `A opção ${rotulo} deixou de estar marcada.`);
    }, { ctrl, max: 2 });

    await ctrl.atualizar({ identificadorConferido: true, subestado: null });
    await ctrl.log(`Campo conferido: ${rotulo} ${reg.mascarado} (opção ${rotulo} marcada).`, { tag: 'VALIDAÇÃO', resultado: 'ok' });
    return null;
  }

  // UM único clique. Antes: confere tipo marcado e valor do campo. O registro "pesquisa
  // enviada" é gravado imediatamente antes do clique: depois disso, nenhuma retomada (F5,
  // erro, Continuar) clica de novo.
  async function etapaClicarPesquisar() {
    if (estado().pesquisaEnviada) return null;
    const reg = estado().registro;
    if (!reg) throw new ErroAutomacao('REGISTRO_AUSENTE');
    const campo = Consulta.campoPesquisa();
    if (!Consulta.tipoMarcado(reg.tipo) || !campo || !Consulta.valorConfere(campo, reg.identificador)) {
      await ctrl.log('Conferência antes de pesquisar falhou; selecionando e preenchendo de novo.', { tag: 'VALIDAÇÃO', nivel: 'aviso' });
      return { irPara: 'selecionar_tipo_documento' };
    }
    await ctrl.atualizar({ mensagem: 'Procurando o botão Pesquisar...', elementoProcurado: 'Botão "Pesquisar"' });
    const botao = Consulta.botaoPesquisar();
    if (!botao) throw new ErroAutomacao('ELEMENTO_NAO_ENCONTRADO', `Botão "Pesquisar" não encontrado. Na tela: ${Consulta.mapaDiagnostico()}`);
    if (!D.habilitado(botao)) {
      await ctrl.atualizar({ mensagem: 'Aguardando o botão Pesquisar ficar disponível...' });
      const ok = await D.esperar(() => botao.isConnected && D.habilitado(botao), { limite: 15000, ctrl });
      if (!ok) throw new ErroAutomacao('ELEMENTO_INVISIVEL', 'O botão "Pesquisar" não ficou disponível.');
    }
    ctx.antesPesquisa = Consulta.instantaneoResposta();
    // Formulário reaproveitado: a tabela do registro anterior ainda está na tela; a resposta só
    // conta quando a tabela MUDAR (ou sumir / aparecer aviso).
    ctx.assinaturaAnterior = Emissao.assinaturaTabela();
    Mouse.mostrar();
    await Mouse.clicar(botao, {
      ctrl,
      aoPosicionar: async () => {
        await ctrl.atualizar({ mensagem: 'Movimentando até o botão Pesquisar...', ultimaAcao: 'Movendo o cursor até "Pesquisar"' });
        await ctrl.log('Posicionando cursor no botão Pesquisar...', { tag: 'MOUSE' });
      },
      antesDoDisparo: async () => {
        const c = Consulta.campoPesquisa();
        if (estado().pesquisaEnviada) throw new ErroAutomacao('CLIQUE_DUPLICADO');
        if (!Consulta.tipoMarcado(reg.tipo) || !c || !Consulta.valorConfere(c, reg.identificador)) {
          throw new ErroAutomacao('CAMPO_NAO_PREENCHIDO', 'O tipo ou o campo mudou antes do clique em Pesquisar; clique cancelado.');
        }
        await ctrl.atualizar({ pesquisaEnviada: true, pesquisaEm: Date.now(), ultimaAcao: 'Clique em "Pesquisar"' });
        await ctrl.log('Clicando em Pesquisar (um único clique)...', { tag: 'PESQUISA' });
      },
    });
    await ctrl.log(`Pesquisa enviada (${descricaoRegistro(reg)}).`, { tag: 'PESQUISA', resultado: 'ok' });
    return null;
  }

  async function etapaAguardarResposta() {
    await ctrl.atualizar({ mensagem: 'Aguardando a resposta do sistema...', elementoProcurado: 'Resposta da pesquisa' });
    // Retomada (recuperação sem recarga): a resposta da pesquisa já enviada pode estar na tela.
    if (!ctx.antesPesquisa && S.Emissao.tabelaResultado()) {
      await ctrl.log('A resposta da pesquisa já está na tela; seguindo sem pesquisar de novo.', { tag: 'PESQUISA' });
      return null;
    }
    await ctrl.log('Aguardando a resposta do sistema (nenhum clique novo será feito)...', { tag: 'PESQUISA' });
    const r = await Consulta.aguardarResposta(ctx.antesPesquisa || null, { ctrl });
    if (r.tipo === 'login_necessario') {
      throw new ErroAutomacao('SESSAO_EXPIRADA', 'O portal pediu login depois da pesquisa. A pesquisa NÃO será repetida automaticamente: faça o login e confira a tela.');
    }
    if (r.tipo === 'sem_mudanca') {
      await ctrl.log(`Sem resposta reconhecível em ${Math.round(Q.esperaRespostaPesquisa / 1000)} s (${r.descricao}). A pesquisa foi enviada uma vez e NÃO será repetida.`, { tag: 'PESQUISA', nivel: 'aviso' });
    } else {
      await ctrl.log(`Resposta recebida: ${r.descricao}.`, { tag: 'PESQUISA', resultado: 'ok' });
    }
    return null; // segue para a conferência do resultado
  }

  // ---- Etapas: emissão e PDF (0.5.0) ------------------------------------------------------------
  // Ações que NUNCA se repetem sozinhas: "Emitir Certidão" (emissaoSolicitada) e "Imprimir
  // Certidão" (visualizarClicado), gravadas imediatamente antes do clique. Numa retomada (F5,
  // erro + Continuar) a automação só CONFERE o que aconteceu depois delas.

  const Emissao = S.Emissao;
  const E = CONFIG.EMISSAO;
  const hora = (t) => new Date(t).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  const descreverLinhas = (ls) => ls.map((l) => `${l.documento || '—'} / IE ${l.ie || '—'} / ${l.nome || '—'}`).join('; ');

  async function etapaAnalisarResultado() {
    const reg = estado().registro;
    if (!reg) throw new ErroAutomacao('REGISTRO_AUSENTE');
    await ctrl.atualizar({ mensagem: 'Conferindo o resultado da pesquisa...', elementoProcurado: 'Tabela de resultado' });
    await ctrl.log(`Conferindo o resultado da pesquisa (${rotuloTipo(reg.tipo)} ${reg.mascarado})...`, { tag: 'RESULTADO' });
    let a = null;
    const tabelaNova = () => !ctx.assinaturaAnterior || Emissao.assinaturaTabela() !== ctx.assinaturaAnterior;
    await D.esperar(() => {
      a = Emissao.analisar(reg);
      return a.situacao !== 'sem_tabela' && tabelaNova();
    }, { limite: E.esperaResultado, ctrl, intervalo: 400 });
    await D.esperarEstabilidade({ ctrl, quieto: 500, limite: 5000 });
    if (!tabelaNova()) {
      throw new ErroAutomacao('CLIQUE_SEM_RESULTADO', 'A tabela na tela ainda é a do registro anterior: a resposta da nova pesquisa não apareceu. Nada foi emitido.');
    }
    a = Emissao.analisar(reg);

    if (a.situacao === 'sem_tabela') {
      throw new ErroAutomacao('RESULTADO_NAO_ENCONTRADO', `A tabela de resultado não apareceu (nada foi emitido). Na tela: ${Consulta.mapaDiagnostico()}`);
    }
    if (a.situacao === 'nao_encontrado') {
      await ctrl.atualizar({ resultado: { situacao: 'nao_encontrado', mensagem: a.mensagem || null } });
      await ctrl.log(`Nenhum registro para ${rotuloTipo(reg.tipo)} ${reg.mascarado}${a.mensagem ? ` (o site informou: "${a.mensagem}")` : ''}. Não houve correspondência; nada será emitido.`, { tag: 'RESULTADO', nivel: 'aviso' });
      ctx.final = 'sem_registro';
      return { concluir: true };
    }
    if (a.situacao === 'divergente') {
      await ctrl.atualizar({ resultado: { situacao: 'divergente', linhas: a.linhas } });
      throw new ErroAutomacao('RESULTADO_DIVERGENTE', `A tabela tem ${a.linhas} linha(s); ${a.correspondentes.length} confere(m) com ${rotuloTipo(reg.tipo)} ${reg.mascarado}. Diferentes: ${descreverLinhas(a.divergentes)}. Nada foi emitido; confira a pesquisa.`);
    }
    // Encontrado: o botão "Emitir Certidão (N)" precisa estar de acordo com o resultado.
    await ctrl.atualizar({ resultado: { situacao: 'encontrado', linhas: a.linhas, nomeSite: String(a.nomeSite || '').slice(0, 200), ie: a.ie || null, documento: a.documento || null } });
    const nomeLista = util.normalizar(reg.nome || '');
    const nomeSite = util.normalizar(a.nomeSite || '');
    const confereNome = !nomeLista || !nomeSite || nomeSite.includes(nomeLista) || nomeLista.includes(nomeSite);
    await ctrl.log(`Registro localizado: ${a.documento || '—'} — ${a.nomeSite || '(sem nome)'} (Inscrição Estadual: ${a.ie || '—'}${a.correspondentes[0].mascarado ? '; documento mascarado pelo site, dígitos visíveis conferem' : ''}).`, { tag: 'RESULTADO', resultado: 'ok' });
    if (!confereNome) {
      await ctrl.log(`O nome da lista ("${reg.nome}") é diferente do nome no site ("${a.nomeSite}"). O identificador confere; o arquivo usará o nome do site se os dois não corresponderem.`, { tag: 'RESULTADO', nivel: 'aviso' });
    }
    return null;
  }

  async function etapaClicarEmitir() {
    if (estado().emissaoSolicitada) return null; // já pedido: só conferir (próxima etapa)
    const reg = estado().registro;
    const res = estado().resultado;
    if (!reg) throw new ErroAutomacao('REGISTRO_AUSENTE');
    if (!res || res.situacao !== 'encontrado') return { irPara: 'analisar_resultado' };

    await ctrl.atualizar({ mensagem: 'Procurando o botão Emitir Certidão...', elementoProcurado: 'Botão "Emitir Certidão"' });
    await ctrl.log('Procurando botão Emitir Certidão...', { tag: 'EMISSÃO' });
    let e = Emissao.botaoEmitir();
    if (!e.botao) {
      await D.esperar(() => { e = Emissao.botaoEmitir(); return !!e.botao; }, { limite: 8000, ctrl });
    }
    if (!e.botao) {
      const erroSite = Emissao.erroNaTela();
      if (e.total > 1) throw new ErroAutomacao('AMBIGUIDADE', `Há ${e.total} botões "Emitir Certidão" na tela; não é seguro escolher. Nada foi emitido.`);
      throw new ErroAutomacao('BOTAO_EMITIR_AUSENTE', `O botão "Emitir Certidão" não apareceu depois do resultado${erroSite ? `; o site mostra: "${erroSite}"` : ''}. Nada foi emitido. Na tela: ${Consulta.mapaDiagnostico()}`);
    }
    if (e.quantidade !== null && e.quantidade !== res.linhas) {
      throw new ErroAutomacao('RESULTADO_DIVERGENTE', `O botão diz "${e.texto}", mas a tabela tem ${res.linhas} registro(s) conferido(s). Nada foi emitido.`);
    }
    if (!e.habilitado) {
      await ctrl.atualizar({ mensagem: 'Aguardando o botão Emitir Certidão ficar disponível...' });
      const ok = await D.esperar(() => e.botao.isConnected && D.habilitado(e.botao), { limite: 15000, ctrl });
      if (!ok) throw new ErroAutomacao('BOTAO_EMITIR_AUSENTE', `O botão "${e.texto}" está desabilitado. Nada foi emitido.`);
    }
    if (!D.naTela(e.botao, 4)) await Scroll.trazerParaVisao(e.botao, { ctrl, posicao: 'centro' });
    await ctrl.log(`Botão "${e.texto}" visível e habilitado.`, { tag: 'EMISSÃO' });

    Mouse.mostrar();
    await Mouse.clicar(e.botao, {
      ctrl,
      aoPosicionar: async () => {
        await ctrl.atualizar({ mensagem: 'Movimentando até Emitir Certidão...', ultimaAcao: 'Movendo o cursor até "Emitir Certidão"' });
        await ctrl.log('Posicionando cursor no botão Emitir Certidão...', { tag: 'MOUSE' });
      },
      antesDoDisparo: async () => {
        // Última conferência: o resultado ainda é o do identificador e o botão é o mesmo.
        if (estado().emissaoSolicitada) throw new ErroAutomacao('CLIQUE_DUPLICADO');
        const agora = Emissao.analisar(reg);
        const b = Emissao.botaoEmitir();
        if (agora.situacao !== 'encontrado' || agora.linhas !== res.linhas || b.botao !== e.botao) {
          throw new ErroAutomacao('RESULTADO_DIVERGENTE', 'O resultado na tela mudou antes do clique em "Emitir Certidão"; clique cancelado (nada foi emitido).');
        }
        await ctrl.atualizar({ emissaoSolicitada: true, emissaoEm: Date.now(), ultimaAcao: 'Clique em "Emitir Certidão" (um único)' });
        await ctrl.log('Solicitando emissão (um único clique)...', { tag: 'EMISSÃO' });
      },
    });
    await ctrl.log(`Emissão solicitada às ${hora(Date.now())} (${descricaoRegistro(reg)}).`, { tag: 'EMISSÃO', resultado: 'ok' });
    return null;
  }

  async function etapaAguardarEmissao() {
    const est = estado();
    if (!est.emissaoSolicitada) return { irPara: 'clicar_emitir' };
    if (est.emissaoConfirmada && Emissao.confirmacao()) return null;
    await ctrl.atualizar({ mensagem: 'Aguardando a confirmação da emissão...', elementoProcurado: '"Certidão emitida com sucesso!"' });
    await ctrl.log('Aguardando a resposta do sistema (a emissão NÃO será repetida)...', { tag: 'EMISSÃO' });
    const inicio = Date.now();
    let proximoAviso = inicio + 20000;
    for (;;) {
      await ctrl.checkpoint();
      const c = Emissao.confirmacao();
      if (c) {
        await ctrl.atualizar({ emissaoConfirmada: true });
        await ctrl.log(`Certidão emitida com sucesso (mensagem do site: "${c.texto}").`, { tag: 'CONFIRMAÇÃO', resultado: 'ok' });
        return null;
      }
      const erroSite = Emissao.erroNaTela();
      if (erroSite) {
        throw new ErroAutomacao('ERRO_EMISSAO', `O site informou: "${erroSite}" (${descricaoRegistro(estado().registro)}). A emissão NÃO será repetida automaticamente.`);
      }
      if (Login.modalLoginNecessario()) {
        throw new ErroAutomacao('SESSAO_EXPIRADA', 'O portal pediu login depois do pedido de emissão. A emissão NÃO será repetida: faça o login e confira se a certidão foi emitida.');
      }
      if (Date.now() >= proximoAviso) {
        proximoAviso = Date.now() + 20000;
        await ctrl.log(`Ainda aguardando a confirmação (${Math.round((Date.now() - inicio) / 1000)} s; o sistema ${D.carregando() ? 'está processando' : 'não mostra carregamento'}).`, { tag: 'EMISSÃO' });
      }
      if (Date.now() - inicio > E.esperaConfirmacao) {
        throw new ErroAutomacao('EMISSAO_SEM_CONFIRMACAO', `A emissão foi pedida às ${hora(est.emissaoEm || inicio)} e a confirmação não apareceu em ${Math.round(E.esperaConfirmacao / 1000)} s. A emissão NÃO será repetida. Confira a tela: se a certidão foi emitida, clique em Continuar (a automação confere de novo). Na tela: ${Consulta.mapaDiagnostico()}`);
      }
      await util.dormir(500);
    }
  }

  // Correção de 18/11/2026: o documento é aberto por "Visualizar Certidão" (#idFecharModal).
  // "Imprimir Certidão" nunca é clicado.
  async function etapaClicarVisualizar() {
    if (estado().visualizarClicado) return null;
    if (!Emissao.confirmacao()) {
      throw new ErroAutomacao('EMISSAO_SEM_CONFIRMACAO', `A confirmação "Certidão emitida com sucesso!" não está mais na tela; "Visualizar Certidão" não foi clicado. Na tela: ${Consulta.mapaDiagnostico()}`);
    }
    await ctrl.atualizar({ mensagem: 'Localizando Visualizar Certidão...', elementoProcurado: 'Botão "Visualizar Certidão"' });
    await ctrl.log('Localizando Visualizar Certidão...', { tag: 'VISUALIZAÇÃO' });
    await util.dormir(util.aleatorioEm(E.estabilizarDocumento));
    await D.esperarEstabilidade({ ctrl, quieto: 600, limite: 8000 });

    const botao = await D.esperar(() => Emissao.botaoVisualizar(), { limite: 10000, ctrl });
    if (!botao) throw new ErroAutomacao('BOTAO_VISUALIZAR_AUSENTE', `O botão "Visualizar Certidão" não foi encontrado na confirmação. Na tela: ${Consulta.mapaDiagnostico()}`);
    if (!D.habilitado(botao)) {
      const ok = await D.esperar(() => botao.isConnected && D.habilitado(botao), { limite: 15000, ctrl });
      if (!ok) throw new ErroAutomacao('BOTAO_VISUALIZAR_AUSENTE', 'O botão "Visualizar Certidão" está desabilitado.');
    }

    // Arma a captura ANTES do clique: todos os quadros desta aba, abas novas abertas por ela,
    // a própria aba (se navegar para o PDF) e os downloads.
    const arm = await chrome.runtime.sendMessage({ tipo: 'captura:armar', ms: E.janelaCaptura });
    if (!arm || !arm.ok) throw new ErroAutomacao('ERRO_COMUNICACAO', 'Não foi possível preparar o recebimento do PDF.');
    S.Captura.armar(E.janelaCaptura);

    Mouse.mostrar();
    await Mouse.clicar(botao, {
      ctrl,
      aoPosicionar: async () => {
        await ctrl.atualizar({ mensagem: 'Movimentando até Visualizar Certidão...', ultimaAcao: 'Movendo o cursor até "Visualizar Certidão"' });
        await ctrl.log('Posicionando cursor no botão Visualizar Certidão...', { tag: 'MOUSE' });
      },
      antesDoDisparo: async () => {
        if (estado().visualizarClicado) throw new ErroAutomacao('CLIQUE_DUPLICADO');
        if (util.normalizar(botao.innerText || botao.textContent) !== E.textoVisualizar) {
          throw new ErroAutomacao('BOTAO_VISUALIZAR_AUSENTE', 'O botão sob o cursor não é "Visualizar Certidão"; clique cancelado.');
        }
        await ctrl.atualizar({ visualizarClicado: true, visualizarEm: Date.now(), visualizarCliques: (estado().visualizarCliques || 0) + 1, ultimaAcao: 'Clique em "Visualizar Certidão"' });
        await ctrl.log('Abrindo documento...', { tag: 'VISUALIZAÇÃO' });
      },
    });
    return null;
  }

  // Espera o PDF salvo e conferido pelo computador. Enquanto espera, pede ao background que
  // procure o documento onde ele pode ter aberto (aba nova, esta aba, quadro embutido). Sem
  // PDF original, mas com a certidão em HTML na tela, pede a geração do PDF da página.
  // Esta etapa pode rodar numa página NOVA (se a aba navegou para o documento).
  async function etapaAguardarArquivo() {
    if (!estado().visualizarClicado) return { irPara: 'clicar_visualizar' };
    await ctrl.atualizar({ mensagem: 'Aguardando o carregamento do documento...', elementoProcurado: 'PDF da certidão' });
    await ctrl.log('Aguardando carregamento...', { tag: 'PDF' });
    const inicio = Date.now();
    let proximoAviso = inicio + 15000;
    let proximaVarredura = inicio + 2500;
    let pediuHtml = false;
    let ultimoErro = null;
    for (;;) {
      await ctrl.checkpoint();
      const est = estado();
      if (est.arquivo && est.arquivo.caminho) {
        ctx.arquivo = est.arquivo;
        return { concluir: true };
      }
      if (est.arquivoErro && est.arquivoErro !== ultimoErro) {
        ultimoErro = est.arquivoErro;
        await ctrl.log(`Problema com o documento: ${est.arquivoErro}. Continuo procurando (aba nova, esta aba, quadro, download).`, { tag: 'PDF', nivel: 'aviso' });
      }
      if (Date.now() >= proximaVarredura) {
        proximaVarredura = Date.now() + 3000;
        const r = await chrome.runtime.sendMessage({ tipo: 'captura:varrer' }).catch(() => null);
        if (r && r.html && !pediuHtml && Date.now() - inicio > E.esperaGerarPdfDeHtml) {
          pediuHtml = true;
          await ctrl.log(`O documento abriu como página (HTML), sem PDF original (${r.html}). Gerando o PDF da página, com todas as páginas...`, { tag: 'PDF', nivel: 'aviso' });
          await chrome.runtime.sendMessage({ tipo: 'captura:gerar_pdf' }).catch(() => null);
        }
      }
      if (Date.now() >= proximoAviso) {
        proximoAviso = Date.now() + 15000;
        const vias = (est.capturaVias || []).join('; ') || 'nenhuma reação detectada ainda';
        await ctrl.log(`Ainda aguardando o documento (${Math.round((Date.now() - inicio) / 1000)} s). Visto até agora: ${vias}.`, { tag: 'PDF' });
      }
      if (Date.now() - inicio > E.esperaArquivo) {
        const vias = (est.capturaVias || []).join('; ') || 'nenhuma reação ao clique (nem aba nova, nem documento na página, nem download)';
        throw new ErroAutomacao('ARQUIVO_NAO_RECEBIDO', `Nenhum PDF chegou à pasta em ${Math.round(E.esperaArquivo / 1000)} s. Reação do site: ${vias}.${est.arquivoErro ? ` Último problema: ${est.arquivoErro}.` : ''} Confira se o documento abriu e clique em Continuar: a automação procura de novo e, se a confirmação ainda estiver na tela, clica outra vez em "Visualizar Certidão" (a certidão NÃO é emitida de novo).`);
      }
      await util.dormir(500);
    }
  }

  // ---- Etapas: Certidões (inalteradas) ----------------------------------------------------------

  // Sessão caiu no meio do caminho? Volta para a verificação de login.
  async function sessaoAtiva() {
    if (!CONFIG.LOGIN.obrigatorioParaCertidoes) return true;
    if (Login.avaliar().estado !== 'nao_autenticado') return true;
    await ctrl.log('A sessão não aparece mais como autenticada (sessão expirada?).', { nivel: 'aviso', erro: 'SESSAO_EXPIRADA' });
    return false;
  }

  async function etapaLocalizarAcessoRapido() {
    await ctrl.atualizar({ mensagem: 'Localizando Acesso Rápido...', elementoProcurado: 'Seção "Acesso Rápido"' });
    await ctrl.log('Procurando Acesso Rápido.');
    if (!(await sessaoAtiva())) return { irPara: 'verificar_login' };

    const r = await comTentativas('Localizar Acesso Rápido', async () => {
      let titulo = D.localizarTituloAcessoRapido();
      if (!titulo) {
        await ctrl.atualizar({ ultimaAcao: 'Rolando a página em busca da seção' });
        const busca = await Scroll.rolarAteEncontrar(() => D.localizarTituloAcessoRapido(), { ctrl });
        titulo = busca.el;
        if (!titulo) throw new ErroAutomacao('ELEMENTO_NAO_ENCONTRADO', `Seção "Acesso Rápido" não encontrada (${busca.motivo}).`);
      }
      const secao = D.secaoDoTitulo(titulo);
      if (!secao) throw new ErroAutomacao('ELEMENTO_NAO_CARREGADO', 'Título "Acesso Rápido" encontrado, mas os blocos ainda não.');
      await ctrl.atualizar({ ultimaAcao: 'Posicionando a seção Acesso Rápido na tela' });
      await Scroll.trazerParaVisao(titulo, { ctrl, posicao: 'topo' });
      await D.esperarEstabilidade({ ctrl });
      return { titulo, secao };
    }, { ctrl });

    ctx.titulo = r.titulo;
    ctx.secao = r.secao;
    await ctrl.atualizar({ ultimaAcao: 'Seção Acesso Rápido visível' });
    await ctrl.log('Seção localizada.', { resultado: 'ok' });
    return null;
  }

  async function etapaLocalizarCertidoes() {
    await ctrl.atualizar({ mensagem: 'Procurando bloco Certidões...', elementoProcurado: 'Bloco "Certidões"' });
    await ctrl.log('Procurando bloco Certidões.');
    if (!(await sessaoAtiva())) return { irPara: 'verificar_login' };

    const r = await comTentativas('Localizar bloco Certidões', async () => {
      if (!ctx.secao || !ctx.secao.isConnected) {
        const titulo = D.localizarTituloAcessoRapido();
        ctx.secao = titulo && D.secaoDoTitulo(titulo);
        if (!ctx.secao) throw new ErroAutomacao('ELEMENTO_NAO_CARREGADO', 'A seção Acesso Rápido não está mais na página.');
      }
      const achado = D.localizarCertidoes(ctx.secao);
      if (!achado || !achado.card) {
        const nomes = achado && achado.nomes.length ? achado.nomes.join(' | ') : 'nenhum';
        throw new ErroAutomacao('ELEMENTO_NAO_ENCONTRADO', `Bloco "Certidões" não encontrado. Blocos vistos: ${nomes}.`);
      }
      await ctrl.atualizar({ ultimaAcao: 'Posicionando o bloco Certidões na tela' });
      await Scroll.trazerParaVisao(achado.card, { ctrl, posicao: 'centro' });
      await util.dormir(util.aleatorioEm(T.pausaAposPosicionar));
      await D.esperarEstabilidade({ ctrl, quieto: 400 });
      if (!D.visivel(achado.card)) throw new ErroAutomacao('ELEMENTO_INVISIVEL', 'O bloco Certidões não ficou visível.');
      return achado;
    }, { ctrl });

    ctx.card = r.card;
    await ctrl.log(`Bloco localizado (${r.total} blocos na seção; os demais foram ignorados).`, { resultado: 'ok' });
    return null;
  }

  async function etapaClicarCertidoes() {
    const est = estado();
    if (est.cliqueRealizado) {
      await ctrl.log('O clique já foi feito nesta execução; não será repetido.');
      return null;
    }
    if ((est.cliquesFeitos || 0) >= RC.maxCliques) {
      throw new ErroAutomacao('CLIQUE_SEM_RESULTADO', `O bloco Certidões já foi clicado ${est.cliquesFeitos} vezes sem resultado.`);
    }
    if (!ctx.card || !ctx.card.isConnected) return { irPara: 'localizar_certidoes' };

    await ctrl.atualizar({ mensagem: 'Movimentando até o elemento...', ultimaAcao: 'Movendo o cursor até "Certidões"' });
    Mouse.mostrar();
    const antes = Nav.instantaneo();
    ctx.antes = antes;

    const r = await Mouse.clicar(ctx.card, {
      ctrl,
      antesDoDisparo: async () => {
        await ctrl.atualizar({
          mensagem: 'Acessando Certidões...',
          cliqueRealizado: true,
          cliqueEm: Date.now(),
          cliquesFeitos: (estado().cliquesFeitos || 0) + 1,
          instantaneoAntes: { href: antes.href, form: antes.form, paginas: antes.paginas },
          ultimaAcao: 'Clique no bloco "Certidões"',
        });
        await ctrl.log('Executando clique.');
      },
    });
    await ctrl.log(`Clique realizado em ${r.alvo}.`, { resultado: 'ok' });
    return null;
  }

  // Aceita a nova tela se a rota/página for a de Certidões ou, como reserva, se a nova
  // página visível tiver "certid" no texto.
  function confirmarDestino(res) {
    const conf = Nav.telaCertidoes();
    if (conf.confirmada) return conf;
    const porConteudo = Consulta.telaCertidoes();
    if (porConteudo.confirmada) return porConteudo;
    const ids = res && res.paginas ? res.paginas : Nav.paginasVisiveis();
    const ev = ids
      .map((id) => document.getElementById(id))
      .filter((el) => el && el.id !== CONFIG.PORTAL.formInicial + 'Page' && /certid/.test(D.textoNormalizado(el).slice(0, 3000)))
      .map((el) => `#${el.id} com texto de certidões`);
    return { confirmada: ev.length > 0, evidencias: ev };
  }

  async function etapaAguardarProximaTela() {
    await ctrl.atualizar({ mensagem: 'Aguardando carregamento...', elementoProcurado: 'Próxima tela (Certidões)' });
    await ctrl.log('Aguardando nova tela.');

    let res = { tipo: 'rota' };
    if (!Nav.telaCertidoes().confirmada) {
      const antes = ctx.antes || estado().instantaneoAntes || Nav.instantaneo();
      res = await Nav.aguardarMudanca(antes, { ctrl });
    }

    if (res.tipo === 'login_necessario') {
      await ctrl.log('O portal respondeu "Necessário estar logado".', { nivel: 'aviso', erro: 'LOGIN_NECESSARIO' });
      Login.fecharModalLogin();
      ctx.loginExigidoPeloPortal = true;
      await ctrl.atualizar({ cliqueRealizado: false, cliquesFeitos: 0 });
      return { irPara: 'verificar_login' };
    }
    if (res.tipo === 'primeiro_acesso') {
      throw new ErroAutomacao('PRIMEIRO_ACESSO', 'O portal abriu o aviso de primeiro acesso. Resolva-o manualmente e clique em Continuar.');
    }
    if (res.tipo === 'sem_mudanca') {
      await ctrl.atualizar({ cliqueRealizado: false });
      // Conferido no portal: sem login e com a sessão anônima da página vencida, o servidor
      // responde 401 e a tela não muda (nem o aviso aparece). Sem login visível = pedir login.
      if (CONFIG.LOGIN.obrigatorioParaCertidoes && Login.avaliar().estado === 'nao_autenticado') {
        await ctrl.log('O clique não produziu mudança e não há login: o serviço exige autenticação.', { nivel: 'aviso', erro: 'LOGIN_NECESSARIO' });
        ctx.loginExigidoPeloPortal = false;
        await ctrl.atualizar({ cliquesFeitos: 0 });
        return { irPara: 'verificar_login' };
      }
      if ((estado().cliquesFeitos || 0) < RC.maxCliques) {
        await ctrl.atualizar({ mensagem: 'Erro identificado. Tentando recuperar...', tentativasRecuperacao: estado().tentativasRecuperacao + 1 });
        await ctrl.log('O clique não produziu mudança; o bloco será localizado e clicado mais uma vez.', { nivel: 'aviso', erro: 'CLIQUE_SEM_RESULTADO', recuperacao: 'novo clique' });
        return { irPara: 'localizar_acesso_rapido' };
      }
      throw new ErroAutomacao('CLIQUE_SEM_RESULTADO');
    }

    await ctrl.atualizar({ statusPagina: 'Carregando próxima tela...' });
    const estavel = await Nav.aguardarEstabilizacao(ctrl);
    const conf = confirmarDestino(res);
    if (!conf.confirmada) {
      throw new ErroAutomacao('REDIRECIONAMENTO_INESPERADO', `A tela mudou (${res.tipo}${res.form ? ': ' + res.form : ''}), mas não foi possível confirmar que é a de Certidões.`);
    }
    await ctrl.atualizar({ statusPagina: estavel ? 'Tela de Certidões carregada' : 'Tela de Certidões (ainda com atividade)' });
    await ctrl.log(`Navegação confirmada: ${conf.evidencias.join('; ')}.`, { resultado: 'ok', tag: 'ACESSO' });
    // Modo "certidoes" (popup) termina aqui; o modo da consulta segue para Certidão Negativa.
    return estado().modo === 'certidoes' ? { concluir: true } : { irPara: 'localizar_certidao_negativa' };
  }

  const ETAPAS = {
    verificar_portal: etapaVerificarPortal,
    verificar_login: etapaVerificarLogin,
    acionar_login_govbr: etapaAcionarLoginGovBr,
    autenticacao_govbr: etapaAutenticacaoGovBr,
    confirmar_acesso: etapaConfirmarAcesso,
    identificar_tela_sefaz: etapaIdentificarTelaSefaz,
    localizar_acesso_rapido: etapaLocalizarAcessoRapido,
    localizar_certidoes: etapaLocalizarCertidoes,
    clicar_certidoes: etapaClicarCertidoes,
    aguardar_proxima_tela: etapaAguardarProximaTela,
    localizar_certidao_negativa: etapaLocalizarCertidaoNegativa,
    abrir_certidao_negativa: etapaAbrirCertidaoNegativa,
    selecionar_tipo_documento: etapaSelecionarTipoDocumento,
    preencher_identificador: etapaPreencherIdentificador,
    clicar_pesquisar: etapaClicarPesquisar,
    aguardar_resposta: etapaAguardarResposta,
    analisar_resultado: etapaAnalisarResultado,
    clicar_emitir: etapaClicarEmitir,
    aguardar_emissao: etapaAguardarEmissao,
    clicar_visualizar: etapaClicarVisualizar,
    aguardar_arquivo: etapaAguardarArquivo,
  };
  const ORDEM = CONST.ETAPAS.map((e) => e.id).filter((id) => ETAPAS[id]);

  // ---- Execução -------------------------------------------------------------------------------

  // Por onde começar (ou retomar). Nas páginas de login, direto na autenticação. No portal,
  // as etapas antes do clique em Certidões só observam a página e podem ser refeitas; depois
  // desse clique, começa pela confirmação.
  // Ações que nunca se repetem numa retomada: o clique em Pesquisar (vai direto aguardar a
  // resposta) e o clique no bloco Certidões (vai direto confirmar a tela).
  function indiceInicial() {
    if (GovBr.ehDominioAutenticacao()) return ORDEM.indexOf('autenticacao_govbr');
    const e = estado();
    if (e.visualizarClicado) return ORDEM.indexOf('aguardar_arquivo');
    if (e.emissaoConfirmada) return ORDEM.indexOf('clicar_visualizar');
    if (e.emissaoSolicitada) return ORDEM.indexOf('aguardar_emissao');
    if (e.pesquisaEnviada) return ORDEM.indexOf('aguardar_resposta');
    if (e.retomarEm && ORDEM.includes(e.retomarEm)) return ORDEM.indexOf(e.retomarEm);
    return estado().cliqueRealizado ? ORDEM.indexOf('aguardar_proxima_tela') : 0;
  }

  // ---- Lista inteira: passar ao próximo registro ---------------------------------------------------

  // Erros que NÃO são de um registro: comprometem o login, o navegador ou a comunicação.
  // Pausam a lista inteira até você resolver (os demais só marcam o registro e a lista segue).

  const descricaoLote = (est) => (est.lote && est.lote.posicao ? `${est.lote.posicao}/${est.lote.total}` : '');

  async function esperarComControle(ms) {
    const fim = Date.now() + ms;
    while (Date.now() < fim) {
      await ctrl.checkpoint();
      await util.dormir(Math.min(250, Math.max(0, fim - Date.now())));
    }
  }

  // Volta ao formulário da Certidão Negativa recarregando SÓ o quadro do portal: some a janela
  // "Certidão emitida com sucesso!" e a tabela do registro anterior; a sessão (cookies) continua.
  async function recarregarParaProximo() {
    await ctrl.atualizar({ trocaRecarregadaEm: Date.now(), mensagem: 'Voltando ao formulário de Certidão Negativa...' });
    await ctrl.log('Voltando ao formulário de Certidão Negativa (a página da consulta é recarregada; a sessão continua).', { tag: 'LOTE' });
    await util.dormir(300);
    location.reload();
    throw new ExecucaoInterrompida('Próximo registro.');
  }

  // res: { situacao: 'sucesso'|'nao_encontrado'|'erro', codigo, etapa, mensagem }
  async function proximoDaLista(res) {
    const est = estado();
    if (res.situacao === 'sucesso') {
      const arq = ctx.arquivo || est.arquivo;
      if (!arq || !arq.caminho) throw new ErroAutomacao('ARQUIVO_NAO_SALVO');
      await ctrl.log(`Certidão salva corretamente (${descricaoLote(est)}): ${arq.caminho}`, { resultado: 'concluída', tag: 'SUCESSO' });
    }
    const f = await chrome.runtime.sendMessage({ tipo: 'captura:fechar_abas' }).catch(() => null);
    if (f && f.fechadas) await ctrl.log(`Aba do documento fechada (${f.fechadas}); a aba do portal continua aberta.`, { tag: 'VISUALIZAÇÃO' });

    const r = await chrome.runtime.sendMessage({ tipo: 'lote:registro', ...res }).catch((e) => ({ ok: false, erro: e.message }));
    if (!r || !r.ok) throw new ErroAutomacao('ERRO_COMUNICACAO', `Não foi possível registrar o resultado do registro na interface (${(r && r.erro) || '?'}). Confira se a janela da interface (INTERFACE.cmd) continua aberta e clique em Continuar.`);
    ctx.final = null; ctx.arquivo = null; ctx.blocoNegativa = null; ctx.antesPesquisa = null;
    if (r.fim) return concluirLista(r);

    const prox = r.proximo;
    const seg = Math.round((r.intervaloMs || 0) / 1000);
    await ctrl.log(`Próximo registro ${r.lote ? `${r.lote.posicao}/${r.lote.total}` : ''}: ${rotuloTipo(prox.tipo)} ${prox.mascarado} — ${prox.nome}.${seg ? ` Aguardando ${seg} s antes de começar.` : ''}`, { tag: 'LOTE' });
    await ctrl.atualizar({ mensagem: seg ? `Intervalo de ${seg} s entre registros...` : 'Preparando o próximo registro...' });
    if (r.intervaloMs) await esperarComControle(r.intervaloMs);
    // 0.6.2: reaproveita o formulário aberto (fecha só o painel); recarrega só se não der.
    if (await voltarAoFormulario()) return 'continuar';
    return recarregarParaProximo();
  }

  // Fecha o painel "Certidão emitida com sucesso!" e confere que o formulário da consulta está
  // livre, SEM recarregar nem navegar. Ordem:
  //   1. já está livre → nada a fazer;
  //   2. clique suave num ponto seguro FORA do painel (no fundo escurecido, nunca num link ou
  //      botão da página) — o painel fecha ao clicar fora;
  //   3. tecla Esc (fecha painéis desse tipo);
  //   4. não deu → false (quem chamou recarrega o quadro do portal, como antes).
  async function voltarAoFormulario() {
    await ctrl.atualizar({ mensagem: 'Fechando o painel da certidão e voltando ao formulário...' });
    const pronto = () => Emissao.formularioLivre();
    if (pronto()) {
      await ctrl.log('O formulário de consulta já está livre; reaproveitando-o.', { tag: 'VISUALIZAÇÃO' });
      return true;
    }
    for (let tentativa = 1; tentativa <= 2; tentativa++) {
      const p = Emissao.pontoForaDoPainel();
      if (!p) break; // sem painel e mesmo assim não livre: deixa para a recarga
      if (p.ponto) {
        await ctrl.log(`Fechando o painel de visualização: clique fora dele (ponto ${p.ponto.x}, ${p.ponto.y}, no fundo do painel)...`, { tag: 'VISUALIZAÇÃO' });
        Mouse.mostrar();
        const c = await Mouse.clicarPonto(p.ponto.x, p.ponto.y, {
          ctrl,
          // Imediatamente antes do clique: o ponto continua no fundo do painel (não num controle).
          conferir: (hit) => !p.caixa.contains(hit) && (hit === p.fundo || p.fundo.contains(hit) || hit.contains(p.fundo)),
        });
        if (c && (await D.esperar(pronto, { limite: 3000, ctrl, intervalo: 200 }))) {
          await ctrl.log('Painel fechado; formulário de consulta livre (mesma página, mesma sessão).', { tag: 'VISUALIZAÇÃO', resultado: 'ok' });
          return true;
        }
      }
      // Reserva: Esc.
      const alvo = document.activeElement || document.body;
      for (const tipo of ['keydown', 'keyup']) alvo.dispatchEvent(new KeyboardEvent(tipo, { key: 'Escape', code: 'Escape', keyCode: 27, which: 27, bubbles: true, cancelable: true }));
      if (await D.esperar(pronto, { limite: 2000, ctrl, intervalo: 200 })) {
        await ctrl.log('Painel fechado com Esc; formulário de consulta livre.', { tag: 'VISUALIZAÇÃO', resultado: 'ok' });
        return true;
      }
    }
    await ctrl.log('O painel não fechou (ou o formulário continua coberto); a página da consulta será recarregada.', { tag: 'VISUALIZAÇÃO', nivel: 'aviso', recuperacao: 'recarregar página' });
    return false;
  }

  async function concluirLista(r) {
    const s = r.resumo || {};
    await ctrl.log(`Lista concluída: ${s.sucesso || 0} certidão(ões) salva(s), ${s.erro || 0} com erro, ${s.naoEncontrado || 0} não encontrado(s), de ${s.total || 0}.`, { resultado: 'concluída', tag: 'SUCESSO' });
    await ctrl.atualizar({
      status: 'concluido', etapa: 'concluida', elementoProcurado: '—', erro: null, erroCodigo: null,
      ultimaAcao: 'Lista processada',
      mensagem: `Processamento finalizado: ${s.sucesso || 0} salva(s), ${s.erro || 0} com erro, ${s.naoEncontrado || 0} não encontrado(s) de ${s.total || 0}.${r.planilha ? ` Planilha: ${r.planilha}` : ''} O navegador continua aberto.`,
    });
    setTimeout(() => Mouse.esconder(), 1500);
  }

  // Falha de UM registro da lista (0.6.1): a escada de recuperação (modules/recuperacao.js)
  // decide entre concluir (PDF já salvo), pausar (erro geral), novo login, repetir sem
  // recarregar, repetir depois de recarregar, ou registrar o erro e seguir para o próximo.
  // Cada decisão vira uma OCORRÊNCIA no histórico do registro (interface e planilha).
  // Devolve true para repetir nesta página; false para pausar; ou não volta (página recarregada
  // / próximo registro).
  async function tratarFalhaNaLista(erro) {
    const est = estado();
    const lote = est.lote || {};
    const tela = { confirmacaoVisivel: !!Emissao.confirmacao(), carregando: D.carregando() };
    const d = S.Recuperacao.decidir(est, erro, tela, { maxTentativas: lote.maxTentativas || 3 });
    const t = Math.max(1, est.tentativaRegistro || 1);
    const max = lote.maxTentativas || 3;
    const decorrido = est.inicioRegistroEm ? Math.round((Date.now() - est.inicioRegistroEm) / 1000) : null;
    const reg = est.registro || {};
    const ocorrencia = {
      etapa: CONST.rotuloEtapa(est.etapa), codigo: erro.codigo, problema: erro.message, acao: d.descricao, tentativa: `${t}/${max}`,
      decorridoSeg: decorrido, situacao: { pesquisaEnviada: !!est.pesquisaEnviada, emissaoSolicitada: !!est.emissaoSolicitada, emissaoConfirmada: !!est.emissaoConfirmada, pdfSalvo: !!(est.arquivo && est.arquivo.caminho) },
    };
    chrome.runtime.sendMessage({ tipo: 'lote:ocorrencia', ocorrencia }).catch(() => {});
    await ctrl.log(`REGISTRO ${descricaoLote(est)} — ${rotuloTipo(reg.tipo)} ${reg.mascarado || ''} — ${reg.nome || ''}. Etapa: ${ocorrencia.etapa}. Tentativa ${t}/${max}. Problema: ${erro.message}${decorrido !== null ? ` (${decorrido} s neste registro)` : ''}. Ação: ${d.descricao}`, { tag: 'RECUPERAÇÃO', nivel: 'aviso', recuperacao: d.acao });

    if (d.acao === 'pausar') return false;
    if (d.acao === 'sucesso') {
      ctx.arquivo = est.arquivo;
      return (await proximoDaLista({ situacao: 'sucesso' })) === 'continuar';
    }
    if (d.acao === 'relogar') {
      await ctrl.atualizar({ ...d.parcial, erro: null, erroCodigo: null });
      return true;
    }
    if (d.acao === 'repetir') {
      await ctrl.atualizar({ ...d.parcial, erro: null, erroCodigo: null, recuperando: true });
      if (d.recarregar) {
        await ctrl.log('Recarregando a página e retomando o registro atual...', { tag: 'RECUPERAÇÃO', recuperacao: 'recarregar página' });
        await util.dormir(500);
        location.reload();
        throw new ExecucaoInterrompida('Recarga de recuperação.');
      }
      await util.dormir(1500);
      return true;
    }
    // 'proximo': registra o erro (com captura da página) e segue, salvo se for um problema geral.
    if ((est.errosSeguidos || 0) >= 2) {
      await ctrl.log('Três registros seguidos com erro: provável problema geral (portal, sessão ou página). A lista foi pausada neste registro.', { tag: 'LOTE', nivel: 'aviso' });
      return false;
    }
    await chrome.runtime.sendMessage({ tipo: 'captura:tela_falha' }).catch(() => null);
    const emitida = est.emissaoConfirmada ? ' A certidão chegou a ser emitida no site, mas o PDF não foi salvo.' : est.emissaoSolicitada ? ' A emissão foi pedida e não teve confirmação (não foi repetida): confira no portal.' : '';
    try {
      if ((await proximoDaLista({ situacao: 'erro', codigo: erro.codigo, etapa: ocorrencia.etapa, mensagem: `${erro.message}${emitida} (${t} tentativa(s))` })) === 'continuar') return true;
    } catch (e) {
      if (e instanceof ExecucaoInterrompida) throw e;
      await ctrl.log(`Não foi possível passar ao próximo registro: ${e.message}`, { tag: 'ERRO', nivel: 'erro' });
    }
    return false; // pausa (só chega aqui se não deu para passar ao próximo)
  }

  async function concluir() {
    // O registro vai antes da mudança de status: assim o terminal/interface mostra [SUCESSO]
    // antes de encerrar.
    if (estado().modo === 'acesso') {
      await ctrl.log('Autenticação concluída. Aguardando próxima etapa.', { resultado: 'concluída', tag: 'SUCESSO' });
      await ctrl.atualizar({
        status: 'concluido', etapa: 'concluida', elementoProcurado: '—', erro: null,
        ultimaAcao: 'Acesso autenticado confirmado',
        mensagem: 'Autenticação concluída. Aguardando próxima etapa.',
      });
    } else if (estado().modo === 'certidao_negativa') {
      const est = estado();
      const reg = est.registro;
      const desc = reg ? descricaoRegistro(reg) : 'registro';
      if (ctx.final === 'sem_registro') {
        // Sem correspondência: concluída SEM emissão (nada foi emitido nem salvo).
        await ctrl.log(`Consulta concluída sem emissão: não há registro para ${desc}.`, { resultado: 'concluída', tag: 'RESULTADO' });
        await ctrl.atualizar({
          status: 'concluido', etapa: 'concluida', elementoProcurado: '—', erro: null, erroCodigo: null,
          ultimaAcao: 'Pesquisa sem resultado',
          mensagem: `A pesquisa não retornou registro (${desc}). Nenhuma certidão foi emitida. O navegador continua aberto.`,
        });
      } else {
        // SUCESSO só aqui: o computador confirmou o PDF salvo e conferido na pasta.
        const arq = ctx.arquivo || est.arquivo;
        if (!arq || !arq.caminho) throw new ErroAutomacao('ARQUIVO_NAO_SALVO');
        await ctrl.log(`Certidão salva corretamente: ${arq.caminho}`, { resultado: 'concluída', tag: 'SUCESSO' });
        await ctrl.atualizar({
          status: 'concluido', etapa: 'concluida', elementoProcurado: '—', erro: null, erroCodigo: null,
          ultimaAcao: 'PDF salvo na pasta de resultados',
          mensagem: `Certidão emitida e salva: ${arq.arquivo || arq.caminho} (${desc}). O navegador continua aberto.`,
        });
      }
    } else {
      await ctrl.log('Etapa concluída.', { resultado: 'concluída', tag: 'SUCESSO' });
      await ctrl.atualizar({
        status: 'concluido', etapa: 'concluida', elementoProcurado: '—', erro: null,
        ultimaAcao: 'Tela de Certidões confirmada',
        mensagem: 'Etapa concluída: bloco Certidões acessado. Aguardando instruções para continuar.',
      });
    }
    setTimeout(() => Mouse.esconder(), 1500);
  }

  // Última tentativa de recuperação de uma falha que esgotou as tentativas da etapa.
  // Devolve true se o fluxo deve ser repetido nesta mesma página.
  async function tratarFalha(erro, repeticoes) {
    const est = estado();
    await ctrl.log(`Falha: ${erro.message}`, { resultado: 'falha', erro: erro.codigo, tag: 'ERRO' });
    const paginaDeLogin = GovBr.ehDominioAutenticacao();

    // Ainda processando? Espera terminar e repete, em vez de recarregar.
    if (!paginaDeLogin && erro.recuperavel && D.carregando() && repeticoes < RC.maxRepeticoesPorCarregamento) {
      await ctrl.atualizar({ mensagem: 'Erro identificado. Tentando recuperar...', ultimaAcao: 'Aguardando o fim do carregamento', tentativasRecuperacao: est.tentativasRecuperacao + 1 });
      const terminou = await D.esperar(() => !D.carregando(), { limite: T.extensaoPorCarregamento, ctrl });
      if (terminou) {
        await ctrl.log('O carregamento terminou; repetindo a partir da etapa segura.', { recuperacao: 'aguardar carregamento' });
        return true;
      }
    }

    // Recarga só no portal: nunca nas páginas de autenticação (interromperia CPF/senha/código).
    // (Na lista, a recarga é decidida pela escada de recuperação do registro, abaixo.)
    if (!paginaDeLogin && erro.recarregar && est.recargas < RC.maxRecargas && !est.lote) {
      await ctrl.atualizar({
        recargas: est.recargas + 1,
        tentativasRecuperacao: est.tentativasRecuperacao + 1,
        mensagem: 'Erro identificado. Tentando recuperar...',
        ultimaAcao: `Recarregando a página (${est.recargas + 1}/${RC.maxRecargas})`,
        erro: erro.message,
      });
      await ctrl.log('Recarregando a página para recuperar.', { recuperacao: 'recarregar página', tentativa: est.recargas + 1 });
      await util.dormir(800);
      Nav.recarregar();
      throw new ExecucaoInterrompida('Página recarregada.');
    }

    // Lista inteira: erro de UM registro não para os outros.
    if (est.lote && est.modo === 'certidao_negativa' && !paginaDeLogin) {
      if (await tratarFalhaNaLista(erro)) return true;
    }

    await ctrl.atualizar({
      status: 'erro',
      erro: `${erro.codigo}: ${erro.message}`,
      erroCodigo: erro.codigo,
      mensagem: `${erro.message} A automação foi pausada; corrija o necessário e clique em Continuar.`,
      aguardandoConfirmacaoLogin: erro.codigo === 'LOGIN_INDETERMINADO',
    });
    Mouse.esconder();
    return false;
  }

  // Erros causados por "a página não avançou". Se depois deles uma página NOVA carrega nesta
  // aba (você concluiu o login, autorizou, a SEFAZ abriu), a automação retoma sozinha.
  const RETOMAVEIS_POR_NAVEGACAO = ['TEMPO_LOGIN_ESGOTADO', 'LOGIN_NAO_CONCLUIDO', 'AUTORIZACAO_SEM_RESULTADO', 'SESSAO_EXPIRADA', 'REDIRECIONAMENTO_INESPERADO', 'PAGINA_SEM_RESPOSTA', 'CLIQUE_SEM_RESULTADO'];
  const MAX_RETOMADAS_AUTOMATICAS = 5;

  function codigoDoErro(est) {
    if (est.erroCodigo) return est.erroCodigo;
    const m = String(est.erro || '').match(/^([A-Z_]+):/); // estado gravado por versões anteriores
    return m ? m[1] : null;
  }

  async function retomarAposErroSePaginaAvancou(est) {
    const codigo = codigoDoErro(est);
    if (!RETOMAVEIS_POR_NAVEGACAO.includes(codigo)) return false;
    if ((est.retomadasAutomaticas || 0) >= MAX_RETOMADAS_AUTOMATICAS) return false;
    if (!GovBr.ehDominioAutenticacao() && !Nav.ehPortal()) return false;
    ctrl.assumir(est.execId);
    await ctrl.atualizar({ retomadasAutomaticas: (est.retomadasAutomaticas || 0) + 1 });
    await ctrl.log(`Nova página carregada depois do erro (${codigo}): ${Nav.enderecoSeguro()}. Verificando o estado real e retomando automaticamente.`, { tag: 'REDIRECIONAMENTO', recuperacao: 'retomada automática' });
    await ctrl.enviarComando('continuar');
    return true;
  }

  async function executar(origem) {
    if (rodando) return;
    if (!ctrl.execucaoDestaAba()) return;
    if (!Nav.devoAtuar()) return; // outro quadro desta aba é quem age
    rodando = true;
    ctrl.assumir(estado().execId);
    let repeticoes = 0;
    try {
      if (origem === 'retomada') {
        await ctrl.log(`Página carregada (${Nav.enderecoSeguro()}); retomando a partir de "${CONST.rotuloEtapa(ORDEM[indiceInicial()])}".`, { recuperacao: 'retomada após carregamento', tag: 'REDIRECIONAMENTO' });
      }
      // Voltou do login (ou de um F5) enquanto aguardava login: agora está verificando de
      // novo, não esperando. Se ainda faltar login, a etapa de login volta a este estado.
      if (estado().status === 'aguardando_login') {
        await ctrl.atualizar({ status: 'executando', statusLogin: 'Verificando...', mensagem: 'Verificando autenticação...' });
      }
      // Passou para o próximo registro mas esta página ainda é a do registro anterior (pausa e
      // Continuar no intervalo, por exemplo): recarrega o formulário antes de seguir.
      const e0 = estado();
      if (e0.lote && e0.trocandoRegistro && !GovBr.ehDominioAutenticacao() && (!e0.trocaRecarregadaEm || performance.timeOrigin < e0.trocaRecarregadaEm)) {
        if (!(await voltarAoFormulario())) await recarregarParaProximo();
      }
      for (;;) {
        try {
          let i = indiceInicial();
          if (estado().retomarEm) await ctrl.atualizar({ retomarEm: null });
          let saltos = 0;
          while (i < ORDEM.length) {
            await ctrl.checkpoint();
            const id = ORDEM[i];
            await ctrl.atualizar({ etapa: id, subestado: null, recuperando: false });
            armarPrazo(id);
            let r;
            try { r = await ETAPAS[id](); } finally { ctx.prazo = null; }
            if (r && r.concluir) break;
            if (r && r.irPara) {
              if (++saltos > 20) throw new ErroAutomacao('LAYOUT_ALTERADO', 'O fluxo entrou em repetição; verifique a página.');
              i = ORDEM.indexOf(r.irPara);
              continue;
            }
            i++;
          }
          const ef = estado();
          if (ef.lote && ef.modo === 'certidao_negativa') {
            // Registro terminado: resultado para o computador e próximo registro (ou fim).
            const seguir = ctx.final === 'sem_registro'
              ? await proximoDaLista({ situacao: 'nao_encontrado', etapa: 'Conferir o resultado da pesquisa', mensagem: (ef.resultado && ef.resultado.mensagem) || 'A pesquisa não retornou registro; nada foi emitido.' })
              : await proximoDaLista({ situacao: 'sucesso' });
            // Próximo registro no MESMO formulário (retomarEm = identificar a tela da SEFAZ).
            if (seguir === 'continuar') { repeticoes = 0; continue; }
            return;
          }
          await concluir();
          return;
        } catch (e) {
          if (e instanceof ExecucaoInterrompida) throw e;
          const erro = S.Erros.normalizarErro(e);
          if (await tratarFalha(erro, repeticoes)) {
            repeticoes++;
            continue;
          }
          return;
        }
      }
    } catch (e) {
      if (!(e instanceof ExecucaoInterrompida)) console.error(CONFIG.PREFIXO_LOG, e);
    } finally {
      rodando = false;
    }
  }

  // ---- Comunicação ------------------------------------------------------------------------------

  chrome.runtime.onMessage.addListener((msg, _sender, responder) => {
    if (!msg || !ctrl.contextoValido()) return false;
    if (msg.tipo === 'ping') {
      responder({ ok: true, rodando });
      return false;
    }
    if (msg.tipo === 'captura:armar') {
      // Todos os quadros da aba passam a observar o que o site faz (captura do PDF).
      if (S.Captura) S.Captura.armar(Number(msg.ms) || 0);
      return false;
    }
    if (msg.tipo === 'executar') {
      ctrl.registrar()
        .then(() => {
          executar('comando');
          responder({ ok: true });
        })
        .catch((e) => responder({ ok: false, erro: e.message }));
      return true;
    }
    return false;
  });

  // Ao carregar (F5, ida/volta do gov.br, janela aberta pelo terminal): retoma ou começa se
  // houver execução desta aba.
  (async () => {
    try {
      // Quadros pequenos ou de outros sites dentro da página nunca agem nem se apresentam.
      if (!Nav.ehTopo() && !Nav.ehQuadroPrincipal()) return;
      const { estado: est, iniciadoPeloTerminal } = await ctrl.registrar();
      S.Painel.atualizar(est);
      if (ctrl.execucaoDestaAba() && ['executando', 'aguardando_login'].includes(est.status)) {
        if (!Nav.ehTopo()) await ctrl.log(`Quadro do portal carregado (${Nav.enderecoSeguro()}); a automação continua dentro dele.`, { tag: 'ACESSO' }).catch(() => {});
        executar(iniciadoPeloTerminal ? 'terminal' : 'retomada');
      } else if (ctrl.execucaoDestaAba() && est.status === 'erro' && Nav.devoAtuar()) {
        await retomarAposErroSePaginaAvancou(est);
      }
    } catch (e) {
      console.warn(CONFIG.PREFIXO_LOG, 'Não foi possível registrar a aba:', e.message);
    }
  })();
})(globalThis);
