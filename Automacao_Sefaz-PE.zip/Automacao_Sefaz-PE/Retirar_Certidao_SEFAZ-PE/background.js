// Service worker (Manifest V3): dono do estado e dos logs, e ponte entre popup, painel da
// página e content script.
//
// - Único escritor de chrome.storage.local (fila serializada): sem corrida entre partes.
// - Recebe os comandos (iniciar, pausar, continuar, parar) do popup e do painel da página.
// - Garante que o content script está na aba (injeta se a aba foi aberta antes da
//   instalação/atualização da extensão) e manda executar.
// - Logs sem dados sensíveis: endereços perdem a parte de consulta (?code=, ?state=...).
// - Ponte com o terminal (iniciar.js, em 127.0.0.1): quando uma aba ANÔNIMA do portal se
//   apresenta e o terminal tem uma sessão pendente, a execução começa nela (modo "acesso");
//   os registros e as mudanças de status dessa execução são enviados ao terminal.

importScripts('modules/constantes.js');

const K = self.SEFAZPE_CONST;
const PREFIXO = '[Retirar_Certidao_SEFAZ-PE]';

// ---- Fila de escrita --------------------------------------------------------------------------

let fila = Promise.resolve();
function serializar(fn) {
  const p = fila.then(fn, fn);
  fila = p.catch(() => {});
  return p;
}

async function lerEstado() {
  const r = await chrome.storage.local.get(K.CHAVES.estado);
  return { ...K.estadoInicial(), ...(r[K.CHAVES.estado] || {}) };
}

async function gravarEstado(novo) {
  novo.atualizadoEm = Date.now();
  await chrome.storage.local.set({ [K.CHAVES.estado]: novo });
  atualizarIcone(novo);
  return novo;
}

// Mescla "parcial" no estado. execId informado = atualização vinda da página: se não for o
// da execução atual, é ignorada (mensagem atrasada de uma execução anterior), e ela não
// pode desfazer uma pausa/parada do usuário. Sem execId = comando do usuário (vale sempre).
function atualizarEstado(parcial, execId) {
  return serializar(async () => {
    const atual = await lerEstado();
    const daPagina = execId !== undefined;
    if (daPagina && execId !== atual.execId) return { ignorado: true, estado: atual };
    const p = { ...parcial };
    if (daPagina && p.status && ['pausado', 'parado'].includes(atual.status) && ['executando', 'aguardando_login'].includes(p.status)) {
      p.statusAntesPausa = atual.status === 'pausado' ? p.status : atual.statusAntesPausa;
      delete p.status;
    }
    const novo = await gravarEstado({ ...atual, ...p });
    if (novo.status !== atual.status) {
      enviarTerminal(novo, { tipo: 'status', status: novo.status, mensagem: sanitizar(novo.mensagem), erro: sanitizar(novo.erro) });
    }
    return { estado: novo };
  });
}

// ---- Terminal (iniciar.js) -----------------------------------------------------------------------

async function pedirTerminal(caminho, corpo, tempoLimite = 1500) {
  const controle = new AbortController();
  const t = setTimeout(() => controle.abort(), tempoLimite);
  try {
    const r = await fetch(K.TERMINAL.url + caminho, {
      method: corpo ? 'POST' : 'GET',
      headers: corpo ? { 'Content-Type': 'application/json' } : undefined,
      body: corpo ? JSON.stringify(corpo) : undefined,
      signal: controle.signal,
      cache: 'no-store',
    });
    return r.ok ? await r.json() : null;
  } catch (e) {
    return null; // terminal não está rodando (uso normal pelo popup)
  } finally {
    clearTimeout(t);
  }
}

// Só para execuções iniciadas pelo terminal ou pela interface. Nunca bloqueia nem falha a
// automação.
function enviarTerminal(estado, evento) {
  if (estado.origem === 'popup' || !estado.tokenTerminal) return;
  pedirTerminal('/evento', { token: estado.tokenTerminal, execId: estado.execId, etapa: estado.etapa, estadoAutomacao: K.estadoAutomacao(estado), ...evento });
}

// A interface pediu pausar/continuar/parar? (consultado pela aba da execução a cada ~2 s)
async function consultarComandoTerminal() {
  const est = await lerEstado();
  if (est.origem === 'popup' || !est.tokenTerminal || !K.STATUS_ATIVOS.includes(est.status)) return { ok: true };
  const r = await pedirTerminal(`/comando?token=${encodeURIComponent(est.tokenTerminal)}`);
  const c = r && r.comando;
  if (c === 'pausar') return pausar();
  if (c === 'continuar') return continuar(est.tabId);
  if (c === 'parar') return parar();
  return { ok: true };
}

// Configuração vinda da sessão do terminal/interface, só com campos conhecidos.
function configDaSessao(c = {}) {
  const cert = c.certificado && typeof c.certificado === 'object' ? c.certificado : null;
  return {
    velocidadeMouse: K.VELOCIDADES[c.velocidadeMouse] ? c.velocidadeMouse : 'lento',
    metodoLogin: c.metodoLogin === 'certificado' && cert ? 'certificado' : 'manual',
    certificado: cert ? {
      titular: String(cert.titular || '').slice(0, 120),
      tipo: String(cert.tipo || '').slice(0, 10),
      documentoMascarado: String(cert.documentoMascarado || '').slice(0, 30),
      validade: String(cert.validade || '').slice(0, 12),
      emissor: String(cert.emissor || '').slice(0, 120),
      impressaoCurta: String(cert.impressaoCurta || '').slice(0, 20),
    } : null,
    pastaResultados: c.pastaResultados ? String(c.pastaResultados).slice(0, 260) : null,
    selecaoNativa: c.selecaoNativa === true && !!cert,
    registro: registroValido(c.registro),
    lote: loteValido(c.lote),
  };
}

function loteValido(l) {
  if (!l || typeof l !== 'object' || !Number(l.total)) return null;
  return {
    total: Number(l.total) || 0,
    posicao: Number(l.posicao) || 0,
    intervaloMs: Math.min(Math.max(Number(l.intervaloMs) || 0, 0), 120000),
    maxTentativas: Math.min(Math.max(Number(l.maxTentativas) || 3, 1), 6),
    limiteEtapaMs: Math.min(Math.max(Number(l.limiteEtapaMs) || 120000, 30000), 600000),
  };
}

// Ocorrência de recuperação de um registro → computador (histórico do registro).
async function enviarOcorrencia(msg) {
  const est = await lerEstado();
  const o = msg.ocorrencia || {};
  enviarTerminal(est, {
    tipo: 'ocorrencia',
    ocorrencia: {
      etapa: sanitizar(o.etapa), codigo: sanitizar(o.codigo), problema: sanitizar(o.problema), acao: sanitizar(o.acao),
      tentativa: sanitizar(o.tentativa), decorridoSeg: Number(o.decorridoSeg) || null,
    },
  });
  return { ok: true };
}

// Captura da página no momento da falha de um registro (só a aba do portal; nunca nas páginas
// de login/certificado do gov.br). Vai para <pasta>\relatorios\falhas no computador.
async function capturarTelaDaFalha() {
  const est = await lerEstado();
  if (!est.tokenTerminal || !est.tabId || !chrome.debugger) return { ok: false };
  let tab;
  try { tab = await chrome.tabs.get(est.tabId); } catch (e) { return { ok: false }; }
  if (!K.urlDoPortal(tab.url)) return { ok: false, erro: 'fora do portal' };
  const alvo = { tabId: est.tabId };
  try {
    await chrome.debugger.attach(alvo, '1.3');
    const r = await chrome.debugger.sendCommand(alvo, 'Page.captureScreenshot', { format: 'jpeg', quality: 60 });
    const reg = est.registro || {};
    return pedirTerminal('/evidencia', { token: est.tokenTerminal, base64: r.data, identificador: reg.identificador || '', tipo: reg.tipo || '' }, 30000).then((x) => x || { ok: false });
  } catch (e) {
    return { ok: false, erro: e.message };
  } finally {
    chrome.debugger.detach(alvo).catch(() => {});
  }
}

// ---- Lista inteira -------------------------------------------------------------------------------
// Campos que pertencem a UM registro: zerados ao passar para o próximo (a sessão do portal, o
// login e as preferências continuam).
function camposDoProximoRegistro() {
  return {
    pesquisaEnviada: false, pesquisaEm: null, resultado: null, tipoSelecionado: null, identificadorConferido: false,
    emissaoSolicitada: false, emissaoEm: null, emissaoConfirmada: false,
    visualizarClicado: false, visualizarEm: null, visualizarCliques: 0,
    capturaId: null, capturaAte: null, capturaVias: [], capturaAbas: [], capturaHtml: null, pdfGerado: false, arquivo: null, arquivoErro: null,
    tentativaRegistro: 1, reemissoes: 0, inicioRegistroEm: Date.now(),
    // 0.6.2: o próximo registro começa no formulário já aberto (sem voltar ao início do portal).
    retomarEm: 'identificar_tela_sefaz',
    negativaClicada: false, negativaCliques: 0, cliqueRealizado: false, cliquesFeitos: 0, instantaneoAntes: null,
    recargas: 0, tentativasRecuperacao: 0, retomadasAutomaticas: 0, recuperacoesUsadas: {}, erro: null, erroCodigo: null, subestado: null,
    trocandoRegistro: true,
  };
}

// Fecha só as abas abertas para o documento (nunca a aba da execução).
async function fecharAbasDoDocumento() {
  const est = await lerEstado();
  const abas = (est.capturaAbas || []).filter((id) => id && id !== est.tabId);
  let fechadas = 0;
  for (const id of abas) {
    try { await chrome.tabs.remove(id); fechadas++; } catch (e) { /* já fechada */ }
  }
  if (abas.length) await atualizarEstado({ capturaAbas: [] }, est.execId);
  return { ok: true, fechadas };
}

// Resultado do registro atual → computador; a resposta traz o próximo (ou o fim da lista).
async function resultadoDoRegistro(msg) {
  const est = await lerEstado();
  if (!est.tokenTerminal || !est.lote) return { ok: false, erro: 'sem lista' };
  const r = await pedirTerminal('/registro', {
    token: est.tokenTerminal,
    situacao: ['sucesso', 'nao_encontrado', 'erro'].includes(msg.situacao) ? msg.situacao : 'erro',
    codigo: sanitizar(msg.codigo), etapa: sanitizar(msg.etapa || est.etapa), mensagem: sanitizar(msg.mensagem),
  }, 60000);
  if (!r || !r.ok) return { ok: false, erro: (r && r.erro) || 'a interface não respondeu' };
  const atual = await lerEstado();
  if (atual.execId !== est.execId) return { ok: false };
  if (!r.proximo) {
    await atualizarEstado({ lote: { ...est.lote, fim: true }, resumoLote: r.resumo || null, planilha: r.planilha || null }, est.execId);
    return { ok: true, fim: true, resumo: r.resumo || null, planilha: r.planilha || null };
  }
  const prox = registroValido(r.proximo);
  if (!prox) return { ok: false, erro: 'próximo registro inválido' };
  await atualizarEstado({ ...camposDoProximoRegistro(), registro: prox, lote: loteValido(r.lote) || est.lote, errosSeguidos: msg.situacao === 'erro' ? (est.errosSeguidos || 0) + 1 : 0 }, est.execId);
  return { ok: true, proximo: prox, lote: loteValido(r.lote), intervaloMs: Number(r.intervaloMs) || 0 };
}

// Registro da lista (vindo da interface): só tipos conhecidos e identificador limpo.
function registroValido(r) {
  if (!r || typeof r !== 'object' || !K.TIPOS_DOCUMENTO[r.tipo]) return null;
  const identificador = String(r.identificador || '').toUpperCase().replace(/[^0-9A-Z]/g, '').slice(0, 14);
  if (!identificador) return null;
  return {
    linha: Number(r.linha) || 0,
    tipo: r.tipo,
    identificador,
    formatado: String(r.formatado || identificador).slice(0, 25),
    mascarado: String(r.mascarado || '').slice(0, 25),
    nome: String(r.nome || '').slice(0, 150),
  };
}

async function lerPreferencias() {
  const r = await chrome.storage.local.get(K.CHAVES.preferencias);
  return { velocidadeMouse: 'lento', metodoLogin: 'manual', ...(r[K.CHAVES.preferencias] || {}) };
}

// Popup: velocidade do mouse e forma de login. A velocidade vale na hora, também para uma
// execução em andamento.
async function salvarPreferencias(dados) {
  const atual = await lerPreferencias();
  const novo = {
    velocidadeMouse: K.VELOCIDADES[dados.velocidadeMouse] ? dados.velocidadeMouse : atual.velocidadeMouse,
    metodoLogin: K.METODOS_LOGIN[dados.metodoLogin] ? dados.metodoLogin : atual.metodoLogin,
  };
  await serializar(() => chrome.storage.local.set({ [K.CHAVES.preferencias]: novo }));
  const est = await lerEstado();
  if (K.STATUS_ATIVOS.includes(est.status) && est.velocidadeMouse !== novo.velocidadeMouse) {
    await atualizarEstado({ velocidadeMouse: novo.velocidadeMouse });
  }
  return { ok: true, preferencias: novo };
}

// Uma aba anônima do portal se apresentou: o terminal está esperando por ela?
async function sessaoDoTerminal(tab) {
  if (!tab || !tab.incognito || !K.urlDoPortal(tab.url)) return null;
  const s = await pedirTerminal('/sessao');
  if (!s || !s.ativa || !s.token) return null;
  const r = await pedirTerminal('/reivindicar', {
    token: s.token,
    tabId: tab.id,
    incognitoPermitido: await chrome.extension.isAllowedIncognitoAccess(),
    versao: chrome.runtime.getManifest().version,
  });
  if (!r || !r.ok) return null;
  return {
    token: s.token,
    modo: K.MODOS[s.modo] ? s.modo : 'acesso',
    origem: s.origem === 'interface' ? 'interface' : 'terminal',
    config: configDaSessao(s.config),
  };
}

// ---- Certidão em PDF ------------------------------------------------------------------------------
// Antes do clique em "Visualizar Certidão", a aba pede para ARMAR a captura. Enquanto armada:
//   - todos os quadros da aba observam o que o site faz (captura_pagina.js: PDF gerado na
//     página, aba nova, link, quadro embutido);
//   - abas NOVAS abertas pela aba da execução são acompanhadas;
//   - a VARREDURA (a cada 3 s) procura o documento já aberto: aba nova, a própria aba (se ela
//     navegou para o PDF) e cada quadro; um PDF achado é buscado ali mesmo, com a sessão
//     da janela anônima;
//   - downloads da janela anônima são acompanhados;
//   - sem PDF original, mas com a certidão em HTML, o PDF é GERADO da página (impressão em
//     PDF do próprio Chrome, todas as páginas).
// O PDF vai para o computador (POST /arquivo), que confere, dá o nome e salva. "arquivo" no
// estado só é gravado com o arquivo salvo e conferido.

const capturaArmada = (est) => !!est.capturaAte && Date.now() < est.capturaAte;
const abasDaCaptura = (est) => [est.tabId, ...(Array.isArray(est.capturaAbas) ? est.capturaAbas : [])].filter(Boolean);
let lacoVarredura = null;

async function armarCaptura(ms, sender) {
  const est = await lerEstado();
  const tabId = (sender && sender.tab && sender.tab.id) || est.tabId;
  if (!tabId || tabId !== est.tabId) return { ok: false, erro: 'aba diferente da execução' };
  const dur = Math.min(Math.max(Number(ms) || 0, 10000), 300000);
  const capturaId = `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
  await atualizarEstado({ capturaId, capturaAte: Date.now() + dur, capturaVias: [], capturaAbas: [], capturaHtml: null, pdfGerado: false, arquivo: null, arquivoErro: null }, est.execId);
  // Todos os quadros da aba (o botão fica no quadro do portal; o site pode agir no de fora).
  chrome.tabs.sendMessage(tabId, { tipo: 'captura:armar', ms: dur }).catch(() => {});
  iniciarVarreduraAutonoma(est.execId, capturaId);
  return { ok: true, ms: dur };
}

// Função injetada em cada quadro/aba candidata. Roda NA PÁGINA (sessão da janela anônima).
// PDF aberto direto (visualizador do Chrome) → busca os bytes originais; HTML com cara de
// certidão do identificador → avisa; senão nada.
async function inspecionarDocumento(identificador) {
  const limpo = (s) => String(s || '').toUpperCase().replace(/[^0-9A-Z]/g, '');
  try {
    if (/pdf/i.test(document.contentType || '')) {
      const r = await fetch(location.href, { credentials: 'include', cache: 'no-store' });
      const buf = new Uint8Array(await r.arrayBuffer());
      if (String.fromCharCode.apply(null, buf.slice(0, 5)) !== '%PDF-') return { tipo: 'nada' };
      let s = '';
      for (let i = 0; i < buf.length; i += 0x8000) s += String.fromCharCode.apply(null, buf.subarray(i, i + 0x8000));
      return { tipo: 'pdf', base64: btoa(s), url: location.href.replace(/[?#].*$/, '') };
    }
    const t = document.body ? document.body.innerText : '';
    const temCertidao = /certid/i.test(t.normalize('NFD').replace(/[̀-ͯ]/g, ''));
    if (temCertidao && identificador && limpo(t).includes(limpo(identificador))) {
      // Certidão em HTML: só conta se não for a própria tela da consulta (tem a tabela/botões).
      const consulta = !!document.querySelector('table.tabela-arredondada, #idFecharModal, #avancarBtn');
      if (!consulta) return { tipo: 'html', url: location.href.replace(/[?#].*$/, ''), titulo: document.title.slice(0, 80) };
    }
  } catch (e) { /* quadro sem acesso */ }
  return { tipo: 'nada' };
}

async function varrerDocumento() {
  const est = await lerEstado();
  if (!capturaArmada(est) || est.arquivo) return { ok: true };
  const id = est.registro && est.registro.identificador;
  let html = null;
  for (const tabId of abasDaCaptura(est)) {
    let resultados = [];
    try {
      resultados = await chrome.scripting.executeScript({ target: { tabId, allFrames: true }, func: inspecionarDocumento, args: [id || ''] });
    } catch (e) {
      continue; // aba fechada ou página sem acesso
    }
    for (const r of resultados) {
      const v = r && r.result;
      if (!v) continue;
      if (v.tipo === 'pdf' && v.base64) {
        const onde = tabId === est.tabId ? (r.frameId ? 'dentro da página (quadro)' : 'na aba atual') : 'numa nova aba';
        await registrarVia(`PDF aberto ${onde}`);
        await registrarLog({ acao: `Documento PDF identificado ${onde} (${sanitizar(v.url).slice(0, 120)}).`, tag: 'PDF' }, est.execId);
        await enviarArquivoAoComputador({ via: tabId === est.tabId ? 'url' : 'janela', base64: v.base64 });
        return { ok: true, pdf: true };
      }
      if (v.tipo === 'html' && !html) html = { tabId, url: v.url, titulo: v.titulo };
    }
  }
  if (html) {
    const atual = await lerEstado();
    if (!atual.capturaHtml) {
      await atualizarEstado({ capturaHtml: html }, est.execId);
      await registrarVia(`certidão aberta como página HTML ${html.tabId === est.tabId ? 'na aba atual' : 'numa nova aba'}`);
    }
    return { ok: true, html: `${sanitizar(html.url).slice(0, 100)}` };
  }
  return { ok: true };
}

// Sem PDF original: gera o PDF da aba com a certidão em HTML (Page.printToPDF do Chrome:
// texto real, todas as páginas, fundos). A barra "a extensão está depurando este navegador"
// aparece só durante a geração.
async function gerarPdfDaPagina() {
  const est = await lerEstado();
  if (!capturaArmada(est) || est.arquivo || est.pdfGerado || !est.capturaHtml) return { ok: false };
  await atualizarEstado({ pdfGerado: true }, est.execId);
  const alvo = { tabId: est.capturaHtml.tabId };
  try {
    await chrome.debugger.attach(alvo, '1.3');
    const r = await chrome.debugger.sendCommand(alvo, 'Page.printToPDF', { printBackground: true, preferCSSPageSize: true, transferMode: 'ReturnAsBase64' });
    await registrarLog({ acao: 'PDF gerado a partir da página da certidão (o site não ofereceu o PDF original).', tag: 'PDF', nivel: 'aviso' }, est.execId);
    return enviarArquivoAoComputador({ via: 'html', base64: r.data });
  } catch (e) {
    await atualizarEstado({ arquivoErro: `não foi possível gerar o PDF da página (${e.message})` }, est.execId);
    return { ok: false };
  } finally {
    chrome.debugger.detach(alvo).catch(() => {});
  }
}

// O background também conduz a espera: se a página que dirigia o fluxo navegou para o
// documento (o script dela some), a varredura, a geração do PDF e a conclusão continuam aqui.
// CORREÇÃO 0.6.1 (causa do erro de 18/11, 15:54:59): esta varredura declarava "Nenhum PDF
// chegou à pasta" quando via "etapa aguardar_arquivo, sem arquivo, captura encerrada". Na lista,
// a passagem para o próximo registro zera exatamente esses campos (arquivo e captura) ANTES de
// a etapa mudar, durante o intervalo de 5 s — e a varredura pausou uma execução que tinha dado
// certo. Agora: (1) a varredura pertence a UMA captura (capturaId) e para assim que ela muda ou
// é zerada; (2) ela NUNCA declara erro — quem decide que o PDF não veio é a etapa da página,
// que sabe qual registro está em andamento.
function iniciarVarreduraAutonoma(execId, capturaId) {
  if (lacoVarredura) clearInterval(lacoVarredura);
  const inicio = Date.now();
  const parar = () => { clearInterval(lacoVarredura); lacoVarredura = null; };
  lacoVarredura = setInterval(async () => {
    const est = await lerEstado();
    if (est.execId !== execId || est.capturaId !== capturaId || !K.STATUS_ATIVOS.includes(est.status)) return parar();
    if (est.arquivo) {
      parar();
      setTimeout(() => concluirSeNinguemConcluiu(execId), 6000);
      return;
    }
    if (!capturaArmada(est)) return parar();
    const v = await varrerDocumento();
    if (v && v.html && Date.now() - inicio > 12000) await gerarPdfDaPagina();
  }, 3000);
}

// O PDF foi salvo, mas a página que dirigia o fluxo não existe mais (navegou para o
// documento): conclui a execução aqui, com o mesmo [SUCESSO] que a página daria.
async function concluirSeNinguemConcluiu(execId) {
  const est = await lerEstado();
  if (est.execId !== execId || est.status === 'concluido' || !est.arquivo || !K.STATUS_ATIVOS.includes(est.status)) return;
  if (est.lote) return; // na lista, quem avança é a página (o registro seguinte começa por ela)
  await registrarLog({ acao: `Certidão salva corretamente: ${est.arquivo.caminho}`, tag: 'SUCESSO', resultado: 'concluída' }, execId);
  await atualizarEstado({ status: 'concluido', etapa: 'concluida', erro: null, erroCodigo: null, ultimaAcao: 'PDF salvo na pasta de resultados', mensagem: `Certidão salva corretamente: ${est.arquivo.arquivo || est.arquivo.caminho}. O navegador continua aberto.` }, execId);
}

// Aba nova aberta pela aba da execução enquanto a captura está armada.
if (chrome.tabs.onCreated) chrome.tabs.onCreated.addListener(async (tab) => {
  const est = await lerEstado();
  if (!capturaArmada(est) || !tab.openerTabId || tab.openerTabId !== est.tabId) return;
  await atualizarEstado({ capturaAbas: [...(est.capturaAbas || []), tab.id].slice(-5) }, est.execId);
  await registrarVia('o documento abriu numa nova aba');
  await registrarLog({ acao: 'Uma nova aba foi aberta pelo portal; procurando o documento nela.', tag: 'VISUALIZAÇÃO' }, est.execId);
});

async function registrarVia(texto) {
  const est = await lerEstado();
  const vias = Array.isArray(est.capturaVias) ? est.capturaVias : [];
  if (!vias.includes(texto) && vias.length < 12) await atualizarEstado({ capturaVias: [...vias, texto] }, est.execId);
}

async function enviarArquivoAoComputador(dados) {
  const est = await lerEstado();
  if (!est.tokenTerminal) {
    await atualizarEstado({ arquivoErro: 'O PDF só pode ser salvo na pasta quando a automação é iniciada pela interface.' }, est.execId);
    return { ok: false };
  }
  const nomeSite = est.resultado && est.resultado.nomeSite ? est.resultado.nomeSite : '';
  const r = await pedirTerminal('/arquivo', { token: est.tokenTerminal, nomeSite, ...dados }, 120000);
  const atual = await lerEstado();
  if (atual.execId !== est.execId) return { ok: false };
  if (r && r.ok) {
    if (!atual.arquivo) await atualizarEstado({ arquivo: { caminho: String(r.caminho || ''), arquivo: String(r.arquivo || ''), bytes: Number(r.bytes) || 0, via: dados.via } }, est.execId);
    return { ok: true };
  }
  const erro = (r && r.erro) || 'a interface não respondeu';
  await atualizarEstado({ arquivoErro: `${dados.via}: ${erro}` }, est.execId);
  return { ok: false, erro };
}

async function arquivoCapturado(msg, sender) {
  const est = await lerEstado();
  if (!capturaArmada(est) || !sender.tab || !abasDaCaptura(est).includes(sender.tab.id)) return { ok: false, ignorado: true };
  if (typeof msg.base64 !== 'string' || !msg.base64) return { ok: false };
  const via = ['blob', 'data', 'url'].includes(msg.via) ? msg.via : 'blob';
  await registrarVia(`documento capturado na página (${via}${msg.origem ? ', ' + sanitizar(msg.origem) : ''})`);
  return enviarArquivoAoComputador({ via, base64: msg.base64 });
}

// Download iniciado pelo site na janela anônima, enquanto a captura está armada.
if (chrome.downloads) chrome.downloads.onChanged.addListener(async (delta) => {
  if (!delta.state) return;
  const est = await lerEstado();
  if (!est.capturaAte || Date.now() > est.capturaAte + 60000 || est.arquivo) return;
  const [item] = await chrome.downloads.search({ id: delta.id });
  if (!item || !item.incognito) return;
  if (est.visualizarEm && new Date(item.startTime).getTime() < est.visualizarEm - 3000) return;
  if (delta.state.current === 'interrupted') {
    await registrarVia(`download interrompido (${item.error || 'motivo desconhecido'})`);
    await atualizarEstado({ arquivoErro: `download interrompido pelo Chrome (${item.error || '?'})` }, est.execId);
    return;
  }
  if (delta.state.current !== 'complete') return;
  await registrarVia('download do Chrome');
  await enviarArquivoAoComputador({ via: 'download', caminhoDownload: item.filename });
});

if (chrome.downloads) chrome.downloads.onCreated.addListener(async (item) => {
  const est = await lerEstado();
  if (!capturaArmada(est) || !item.incognito) return;
  await registrarLog({ acao: `O Chrome iniciou um download (${sanitizar(item.finalUrl || item.url).slice(0, 120)}).`, tag: 'DOWNLOAD' }, est.execId);
});

// ---- Logs ----------------------------------------------------------------------------------------

function sanitizar(valor) {
  if (valor === null || valor === undefined) return null;
  return String(valor)
    .replace(/(https?:\/\/[^\s?#]+)[?#][^\s)]*/g, '$1')
    .replace(/\b(token|senha|password|cookie|code|state|session_state|access_token|id_token)\s*[=:]\s*[^\s&;,]+/gi, '$1=[omitido]')
    .slice(0, 600);
}

function registrarLog(entrada, execId) {
  return serializar(async () => {
    const atual = await lerEstado();
    if (execId !== undefined && execId !== atual.execId) return;
    const r = await chrome.storage.local.get(K.CHAVES.logs);
    const logs = Array.isArray(r[K.CHAVES.logs]) ? r[K.CHAVES.logs] : [];
    logs.push({
      t: Date.now(),
      execId: atual.execId,
      etapa: entrada.etapa || atual.etapa || null,
      acao: sanitizar(entrada.acao),
      resultado: sanitizar(entrada.resultado),
      erro: sanitizar(entrada.erro),
      tentativa: entrada.tentativa || null,
      recuperacao: sanitizar(entrada.recuperacao),
      nivel: entrada.nivel || 'info',
      tag: entrada.tag || null,
      acaoNativa: entrada.acaoNativa === 'selecionar_certificado' ? entrada.acaoNativa : null,
    });
    await chrome.storage.local.set({ [K.CHAVES.logs]: logs.slice(-K.MAX_LOGS) });
    const ultimo = logs[logs.length - 1];
    enviarTerminal(atual, { tipo: 'log', tag: ultimo.tag, mensagem: ultimo.acao, erro: ultimo.erro, nivel: ultimo.nivel, etapa: ultimo.etapa, acaoNativa: ultimo.acaoNativa });
  });
}

// ---- Ícone (selo) ---------------------------------------------------------------------------------

const SELOS = {
  executando: ['RUN', '#1351b4'],
  aguardando_login: ['LOG', '#b46a00'],
  pausado: ['II', '#5c6b7a'],
  erro: ['ERR', '#c4161c'],
  concluido: ['OK', '#168821'],
};

function atualizarIcone(estado) {
  const [texto, cor] = SELOS[estado.status] || ['', '#5c6b7a'];
  chrome.action.setBadgeText({ text: texto }).catch(() => {});
  chrome.action.setBadgeBackgroundColor({ color: cor }).catch(() => {});
}

// ---- Content script ----------------------------------------------------------------------------------

async function ping(tabId) {
  try {
    const r = await chrome.tabs.sendMessage(tabId, { tipo: 'ping' });
    return !!(r && r.ok);
  } catch (e) {
    return false;
  }
}

async function garantirContentScript(tabId) {
  if (await ping(tabId)) return true;
  const arquivos = chrome.runtime.getManifest().content_scripts[0].js;
  try {
    await chrome.scripting.executeScript({ target: { tabId, allFrames: true }, files: arquivos });
  } catch (e) {
    console.warn(PREFIXO, 'Injeção do content script falhou:', e.message);
    return false;
  }
  return ping(tabId);
}

async function mandarExecutar(tabId) {
  if (!(await garantirContentScript(tabId))) {
    const msg = 'Não foi possível conectar à aba do portal. Atualize a página (F5) e tente de novo.';
    await atualizarEstado({ status: 'erro', mensagem: msg, erro: 'ERRO_COMUNICACAO' });
    await registrarLog({ acao: 'Conexão com a aba falhou.', erro: 'ERRO_COMUNICACAO', nivel: 'erro' });
    return { ok: false, erro: msg };
  }
  try {
    await chrome.tabs.sendMessage(tabId, { tipo: 'executar' });
  } catch (e) {
    console.warn(PREFIXO, 'Envio de "executar" falhou:', e.message);
  }
  return { ok: true };
}

// ---- Comandos -----------------------------------------------------------------------------------------

// opcoes: { modo: 'certidoes'|'acesso', origem: 'popup'|'terminal', tokenTerminal, enviar }
// enviar=false: a própria aba (que acabou de se apresentar) começa ao receber a resposta.
async function iniciar(tabId, url, opcoes = {}) {
  const { modo = 'certidoes', origem = 'popup', tokenTerminal = null, enviar = true } = opcoes;
  // Execução do popup usa as preferências salvas no popup (sem certificado escolhido: a
  // forma "certificado" só clica na opção, e a escolha na janela do Chrome é sua).
  const config = opcoes.config || (origem === 'popup' ? await lerPreferencias() : {});
  if (!tabId) return { ok: false, erro: 'Nenhuma aba ativa identificada.' };
  if (!K.urlDoPortal(url)) return { ok: false, erro: 'A aba ativa não é o Portal de Atendimento da SEFAZ-PE.' };
  const atual = await lerEstado();
  if (['executando', 'aguardando_login'].includes(atual.status)) {
    return { ok: false, erro: atual.tabId === tabId ? 'A automação já está em execução nesta aba.' : 'Já existe uma execução em andamento em outra aba. Pare-a antes de iniciar outra.' };
  }
  const execId = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
  await serializar(() => gravarEstado({
    ...K.estadoInicial(),
    execId,
    tabId,
    modo,
    origem,
    tokenTerminal,
    velocidadeMouse: K.VELOCIDADES[config.velocidadeMouse] ? config.velocidadeMouse : 'lento',
    metodoLogin: config.metodoLogin === 'certificado' ? 'certificado' : 'manual',
    certificado: config.certificado || null,
    pastaResultados: config.pastaResultados || null,
    selecaoNativa: config.selecaoNativa === true,
    registro: config.registro || null,
    lote: config.lote || null,
    status: 'executando',
    etapa: 'verificar_portal',
    mensagem: 'Verificando portal SEFAZ-PE...',
    iniciadoEm: Date.now(),
  }));
  const est = await lerEstado();
  await registrarLog({ etapa: 'verificar_portal', acao: `Automação iniciada (${K.MODOS[modo] || modo}, pela ${origem === 'interface' ? 'interface' : origem === 'terminal' ? 'linha de comando' : 'extensão'}; mouse ${K.VELOCIDADES[est.velocidadeMouse]}; login: ${K.METODOS_LOGIN[est.metodoLogin]}).`, tag: 'INICIANDO' });
  return enviar ? mandarExecutar(tabId) : { ok: true };
}

async function pausar() {
  const atual = await lerEstado();
  if (!['executando', 'aguardando_login'].includes(atual.status)) return { ok: false, erro: 'Não há execução em andamento.' };
  await atualizarEstado({ status: 'pausado', statusAntesPausa: atual.status, mensagem: 'Execução pausada.' });
  await registrarLog({ acao: 'Execução pausada pelo usuário.' });
  return { ok: true };
}

async function continuar(tabIdPedido) {
  const atual = await lerEstado();
  if (!['pausado', 'erro'].includes(atual.status)) return { ok: false, erro: 'Não há execução pausada.' };
  const tabId = tabIdPedido || atual.tabId;
  const parcial = {
    status: atual.status === 'pausado' && atual.statusAntesPausa === 'aguardando_login' ? 'aguardando_login' : 'executando',
    tabId,
    statusAntesPausa: null,
    erro: null,
    mensagem: atual.status === 'erro' ? 'Retomando após o erro...' : 'Retomando...',
  };
  if (atual.aguardandoConfirmacaoLogin) {
    parcial.loginConfirmadoManual = true;
    parcial.aguardandoConfirmacaoLogin = false;
  }
  if (atual.status === 'erro') {
    // Nova tentativa controlada após intervenção: zera recargas e os contadores de cliques
    // de login/autorização (o limite volta a valer a partir daqui).
    // "pesquisaEnviada" NUNCA é zerado: uma pesquisa enviada não é repetida automaticamente.
    Object.assign(parcial, { recargas: 0, loginAcionamentos: 0, autorizacaoCliques: 0, autorizacaoEm: null, negativaCliques: 0, erroCodigo: null });
    // "emissaoSolicitada" também NUNCA é zerado (não emite de novo sozinho). O clique em
    // "Visualizar Certidão" pode ser refeito depois da sua intervenção (não emite outra certidão),
    // até 3 vezes por execução.
    if (atual.erroCodigo === 'ARQUIVO_NAO_RECEBIDO' && !atual.arquivo && (atual.visualizarCliques || 0) < 3) {
      Object.assign(parcial, { visualizarClicado: false, capturaAte: null, arquivoErro: null });
    }
  }
  await atualizarEstado(parcial);
  await registrarLog({ acao: atual.status === 'erro' ? 'Continuar após erro (intervenção manual).' : 'Execução retomada pelo usuário.' });
  return mandarExecutar(tabId);
}

async function parar() {
  const atual = await lerEstado();
  if (!K.STATUS_ATIVOS.includes(atual.status)) return { ok: false, erro: 'Não há execução para parar.' };
  await atualizarEstado({ status: 'parado', mensagem: 'Execução interrompida pelo usuário.', elementoProcurado: '—' });
  await registrarLog({ acao: 'Execução interrompida pelo usuário.' });
  return { ok: true };
}

async function limparLogs() {
  await serializar(() => chrome.storage.local.set({ [K.CHAVES.logs]: [] }));
  return { ok: true };
}

async function redefinir() {
  const atual = await lerEstado();
  if (['executando', 'aguardando_login'].includes(atual.status)) return { ok: false, erro: 'Pare a execução antes de redefinir.' };
  await serializar(() => gravarEstado(K.estadoInicial()));
  return { ok: true };
}

async function comando(nome, dados, sender) {
  const tabDoPainel = sender && sender.tab ? sender.tab.id : null;
  switch (nome) {
    case 'iniciar': return iniciar(dados.tabId || tabDoPainel, dados.url || (sender && sender.tab && sender.tab.url));
    case 'pausar': return pausar();
    case 'continuar': return continuar(dados.tabId || tabDoPainel);
    case 'parar': return parar();
    case 'limpar_logs': return limparLogs();
    case 'preferencias': return salvarPreferencias(dados);
    case 'redefinir': return redefinir();
    default: return { ok: false, erro: `Comando desconhecido: ${nome}` };
  }
}

// ---- Mensagens -------------------------------------------------------------------------------------------

chrome.runtime.onMessage.addListener((msg, sender, responder) => {
  if (!msg || !msg.tipo) return false;
  const tratar = async () => {
    switch (msg.tipo) {
      case 'registrar': {
        const tab = sender.tab || null;
        const atual = await lerEstado();
        if (tab && !['executando', 'aguardando_login'].includes(atual.status)) {
          const sessao = await sessaoDoTerminal(tab);
          if (sessao) {
            const r = await iniciar(tab.id, tab.url, { modo: sessao.modo, origem: sessao.origem, tokenTerminal: sessao.token, config: sessao.config, enviar: false });
            if (r.ok) return { tabId: tab.id, estado: await lerEstado(), iniciadoPeloTerminal: true };
          }
        }
        return { tabId: tab ? tab.id : null, estado: atual };
      }
      case 'estado:atualizar':
        return atualizarEstado(msg.parcial || {}, msg.execId);
      case 'log':
        await registrarLog(msg.entrada || {}, msg.execId);
        return { ok: true };
      case 'comando':
        return comando(msg.comando, msg, sender);
      case 'terminal:poll':
        return consultarComandoTerminal();
      case 'captura:armar':
        return armarCaptura(msg.ms, sender);
      case 'lote:registro':
        return resultadoDoRegistro(msg);
      case 'lote:ocorrencia':
        return enviarOcorrencia(msg);
      case 'captura:tela_falha':
        return capturarTelaDaFalha();
      case 'captura:fechar_abas':
        return fecharAbasDoDocumento();
      case 'captura:varrer':
        return varrerDocumento();
      case 'captura:gerar_pdf':
        return gerarPdfDaPagina();
      case 'arquivo:capturado':
        return arquivoCapturado(msg, sender);
      case 'captura:evento': {
        const est = await lerEstado();
        if (!capturaArmada(est) || !sender.tab || !abasDaCaptura(est).includes(sender.tab.id)) return { ok: false };
        const ROTULOS = { 'window.open': 'o site abriu uma nova aba', print: 'o site abriu a janela de impressão', link: 'o site abriu um link', 'link com download': 'o site iniciou um download por link' };
        const texto = ROTULOS[msg.evento] || sanitizar(msg.evento);
        await registrarVia(texto);
        await registrarLog({ acao: `Reação ao clique: ${texto}${msg.url ? ` (${sanitizar(msg.url).slice(0, 120)})` : ''}.`, tag: 'DOWNLOAD' }, est.execId);
        return { ok: true };
      }
      case 'preferencias:ler':
        return lerPreferencias();
      default:
        return { ok: false, erro: 'Mensagem desconhecida.' };
    }
  };
  tratar()
    .then(responder)
    .catch((e) => {
      console.error(PREFIXO, e);
      responder({ ok: false, erro: e.message });
    });
  return true; // resposta assíncrona
});

// Aba da execução fechada: encerra a execução.
chrome.tabs.onRemoved.addListener(async (tabId) => {
  const atual = await lerEstado();
  if (atual.tabId === tabId && K.STATUS_ATIVOS.includes(atual.status)) {
    await atualizarEstado({ status: 'parado', mensagem: 'A aba do portal foi fechada; execução encerrada.' });
    await registrarLog({ acao: 'Aba do portal fechada; execução encerrada.', nivel: 'aviso' });
  }
});

// Instalação/atualização: os content scripts antigos deixam de funcionar. Uma execução que
// estava em andamento fica pausada, para o usuário clicar em Continuar.
chrome.runtime.onInstalled.addListener(async () => {
  const atual = await lerEstado();
  if (['executando', 'aguardando_login'].includes(atual.status)) {
    await atualizarEstado({ status: 'pausado', statusAntesPausa: atual.status, mensagem: 'A extensão foi atualizada. Clique em Continuar para retomar.' });
  } else {
    atualizarIcone(atual);
  }
});

chrome.runtime.onStartup.addListener(async () => atualizarIcone(await lerEstado()));
