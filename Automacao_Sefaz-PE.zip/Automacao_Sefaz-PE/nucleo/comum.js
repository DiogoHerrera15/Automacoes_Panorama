// Peças comuns à interface (interface/servidor.js) e à linha de comando (iniciar.js):
// constantes da extensão, registro (terminal + arquivos), Chrome e verificação da instalação.

'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const vm = require('vm');
const { spawn } = require('child_process');

const RAIZ = path.join(__dirname, '..');
const PASTA_EXTENSAO = path.join(RAIZ, 'Retirar_Certidao_SEFAZ-PE');
const NOME_EXTENSAO = 'Retirar_Certidao_SEFAZ-PE';

// As constantes vêm da própria extensão (mesma porta, URL, modos e velocidades).
function carregarConstantes() {
  const ctx = {};
  ctx.globalThis = ctx;
  vm.createContext(ctx);
  vm.runInContext(fs.readFileSync(path.join(PASTA_EXTENSAO, 'modules', 'constantes.js'), 'utf8'), ctx);
  return ctx.SEFAZPE_CONST;
}
const K = carregarConstantes();
const VERSAO_EXTENSAO = JSON.parse(fs.readFileSync(path.join(PASTA_EXTENSAO, 'manifest.json'), 'utf8')).version;

// ---- Registro ---------------------------------------------------------------------------------

const CORES = { SUCESSO: 32, ERRO: 31, AVISO: 33, PAUSA: 33, PARADO: 31, EXTENSÃO: 36, NAVEGADOR: 36, MOUSE: 35, 'GOV.BR': 34, AUTORIZAÇÃO: 34, CERTIFICADO: 34, INTERFACE: 36 };

// Escreve no terminal, guarda as últimas linhas (para a interface) e grava nos arquivos
// adicionados (logs\terminal_*.txt e o relatório da pasta de resultados).
class Registro {
  constructor({ console: noConsole = true } = {}) {
    this.noConsole = noConsole;
    this.usarCor = noConsole && process.stdout.isTTY && !process.env.NO_COLOR;
    this.linhas = [];
    this.seq = 0;
    this.arquivos = new Set();
  }

  adicionarArquivo(caminho) {
    try {
      fs.mkdirSync(path.dirname(caminho), { recursive: true });
      this.arquivos.add(caminho);
      return caminho;
    } catch (e) {
      return null;
    }
  }

  removerArquivo(caminho) {
    this.arquivos.delete(caminho);
  }

  escrever(tag, mensagem, nivel = 'info') {
    const tagFinal = nivel === 'erro' && !['ERRO', 'PARADO'].includes(tag) ? 'ERRO' : tag;
    const linha = { seq: ++this.seq, t: Date.now(), tag: tagFinal, mensagem: String(mensagem || ''), nivel };
    this.linhas.push(linha);
    if (this.linhas.length > 400) this.linhas.shift();
    const rotulo = `[${tagFinal}]`;
    if (this.noConsole) {
      const cor = CORES[tagFinal] || (nivel === 'aviso' ? 33 : 0);
      console.log(this.usarCor && cor ? `\x1b[${cor}m${rotulo}\x1b[0m ${linha.mensagem}` : `${rotulo} ${linha.mensagem}`);
    }
    const hora = new Date(linha.t).toLocaleTimeString('pt-BR', { hour12: false });
    for (const arq of this.arquivos) {
      try {
        fs.appendFileSync(arq, `${hora} ${rotulo} ${linha.mensagem}${os.EOL}`, 'utf8');
      } catch (e) { /* o registro em arquivo nunca interrompe a automação */ }
    }
    return linha;
  }
}

function arquivoLogTerminal(prefixo = 'terminal') {
  const d = new Date();
  const p = (n) => String(n).padStart(2, '0');
  return path.join(RAIZ, 'logs', `${prefixo}_${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}_${p(d.getHours())}h${p(d.getMinutes())}m${p(d.getSeconds())}.txt`);
}

// ---- Chrome ---------------------------------------------------------------------------------------

function caminhoChrome(preferido) {
  const candidatos = [preferido, process.env.CHROME_PATH];
  if (process.platform === 'win32') {
    for (const base of [process.env.PROGRAMFILES, process.env['PROGRAMFILES(X86)'], process.env.LOCALAPPDATA]) {
      if (base) candidatos.push(path.join(base, 'Google', 'Chrome', 'Application', 'chrome.exe'));
    }
  } else if (process.platform === 'darwin') {
    candidatos.push('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome');
  } else {
    candidatos.push('/usr/bin/google-chrome', '/usr/bin/google-chrome-stable');
  }
  return candidatos.find((c) => c && fs.existsSync(c)) || null;
}

function abrirChrome(exe, args, aoErro) {
  const filho = spawn(exe, args, { detached: true, stdio: 'ignore', windowsHide: false });
  filho.on('error', (e) => aoErro && aoErro(e));
  filho.unref();
}

// Janela ANÔNIMA no perfil indicado. Com o Chrome já aberto, abre na instância existente (é
// ela que tem a extensão instalada); a sessão anônima não usa os cookies das janelas normais.
function abrirChromeAnonimo(exe, perfil, url, aoErro) {
  abrirChrome(exe, ['--incognito', '--new-window', `--profile-directory=${perfil}`, url], aoErro);
}

// Interface da automação numa janela de aplicativo (sem barra de endereço), janela normal.
function abrirJanelaApp(exe, perfil, url, aoErro) {
  abrirChrome(exe, [`--app=${url}`, `--profile-directory=${perfil}`, '--window-size=1180,860'], aoErro);
}

// ---- Extensão instalada? (leitura das preferências do perfil do Chrome) -----------------------------

function pastaUsuarioChrome() {
  if (process.platform === 'win32') return path.join(process.env.LOCALAPPDATA || '', 'Google', 'Chrome', 'User Data');
  if (process.platform === 'darwin') return path.join(os.homedir(), 'Library', 'Application Support', 'Google', 'Chrome');
  return path.join(os.homedir(), '.config', 'google-chrome');
}

const normalizarCaminho = (p) => path.resolve(p).replace(/[\\/]+$/, '').toLowerCase();

// Melhor esforço (formato interno do Chrome). A verificação definitiva é a conexão da extensão.
function verificarInstalacao(perfil) {
  const pastaPerfil = path.join(pastaUsuarioChrome(), perfil);
  const achados = [];
  for (const nome of ['Secure Preferences', 'Preferences']) {
    try {
      const json = JSON.parse(fs.readFileSync(path.join(pastaPerfil, nome), 'utf8'));
      const ext = (json.extensions && json.extensions.settings) || {};
      for (const [id, cfg] of Object.entries(ext)) {
        if (!cfg || typeof cfg.path !== 'string') continue;
        const nomeManifesto = cfg.manifest && cfg.manifest.name;
        if (path.basename(cfg.path) !== NOME_EXTENSAO && nomeManifesto !== NOME_EXTENSAO) continue;
        const razoes = cfg.disable_reasons;
        const desativada = cfg.state === 0 || (Array.isArray(razoes) ? razoes.length > 0 : !!razoes);
        achados.push({ id, caminho: cfg.path, anonimo: cfg.incognito === true, desativada });
      }
    } catch (e) { /* arquivo ausente ou ilegível */ }
  }
  const extensoes = [...new Map(achados.map((a) => [a.id, a])).values()].map((e) => ({
    ...e, mesmaPasta: normalizarCaminho(e.caminho) === normalizarCaminho(PASTA_EXTENSAO),
  }));
  return { perfil, pastaPerfil, perfilExiste: fs.existsSync(pastaPerfil), extensoes };
}

// Mensagens prontas (terminal e interface) sobre a instalação.
function mensagensInstalacao(r) {
  const m = [];
  if (!r.perfilExiste) {
    m.push({ nivel: 'aviso', texto: `Perfil do Chrome "${r.perfil}" não encontrado. Use --perfil "Profile 1" (ou o nome da pasta do seu perfil).` });
    return m;
  }
  if (!r.extensoes.length) {
    m.push({ nivel: 'aviso', texto: `A extensão não aparece neste perfil. Instale: chrome://extensions > Modo do desenvolvedor > Carregar sem compactação > ${PASTA_EXTENSAO}` });
    return m;
  }
  for (const e of r.extensoes) {
    m.push({ nivel: 'info', texto: `Encontrada (id ${e.id}) carregada de: ${e.caminho}` });
    if (!e.mesmaPasta) m.push({ nivel: 'aviso', texto: `Ela foi carregada de OUTRA pasta. Remova-a em chrome://extensions e carregue de novo de: ${PASTA_EXTENSAO}` });
    if (e.desativada) m.push({ nivel: 'aviso', texto: 'Ela está DESLIGADA em chrome://extensions. Ligue-a (botão azul do cartão).' });
    m.push(e.anonimo
      ? { nivel: 'info', texto: '"Permitir no modo anônimo" está ligado.' }
      : { nivel: 'aviso', texto: '"Permitir no modo anônimo" parece DESLIGADO: chrome://extensions > Detalhes da extensão > ligue "Permitir no modo anônimo".' });
  }
  return m;
}

// ---- Configuração salva (dados\config.json): sem dados sensíveis ------------------------------------

// SEFAZPE_CONFIG substitui o caminho (usado nos testes, para não mexer na sua configuração).
const ARQ_CONFIG = process.env.SEFAZPE_CONFIG ? path.resolve(process.env.SEFAZPE_CONFIG) : path.join(RAIZ, 'dados', 'config.json');

// A lista de documentos fica em arquivo próprio, ao lado da configuração (preservada para as
// próximas etapas).
const ARQ_LISTA = path.join(path.dirname(ARQ_CONFIG), 'lista_documentos.txt');

const PADRAO_CONFIG = { certificadoId: null, pasta: '', velocidadeMouse: 'lento', perfil: 'Default', registroLinha: null, selecaoNativa: true, intervaloSegundos: 5, maxTentativas: 3, limiteEtapaSegundos: 120 };

function lerConfig() {
  try {
    const c = JSON.parse(fs.readFileSync(ARQ_CONFIG, 'utf8'));
    return {
      certificadoId: typeof c.certificadoId === 'string' ? c.certificadoId : null,
      pasta: typeof c.pasta === 'string' ? c.pasta : '',
      velocidadeMouse: K.VELOCIDADES[c.velocidadeMouse] ? c.velocidadeMouse : 'lento',
      perfil: typeof c.perfil === 'string' && c.perfil ? c.perfil : 'Default',
      registroLinha: Number.isInteger(c.registroLinha) ? c.registroLinha : null,
      selecaoNativa: c.selecaoNativa !== false, // padrão: ligada
      intervaloSegundos: Number.isFinite(c.intervaloSegundos) && c.intervaloSegundos >= 0 && c.intervaloSegundos <= 120 ? c.intervaloSegundos : 5,
      maxTentativas: Number.isInteger(c.maxTentativas) && c.maxTentativas >= 1 && c.maxTentativas <= 6 ? c.maxTentativas : 3,
      limiteEtapaSegundos: Number.isFinite(c.limiteEtapaSegundos) && c.limiteEtapaSegundos >= 30 && c.limiteEtapaSegundos <= 600 ? c.limiteEtapaSegundos : 120,
    };
  } catch (e) {
    return { ...PADRAO_CONFIG };
  }
}

function salvarConfig(c) {
  const atual = lerConfig();
  const novo = {
    certificadoId: c.certificadoId !== undefined ? c.certificadoId : atual.certificadoId,
    pasta: c.pasta !== undefined ? String(c.pasta) : atual.pasta,
    velocidadeMouse: K.VELOCIDADES[c.velocidadeMouse] ? c.velocidadeMouse : atual.velocidadeMouse,
    perfil: c.perfil || atual.perfil,
    registroLinha: c.registroLinha !== undefined ? (Number.isInteger(c.registroLinha) ? c.registroLinha : null) : atual.registroLinha,
    selecaoNativa: typeof c.selecaoNativa === 'boolean' ? c.selecaoNativa : atual.selecaoNativa,
    intervaloSegundos: Number.isFinite(c.intervaloSegundos) && c.intervaloSegundos >= 0 && c.intervaloSegundos <= 120 ? c.intervaloSegundos : atual.intervaloSegundos,
    maxTentativas: Number.isInteger(c.maxTentativas) && c.maxTentativas >= 1 && c.maxTentativas <= 6 ? c.maxTentativas : atual.maxTentativas,
    limiteEtapaSegundos: Number.isFinite(c.limiteEtapaSegundos) && c.limiteEtapaSegundos >= 30 && c.limiteEtapaSegundos <= 600 ? c.limiteEtapaSegundos : atual.limiteEtapaSegundos,
  };
  fs.mkdirSync(path.dirname(ARQ_CONFIG), { recursive: true });
  fs.writeFileSync(ARQ_CONFIG, JSON.stringify(novo, null, 2), 'utf8');
  if (typeof c.lista === 'string') salvarLista(c.lista);
  return novo;
}

function lerLista() {
  try {
    return fs.readFileSync(ARQ_LISTA, 'utf8');
  } catch (e) {
    return '';
  }
}

function salvarLista(texto) {
  fs.mkdirSync(path.dirname(ARQ_LISTA), { recursive: true });
  fs.writeFileSync(ARQ_LISTA, String(texto).slice(0, 2 * 1024 * 1024), 'utf8');
}

module.exports = {
  RAIZ, PASTA_EXTENSAO, NOME_EXTENSAO, K, VERSAO_EXTENSAO,
  Registro, arquivoLogTerminal,
  caminhoChrome, abrirChromeAnonimo, abrirJanelaApp,
  verificarInstalacao, mensagensInstalacao,
  lerConfig, salvarConfig, ARQ_CONFIG, lerLista, salvarLista, ARQ_LISTA,
};
