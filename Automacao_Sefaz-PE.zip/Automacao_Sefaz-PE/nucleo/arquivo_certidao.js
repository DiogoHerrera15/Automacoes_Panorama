// Salvamento das certidões em PDF na pasta de resultados.
//
// Recebe o PDF de dois jeitos:
//   - bytes   → a extensão capturou o documento na página (PDF gerado pela página, aba nova
//               ou endereço do documento) e mandou o conteúdo;
//   - arquivo → o Chrome BAIXOU o documento (pasta Downloads); este módulo espera o download
//               terminar, confere e MOVE o arquivo para a pasta de resultados.
//
// Regras (pedidas pelo usuário):
//   - nome = identificador + nome da empresa/titular:
//       CNPJ → 36.690.216_0001-73_NOME.pdf   CPF → CPF_12345678900_NOME.pdf   IE → IE_012345678_NOME.pdf
//   - nome da lista de preferência, conferido com o nome devolvido pelo site; sem nome na
//     lista, usa o do site;
//   - caracteres inválidos no Windows removidos; nunca sobrescreve (sufixo _2, _3...);
//   - grava num arquivo temporário na mesma pasta e só renomeia depois de conferir; em caso de
//     erro o temporário é apagado (nada incompleto fica para trás);
//   - o PDF precisa começar com "%PDF-", terminar com "%%EOF" e ter ao menos uma página.

'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const zlib = require('zlib');

const PROIBIDOS = /[<>:"/\\|?*\x00-\x1F]/g;
const RESERVADOS = /^(con|prn|aux|nul|com[1-9]|lpt[1-9])$/i;
const TAMANHO_MINIMO = 1024; // um PDF de certidão real tem dezenas de KB
const MAX_NOME = 150;

const semAcentos = (s) => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '');
const comparavel = (s) => semAcentos(s).toUpperCase().replace(/[^0-9A-Z]+/g, ' ').trim();
const soDigitos = (s) => String(s || '').toUpperCase().replace(/[^0-9A-Z]/g, '');

// "36.690.216 SERGIO HENRIQUE" → "SERGIO HENRIQUE" quando o começo é o próprio identificador
// (a Receita põe a raiz do CNPJ no nome do MEI).
function semIdentificadorNoInicio(nome, registro) {
  let n = String(nome || '').trim();
  if (!registro) return n;
  const id = soDigitos(registro.identificador);
  const raiz = registro.tipo === 'CNPJ' ? id.slice(0, 8) : id;
  const m = n.match(/^[0-9A-Z][0-9A-Z./\-\s]*?(?=\s+[A-Za-zÀ-ÿ])/);
  if (m) {
    const inicio = soDigitos(m[0]);
    if (inicio && (inicio === id || inicio === raiz)) n = n.slice(m[0].length).trim();
  }
  return n.replace(/^[-–—:;,.\s]+/, '').trim();
}

// Os dois nomes se referem à mesma empresa/pessoa? (um contém o outro, ou ≥ 60% das palavras
// em comum, sem contar palavras curtas e formas societárias)
const PALAVRAS_FRACAS = new Set(['DA', 'DE', 'DO', 'DAS', 'DOS', 'E', 'LTDA', 'ME', 'EPP', 'SA', 'S', 'A', 'EIRELI', 'MEI']);
function nomesCorrespondem(a, b) {
  const x = comparavel(a);
  const y = comparavel(b);
  if (!x || !y) return false;
  if (x === y || x.includes(y) || y.includes(x)) return true;
  const px = new Set(x.split(' ').filter((p) => p.length > 1 && !PALAVRAS_FRACAS.has(p)));
  const py = new Set(y.split(' ').filter((p) => p.length > 1 && !PALAVRAS_FRACAS.has(p)));
  if (!px.size || !py.size) return false;
  let comuns = 0;
  for (const p of px) if (py.has(p)) comuns++;
  return comuns / Math.min(px.size, py.size) >= 0.6;
}

// Trecho seguro para nome de arquivo no Windows: sem acentos, sem caracteres proibidos,
// espaços viram "_".
function trechoSeguro(s) {
  const t = semAcentos(s)
    .replace(PROIBIDOS, ' ')
    .replace(/[^\x20-\x7E]/g, ' ')
    .replace(/\s+/g, '_')
    .replace(/_+/g, '_')
    .replace(/^[_.]+|[_. ]+$/g, '');
  return RESERVADOS.test(t) ? `_${t}` : t;
}

function prefixoDoIdentificador(registro) {
  const id = soDigitos(registro.identificador);
  if (registro.tipo === 'CNPJ') {
    // 36.690.216/0001-73 → 36.690.216_0001-73 (a barra não pode ir no nome do arquivo)
    const f = id.length === 14 ? `${id.slice(0, 2)}.${id.slice(2, 5)}.${id.slice(5, 8)}/${id.slice(8, 12)}-${id.slice(12)}` : (registro.formatado || id);
    return trechoSeguro(String(f).replace(/\//g, '_'));
  }
  if (registro.tipo === 'CPF') return `CPF_${id}`;
  return `IE_${id}`;
}

// Escolhe o nome (lista x site) e monta o nome do arquivo.
// Devolve { arquivo, nome, origemNome: 'lista'|'site'|'nenhum', aviso }
function nomeDoArquivo(registro, nomeSite) {
  if (!registro || !registro.tipo || !registro.identificador) throw new Error('registro ausente');
  const daLista = semIdentificadorNoInicio(registro.nome, registro);
  const doSite = semIdentificadorNoInicio(nomeSite, registro);
  let nome = '';
  let origemNome = 'nenhum';
  let aviso = null;
  if (daLista && (!doSite || nomesCorrespondem(daLista, doSite))) {
    nome = daLista; origemNome = 'lista';
  } else if (doSite) {
    nome = doSite; origemNome = 'site';
    if (daLista) aviso = `O nome da lista ("${daLista}") não confere com o do site ("${doSite}"); o arquivo usa o nome do site.`;
  } else if (daLista) {
    nome = daLista; origemNome = 'lista';
  }
  const prefixo = prefixoDoIdentificador(registro);
  let trecho = trechoSeguro(nome);
  const espaco = MAX_NOME - prefixo.length - 5;
  if (trecho.length > espaco) trecho = trecho.slice(0, espaco).replace(/[_.]+$/, '');
  return { arquivo: `${prefixo}${trecho ? '_' + trecho : ''}.pdf`, nome, origemNome, aviso };
}

// NOME.pdf → NOME_2.pdf → NOME_3.pdf ...
function caminhoLivre(pasta, arquivo) {
  const ext = path.extname(arquivo);
  const base = arquivo.slice(0, arquivo.length - ext.length);
  let c = path.join(pasta, arquivo);
  for (let i = 2; fs.existsSync(c); i++) c = path.join(pasta, `${base}_${i}${ext}`);
  return c;
}

function validarPdf(buf) {
  if (!Buffer.isBuffer(buf) || !buf.length) return { ok: false, motivo: 'arquivo vazio' };
  if (buf.length < TAMANHO_MINIMO) return { ok: false, motivo: `arquivo pequeno demais (${buf.length} bytes)` };
  if (buf.subarray(0, 5).toString('latin1') !== '%PDF-') {
    const inicio = buf.subarray(0, 200).toString('latin1').toLowerCase();
    const html = inicio.includes('<html') || inicio.includes('<!doctype');
    return { ok: false, motivo: html ? 'o conteúdo é uma página HTML, não um PDF' : 'o conteúdo não começa com %PDF-' };
  }
  const fim = buf.subarray(Math.max(0, buf.length - 2048)).toString('latin1');
  if (!fim.includes('%%EOF')) return { ok: false, motivo: 'PDF incompleto (sem %%EOF no final)' };
  const texto = buf.toString('latin1');
  const paginas = (texto.match(/\/Type\s*\/Page(?![s\w])/g) || []).length;
  const comObjetosComprimidos = /\/Type\s*\/ObjStm/.test(texto);
  if (!paginas && !comObjetosComprimidos) return { ok: false, motivo: 'PDF sem páginas' };
  return { ok: true, paginas: paginas || null, versao: buf.subarray(5, 8).toString('latin1') };
}

const sha256 = (buf) => crypto.createHash('sha256').update(buf).digest('hex');

// Texto legível do PDF: conteúdo das partes comprimidas (FlateDecode) e não comprimidas,
// com as strings (...) e <hex> dos comandos de texto. Não é um leitor completo de PDF: serve
// para achar o identificador na certidão. Fontes com códigos próprios (Identity-H) podem não
// dar texto legível — aí o resultado é "indeterminado".
function textoDoPdf(buf) {
  const bruto = buf.toString('latin1');
  const partes = [];
  const re = /stream\r?\n/g;
  let m;
  while ((m = re.exec(bruto)) && partes.length < 400) {
    const inicio = m.index + m[0].length;
    const fim = bruto.indexOf('endstream', inicio);
    if (fim < 0) break;
    const dados = buf.subarray(inicio, fim);
    let t = null;
    try { t = zlib.inflateSync(dados).toString('latin1'); } catch (e) {
      try { t = zlib.inflateSync(dados.subarray(0, dados.length - 2)).toString('latin1'); } catch (e2) { t = dados.toString('latin1'); }
    }
    partes.push(t);
    re.lastIndex = fim;
  }
  partes.push(bruto);
  const textos = [];
  for (const p of partes) {
    for (const s of p.match(/\((?:\\.|[^\\)])*\)/g) || []) textos.push(s.slice(1, -1).replace(/\\([()\\])/g, '$1'));
    for (const h of p.match(/<([0-9A-Fa-f\s]{4,})>/g) || []) {
      const hex = h.replace(/[<>\s]/g, '');
      if (hex.length % 2) continue;
      const b = Buffer.from(hex, 'hex');
      // 2 bytes por caractere (UTF-16) ou 1 byte
      textos.push(b.length > 1 && b[0] === 0 ? b.swap16().toString('utf16le') : b.toString('latin1'));
    }
  }
  return textos.join(' ');
}

// O identificador consultado aparece na certidão?
//   confere       → aparece (formatado ou só dígitos)
//   diverge       → o texto é legível, fala de certidão, tem outro documento e NÃO o pesquisado
//   indeterminado → o texto não é legível o bastante para conferir
function conferirIdentificador(buf, registro) {
  const texto = textoDoPdf(buf);
  const digitos = texto.toUpperCase().replace(/[^0-9A-Z]/g, '');
  const id = soDigitos(registro.identificador);
  const idSemZeros = id.replace(/^0+/, '');
  const legivel = /certid/i.test(semAcentos(texto));
  if (id && (digitos.includes(id) || (registro.tipo === 'IE' && idSemZeros.length >= 6 && digitos.includes(idSemZeros)))) {
    return { situacao: 'confere', legivel };
  }
  if (!legivel) return { situacao: 'indeterminado', legivel };
  const outros = (texto.match(/\d{2}\.?\d{3}\.?\d{3}\/?\d{4}-?\d{2}|\d{3}\.?\d{3}\.?\d{3}-?\d{2}/g) || []).map(soDigitos).filter((x) => x !== id);
  return outros.length ? { situacao: 'diverge', legivel, encontrados: [...new Set(outros)].slice(0, 3) } : { situacao: 'indeterminado', legivel };
}

// Grava "buf" em "destino" sem nunca deixar arquivo pela metade: temporário na mesma pasta,
// conferência (tamanho e conteúdo relidos do disco) e só então o nome final.
function gravarConferido(destino, buf) {
  const temp = `${destino}.${process.pid}.${Date.now()}.parcial`;
  try {
    fs.writeFileSync(temp, buf, { flag: 'wx' });
    const relido = fs.readFileSync(temp);
    if (relido.length !== buf.length || sha256(relido) !== sha256(buf)) throw new Error('o arquivo gravado não confere com o recebido');
    if (fs.existsSync(destino)) throw new Error('o nome final foi ocupado durante a gravação');
    fs.renameSync(temp, destino);
  } catch (e) {
    try { fs.unlinkSync(temp); } catch (_) { /* já não existe */ }
    throw e;
  }
  const v = validarPdf(fs.readFileSync(destino));
  if (!v.ok) throw new Error(`o PDF salvo não passou na conferência: ${v.motivo}`);
  return v;
}

function dormir(ms) { return new Promise((r) => setTimeout(r, ms)); }

// Espera o download do Chrome terminar: o arquivo existe, não há ".crdownload" ao lado e o
// tamanho ficou parado por ~1,5 s.
async function esperarDownloadCompleto(caminho, { limite = 60000 } = {}) {
  const fim = Date.now() + limite;
  let ultimo = -1;
  let parado = 0;
  while (Date.now() < fim) {
    const existe = fs.existsSync(caminho);
    const temp = fs.existsSync(`${caminho}.crdownload`);
    if (existe && !temp) {
      const t = fs.statSync(caminho).size;
      if (t > 0 && t === ultimo) {
        if (++parado >= 3) return t;
      } else {
        parado = 0;
        ultimo = t;
      }
    }
    await dormir(500);
  }
  throw new Error('o download não terminou a tempo');
}

// pasta: pasta de resultados; registro: o da lista; nomeSite: Nome/Razão Social da tabela.
// Uma das duas fontes: bytes (Buffer) ou caminhoDownload (arquivo baixado pelo Chrome).
// Devolve { ok, caminho, arquivo, bytes, paginas, sha256, origemNome, aviso } ou { ok:false, erro }.
async function salvarCertidao({ pasta, registro, nomeSite = '', bytes = null, caminhoDownload = null, aoProgresso = () => {} }) {
  try {
    if (!pasta) throw new Error('pasta de resultados não configurada');
    if (!fs.existsSync(pasta) || !fs.statSync(pasta).isDirectory()) throw new Error(`a pasta de resultados não existe: ${pasta}`);
    let buf = bytes;
    if (!buf && caminhoDownload) {
      const origem = path.resolve(String(caminhoDownload));
      if (path.extname(origem).toLowerCase() === '.crdownload') throw new Error('download ainda em andamento');
      aoProgresso('DOWNLOAD', `Aguardando o download terminar (${path.basename(origem)})...`);
      await esperarDownloadCompleto(origem);
      buf = fs.readFileSync(origem);
    }
    if (!buf) throw new Error('nenhum conteúdo recebido');
    const v = validarPdf(buf);
    if (!v.ok) throw new Error(`o documento recebido não é um PDF válido: ${v.motivo}`);

    aoProgresso('VALIDAÇÃO', 'Conferindo identificação do documento...');
    const ident = conferirIdentificador(buf, registro);
    const n = nomeDoArquivo(registro, nomeSite);
    let nomeFinal = n.arquivo;
    if (ident.situacao === 'confere') aoProgresso('VALIDAÇÃO', `O identificador consultado (${registro.formatado || registro.identificador}) aparece na certidão.`);
    else if (ident.situacao === 'indeterminado') aoProgresso('VALIDAÇÃO', 'O texto do PDF não permite conferir o identificador (fonte codificada); a correspondência foi conferida no resultado da consulta.');
    else {
      // A certidão parece ser de OUTRO documento: preserva o arquivo, mas com aviso no nome,
      // e a execução NÃO é dada como concluída.
      nomeFinal = n.arquivo.replace(/\.pdf$/, '_CONFERIR.pdf');
      aoProgresso('VALIDAÇÃO', `ATENÇÃO: a certidão não mostra ${registro.formatado || registro.identificador} e cita outro documento (${ident.encontrados.join(', ')}).`);
    }
    const destino = caminhoLivre(pasta, nomeFinal);
    // Nunca sai da pasta escolhida.
    if (path.relative(path.resolve(pasta), destino).startsWith('..')) throw new Error('nome de arquivo inválido');
    aoProgresso('SALVAMENTO', `Salvando PDF na pasta configurada (${path.basename(destino)})...`);
    const conf = gravarConferido(destino, buf);
    aoProgresso('VERIFICAÇÃO', `Validando arquivo salvo: existe, ${buf.length} bytes, começa com %PDF- e termina com %%EOF${conf.paginas ? `, ${conf.paginas} página(s)` : ''}.`);
    if (ident.situacao === 'diverge') {
      return { ok: false, erro: `a certidão recebida não mostra o identificador consultado (cita ${ident.encontrados.join(', ')}); o arquivo foi guardado como ${path.basename(destino)} para conferência`, caminho: destino };
    }

    // Veio do Downloads: o original só é apagado depois de a cópia na pasta estar conferida
    // (o efeito é o de mover o arquivo; nada fica duplicado no Downloads).
    if (caminhoDownload) {
      try { fs.unlinkSync(path.resolve(String(caminhoDownload))); } catch (_) { /* fica no Downloads; avisado abaixo */ }
    }
    const ficou = caminhoDownload && fs.existsSync(path.resolve(String(caminhoDownload)));
    return {
      ok: true,
      caminho: destino,
      arquivo: path.basename(destino),
      bytes: buf.length,
      paginas: conf.paginas,
      sha256: sha256(buf),
      origemNome: n.origemNome,
      aviso: [n.aviso, ficou ? `A cópia baixada continua em ${caminhoDownload} (não foi possível removê-la).` : null].filter(Boolean).join(' ') || null,
      renomeado: path.basename(destino) !== n.arquivo,
      identificacao: ident.situacao,
    };
  } catch (e) {
    return { ok: false, erro: e.message };
  }
}

module.exports = { salvarCertidao, textoDoPdf, conferirIdentificador, nomeDoArquivo, validarPdf, nomesCorrespondem, caminhoLivre, semIdentificadorNoInicio, trechoSeguro, esperarDownloadCompleto, sha256 };
