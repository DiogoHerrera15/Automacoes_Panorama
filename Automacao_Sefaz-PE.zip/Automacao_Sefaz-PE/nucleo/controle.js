// Controle de UMA execução por vez, compartilhado pela interface e pela linha de comando.
//
//   iniciar()  → cria uma sessão de uso único (token), abre o Chrome anônimo no portal
//   extensão   → GET /sessao, POST /reivindicar (pega a sessão), POST /evento (registros e
//                status), GET /comando (pausar/continuar/parar pedidos aqui)
//
// A ponte (rotas acima) aceita só chamadas sem origem ou de "chrome-extension://" e exige o
// token da sessão. Este módulo não controla o navegador: quem age na página é a extensão.

'use strict';

const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const C = require('./comum');
const Arquivo = require('./arquivo_certidao');
const Lista = require('./lista');
const Pasta = require('./pasta');

const { K } = C;

// PDF em base64 vindo da extensão: até ~15 MB de documento.
const LIMITE_PDF_BASE64 = 21 * 1024 * 1024;

// Etapa da extensão → rótulo do terminal, quando a extensão não mandou um.
const TAG_POR_ETAPA = {
  verificar_portal: 'ACESSO', verificar_login: 'LOGIN', acionar_login_govbr: 'LOGIN',
  autenticacao_govbr: 'GOV.BR', confirmar_acesso: 'VALIDAÇÃO', identificar_tela_sefaz: 'ACESSO',
  localizar_certidao_negativa: 'CERTIDÃO', abrir_certidao_negativa: 'CERTIDÃO', selecionar_tipo_documento: 'TIPO',
  preencher_identificador: 'PREENCHIMENTO', clicar_pesquisar: 'PESQUISA', aguardar_resposta: 'PESQUISA',
  analisar_resultado: 'RESULTADO', clicar_emitir: 'EMISSÃO', aguardar_emissao: 'CONFIRMAÇÃO',
  clicar_visualizar: 'VISUALIZAÇÃO', aguardar_arquivo: 'PDF',
};

// fase: parada | abrindo | executando | aguardando_voce | pausada | erro | concluida | interrompida
function estadoVazio() {
  return { fase: 'parada', status: 'ocioso', etapa: null, estadoAutomacao: null, mensagem: 'Pronta para iniciar.', aguardandoVoce: false, erro: null, conectada: false, iniciadaEm: null, config: null, modo: null };
}

// selecionarCertificado: Modo 2 (janela nativa do Windows). Injetável nos testes.
function criarControle({ registro, abrirNavegador = true, perfil = 'Default', chrome = null, esperaExtensao = 300, aoTerminar = null, selecionarCertificado = null } = {}) {
  let sessao = null;
  let execucao = estadoVazio();
  let timers = [];
  const selecionar = selecionarCertificado || require('./certificado_nativo').selecionarCertificado;

  const limparTimers = () => { timers.forEach(clearTimeout); timers = []; };
  const ativa = () => sessao && ['abrindo', 'executando', 'aguardando_voce', 'pausada', 'erro'].includes(execucao.fase);

  // ---- Modo 2: janela nativa "Selecione um certificado" ------------------------------------
  // Começa quando a extensão avisa que clicou em "Seu certificado digital". Uma seleção por
  // vez; Parar (ou o fim da execução) interrompe o controle do mouse na hora.
  function iniciarSelecaoNativa() {
    if (!sessao || !sessao.nativo || sessao.selecaoNativa) return;
    registro.escrever('CERTIFICADO', 'Detectando janela de certificados... (mouse do Windows; mexer o mouse ou ESC cancela)');
    const s = selecionar({
      cert: sessao.nativo,
      velocidade: (sessao.config && sessao.config.velocidadeMouse) || 'normal',
      aoEvento: (ev) => {
        if (ev.tipo === 'progresso') registro.escrever('CERTIFICADO', ev.mensagem);
      },
    });
    sessao.selecaoNativa = s;
    const daSessao = sessao;
    s.fim.then((r) => {
      daSessao.selecaoNativa = null;
      const r2 = r || {};
      if (r2.resultado === 'ok') {
        registro.escrever('CERTIFICADO', r2.mensagem);
      } else if (r2.resultado === 'nao_encontrada') {
        // Normal quando o Chrome já lembra o certificado desta sessão anônima (2º login).
        registro.escrever('CERTIFICADO', `${r2.mensagem} Se o Chrome já usou o certificado nesta janela anônima, ele não pergunta de novo e o login segue sozinho; se a janela aparecer depois, escolha o certificado manualmente.`, 'aviso');
      } else {
        registro.escrever('AGUARDANDO', r2.mensagem || 'Selecione o certificado manualmente na janela do Chrome.', 'aviso');
        if (r2.diagnostico) registro.escrever('CERTIFICADO', `Diagnóstico da janela: ${r2.diagnostico}`, 'aviso');
      }
      execucao = { ...execucao, selecaoNativa: r2.resultado };
    });
  }

  // ---- Certidão em PDF (POST /arquivo) -------------------------------------------------------
  // A extensão manda o PDF capturado na página (base64) ou o caminho do arquivo que o Chrome
  // baixou. Uma chegada por vez (fila): se o mesmo documento chegar pelos dois caminhos, o
  // segundo é reconhecido como duplicado (mesmo conteúdo) e não gera outro arquivo.
  let filaArquivo = Promise.resolve();
  function receberArquivo(dados) {
    const p = filaArquivo.then(() => salvarRecebido(dados), () => salvarRecebido(dados));
    filaArquivo = p.catch(() => {});
    return p;
  }

  async function salvarRecebido(dados) {
    const s = sessao;
    if (!s) return { ok: false, erro: 'sem sessão' };
    const cfg = s.config || {};
    const via = ['blob', 'data', 'url', 'janela', 'download', 'html'].includes(dados.via) ? dados.via : 'desconhecida';
    const ROTULO_VIA = { blob: 'PDF original gerado pela página', data: 'PDF original embutido na página', url: 'PDF original aberto na página/aba atual', janela: 'PDF original aberto numa nova aba', download: 'PDF original baixado pelo Chrome', html: 'PDF gerado da página HTML da certidão (o site não ofereceu o PDF)' };
    if (!cfg.pastaResultados) return { ok: false, erro: 'pasta de resultados não configurada' };
    if (!cfg.registro) return { ok: false, erro: 'registro da lista ausente' };

    let bytes = null;
    let caminhoDownload = null;
    if (typeof dados.base64 === 'string' && dados.base64) {
      bytes = Buffer.from(dados.base64, 'base64');
    } else if (via === 'download' && typeof dados.caminhoDownload === 'string' && dados.caminhoDownload) {
      caminhoDownload = dados.caminhoDownload;
      try {
        const st = fs.statSync(caminhoDownload);
        // Só aceita um arquivo comum, criado agora (o download que acabou de acontecer).
        if (!st.isFile() || Date.now() - st.mtimeMs > 15 * 60000) return { ok: false, erro: 'o arquivo baixado não é recente' };
      } catch (e) {
        return { ok: false, erro: 'o arquivo baixado não foi encontrado' };
      }
    } else {
      return { ok: false, erro: 'nenhum conteúdo recebido' };
    }

    registro.escrever('PDF', `Documento recebido (${ROTULO_VIA[via] || via}${bytes ? `, ${Math.round(bytes.length / 1024)} KB` : ''}).`);

    // Mesmo documento já salvo nesta execução? (o site pode abrir e baixar ao mesmo tempo)
    if (s.certidao) {
      let conteudo = bytes;
      if (!conteudo && caminhoDownload) {
        try { await Arquivo.esperarDownloadCompleto(caminhoDownload); conteudo = fs.readFileSync(caminhoDownload); } catch (e) { conteudo = null; }
      }
      if (conteudo && Arquivo.sha256(conteudo) === s.certidao.sha256) {
        if (caminhoDownload) { try { fs.unlinkSync(caminhoDownload); } catch (_) { /* fica no Downloads */ } }
        registro.escrever('ARQUIVO', `O mesmo documento chegou de novo (${ROTULO_VIA[via] || via}); nenhuma cópia extra foi criada.`);
        return { ok: true, duplicado: true, caminho: s.certidao.caminho, arquivo: s.certidao.arquivo, bytes: s.certidao.bytes };
      }
      registro.escrever('AVISO', 'Chegou um segundo documento diferente do primeiro; ele também será salvo (sem sobrescrever).', 'aviso');
    }

    const r = await Arquivo.salvarCertidao({
      pasta: cfg.pastaResultados,
      registro: cfg.registro,
      nomeSite: typeof dados.nomeSite === 'string' ? dados.nomeSite.slice(0, 200) : '',
      bytes,
      caminhoDownload,
      aoProgresso: (tag, msg) => registro.escrever(tag, msg),
    });
    if (!r.ok) {
      registro.escrever('ERRO', `O documento não foi salvo: ${r.erro}.`, 'erro');
      return { ok: false, erro: r.erro };
    }
    if (r.aviso) registro.escrever('AVISO', r.aviso, 'aviso');
    if (r.renomeado) registro.escrever('ARQUIVO', 'Já existia um arquivo com esse nome; o novo recebeu um sufixo (nada foi sobrescrito).');
    registro.escrever('ARQUIVO', `PDF salvo na pasta configurada: ${r.caminho} (${Math.round(r.bytes / 1024)} KB${r.paginas ? `, ${r.paginas} página(s)` : ''}; nome ${r.origemNome === 'lista' ? 'da lista' : r.origemNome === 'site' ? 'do site' : 'ausente'}).`);
    if (!s.certidao) s.certidao = { caminho: r.caminho, arquivo: r.arquivo, bytes: r.bytes, sha256: r.sha256 };
    execucao = { ...execucao, arquivo: { caminho: r.caminho, arquivo: r.arquivo, bytes: r.bytes } };
    return { ok: true, caminho: r.caminho, arquivo: r.arquivo, bytes: r.bytes, paginas: r.paginas };
  }

  function pararSelecaoNativa() {
    if (sessao && sessao.selecaoNativa) {
      sessao.selecaoNativa.parar();
      sessao.selecaoNativa = null;
      registro.escrever('WINDOWS', 'Controle do mouse do Windows encerrado.');
    }
  }

  // ---- Lista inteira (nucleo/lote.js) --------------------------------------------------------
  // A extensão processa UM registro por vez. Ao terminar um (sucesso, não encontrado ou erro),
  // ela chama POST /registro: o resultado é gravado no arquivo de controle e a resposta traz o
  // próximo registro. "sucesso" só vale se o PDF DESTE registro foi salvo e conferido aqui.
  let loteAtual = null;
  const paraExtensao = (i) => (i ? { linha: i.linha, tipo: i.tipo, identificador: i.identificador, formatado: i.formatado, mascarado: i.mascarado, nome: i.nome } : null);
  const infoLote = () => {
    const r = loteAtual.resumo();
    return { total: r.total, posicao: r.atual ? r.atual.posicao : null, intervaloMs: sessao ? sessao.intervaloMs : 5000, maxTentativas: sessao ? sessao.maxTentativas : 3, limiteEtapaMs: sessao ? sessao.limiteEtapaMs : 120000 };
  };
  const rotuloRegistro = (i) => `${Lista.ROTULOS[i.tipo] || i.tipo} ${i.formatado} — ${i.nome}`;

  function anunciarRegistro(item) {
    const r = loteAtual.resumo();
    registro.escrever('LOTE', `Registro ${r.atual.posicao}/${r.total}: ${rotuloRegistro(item)} (tentativa ${item.tentativas}).`);
  }

  async function registrarResultado(d) {
    const s = sessao;
    const item = loteAtual && loteAtual.atual();
    if (!s || !item) return { ok: false, erro: 'nenhum registro em processamento' };
    let status = ['sucesso', 'nao_encontrado'].includes(d.situacao) ? d.situacao : 'erro';
    let mensagem = typeof d.mensagem === 'string' ? d.mensagem.slice(0, 500) : null;
    if (status === 'sucesso') {
      const ok = s.certidao && fs.existsSync(s.certidao.caminho) && Arquivo.validarPdf(fs.readFileSync(s.certidao.caminho)).ok;
      if (!ok) {
        status = 'erro';
        mensagem = 'A página indicou sucesso, mas o computador não confirmou o PDF deste registro na pasta.';
      }
    }
    const feito = loteAtual.concluirAtual({ status, mensagem, codigo: d.codigo || null, etapa: d.etapa || null, caminho: s.certidao && s.certidao.caminho });
    s.certidao = null;
    execucao = { ...execucao, arquivo: null };
    const r = loteAtual.resumo();
    const sufixo = `(${r.finalizados}/${r.total} — ${r.percentual.toLocaleString('pt-BR')}%)`;
    if (status === 'sucesso') registro.escrever('LOTE', `Concluído com sucesso: ${rotuloRegistro(feito)} → ${feito.caminho} ${sufixo}`);
    else if (status === 'nao_encontrado') registro.escrever('LOTE', `Não encontrado: ${rotuloRegistro(feito)}${mensagem ? ` (${mensagem})` : ''} ${sufixo}`, 'aviso');
    else registro.escrever('LOTE', `Erro em ${rotuloRegistro(feito)}: ${d.codigo ? `${d.codigo} na etapa ${d.etapa || '?'} — ` : ''}${mensagem || 'sem detalhe'} ${sufixo}. A lista continua.`, 'aviso');

    const prox = loteAtual.proximo();
    if (prox) {
      s.config = { ...s.config, registro: paraExtensao(prox), lote: infoLote() };
      execucao = { ...execucao, config: s.config };
      anunciarRegistro(prox);
      return { ok: true, proximo: paraExtensao(prox), lote: infoLote(), intervaloMs: s.intervaloMs };
    }
    // Fim da lista: planilha e resumo.
    let planilha = null;
    try { planilha = loteAtual.gerarPlanilha(Pasta.carimbo()); } catch (e) { registro.escrever('ERRO', `Não foi possível gerar a planilha: ${e.message}`, 'erro'); }
    const f = loteAtual.resumo();
    registro.escrever('LOTE', 'PROCESSAMENTO FINALIZADO');
    registro.escrever('LOTE', `Total de registros: ${f.total}`);
    registro.escrever('LOTE', `Certidões salvas: ${f.sucesso}`);
    registro.escrever('LOTE', `Registros com erro: ${f.erro}`);
    registro.escrever('LOTE', `Registros não encontrados: ${f.naoEncontrado}`);
    if (f.invalido) registro.escrever('LOTE', `Linhas inválidas na lista (não processadas): ${f.invalido}`);
    registro.escrever('LOTE', `Pasta de resultados: ${s.config.pastaResultados}`);
    if (planilha) registro.escrever('LOTE', `Planilha: ${planilha}`);
    execucao = { ...execucao, planilha };
    return { ok: true, proximo: null, resumo: { total: f.total, sucesso: f.sucesso, erro: f.erro, naoEncontrado: f.naoEncontrado }, planilha };
  }

  // Captura da página no momento da falha de um registro: <pasta>\relatorios\falhas\*.jpg
  function salvarEvidencia(d) {
    const pasta = sessao && sessao.config && sessao.config.pastaResultados;
    const item = loteAtual && loteAtual.atual();
    if (!pasta || !item || typeof d.base64 !== 'string' || !d.base64) return { ok: false };
    try {
      const buf = Buffer.from(d.base64, 'base64');
      if (buf.length < 100 || buf[0] !== 0xFF || buf[1] !== 0xD8) return { ok: false, erro: 'imagem inválida' };
      const dir = path.join(pasta, 'relatorios', 'falhas');
      fs.mkdirSync(dir, { recursive: true });
      const nome = Arquivo.trechoSeguro(`__`) + '.jpg';
      const destino = Arquivo.caminhoLivre(dir, nome);
      fs.writeFileSync(destino, buf, { flag: 'wx' });
      loteAtual.registrarEvidencia(destino);
      registro.escrever('RECUPERAÇÃO', `Captura da página no momento da falha: `);
      return { ok: true, caminho: destino };
    } catch (e) {
      return { ok: false, erro: e.message };
    }
  }

  function terminar(fase, mensagem, nivel = 'info') {
    if (loteAtual && fase !== 'concluida') loteAtual.interromper();
    pararSelecaoNativa();
    limparTimers();
    execucao = { ...execucao, fase, mensagem, aguardandoVoce: false };
    if (mensagem) registro.escrever('FIM', mensagem, nivel);
    if (aoTerminar) aoTerminar(fase);
  }

  function orientarConexao() {
    if (!sessao || sessao.reivindicada || !ativa()) return;
    registro.escrever('AVISO', 'A extensão ainda não se conectou. Confira:', 'aviso');
    registro.escrever('AVISO', `  1. chrome://extensions > ${C.NOME_EXTENSAO} ligada, versão ${C.VERSAO_EXTENSAO} (se não, clique na setinha de recarregar);`, 'aviso');
    registro.escrever('AVISO', '  2. Detalhes > "Permitir no modo anônimo" LIGADO (feche as janelas anônimas e inicie de novo depois de ligar);', 'aviso');
    registro.escrever('AVISO', '  3. a janela anônima está no portal SEFAZ-PE e terminou de carregar (F5 se preciso).', 'aviso');
    execucao = { ...execucao, mensagem: 'A extensão ainda não se conectou na janela anônima. Veja as orientações nos registros.' };
  }

  // config: { velocidadeMouse, metodoLogin, certificado (resumo), pastaResultados, registro, selecaoNativa }
  // nativo: { serial, titular, emissor } do certificado escolhido, para o Modo 2. Fica SÓ aqui
  // (não vai para a extensão nem para a página).
  // lote: de nucleo/lote.js (lista inteira). intervaloSegundos: pausa entre registros.
  function iniciar({ modo = 'acesso', origem = 'interface', config = {}, nativo = null, lote = null, intervaloSegundos = 5, maxTentativas = 3, limiteEtapaSegundos = 120 } = {}) {
    if (ativa()) return { ok: false, erro: 'Já existe uma execução em andamento. Pare-a antes de iniciar outra.' };
    limparTimers();
    const intervaloMs = Math.min(Math.max(Number(intervaloSegundos) || 0, 0), 120) * 1000;
    loteAtual = lote;
    if (lote) {
      const primeiro = lote.proximo();
      if (!primeiro) {
        loteAtual = null;
        return { ok: false, erro: 'Todos os registros da lista já foram processados (veja controle_execucao.json na pasta). Nada pendente.' };
      }
      config = { ...config, registro: paraExtensao(primeiro), lote: null };
    }
    sessao = { token: crypto.randomUUID(), modo, origem, config, nativo: nativo && nativo.serial ? nativo : null, reivindicada: false, tabId: null, comandoPendente: null, selecaoNativa: null, intervaloMs,
      maxTentativas: Math.min(Math.max(Number(maxTentativas) || 3, 1), 6), limiteEtapaMs: Math.min(Math.max(Number(limiteEtapaSegundos) || 120, 30), 600) * 1000 };
    if (lote) {
      sessao.config = { ...config, lote: infoLote() };
      config = sessao.config;
      anunciarRegistro(lote.atual());
    }
    execucao = { ...estadoVazio(), fase: 'abrindo', estadoAutomacao: 'INICIANDO', mensagem: 'Abrindo o Chrome em modo anônimo...', iniciadaEm: Date.now(), config, modo };

    if (abrirNavegador) {
      registro.escrever('EXTENSÃO', `Verificando ${C.NOME_EXTENSAO} (perfil do Chrome "${perfil}")...`);
      for (const m of C.mensagensInstalacao(C.verificarInstalacao(perfil))) {
        registro.escrever(m.nivel === 'aviso' ? 'AVISO' : 'EXTENSÃO', m.texto, m.nivel);
      }
      const exe = C.caminhoChrome(chrome);
      if (!exe) {
        registro.escrever('ERRO', 'Google Chrome não encontrado. Informe o caminho com --chrome "C:\\...\\chrome.exe".', 'erro');
        sessao = null;
        execucao = { ...estadoVazio(), fase: 'erro', mensagem: 'Google Chrome não encontrado.', erro: 'Google Chrome não encontrado.' };
        return { ok: false, erro: 'Google Chrome não encontrado.' };
      }
      registro.escrever('NAVEGADOR', 'Abrindo Chrome em modo anônimo...');
      C.abrirChromeAnonimo(exe, perfil, K.URL_INICIAL, (e) => registro.escrever('ERRO', `Não foi possível abrir o Chrome: ${e.message}`, 'erro'));
    } else {
      registro.escrever('NAVEGADOR', 'Modo de teste: o Chrome não será aberto.');
    }
    registro.escrever('EXTENSÃO', 'Aguardando a extensão conectar na aba anônima do portal...');
    registro.escrever('ACESSO', 'Aguardando página inicial...');
    timers.push(setTimeout(orientarConexao, 25000), setTimeout(orientarConexao, 90000));
    timers.push(setTimeout(() => {
      if (sessao && !sessao.reivindicada && ativa()) {
        sessao = null;
        terminar('erro', `A extensão não se conectou em ${esperaExtensao} s. Ajuste o que foi indicado e inicie de novo.`, 'aviso');
        execucao.erro = 'A extensão não se conectou.';
      }
    }, esperaExtensao * 1000));
    return { ok: true };
  }

  // Pausar/Continuar/Parar pedidos pela interface. A extensão busca o pedido em até ~2 s.
  function comando(c) {
    if (!['pausar', 'continuar', 'parar'].includes(c)) return { ok: false, erro: 'Comando desconhecido.' };
    if (!sessao || !ativa()) return { ok: false, erro: 'Não há execução em andamento.' };
    if (c === 'parar' || c === 'pausar') pararSelecaoNativa();
    if (!sessao.reivindicada) {
      if (c === 'parar') {
        sessao = null;
        terminar('interrompida', 'Execução cancelada antes de a extensão se conectar. O navegador continua aberto.');
        return { ok: true };
      }
      return { ok: false, erro: 'A extensão ainda não se conectou; aguarde ou clique em Parar.' };
    }
    sessao.comandoPendente = c;
    registro.escrever('CONTROLE', { pausar: 'Pausa pedida pela interface...', continuar: 'Continuação pedida pela interface...', parar: 'Parada pedida pela interface...' }[c]);
    return { ok: true };
  }

  function aoEvento(ev) {
    if (ev.estadoAutomacao && K.ESTADOS_AUTOMACAO[ev.estadoAutomacao]) {
      if (ev.estadoAutomacao !== execucao.estadoAutomacao && ev.tipo === 'status') {
        registro.escrever('ESTADO', `${ev.estadoAutomacao} (${K.ESTADOS_AUTOMACAO[ev.estadoAutomacao]})`);
      }
      execucao = { ...execucao, estadoAutomacao: ev.estadoAutomacao };
    }
    if (ev.tipo === 'log' && ev.acaoNativa === 'selecionar_certificado') iniciarSelecaoNativa();
    if (ev.tipo === 'ocorrencia') {
      if (loteAtual && ev.ocorrencia) loteAtual.registrarOcorrencia(ev.ocorrencia);
      return;
    }
    if (ev.tipo === 'log') {
      const tag = ev.tag || TAG_POR_ETAPA[ev.etapa] || 'INFO';
      const texto = ev.erro && !String(ev.mensagem || '').includes(ev.erro) ? `${ev.mensagem} (${ev.erro})` : ev.mensagem;
      registro.escrever(tag, texto || '', ev.nivel);
      execucao = { ...execucao, etapa: ev.etapa || execucao.etapa, ultimaLinha: texto };
      return;
    }
    if (ev.tipo !== 'status') return;
    const base = { ...execucao, status: ev.status, mensagem: ev.mensagem || execucao.mensagem, etapa: ev.etapa || execucao.etapa };
    switch (ev.status) {
      case 'executando':
        execucao = { ...base, fase: 'executando', aguardandoVoce: false, erro: null };
        break;
      case 'aguardando_login':
        execucao = { ...base, fase: 'aguardando_voce', aguardandoVoce: true };
        registro.escrever('AGUARDANDO', ev.mensagem || 'Aguardando você no navegador.', 'aviso');
        break;
      case 'pausado':
        execucao = { ...base, fase: 'pausada', aguardandoVoce: false };
        registro.escrever('PAUSA', 'Execução pausada. Clique em Continuar para retomar.', 'aviso');
        break;
      case 'erro':
        execucao = { ...base, fase: 'erro', aguardandoVoce: true, erro: ev.mensagem || ev.erro };
        registro.escrever('ERRO', ev.mensagem || ev.erro || 'Erro na automação.', 'erro');
        registro.escrever('AVISO', 'Resolva no navegador e clique em Continuar (aqui, no painel da página ou no ícone da extensão).', 'aviso');
        break;
      // A sessão continua aceitando os últimos registros da extensão (mesmo token), mas deixa de
      // estar "ativa": não pode ser reivindicada de novo e um novo Iniciar cria outra.
      case 'concluido':
        execucao = { ...base, fase: 'concluida', aguardandoVoce: false, erro: null };
        terminar('concluida', 'Etapa encerrada. O navegador continua aberto.');
        break;
      case 'parado':
        execucao = { ...base, fase: 'interrompida', aguardandoVoce: false };
        terminar('interrompida', `Execução interrompida: ${ev.mensagem || ''}`, 'aviso');
        break;
      default:
        execucao = base;
    }
  }

  // ---- Ponte com a extensão (devolve true se tratou a requisição) ----------------------------

  function responder(res, codigo, corpo) {
    res.writeHead(codigo, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
    res.end(JSON.stringify(corpo));
  }

  function lerCorpo(req, limite = 65536) {
    return new Promise((resolve, reject) => {
      let corpo = '';
      req.on('data', (parte) => {
        corpo += parte;
        if (corpo.length > limite) { req.destroy(); reject(new Error('corpo grande demais')); }
      });
      req.on('end', () => {
        try { resolve(JSON.parse(corpo || '{}')); } catch (e) { reject(e); }
      });
      req.on('error', reject);
    });
  }

  function tratarPonte(req, res) {
    const url = new URL(req.url, 'http://127.0.0.1');
    const rota = url.pathname;
    if (!['/sessao', '/reivindicar', '/evento', '/comando', '/arquivo', '/registro', '/evidencia'].includes(rota)) return false;
    const origem = req.headers.origin;
    if (origem && !origem.startsWith('chrome-extension://')) { responder(res, 403, { ok: false }); return true; }

    if (req.method === 'GET' && rota === '/sessao') {
      const s = sessao && !sessao.reivindicada && ativa() ? sessao : null;
      responder(res, 200, s ? { ativa: true, token: s.token, modo: s.modo, origem: s.origem, config: s.config } : { ativa: false });
      return true;
    }
    if (req.method === 'GET' && rota === '/comando') {
      if (!sessao || url.searchParams.get('token') !== sessao.token) { responder(res, 403, { ok: false }); return true; }
      const c = sessao.comandoPendente;
      sessao.comandoPendente = null;
      responder(res, 200, { ok: true, comando: c });
      return true;
    }
    if (req.method !== 'POST') { responder(res, 404, { ok: false }); return true; }

    lerCorpo(req, rota === '/arquivo' || rota === '/evidencia' ? LIMITE_PDF_BASE64 : 65536).then(async (dados) => {
      if (!sessao || dados.token !== sessao.token) return responder(res, 403, { ok: false });
      if (rota === '/arquivo') return responder(res, 200, await receberArquivo(dados));
      if (rota === '/evidencia') return responder(res, 200, salvarEvidencia(dados));
      if (rota === '/registro') {
        // Espera um PDF ainda em gravação antes de dar o registro por encerrado.
        await filaArquivo;
        return responder(res, 200, await registrarResultado(dados));
      }
      if (rota === '/reivindicar') {
        if (sessao.reivindicada) return responder(res, 409, { ok: false, erro: 'sessão já em uso' });
        sessao.reivindicada = true;
        sessao.tabId = dados.tabId;
        execucao = { ...execucao, fase: 'executando', conectada: true, mensagem: 'Extensão conectada. Acessando o portal...' };
        registro.escrever('EXTENSÃO', `Extensão conectada na janela anônima (versão ${dados.versao || '?'}; aba ${dados.tabId}).`);
        if (dados.incognitoPermitido === false) registro.escrever('AVISO', 'O Chrome informa que a extensão não tem permissão no modo anônimo.', 'aviso');
        return responder(res, 200, { ok: true });
      }
      aoEvento(dados);
      return responder(res, 200, { ok: true });
    }).catch(() => responder(res, 400, { ok: false }));
    return true;
  }

  return {
    iniciar,
    comando,
    tratarPonte,
    estado: () => ({ ...execucao, sessaoAtiva: !!ativa(), lote: loteAtual ? { ...loteAtual.resumo(), itens: loteAtual.itens() } : null }),
    ativa,
  };
}

module.exports = { criarControle, TAG_POR_ETAPA };
