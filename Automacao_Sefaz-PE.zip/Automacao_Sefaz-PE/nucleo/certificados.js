// Certificados digitais do Windows (repositório "Pessoal" do usuário: Cert:\CurrentUser\My),
// o mesmo que o Chrome usa no Windows. SOMENTE LEITURA: lê os dados públicos do certificado
// (titular, CPF/CNPJ, validade, emissor, impressão digital). Não exporta certificado, não
// acessa a chave privada e não pede PIN. Tokens A3 aparecem quando estão conectados.

'use strict';

const { execFile } = require('child_process');

const OID_AUTENTICACAO_CLIENTE = '1.3.6.1.5.5.7.3.2';

const SCRIPT_PS = `
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$ErrorActionPreference = 'Stop'
$lista = @(Get-ChildItem Cert:\\CurrentUser\\My | ForEach-Object {
  [pscustomobject]@{
    subject       = $_.Subject
    issuer        = $_.Issuer
    thumbprint    = $_.Thumbprint
    serial        = $_.SerialNumber
    notBefore     = $_.NotBefore.ToUniversalTime().ToString('o')
    notAfter      = $_.NotAfter.ToUniversalTime().ToString('o')
    hasPrivateKey = $_.HasPrivateKey
    eku           = @($_.EnhancedKeyUsageList | ForEach-Object { [string]$_.ObjectId })
  }
})
ConvertTo-Json -InputObject $lista -Depth 4 -Compress
`;

function lerCN(dn) {
  const m = String(dn || '').match(/(?:^|,\s*)CN=("?)([^,"]+)\1/);
  return m ? m[2].trim() : '';
}

function lerCampo(dn, campo) {
  const m = String(dn || '').match(new RegExp(`(?:^|,\\s*)${campo}=("?)([^,"]+)\\1`));
  return m ? m[2].trim() : '';
}

function formatarDocumento(doc) {
  if (/^\d{11}$/.test(doc)) return `${doc.slice(0, 3)}.${doc.slice(3, 6)}.${doc.slice(6, 9)}-${doc.slice(9)}`;
  if (/^\d{14}$/.test(doc)) return `${doc.slice(0, 2)}.${doc.slice(2, 5)}.${doc.slice(5, 8)}/${doc.slice(8, 12)}-${doc.slice(12)}`;
  return doc;
}

// CPF aparece parcialmente fora da interface (logs, painel da página). CNPJ é público.
function mascararDocumento(doc) {
  if (/^\d{11}$/.test(doc)) return `***.${doc.slice(3, 6)}.${doc.slice(6, 9)}-**`;
  return formatarDocumento(doc);
}

const dataBR = (d) => d.toLocaleDateString('pt-BR', { timeZone: 'America/Recife' });

// Converte um item do PowerShell no formato mostrado na interface. Função pura (testada).
function interpretar(c, agora = new Date()) {
  const cn = lerCN(c.subject);
  const icpBr = /ICP-Brasil/i.test(c.issuer || '') || /ICP-Brasil/i.test(c.subject || '');
  const m = cn.match(/^(.*?):(\d{11}|\d{14})$/);
  const documento = m ? m[2] : '';
  const titular = (m ? m[1] : cn) || lerCampo(c.subject, 'O') || '(sem nome)';
  const tipo = documento.length === 11 ? 'e-CPF' : documento.length === 14 ? 'e-CNPJ' : 'Outro';
  const inicio = new Date(c.notBefore);
  const fim = new Date(c.notAfter);
  const eku = Array.isArray(c.eku) ? c.eku : [];
  const autenticaCliente = eku.length === 0 || eku.includes(OID_AUTENTICACAO_CLIENTE);
  const dias = Math.floor((fim - agora) / 86400000);

  let situacao = 'Válido';
  let nivel = 'ok';
  if (agora < inicio) { situacao = 'Ainda não válido'; nivel = 'erro'; }
  else if (agora > fim) { situacao = 'Vencido'; nivel = 'erro'; }
  else if (dias <= 30) { situacao = `Vence em ${dias} dia${dias === 1 ? '' : 's'}`; nivel = 'atencao'; }

  const problemas = [];
  if (!c.hasPrivateKey) problemas.push('sem chave privada neste computador');
  if (!autenticaCliente) problemas.push('não serve para login (sem "Autenticação de Cliente")');
  if (nivel === 'erro') problemas.push(situacao.toLowerCase());
  const thumb = String(c.thumbprint || '').toUpperCase();

  return {
    id: thumb,
    titular,
    tipo,
    documento,
    documentoFormatado: formatarDocumento(documento),
    documentoMascarado: mascararDocumento(documento),
    emissor: lerCN(c.issuer) || lerCampo(c.issuer, 'O') || '',
    icpBrasil: icpBr,
    validoDe: dataBR(inicio),
    validoAte: dataBR(fim),
    situacao,
    nivel,
    utilizavel: problemas.length === 0,
    problemas,
    impressaoCurta: thumb ? `${thumb.slice(0, 4)}…${thumb.slice(-4)}` : '',
    // Número de série (público, impresso no próprio certificado): é como a janela do Chrome
    // identifica cada certificado, e é o critério da seleção nativa.
    serial: String(c.serial || '').toUpperCase(),
  };
}

// Só o necessário para a extensão mostrar a instrução na página (sem CPF completo e sem a
// impressão digital completa).
function resumoParaExtensao(cert) {
  if (!cert) return null;
  return {
    titular: cert.titular,
    tipo: cert.tipo,
    documentoMascarado: cert.documentoMascarado,
    validade: cert.validoAte,
    emissor: cert.emissor,
    impressaoCurta: cert.impressaoCurta,
  };
}

function listarCertificados() {
  return new Promise((resolve) => {
    if (process.platform !== 'win32') {
      resolve({ ok: false, erro: 'A lista de certificados só está disponível no Windows.', certificados: [] });
      return;
    }
    const codificado = Buffer.from(SCRIPT_PS, 'utf16le').toString('base64');
    execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-EncodedCommand', codificado], { timeout: 20000, windowsHide: true, maxBuffer: 4 * 1024 * 1024 }, (erro, saida) => {
      if (erro) {
        resolve({ ok: false, erro: `Não foi possível ler os certificados do Windows: ${erro.message.split('\n')[0]}`, certificados: [] });
        return;
      }
      try {
        const texto = String(saida || '').trim();
        const bruto = texto ? JSON.parse(texto) : [];
        const lista = (Array.isArray(bruto) ? bruto : [bruto]).map((c) => interpretar(c));
        lista.sort((a, b) => Number(b.utilizavel) - Number(a.utilizavel) || a.titular.localeCompare(b.titular, 'pt-BR'));
        resolve({ ok: true, certificados: lista });
      } catch (e) {
        resolve({ ok: false, erro: `Resposta inesperada ao ler os certificados: ${e.message}`, certificados: [] });
      }
    });
  });
}

module.exports = { listarCertificados, interpretar, resumoParaExtensao, formatarDocumento, mascararDocumento };
