// Lista de empresas / documentos para consulta. Funções puras (testadas em tests/lista.test.js).
//
// Formatos aceitos, uma linha por registro (separador ";" ou TAB, vindo do Excel):
//   tipo;identificador;nome        CNPJ;12.345.678/0001-00;EMPRESA ALFA
//                                  CPF;123.456.789-00;PESSOA BETA
//                                  IE;0123456-78;EMPRESA GAMA      (também "Inscrição Estadual")
//   cnpj;nome                      formato antigo: só vale para CNPJ (14 dígitos e dígitos
//                                  verificadores corretos). 11 dígitos sem tipo NÃO viram CPF:
//                                  podem ser outra coisa, então o tipo é exigido.
//
// Regras: maiúsculas/minúsculas e espaços não importam; máscaras são aceitas; a ordem da lista
// é preservada; linha inválida é apontada com o motivo e NÃO impede as demais; linha vazia,
// comentário (#) e cabeçalho são ignorados; registro repetido (mesmo tipo e número) é
// ignorado (vale o primeiro).

'use strict';

const TIPOS = Object.freeze({ CNPJ: 'CNPJ', CPF: 'CPF', IE: 'IE' });
const ROTULOS = Object.freeze({ CNPJ: 'CNPJ', CPF: 'CPF', IE: 'Inscrição Estadual' });

const normalizar = (s) => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[.\s_-]+/g, ' ').trim().toLowerCase();
const digitos = (s) => String(s || '').replace(/\D/g, '');

function tipoDoTexto(texto) {
  const t = normalizar(texto);
  if (t === 'cnpj') return TIPOS.CNPJ;
  if (t === 'cpf') return TIPOS.CPF;
  if (['ie', 'i e', 'inscricao estadual', 'insc estadual', 'inscricao', 'inscr estadual', 'cacepe'].includes(t)) return TIPOS.IE;
  return null;
}

// ---- Dígitos verificadores -----------------------------------------------------------------

// CNPJ numérico ou ALFANUMÉRICO (emitido desde jul/2026: 12 posições com letras ou números
// + 2 dígitos verificadores numéricos). Cada caractere vale (código ASCII − 48), o que para
// números dá o próprio dígito — o mesmo cálculo serve aos dois formatos.
function cnpjValido(d) {
  if (!/^[0-9A-Z]{12}\d{2}$/.test(d) || /^(\d)\1{13}$/.test(d)) return false;
  const calc = (base) => {
    const pesos = base.length === 12 ? [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2] : [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2];
    const soma = base.split('').reduce((s, c, i) => s + (c.charCodeAt(0) - 48) * pesos[i], 0);
    const r = soma % 11;
    return r < 2 ? 0 : 11 - r;
  };
  const dv1 = calc(d.slice(0, 12));
  const dv2 = calc(d.slice(0, 12) + dv1);
  return d.slice(12) === `${dv1}${dv2}`;
}

function cpfValido(d) {
  if (!/^\d{11}$/.test(d) || /^(\d)\1{10}$/.test(d)) return false;
  const calc = (base, pesoInicial) => {
    const soma = base.split('').reduce((s, n, i) => s + Number(n) * (pesoInicial - i), 0);
    const r = (soma * 10) % 11;
    return r === 10 ? 0 : r;
  };
  const dv1 = calc(d.slice(0, 9), 10);
  const dv2 = calc(d.slice(0, 10), 11);
  return d.slice(9) === `${dv1}${dv2}`;
}

// Inscrição Estadual de Pernambuco (e-Fisco): 9 dígitos, 7 + 2 verificadores (módulo 11).
function iePe9Valida(d) {
  if (!/^\d{9}$/.test(d) || /^(\d)\1{8}$/.test(d)) return false;
  const dv = (base) => {
    const pesoInicial = base.length + 1;
    const soma = base.split('').reduce((s, n, i) => s + Number(n) * (pesoInicial - i), 0);
    const r = soma % 11;
    return r < 2 ? 0 : 11 - r;
  };
  const dv1 = dv(d.slice(0, 7));
  const dv2 = dv(d.slice(0, 7) + dv1);
  return d.slice(7) === `${dv1}${dv2}`;
}

// Formato antigo de PE (CACEPE, 14 dígitos). A conferência é só um aviso: o formato antigo
// tem variações e o portal é quem decide.
function iePe14Confere(d) {
  if (!/^\d{14}$/.test(d)) return false;
  const pesos = [5, 4, 3, 2, 1, 9, 8, 7, 6, 5, 4, 3, 2];
  const soma = d.slice(0, 13).split('').reduce((s, n, i) => s + Number(n) * pesos[i], 0);
  let dv = 11 - (soma % 11);
  if (dv > 9) dv -= 10;
  return Number(d[13]) === dv;
}

// ---- Formatação ----------------------------------------------------------------------------------

function formatar(tipo, d) {
  if (tipo === TIPOS.CNPJ && /^[0-9A-Z]{14}$/.test(d)) return `${d.slice(0, 2)}.${d.slice(2, 5)}.${d.slice(5, 8)}/${d.slice(8, 12)}-${d.slice(12)}`;
  if (tipo === TIPOS.CPF && d.length === 11) return `${d.slice(0, 3)}.${d.slice(3, 6)}.${d.slice(6, 9)}-${d.slice(9)}`;
  if (tipo === TIPOS.IE && d.length === 9) return `${d.slice(0, 7)}-${d.slice(7)}`;
  if (tipo === TIPOS.IE && d.length === 14) return `${d.slice(0, 2)}.${d.slice(2, 3)}.${d.slice(3, 6)}.${d.slice(6, 13)}-${d.slice(13)}`;
  return d;
}

// CPF aparece parcialmente fora da interface (registros, painel da página).
function mascarar(tipo, d) {
  if (tipo === TIPOS.CPF && d.length === 11) return `***.${d.slice(3, 6)}.${d.slice(6, 9)}-**`;
  return formatar(tipo, d);
}

// ---- Validação de um identificador já com tipo ----------------------------------------------------

// Devolve { ok, identificador, avisos, motivo }. Completa zeros à esquerda perdidos (Excel)
// somente quando os dígitos verificadores confirmam.
function validarIdentificador(tipo, bruto) {
  const original = String(bruto || '').trim();
  if (!original) return { ok: false, motivo: 'identificador vazio' };
  const avisos = [];
  let d;

  if (tipo === TIPOS.CNPJ) {
    const limpo = original.toUpperCase().replace(/[.\-/\s]/g, '');
    if (/[^0-9A-Z]/.test(limpo)) return { ok: false, motivo: 'o CNPJ tem símbolos que não são máscara' };
    if (/[A-Z]/.test(limpo)) {
      // CNPJ alfanumérico: sem completar zeros (as letras não somem no Excel).
      if (limpo.length !== 14) return { ok: false, motivo: `CNPJ precisa de 14 caracteres (tem ${limpo.length})` };
      if (!cnpjValido(limpo)) return { ok: false, motivo: 'CNPJ alfanumérico com dígitos verificadores inválidos' };
      return { ok: true, identificador: limpo, avisos };
    }
    d = limpo;
  } else {
    if (/[^\d.\-/\s]/.test(original)) return { ok: false, motivo: 'o identificador tem letras ou símbolos que não são máscara' };
    d = digitos(original);
  }

  if (tipo === TIPOS.CNPJ) {
    if (d.length === 12 || d.length === 13) {
      const completo = d.padStart(14, '0');
      if (cnpjValido(completo)) { avisos.push(`zeros à esquerda completados (${d.length} → 14 dígitos)`); d = completo; }
    }
    if (d.length !== 14) return { ok: false, motivo: `CNPJ precisa de 14 dígitos (tem ${d.length})` };
    if (!cnpjValido(d)) return { ok: false, motivo: 'CNPJ com dígitos verificadores inválidos' };
  } else if (tipo === TIPOS.CPF) {
    if (d.length === 9 || d.length === 10) {
      const completo = d.padStart(11, '0');
      if (cpfValido(completo)) { avisos.push(`zeros à esquerda completados (${d.length} → 11 dígitos)`); d = completo; }
    }
    if (d.length !== 11) return { ok: false, motivo: `CPF precisa de 11 dígitos (tem ${d.length})` };
    if (!cpfValido(d)) return { ok: false, motivo: 'CPF com dígitos verificadores inválidos' };
  } else if (tipo === TIPOS.IE) {
    if (d.length === 8) {
      const completo = d.padStart(9, '0');
      if (iePe9Valida(completo)) { avisos.push('zero à esquerda completado (8 → 9 dígitos)'); d = completo; }
    }
    if (d.length === 9) {
      if (!iePe9Valida(d)) return { ok: false, motivo: 'Inscrição Estadual com dígitos verificadores inválidos (formato de 9 dígitos)' };
    } else if (d.length === 14) {
      if (!iePe14Confere(d)) avisos.push('formato antigo de 14 dígitos: dígito verificador não conferido; o portal fará a validação final');
    } else {
      return { ok: false, motivo: `Inscrição Estadual de PE tem 9 dígitos (ou 14 no formato antigo); esta tem ${d.length}` };
    }
  } else {
    return { ok: false, motivo: 'tipo desconhecido' };
  }
  return { ok: true, identificador: d, avisos };
}

// ---- Leitura da lista -------------------------------------------------------------------------------

function separar(linha) {
  return (linha.includes(';') ? linha.split(';') : linha.split('\t')).map((p) => p.trim());
}

function ehCabecalho(campos) {
  const n = campos.map(normalizar);
  return (n[0] === 'tipo' && /identificador|documento|numero/.test(n[1] || '')) || (n[0] === 'cnpj' && /^nome/.test(n[1] || '') && !digitos(campos[1]));
}

// Interpreta uma linha. Devolve { status: 'valido'|'invalido'|'ignorada', ... }.
function interpretarLinha(texto, numero) {
  const base = { linha: numero, original: texto };
  const t = String(texto || '').trim();
  if (!t) return { ...base, status: 'ignorada', motivo: 'linha vazia' };
  if (t.startsWith('#')) return { ...base, status: 'ignorada', motivo: 'comentário' };
  const campos = separar(t);
  if (ehCabecalho(campos)) return { ...base, status: 'ignorada', motivo: 'cabeçalho' };
  if (campos.length < 2) return { ...base, status: 'invalido', motivo: 'faltou o separador ";" (use tipo;identificador;nome ou cnpj;nome)' };

  let tipo = tipoDoTexto(campos[0]);
  let bruto;
  let nome;
  if (tipo) {
    // tipo;identificador;nome (o nome pode conter ";")
    bruto = campos[1];
    nome = campos.slice(2).join('; ').trim();
    if (campos.length < 3 || !nome) return { ...base, status: 'invalido', tipo, motivo: 'faltou o nome (use tipo;identificador;nome)' };
  } else {
    // formato antigo cnpj;nome: só CNPJ é reconhecido sem tipo
    bruto = campos[0];
    nome = campos.slice(1).join('; ').trim();
    const cnpj = validarIdentificador(TIPOS.CNPJ, bruto);
    const pareceCnpjAlfa = /^[0-9A-Z]{12}\d{2}$/.test(bruto.toUpperCase().replace(/[.\-/\s]/g, '')) && /[a-z]/i.test(bruto);
    if (/[a-z]/i.test(bruto) && !pareceCnpjAlfa) return { ...base, status: 'invalido', motivo: `tipo "${campos[0]}" desconhecido (use CNPJ, CPF ou IE)` };
    if (!nome) return { ...base, status: 'invalido', motivo: 'faltou o nome' };
    const d = digitos(bruto);
    if (cnpj.ok) {
      tipo = TIPOS.CNPJ;
    } else if (pareceCnpjAlfa || d.length === 14) {
      return { ...base, status: 'invalido', motivo: cnpj.motivo };
    } else if (d.length === 11) {
      return { ...base, status: 'invalido', motivo: '11 dígitos sem tipo: pode ser CPF ou outro número. Informe o tipo: CPF;número;nome ou IE;número;nome' };
    } else {
      return { ...base, status: 'invalido', motivo: `sem tipo, só CNPJ é reconhecido (14 dígitos). Para CPF ou Inscrição Estadual use CPF;número;nome ou IE;número;nome` };
    }
  }
  if (nome.length > 150) return { ...base, status: 'invalido', tipo, motivo: 'nome com mais de 150 caracteres' };

  const v = validarIdentificador(tipo, bruto);
  if (!v.ok) return { ...base, status: 'invalido', tipo, motivo: v.motivo };
  return {
    ...base,
    status: 'valido',
    tipo,
    rotuloTipo: ROTULOS[tipo],
    identificador: v.identificador,
    formatado: formatar(tipo, v.identificador),
    mascarado: mascarar(tipo, v.identificador),
    nome,
    avisos: v.avisos,
  };
}

function interpretarLista(texto) {
  const linhas = String(texto || '').replace(/\r\n?/g, '\n').split('\n');
  const vistos = new Map();
  const registros = linhas.map((l, i) => {
    const r = interpretarLinha(l, i + 1);
    if (r.status !== 'valido') return r;
    const chave = `${r.tipo}:${r.identificador}`;
    if (vistos.has(chave)) return { ...r, status: 'ignorada', motivo: `repetido (igual à linha ${vistos.get(chave)})` };
    vistos.set(chave, r.linha);
    return r;
  });
  // Linhas vazias do fim do texto não aparecem no resultado.
  while (registros.length && registros[registros.length - 1].status === 'ignorada' && registros[registros.length - 1].motivo === 'linha vazia') registros.pop();
  const conta = (s) => registros.filter((r) => r.status === s).length;
  return {
    registros,
    resumo: {
      total: registros.filter((r) => r.motivo !== 'linha vazia').length,
      validos: conta('valido'),
      invalidos: conta('invalido'),
      ignoradas: registros.filter((r) => r.status === 'ignorada' && r.motivo !== 'linha vazia').length,
      porTipo: { CNPJ: registros.filter((r) => r.status === 'valido' && r.tipo === 'CNPJ').length, CPF: registros.filter((r) => r.status === 'valido' && r.tipo === 'CPF').length, IE: registros.filter((r) => r.status === 'valido' && r.tipo === 'IE').length },
    },
  };
}

// Só o necessário para a extensão consultar UM registro.
function registroParaExtensao(r) {
  if (!r || r.status !== 'valido') return null;
  return { linha: r.linha, tipo: r.tipo, identificador: r.identificador, formatado: r.formatado, mascarado: r.mascarado, nome: r.nome };
}

module.exports = {
  TIPOS, ROTULOS, interpretarLista, interpretarLinha, validarIdentificador, registroParaExtensao,
  cnpjValido, cpfValido, iePe9Valida, formatar, mascarar, tipoDoTexto,
};
