// Pasta de resultados na Área de Trabalho: validação do nome, criação sem apagar nada e
// nomes de arquivo que nunca sobrescrevem.
//
// Estrutura criada (preparada para as próximas etapas):
//   <Área de Trabalho>\<NOME>\
//   ├── relatorios\           registro de cada execução (execucao_<data-hora>.txt)
//   └── (futuro) <CNPJ> - <EMPRESA>\   uma subpasta por empresa, com as certidões

'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFileSync } = require('child_process');

const PROIBIDOS = /[<>:"/\\|?*\x00-\x1F]/;
const RESERVADOS = /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(\..*)?$/i;

function validarNomePasta(nome) {
  const limpo = String(nome || '').trim();
  if (!limpo) return { ok: false, erro: 'Informe o nome da pasta de resultados.' };
  if (limpo.length > 80) return { ok: false, erro: 'Use no máximo 80 caracteres no nome da pasta.' };
  if (PROIBIDOS.test(limpo)) return { ok: false, erro: 'O nome não pode ter estes caracteres: < > : " / \\ | ? *' };
  if (/[. ]$/.test(limpo)) return { ok: false, erro: 'O nome não pode terminar com ponto ou espaço.' };
  if (limpo === '.' || limpo.includes('..')) return { ok: false, erro: 'O nome não pode ter "..".' };
  if (RESERVADOS.test(limpo)) return { ok: false, erro: 'Esse nome é reservado pelo Windows. Escolha outro.' };
  return { ok: true, nome: limpo };
}

let cacheAreaDeTrabalho = null;

// A Área de Trabalho real (inclusive quando o OneDrive a redireciona). SEFAZPE_AREA_TRABALHO
// substitui (usado nos testes).
function areaDeTrabalho() {
  if (process.env.SEFAZPE_AREA_TRABALHO) return path.resolve(process.env.SEFAZPE_AREA_TRABALHO);
  if (cacheAreaDeTrabalho) return cacheAreaDeTrabalho;
  let caminho = null;
  if (process.platform === 'win32') {
    try {
      caminho = execFileSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', "[Console]::OutputEncoding=[Text.Encoding]::UTF8; [Environment]::GetFolderPath('Desktop')"], { encoding: 'utf8', timeout: 10000, windowsHide: true }).trim();
    } catch (e) {
      caminho = null;
    }
  }
  if (!caminho || !fs.existsSync(caminho)) caminho = path.join(os.homedir(), 'Desktop');
  cacheAreaDeTrabalho = caminho;
  return caminho;
}

function caminhoDaPasta(nome) {
  const v = validarNomePasta(nome);
  if (!v.ok) return v;
  const base = areaDeTrabalho();
  const caminho = path.join(base, v.nome);
  if (path.relative(base, caminho).startsWith('..')) return { ok: false, erro: 'Nome de pasta inválido.' };
  return { ok: true, nome: v.nome, caminho, existe: fs.existsSync(caminho) };
}

// Cria a pasta (e "relatorios") se não existir. Nunca apaga nem move nada que já está lá.
function prepararPasta(nome) {
  const c = caminhoDaPasta(nome);
  if (!c.ok) return c;
  const existia = fs.existsSync(c.caminho);
  if (existia && !fs.statSync(c.caminho).isDirectory()) {
    return { ok: false, erro: `Já existe um ARQUIVO com esse nome na Área de Trabalho: ${c.caminho}` };
  }
  fs.mkdirSync(c.caminho, { recursive: true });
  const relatorios = path.join(c.caminho, 'relatorios');
  fs.mkdirSync(relatorios, { recursive: true });
  return { ok: true, nome: c.nome, caminho: c.caminho, relatorios, existia };
}

// "relatorio.txt" → "relatorio (2).txt" → "relatorio (3).txt"... se o nome já existir.
function caminhoSemSobrescrever(pasta, nomeArquivo) {
  const ext = path.extname(nomeArquivo);
  const base = nomeArquivo.slice(0, nomeArquivo.length - ext.length);
  let candidato = path.join(pasta, nomeArquivo);
  for (let i = 2; fs.existsSync(candidato); i++) candidato = path.join(pasta, `${base} (${i})${ext}`);
  return candidato;
}

function carimbo(d = new Date()) {
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}_${p(d.getHours())}h${p(d.getMinutes())}`;
}

module.exports = { validarNomePasta, areaDeTrabalho, caminhoDaPasta, prepararPasta, caminhoSemSobrescrever, carimbo };
