// Modo 2 do mouse: interação NATIVA do Windows, usada só para a janela "Selecione um
// certificado" do Chrome (que não faz parte da página e a extensão não alcança).
//
// Executa nucleo/selecionar_certificado.ps1 (Windows UI Automation + cursor real) e repassa
// cada passo ao registro (terminal, interface, relatório). O Modo 1 (cursor da extensão, na
// página) continua cuidando de todo o resto; a troca é automática: a extensão avisa quando
// clicou em "Seu certificado digital" e este módulo assume só até a janela fechar.
//
// Sem dependências externas: PowerShell 5.1 e .NET já vêm no Windows.

'use strict';

const path = require('path');
const { spawn } = require('child_process');

const SCRIPT = path.join(__dirname, 'selecionar_certificado.ps1');

// O PowerShell 5.1 só lê acentos de um .ps1 em UTF-8 se o arquivo tiver BOM: garante isso.
function garantirBom() {
  const fs = require('fs');
  const dados = fs.readFileSync(SCRIPT);
  if (dados[0] === 0xEF && dados[1] === 0xBB && dados[2] === 0xBF) return;
  fs.writeFileSync(SCRIPT, Buffer.concat([Buffer.from([0xEF, 0xBB, 0xBF]), dados]));
}

function argumentosBase() {
  garantirBom();
  return ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', SCRIPT];
}

// Executa o script e entrega os eventos JSON. Devolve { processo, fim: Promise<resultado> }.
function executar(args, aoEvento = () => {}) {
  const filho = spawn('powershell.exe', [...argumentosBase(), ...args], { windowsHide: true });
  let buffer = '';
  let resultado = null;
  let erroTexto = '';
  filho.stdout.setEncoding('utf8');
  filho.stdout.on('data', (d) => {
    buffer += d;
    let i;
    while ((i = buffer.indexOf('\n')) >= 0) {
      const linha = buffer.slice(0, i).trim();
      buffer = buffer.slice(i + 1);
      if (!linha.startsWith('{')) continue;
      try {
        const ev = JSON.parse(linha);
        if (ev.tipo === 'resultado') resultado = ev;
        aoEvento(ev);
      } catch (e) { /* linha que não é evento */ }
    }
  });
  filho.stderr.on('data', (d) => { erroTexto += d; });
  const fim = new Promise((resolve) => {
    filho.on('error', (e) => resolve({ tipo: 'resultado', resultado: 'erro', mensagem: `Não foi possível executar o PowerShell: ${e.message}` }));
    filho.on('exit', () => resolve(resultado || { tipo: 'resultado', resultado: 'erro', mensagem: `O script terminou sem resultado. ${erroTexto.split('\n')[0] || ''}`.trim() }));
  });
  return { processo: filho, fim };
}

// cert: { serial, titular, emissor } (o serial vem do Windows; nunca chave nem PIN).
function selecionarCertificado({ cert, velocidade = 'normal', esperaJanela = 60, aoEvento }) {
  if (process.platform !== 'win32') {
    return { processo: null, parar() {}, fim: Promise.resolve({ resultado: 'manual', mensagem: 'A seleção nativa só funciona no Windows.' }) };
  }
  const args = ['-Serial', cert.serial || '', '-Titular', cert.titular || '', '-Emissor', cert.emissor || '', '-Documento', cert.documento || '', '-Velocidade', velocidade, '-EsperaJanela', String(esperaJanela)];
  const r = executar(args, aoEvento);
  return { processo: r.processo, fim: r.fim, parar() { try { r.processo.kill(); } catch (e) { /* já terminou */ } } };
}

// Só para testes: roda a correspondência com linhas simuladas (sem janela e sem mouse).
async function testarCorrespondencia(linhas, cert) {
  const b64 = Buffer.from(JSON.stringify(linhas), 'utf8').toString('base64');
  const r = executar(['-Serial', cert.serial || '', '-Titular', cert.titular || '', '-Emissor', cert.emissor || '', '-Documento', cert.documento || '', '-LinhasTeste', b64]);
  return r.fim;
}

// Teste da busca com rolagem numa lista SIMULADA (sem janela nem mouse):
// sim = { linhas: [{ textos: [...] }], visiveis, inicio, passo }
async function testarBusca(sim, cert) {
  const b64 = Buffer.from(JSON.stringify(sim), 'utf8').toString('base64');
  return executar(['-Serial', cert.serial || '', '-Titular', cert.titular || '', '-Emissor', cert.emissor || '', '-Documento', cert.documento || '', '-PaginasTeste', b64]).fim;
}

// Só lê a janela, se estiver aberta (sem clicar). Para diagnóstico.
function verificarJanela({ esperaJanela = 2, aoEvento } = {}) {
  return executar(['-SomenteVerificar', '-EsperaJanela', String(esperaJanela)], aoEvento).fim;
}

module.exports = { selecionarCertificado, testarCorrespondencia, testarBusca, verificarJanela, SCRIPT };
