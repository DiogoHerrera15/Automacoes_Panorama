// Processamento da LISTA inteira: um registro por vez, na ordem da lista, com um arquivo de
// controle na pasta de resultados para retomar depois de uma interrupção.
//
//   <pasta>\controle_execucao.json   estado de cada registro (gravado a cada mudança)
//   <pasta>\resultado_certidoes_<data-hora>.xlsx   planilha final
//
// Situação de cada registro:
//   pendente       ainda não processado (ou será tentado de novo)
//   processando    é o registro atual
//   sucesso        PDF salvo E conferido pelo computador (nunca só porque a página disse)
//   nao_encontrado a pesquisa não retornou o registro (não há o que emitir)
//   erro           não deu certo depois das tentativas; fica para uma nova execução
//   invalido       linha da lista com problema de preenchimento (não é processada)
//
// Retomada: ao iniciar, um registro "sucesso" do arquivo de controle só é pulado se o PDF
// dele ainda existir e for um PDF válido; "nao_encontrado" também é pulado; "erro" e um
// "processando" interrompido voltam a "pendente".

'use strict';

const fs = require('fs');
const path = require('path');
const Arquivo = require('./arquivo_certidao');
const Planilha = require('./planilha');
const Lista = require('./lista');

const NOME_CONTROLE = 'controle_execucao.json';
const FINAIS = ['sucesso', 'nao_encontrado', 'erro'];
const ROTULO_STATUS = { pendente: 'Pendente', processando: 'Em processamento', sucesso: 'Sucesso', nao_encontrado: 'Não encontrado', erro: 'Erro', invalido: 'Inválido' };

const chaveDe = (r) => `${r.tipo}:${r.identificador}`;
const agora = () => new Date().toISOString();
const dataHora = (iso) => (iso ? new Date(iso).toLocaleString('pt-BR') : '');

function lerControle(arquivo) {
  try {
    const d = JSON.parse(fs.readFileSync(arquivo, 'utf8'));
    return d && Array.isArray(d.registros) ? d : null;
  } catch (e) {
    return null;
  }
}

function pdfValido(caminho) {
  try {
    return !!caminho && fs.existsSync(caminho) && Arquivo.validarPdf(fs.readFileSync(caminho)).ok;
  } catch (e) {
    return false;
  }
}

// registros: os da lista interpretada (nucleo/lista.js), na ordem da lista.
function criarLote({ pasta, registros, agora: relogio = agora } = {}) {
  const arquivo = path.join(pasta, NOME_CONTROLE);
  const anterior = lerControle(arquivo);
  const antes = new Map((anterior ? anterior.registros : []).map((r) => [r.chave, r]));
  const retomada = { sucessoMantido: 0, sucessoSemPdf: 0, naoEncontradoMantido: 0, erroDeNovo: 0, interrompidoDeNovo: 0 };

  const itens = [];
  for (const r of registros) {
    if (r.status === 'ignorada') continue;
    if (r.status !== 'valido') {
      itens.push({ chave: `linha:${r.linha}`, linha: r.linha, tipo: r.tipo || '', identificador: '', formatado: String(r.original || '').slice(0, 40), mascarado: '', nome: '', status: 'invalido', tentativas: 0, mensagem: r.motivo || 'linha inválida', codigo: 'LINHA_INVALIDA', etapa: 'lista', caminho: null, concluidoEm: null });
      continue;
    }
    const base = { chave: chaveDe(r), linha: r.linha, tipo: r.tipo, identificador: r.identificador, formatado: r.formatado, mascarado: r.mascarado, nome: r.nome, status: 'pendente', tentativas: 0, mensagem: null, codigo: null, etapa: null, caminho: null, concluidoEm: null, historico: [], evidencia: null, duracaoSeg: null };
    const a = antes.get(base.chave);
    if (a) {
      base.tentativas = a.tentativas || 0;
      base.historico = Array.isArray(a.historico) ? a.historico.slice(-30) : [];
      if (a.status === 'sucesso' && pdfValido(a.caminho)) {
        Object.assign(base, { status: 'sucesso', caminho: a.caminho, concluidoEm: a.concluidoEm, mensagem: 'Concluído numa execução anterior (PDF conferido).' });
        retomada.sucessoMantido++;
      } else if (a.status === 'sucesso') {
        base.mensagem = 'Estava concluído, mas o PDF não existe mais ou não é válido: será emitido de novo.';
        retomada.sucessoSemPdf++;
      } else if (a.status === 'nao_encontrado') {
        Object.assign(base, { status: 'nao_encontrado', mensagem: a.mensagem, concluidoEm: a.concluidoEm, codigo: a.codigo, etapa: a.etapa });
        retomada.naoEncontradoMantido++;
      } else if (a.status === 'erro') {
        base.mensagem = `Nova tentativa (erro anterior: ${a.mensagem || a.codigo || '?'})`;
        retomada.erroDeNovo++;
      } else if (a.status === 'processando') {
        base.mensagem = 'A execução anterior foi interrompida neste registro; ele será processado de novo.';
        retomada.interrompidoDeNovo++;
      }
    }
    itens.push(base);
  }

  let atual = null;
  let inicioEm = relogio();
  let fimEm = null;

  function salvar() {
    const dados = { versao: 1, atualizadoEm: relogio(), inicioEm, fimEm, registros: itens };
    const temp = `${arquivo}.${process.pid}.parcial`;
    fs.writeFileSync(temp, JSON.stringify(dados, null, 2));
    fs.renameSync(temp, arquivo);
  }

  const validos = () => itens.filter((i) => i.status !== 'invalido');

  function proximo() {
    atual = itens.find((i) => i.status === 'pendente') || null;
    if (atual) {
      atual.status = 'processando';
      atual.tentativas = (atual.tentativas || 0) + 1;
      atual.inicioEm = relogio();
      atual.mensagem = null;
    }
    salvar();
    return atual;
  }

  // resultado: { status: 'sucesso'|'nao_encontrado'|'erro', mensagem, codigo, etapa, caminho }
  function concluirAtual(resultado) {
    if (!atual) return null;
    const st = FINAIS.includes(resultado.status) ? resultado.status : 'erro';
    Object.assign(atual, {
      status: st,
      mensagem: resultado.mensagem ? String(resultado.mensagem).slice(0, 500) : null,
      codigo: resultado.codigo || null,
      etapa: resultado.etapa || null,
      caminho: st === 'sucesso' ? resultado.caminho : null,
      concluidoEm: relogio(),
      duracaoSeg: atual.inicioEm ? Math.round((Date.parse(relogio()) - Date.parse(atual.inicioEm)) / 1000) : null,
    });
    atual.historico.push({ hora: relogio(), etapa: resultado.etapa || null, problema: st === 'erro' ? (resultado.mensagem || resultado.codigo || null) : null, acao: 'resultado final', resultado: ROTULO_STATUS[st] });
    const feito = atual;
    atual = null;
    salvar();
    return feito;
  }

  // Ocorrência de recuperação (etapa, problema, ação, tentativa) no histórico do registro atual.
  function registrarOcorrencia(o) {
    if (!atual || !o) return;
    const s = (v, n = 300) => (v == null ? null : String(v).slice(0, n));
    atual.historico.push({ hora: relogio(), etapa: s(o.etapa, 80), codigo: s(o.codigo, 40), problema: s(o.problema), acao: s(o.acao), tentativa: s(o.tentativa, 10), decorridoSeg: Number(o.decorridoSeg) || null });
    if (atual.historico.length > 30) atual.historico.splice(0, atual.historico.length - 30);
    salvar();
  }

  function registrarEvidencia(caminho) {
    if (!atual) return;
    atual.evidencia = caminho;
    salvar();
  }

  // Parada no meio: o registro atual volta a "pendente" no arquivo (a retomada o refaz).
  function interromper() {
    if (atual) {
      atual.status = 'pendente';
      atual.mensagem = 'Execução interrompida neste registro.';
      atual = null;
    }
    salvar();
  }

  function resumo() {
    const v = validos();
    const conta = (s) => v.filter((i) => i.status === s).length;
    const total = v.length;
    const finalizados = conta('sucesso') + conta('erro') + conta('nao_encontrado');
    const posicao = atual ? v.indexOf(atual) + 1 : null;
    return {
      total,
      sucesso: conta('sucesso'),
      erro: conta('erro'),
      naoEncontrado: conta('nao_encontrado'),
      pendente: conta('pendente'),
      processando: conta('processando'),
      invalido: itens.length - total,
      finalizados,
      percentual: total ? Math.round((finalizados / total) * 1000) / 10 : 0,
      atual: atual ? { posicao, tipo: atual.tipo, formatado: atual.formatado, nome: atual.nome, linha: atual.linha, tentativas: atual.tentativas, ultimaOcorrencia: atual.historico.length ? atual.historico[atual.historico.length - 1] : null, inicioEm: atual.inicioEm } : null,
      retomada,
      arquivoControle: arquivo,
    };
  }

  const itensParaTela = () => itens.map((i) => ({ linha: i.linha, tipo: i.tipo, formatado: i.formatado, nome: i.nome, status: i.status, tentativas: i.tentativas, mensagem: i.mensagem, codigo: i.codigo, etapa: i.etapa, caminho: i.caminho, concluidoEm: i.concluidoEm, duracaoSeg: i.duracaoSeg, evidencia: i.evidencia, historico: (i.historico || []).filter((h) => h.acao !== 'resultado final').slice(-8) }));
  const textoHistorico = (i) => (i.historico || []).filter((h) => h.acao !== 'resultado final').map((h) => `[${dataHora(h.hora)}] ${h.etapa || '?'} — ${h.problema || ''} → ${h.acao || ''}${h.tentativa ? ` (tentativa ${h.tentativa})` : ''}`).join(' | ');

  // Planilha final na pasta de resultados.
  function gerarPlanilha(carimbo) {
    fimEm = relogio();
    salvar();
    const destino = Arquivo.caminhoLivre(pasta, `resultado_certidoes_${carimbo}.xlsx`);
    Planilha.gerarXlsx(destino, {
      aba: 'Certidões',
      cabecalho: ['Linha', 'Tipo', 'Identificador', 'Nome', 'Status', 'Tentativas', 'Mensagem', 'Etapa', 'Tempo (s)', 'Recuperações (horário, etapa, problema, ação)', 'Caminho do PDF', 'Captura da falha', 'Concluído em'],
      linhas: itens.map((i) => [i.linha, Lista.ROTULOS[i.tipo] || i.tipo || '', i.formatado || '', i.nome || '', ROTULO_STATUS[i.status] || i.status, i.tentativas || 0, i.mensagem || '', i.etapa || '', i.duracaoSeg == null ? '' : i.duracaoSeg, textoHistorico(i), i.caminho || '', i.evidencia || '', dataHora(i.concluidoEm)]),
      larguras: [7, 18, 22, 40, 16, 11, 60, 22, 10, 90, 80, 60, 20],
    });
    return destino;
  }

  salvar();
  return { proximo, concluirAtual, interromper, resumo, itens: itensParaTela, gerarPlanilha, registrarOcorrencia, registrarEvidencia, atual: () => atual, arquivo, pasta };
}

module.exports = { criarLote, NOME_CONTROLE, ROTULO_STATUS, chaveDe };
