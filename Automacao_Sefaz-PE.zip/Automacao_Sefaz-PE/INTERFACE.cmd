@echo off
rem Automacao_Sefaz-PE: abre a interface (certificado, pasta de resultados, velocidade do mouse,
rem iniciar/pausar/parar). Mantenha esta janela aberta enquanto usar a automacao.
rem Opcoes: --perfil "Profile 1"   --chrome "C:\caminho\chrome.exe"
chcp 65001 >nul
cd /d "%~dp0"
title Automacao SEFAZ-PE - interface
where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo O Node.js nao esta instalado. Instale a versao LTS com:  winget install OpenJS.NodeJS.LTS
  echo ou em https://nodejs.org , feche e abra esta janela de novo.
  pause
  exit /b 1
)
node interface\servidor.js %*
set CODIGO=%ERRORLEVEL%
echo.
pause
exit /b %CODIGO%
