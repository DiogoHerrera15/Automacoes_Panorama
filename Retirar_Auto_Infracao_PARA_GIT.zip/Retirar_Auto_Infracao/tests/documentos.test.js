import assert from 'node:assert/strict';
import { test } from 'node:test';
import { chaveDoc, cnpjValido, cpfValido, formatarDocumento, interpretarLista, nomeDePasta, nomeLimpo } from '../src/documentos.js';
import { conferirPdf, documentosNoTexto, ehCertidaoTrabalhista, textoDoPdf } from '../src/pdf.js';
import { certidaoFicticia, criarPdf } from './ajuda.js';

test('CNPJ: dígitos verificadores', () => {
  assert.ok(cnpjValido('11222333000181'));
  assert.ok(cnpjValido('22333444000181'));
  assert.ok(!cnpjValido('11222333000182'));
  assert.ok(!cnpjValido('11111111111111'));
  assert.ok(!cnpjValido('123'));
});

test('CNPJ alfanumérico (regra da RFB, letra = ASCII - 48)', () => {
  assert.ok(cnpjValido('12ABC34501DE35'));
  assert.ok(!cnpjValido('12ABC34501DE36'));
});

test('CPF: dígitos verificadores', () => {
  assert.ok(cpfValido('12345678909'));
  assert.ok(!cpfValido('12345678900'));
  assert.ok(!cpfValido('11111111111'));
});

test('formatação e chave', () => {
  assert.equal(chaveDoc('11.222.333/0001-81'), '11222333000181');
  assert.equal(formatarDocumento('11222333000181'), '11.222.333/0001-81');
  assert.equal(formatarDocumento('12345678909'), '123.456.789-09');
});

test('lista: todos os formatos aceitos no LEIA-ME', () => {
  const r = interpretarLista([
    '# comentário',
    '',
    '11.222.333/0001-81',
    '11222333000181;FULANO DE TAL ME',
    '33.444.555/0001-81 - COMERCIO DE BALAS EXEMPLO LTDA',
    '22.333.444/0001-81\tCAMBIO EXEMPLO LTDA',
    'CPF/CNPJ Empresa',
    '123.456.789-09;FULANO DE TAL',
  ].join('\r\n'));
  assert.equal(r.length, 5);
  assert.deepEqual(r.map((x) => x.problema), ['', '', '', '', '']);
  assert.equal(r[0].nome, '');
  assert.equal(r[1].nome, 'FULANO DE TAL ME');
  assert.equal(r[2].nome, 'COMERCIO DE BALAS EXEMPLO LTDA');
  assert.equal(r[3].nome, 'CAMBIO EXEMPLO LTDA');
  assert.equal(r[4].documento, '123.456.789-09');
  assert.equal(r[4].chave.length, 11);
});

test('lista: documento inválido e número solto viram problema; cabeçalho é ignorado', () => {
  const r = interpretarLista('11.222.333/0001-82;X\n12345678\nCPF/CNPJ Empresa');
  assert.equal(r.length, 2);
  assert.match(r[0].problema, /inválido/);
  assert.match(r[1].problema, /sem CPF\/CNPJ/);
});

test('lista: CPF do dono dentro do nome não vale quando a linha já tem CNPJ', () => {
  const [r] = interpretarLista('11.222.333/0001-81 - JOAO 123.456.789-09');
  assert.equal(r.chave, '11222333000181');
});

test('nome do arquivo: tira só o que o sistema não aceita e mantém os acentos', () => {
  assert.equal(nomeLimpo('AÇAÍ & CIA: "LTDA"/ME.'), 'AÇAÍ & CIA LTDA ME');
  assert.equal(nomeLimpo('  PADARIA   SÃO JOÃO  LTDA  '), 'PADARIA SÃO JOÃO LTDA');
  assert.equal(nomeLimpo('A\\B/C:D*E?F"G<H>I|J'), 'A B C D E F G H I J');
  assert.equal(nomeLimpo('M & M; COMERCIO (FILIAL) - 01'), 'M & M; COMERCIO (FILIAL) - 01');
  assert.equal(nomeLimpo('...oculto'), 'oculto');
  assert.equal(nomeLimpo('NOME\u0000COM\tCONTROLE'), 'NOME COM CONTROLE');
  assert.equal(nomeLimpo('E'.repeat(400)).length, 150);
  assert.equal(nomeLimpo(undefined), '');
  assert.equal(nomeLimpo('???'), '');
});

test('nome do arquivo: nomes reservados do Windows ganham "_"', () => {
  assert.equal(nomeLimpo('CON'), 'CON_');
  assert.equal(nomeLimpo('lpt1'), 'lpt1_');
  assert.equal(nomeLimpo('CONSTRUTORA'), 'CONSTRUTORA');
});

test('nome da pasta de destino: mesmas regras, sem escapar da pasta principal', () => {
  assert.equal(nomeDePasta('AUTO INFRACAO NOVEMBRO'), 'AUTO INFRACAO NOVEMBRO');
  assert.equal(nomeDePasta('Novembro/2026: lote 1'), 'Novembro 2026 lote 1');
  assert.equal(nomeDePasta('..'), '');
  assert.equal(nomeDePasta('../../etc'), 'etc');
  assert.equal(nomeDePasta('   '), '');
});

test('PDF: texto, tipo de certidão e documentos', async () => {
  const pdf = certidaoFicticia('11.222.333/0001-81');
  const texto = await textoDoPdf(pdf);
  assert.ok(ehCertidaoTrabalhista(texto));
  assert.ok(documentosNoTexto(texto).has('11222333000181'));
});

test('conferirPdf: CNPJ certo, outro CNPJ, não-certidão, lixo, CPF e raiz', async () => {
  const empresa = { chave: '11222333000181', nome: 'X' };
  assert.equal((await conferirPdf(empresa, certidaoFicticia('11.222.333/0001-81'))).ok, true);

  const outro = await conferirPdf(empresa, certidaoFicticia('22.333.444/0001-81'));
  assert.equal(outro.ok, false);
  assert.match(outro.mensagem, /outro CPF\/CNPJ/);

  const naoCertidao = await conferirPdf(empresa, criarPdf(['Outro documento', '11.222.333/0001-81']));
  assert.equal(naoCertidao.ok, false);

  assert.equal((await conferirPdf(empresa, Buffer.from('nao e pdf'))).ok, false);

  const cpf = await conferirPdf({ chave: '12345678909', nome: 'F' }, certidaoFicticia('123.456.789-09'));
  assert.equal(cpf.ok, true);
  assert.match(cpf.mensagem, /CPF conferido/);

  // A certidão pode trazer só a raiz (8 primeiros dígitos) do CNPJ.
  const raiz = await conferirPdf({ chave: '11222333000221', nome: 'F' }, criarPdf(['CERTIDAO DE DEBITOS TRABALHISTAS', 'Raiz 11.222.333']));
  assert.equal(raiz.ok, true);
  assert.match(raiz.mensagem, /Raiz/);
});
