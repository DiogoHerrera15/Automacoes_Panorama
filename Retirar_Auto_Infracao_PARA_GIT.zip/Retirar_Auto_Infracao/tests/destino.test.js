// Pasta de destino informada pelo usuário e nome dos arquivos pelo nome da empresa.
// Tudo em pastas temporárias; nada toca a pasta Downloads de verdade.

import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { test } from 'node:test';
import { Assistente, ErroDeUso } from '../src/assistente.js';
import { candidatosDeNome, marcarNomesDuplicados, salvarListaArquivo, salvarPdf } from '../src/persistencia.js';
import { cnpjValido, formatarDocumento } from '../src/documentos.js';
import { textoDoPdf } from '../src/pdf.js';
import { certidaoFicticia, cnpjDaVez, criarAmbiente, esperarAte } from './ajuda.js';

const A = '11.222.333/0001-81';
const B = '22.333.444/0001-81';
const CHAVE_A = '11222333000181';
const CHAVE_B = '22333444000181';

async function comAmbiente(corpo) {
  const amb = await criarAmbiente();
  try {
    await corpo(amb);
  } finally {
    amb.limpar();
  }
}

const esperarVez = (cfg, documento) => esperarAte(async () => (await cnpjDaVez(cfg))?.cnpj === documento, { mensagem: `vez de ${documento}` });

// Entrega a certidão de `documento` em Downloads, como o Chrome faria, e espera ela sumir.
async function entregar(downloads, documento) {
  const arquivo = path.join(downloads, 'Document.pdf');
  fs.writeFileSync(arquivo, certidaoFicticia(documento));
  await esperarAte(() => !fs.existsSync(arquivo), { mensagem: `PDF de ${documento} movido` });
}

// CNPJ válido para uma sequência (base de 12 dígitos + dígitos verificadores).
function cnpjDaSequencia(n) {
  const base = String(10_000_000 + n).padStart(8, '0') + '0001';
  const dv = (digitos) => {
    let soma = 0;
    let peso = digitos.length - 7;
    for (const d of digitos) {
      soma += Number(d) * peso--;
      if (peso < 2) peso = 9;
    }
    const resto = soma % 11;
    return resto < 2 ? 0 : 11 - resto;
  };
  const d1 = dv(base);
  const d2 = dv(base + d1);
  const chave = `${base}${d1}${d2}`;
  assert.ok(cnpjValido(chave));
  return formatarDocumento(chave);
}

test('exemplo do pedido: cria a pasta informada e salva cada PDF com o nome da empresa', () => comAmbiente(async ({ cfg, downloads, principal }) => {
  salvarListaArquivo(cfg, `${A} - EMPRESA EXEMPLO LTDA\n${B} - COMERCIAL RECIFE LTDA`);
  const assistente = new Assistente(cfg);
  const execucao = assistente.executar({ nomePasta: 'AUTO INFRACAO NOVEMBRO' });

  await esperarVez(cfg, A);
  assert.ok(fs.existsSync(path.join(principal, 'AUTO INFRACAO NOVEMBRO')), 'a pasta é criada antes de emitir');
  await entregar(downloads, A);
  await esperarVez(cfg, B);
  await entregar(downloads, B);
  const { resultado } = await execucao;

  assert.equal(resultado, 'concluido');
  const pasta = path.join(principal, 'AUTO INFRACAO NOVEMBRO');
  assert.deepEqual(fs.readdirSync(pasta).filter((a) => a.endsWith('.pdf')).sort(), ['COMERCIAL RECIFE LTDA.pdf', 'EMPRESA EXEMPLO LTDA.pdf']);
  // Cada arquivo tem a certidão do CNPJ certo.
  assert.match(await textoDoPdf(fs.readFileSync(path.join(pasta, 'EMPRESA EXEMPLO LTDA.pdf'))), /11\.222\.333\/0001-81/);
  assert.match(await textoDoPdf(fs.readFileSync(path.join(pasta, 'COMERCIAL RECIFE LTDA.pdf'))), /22\.333\.444\/0001-81/);
  // Nada de pasta Lote_ nova na raiz do projeto, e a extensão .pdf é preservada.
  assert.deepEqual(fs.readdirSync(cfg.raiz).filter((n) => n.startsWith('Lote_')), []);
  // A interface mostra e abre a pasta de destino escolhida.
  assert.equal(assistente.snapshot().pastaLote, pasta);
}));

test('pasta já existente é reutilizada: nada é apagado nem sobrescrito', () => comAmbiente(async ({ cfg, downloads, principal }) => {
  const pasta = path.join(principal, 'AUTO INFRACAO NOVEMBRO');
  fs.mkdirSync(pasta);
  fs.writeFileSync(path.join(pasta, 'EMPRESA EXEMPLO LTDA.pdf'), 'CONTEUDO ANTIGO');
  fs.writeFileSync(path.join(pasta, 'anotacoes.txt'), 'minhas anotações');
  salvarListaArquivo(cfg, `${A};EMPRESA EXEMPLO LTDA`);
  const assistente = new Assistente(cfg);
  const logs = [];
  assistente.on('log', (l) => logs.push(l.texto));
  const execucao = assistente.executar({ nomePasta: 'AUTO INFRACAO NOVEMBRO' });
  await esperarVez(cfg, A);
  await entregar(downloads, A);
  assert.equal((await execucao).resultado, 'concluido');

  assert.equal(fs.readFileSync(path.join(pasta, 'EMPRESA EXEMPLO LTDA.pdf'), 'utf8'), 'CONTEUDO ANTIGO');
  assert.equal(fs.readFileSync(path.join(pasta, 'anotacoes.txt'), 'utf8'), 'minhas anotações');
  // O novo documento ganha o CNPJ no nome em vez de substituir o antigo.
  assert.ok(fs.existsSync(path.join(pasta, `EMPRESA EXEMPLO LTDA - ${CHAVE_A}.pdf`)));
  assert.ok(logs.some((t) => t.includes('já existia')));
}));

test('mesmo nome para empresas diferentes: todas levam "NOME - CNPJ" (sem diferenciar maiúsculas)', () => comAmbiente(async ({ cfg, downloads, principal }) => {
  salvarListaArquivo(cfg, `${A};PADARIA CENTRAL LTDA\n${B};Padaria Central Ltda`);
  const execucao = new Assistente(cfg).executar({ nomePasta: 'IGUAIS' });
  await esperarVez(cfg, A);
  await entregar(downloads, A);
  await esperarVez(cfg, B);
  await entregar(downloads, B);
  assert.equal((await execucao).resultado, 'concluido');
  assert.deepEqual(fs.readdirSync(path.join(principal, 'IGUAIS')).filter((a) => a.endsWith('.pdf')).sort(), [
    `PADARIA CENTRAL LTDA - ${CHAVE_A}.pdf`,
    `Padaria Central Ltda - ${CHAVE_B}.pdf`,
  ]);
}));

test('sem nome na lista: usa o CNPJ e não interrompe a execução', () => comAmbiente(async ({ cfg, downloads, principal }) => {
  salvarListaArquivo(cfg, `${A}\n123.456.789-09`);
  const assistente = new Assistente(cfg);
  const logs = [];
  assistente.on('log', (l) => logs.push(l.texto));
  const execucao = assistente.executar({ nomePasta: 'SEM NOMES' });
  assert.equal(assistente.snapshot().contagem.semNome, 2);
  await esperarVez(cfg, A);
  await entregar(downloads, A);
  await esperarVez(cfg, '123.456.789-09');
  await entregar(downloads, '123.456.789-09');
  assert.equal((await execucao).resultado, 'concluido');
  assert.deepEqual(fs.readdirSync(path.join(principal, 'SEM NOMES')).filter((a) => a.endsWith('.pdf')).sort(), ['11222333000181.pdf', '12345678909.pdf']);
  assert.ok(logs.some((t) => t.includes('sem nome na lista')));
}));

test('caracteres proibidos saem do nome; acentos ficam', () => comAmbiente(async ({ cfg, downloads, principal }) => {
  salvarListaArquivo(cfg, `${A};AÇAÍ & CIA: "SÃO JOÃO"/FILIAL 1`);
  const execucao = new Assistente(cfg).executar({ nomePasta: 'Novembro/2026' });
  await esperarVez(cfg, A);
  await entregar(downloads, A);
  assert.equal((await execucao).resultado, 'concluido');
  assert.deepEqual(fs.readdirSync(path.join(principal, 'Novembro 2026')).filter((a) => a.endsWith('.pdf')), ['AÇAÍ & CIA SÃO JOÃO FILIAL 1.pdf']);
}));

test('lista grande: cada arquivo fica com o CNPJ da sua empresa', () => comAmbiente(async ({ cfg, downloads, principal }) => {
  const total = 20;
  const empresas = Array.from({ length: total }, (_, i) => ({ documento: cnpjDaSequencia(i + 1), nome: `EMPRESA NUMERO ${String(i + 1).padStart(2, '0')} LTDA` }));
  salvarListaArquivo(cfg, empresas.map((e) => `${e.documento};${e.nome}`).join('\n'));
  const assistente = new Assistente(cfg);
  const logs = [];
  assistente.on('log', (l) => logs.push(l.texto));
  const execucao = assistente.executar({ nomePasta: 'LISTA GRANDE' });
  for (const e of empresas) {
    await esperarVez(cfg, e.documento);
    // Um PDF de outra empresa cai antes: tem que ser rejeitado e ficar em Downloads.
    if (e === empresas[7]) {
      fs.writeFileSync(path.join(downloads, 'trocado.pdf'), certidaoFicticia(empresas[0].documento));
      await esperarAte(() => logs.some((t) => t.includes('trocado.pdf ficou em Downloads')), { mensagem: 'PDF trocado rejeitado' });
    }
    await entregar(downloads, e.documento);
  }
  const { resultado, placar } = await execucao;
  assert.equal(resultado, 'concluido');
  assert.equal(placar.feitas, total);
  const pasta = path.join(principal, 'LISTA GRANDE');
  for (const e of empresas) {
    const arquivo = path.join(pasta, `${e.nome}.pdf`);
    assert.ok(fs.existsSync(arquivo), `falta ${e.nome}`);
    const texto = await textoDoPdf(fs.readFileSync(arquivo));
    assert.ok(texto.includes(e.documento), `${e.nome} deveria ter ${e.documento}`);
  }
  assert.equal(fs.readdirSync(pasta).filter((a) => a.endsWith('.pdf')).length, total);
  assert.ok(fs.existsSync(path.join(downloads, 'trocado.pdf')), 'o PDF trocado não foi movido');
}));

test('PDF já salvo na pasta antes de a execução cair é reconhecido pelo conteúdo, mesmo com o nome da empresa', () => comAmbiente(async ({ cfg, principal }) => {
  const pasta = path.join(principal, 'RETOMADA');
  fs.mkdirSync(pasta);
  fs.mkdirSync(cfg.pastaDados, { recursive: true });
  fs.writeFileSync(path.join(pasta, 'EMPRESA A.pdf'), certidaoFicticia(A));
  fs.writeFileSync(cfg.arquivoControle, JSON.stringify({
    loteIniciadoEm: 'x', loteIniciadoMs: Date.now() - 60_000, pastaLote: pasta,
    documentos: { [CHAVE_A]: { nome: 'EMPRESA A', documento: A, chave: CHAVE_A, situacao: 'pendente', mensagem: '', pdf: '', processadoEm: '' } },
  }));
  salvarListaArquivo(cfg, `${A};EMPRESA A`);
  const logs = [];
  const assistente = new Assistente(cfg);
  assistente.on('log', (l) => logs.push(l.texto));
  const { resultado } = await assistente.executar({ nomePasta: 'RETOMADA' });
  assert.equal(resultado, 'concluido', 'não pede a mesma certidão de novo');
  assert.ok(logs.some((t) => t.includes('PDFs que já estavam na pasta: 1')));
  assert.deepEqual(fs.readdirSync(pasta).filter((a) => a.endsWith('.pdf')), ['EMPRESA A.pdf']);
}));

test('PDF antigo na pasta (de antes do lote) não conta como emitido', () => comAmbiente(async ({ cfg, principal }) => {
  const pasta = path.join(principal, 'RETOMADA');
  fs.mkdirSync(pasta);
  const antigo = path.join(pasta, 'EMPRESA A.pdf');
  fs.writeFileSync(antigo, certidaoFicticia(A));
  const ontem = new Date(Date.now() - 86_400_000);
  fs.utimesSync(antigo, ontem, ontem);
  salvarListaArquivo(cfg, `${A};EMPRESA A`);
  const assistente = new Assistente(cfg);
  const execucao = assistente.executar({ nomePasta: 'RETOMADA' });
  await esperarVez(cfg, A);
  assistente.enviarComando('s');
  assert.equal((await execucao).resultado, 'parado', 'a empresa continua pendente');
}));

test('nome completado na lista depois vale para quem ainda não tem PDF', () => comAmbiente(async ({ cfg, downloads, principal }) => {
  salvarListaArquivo(cfg, A); // sem nome
  const primeira = new Assistente(cfg);
  const execucao1 = primeira.executar({ nomePasta: 'COMPLETAR' });
  await esperarVez(cfg, A);
  primeira.enviarComando('s');
  assert.equal((await execucao1).resultado, 'parado');

  salvarListaArquivo(cfg, `${A};EMPRESA A COMPLETA`);
  const execucao2 = new Assistente(cfg).executar({ nomePasta: 'COMPLETAR' });
  await esperarVez(cfg, A);
  await entregar(downloads, A);
  assert.equal((await execucao2).resultado, 'concluido');
  assert.ok(fs.existsSync(path.join(principal, 'COMPLETAR', 'EMPRESA A COMPLETA.pdf')));
}));

test('nome da pasta vazio ou inválido é recusado e nada é criado', () => comAmbiente(async ({ cfg, principal }) => {
  salvarListaArquivo(cfg, `${A};EMPRESA A`);
  for (const nome of ['', '   ', '..', '???']) {
    await assert.rejects(() => new Assistente(cfg).executar({ nomePasta: nome }), (e) => e instanceof ErroDeUso && /nome da pasta de destino/.test(e.message));
  }
  assert.deepEqual(fs.readdirSync(principal), []);
}));

test('pasta principal escolhida na tela vale no lugar da padrão', () => comAmbiente(async ({ cfg, downloads, base }) => {
  const outra = path.join(base, 'OutraPasta');
  fs.mkdirSync(outra);
  salvarListaArquivo(cfg, `${A};EMPRESA A`);
  const execucao = new Assistente(cfg).executar({ nomePasta: 'LOTE X', pastaPrincipal: outra });
  await esperarVez(cfg, A);
  await entregar(downloads, A);
  await execucao;
  assert.ok(fs.existsSync(path.join(outra, 'LOTE X', 'EMPRESA A.pdf')));
}));

test('relatório não sobrescreve o de um lote anterior na mesma pasta', () => comAmbiente(async ({ cfg, downloads, principal }) => {
  for (const [doc, nome] of [[A, 'EMPRESA A'], [B, 'EMPRESA B']]) {
    salvarListaArquivo(cfg, `${doc};${nome}`);
    const execucao = new Assistente(cfg).executar({ nomePasta: 'MESMA PASTA' });
    await esperarVez(cfg, doc);
    await entregar(downloads, doc);
    assert.equal((await execucao).resultado, 'concluido');
  }
  const arquivos = fs.readdirSync(path.join(principal, 'MESMA PASTA')).sort();
  assert.deepEqual(arquivos, ['EMPRESA A.pdf', 'EMPRESA B.pdf', 'Relatorio (2).csv', 'Relatorio.csv']);
  assert.match(fs.readFileSync(path.join(principal, 'MESMA PASTA', 'Relatorio.csv'), 'utf8'), /EMPRESA A/);
  assert.match(fs.readFileSync(path.join(principal, 'MESMA PASTA', 'Relatorio (2).csv'), 'utf8'), /EMPRESA B/);
}));

test('sem nomePasta (terminal) continua criando Lote_AAAA-MM-DD_HHhMM na raiz do projeto', () => comAmbiente(async ({ cfg, downloads, principal }) => {
  salvarListaArquivo(cfg, `${A};EMPRESA A`);
  const execucao = new Assistente(cfg).executar();
  await esperarVez(cfg, A);
  await entregar(downloads, A);
  await execucao;
  const lotes = fs.readdirSync(cfg.raiz).filter((n) => /^Lote_\d{4}-\d{2}-\d{2}_\d{2}h\d{2}$/.test(n));
  assert.equal(lotes.length, 1);
  assert.ok(fs.existsSync(path.join(cfg.raiz, lotes[0], 'EMPRESA A.pdf')));
  assert.deepEqual(fs.readdirSync(principal), []);
}));

test('nomes de arquivo: candidatos, duplicados e numeração sem sobrescrever', () => {
  assert.deepEqual(candidatosDeNome({ nome: 'EMPRESA X', chave: CHAVE_A }), ['EMPRESA X', `EMPRESA X - ${CHAVE_A}`]);
  assert.deepEqual(candidatosDeNome({ nome: 'EMPRESA X', chave: CHAVE_A, nomeDuplicado: true }), [`EMPRESA X - ${CHAVE_A}`]);
  assert.deepEqual(candidatosDeNome({ nome: '', chave: CHAVE_A }), [CHAVE_A]);
  assert.deepEqual(candidatosDeNome({ nome: '???', chave: CHAVE_A }), [CHAVE_A]);

  const empresas = [{ nome: 'X', chave: '1' }, { nome: 'x', chave: '2' }, { nome: 'Y', chave: '3' }, { nome: '', chave: '4' }, { nome: '', chave: '5' }];
  marcarNomesDuplicados(empresas);
  assert.deepEqual(empresas.map((e) => Boolean(e.nomeDuplicado)), [true, true, false, false, false]);
});

test('salvarPdf: nunca sobrescreve (nome, nome - CNPJ, depois numeração)', async () => {
  const amb = await criarAmbiente();
  try {
    const pasta = amb.principal;
    const empresa = { nome: 'EMPRESA X', chave: CHAVE_A };
    const salvos = [1, 2, 3, 4].map((n) => path.basename(salvarPdf(pasta, empresa, Buffer.from(`pdf ${n}`))));
    assert.deepEqual(salvos, ['EMPRESA X.pdf', `EMPRESA X - ${CHAVE_A}.pdf`, `EMPRESA X - ${CHAVE_A} (2).pdf`, `EMPRESA X - ${CHAVE_A} (3).pdf`]);
    assert.equal(fs.readFileSync(path.join(pasta, 'EMPRESA X.pdf'), 'utf8'), 'pdf 1');
    // Sem nome: CNPJ, depois numeração.
    const semNome = [1, 2].map((n) => path.basename(salvarPdf(pasta, { nome: '', chave: CHAVE_B }, Buffer.from(`s ${n}`))));
    assert.deepEqual(semNome, [`${CHAVE_B}.pdf`, `${CHAVE_B} (2).pdf`]);
    // Maiúsculas/minúsculas diferentes colidem em sistemas de arquivos que não as distinguem (macOS/Windows):
    // o "wx" garante que nada é sobrescrito de qualquer forma.
    const salvo = path.basename(salvarPdf(pasta, { nome: 'empresa x', chave: CHAVE_B }, Buffer.from('outro')));
    assert.equal(fs.readFileSync(path.join(pasta, 'EMPRESA X.pdf'), 'utf8'), 'pdf 1');
    assert.ok(salvo.endsWith('.pdf'));
  } finally {
    amb.limpar();
  }
});
