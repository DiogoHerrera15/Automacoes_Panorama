// Cruza a lista DOCUMENTOS do content.js com as pastas em Downloads\Situacao_Fiscal_Assecon.
// Uso: node analisar_progresso.js <content.js> <pasta raiz> <saida.csv>
const fs = require('fs');
const path = require('path');
const [, , arqContent, raiz, saidaCsv] = process.argv;

const src = fs.readFileSync(arqContent, 'utf8');
const bloco = src.match(/const DOCUMENTOS = \[([\s\S]*?)\n  \];/)[1];
const linhas = [...bloco.matchAll(/'([^']+)'/g)].map((m) => m[1]);
const limpo = (s) => String(s || '').replace(/[<>:"/\\|?*\x00-\x1f]/g, '_').replace(/\s+/g, ' ').trim().replace(/[. ]+$/, '').slice(0, 120);
const fila = linhas.map((l, i) => {
  const [doc, ...n] = l.split(';');
  return { ordem: i + 1, documento: doc.trim(), digitos: doc.replace(/\D/g, ''), nome: n.join(';').trim() };
});
for (const f of fila) {
  let nome = limpo(f.nome) || f.digitos;
  if (fila.filter((g) => limpo(g.nome).toUpperCase() === nome.toUpperCase()).length > 1) nome = `${nome} ${f.digitos.slice(8, 12)}`;
  f.pasta = nome;
}

const existentes = fs.existsSync(raiz) ? fs.readdirSync(raiz, { withFileTypes: true }).filter((d) => d.isDirectory()).map((d) => d.name) : [];
const porMaiuscula = new Map(existentes.map((n) => [n.toUpperCase(), n]));
const listar = (dir) => (fs.existsSync(dir) ? fs.readdirSync(dir, { withFileTypes: true }) : []);

const resultado = fila.map((f) => {
  const real = porMaiuscula.get(f.pasta.toUpperCase());
  const r = { ...f, existe: !!real, captura: false, certidao: false, relatorio: false, erroProcuracao: false, arquivos: 0, ultima: null };
  if (real) {
    const dir = path.join(raiz, real);
    const marca = (p) => { const t = fs.statSync(p).mtime; if (!r.ultima || t > r.ultima) r.ultima = t; r.arquivos++; };
    for (const e of listar(dir)) {
      const p = path.join(dir, e.name);
      if (e.isFile()) {
        marca(p);
        if (/^Com_Pendencia_/i.test(e.name)) r.captura = true;
        if (/^RFB_\d+\.pdf$/i.test(e.name)) r.certidao = true;
      } else if (/situa..o fiscal/i.test(e.name)) {
        for (const x of listar(p)) if (x.isFile()) { marca(path.join(p, x.name)); r.relatorio = true; }
      } else if (/Erro_de_Procuracao/i.test(e.name)) {
        for (const x of listar(p)) if (x.isFile()) { marca(path.join(p, x.name)); r.erroProcuracao = true; }
      }
    }
  }
  if (r.erroProcuracao) r.situacao = 'Concluído — erro de procuração (evidência salva)';
  else if (r.relatorio) r.situacao = r.certidao ? 'Concluído — certidão + relatório' : (r.captura ? 'Concluído — com pendência (captura + relatório)' : 'Concluído — relatório');
  else if (r.certidao) r.situacao = 'Incompleto? — só certidão (falta relatório, ou o portal não ofereceu)';
  else if (r.captura) r.situacao = 'Incompleto — só captura (faltam certidão/relatório)';
  else if (r.existe) r.situacao = 'Incompleto — pasta vazia';
  else r.situacao = 'Não processado';
  return r;
});

const extras = existentes.filter((n) => !fila.some((f) => f.pasta.toUpperCase() === n.toUpperCase()));
const grupos = {};
for (const r of resultado) (grupos[r.situacao] = grupos[r.situacao] || []).push(r);

console.log(`Lista: ${fila.length} CNPJs | pastas encontradas: ${existentes.length}`);
for (const [k, v] of Object.entries(grupos)) console.log(`${String(v.length).padStart(4)}  ${k}`);
const feitos = resultado.filter((r) => r.existe).sort((a, b) => b.ultima - a.ultima);
if (feitos.length) {
  const u = feitos[0];
  console.log(`\nÚltimo arquivo salvo: ${u.ultima.toLocaleString('pt-BR')} — nº ${u.ordem} ${u.documento} ${u.nome}`);
}
const maiorOrdemFeita = Math.max(0, ...resultado.filter((r) => r.situacao.startsWith('Concluído')).map((r) => r.ordem));
console.log(`Maior posição concluída na lista: ${maiorOrdemFeita}`);
const naoFeitosAntes = resultado.filter((r) => !r.situacao.startsWith('Concluído') && r.ordem < maiorOrdemFeita);
console.log(`\nNão concluídos ANTES da posição ${maiorOrdemFeita} (pendentes/pulados): ${naoFeitosAntes.length}`);
naoFeitosAntes.forEach((r) => console.log(`  nº ${r.ordem}  ${r.documento}  ${r.nome}  →  ${r.situacao}`));
const depois = resultado.filter((r) => r.ordem > maiorOrdemFeita);
console.log(`\nDepois da posição ${maiorOrdemFeita}: ${depois.length} CNPJs (${depois.filter((r) => r.existe).length} com pasta)`);
if (depois.length) console.log(`  próximo da fila: nº ${depois[0].ordem} ${depois[0].documento} ${depois[0].nome}`);
console.log(`\nPastas fora da lista: ${extras.length ? extras.join(' | ') : 'nenhuma'}`);

const csv = ['Ordem;CNPJ;Empresa;Situação;Certidão;Relatório;Captura pendência;Erro procuração;Arquivos;Último arquivo']
  .concat(resultado.map((r) => [r.ordem, r.documento, r.nome, r.situacao, r.certidao ? 'sim' : '', r.relatorio ? 'sim' : '',
    r.captura ? 'sim' : '', r.erroProcuracao ? 'sim' : '', r.arquivos, r.ultima ? r.ultima.toLocaleString('pt-BR') : ''].join(';')));
fs.writeFileSync(saidaCsv, '﻿' + csv.join('\r\n'), 'utf8');
console.log(`\nPlanilha: ${saidaCsv}`);
