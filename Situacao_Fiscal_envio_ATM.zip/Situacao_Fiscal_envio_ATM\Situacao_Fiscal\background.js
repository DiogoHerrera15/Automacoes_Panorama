// Situacao_Fiscal — service worker.
// - Reforça o aviso de navegação interna do portal (SPA: muda só o trecho depois de "#" ou usa history.pushState).
// - Botão da extensão: executa o fluxo de novo na aba.
// - Captura a tela da aba e salva como PDF (RFB_CNPJ/<CNPJ>/Com_Pendencia_<CNPJ>.pdf).
// - Redireciona o download do "Baixar Relatório" para RFB_CNPJ/<CNPJ>/situação fiscal/<nome original>.
// As pastas são relativas à pasta de Downloads do Chrome.
'use strict';

const PREFIXO = '[Situacao_Fiscal]';
const ID_EXTENSAO = chrome.runtime.id;
const FILTRO = { url: [{ hostEquals: 'servicos.receitafederal.gov.br', pathPrefix: '/servico/' }] };
const VALIDADE_ESPERA_RELATORIO_MS = 120000;

// ------------------------------- navegação e botão -------------------------------
function avisarAba(tabId, frameId, tipo) {
  if (frameId !== 0) return; // só o quadro principal
  chrome.tabs.sendMessage(tabId, { origem: 'Situacao_Fiscal', tipo }).catch(() => {
    injetar(tabId); // content.js ainda não está na aba (ex.: aba aberta antes de instalar)
  });
}

function injetar(tabId) {
  chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] }).catch((e) =>
    console.warn(PREFIXO, 'não consegui injetar o content.js:', e && e.message));
}

chrome.webNavigation.onReferenceFragmentUpdated.addListener((d) => avisarAba(d.tabId, d.frameId, 'url-mudou'), FILTRO);
chrome.webNavigation.onHistoryStateUpdated.addListener((d) => avisarAba(d.tabId, d.frameId, 'url-mudou'), FILTRO);

// O ícone da extensão abre a janela de configuração (popup.html: pasta de destino + lista de CNPJs).
// Antes (até a v1.0.6) o ícone recomeçava a lista do zero; isso agora é o botão "Zerar progresso" da janela.

// ------------------------------- downloads múltiplos (autorizado pelo usuário) -------------------------------
// O Chrome bloqueia o 2º download seguido de um site ("Este site tentou baixar vários arquivos"). A permissão é
// dada SÓ para o portal da Receita (servicos.receitafederal.gov.br), antes de qualquer download.
const PADRAO_PORTAL = 'https://servicos.receitafederal.gov.br/*';
async function permitirDownloadsMultiplos() {
  try {
    const atual = await chrome.contentSettings.automaticDownloads.get({ primaryUrl: 'https://servicos.receitafederal.gov.br/' });
    if (atual && atual.setting === 'allow') return true;
    await chrome.contentSettings.automaticDownloads.set({ primaryPattern: PADRAO_PORTAL, setting: 'allow' });
    console.log(PREFIXO, 'downloads múltiplos permitidos para', PADRAO_PORTAL);
    return true;
  } catch (e) {
    console.warn(PREFIXO, 'não consegui permitir downloads múltiplos:', e && e.message);
    return false;
  }
}
chrome.runtime.onInstalled.addListener(() => { permitirDownloadsMultiplos(); });
chrome.runtime.onStartup.addListener(() => { permitirDownloadsMultiplos(); });

// ------------------------------- utilidades de download -------------------------------
function enviarParaAba(tabId, msg) {
  chrome.tabs.sendMessage(tabId, { origem: 'Situacao_Fiscal', ...msg }).catch(() => {});
}

// Espera o download terminar; devolve o item (com o caminho final em item.filename).
function acompanharDownload(id, timeout) {
  return new Promise((resolve, reject) => {
    let feito = false;
    const fim = (f, v) => { if (feito) return; feito = true; clearTimeout(t); chrome.downloads.onChanged.removeListener(ouvir); f(v); };
    const conferir = async () => {
      const [it] = await chrome.downloads.search({ id });
      if (!it) return fim(reject, new Error('download não encontrado'));
      if (it.state === 'complete') fim(resolve, it);
      else if (it.state === 'interrupted') fim(reject, new Error(`download interrompido (${it.error || 'motivo desconhecido'})`));
    };
    const ouvir = (d) => { if (d.id === id && d.state) conferir(); };
    const t = setTimeout(() => fim(reject, new Error(`download não terminou em ${Math.round(timeout / 1000)} s`)), timeout);
    chrome.downloads.onChanged.addListener(ouvir);
    conferir(); // pode já ter terminado
  });
}

function base64ParaBytes(b64) {
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

function bytesParaBase64(bytes) {
  let s = '';
  for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
  return btoa(s);
}

// PDF de uma página com a imagem JPEG inteira (largura padrão A4 deitada: 842 pt; altura proporcional).
function pdfDeJpeg(jpeg, largura, altura, larguraPt = 842) {
  const pw = Math.round(larguraPt * 100) / 100, ph = Math.round((larguraPt * altura / largura) * 100) / 100;
  const partes = [];
  const offsets = [];
  let tamanho = 0;
  const latin1 = (s) => { const b = new Uint8Array(s.length); for (let i = 0; i < s.length; i++) b[i] = s.charCodeAt(i) & 0xff; return b; };
  const por = (x) => { const b = typeof x === 'string' ? latin1(x) : x; partes.push(b); tamanho += b.length; };
  const objeto = (n, corpo) => { offsets[n] = tamanho; por(`${n} 0 obj\n`); corpo(); por('\nendobj\n'); };
  por('%PDF-1.4\n%\xE2\xE3\xCF\xD3\n');
  objeto(1, () => por('<< /Type /Catalog /Pages 2 0 R >>'));
  objeto(2, () => por('<< /Type /Pages /Kids [3 0 R] /Count 1 >>'));
  objeto(3, () => por(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${pw} ${ph}] /Resources << /XObject << /Im0 4 0 R >> >> /Contents 5 0 R >>`));
  objeto(4, () => {
    por(`<< /Type /XObject /Subtype /Image /Width ${largura} /Height ${altura} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${jpeg.length} >>\nstream\n`);
    por(jpeg);
    por('\nendstream');
  });
  const conteudo = `q ${pw} 0 0 ${ph} 0 0 cm /Im0 Do Q`;
  objeto(5, () => por(`<< /Length ${conteudo.length} >>\nstream\n${conteudo}\nendstream`));
  const xref = tamanho;
  por('xref\n0 6\n0000000000 65535 f \n' + [1, 2, 3, 4, 5].map((n) => `${String(offsets[n]).padStart(10, '0')} 00000 n \n`).join(''));
  por(`trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF\n`);
  const pdf = new Uint8Array(tamanho);
  let pos = 0;
  for (const p of partes) { pdf.set(p, pos); pos += p.length; }
  return pdf;
}

// ------------------------------- captura da tela em PDF -------------------------------
// regiao (opcional) = { x, y, w, h } em px da janela da página; janela = { w, h } da página (para a escala:
// a captura vem em pixels do monitor, que mudam com o zoom e a escala do Windows).
async function capturarPdf(tabId, filename, regiao, janelaPagina) {
  const tab = await chrome.tabs.get(tabId);
  if (!tab.active) throw new Error('a aba da Receita precisa estar visível (ativa) no momento da captura');
  const janela = await chrome.windows.get(tab.windowId);
  if (janela.state === 'minimized') throw new Error('a janela do Chrome está minimizada');
  const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: regiao ? 'png' : 'jpeg', quality: 92 });
  let jpeg = base64ParaBytes(dataUrl.split(',')[1]);
  const bmp = await createImageBitmap(new Blob([jpeg], { type: regiao ? 'image/png' : 'image/jpeg' }));
  let width = bmp.width, height = bmp.height, larguraPt = 842;
  if (regiao) {
    const escala = bmp.width / ((janelaPagina && janelaPagina.w) || bmp.width);
    const sx = Math.max(0, Math.round(regiao.x * escala)), sy = Math.max(0, Math.round(regiao.y * escala));
    const sw = Math.min(bmp.width - sx, Math.round(regiao.w * escala)), sh = Math.min(bmp.height - sy, Math.round(regiao.h * escala));
    if (sw < 10 || sh < 10) { bmp.close(); throw new Error(`recorte inválido (${sw}x${sh} px)`); }
    const tela = new OffscreenCanvas(sw, sh);
    const g = tela.getContext('2d');
    g.fillStyle = '#fff';
    g.fillRect(0, 0, sw, sh);
    g.drawImage(bmp, sx, sy, sw, sh, 0, 0, sw, sh);
    jpeg = new Uint8Array(await (await tela.convertToBlob({ type: 'image/jpeg', quality: 0.95 })).arrayBuffer());
    width = sw; height = sh;
    larguraPt = Math.min(842, regiao.w * 1.25); // recorte pequeno: página do tamanho dele (legível, sem esticar)
  }
  bmp.close();
  const pdf = pdfDeJpeg(jpeg, width, height, larguraPt);
  const url = `data:application/pdf;base64,${bytesParaBase64(pdf)}`;
  // Com um ouvinte de onDeterminingFilename registrado, o Chrome ignora o "filename" abaixo se o ouvinte não o
  // confirmar (foi assim que a captura virou "download (3).pdf"). O ouvinte lê o nome deste mapa.
  nomesProprios.set(url, filename);
  let item;
  try {
    const id = await chrome.downloads.download({ url, filename, conflictAction: 'overwrite', saveAs: false });
    item = await acompanharDownload(id, 60000);
  } finally {
    nomesProprios.delete(url);
  }
  const final = item.filename.replace(/\\/g, '/');
  if (!final.endsWith(filename)) throw new Error(`o Chrome salvou a captura como "${item.filename}" em vez de ".../${filename}"`);
  console.log(PREFIXO, 'captura salva:', item.filename);
  return { ok: true, filename: item.filename };
}

// Downloads feitos pela própria extensão: url → caminho desejado (relativo a Downloads).
const nomesProprios = new Map();

// CNPJs (dígitos) que já têm o relatório salvo em RFB_CNPJ/<CNPJ>/situação fiscal/ (arquivo ainda existe).
async function concluidosPorDownload(digitos) {
  const itens = await chrome.downloads.search({ query: ['RFB_CNPJ'], state: 'complete', limit: 0 });
  const achados = {};
  for (const it of itens) {
    const m = it.filename.replace(/\\/g, '/').match(/\/RFB_CNPJ\/(\d{11,14})\/situação fiscal\/[^/]+$/);
    if (m && it.exists && digitos.includes(m[1]) && !achados[m[1]]) achados[m[1]] = it.filename;
  }
  return achados;
}

// ------------------------------- relatório do portal -------------------------------
// Espera de UM download: { tabId, pasta, ate }. Guardada também em storage.session (o service worker pode reiniciar).
let esperaRelatorio = null;

async function lerEspera() {
  if (esperaRelatorio) return esperaRelatorio;
  const { esperaRelatorio: e } = await chrome.storage.session.get('esperaRelatorio');
  return e || null;
}

async function definirEspera(e) {
  esperaRelatorio = e;
  if (e) await chrome.storage.session.set({ esperaRelatorio: e });
  else await chrome.storage.session.remove('esperaRelatorio');
}

// Nome de arquivo sem caracteres que o Windows não aceita.
const limparNome = (s) => String(s).replace(/[<>:"/\\|?*\x00-\x1f]/g, '_').trim() || 'relatorio.pdf';

chrome.downloads.onDeterminingFilename.addListener((item, sugerir) => {
  if (item.byExtensionId === ID_EXTENSAO) {
    // nossos downloads: confirma o caminho pedido (sem isso o Chrome usaria "download.pdf")
    const nome = nomesProprios.get(item.url) || nomesProprios.get(item.finalUrl);
    if (nome) sugerir({ filename: nome, conflictAction: 'overwrite' });
    else sugerir();
    return;
  }
  (async () => {
    const e = await lerEspera();
    if (!e || Date.now() > e.ate) { sugerir(); return; }
    await definirEspera(null); // vale para um único download
    // nome fixo (certidão: RFB_<CNPJ>.pdf) ou o nome original do portal (relatório)
    const original = limparNome((item.filename || 'documento.pdf').split(/[\\/]/).pop());
    const destino = `${e.pasta}/${e.nome ? limparNome(e.nome) : original}`;
    // overwrite: numa retomada o mesmo arquivo é substituído, sem cópias "(1)"
    sugerir({ filename: destino, conflictAction: 'overwrite' });
    console.log(PREFIXO, 'relatório redirecionado para', destino);
    enviarParaAba(e.tabId, { tipo: 'relatorio-iniciado', filename: destino });
    acompanharDownload(item.id, VALIDADE_ESPERA_RELATORIO_MS).then(
      (it) => enviarParaAba(e.tabId, { tipo: 'relatorio-salvo', filename: it.filename }),
      (err) => enviarParaAba(e.tabId, { tipo: 'relatorio-erro', erro: err.message }));
  })();
  return true; // a sugestão é feita de forma assíncrona
});

// Se o portal abrir o relatório numa aba nova em vez de baixar, avisa a automação.
chrome.tabs.onCreated.addListener(async (tab) => {
  const e = await lerEspera();
  if (!e || Date.now() > e.ate || tab.openerTabId !== e.tabId) return;
  await definirEspera(null);
  enviarParaAba(e.tabId, { tipo: 'relatorio-erro', erro: `o portal abriu o relatório numa nova aba (${tab.pendingUrl || tab.url || 'endereço desconhecido'}) em vez de baixar o arquivo` });
});

// ------------------------------- mensagens do content.js -------------------------------
chrome.runtime.onMessage.addListener((msg, sender, responder) => {
  if (!msg || msg.origem !== 'Situacao_Fiscal' || !sender.tab) return;
  if (msg.tipo === 'capturar-pdf') {
    capturarPdf(sender.tab.id, msg.filename, msg.regiao, msg.janela).then(responder, (e) => responder({ ok: false, erro: e.message }));
    return true;
  }
  if (msg.tipo === 'preparar-relatorio') {
    permitirDownloadsMultiplos() // garante a permissão antes de cada download do portal
      .then(() => definirEspera({ tabId: sender.tab.id, pasta: msg.pasta, nome: msg.nome || null, ate: Date.now() + VALIDADE_ESPERA_RELATORIO_MS }))
      .then(() => responder({ ok: true }), (e) => responder({ ok: false, erro: e.message }));
    return true;
  }
  if (msg.tipo === 'concluidos-por-download') {
    concluidosPorDownload(msg.digitos || []).then((achados) => responder({ ok: true, achados }),
      (e) => responder({ ok: false, erro: e.message }));
    return true;
  }
  if (msg.tipo === 'cancelar-relatorio') {
    definirEspera(null).then(() => responder({ ok: true }));
    return true;
  }
});
