// Substitui o bloco "const DOCUMENTOS = [ ... ];" do content.js pela lista do arquivo (uma linha por empresa).
const fs = require('fs');
const [, , arqLista, arqContent] = process.argv;
const linhas = fs.readFileSync(arqLista, 'utf8').split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
const corpo = linhas.map((l) => `    ${JSON.stringify(l).replace(/^"|"$/g, "'").replace(/\\"/g, '"')},`).join('\n');
const src = fs.readFileSync(arqContent, 'utf8');
const re = /const DOCUMENTOS = \[[\s\S]*?\n  \];/;
if (!re.test(src)) throw new Error('bloco DOCUMENTOS não encontrado');
fs.writeFileSync(arqContent, src.replace(re, `const DOCUMENTOS = [\n${corpo}\n  ];`), 'utf8');
console.log('lista aplicada:', linhas.length, 'itens');
