# Autom_Situacao_Fiscal — código completo

Extensão **Situacao_Fiscal**, versão **1.1.1**. Página gerada em 13/11/2026, 15:16:59 por `ferramentas/gerar_codigo_completo.js`.

Para reconstruir o projeto, crie cada arquivo no caminho indicado (relativo à pasta `Autom_Situacao_Fiscal`) e cole o conteúdo do bloco logo abaixo dele, do início ao fim, sem a linha de abertura e a de fechamento do bloco. Os arquivos são UTF-8.

## Arquivos

1. `README.md` — Como instalar e executar
2. `Situacao_Fiscal/manifest.json` — Manifesto da extensão (nome, versão, permissões)
3. `Situacao_Fiscal/background.js` — Service worker: captura em PDF, downloads, pastas, permissões
4. `Situacao_Fiscal/content.js` — Fluxo da automação, seta, lista de CNPJs e configurações
5. `Situacao_Fiscal/popup.html` — Janela da extensão (ícone): pasta de destino e lista de CNPJs
6. `Situacao_Fiscal/popup.js` — Validação e gravação da configuração da janela
7. `Situacao_Fiscal/LEIA-ME.md` — Manual detalhado da extensão
8. `ferramentas/lista_cnpjs.txt` — Lista de CNPJs (CNPJ;NOME)
9. `ferramentas/validar_lista.js` — Valida a lista
10. `ferramentas/aplicar_lista.js` — Grava a lista no content.js
11. `ferramentas/analisar_progresso.js` — Cruza a lista com as pastas salvas
12. `ferramentas/gerar_codigo_completo.js` — Gera esta página
13. `CLAUDE.md` — Instruções para o Claude continuar o projeto
14. `HISTORICO.md` — Histórico de criação (decisões, problemas, regras, pendências)

---

## `README.md`

**Arquivo:** `README.md` · **Caminho:** `Autom_Situacao_Fiscal/README.md` · 134 linhas · 7700 bytes — Como instalar e executar

````markdown
# Autom_Situacao_Fiscal

Extensão do Chrome (Manifest V3) **Situacao_Fiscal**, versão **1.1.1**. Ela automatiza a consulta de situação
fiscal no portal da Receita Federal (**Minhas Dívidas e Pendências**, acessado pelo e-CAC), para uma lista de CNPJs
representados pela Assecon como **Procurador**.

Para cada CNPJ da lista, a extensão:

1. abre o perfil e representa o CNPJ (Trocar Representação → CNPJ → perfil **Procurador** → **Representar**);
2. confere o CNPJ em **Representação Atual** e em **Dados Cadastrais**;
3. lê o **Resultado da Análise**. Se for **Com pendência**, salva a captura da tela em PDF;
4. rola até o rodapé e baixa, um por vez, **Baixar Certidão** e **Baixar Relatório**;
5. se o portal recusar a procuração, salva o recorte da mensagem como evidência em PDF;
6. passa para o próximo CNPJ, com pelo menos 5 s de intervalo.

Não usa Playwright nem Selenium. É JavaScript de extensão, com uma seta visível que mostra cada ação.

---

## Estrutura

```
Autom_Situacao_Fiscal/
├── README.md                    ← este arquivo
├── CODIGO_COMPLETO.md           ← todos os arquivos do projeto, com o código integral (para reconstruir)
├── HISTORICO.md                 ← histórico da criação: decisões, problemas, soluções, regras, pendências
├── CLAUDE.md                    ← instruções para o Claude continuar o projeto num chat novo
├── Situacao_Fiscal/             ← A EXTENSÃO (pasta carregada no Chrome)
│   ├── manifest.json            ← nome, versão, permissões
│   ├── background.js            ← service worker: captura em PDF, downloads, pastas, permissões
│   ├── content.js               ← fluxo da automação, seta, lista padrão de CNPJs e configurações
│   ├── popup.html / popup.js    ← janela do ícone: pasta de destino, lista de CNPJs, aviso do e-CAC
│   └── LEIA-ME.md               ← manual detalhado de cada etapa e regra
└── ferramentas/                 ← auxiliares (Node.js), opcionais
    ├── lista_cnpjs.txt          ← a lista de CNPJs (CNPJ;NOME), uma por linha
    ├── validar_lista.js         ← confere formato, dígitos verificadores, repetidos e nomes de pasta iguais
    ├── aplicar_lista.js         ← grava a lista do .txt dentro do content.js
    └── analisar_progresso.js    ← cruza a lista com as pastas salvas e gera uma planilha do que falta
```

> **Onde o Chrome executa a extensão hoje:** `C:\Users\PANORAMA-PC\Desktop\ATM_SIT_FISCAL\Situacao_Fiscal`.
> Esta pasta de Documentos é a cópia de referência do projeto, e as duas devem ficar iguais. Não troque a pasta
> carregada no Chrome no meio de uma lista: o Chrome trataria a extensão como nova e o registro de progresso
> (CNPJs concluídos/pendentes) começaria do zero.

---

## Instalar

1. Abra `chrome://extensions` e ligue o **Modo do desenvolvedor**, no canto superior direito.
2. Clique em **Carregar sem compactação** e escolha a pasta `Situacao_Fiscal`.
3. Confira se o card mostra **Situacao_Fiscal 1.1.1**.
4. Em `chrome://settings/downloads`, deixe **desligado** "Perguntar onde salvar cada arquivo".
5. A permissão "Downloads automáticos", só para `servicos.receitafederal.gov.br`, é aplicada pela própria extensão.
   Para conferir: `chrome://settings/content/automaticDownloads`.

Depois de alterar qualquer arquivo, clique em **↻** no card da extensão e recarregue a página do portal.

## Executar

1. Entre no **e-CAC** com o certificado ou o gov.br (o login é manual).
2. Abra **Minhas Dívidas e Pendências**
   (`https://servicos.receitafederal.gov.br/servico/pendencias/#/analise-pendencias`).
3. Clique no **ícone da extensão**. Abre uma janela com:
   - um aviso de que o e-CAC e essa página precisam estar abertos, e se a página está aberta;
   - a **pasta de destino** (dentro de Downloads);
   - a **lista de CNPJs** (`CNPJ` ou `CNPJ;NOME`, um por linha; aceita colar do Excel);
   - o placar da pasta.
   Clique em **Salvar e iniciar**: a página recarrega e a lista começa, ou continua se a pasta for a mesma.
   **Zerar progresso** (dois cliques) recomeça a pasta do 1º CNPJ.
4. Enquanto roda:
   - deixe a **aba visível** e o Chrome sem minimizar, porque as capturas dependem disso;
   - não deixe o computador entrar em suspensão;
   - se a sessão do e-CAC expirar, faça login de novo e volte à página. A extensão continua de onde parou.

O aviso no canto inferior esquerdo mostra no topo o **placar** (analisados, faltam e pendentes, com uma barra de
progresso) e, embaixo, a etapa: azul para andamento, verde para concluído e vermelho para erro,
com a etapa e o motivo. Detalhes no console (F12), com o prefixo `[Situacao_Fiscal]`.

## Onde os resultados ficam

O Chrome só permite que extensões gravem dentro da pasta de Downloads:

```
C:\Users\PANORAMA-PC\Downloads\Situacao_Fiscal_Assecon\PRISCILLA_ASSECON\<NOME DA EMPRESA>\
    RFB_<CNPJ>.pdf                                   certidão (quando o portal oferece)
    Com_Pendencia_<CNPJ>.pdf                         captura da tela (só "Com pendência")
    situação fiscal\<nome original do relatório>.pdf relatório oficial
    Erro_de_Procuracao\Erro_de_Procuracao_<CNPJ>.pdf evidência quando o portal recusa a procuração
```

`<CNPJ>` usa só os 14 dígitos, com os zeros à esquerda. O nome da pasta vem da lista (depois do `;`). Quando o
nome se repete na lista (ex.: filiais "… LTDA PE"), o número da filial é acrescentado no fim (`… PE 0002`).

## Configurar

Tudo fica no bloco **CONFIGURAÇÃO**, no início de `Situacao_Fiscal/content.js`:

| Constante | Para que serve | Valor |
|---|---|---|
| `DOCUMENTOS` | lista de CNPJs, `'CNPJ;NOME'` | 208 itens |
| `PASTA_RAIZ` | pasta dentro de Downloads (cada raiz tem o próprio progresso) | `Situacao_Fiscal_Assecon/PRISCILLA_ASSECON` (2ª rodada; a 1ª está em `ASSECON HUB CONTABILIDADE`) |
| `PERFIL` | opção escolhida no seletor | `Procurador` |
| `LENTIDAO_MOUSE` / `LENTIDAO_DIGITACAO` | velocidade da seta e da digitação | `1.0` |
| `INTERVALO_ENTRE_EMPRESAS_MS` | intervalo mínimo entre empresas | 5 s |
| `ESPERA_PROCESSANDO_NA_PAGINA_MS` | tempo esperando "Estamos processando…" antes de marcar pendente | 60 s |
| `RODADAS_PENDENTES` | novas tentativas dos pendentes no fim da lista | 1 |
| `MAX_TENTATIVAS_REPRESENTAR` | repetições quando a página volta com a empresa anterior | 3 |
| `MAX_RECARGAS_POR_CNPJ` | recargas automáticas em falha temporária do portal | 3 |
| `MAX_RECARGAS_DOWNLOAD` / `ESPERA_DOWNLOAD_1A_MS` | falha no download (ex.: erro 043): recargas e espera da 1ª (depois, 2 min) | 4 / 15 s |
| `TIMEOUT_INICIO_DOWNLOAD_MS` | tempo para o download começar após o clique | 30 s |
| `TIMEOUT_CARREGANDO_MS` / `ESPERA_FALHA_PORTAL_MS` / `ESPERA_CARREGAMENTO_MS` | tempos da recuperação | 60 s / 2 min / 15 s |

## Trocar a lista de CNPJs (com as ferramentas)

Requer o Node.js instalado. Na pasta `Autom_Situacao_Fiscal`:

```
node ferramentas\validar_lista.js ferramentas\lista_cnpjs.txt
node ferramentas\aplicar_lista.js ferramentas\lista_cnpjs.txt Situacao_Fiscal\content.js
```

A primeira confere a lista e a segunda grava a lista no `content.js`. Depois, clique em ↻ na extensão. Para começar
do zero numa pasta nova, troque também `PASTA_RAIZ`.

## Ver o que falta

```
node ferramentas\analisar_progresso.js Situacao_Fiscal\content.js "C:\Users\PANORAMA-PC\Downloads\Situacao_Fiscal_Assecon" progresso.csv
```

Mostra quantos estão concluídos (e de que tipo), onde parou, os pulados e o próximo da fila, e gera `progresso.csv`,
que abre no Excel.
````

---

## `Situacao_Fiscal/manifest.json`

**Arquivo:** `manifest.json` · **Caminho:** `Autom_Situacao_Fiscal/Situacao_Fiscal/manifest.json` · 24 linhas · 837 bytes — Manifesto da extensão (nome, versão, permissões)

```json
{
  "manifest_version": 3,
  "name": "Situacao_Fiscal",
  "version": "1.1.1",
  "description": "Situacao_Fiscal: para cada CNPJ da lista, representa como Procurador em Minhas Dívidas e Pendências, confere a empresa e, se houver pendência, salva a captura e o relatório em PDF.",
  "action": {
    "default_title": "Situacao_Fiscal: pasta de destino e lista de CNPJs",
    "default_popup": "popup.html"
  },
  "permissions": ["webNavigation", "scripting", "downloads", "storage", "contentSettings"],
  "host_permissions": ["https://servicos.receitafederal.gov.br/*", "<all_urls>"],
  "background": {
    "service_worker": "background.js"
  },
  "content_scripts": [
    {
      "matches": ["https://servicos.receitafederal.gov.br/*"],
      "js": ["content.js"],
      "run_at": "document_idle",
      "all_frames": false
    }
  ]
}
```

---

## `Situacao_Fiscal/background.js`

**Arquivo:** `background.js` · **Caminho:** `Autom_Situacao_Fiscal/Situacao_Fiscal/background.js` · 252 linhas · 13552 bytes — Service worker: captura em PDF, downloads, pastas, permissões

```javascript
// Situacao_Fiscal — service worker.
// - Reforça o aviso de navegação interna do portal (SPA: muda só o trecho depois de "#" ou usa history.pushState).
// - Botão da extensão: executa o fluxo de novo na aba.
// - Captura a tela da aba e salva como PDF (RFB_CNPJ/<CNPJ>/Com_Pendencia_<CNPJ>.pdf).
// - Redireciona o download do "Baixar Relatório" para RFB_CNPJ/<CNPJ>/situação fiscal/<nome original>.
// As pastas são relativas à pasta de Downloads do Chrome.
'use strict';

const PREFIXO = '[Situacao_Fiscal]';
const ID_EXTENSAO = chrome.runtime.id;
const FILTRO = { url: [{ hostEquals: 'servicos.receitafederal.gov.br', pathPrefix: '/servico/' }] };
const VALIDADE_ESPERA_RELATORIO_MS = 120000;

// ------------------------------- navegação e botão -------------------------------
function avisarAba(tabId, frameId, tipo) {
  if (frameId !== 0) return; // só o quadro principal
  chrome.tabs.sendMessage(tabId, { origem: 'Situacao_Fiscal', tipo }).catch(() => {
    injetar(tabId); // content.js ainda não está na aba (ex.: aba aberta antes de instalar)
  });
}

function injetar(tabId) {
  chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] }).catch((e) =>
    console.warn(PREFIXO, 'não consegui injetar o content.js:', e && e.message));
}

chrome.webNavigation.onReferenceFragmentUpdated.addListener((d) => avisarAba(d.tabId, d.frameId, 'url-mudou'), FILTRO);
chrome.webNavigation.onHistoryStateUpdated.addListener((d) => avisarAba(d.tabId, d.frameId, 'url-mudou'), FILTRO);

// O ícone da extensão abre a janela de configuração (popup.html: pasta de destino + lista de CNPJs).
// Antes (até a v1.0.6) o ícone recomeçava a lista do zero; isso agora é o botão "Zerar progresso" da janela.

// ------------------------------- downloads múltiplos (autorizado pelo usuário) -------------------------------
// O Chrome bloqueia o 2º download seguido de um site ("Este site tentou baixar vários arquivos"). A permissão é
// dada SÓ para o portal da Receita (servicos.receitafederal.gov.br), antes de qualquer download.
const PADRAO_PORTAL = 'https://servicos.receitafederal.gov.br/*';
async function permitirDownloadsMultiplos() {
  try {
    const atual = await chrome.contentSettings.automaticDownloads.get({ primaryUrl: 'https://servicos.receitafederal.gov.br/' });
    if (atual && atual.setting === 'allow') return true;
    await chrome.contentSettings.automaticDownloads.set({ primaryPattern: PADRAO_PORTAL, setting: 'allow' });
    console.log(PREFIXO, 'downloads múltiplos permitidos para', PADRAO_PORTAL);
    return true;
  } catch (e) {
    console.warn(PREFIXO, 'não consegui permitir downloads múltiplos:', e && e.message);
    return false;
  }
}
chrome.runtime.onInstalled.addListener(() => { permitirDownloadsMultiplos(); });
chrome.runtime.onStartup.addListener(() => { permitirDownloadsMultiplos(); });

// ------------------------------- utilidades de download -------------------------------
function enviarParaAba(tabId, msg) {
  chrome.tabs.sendMessage(tabId, { origem: 'Situacao_Fiscal', ...msg }).catch(() => {});
}

// Espera o download terminar; devolve o item (com o caminho final em item.filename).
function acompanharDownload(id, timeout) {
  return new Promise((resolve, reject) => {
    let feito = false;
    const fim = (f, v) => { if (feito) return; feito = true; clearTimeout(t); chrome.downloads.onChanged.removeListener(ouvir); f(v); };
    const conferir = async () => {
      const [it] = await chrome.downloads.search({ id });
      if (!it) return fim(reject, new Error('download não encontrado'));
      if (it.state === 'complete') fim(resolve, it);
      else if (it.state === 'interrupted') fim(reject, new Error(`download interrompido (${it.error || 'motivo desconhecido'})`));
    };
    const ouvir = (d) => { if (d.id === id && d.state) conferir(); };
    const t = setTimeout(() => fim(reject, new Error(`download não terminou em ${Math.round(timeout / 1000)} s`)), timeout);
    chrome.downloads.onChanged.addListener(ouvir);
    conferir(); // pode já ter terminado
  });
}

function base64ParaBytes(b64) {
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

function bytesParaBase64(bytes) {
  let s = '';
  for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
  return btoa(s);
}

// PDF de uma página com a imagem JPEG inteira (largura padrão A4 deitada: 842 pt; altura proporcional).
function pdfDeJpeg(jpeg, largura, altura, larguraPt = 842) {
  const pw = Math.round(larguraPt * 100) / 100, ph = Math.round((larguraPt * altura / largura) * 100) / 100;
  const partes = [];
  const offsets = [];
  let tamanho = 0;
  const latin1 = (s) => { const b = new Uint8Array(s.length); for (let i = 0; i < s.length; i++) b[i] = s.charCodeAt(i) & 0xff; return b; };
  const por = (x) => { const b = typeof x === 'string' ? latin1(x) : x; partes.push(b); tamanho += b.length; };
  const objeto = (n, corpo) => { offsets[n] = tamanho; por(`${n} 0 obj\n`); corpo(); por('\nendobj\n'); };
  por('%PDF-1.4\n%\xE2\xE3\xCF\xD3\n');
  objeto(1, () => por('<< /Type /Catalog /Pages 2 0 R >>'));
  objeto(2, () => por('<< /Type /Pages /Kids [3 0 R] /Count 1 >>'));
  objeto(3, () => por(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${pw} ${ph}] /Resources << /XObject << /Im0 4 0 R >> >> /Contents 5 0 R >>`));
  objeto(4, () => {
    por(`<< /Type /XObject /Subtype /Image /Width ${largura} /Height ${altura} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${jpeg.length} >>\nstream\n`);
    por(jpeg);
    por('\nendstream');
  });
  const conteudo = `q ${pw} 0 0 ${ph} 0 0 cm /Im0 Do Q`;
  objeto(5, () => por(`<< /Length ${conteudo.length} >>\nstream\n${conteudo}\nendstream`));
  const xref = tamanho;
  por('xref\n0 6\n0000000000 65535 f \n' + [1, 2, 3, 4, 5].map((n) => `${String(offsets[n]).padStart(10, '0')} 00000 n \n`).join(''));
  por(`trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF\n`);
  const pdf = new Uint8Array(tamanho);
  let pos = 0;
  for (const p of partes) { pdf.set(p, pos); pos += p.length; }
  return pdf;
}

// ------------------------------- captura da tela em PDF -------------------------------
// regiao (opcional) = { x, y, w, h } em px da janela da página; janela = { w, h } da página (para a escala:
// a captura vem em pixels do monitor, que mudam com o zoom e a escala do Windows).
async function capturarPdf(tabId, filename, regiao, janelaPagina) {
  const tab = await chrome.tabs.get(tabId);
  if (!tab.active) throw new Error('a aba da Receita precisa estar visível (ativa) no momento da captura');
  const janela = await chrome.windows.get(tab.windowId);
  if (janela.state === 'minimized') throw new Error('a janela do Chrome está minimizada');
  const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: regiao ? 'png' : 'jpeg', quality: 92 });
  let jpeg = base64ParaBytes(dataUrl.split(',')[1]);
  const bmp = await createImageBitmap(new Blob([jpeg], { type: regiao ? 'image/png' : 'image/jpeg' }));
  let width = bmp.width, height = bmp.height, larguraPt = 842;
  if (regiao) {
    const escala = bmp.width / ((janelaPagina && janelaPagina.w) || bmp.width);
    const sx = Math.max(0, Math.round(regiao.x * escala)), sy = Math.max(0, Math.round(regiao.y * escala));
    const sw = Math.min(bmp.width - sx, Math.round(regiao.w * escala)), sh = Math.min(bmp.height - sy, Math.round(regiao.h * escala));
    if (sw < 10 || sh < 10) { bmp.close(); throw new Error(`recorte inválido (${sw}x${sh} px)`); }
    const tela = new OffscreenCanvas(sw, sh);
    const g = tela.getContext('2d');
    g.fillStyle = '#fff';
    g.fillRect(0, 0, sw, sh);
    g.drawImage(bmp, sx, sy, sw, sh, 0, 0, sw, sh);
    jpeg = new Uint8Array(await (await tela.convertToBlob({ type: 'image/jpeg', quality: 0.95 })).arrayBuffer());
    width = sw; height = sh;
    larguraPt = Math.min(842, regiao.w * 1.25); // recorte pequeno: página do tamanho dele (legível, sem esticar)
  }
  bmp.close();
  const pdf = pdfDeJpeg(jpeg, width, height, larguraPt);
  const url = `data:application/pdf;base64,${bytesParaBase64(pdf)}`;
  // Com um ouvinte de onDeterminingFilename registrado, o Chrome ignora o "filename" abaixo se o ouvinte não o
  // confirmar (foi assim que a captura virou "download (3).pdf"). O ouvinte lê o nome deste mapa.
  nomesProprios.set(url, filename);
  let item;
  try {
    const id = await chrome.downloads.download({ url, filename, conflictAction: 'overwrite', saveAs: false });
    item = await acompanharDownload(id, 60000);
  } finally {
    nomesProprios.delete(url);
  }
  const final = item.filename.replace(/\\/g, '/');
  if (!final.endsWith(filename)) throw new Error(`o Chrome salvou a captura como "${item.filename}" em vez de ".../${filename}"`);
  console.log(PREFIXO, 'captura salva:', item.filename);
  return { ok: true, filename: item.filename };
}

// Downloads feitos pela própria extensão: url → caminho desejado (relativo a Downloads).
const nomesProprios = new Map();

// CNPJs (dígitos) que já têm o relatório salvo em RFB_CNPJ/<CNPJ>/situação fiscal/ (arquivo ainda existe).
async function concluidosPorDownload(digitos) {
  const itens = await chrome.downloads.search({ query: ['RFB_CNPJ'], state: 'complete', limit: 0 });
  const achados = {};
  for (const it of itens) {
    const m = it.filename.replace(/\\/g, '/').match(/\/RFB_CNPJ\/(\d{11,14})\/situação fiscal\/[^/]+$/);
    if (m && it.exists && digitos.includes(m[1]) && !achados[m[1]]) achados[m[1]] = it.filename;
  }
  return achados;
}

// ------------------------------- relatório do portal -------------------------------
// Espera de UM download: { tabId, pasta, ate }. Guardada também em storage.session (o service worker pode reiniciar).
let esperaRelatorio = null;

async function lerEspera() {
  if (esperaRelatorio) return esperaRelatorio;
  const { esperaRelatorio: e } = await chrome.storage.session.get('esperaRelatorio');
  return e || null;
}

async function definirEspera(e) {
  esperaRelatorio = e;
  if (e) await chrome.storage.session.set({ esperaRelatorio: e });
  else await chrome.storage.session.remove('esperaRelatorio');
}

// Nome de arquivo sem caracteres que o Windows não aceita.
const limparNome = (s) => String(s).replace(/[<>:"/\\|?*\x00-\x1f]/g, '_').trim() || 'relatorio.pdf';

chrome.downloads.onDeterminingFilename.addListener((item, sugerir) => {
  if (item.byExtensionId === ID_EXTENSAO) {
    // nossos downloads: confirma o caminho pedido (sem isso o Chrome usaria "download.pdf")
    const nome = nomesProprios.get(item.url) || nomesProprios.get(item.finalUrl);
    if (nome) sugerir({ filename: nome, conflictAction: 'overwrite' });
    else sugerir();
    return;
  }
  (async () => {
    const e = await lerEspera();
    if (!e || Date.now() > e.ate) { sugerir(); return; }
    await definirEspera(null); // vale para um único download
    // nome fixo (certidão: RFB_<CNPJ>.pdf) ou o nome original do portal (relatório)
    const original = limparNome((item.filename || 'documento.pdf').split(/[\\/]/).pop());
    const destino = `${e.pasta}/${e.nome ? limparNome(e.nome) : original}`;
    // overwrite: numa retomada o mesmo arquivo é substituído, sem cópias "(1)"
    sugerir({ filename: destino, conflictAction: 'overwrite' });
    console.log(PREFIXO, 'relatório redirecionado para', destino);
    enviarParaAba(e.tabId, { tipo: 'relatorio-iniciado', filename: destino });
    acompanharDownload(item.id, VALIDADE_ESPERA_RELATORIO_MS).then(
      (it) => enviarParaAba(e.tabId, { tipo: 'relatorio-salvo', filename: it.filename }),
      (err) => enviarParaAba(e.tabId, { tipo: 'relatorio-erro', erro: err.message }));
  })();
  return true; // a sugestão é feita de forma assíncrona
});

// Se o portal abrir o relatório numa aba nova em vez de baixar, avisa a automação.
chrome.tabs.onCreated.addListener(async (tab) => {
  const e = await lerEspera();
  if (!e || Date.now() > e.ate || tab.openerTabId !== e.tabId) return;
  await definirEspera(null);
  enviarParaAba(e.tabId, { tipo: 'relatorio-erro', erro: `o portal abriu o relatório numa nova aba (${tab.pendingUrl || tab.url || 'endereço desconhecido'}) em vez de baixar o arquivo` });
});

// ------------------------------- mensagens do content.js -------------------------------
chrome.runtime.onMessage.addListener((msg, sender, responder) => {
  if (!msg || msg.origem !== 'Situacao_Fiscal' || !sender.tab) return;
  if (msg.tipo === 'capturar-pdf') {
    capturarPdf(sender.tab.id, msg.filename, msg.regiao, msg.janela).then(responder, (e) => responder({ ok: false, erro: e.message }));
    return true;
  }
  if (msg.tipo === 'preparar-relatorio') {
    permitirDownloadsMultiplos() // garante a permissão antes de cada download do portal
      .then(() => definirEspera({ tabId: sender.tab.id, pasta: msg.pasta, nome: msg.nome || null, ate: Date.now() + VALIDADE_ESPERA_RELATORIO_MS }))
      .then(() => responder({ ok: true }), (e) => responder({ ok: false, erro: e.message }));
    return true;
  }
  if (msg.tipo === 'concluidos-por-download') {
    concluidosPorDownload(msg.digitos || []).then((achados) => responder({ ok: true, achados }),
      (e) => responder({ ok: false, erro: e.message }));
    return true;
  }
  if (msg.tipo === 'cancelar-relatorio') {
    definirEspera(null).then(() => responder({ ok: true }));
    return true;
  }
});
```

---

## `Situacao_Fiscal/content.js`

**Arquivo:** `content.js` · **Caminho:** `Autom_Situacao_Fiscal/Situacao_Fiscal/content.js` · 2023 linhas · 113831 bytes — Fluxo da automação, seta, lista de CNPJs e configurações

```javascript
(() => {
  'use strict';
  // Uma cópia só por aba: o background pode injetar este script de novo (aba aberta antes da instalação).
  if (window.__situacaoFiscalCarregado) return;
  window.__situacaoFiscalCarregado = true;

  // ===================== CONFIGURAÇÃO (fácil de trocar) =====================
  // LISTA de CNPJs a processar, na ordem — ÚNICO ponto de entrada (com ou sem pontuação; zeros à esquerda mantidos).
  // Para adicionar empresas, basta acrescentar linhas. Cada item concluído fica registrado (chrome.storage.local) e
  // a execução segue para o próximo; ao terminar o último, encerra.
  // Formato de cada linha: 'CNPJ' ou 'CNPJ;NOME DA EMPRESA' (o nome só aparece nos avisos e no registro).
  const DOCUMENTOS = [
    '00.351.766/0001-10;OXIL GASES EQUIPAMENTOS COMERCIO LTDA.',
    '00.563.631/0001-19;JARDIM MOTO PECAS LTDA',
    '02.105.151/0001-30;CONSTRUTORA FIBRA LTDA',
    '02.106.023/0001-00;CONDOMINIO DO EDIFICIO COLOMBO',
    '02.767.953/0001-05;JBR PARTNERS SERVICOS LTDA',
    '02.940.168/0001-02;FCA TECNOLOGIA DE INFORMACAO LTDA',
    '03.679.839/0001-96;LIDIANY DE ALBUQUERQUE LEMOS',
    '04.025.127/0001-16;ARGAMASSAS SOLOSSANTINI E PRE MOLDADOS LTDA',
    '04.327.791/0001-10;PLANET PET COMERCIO E SERVICOS VETERINARIOS LTDA',
    '04.662.526/0001-98;PRATICA CONSULTORIA & CONSTRUCOES LTDA',
    '05.379.833/0001-29;MUSA TROPICAL LTDA',
    '05.379.833/0002-00;MUSA TROPICAL LTDA PE',
    '05.790.893/0001-30;KESIO TRANSPORTES LTDA',
    '06.000.805/0001-11;AZEVEDO & OLIVEIRA SERVICOS LTDA',
    '06.914.565/0001-60;MITRA MINERACAO E LOCACAO DE EQUIPAMENTOS LTDA',
    '06.914.565/0002-41;MITRA MINERACAO E LOCACAO DE EQUIPAMENTOS LTDA PB',
    '07.378.462/0001-96;M. M. DIESEL LTDA',
    '07.556.361/0001-68;ZILDEMBERG DE SOUSA RABELO',
    '07.595.014/0001-44;G. C. AUTOMACAO LTDA',
    '08.014.585/0001-00;AULETTE APOIO ADMINISTRATIVO LTDA',
    '09.865.460/0001-57;RESTAURANTE COSTA BRAVA LTDA',
    '10.358.365/0001-46;F & D FISIOTERAPIA LTDA',
    '10.595.650/0001-80;NORTEXTIL NORDESTE TEXTIL REP COM E ASS LTDA',
    '10.754.473/0001-38;ASSECON HUB CONTABILIDADE, CONSULTORIA E PLANEJAMENTO TRIBUTARIO LTDA',
    '10.820.066/0001-81;SOLOS SERVICOS DO BRASIL LTDA',
    '11.228.970/0001-65;SKITUR D. SANTINI PARQUES TURISTICOS LTDA',
    '11.836.288/0001-55;IMOBILIARIA FIBRA LTDA',
    '11.932.891/0001-30;MANA REPRESENTACOES COMERCIAIS LTDA',
    '12.096.200/0001-79;PERNAMBUCO PISO CONSTRUCOES E SERVICOS LTDA',
    '12.258.407/0001-00;SUPORTEC - SUPORTE EM SERVICOS DE INFORMATICA LTDA',
    '12.355.091/0001-67;LA URSA PRODUCOES CULTURAIS LTDA',
    '12.497.218/0001-82;SANDERSON RODRIGUES CAVALCANTI DOS SANTOS',
    '12.901.802/0001-51;ROCHA CLIMATIZACAO LTDA',
    '13.009.233/0001-05;J. D. SERVICOS DE MECANICA DE AUTOS LTDA.',
    '13.259.754/0001-02;COLOMBO REPRESENTACOES LTDA',
    '13.419.101/0001-43;GL CONSTRUCOES LTDA',
    '14.147.345/0001-87;JMC IMOBILIARIA LTDA',
    '14.298.373/0001-03;PERNAMBUCO PISCINAS COMERCIO E SERVICOS LTDA',
    '14.529.829/0001-90;BBA MATERIAIS PARA CONSTRUCAO LTDA',
    '14.754.104/0001-04;CE LOGISTICA INTEGRADA LTDA',
    '15.024.222/0001-11;CRIATIVAS CERIMONIAL E ASSESSORIA DE EVENTOS LTDA',
    '15.174.566/0001-07;VPA PARTICIPACOES LTDA',
    '15.586.487/0001-03;ANA MARIA DA SILVA - SERVICOS CONTABEIS LTDA',
    '15.863.081/0001-20;BARMONT CONSULTORIA E REPRESENTACAO LTDA',
    '16.366.121/0001-91;FK REPRESENTACOES COMERCIAIS E CONSULTORIA LTDA',
    '16.942.752/0001-01;CANTARELLI COMERCIO VAREJISTA DE ROUPAS E ACESSORIOS LTDA',
    '17.354.744/0001-07;PLUS HOME CONSTRUCOES LTDA',
    '17.504.941/0001-65;LAURO DE FARIAS TAVARES LAVA JATO',
    '17.658.085/0001-00;MPE TREINAMENTO & CONSULTORIA LTDA',
    '18.035.940/0001-81;GAS BRAS TECNOLOGIA EM GASES LTDA',
    '18.604.375/0001-26;C.P.B. CONSTRUTORA PAULO BORGES LTDA',
    '18.727.813/0001-43;LK DE ARAUJO TRANSPORTES DE CARGAS LTDA',
    '18.747.177/0001-11;FISIO DO TRABALHO CONSULTORIA & SERVICOS LTDA',
    '19.651.564/0001-12;TERRA FIRME EMPREENDIMENTOS LTDA',
    '20.297.739/0001-14;MOVIMENTAR PROMOCAO DE SAUDE DO TRABALHO LTDA',
    '20.898.850/0001-66;TECNOCOM ENGENHARIA LTDA',
    '20.937.437/0001-63;METALNORDESTE MONTAGENS E SERVICOS LTDA',
    '21.294.976/0001-94;MMA TECNOLOGIA-TI E AUTOMACAO COMERCIAL LTDA',
    '21.347.194/0001-76;D GRAUS ENGENHARIA LTDA',
    '21.794.062/0001-92;ASOS OCUPACIONAL LTDA',
    '22.884.706/0001-04;J A RIBEIRO SERVICOS E REPRESENTACOES LTDA',
    '23.085.619/0001-41;NAHAS LOCACOES DE ESPACOS, TREINAMENTOS E ALUGUEIS DE IMOVEIS LTDA',
    '23.239.974/0001-28;MADA CORRETORA DE SEGUROS LTDA',
    '23.398.612/0001-80;ANTONIO FELIX FOTOGRAFIA LTDA',
    '23.837.442/0001-92;BRINKALHANDO BUFFET INFANTIL LTDA',
    '23.975.573/0001-36;UNIENG ENGENHARIA LTDA',
    '24.134.405/0001-80;CONJUNTO RESIDENCIAL USINA CERAMICA DO CORDEIRO',
    '24.847.552/0001-06;NOVA MARCA PROJETOS E ENGENHARIA LTDA',
    '25.187.046/0001-92;FAMILIA MANA COMERCIO VAREJISTA DE ARTIGOS DE VESTUARIO E ACESSORIOS LTDA',
    '25.274.221/0001-89;FERREIRA & DANTAS ENGENHARIA LTDA',
    '26.247.531/0001-77;JE ENGENHARIA LTDA',
    '26.247.994/0001-39;CALDAS MAIA CONSTRUTORA LTDA',
    '26.796.129/0001-41;RCR ENGENHARIA E GERENCIAMENTO LTDA',
    '26.871.958/0001-41;D&B CONSULTORIA LTDA',
    '26.950.919/0001-30;IZABEL MELO DE LIMA ACADEMIA',
    '27.347.247/0001-35;VIGOR CONSULTORIA E SERVICOS LTDA',
    '27.709.935/0001-06;AWDRY MARCIO DA SILVA',
    '27.728.176/0001-10;REFERENCIA FACTORING SOCIEDADE DE FOMENTO COMERCIAL LTDA',
    '27.820.582/0001-09;JOSE ANTERO VIEIRA FILHO',
    '27.907.882/0001-20;INFINIT ENGENHARIA E PROJETOS LTDA',
    '28.462.750/0001-02;GR3 MAESTRIA EM GINASTICA LTDA',
    '28.717.348/0001-13;SANDRO AZEVEDO SERVICOS LTDA',
    '29.410.072/0001-99;COMERCIO DE GASES E EQUIPAMENTOS LTDA',
    '29.413.756/0001-44;VENETO LOCADORA DE MAQUINAS E EQUIPAMENTOS LTDA',
    '29.652.788/0001-00;OREN CORRETORA DE SEGUROS LTDA',
    '30.017.694/0001-30;BRUNO NEVES MATHEUS DUTRA - CONSULTORIA IMOBILIARIA',
    '30.492.473/0001-14;MARTON ANTONIO DA SILVA',
    '30.732.910/0001-20;LUSOBRAS INCORPORACAO E SERVICOS DE ENGENHARIA LTDA',
    '31.249.591/0001-69;JVP BAR E RESTAURANTE LTDA',
    '31.323.817/0001-24;RS ENGENHARIA E SERVICOS LTDA',
    '31.399.696/0001-02;31.399.696 JOELMIR DE OLIVEIRA',
    '31.946.781/0001-35;GLEBESON SERAFIM DA SILVA 04267481407',
    '31.982.478/0001-98;EDLEUSA MIRANDA PEREIRA SOCIEDADE INDIVIDUAL DE ADVOCACIA',
    '32.084.687/0001-87;SOMATEC DESENVOLVIMENTO DE OBRAS LTDA',
    '32.309.830/0001-91;JU FEITOZA MKT DIGITAL LTDA',
    '32.941.058/0001-26;FABRICIO DA SILVA',
    '33.072.274/0001-45;JRM & FAM REPRESENTACOES COMERCIAIS DE BRINQUEDOS E ARTIGOS LTDA',
    '33.546.098/0001-36;DIESEL SERVICOS DE MANUTENCAO E REPARACAO MECANICA LTDA',
    '33.683.321/0001-97;D FIBRA AMBIENTAL ,FABRICACAO, INSTALACAO E CONSTRUCAO DE OBRAS LTDA',
    '33.689.471/0001-08;FLY LOCADORA DE VEICULOS LTDA',
    '33.807.491/0001-36;JE ENGENHARIA EMPREENDIMENTOS VITORIA V, VI E VII SCP',
    '34.017.942/0001-02;MPL REPRESENTACOES LTDA',
    '35.211.448/0001-39;MM DIESEL SERVICOS DE ELETRONICA E COMERCIO DE PECAS LTDA',
    '35.229.495/0001-00;ROSANGELA DA SILVA LIMA COMERCIO DE PECAS E SERVICOS DE MOTOS',
    '35.327.709/0001-80;CONDOMINIO DO EDIFICIO CHATEAU LYON',
    '35.439.014/0001-90;35.439.014 RAFAELLY DE ARAUJO JUVENAL',
    '35.471.841/0001-61;DEBORAH S T SANTIAGO',
    '35.495.169/0001-44;IMPULSO COMERCIAL EDUCACAO CORPORATIVA E CONSULTORIA LTDA',
    '38.005.389/0001-30;NORDESTE LOCADORA DE VEICULO LTDA',
    '38.184.450/0001-54;SINGULAR ENGENHARIA E CONSTRUCAO LTDA',
    '38.252.962/0001-00;TAVARES MARKETING GROUP LTDA',
    '40.723.311/0001-01;SOLUTECH - SUPORTE EM SERVICOS DE INFORMATICA LTDA',
    '41.041.901/0001-09;GERTROX COMERCIO DE MAQUINAS E FERRAMENTAS LTDA',
    '41.115.457/0001-29;GABRIEL C. DA SILVA COMERCIO DE BOMBAS E SOLUCOES HIDRAULICAS LTDA',
    '41.175.771/0001-05;MARIANNA SAMPAIO SERPA ANDRADE - LAUDOS ODONTOLOGICOS',
    '41.233.081/0001-57;GILDO ANSELMO DE OLIVEIRA',
    '41.326.049/0001-16;GLL CONSTRUCOES E SERVICOS DE REFORMAS LTDA',
    '41.405.818/0001-71;MARCIA BARBOSA SERVICOS ADMINISTRATIVOS LTDA',
    '42.377.207/0001-20;WE MANUTENCAO E REPRESENTACAO LTDA',
    '42.887.533/0001-87;ROSSI ENGENHARIA ELETRICA LTDA',
    '42.919.913/0001-56;HANGAR DO DRONE, ASSISTENCIA TECNICA, VENDAS E TREINAMENTOS LTDA',
    '43.039.005/0001-30;SANTINI E MENDES LTDA',
    '43.176.206/0001-80;PE DUTRA CONSULTORIA EMPRESARIAL LTDA',
    '43.533.088/0001-10;OLIVEIRA PRINCIPE & TAVARES ADVOCACIA',
    '44.132.869/0001-65;FARMACIA PESSOA LTDA',
    '44.132.869/0002-46;FARMACIA PESSOA LTDA PE',
    '44.232.720/0001-58;MORGANA TOSCANO GOMES - SERVICOS',
    '44.480.096/0001-08;DBG EMPREENDIMENTOS DE LAZER LTDA',
    '44.669.923/0001-06;LETICIA SIQUEIRA CAVALCANTE & CIA LTDA',
    '45.146.708/0001-93;GSSA ENGENHARIA & CONSULTORIA LTDA',
    '45.201.851/0001-30;MOACY SANTOS FERREIRA - GESTAO E SERVICOS DE ENGENHARIA',
    '45.315.376/0001-23;ANNA CANAS EDUCACIONAL LTDA',
    '46.254.688/0001-37;JAIR EUCLIDES DE OLIVEIRA JUNIOR - JR DIESEL',
    '46.806.564/0001-17;SUNSET RESIDENCE FRANCES SPE LTDA',
    '46.806.564/0002-06;SUNSET RESIDENCE FRANCES SPE LTDA AL',
    '46.807.957/0001-45;46.807.957 NATHALIA LOPES WANDERLEY E SILVA',
    '46.855.199/0001-30;I S ASSESSORIA LTDA',
    '47.257.925/0001-86;BMAF TECNOLOGIA LTDA',
    '47.377.778/0001-88;FERNANDO ANTONIO TAVARES DE LIMA - EDUCACIONAL LTDA',
    '47.377.778/0002-69;FERNANDO ANTONIO TAVARES DE LIMA - EDUCACIONAL LTDA PE',
    '47.377.778/0003-40;FERNANDO ANTONIO TAVARES DE LIMA - EDUCACIONAL LTDA PE',
    '47.377.778/0004-20;FERNANDO ANTONIO TAVARES DE LIMA - EDUCACIONAL LTDA PE',
    '47.377.778/0005-01;FERNANDO ANTONIO TAVARES DE LIMA - EDUCACIONAL LTDA PE',
    '47.377.778/0006-92;FERNANDO ANTONIO TAVARES DE LIMA - EDUCACIONAL LTDA PE',
    '47.377.778/0007-73;FERNANDO ANTONIO TAVARES DE LIMA - EDUCACIONAL LTDA PE',
    '47.505.140/0001-85;BRUNO JOSE MOREIRA BRAGA 84668121487',
    '47.828.976/0001-10;G&Z GASES ESPECIAIS COM. E TRANSP. LTDA',
    '47.913.830/0001-73;MERELUANA ALINE BARROS DA SILVA 09405655442',
    '48.000.353/0001-18;G H TAVEIRA CONSULTORIA LTDA',
    '48.475.543/0001-91;CASA DI GRANO DISTRIBUIDORA DE FARINHAS LTDA',
    '48.893.270/0001-03;EVL REPRESENTACOES LTDA',
    '49.401.644/0001-80;CARBOPLUS SERVICOS DE ESCRITORIO LTDA',
    '49.451.414/0001-26;U. E. ENGENHARIA E CONSTRUCAO LTDA',
    '49.585.956/0001-91;JOSE DEIVSON DO NASCIMENTO - SERVICOS DE MANUTENCAO',
    '50.199.704/0001-03;TECNOCOM ENGENHARIA LTDA SCP',
    '50.469.019/0001-50;ONSITE SOLUTION PROVIDER LTDA',
    '51.314.754/0001-57;WINE 48 LTDA',
    '51.339.135/0001-17;UBIRACY DO AMARAL DIAGNOSTICO EM ANATOMIA PATOLOGICA LTDA',
    '51.406.327/0001-07;NOVA MARCA PORTAS E ESQUADRIAS LTDA',
    '51.435.924/0001-51;51.435.924 ANNE GLAYCE MORAIS DA SILVA NASCIMENTO',
    '51.745.220/0001-85;MJFA SERVICOS VETERINARIOS LTDA',
    '52.328.377/0001-78;EXITO SERVICOS ADMINISTRATIVOS LTDA',
    '52.368.325/0001-25;COSTA II RESTAURANTE LTDA',
    '52.437.943/0001-80;DOGSHIP PET TECH SERVICOS LTDA',
    '52.440.780/0001-94;JERIMOON COMERCIO DE ARTIGOS E ACESSORIOS LTDA',
    '52.967.691/0001-09;52.967.691 RUAN HENRIQUE GOMES DE ALMEIDA',
    '53.007.769/0001-06;RESI ENGENHARIA LTDA',
    '53.053.305/0001-28;LUCAS CARVALHO MACHADO - SOCIEDADE INDIVIDUAL DE ADVOCACIA',
    '54.169.607/0001-29;SPEEDO LOCADORA DE VEICULOS LTDA',
    '54.330.770/0001-21;54.330.770 EVA DE OLIVEIRA SOBRAL BRAGA',
    '54.390.136/0001-84;J & S SOLUCOES EM TECNOLOGIA LTDA',
    '54.468.850/0001-48;54.468.850 CAROLINA PEPE DE CARVALHO',
    '54.673.309/0001-71;MIXSANTINI INDUSTRIA E COMERCIO LTDA',
    '54.708.742/0001-03;EDUARDO MARTINS SOCIEDADE INDIVIDUAL DE ADVOCACIA',
    '55.129.749/0001-25;SANA INSTALACOES E SERVICOS LTDA',
    '55.335.929/0001-63;FAST SOLUTIONS COMERCIO E SERVICOS LTDA',
    '55.968.276/0001-50;SINGULAR ENGENHARIA LTDA.',
    '56.414.611/0001-30;BLESSED STORE COMERCIO LTDA',
    '56.414.611/0002-11;BLESSED STORE COMERCIO LTDA PE',
    '56.414.611/0003-00;BLESSED STORE COMERCIO LTDA AL',
    '57.371.792/0001-28;DREAM TOURS AGENCIA DE TURISMO E SERVICOS LTDA',
    '57.536.996/0001-71;EVOLTEC ELETRONICA LTDA',
    '57.739.030/0001-31;BERG RABELO PRODUCOES LTDA',
    '57.766.383/0001-20;THIAGO CYSNEIROS SOCIEDADE INDIVIDUAL DE ADVOCACIA',
    '58.076.370/0001-92;D FIBRA CONSTRUCOES E SERVICOS LTDA',
    '58.103.660/0001-88;JNS CONSTRUCOES E SERVICOS LTDA',
    '58.278.519/0001-16;MAAS PATRIMONIAL LTDA',
    '58.524.268/0001-02;58.524.268 SAMUEL DA SILVA OLIVEIRA',
    '58.779.803/0001-76;58.779.803 THIAGO ABNER LESSA SANTIAGO SILVA',
    '59.131.776/0001-93;CARLOS FELIPE LIMA DA SILVA - PE PISCINA AGUAZUL',
    '59.155.514/0001-69;KEKA PATRIMONIAL LTDA',
    '59.218.381/0001-22;PRESENTEAR CARTOES E PRESENTES LTDA',
    '59.391.808/0001-90;TOSCANO SERVICOS DE APOIO A EMPRESAS LTDA',
    '60.588.187/0001-18;PRISCILLA OLIVEIRA DE CARVALHO - SOCIEDADE INDIVIDUAL DE ADVOCACIA',
    '60.883.613/0001-46;SANTANA PROJETOS E ENGENHARIA LTDA',
    '62.187.605/0001-90;HSX SOLUCOES EMPRESARIAIS LTDA',
    '62.357.639/0001-86;ECOASSESSORIA E ENGENHARIA LTDA',
    '62.475.980/0001-36;INSTITUTO EDUCACIONAL GOUVEIA LTDA',
    '62.528.743/0001-96;INCORPORADORA GOUVEIA LTDA',
    '62.862.944/0001-25;PV3 PARTICIPACOES LTDA',
    '63.274.746/0001-03;63.274.746 JOAO DIOGO FEITOSA',
    '63.986.506/0001-31;EA CONSULTORIA E TREINAMENTOS LTDA',
    '64.145.906/0001-87;SUNWAVE RESIDENCE LTDA',
    '64.444.591/0001-79;MAVIDA SEGUROS LTDA',
    '64.713.114/0001-61;PROLOOP ENGENHARIA E PROJETOS DE AUTOMACAO LTDA',
    '64.778.451/0001-37;ADRESOURCES MODELAGEM DE RECURSOS MINERAIS LTDA',
    '65.497.199/0001-50;GRANSAFRA EMBALAGENS LTDA',
    '69.904.274/0001-01;CONDOMINIO DO EDIFICIO MONTE CARMELO',
  ];
  // A lista acima e a PASTA_RAIZ abaixo são só o PADRÃO: a janela da extensão (clique no ícone) grava a pasta e a
  // lista escolhidas em chrome.storage.local['situacao_fiscal_config'], e essa configuração vale ao abrir a página.
  const paraFila = (lista) => lista.map((linha) => {
    const [documento, ...nome] = String(linha).split(';');
    return { documento: documento.trim(), nome: nome.join(';').trim() };
  }).filter((f) => f.documento);
  let FILA = paraFila(DOCUMENTOS);
  // Pastas de saída (relativas à pasta de Downloads do Chrome): Situacao_Fiscal_Assecon/<NOME DA EMPRESA>/...
  // O nome vem da lista acima (depois do ";"); sem nome na lista, usa o de Dados Cadastrais; sem nenhum, o CNPJ.
  // Cada pasta raiz tem o PRÓPRIO registro de progresso: trocar a raiz recomeça a lista do zero.
  // 1ª rodada (certificado da Assecon, 207/208): 'Situacao_Fiscal_Assecon' — resultados movidos pelo usuário para
  // Situacao_Fiscal_Assecon/ASSECON HUB CONTABILIDADE. 2ª rodada (certificado da Priscilla), lista inteira de novo:
  let PASTA_RAIZ = 'Situacao_Fiscal_Assecon/PRISCILLA_ASSECON';
  const SUBPASTA_RELATORIO = 'situação fiscal';
  const TIMEOUT_INICIO_DOWNLOAD_MS = 30000; // depois de "Baixar Relatório", tempo para o download começar
  const TIMEOUT_DOWNLOAD_MS = 120000;       // tempo para o download do relatório terminar
  // Falhas temporárias do portal ("Não foi possível concluir a ação… tente novamente dentro de alguns minutos")
  // ou página carregando sem progresso: espera, recarrega (F5) e retoma o MESMO CNPJ.
  const TIMEOUT_CARREGANDO_MS = 60000;      // carregamento sem progresso por mais que isso = falha temporária
  const ESPERA_FALHA_PORTAL_MS = 120000;    // "dentro de alguns minutos" (sem número) = esperar isto antes do F5
  const ESPERA_CARREGAMENTO_MS = 15000;     // carregamento travado / sem confirmação = esperar isto antes do F5
  const MAX_RECARGAS_POR_CNPJ = 3;          // depois disso, o CNPJ fica PENDENTE e a fila segue
  // "Estamos processando sua solicitação. Tente novamente em instantes." — o portal ainda está montando o resultado:
  // acompanha a página; se demorar mais que isto, o CNPJ fica PENDENTE e a extensão segue para o próximo (sem F5).
  const ESPERA_PROCESSANDO_NA_PAGINA_MS = 60000;
  const RODADAS_PENDENTES = 1; // no fim da lista, tenta os CNPJs pendentes de novo esta quantidade de vezes
  // Se o portal recarregar a página depois de "Representar" e ela voltar com a empresa ANTERIOR, a representação é
  // repetida para o mesmo CNPJ até este número de tentativas; depois, o CNPJ fica PENDENTE e a fila segue.
  const MAX_TENTATIVAS_REPRESENTAR = 3;
  // Falha ao baixar certidão/relatório — aviso do portal ("Não foi possível emitir a certidão. Tente novamente daqui
  // alguns minutos", código 043) ou download que não começa em TIMEOUT_INICIO_DOWNLOAD_MS: salva o estado, recarrega
  // (F5) sozinha e tenta de novo SÓ o documento que falta. 1ª recarga após ESPERA_DOWNLOAD_1A_MS; se persistir,
  // espera ESPERA_FALHA_PORTAL_MS ("alguns minutos") entre as tentativas; esgotado o limite, o CNPJ fica PENDENTE.
  const MAX_RECARGAS_DOWNLOAD = 4;
  const ESPERA_DOWNLOAD_1A_MS = 15000;
  const INTERVALO_ENTRE_EMPRESAS_MS = 5000; // mínimo entre concluir uma empresa e abrir o perfil para a próxima
  const PERFIL = 'Procurador';          // opção da lista "Digite um perfil de representação"
  const TIMEOUT_RESPOSTA_MS = 25000;    // depois de "Representar", tempo esperando a resposta do portal
  const TIMEOUT_LISTA_MS = 6000;        // tempo para a lista de perfis abrir após o clique
  // Só roda nesta página (o trecho depois de "#" é conferido aqui, porque o manifest não enxerga o "#").
  const URL_ALVO = /^https:\/\/servicos\.receitafederal\.gov\.br\/servico\/pendencias\/?#\/analise-pendencias(?:[/?].*)?$/;
  const TIMEOUT_PAGINA_MS = 30000;     // tempo para a página carregar e mostrar título e blocos
  const TIMEOUT_ELEMENTO_MS = 15000;   // tempo máximo esperando cada elemento
  const ESPERA_AVISO_COOKIES_MS = 2500; // com a página pronta, chance de o aviso de cookies aparecer (pode não vir)
  const QUIETUDE_MS = 500;             // "tela estável" = este tempo sem mudanças no DOM
  const LENTIDAO_MOUSE = 1.0;          // maior = seta mais devagar (0.5 = dobro da velocidade, 2 = metade)
  const LENTIDAO_DIGITACAO = 1.0;      // maior = digitação mais devagar (base: ~0,35 s por dígito)
  const INTERVALO_URL_MS = 400;        // vigia da URL (cobre history.pushState do portal)
  // ==========================================================================

  const PREFIXO = '[Situacao_Fiscal]';
  const ID_SETA = 'situacao-fiscal-seta';
  const ID_AVISO = 'situacao-fiscal-aviso';
  const MSG_PAINEL = 'Etapa concluída — painel de perfil aberto';
  const MSG_SEM_CONFIRMACAO = 'Representação solicitada, sem confirmação do portal';
  const CHAVE_PENDENTE = 'situacao_fiscal_representacao'; // sessionStorage: "Representar" já clicado (evita repetir após recarga)
  const VALIDADE_PENDENTE_MS = 300000;
  const soDigitos = (s) => String(s || '').replace(/\D/g, '');
  const RE_DOC = /\d{2}\.?\d{3}\.?\d{3}\/?\d{4}-?\d{2}|[\d*•x]{3}\.[\d*•x]{3}\.[\d*•x]{3}-[\d*•x]{2}/i; // CNPJ ou CPF (também mascarado)

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  // Próximo quadro; com a aba em segundo plano o requestAnimationFrame pausa, então um timer garante o avanço.
  const quadro = () => new Promise((r) => { const t = setTimeout(r, 40); requestAnimationFrame(() => { clearTimeout(t); r(); }); });
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  const rand = (a, b) => a + Math.random() * (b - a);
  const norm = (s) => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/\s+/g, ' ').trim().toLowerCase();
  const log = (...a) => console.log(PREFIXO, ...a);

  // ------------------------------- controle da execução -------------------------------
  let execucao = null;          // { cancelada } enquanto o fluxo roda
  let estavaNoAlvo = false;     // a aba está na página alvo (para detectar a chegada)
  let concluidaNestaVisita = false; // evita repetir o fluxo sem sair e voltar à página

  function conferir() {
    if (!execucao || execucao.cancelada) {
      const e = new Error('execução cancelada');
      e.cancelada = true;
      throw e;
    }
  }

  class ErroEtapa extends Error {
    constructor(etapa, elemento, segundos) {
      super(`Etapa ${etapa}: o elemento esperado "${elemento}" não apareceu em ${segundos} s. Execução interrompida.`);
      this.etapa = etapa;
      this.elemento = elemento;
    }
  }

  // ---- confirmação "Encerrar representação" ----
  // Se o portal perguntar "Você tem certeza de que deseja encerrar a representação?", a resposta é SEMPRE
  // "Cancelar": a extensão nunca encerra representações; continua o processo de onde estava.
  function acharDialogoEncerrar() {
    const pergunta = todos().find((e) => e.children.length === 0 && visivel(e) &&
      /deseja encerrar a representacao/.test(norm(e.textContent)));
    if (!pergunta) return null;
    for (let c = pai(pergunta), i = 0; c && c !== document.body && i < 8; c = pai(c), i++) {
      const cancelar = todos(c).find((b) => b.matches('button,[role=button],a') && textoDoBotaoSimples(b) === 'cancelar' && visivel(b));
      if (cancelar) return { dialogo: c, cancelar };
    }
    return null;
  }
  const textoDoBotaoSimples = (e) => norm(e.textContent).replace(/[^a-z0-9 ]/g, '').trim();
  let cancelandoDialogo = false;
  async function cancelarDialogoEncerrar() {
    if (cancelandoDialogo) return false;
    const d = acharDialogoEncerrar();
    if (!d) return false;
    cancelandoDialogo = true;
    try {
      log('confirmação "Encerrar representação" na tela — clicando em Cancelar');
      criarSeta();
      await clicarEm(() => { const x = acharDialogoEncerrar(); return x ? x.cancelar : null; }, 'diálogo "Encerrar representação"', 'botão "Cancelar"');
      const ate = Date.now() + 10000;
      while (acharDialogoEncerrar() && Date.now() < ate) await sleep(200);
      if (acharDialogoEncerrar()) throw erroEtapa('A confirmação "Encerrar representação" não fechou após "Cancelar".');
      await esperarEstabilidade(1200);
      log('confirmação cancelada; a representação continua ativa');
      return true;
    } finally {
      cancelandoDialogo = false;
    }
  }

  // ---- falha temporária do portal ----
  const RE_FALHA_TEMPORARIA = /nao foi possivel concluir a acao|nao foi possivel emitir|tente novamente (dentro de alguns|em alguns|daqui (a )?alguns|daqui a pouco|mais tarde)|servico (temporariamente )?indisponivel|erro interno no servidor/;
  // Mensagem de processamento; a data/hora que vem depois dela é ignorada (o teste é só pelo texto).
  const RE_PROCESSANDO = /estamos processando sua solicitacao|tente novamente em instantes/;
  // Linhas de texto visíveis da página (o aviso e a seta da extensão ficam fora do <body>), lidas no máximo a cada 800 ms.
  let linhasCache = { t: 0, linhas: [] };
  function linhasDaPagina() {
    if (Date.now() - linhasCache.t < 800) return linhasCache.linhas;
    const t = document.body ? document.body.innerText || '' : '';
    linhasCache = { t: Date.now(), linhas: t.split('\n').map((s) => s.trim()).filter(Boolean) };
    return linhasCache.linhas;
  }
  // Texto visível da página com a mensagem de falha, ou null.
  function falhaTemporaria() {
    return linhasDaPagina().find((l) => RE_FALHA_TEMPORARIA.test(norm(l)) && !RE_PROCESSANDO.test(norm(l))) || null;
  }
  // "Estamos processando sua solicitação…" visível, ou null.
  function mensagemProcessando() {
    return linhasDaPagina().find((l) => RE_PROCESSANDO.test(norm(l))) || null;
  }
  // Tela "Minhas Dívidas e Pendências" com a mensagem de processamento no lugar dos blocos.
  function paginaEmProcessamento() {
    const titulo = acharTextos('Minhas Dívidas e Pendências')[0];
    const msg = titulo && mensagemProcessando();
    return msg ? { titulo, processando: true, mensagem: msg } : null;
  }
  // tipo: 'portal' (mensagem de falha), 'carregamento' (travou / sem confirmação) ou 'processando'
  const erroTemporario = (texto, tipo) => Object.assign(new Error(texto), { temporario: true, tipoFalha: tipo });

  // Refaz a busca a cada ciclo: o elemento pode surgir, sumir ou ser trocado enquanto o portal (Angular) desenha.
  // Se o portal mostrar a falha temporária, ou ficar carregando além de TIMEOUT_CARREGANDO_MS, vira recuperação.
  async function esperar(buscar, etapa, elemento, timeout = TIMEOUT_ELEMENTO_MS) {
    let inicio = Date.now();
    let processandoDesde = 0, ultimoAvisoProc = 0;
    for (;;) {
      conferir();
      if (await cancelarDialogoEncerrar()) continue; // "Encerrar representação?" → Cancelar, e segue esperando
      const falha = falhaTemporaria();
      if (falha) throw erroTemporario(falha, 'portal');
      const achado = buscar();
      if (achado) return achado;
      // Portal "processando": não conta o tempo limite normal; acompanha a página até ESPERA_PROCESSANDO_NA_PAGINA_MS.
      const proc = mensagemProcessando();
      if (proc) {
        if (!processandoDesde) {
          processandoDesde = Date.now();
          log(`etapa ${etapa}: o portal está processando a solicitação ("${proc}"); acompanhando a página`);
        }
        const passouProc = Date.now() - processandoDesde;
        if (passouProc >= ESPERA_PROCESSANDO_NA_PAGINA_MS) {
          throw erroTemporario(`o portal continuou processando por ${Math.round(passouProc / 1000)} s sem mostrar ${elemento}: "${proc}"`, 'processando');
        }
        if (Date.now() - ultimoAvisoProc > 5000) {
          ultimoAvisoProc = Date.now();
          mostrarAviso(`Etapa ${etapa}: portal em processamento — acompanhando a página ` +
            `(${Math.round(passouProc / 1000)}/${Math.round(ESPERA_PROCESSANDO_NA_PAGINA_MS / 1000)} s)…`);
        }
        await sleep(500);
        continue;
      }
      if (processandoDesde) { // a mensagem sumiu: o tempo limite normal recomeça a contar daqui
        log(`etapa ${etapa}: o portal terminou de processar após ${Math.round((Date.now() - processandoDesde) / 1000)} s`);
        processandoDesde = 0;
        inicio = Date.now();
      }
      const passou = Date.now() - inicio;
      if (passou >= timeout) {
        const carregando = typeof carregandoVisiveis === 'function' && carregandoVisiveis().length > 0;
        if (!carregando) throw new ErroEtapa(etapa, elemento, Math.round(timeout / 1000));
        if (passou >= Math.max(timeout, TIMEOUT_CARREGANDO_MS)) {
          throw erroTemporario(`a página ficou carregando por mais de ${Math.round(passou / 1000)} s sem mostrar ${elemento} (etapa ${etapa})`, 'carregamento');
        }
      }
      await sleep(200);
    }
  }

  // Espera o DOM ficar QUIETUDE_MS sem mudanças (banner sumindo, painel deslizando, conteúdo chegando).
  function esperarEstabilidade(maximo = 6000) {
    return new Promise((resolve) => {
      let timer = null;
      const fim = () => { obs.disconnect(); clearTimeout(limite); clearTimeout(timer); resolve(); };
      const obs = new MutationObserver(() => { clearTimeout(timer); timer = setTimeout(fim, QUIETUDE_MS); });
      obs.observe(document.documentElement, { subtree: true, childList: true, attributes: true, characterData: true });
      timer = setTimeout(fim, QUIETUDE_MS);
      const limite = setTimeout(fim, maximo);
    }).then(() => sleep(150));
  }

  // ------------------------------- leitura do DOM -------------------------------
  // Todos os elementos da página, inclusive dentro de shadow DOM aberto (componentes do padrão gov.br).
  function todos(raiz = document) {
    const lista = [];
    const pilha = [raiz];
    while (pilha.length) {
      const r = pilha.pop();
      for (const e of r.querySelectorAll('*')) {
        if (e.id === ID_SETA || e.id === ID_AVISO) continue;
        lista.push(e);
        if (e.shadowRoot) pilha.push(e.shadowRoot);
      }
    }
    return lista;
  }

  function pai(e) {
    if (e.parentElement) return e.parentElement;
    const raiz = e.getRootNode && e.getRootNode();
    return raiz && raiz.host ? raiz.host : null;
  }

  function contem(a, b) {
    for (let e = b; e; e = pai(e)) if (e === a) return true;
    return false;
  }

  function visivel(el) {
    if (!el || !el.isConnected) return false;
    const r = el.getBoundingClientRect();
    if (r.width < 1 || r.height < 1) return false;
    if (typeof el.checkVisibility === 'function') {
      return el.checkVisibility({ opacityProperty: true, visibilityProperty: true });
    }
    const s = getComputedStyle(el);
    return s.display !== 'none' && s.visibility !== 'hidden' && Number(s.opacity) > 0;
  }

  // Elementos visíveis cujo texto (sem acento, sem diferença de maiúsculas) é exatamente `texto`.
  // Fica só com o mais interno (o <span> dentro do <h2>, por exemplo, não os dois).
  function acharTextos(texto, raiz = document) {
    const alvo = norm(texto);
    const achados = todos(raiz).filter((e) => !/^(SCRIPT|STYLE|NOSCRIPT|TEMPLATE)$/.test(e.tagName) &&
      norm(e.textContent) === alvo && visivel(e));
    return achados.filter((e) => !achados.some((o) => o !== e && contem(e, o)));
  }

  const CLICAVEL = 'button,[role=button],a[href],input[type=button],input[type=submit],[tabindex]:not([tabindex="-1"])';
  function clicavelDe(el) {
    for (let e = el; e && e !== document.body; e = pai(e)) if (e.matches && e.matches(CLICAVEL)) return e;
    return el;
  }

  function classe(e) { return String((e.getAttribute && e.getAttribute('class')) || ''); }

  // ------------------------------- etapa 1: reconhecer a página -------------------------------
  function reconhecerPagina() {
    // O título pode repetir no breadcrumb ("Minhas Dividas e Pendências"): fica com o de letra maior.
    const titulos = acharTextos('Minhas Dívidas e Pendências');
    if (!titulos.length) return null;
    const titulo = titulos.reduce((m, e) => (parseFloat(getComputedStyle(e).fontSize) > parseFloat(getComputedStyle(m).fontSize) ? e : m));
    const dados = acharTextos('Dados Cadastrais')[0];
    const resultado = acharTextos('Resultado da Análise')[0];
    if (!dados || !resultado) return null;
    return { titulo, dados, resultado };
  }

  // O cartão (bloco) de um cabeçalho como "Dados Cadastrais": o primeiro ancestral bem maior que o título.
  function blocoDe(cab) {
    for (let e = pai(cab); e && e !== document.body; e = pai(e)) {
      const r = e.getBoundingClientRect();
      if (r.height > cab.getBoundingClientRect().height * 2.5 && norm(e.textContent).length > norm(cab.textContent).length + 10) return e;
    }
    return pai(cab);
  }

  // Lê a estrutura da página e registra no console (funciona com qualquer empresa, CNPJ ou resultado).
  function registrarEstrutura(p) {
    const texto = (el) => (el ? el.innerText || el.textContent || '' : '').replace(/\n{2,}/g, '\n').trim();
    const blocoDados = blocoDe(p.dados);
    const blocoResultado = blocoDe(p.resultado);
    const cnpj = (texto(blocoDados).match(/\d{2}\.\d{3}\.\d{3}\/\d{4}-\d{2}/) || [''])[0];
    const estrutura = {
      url: location.href,
      titulo: texto(p.titulo),
      cabecalhos: todos().filter((e) => /^H[1-6]$/.test(e.tagName) && visivel(e)).map((e) => `${e.tagName}: ${texto(e)}`),
      botoes: todos().filter((e) => e.matches('button,[role=button],a[href]') && visivel(e))
        .map((e) => texto(e) || e.getAttribute('aria-label') || e.getAttribute('title') || `(${e.tagName.toLowerCase()} sem texto)`),
      campos: todos().filter((e) => e.matches('input,select,textarea') && visivel(e))
        .map((e) => e.getAttribute('placeholder') || e.name || e.id || e.type),
      dadosCadastrais: texto(blocoDados),
      resultadoAnalise: texto(blocoResultado),
      cnpj,
    };
    console.groupCollapsed(PREFIXO, 'Página reconhecida: Minhas Dívidas e Pendências', cnpj ? `(CNPJ ${cnpj})` : '');
    console.log(estrutura);
    console.groupEnd();
    return estrutura;
  }

  // ------------------------------- etapa 2: cookies -------------------------------
  function acharAvisoCookies() {
    const frases = todos().filter((e) => /utilizamos cookies|uso de cookies|politica de cookies|declaracao de cookies/.test(norm(e.textContent)) && visivel(e));
    // do mais interno para fora: o primeiro ancestral que também contém o botão "Aceitar"
    frases.sort((a, b) => norm(a.textContent).length - norm(b.textContent).length);
    for (const f of frases) {
      for (let c = f; c && c !== document.body && c !== document.documentElement; c = pai(c)) {
        const botao = acharTextos('Aceitar', c).map(clicavelDe).find(visivel);
        if (botao) {
          const r = c.getBoundingClientRect();
          // aviso no rodapé: termina perto da borda inferior da janela
          if (r.bottom > innerHeight * 0.6) return { aviso: c, botao };
          break;
        }
      }
    }
    return null;
  }

  // ------------------------------- etapa 3/4: perfil e painel -------------------------------
  function acharPainel() {
    for (const rr of acharTextos('Representações Recentes')) {
      if (rr.getBoundingClientRect().left < innerWidth * 0.4) continue; // painel é o da direita
      for (let c = pai(rr); c && c !== document.body; c = pai(c)) {
        const rep = acharTextos('Representar', c).find((e) => !contem(e, rr));
        if (rep && visivel(c)) {
          const r = c.getBoundingClientRect();
          // na tela (um painel fechado pode só deslizar para fora da janela)
          if (r.left >= innerWidth * 0.3 && r.left < innerWidth - 40) return { painel: c, representar: rep, recentes: rr };
        }
      }
    }
    return null;
  }

  // O controle com avatar + identificação (nome/CNPJ) + seta para baixo, no canto superior direito do cabeçalho.
  function acharControlePerfil() {
    const W = innerWidth, H = innerHeight;
    const noCanto = (r) => r.top < Math.max(260, H * 0.35) && r.left + r.width / 2 > W * 0.5 && r.width < W * 0.5;
    let melhor = null, pontos = 0;
    for (const e of todos()) {
      if (!e.matches(CLICAVEL + ',[aria-haspopup],[aria-expanded]') || !visivel(e)) continue;
      const r = e.getBoundingClientRect();
      if (!noCanto(r)) continue;
      let p = 0;
      if (RE_DOC.test(e.textContent)) p += 4;
      if (/avatar/i.test(classe(e)) || e.querySelector('img,[class*=avatar i]')) p += 3;
      if (e.querySelector('[class*=caret i],[class*=chevron i],[class*=angle-down i],[class*=arrow-down i],[class*=dropdown i],svg,i[class*=fa]')) p += 1;
      if (e.hasAttribute('aria-haspopup') || e.hasAttribute('aria-expanded')) p += 1;
      if (r.width > 100) p += 1;
      if (p > pontos || (p === pontos && melhor && contem(e, melhor))) { melhor = e; pontos = p; }
    }
    if (melhor && pontos >= 5) return melhor;
    // Plano B: o texto do CNPJ/CPF no canto e, subindo, o maior contêiner "clicável" (cursor de mão) em volta dele.
    const doc = todos().filter((e) => e.children.length === 0 && RE_DOC.test(e.textContent) && visivel(e) && noCanto(e.getBoundingClientRect()))[0];
    if (!doc) return null;
    let alvo = null;
    for (let c = doc, i = 0; c && c !== document.body && i < 6; c = pai(c), i++) {
      const r = c.getBoundingClientRect();
      if (!noCanto(r)) break;
      if (getComputedStyle(c).cursor === 'pointer' || c.matches(CLICAVEL)) alvo = c;
    }
    return alvo;
  }

  // ------------------------------- aviso na tela -------------------------------
  let etapaAtual = ''; // última etapa anunciada (guardada antes de um F5 de recuperação)
  function mostrarAviso(texto, tipo = 'info') {
    const m = String(texto).match(/^Etapa (\d+)/);
    if (m) etapaAtual = `Etapa ${m[1]}`;
    let box = document.getElementById(ID_AVISO);
    if (!box) {
      box = document.createElement('div');
      box.id = ID_AVISO;
      document.documentElement.appendChild(box);
    }
    const cor = { info: '#1f4e79', ok: '#1e7b3a', erro: '#b03a2e' }[tipo] || '#1f4e79';
    box.style.cssText =
      'position:fixed!important;left:10px!important;bottom:10px!important;max-width:380px!important;' +
      'z-index:2147483646!important;padding:10px 14px!important;border-radius:6px!important;' +
      `background:${cor}!important;color:#fff!important;font:13px/1.4 Arial,sans-serif!important;` +
      'box-shadow:0 2px 10px rgba(0,0,0,.3)!important;pointer-events:none!important;white-space:pre-line!important;';
    box.textContent = `Situacao_Fiscal${placar ? `\n${placar}` : ''}\n${texto}`;
    // Só no console comum (nunca console.error): o Chrome copia todo console.error de extensão para o botão "Erros"
    // do card, e a contagem regressiva da recuperação (1 aviso por segundo) enchia essa lista. Avisos repetidos que
    // só mudam a contagem ("em 1:38…") são registrados uma vez.
    const chave = `${tipo}|${String(texto).replace(/\d+:\d{2}/g, '')}`;
    if (chave !== ultimoAvisoRegistrado) {
      ultimoAvisoRegistrado = chave;
      console.log(PREFIXO, tipo === 'erro' ? '[AVISO VERMELHO]' : '', texto);
    }
  }
  let ultimoAvisoRegistrado = '';

  // Placar da lista (topo do aviso): quantos CNPJs já foram analisados e quantos faltam.
  // Recalculado a cada leitura/gravação do progresso; "analisado" = concluído (inclusive erro de procuração).
  let placar = '';
  function atualizarPlacar(p) {
    if (!p) return;
    const total = FILA.length;
    let feitos = 0, pendentes = 0;
    for (const f of FILA) {
      const d = soDigitos(f.documento);
      if (concluidoValido((p.concluidos || {})[d])) feitos += 1;
      else if (p.pendentes && p.pendentes[d]) pendentes += 1;
    }
    const pct = total ? Math.floor((feitos / total) * 100) : 0;
    const cheio = Math.floor(pct / 5); // barra de 20 blocos; só fica cheia em 100%
    const novo = `Analisados: ${feitos} de ${total} (${pct}%) · Faltam: ${total - feitos}` +
      `${pendentes ? ` (${pendentes} pendente${pendentes > 1 ? 's' : ''})` : ''}\n` +
      `${'█'.repeat(cheio)}${'░'.repeat(20 - cheio)}`;
    if (novo !== placar) {
      placar = novo;
      log(`placar — analisados ${feitos}/${total}, faltam ${total - feitos}, pendentes ${pendentes}`);
    }
  }

  // ------------------------------- seta -------------------------------
  const cursor = { el: null, x: 0, y: 0 };
  const PONTA = { x: 3, y: 2 }; // ponta da seta dentro do desenho

  function criarSeta() {
    if (cursor.el && cursor.el.isConnected) return;
    const el = document.createElement('div');
    el.id = ID_SETA;
    el.style.cssText =
      'position:fixed!important;left:0!important;top:0!important;width:24px!important;height:28px!important;' +
      'z-index:2147483647!important;pointer-events:none!important;margin:0!important;padding:0!important;' +
      'transition:opacity .25s!important;opacity:0;will-change:transform;';
    el.innerHTML =
      '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="28" viewBox="0 0 24 28" style="display:block;overflow:visible">' +
      '<path d="M3 2 L3 20 L7.6 15.8 L10.8 22.8 L13.6 21.6 L10.5 14.8 L16.8 14.4 Z" ' +
      'fill="#111" stroke="#fff" stroke-width="1.4" stroke-linejoin="round"/></svg>';
    document.documentElement.appendChild(el);
    cursor.el = el;
    cursor.x = innerWidth * 0.5;
    cursor.y = innerHeight * 0.6;
    posicionar();
    requestAnimationFrame(() => { el.style.opacity = '1'; });
  }

  function posicionar() {
    cursor.el.style.transform = `translate(${cursor.x - PONTA.x}px, ${cursor.y - PONTA.y}px)`;
  }

  function pulso() {
    const anel = document.createElement('div');
    anel.style.cssText =
      `position:fixed!important;left:${cursor.x - 14}px!important;top:${cursor.y - 14}px!important;` +
      'width:28px!important;height:28px!important;border-radius:50%!important;' +
      'border:2px solid rgba(31,78,121,.85)!important;z-index:2147483647!important;pointer-events:none!important;';
    document.documentElement.appendChild(anel);
    anel.animate([{ transform: 'scale(.3)', opacity: 1 }, { transform: 'scale(1.5)', opacity: 0 }],
      { duration: 450, easing: 'ease-out' }).onfinish = () => anel.remove();
  }

  const suave = (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2); // acelera e desacelera

  // Movimento contínuo por uma curva leve (Bézier), com aceleração e desaceleração suaves.
  async function moverPara(x, y) {
    const x0 = cursor.x, y0 = cursor.y;
    const dx = x - x0, dy = y - y0;
    const dist = Math.hypot(dx, dy);
    if (dist < 2) return;
    const duracao = clamp(900 + dist * 1.7, 1100, 3400) * LENTIDAO_MOUSE;
    const arco = (Math.random() < 0.5 ? -1 : 1) * rand(0.06, 0.18) * dist;
    const nx = -dy / dist, ny = dx / dist;
    const c1 = { x: x0 + dx * 0.3 + nx * arco, y: y0 + dy * 0.3 + ny * arco };
    const c2 = { x: x0 + dx * 0.75 + nx * arco * 0.4, y: y0 + dy * 0.75 + ny * arco * 0.4 };
    const inicio = performance.now();
    for (;;) {
      conferir();
      const t = clamp((performance.now() - inicio) / duracao, 0, 1);
      const e = suave(t), u = 1 - e;
      cursor.x = u * u * u * x0 + 3 * u * u * e * c1.x + 3 * u * e * e * c2.x + e * e * e * x;
      cursor.y = u * u * u * y0 + 3 * u * u * e * c1.y + 3 * u * e * e * c2.y + e * e * e * y;
      posicionar();
      if (t >= 1) break;
      await quadro();
    }
    cursor.x = x; cursor.y = y;
    posicionar();
  }

  function centro(el) {
    const r = el.getBoundingClientRect(); // coordenadas da janela: valem para qualquer resolução e zoom
    return { x: r.left + r.width / 2, y: r.top + r.height / 2 };
  }

  function disparar(el, tipo) {
    const Ctor = tipo.startsWith('pointer') && typeof PointerEvent === 'function' ? PointerEvent : MouseEvent;
    el.dispatchEvent(new Ctor(tipo, {
      bubbles: true, cancelable: true, composed: true, view: window,
      clientX: cursor.x, clientY: cursor.y, button: 0,
      buttons: tipo === 'mousedown' || tipo === 'pointerdown' ? 1 : 0,
      pointerId: 1, pointerType: 'mouse', isPrimary: true, detail: tipo === 'click' ? 1 : 0,
    }));
  }

  function elementoNoPonto(x, y) {
    let el = document.elementFromPoint(x, y);
    while (el && el.shadowRoot) {
      const dentro = el.shadowRoot.elementFromPoint(x, y);
      if (!dentro || dentro === el) break;
      el = dentro;
    }
    return el;
  }

  // Leva a seta até o elemento (recalculando o destino se a tela mexer), pausa e clica UMA vez no elemento real.
  async function clicarEm(obterAlvo, etapa, descricao) {
    let el = obterAlvo();
    if (!el || !visivel(el)) throw new ErroEtapa(etapa, descricao, 0);
    const r = el.getBoundingClientRect();
    if (r.top < 0 || r.bottom > innerHeight || r.left < 0 || r.right > innerWidth) {
      el.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'nearest' });
      await sleep(700);
    }
    log(`movendo a seta até: ${descricao}`);
    for (let i = 0; i < 4; i++) {
      el = obterAlvo() || el;
      const c = centro(el);
      if (Math.hypot(c.x - cursor.x, c.y - cursor.y) < 4) break;
      await moverPara(c.x, c.y);
    }
    await sleep(rand(500, 800) * LENTIDAO_MOUSE); // breve pausa ao chegar, antes do clique
    conferir();
    el = obterAlvo() || el;
    if (!visivel(el)) throw new ErroEtapa(etapa, `${descricao} (sumiu antes do clique)`, 0);
    const sob = elementoNoPonto(cursor.x, cursor.y);
    const alvo = sob && (sob === el || contem(el, sob)) ? sob : el; // algo cobrindo? aciona o próprio elemento
    if (alvo === el && sob !== el) log(`outro elemento está sobre ${descricao}; acionando o próprio elemento`);
    log(`clicando em: ${descricao}`);
    pulso();
    disparar(alvo, 'pointerdown'); disparar(alvo, 'mousedown');
    const foco = [alvo, el].find((x) => x.matches && x.matches('input,textarea'));
    if (foco) foco.focus();
    await sleep(rand(70, 140));
    disparar(alvo, 'pointerup'); disparar(alvo, 'mouseup');
    disparar(alvo, 'click'); // um único click (sobe até o controle real do portal)
  }

  // ------------------------------- fluxo -------------------------------
  // ctx = dados DESTA execução: { documento, digitos, cnpjConfirmado }. Nada é guardado entre execuções.
  async function fluxo(ctx) {
    // 1. Reconhecer a página
    mostrarAviso('Etapa 1: aguardando a página Minhas Dívidas e Pendências carregar…');
    // A página vale também "em processamento" (título + "Estamos processando sua solicitação…"): o cabeçalho e o
    // perfil continuam lá, então dá para trocar de empresa sem esperar o resultado da anterior.
    const pagina = await esperar(() => reconhecerPagina() || paginaEmProcessamento(), '1 (reconhecer a página)',
      'título "Minhas Dívidas e Pendências" com os blocos "Dados Cadastrais" e "Resultado da Análise"', TIMEOUT_PAGINA_MS);
    await esperarEstabilidade();
    if (pagina.processando && !reconhecerPagina()) {
      log('página reconhecida em processamento ("Estamos processando sua solicitação"); seguindo para o perfil');
      mostrarAviso('Etapa 1: página reconhecida (portal em processamento).');
    } else {
      const estrutura = registrarEstrutura(reconhecerPagina() || pagina);
      mostrarAviso(`Etapa 1: página reconhecida${estrutura.cnpj ? ` (CNPJ ${estrutura.cnpj})` : ''}.`);
    }
    criarSeta();

    // 2. Cookies (o aviso pode não vir, ou já ter sido aceito)
    let cookies = acharAvisoCookies();
    if (!cookies) {
      const ate = Date.now() + ESPERA_AVISO_COOKIES_MS;
      while (!cookies && Date.now() < ate) { conferir(); await sleep(200); cookies = acharAvisoCookies(); }
    }
    if (cookies) {
      mostrarAviso('Etapa 2: aceitando os cookies…');
      await clicarEm(() => { const c = acharAvisoCookies(); return c ? c.botao : null; }, '2 (aceitar cookies)', 'botão "Aceitar" do aviso de cookies');
      await esperar(() => !acharAvisoCookies(), '2 (aceitar cookies)', 'aviso de cookies desaparecer após "Aceitar"');
      await esperarEstabilidade();
      log('cookies aceitos; aviso fechado');
    } else {
      log('aviso de cookies não está visível (já aceito); seguindo para o perfil');
    }

    // 3. Abrir o perfil (se o painel já estiver aberto, só confirma)
    if (acharPainel()) {
      log('painel de perfil já está aberto');
    } else {
      mostrarAviso('Etapa 3: abrindo o perfil do usuário…');
      await esperar(acharControlePerfil, '3 (abrir perfil)', 'controle do perfil (avatar, identificação e seta) no canto superior direito');
      await clicarEm(acharControlePerfil, '3 (abrir perfil)', 'controle do perfil no cabeçalho');
    }

    // 4. Confirmar o painel e encerrar com ele aberto
    mostrarAviso('Etapa 4: aguardando o painel lateral…');
    await esperar(acharPainel, '4 (confirmar painel)', 'painel lateral com as seções "Representar" e "Representações Recentes"');
    await esperarEstabilidade();
    const p = await esperar(acharPainel, '4 (confirmar painel)', 'painel lateral com as seções "Representar" e "Representações Recentes"');
    log(MSG_PAINEL);
    mostrarAviso(MSG_PAINEL, 'ok');
    await sleep(600);

    // Esta empresa já está em "Representação Atual" (ex.: retomada depois de F5): não representa de novo,
    // retoma a análise a partir da página dela.
    // CNPJ da PRÓPRIA conta logada (titular, no topo do painel): a extensão NÃO encerra a representação ativa
    // (a confirmação "Encerrar representação" é sempre cancelada); segue o fluxo normal de Trocar Representação.
    const titular = lerTitularDoPainel();
    if (titular && titular.digitos === ctx.digitos) {
      log(`${ctx.documento} é o titular da conta; seguindo pelo fluxo normal de Trocar Representação (sem encerrar a representação ativa)`);
    }

    const repJa = lerRepresentacaoAtual();
    if (repJa && repJa.digitos === ctx.digitos) {
      ctx.cnpjConfirmado = repJa.digitos;
      log(`${ctx.documento} já está em "Representação Atual" (Procurador de ${repJa.documento}); retomando a análise`);
      mostrarAviso(`Etapa 8: ${repJa.documento} já representada — retomando a análise`, 'ok');
      return posRepresentacao(ctx);
    }

    // 5. Preencher o CPF/CNPJ (se já estiver com o documento certo, aproveita)
    await esperar(campoDoc, '5 (preencher CPF/CNPJ)', 'campo "Digite o CPF ou CNPJ" no painel');

    // A tentativa deste CNPJ já foi recusada e a mensagem continua na tela: salva a evidência sem clicar de novo.
    if (soDigitos(campoDoc().value) === ctx.digitos) {
      const ja = mensagemRecusaNoPainel();
      if (ja && perfilSelecionado(seletorAtual())) {
        log('a recusa deste CNPJ ainda está visível no painel; salvando a evidência sem nova tentativa');
        return tratarRecusa(ctx, { recusa: true, texto: ja.texto, el: ja.el });
      }
    }
    if (soDigitos(campoDoc().value) === ctx.digitos) {
      log(`documento já preenchido ("${campoDoc().value}"); aproveitando o valor`);
    } else {
      mostrarAviso(`Etapa 5: preenchendo o documento ${ctx.documento}…`);
      await clicarEm(campoDoc, '5 (preencher CPF/CNPJ)', 'campo "Digite o CPF ou CNPJ"');
      await preencherDocumento(campoDoc(), ctx);
      campoDoc().blur(); // sai do campo como quem clica no próximo: o portal valida o documento
      await esperarEstabilidade(2500); // o portal pode recriar o seletor de perfil depois de validar
    }
    log(`documento conferido no campo: "${campoDoc().value}"`);

    // 6. Selecionar o perfil "Procurador"
    mostrarAviso(`Etapa 6: selecionando o perfil "${PERFIL}"…`);
    try {
      await selecionarPerfil();
    } catch (e) {
      const c = acharPainel();
      if (c && !e.cancelada) console.warn(PREFIXO, 'HTML do painel (para diagnóstico da etapa 6):', c.painel.outerHTML.slice(0, 12000));
      throw e;
    }

    // 7 e 8. Representar e aguardar a resposta
    mostrarAviso('Etapa 7: aguardando o botão "Representar" ficar habilitado…');
    await esperar(() => { const b = acharBotaoRepresentar(); return b && habilitado(b) ? b : null; },
      '7 (representar)', 'botão "Representar" habilitado');
    const rep = await representarEAguardar(ctx);
    if (rep.recusa) return tratarRecusa(ctx, rep);

    // 8. Confirmar a empresa representada (antes de salvar qualquer coisa)
    if (rep.digitos !== ctx.digitos) {
      throw erroEtapa(`Etapa 8 (confirmar representação) — divergência: solicitado ${ctx.documento} (${ctx.digitos}), ` +
        `o portal mostra "Procurador de:" ${rep.documento} (${rep.digitos}). Execução interrompida; nada foi salvo.`);
    }
    ctx.cnpjConfirmado = rep.digitos;
    log(`representação confirmada em "Representação Atual": Procurador de ${rep.documento} (${rep.digitos})`);
    mostrarAviso(`Etapa 8: representação confirmada — ${rep.documento}`, 'ok');
    return posRepresentacao(ctx);
  }

  // ------------------------------- etapas 5 a 8 -------------------------------
  function acharCampo(raiz, rePlaceholder) {
    return todos(raiz).find((e) => e.tagName === 'INPUT' && rePlaceholder.test(norm(e.getAttribute('placeholder'))) && visivel(e)) || null;
  }
  const campoDoc = () => { const c = acharPainel(); return c ? acharCampo(c.painel, /cpf ou cnpj/) : null; };

  // Pasta da empresa: RFB_CNPJ/<nome da empresa>, com o nome limpo para o Windows (sem <>:"/\|?*, sem ponto ou
  // espaço no fim). Ordem: nome da lista → nome em Dados Cadastrais → dígitos do CNPJ.
  const limparNomePasta = (s) => String(s || '').replace(/[<>:"/\\|?*\x00-\x1f]/g, '_').replace(/\s+/g, ' ').trim()
    .replace(/[. ]+$/, '').slice(0, 120);
  function pastaDaEmpresa(ctx, nomeDaPagina = '') {
    let nome = limparNomePasta(ctx.nome) || limparNomePasta(nomeDaPagina) || ctx.digitos;
    // nome igual ao de outra empresa da lista (ex.: várias filiais "… LTDA PE"): acrescenta o nº da filial (0002…)
    const iguais = FILA.filter((f) => limparNomePasta(f.nome).toUpperCase() === nome.toUpperCase()).length;
    if (iguais > 1) nome = `${nome} ${ctx.digitos.slice(8, 12)}`;
    return `${PASTA_RAIZ}/${nome}`;
  }

  // ---- recusa da representação: evidência em PDF ----
  // Recorte: do título da seção ("Trocar Representação"; sem representação anterior, o "Representar" logo acima do
  // campo) até a borda inferior do campo Procurador — com o CNPJ, a mensagem vermelha inteira e o perfil, SEM o botão.
  function regiaoDaRecusa(msgEl) {
    const c = acharPainel(), campo = campoDoc(), sel = seletorAtual();
    if (!c || !campo || !sel) return null;
    const rc = campo.getBoundingClientRect();
    const titulo = acharTextos('Trocar Representação', c.painel)[0] ||
      acharTextos('Representar', c.painel).filter((e) => e.getBoundingClientRect().bottom <= rc.top + 2)
        .sort((a, b) => b.getBoundingClientRect().bottom - a.getBoundingClientRect().bottom)[0];
    if (!titulo) return null;
    const rt = titulo.getBoundingClientRect(), rs = retCampo(sel), pr = c.painel.getBoundingClientRect();
    const rm = msgEl && msgEl.isConnected ? msgEl.getBoundingClientRect() : rs;
    const botao = acharBotaoRepresentar();
    const limiteBaixo = botao ? botao.getBoundingClientRect().top - 2 : Infinity;
    const esquerda = Math.max(pr.left, Math.min(rt.left, rc.left, rs.left, rm.left) - 10);
    const direita = Math.min(pr.right, Math.max(rc.right, rs.right, rm.right) + 10);
    const topo = rt.top - 8;
    const base = Math.min(Math.max(rs.bottom, rm.bottom) + 6, limiteBaixo);
    return { x: esquerda, y: topo, w: direita - esquerda, h: base - topo };
  }

  async function tratarRecusa(ctx, recusa) {
    // 1. o CNPJ no campo é o do item da fila (a Representação Atual pode continuar com a empresa anterior)
    const valor = campoDoc() ? campoDoc().value : '';
    if (soDigitos(valor) !== ctx.digitos) {
      throw erroEtapa(`Etapa 8 (recusa) — o campo mostra "${valor || '(vazio)'}", não ${ctx.documento}. Evidência não salva.`);
    }
    mostrarAviso(`Etapa 8: o portal recusou ${ctx.documento} — salvando a evidência…`, 'erro');
    // 2. enquadra a seção na tela (o painel pode ter rolagem própria)
    let reg = regiaoDaRecusa(recusa.el);
    if (!reg) throw erroEtapa('Etapa 8 (recusa) — não localizei o título da seção, o campo do CNPJ ou o campo Procurador para o recorte.');
    if (reg.y < 0 || reg.y + reg.h > innerHeight) {
      const t = acharTextos('Trocar Representação')[0] || campoDoc();
      t.scrollIntoView({ block: 'center' });
      await sleep(500);
      reg = regiaoDaRecusa(recusa.el);
    }
    const msg = recusa.el && recusa.el.isConnected ? recusa.el : null;
    if (!msg || !visivel(msg)) throw erroEtapa(`Etapa 8 (recusa) — a mensagem "${recusa.texto}" sumiu antes da captura. Evidência não salva.`);
    // 3. salva o PDF na pasta da empresa
    const caminho = `${pastaDaEmpresa(ctx)}/Erro_de_Procuracao/Erro_de_Procuracao_${ctx.digitos}.pdf`;
    const cap = await capturarTelaPdf(caminho, reg);
    limparPendente();
    log(`Erro de procuração — evidência salva: ${cap.filename} (mensagem: "${recusa.texto}")`);
    mostrarAviso(`Erro de procuração — evidência salva\n${ctx.documento}: "${recusa.texto}"\n• ${cap.filename}`, 'ok');
    return { status: 'Erro de procuração', mensagem: recusa.texto, evidencia: cap.filename };
  }

  const setterValor = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
  function definirValor(campo, valor, inputType = 'insertText', data = null) {
    setterValor.call(campo, valor); // setter nativo: o Angular/máscara percebe a mudança
    campo.dispatchEvent(new InputEvent('input', { bubbles: true, composed: true, inputType, data }));
  }

  // Digita caractere por caractere (teclas + input), como uma pessoa; a máscara do portal formata sozinha.
  async function digitar(campo, texto) {
    campo.focus();
    if (campo.value) { definirValor(campo, '', 'deleteContentBackward'); await sleep(250); }
    for (const ch of texto) {
      conferir();
      const k = { key: ch, code: /\d/.test(ch) ? `Digit${ch}` : '', keyCode: ch.charCodeAt(0), which: ch.charCodeAt(0),
        bubbles: true, cancelable: true, composed: true, view: window };
      if (campo.dispatchEvent(new KeyboardEvent('keydown', k))) {
        campo.dispatchEvent(new KeyboardEvent('keypress', { ...k, charCode: k.keyCode }));
        definirValor(campo, campo.value + ch, 'insertText', ch);
      }
      campo.dispatchEvent(new KeyboardEvent('keyup', k));
      await sleep(rand(280, 420) * LENTIDAO_DIGITACAO); // dá para acompanhar cada dígito e a máscara
    }
    campo.dispatchEvent(new Event('change', { bubbles: true }));
  }

  async function preencherDocumento(campo, ctx) {
    const digitos = ctx.digitos; // "00351766000110": a máscara do portal coloca a pontuação
    await digitar(campo, digitos);
    await sleep(400);
    if (soDigitos(campo.value) !== digitos) {
      // máscara perdeu algum caractere: põe o valor inteiro de uma vez e confere de novo
      log(`campo ficou "${campo.value}"; preenchendo o valor completo de uma vez`);
      definirValor(campo, '', 'deleteContentBackward');
      definirValor(campo, ctx.documento, 'insertFromPaste');
      campo.dispatchEvent(new Event('change', { bubbles: true }));
      await sleep(400);
    }
    if (soDigitos(campo.value) !== digitos) {
      throw new Error(`Etapa 5: o campo mostra "${campo.value}", diferente de ${ctx.documento}. Execução interrompida.`);
    }
  }

  // ---- seletor "Digite um perfil de representação" ----
  // O texto pode estar como placeholder de um <input>, como nome acessível (aria-label/aria-labelledby) ou desenhado
  // num <div>/<span> por cima de um <input> escondido (ng-select e afins). Por isso há três jeitos de achar a "âncora",
  // e daí sobe-se até a caixa visível do campo, que é onde se clica.
  const RE_PERFIL = /perfil de representacao/;
  const ATRIBUTOS_ROTULO = ['placeholder', 'aria-label', 'aria-placeholder', 'title', 'data-placeholder', 'label'];
  const SEL_OPCAO = '[role=option],mat-option,.ng-option,li,.br-item,[class*=option i]';
  let ultimoSeletor = null;

  function rotulos(e) {
    let t = ATRIBUTOS_ROTULO.map((a) => e.getAttribute(a)).filter(Boolean).join(' ');
    const ids = (e.getAttribute('aria-labelledby') || '').split(/\s+/).filter(Boolean);
    const raiz = e.getRootNode();
    for (const id of ids) {
      const l = (raiz.getElementById ? raiz.getElementById(id) : null) || document.getElementById(id);
      if (l) t += ' ' + l.textContent;
    }
    return t;
  }

  // Sobe da âncora até o retângulo com cara de campo (largo, até ~90 px de altura). Para antes de engolir a lista.
  function caixaDoControle(ancora, painel) {
    const larguraMin = Math.min(150, painel.getBoundingClientRect().width * 0.5);
    let melhor = null;
    for (let e = ancora, i = 0; e && e !== painel && i < 7; e = pai(e), i++) {
      const r = e.getBoundingClientRect();
      if (r.height > 70) break; // uma linha de campo; acima disso já seria a seção inteira
      if (visivel(e) && r.width >= larguraMin && r.height >= 24) melhor = e;
    }
    return melhor;
  }

  function acharSeletorPerfil() {
    const c = acharPainel();
    if (!c) return null;
    const els = todos(c.painel);
    let ancora = els.find((e) => RE_PERFIL.test(norm(rotulos(e)))) || null; // inclui <input> invisível
    let por = ancora ? `atributo de <${ancora.tagName.toLowerCase()}>` : '';
    if (!ancora) { ancora = acharTextos('Digite um perfil de representação', c.painel)[0] || null; por = 'texto visível'; }
    if (!ancora) {
      // depois de escolhido, o texto de ajuda some: é o controle logo abaixo do campo do CPF/CNPJ
      const doc = acharCampo(c.painel, /cpf ou cnpj/);
      if (doc) {
        const dr = doc.getBoundingClientRect();
        ancora = els.find((e) => e !== doc && e.matches('input,select,[role=combobox],[aria-haspopup=listbox]') &&
          e.getBoundingClientRect().top >= dr.bottom - 2 && e.getBoundingClientRect().top < dr.bottom + 90) || null;
        por = 'posição abaixo do CPF/CNPJ';
      }
    }
    if (!ancora) return null;
    const controle = caixaDoControle(ancora, c.painel);
    if (!controle) return null;
    const input = ancora.tagName === 'INPUT' ? ancora : todos(controle).find((e) => e.tagName === 'INPUT') || null;
    return (ultimoSeletor = { controle, input, por });
  }

  // Busca de novo a cada uso (o portal pode recriar o componente); se sumir por um instante, usa o último achado.
  function seletorAtual() {
    return acharSeletorPerfil() || (ultimoSeletor && ultimoSeletor.controle.isConnected ? ultimoSeletor : null);
  }

  // ---- lista de perfis ----
  // A lista pode ser renderizada dentro do próprio componente do campo (posição absoluta), numa camada fora do painel
  // ou com elementos personalizados. Por isso ela é reconhecida pela POSIÇÃO NA TELA (logo abaixo/acima do campo,
  // na mesma coluna) e pelo que está de fato visível por cima (elementFromPoint), não pela estrutura do DOM.
  const PERFIS_CONHECIDOS = ['Procurador', 'Matriz', 'Sucessor', 'Ente Federado']; // só evidência; ordem/quantidade podem variar
  const textoVisivel = (e) => norm(e.innerText !== undefined ? e.innerText : e.textContent);

  function retCampo(sel) { return sel.controle.getBoundingClientRect(); }

  function naAreaDaLista(sel, e) {
    const s = retCampo(sel), r = e.getBoundingClientRect();
    const mesmaColuna = r.right > s.left + 4 && r.left < s.right - 4;
    const foraDoCampo = r.top >= s.bottom - 6 || r.bottom <= s.top + 6;
    return mesmaColuna && foraDoCampo && r.top < s.bottom + 450 && r.bottom > s.top - 450;
  }

  // O elemento está mesmo à vista (nada cobrindo o centro dele)?
  function emCima(e) {
    const r = e.getBoundingClientRect();
    const x = r.left + r.width / 2, y = r.top + r.height / 2;
    if (x < 0 || y < 0 || x >= innerWidth || y >= innerHeight) return false;
    const hit = elementoNoPonto(x, y);
    return !!hit && (hit === e || contem(e, hit) || contem(hit, e));
  }

  // Textos de uma linha visíveis na área da lista (o mais interno de cada texto).
  function itensDaLista(sel) {
    const els = todos().filter((e) => !/^(SCRIPT|STYLE|SVG|PATH|INPUT)$/i.test(e.tagName) && visivel(e) && naAreaDaLista(sel, e));
    return els.filter((e) => {
      const t = textoVisivel(e);
      return t && t.length <= 60 && ![...e.children].some((c) => textoVisivel(c) === t) && emCima(e);
    });
  }

  function textosLidos(sel) {
    if (!sel) return 'nenhum (campo não localizado)';
    const t = [...new Set(itensDaLista(sel).map((e) => (e.innerText || e.textContent).replace(/\s+/g, ' ').trim()))].slice(0, 12);
    return t.length ? t.map((x) => `"${x}"`).join(', ') : 'nenhum';
  }

  function listaAberta(sel) {
    if (!sel) return false;
    const conhecidos = PERFIS_CONHECIDOS.map(norm);
    return itensDaLista(sel).some((e) => conhecidos.includes(textoVisivel(e))) ||
      todos().some((e) => e.matches('[role=option],[role=listbox],.ng-option,mat-option') && visivel(e) && naAreaDaLista(sel, e) && emCima(e));
  }

  // A linha clicável da opção: sobe enquanto o texto continuar sendo só "Procurador" e a altura for de uma linha.
  function linhaDaOpcao(e) {
    let linha = e;
    for (let c = pai(e), i = 0; c && i < 5; c = pai(c), i++) {
      const r = c.getBoundingClientRect();
      if (r.height > 70 || textoVisivel(c) !== norm(PERFIL)) break;
      linha = c;
    }
    for (let c = linha, i = 0; c && i < 3; c = pai(c), i++) {
      if (c.matches && c.matches(SEL_OPCAO) && c.getBoundingClientRect().height <= 70) return c;
    }
    return linha;
  }

  // Item da lista cujo texto completo é PERFIL (sem diferença de espaços/maiúsculas), em qualquer posição.
  function acharOpcaoPerfil(sel) {
    if (!sel) return null;
    const item = itensDaLista(sel).find((e) => textoVisivel(e) === norm(PERFIL));
    return item ? linhaDaOpcao(item) : null;
  }

  function valorDoCampo(sel) {
    if (!sel) return '';
    if (sel.input && sel.input.value) return sel.input.value;
    const s = retCampo(sel);
    const dentro = todos().filter((e) => {
      if (!visivel(e) || e.children.length) return false;
      const r = e.getBoundingClientRect(), x = r.left + r.width / 2, y = r.top + r.height / 2;
      return x > s.left && x < s.right && y > s.top && y < s.bottom;
    });
    return dentro.map((e) => (e.innerText || e.textContent).trim()).filter(Boolean).join(' ');
  }

  function perfilSelecionado(sel) {
    if (!sel) return false;
    if (sel.input && norm(sel.input.value) === norm(PERFIL)) return true;
    // valor desenhado dentro da caixa do campo (e não o item da lista logo abaixo)
    const s = retCampo(sel);
    return acharTextos(PERFIL).some((e) => {
      const r = e.getBoundingClientRect(), x = r.left + r.width / 2, y = r.top + r.height / 2;
      return x > s.left && x < s.right && y > s.top && y < s.bottom;
    });
  }

  // A seta azul à direita do próprio campo (procurada pela posição: dentro da caixa, nos últimos 60 px).
  function setaDoSeletor(sel) {
    const s = retCampo(sel);
    const candidatos = todos().filter((e) => {
      if (!visivel(e)) return false;
      const r = e.getBoundingClientRect(), x = r.left + r.width / 2, y = r.top + r.height / 2;
      return x > s.right - 60 && x < s.right && y > s.top && y < s.bottom && r.width <= 60 && r.height <= 60;
    });
    return candidatos.find((e) => e.matches('button,[role=button]')) ||
      candidatos.find((e) => /arrow|chevron|caret|toggle|angle|dropdown|seta/i.test(classe(e))) ||
      candidatos.find((e) => e.matches('svg,i')) || null;
  }

  // Espera acompanhando o DOM: confere já, a cada mudança (agrupada) e a cada 250 ms, até o tempo limite.
  function esperarComDOM(buscar, timeout) {
    return new Promise((resolve, reject) => {
      let feito = false, agendado = false;
      const fim = (f, v) => { if (feito) return; feito = true; obs.disconnect(); clearInterval(iv); clearTimeout(to); f(v); };
      const testar = () => {
        agendado = false;
        try {
          conferir();
          const falha = falhaTemporaria();
          if (falha) return fim(reject, erroTemporario(falha, 'portal'));
          const r = buscar();
          if (r) fim(resolve, r);
        } catch (e) { fim(reject, e); }
      };
      const obs = new MutationObserver(() => { if (!agendado) { agendado = true; setTimeout(testar, 60); } });
      obs.observe(document.documentElement, { subtree: true, childList: true, attributes: true, characterData: true });
      const iv = setInterval(testar, 250);
      const to = setTimeout(() => fim(resolve, null), timeout);
      testar();
    });
  }

  async function selecionarPerfil() {
    const E = 'Etapa 6 (selecionar perfil)';
    const atual = () => seletorAtual();
    const sel = await esperar(seletorAtual, '6 (selecionar perfil) — ao localizar o campo', 'seletor "Digite um perfil de representação" no painel');
    log(`seletor de perfil localizado (${sel.por}):`, sel.controle);
    if (perfilSelecionado(sel)) { log(`perfil "${PERFIL}" já selecionado`); return; }

    // Leitura imediata: se a lista já estiver aberta, vai direto à seleção (outro clique no campo poderia fechá-la).
    let aberta = listaAberta(sel);
    if (aberta) {
      log('lista de perfis já está aberta; indo direto à seleção. Opções lidas:', textosLidos(sel));
    } else {
      // 1ª tentativa: clique no corpo do campo
      await clicarEm(() => (atual() || sel).controle, '6 (selecionar perfil) — ao abrir a lista', 'seletor "Digite um perfil de representação"');
      aberta = await esperarComDOM(() => listaAberta(atual() || sel), 3000);
      // 2ª tentativa: a seta azul — só se a lista continuar fechada (para não fechá-la por engano)
      if (!aberta && !listaAberta(atual() || sel)) {
        const seta = setaDoSeletor(atual() || sel);
        if (!seta) {
          throw new Error(`${E} — ao abrir a lista: o clique no campo não abriu a lista e a seta azul não foi encontrada. ` +
            `Textos lidos abaixo do campo: ${textosLidos(atual() || sel)}. Execução interrompida.`);
        }
        log('o clique no campo não abriu a lista; tentando a seta azul à direita');
        await clicarEm(() => setaDoSeletor(atual() || sel) || seta, '6 (selecionar perfil) — ao abrir a lista', 'seta azul do seletor de perfil');
        aberta = await esperarComDOM(() => listaAberta(atual() || sel), TIMEOUT_LISTA_MS);
        if (!aberta) {
          throw new Error(`${E} — ao abrir a lista: a lista não apareceu nem pelo campo nem pela seta azul. ` +
            `Textos lidos abaixo do campo: ${textosLidos(atual() || sel)}. Execução interrompida.`);
        }
      }
      log('lista de perfis aberta. Opções lidas:', textosLidos(atual() || sel));
    }

    // Opção "Procurador" (acompanha a renderização dos itens até o tempo limite)
    const opcao = await esperarComDOM(() => acharOpcaoPerfil(atual() || sel), 4000);
    if (!opcao) {
      throw new Error(`${E} — ao encontrar a opção ${PERFIL}: a lista está aberta, mas não há item com o texto "${PERFIL}". ` +
        `Opções lidas: ${textosLidos(atual() || sel)}. Execução interrompida.`);
    }
    log(`opção "${PERFIL}" encontrada:`, opcao);
    await clicarEm(() => acharOpcaoPerfil(atual() || sel) || (opcao.isConnected ? opcao : null),
      '6 (selecionar perfil) — ao clicar na opção', `opção "${PERFIL}"`);
    const ok = await esperarComDOM(() => perfilSelecionado(atual() || sel), 6000);
    if (!ok) {
      throw new Error(`${E} — ao confirmar a seleção: a opção "${PERFIL}" foi clicada, mas o campo mostra ` +
        `"${valorDoCampo(atual() || sel) || '(vazio)'}". Opções lidas: ${textosLidos(atual() || sel)}. Execução interrompida.`);
    }
    log(`perfil "${PERFIL}" confirmado no campo`);
  }

  // O botão azul "Representar" fica logo ABAIXO do seletor de perfil. O título da seção ("^ Representar") também é
  // um botão com o mesmo texto (abre/fecha a seção) e fica acima dos campos — por isso a escolha é pela posição.
  function acharBotaoRepresentar() {
    const c = acharPainel();
    if (!c) return null;
    const candidatos = todos(c.painel).filter((e) => e.matches('button,[role=button],input[type=submit],input[type=button]') &&
      norm(e.textContent || e.value) === 'representar' && visivel(e));
    const sel = seletorAtual();
    if (!sel) return null;
    const base = retCampo(sel).bottom;
    const abaixo = candidatos.filter((e) => e.getBoundingClientRect().top >= base - 4)
      .sort((a, b) => a.getBoundingClientRect().top - b.getBoundingClientRect().top);
    return abaixo[0] || null;
  }

  function habilitado(b) {
    return !b.disabled && b.getAttribute('aria-disabled') !== 'true' && !/(^|\s|-)disabled(\s|$)/i.test(classe(b));
  }

  const SEL_AVISOS = '[role=alert],[role=alertdialog],[role=status],[role=dialog],[aria-live],.br-message,.br-modal,.modal,' +
    '[class*=toast i],[class*=snack i],[class*=alert i],[class*=message i],[class*=notifica i],[class*=feedback i]';
  const SEL_CARREGANDO = '[class*=loading i],[class*=spinner i],[class*=loader i],[aria-busy=true],.br-loading';

  // Mensagens visíveis do portal: [{ el, texto }] (o elemento permite saber se a mensagem é desta tentativa).
  function avisosVisiveis() {
    // o próprio painel lateral (ou algo em volta dele) não é mensagem do portal, mesmo que o texto dele mude
    const p = acharPainel();
    const ehPainel = (e) => !!p && (contem(e, p.recentes) || contem(e, p.painel));
    const els = todos().filter((e) => e.matches(SEL_AVISOS) && visivel(e) && !ehPainel(e) && e.id !== ID_AVISO);
    return els.filter((e) => !els.some((o) => o !== e && contem(o, e)))
      .map((el) => ({ el, texto: (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim() }))
      .filter((a) => a.texto.length >= 3 && a.texto.length <= 600);
  }
  const textosAvisos = () => avisosVisiveis().map((a) => a.texto);

  // Recusa da representação (ex.: "Sua autorização como procurador não permite acesso a este serviço.").
  const RE_RECUSA = /autorizacao como procurador|nao permite acesso|procuracao|procurador nao|nao (foi|ha|existe|possui|e possivel|autoriz)|sem permiss|negad|invalid|erro|falha|indisponiv/;
  const ehRecusa = (t) => RE_RECUSA.test(norm(t)) && !RUIDO_AVISOS.test(norm(t));
  // mensagem de recusa visível dentro do painel (a que fica entre o campo do CPF/CNPJ e o seletor)
  function mensagemRecusaNoPainel() {
    const c = acharPainel();
    if (!c) return null;
    return avisosVisiveis().find((a) => contem(c.painel, a.el) && ehRecusa(a.texto)) || null;
  }

  const carregandoVisiveis = () => todos().filter((e) => e.matches(SEL_CARREGANDO) && visivel(e));

  // Erro com mensagem pronta para o aviso (tipo 'erro' = vermelho, 'info' = azul).
  const erroEtapa = (mensagem, tipo = 'erro') => Object.assign(new Error(mensagem), { etapaMsg: true, tipo });

  // Textos de leitores de tela do seletor ("Quantidade de opções exibidas: 1") não são resposta do portal.
  const RUIDO_AVISOS = /quantidade de opcoes|opcoes exibidas|resultados? (encontrad|disponive)/;
  const RE_DOC_TEXTO = /\d{2}\.?\d{3}\.?\d{3}\/?\d{4}-?\d{2}|\d{3}\.?\d{3}\.?\d{3}-?\d{2}/; // CNPJ ou CPF, com ou sem pontuação

  // Seção "Representação Atual" do painel: o documento exibido ao lado de "Procurador de:".
  function lerRepresentacaoAtual() {
    const titulo = acharTextos('Representação Atual').find((e) => e.getBoundingClientRect().left > innerWidth * 0.4);
    if (!titulo) return null;
    const tr = titulo.getBoundingClientRect();
    const trocar = acharTextos('Trocar Representação')[0];
    const fundo = trocar ? trocar.getBoundingClientRect().top : tr.bottom + 220;
    const rotulo = todos().find((e) => /^procurador de:?$/.test(textoVisivel(e)) && visivel(e) &&
      e.getBoundingClientRect().top >= tr.bottom - 2 && e.getBoundingClientRect().top < fundo);
    if (!rotulo) return null;
    // sobe do rótulo até a linha que também mostra o documento (sem chegar ao painel inteiro)
    for (let c = pai(rotulo), i = 0; c && i < 6; c = pai(c), i++) {
      const t = (c.innerText || c.textContent || '').replace(/\s+/g, ' ').trim();
      if (t.length > 300) break;
      const m = t.match(RE_DOC_TEXTO);
      if (m) return { documento: m[0], digitos: soDigitos(m[0]), texto: t, el: c };
    }
    return null;
  }

  // Titular da conta: o primeiro CNPJ/CPF do painel, no topo (antes de "Representação Atual"/"Representar").
  function lerTitularDoPainel() {
    const c = acharPainel();
    if (!c) return null;
    const limite = (acharTextos('Representação Atual', c.painel)[0] || c.representar).getBoundingClientRect().top;
    const el = todos(c.painel).find((e) => e.children.length === 0 && visivel(e) && RE_DOC_TEXTO.test(e.textContent) &&
      e.getBoundingClientRect().bottom <= limite);
    if (!el) return null;
    const m = el.textContent.match(RE_DOC_TEXTO);
    return { documento: m[0], digitos: soDigitos(m[0]) };
  }


  // Marca "Representar já clicado" para este CNPJ e conta as tentativas seguidas dele (para não repetir sem fim).
  function marcarPendente(ctx) {
    try {
      const ant = JSON.parse(sessionStorage.getItem(CHAVE_PENDENTE) || 'null');
      const tentativas = (ant && ant.documento === ctx.documento ? ant.tentativas || 1 : 0) + 1;
      sessionStorage.setItem(CHAVE_PENDENTE, JSON.stringify({ t: Date.now(), documento: ctx.documento, tentativas }));
    } catch (_) { /* sem storage */ }
  }
  function limparPendente() {
    try { sessionStorage.removeItem(CHAVE_PENDENTE); } catch (_) { /* sem storage */ }
  }
  function lerPendente() {
    try {
      const p = JSON.parse(sessionStorage.getItem(CHAVE_PENDENTE) || 'null');
      if (p && Date.now() - p.t < VALIDADE_PENDENTE_MS) return p;
      sessionStorage.removeItem(CHAVE_PENDENTE);
    } catch (_) { /* sem storage */ }
    return null;
  }

  // Etapas 7 e 8: clica em "Representar" uma vez e espera a seção "Representação Atual" mostrar o CNPJ pedido, ou
  // uma recusa do portal. Devolve { recusa: false, ...representação } ou { recusa: true, texto, el }.
  async function representarEAguardar(ctx) {
    // Mensagens já na tela antes do clique (ex.: a recusa do CNPJ anterior). Uma delas só vale como resposta
    // DESTA tentativa se sumir e voltar depois do clique; mensagens em elementos novos valem na hora.
    const elsAntes = new Set(avisosVisiveis().map((a) => a.el));
    const sumiram = new Set();
    const carregandoAntes = new Set(carregandoVisiveis());
    const repAntes = lerRepresentacaoAtual(); // se já havia uma representação, espera ela mudar
    mostrarAviso('Etapa 7: clicando em "Representar"…');
    marcarPendente(ctx); // ANTES do clique: se o portal recarregar a página, a nova cópia do script não clica de novo
    execucao.aguardandoResposta = true;
    await clicarEm(acharBotaoRepresentar, '7 (representar)', 'botão "Representar"');

    mostrarAviso('Etapa 8: aguardando "Representação Atual" no painel…');
    const inicio = Date.now();
    const vistos = new Set();
    let viuCarregando = false;
    let carregandoDesde = 0;
    for (;;) {
      conferir();
      const falha = falhaTemporaria();
      if (falha) { execucao.aguardandoResposta = false; throw erroTemporario(falha, 'portal'); }
      // a Representação Atual é lida SEMPRE (antes, um indicador de carregamento preso impedia esta leitura)
      const rep = lerRepresentacaoAtual();
      // Já é a empresa pedida: pronto. Ainda é a empresa anterior: espera o portal atualizar.
      // Outra empresa (nem a pedida nem a anterior): devolve para a etapa 8 acusar a divergência.
      if (rep && (rep.digitos === ctx.digitos || !repAntes || rep.digitos !== repAntes.digitos)) {
        execucao.aguardandoResposta = false;
        return { recusa: false, ...rep };
      }
      if (rep && repAntes && rep.digitos === repAntes.digitos && !vistos.has('__anterior')) {
        vistos.add('__anterior');
        log(`"Representação Atual" ainda mostra ${rep.documento}; aguardando a atualização para ${ctx.documento}`);
      }
      // carregando: estende a espera até TIMEOUT_CARREGANDO_MS; parado e sem resposta: até TIMEOUT_RESPOSTA_MS
      const carregando = carregandoVisiveis().some((e) => !carregandoAntes.has(e));
      if (carregando && !carregandoDesde) { carregandoDesde = Date.now(); if (!viuCarregando) log('portal carregando…'); viuCarregando = true; }
      if (!carregando) carregandoDesde = 0;
      const passou = Date.now() - inicio;
      if (passou >= (carregando ? Math.max(TIMEOUT_RESPOSTA_MS, TIMEOUT_CARREGANDO_MS) : TIMEOUT_RESPOSTA_MS)) break;
      const atuais = avisosVisiveis();
      for (const el of elsAntes) if (!atuais.some((a) => a.el === el)) sumiram.add(el);
      for (const a of atuais) {
        if (elsAntes.has(a.el) && !sumiram.has(a.el)) continue; // ainda é a mensagem de antes do clique
        if (RUIDO_AVISOS.test(norm(a.texto))) continue;
        if (ehRecusa(a.texto)) {
          execucao.aguardandoResposta = false;
          log('o portal recusou a representação:', a.texto);
          return { recusa: true, texto: a.texto, el: a.el };
        }
        if (!vistos.has(a.texto)) { vistos.add(a.texto); log('mensagem do portal:', a.texto); }
      }
      await sleep(250);
    }
    execucao.aguardandoResposta = false;
    limparPendente();
    vistos.delete('__anterior');
    // sem resposta = falha temporária: recarrega e confere (se a representação pegou, retoma direto a análise)
    throw erroTemporario(`${MSG_SEM_CONFIRMACAO}: "Representação Atual" não passou a mostrar ${ctx.documento} em ` +
      `${Math.round((Date.now() - inicio) / 1000)} s${vistos.size ? ` (mensagens: ${[...vistos].join(' | ')})` : ''}`, 'carregamento');
  }

  // ------------------------------- etapas 9 a 11 -------------------------------
  function lerDadosPagina() {
    const p = reconhecerPagina();
    if (!p) return null;
    const bd = blocoDe(p.dados), br = blocoDe(p.resultado);
    const linhas = (el) => (el.innerText || el.textContent || '').split('\n').map((s) => s.trim()).filter(Boolean);
    const ld = linhas(bd), lr = linhas(br);
    const m = ld.join('\n').match(RE_DOC_TEXTO);
    const iNome = ld.findIndex((l) => norm(l) === 'nome');
    const iCab = lr.findIndex((l) => norm(l) === 'resultado da analise');
    // mensagem do cartão: as linhas depois do status, sem a data da análise e sem o botão "Atualizar"
    const mensagem = lr.slice(iCab + 2).filter((l) => !/^analise realizada/.test(norm(l)) && norm(l) !== 'atualizar').join(' ');
    return {
      nome: iNome >= 0 ? ld[iNome + 1] || '' : '',
      documento: m ? m[0] : '',
      digitos: m ? soDigitos(m[0]) : '',
      status: lr[iCab + 1] || '', // ex.: "Com pendência" / "Sem pendência"
      mensagem,
      debitoAVencer: /debito a vencer/.test(norm(mensagem)),
      blocoDados: bd,
      blocoResultado: br,
    };
  }

  function botaoFechar(painel) {
    if (!painel) return null;
    const pr = painel.getBoundingClientRect();
    return todos(painel).find((e) => {
      if (!e.matches('button,[role=button],a') || !visivel(e)) return false;
      const r = e.getBoundingClientRect();
      const rot = norm(`${e.getAttribute('aria-label') || ''} ${e.getAttribute('title') || ''} ${e.textContent}`);
      return r.top < pr.top + 90 && r.left + r.width / 2 > pr.right - 90 && (/fechar|close/.test(rot) || /^[×✕x]?$/.test(rot));
    }) || null;
  }

  // Camada escura que cobre a página atrás do painel: fixa/absoluta, quase do tamanho da janela, e não é um controle.
  function ehFundo(h) {
    if (!h || h.closest('a,button,input,select,textarea,[role=button]')) return false;
    for (let e = h, i = 0; e && i < 3; e = pai(e), i++) {
      const r = e.getBoundingClientRect(), s = getComputedStyle(e);
      if ((s.position === 'fixed' || s.position === 'absolute') && r.width >= innerWidth * 0.5 && r.height >= innerHeight * 0.8) return true;
    }
    return false;
  }

  async function clicarNoPonto(x, y, descricao) {
    log(`movendo a seta até: ${descricao}`);
    await moverPara(x, y);
    await sleep(rand(500, 800) * LENTIDAO_MOUSE);
    conferir();
    const alvo = elementoNoPonto(x, y);
    if (!alvo) throw erroEtapa(`Etapa 9 — nada clicável em ${descricao}.`);
    log(`clicando em: ${descricao}`);
    pulso();
    disparar(alvo, 'pointerdown'); disparar(alvo, 'mousedown');
    await sleep(rand(70, 140));
    disparar(alvo, 'pointerup'); disparar(alvo, 'mouseup');
    disparar(alvo, 'click');
  }

  // Etapa 9: fecha o painel com um clique numa área livre do fundo escurecido (plano B: o "×" do painel).
  async function fecharPainel() {
    mostrarAviso('Etapa 9: fechando o painel lateral…');
    const p = acharPainel();
    const pr = p.painel.getBoundingClientRect();
    const pontos = [[0.5, 0.55], [0.35, 0.7], [0.6, 0.4], [0.25, 0.85]].map(([fx, fy]) => ({ x: pr.left * fx, y: innerHeight * fy }));
    const livre = pontos.find(({ x, y }) => { const h = elementoNoPonto(x, y); return h && !contem(p.painel, h) && ehFundo(h); });
    let fechou = false;
    if (livre) {
      await clicarNoPonto(livre.x, livre.y, 'área livre do fundo escurecido');
      fechou = !!(await esperarComDOM(() => !acharPainel(), 5000));
      if (!fechou) log('o clique no fundo não fechou o painel; usando o × do painel');
    } else {
      log('fundo escurecido não encontrado; usando o × do painel');
    }
    if (!fechou) {
      const x = botaoFechar(p.painel);
      if (!x) throw erroEtapa('Etapa 9 (fechar painel) — não encontrei o fundo escurecido nem o botão × do painel.');
      await clicarEm(() => { const c = acharPainel(); return (c && botaoFechar(c.painel)) || x; }, '9 (fechar painel)', 'botão × do painel');
      await esperar(() => !acharPainel(), '9 (fechar painel)', 'painel lateral desaparecer', 8000);
    }
    await esperarEstabilidade(1500);
    log('painel fechado');
  }

  // Altura do cabeçalho fixo do portal (o que fica por cima ao rolar).
  function alturaCabecalhoFixo() {
    for (let e = elementoNoPonto(innerWidth / 2, 4); e && e !== document.body; e = pai(e)) {
      const s = getComputedStyle(e);
      if (s.position === 'fixed' || s.position === 'sticky') return Math.max(0, e.getBoundingClientRect().bottom);
    }
    return 0;
  }

  // Rola só o necessário para Dados Cadastrais e Resultado da Análise ficarem inteiros na tela.
  async function mostrarBlocos() {
    const d = lerDadosPagina();
    const r1 = d.blocoDados.getBoundingClientRect(), r2 = d.blocoResultado.getBoundingClientRect();
    const topo = Math.min(r1.top, r2.top), base = Math.max(r1.bottom, r2.bottom);
    const livreTopo = alturaCabecalhoFixo() + 8;
    if (topo >= livreTopo && base <= innerHeight - 8) return;
    const delta = base - topo <= innerHeight - livreTopo - 16 ? topo - livreTopo - 8 : topo - livreTopo;
    window.scrollBy({ top: delta, behavior: 'smooth' });
    await sleep(900);
    await esperarEstabilidade(1500);
  }

  const enviarSW = (msg) => chrome.runtime.sendMessage({ origem: 'Situacao_Fiscal', ...msg });

  // Captura a parte visível da aba (sem a seta nem o aviso) e salva como PDF pelo service worker.
  // regiao (opcional) = recorte em px da janela { x, y, w, h }; o service worker converte para os pixels da captura.
  async function capturarTelaPdf(caminho, regiao = null) {
    const sobrepostos = [cursor.el, document.getElementById(ID_AVISO)].filter(Boolean);
    sobrepostos.forEach((e) => { e.style.setProperty('visibility', 'hidden', 'important'); });
    await quadro(); await quadro(); await sleep(200);
    let r;
    try {
      r = await enviarSW({ tipo: 'capturar-pdf', filename: caminho, regiao, janela: { w: innerWidth, h: innerHeight } });
    } finally {
      sobrepostos.forEach((e) => e.style.removeProperty('visibility'));
    }
    if (!r || !r.ok) throw erroEtapa(`Etapa 10 (captura) — não consegui salvar ${caminho}: ${(r && r.erro) || 'sem resposta da extensão'}.`);
    return r;
  }

  // Avisos do service worker sobre o download preparado (certidão ou relatório: um por vez).
  // As mensagens se chamam "relatorio-*" por histórico; valem para qualquer documento.
  let ouvinteRelatorio = null;
  // Espera UM download. Dois gatilhos de falha (o primeiro que ocorrer encerra a espera — uma só recuperação):
  //  • o portal mostra o aviso de falha (ex.: "Não foi possível emitir a certidão…", código 043) ANTES de o download
  //    começar — não espera os 30 s;
  //  • o download não começa em TIMEOUT_INICIO_DOWNLOAD_MS.
  // Se o download já começou, acompanha até terminar (o aviso não interrompe). As falhas são "temporárias" do tipo
  // 'download': a extensão salva o estado, recarrega sozinha e tenta de novo só o documento que falta.
  function aguardarDownload(rotulo, textoBotao) {
    return new Promise((resolve, reject) => {
      let tInicio = null, tFim = null, vigia = null, iniciado = false, encerrado = false;
      const fim = (f, v) => {
        if (encerrado) return;
        encerrado = true;
        clearTimeout(tInicio); clearTimeout(tFim); clearInterval(vigia); ouvinteRelatorio = null; f(v);
      };
      tInicio = setTimeout(() => fim(reject, erroTemporario(`o download (${rotulo}) não começou em ${TIMEOUT_INICIO_DOWNLOAD_MS / 1000} s após "${textoBotao}"`, 'download')), TIMEOUT_INICIO_DOWNLOAD_MS);
      tFim = setTimeout(() => fim(reject, erroTemporario(`o download (${rotulo}) não terminou em ${TIMEOUT_DOWNLOAD_MS / 1000} s`, 'download')), TIMEOUT_DOWNLOAD_MS);
      vigia = setInterval(() => {
        if (iniciado) return;
        const falha = falhaTemporaria();
        if (falha) fim(reject, erroTemporario(falha, 'download'));
      }, 500);
      ouvinteRelatorio = (msg) => {
        if (msg.tipo === 'relatorio-iniciado') { iniciado = true; clearTimeout(tInicio); log(`download (${rotulo}) iniciado:`, msg.filename || ''); mostrarAviso(`Etapa 11: download (${rotulo}) em andamento…`); }
        if (msg.tipo === 'relatorio-salvo') fim(resolve, msg);
        if (msg.tipo === 'relatorio-erro') fim(reject, erroTemporario(`download (${rotulo}): ${msg.erro}`, 'download'));
      };
    });
  }

  // texto do botão sem ícones/símbolos (o portal põe um ícone de PDF antes do texto)
  const textoDoBotao = (e) => norm(e.textContent).replace(/[^a-z0-9 ]/g, '').trim();
  const botaoPorTexto = (t) => () => todos().find((e) => e.matches('button,[role=button],a') && textoDoBotao(e) === t && visivel(e)) || null;
  const botaoBaixarCertidao = botaoPorTexto('baixar certidao');
  const botaoBaixarRelatorio = botaoPorTexto('baixar relatorio');

  // Rolagem visível e gradual da página principal (acelera e desacelera).
  async function rolarGradual(destino) {
    const el = document.scrollingElement || document.documentElement;
    const y0 = el.scrollTop, alvo = clamp(destino, 0, el.scrollHeight - innerHeight);
    const dist = alvo - y0;
    if (Math.abs(dist) < 4) return;
    const duracao = clamp(600 + Math.abs(dist) * 1.4, 900, 4500) * LENTIDAO_MOUSE;
    const inicio = performance.now();
    for (;;) {
      conferir();
      const t = clamp((performance.now() - inicio) / duracao, 0, 1);
      el.scrollTop = y0 + dist * suave(t);
      if (t >= 1) break;
      await quadro();
    }
  }

  // Rola passando pelo Detalhamento da Análise até o rodapé, espera os controles e diz quais botões existem.
  async function rolarAteDownloads(ctx) {
    mostrarAviso('Etapa 11: rolando até os botões de download…');
    const el = document.scrollingElement || document.documentElement;
    const det = acharTextos('Detalhamento da Análise')[0];
    if (det) {
      await rolarGradual(el.scrollTop + det.getBoundingClientRect().top - alturaCabecalhoFixo() - 20);
      await sleep(600);
    }
    for (let i = 0; i < 3; i++) { // a página pode crescer enquanto carrega
      await rolarGradual(el.scrollHeight);
      await esperarEstabilidade(1500);
      if (el.scrollTop + innerHeight >= el.scrollHeight - 4) break;
    }
    // esperar() também acompanha "processando" e falhas do portal (viram recuperação, não erro)
    await esperar(() => botaoBaixarCertidao() || botaoBaixarRelatorio(), '11 (downloads)',
      `botão "Baixar Certidão" ou "Baixar Relatório" para ${ctx.documento}`, 15000);
    await esperarEstabilidade(1500);
    const disp = { certidao: !!botaoBaixarCertidao(), relatorio: !!botaoBaixarRelatorio() };
    log(`botões de download para ${ctx.documento}:`, disp);
    return disp;
  }

  // Um download por vez: prepara o destino no service worker, clica UMA vez e espera o arquivo terminar.
  // nome = nome fixo (certidão); sem nome = mantém o nome original do portal (relatório).
  async function baixarDocumento({ rotulo, textoBotao, botao, pasta, nome }) {
    await esperar(botao, `11 (${rotulo})`, `botão "${textoBotao}"`);
    const prep = await enviarSW({ tipo: 'preparar-relatorio', pasta, nome: nome || null });
    if (!prep || !prep.ok) throw erroTemporario(`não consegui preparar o download (${rotulo}): ${(prep && prep.erro) || 'sem resposta'}`, 'download');
    const espera = aguardarDownload(rotulo, textoBotao);
    espera.catch(() => {}); // tratado abaixo
    let r;
    try {
      await clicarEm(botao, `11 (${rotulo})`, `botão "${textoBotao}"`);
      r = await espera;
    } finally {
      enviarSW({ tipo: 'cancelar-relatorio' }).catch(() => {});
    }
    const final = String(r.filename || '').replace(/\\/g, '/');
    const esperado = nome ? `${pasta}/${nome}` : `${pasta}/`;
    if (!final.includes(esperado)) throw new Error(`o arquivo foi salvo como "${r.filename}", fora de "${esperado}"`);
    log(`arquivo salvo (${rotulo}):`, r.filename);
    return r.filename;
  }

  // Etapas 9 a 11, com o CNPJ confirmado DESTA execução (ctx.cnpjConfirmado) em todos os nomes e pastas.
  async function posRepresentacao(ctx) {
    const cnpj = ctx.cnpjConfirmado;
    if (acharPainel()) await fecharPainel();

    mostrarAviso(`Etapa 9: conferindo a página da empresa ${ctx.documento}…`);
    await esperar(() => { const d = lerDadosPagina(); return d && d.digitos === cnpj && d.status ? d : null; },
      '9 (conferir página)', `Dados Cadastrais com o CNPJ ${ctx.documento} e o Resultado da Análise`, TIMEOUT_PAGINA_MS);
    await esperarEstabilidade(3000);
    const d = lerDadosPagina();
    if (!d || d.digitos !== cnpj) throw erroEtapa(`Etapa 9 (conferir página) — a página deixou de mostrar o CNPJ ${ctx.documento}. Nada foi salvo.`);
    // 10. Resultado da Análise (status + mensagem, ex.: "Sem pendência" com débito a vencer)
    const pasta = pastaDaEmpresa(ctx, d.nome); // RFB_CNPJ/<nome da empresa>
    log(`pasta desta empresa: ${pasta}`);
    const res = { status: d.status, mensagem: d.mensagem, debitoAVencer: d.debitoAVencer, nome: d.nome, pasta };
    log('Resultado da Análise:', { empresa: d.nome, documento: d.documento, status: d.status, mensagem: d.mensagem, debitoAVencer: d.debitoAVencer });
    mostrarAviso(`Etapa 10: ${d.nome || ctx.documento} — "${d.status}"${d.debitoAVencer ? ' (há débito a vencer)' : ''}`);
    const ja = await lerParcial(cnpj); // o que já foi salvo numa tentativa anterior deste CNPJ (não baixa de novo)
    Object.assign(res, ja);
    if (/^com pendencia/.test(norm(d.status))) {
      if (ja.captura) {
        log('captura já salva antes:', ja.captura);
      } else {
        mostrarAviso(`Etapa 10: "${d.status}" — salvando a captura da tela em PDF…`);
        await mostrarBlocos();
        const cap = await capturarTelaPdf(`${pasta}/Com_Pendencia_${cnpj}.pdf`);
        res.captura = cap.filename;
        await gravarParcial(cnpj, { captura: cap.filename });
        log('captura salva:', cap.filename);
      }
    }
    await sleep(800);

    // 11. Rola até os downloads e baixa um documento por vez (certidão, depois relatório)
    const disp = await rolarAteDownloads(ctx);
    const documentos = [
      { chave: 'certidao', rotulo: 'certidão', textoBotao: 'Baixar Certidão', botao: botaoBaixarCertidao,
        pasta, nome: `RFB_${cnpj}.pdf` },
      { chave: 'relatorio', rotulo: 'relatório', textoBotao: 'Baixar Relatório', botao: botaoBaixarRelatorio,
        pasta: `${pasta}/${SUBPASTA_RELATORIO}`, nome: null },
    ];
    for (const doc of documentos) {
      if (!disp[doc.chave] && !doc.botao()) { log(`"${doc.textoBotao}" não está disponível para ${ctx.documento}`); continue; }
      if (ja[doc.chave]) { log(`arquivo já salvo antes (${doc.rotulo}):`, ja[doc.chave]); continue; }
      mostrarAviso(`Etapa 11: baixando ${doc.chave === 'certidao' ? 'a certidão' : 'o relatório'}…`);
      try {
        res[doc.chave] = await baixarDocumento(doc);
      } catch (e) {
        if (e.cancelada || e.temporario) throw e;
        throw erroEtapa(`Etapa 11 — ${doc.chave === 'certidao' ? 'a certidão' : 'o relatório'} de ${ctx.documento} ficou PENDENTE: ` +
          `${e.message}. Aperte F5 para retomar deste ponto (o que já foi salvo não será baixado de novo).`);
      }
      await gravarParcial(cnpj, { [doc.chave]: res[doc.chave] });
      await esperarEstabilidade(1500);
    }

    limparPendente();
    const arquivos = [res.captura, res.certidao, res.relatorio].filter(Boolean);
    mostrarAviso(`Concluído — ${ctx.documento} (${d.status}${d.debitoAVencer ? '; débito a vencer' : ''})\n` +
      arquivos.map((a) => `• ${a}`).join('\n'), 'ok');
    return res;
  }

  // A página recarregou logo depois do clique em "Representar": não clica de novo. Se a página já mostra a empresa
  // pedida, segue para as etapas 9 a 11; senão, só informa.
  async function depoisDaRecarga(p, ctx) {
    mostrarAviso('Representar já foi clicado; conferindo a empresa na página após a recarga…');
    const d = await esperar(() => { const x = lerDadosPagina(); return x && x.digitos ? x : null; },
      '8 (após recarga)', 'Dados Cadastrais com o CNPJ', TIMEOUT_PAGINA_MS);
    criarSeta();
    if (d.digitos !== ctx.digitos) {
      // A representação não pegou (a página voltou com a empresa anterior): repete o MESMO CNPJ, até o limite.
      const tentativas = p.tentativas || 1;
      if (tentativas >= MAX_TENTATIVAS_REPRESENTAR) {
        limparPendente();
        throw Object.assign(new Error(`a representação de ${ctx.documento} não pegou em ${tentativas} tentativas ` +
          `(após a recarga, a página mostra ${d.documento || '(sem CNPJ)'})`), { pularParaProximo: true });
      }
      log(`após a recarga, a página mostra ${d.documento || '(sem CNPJ)'} e não ${ctx.documento}; repetindo a representação (tentativa ${tentativas + 1}/${MAX_TENTATIVAS_REPRESENTAR})`);
      mostrarAviso(`A página voltou com ${d.documento || 'outra empresa'} em vez de ${ctx.documento}.\n` +
        `Repetindo a representação do mesmo CNPJ (tentativa ${tentativas + 1}/${MAX_TENTATIVAS_REPRESENTAR})…`, 'erro');
      await sleep(2500);
      return fluxo(ctx); // refaz perfil → Trocar Representação → CNPJ → Procurador → Representar
    }
    ctx.cnpjConfirmado = d.digitos;
    log(`após a recarga, a página mostra a empresa pedida (${d.documento}); seguindo`);
    return posRepresentacao(ctx);
  }

  function novoContexto(item, indice) {
    return { documento: item.documento, nome: item.nome, digitos: soDigitos(item.documento), indice, total: FILA.length, cnpjConfirmado: null };
  }

  // ------------------------------- lista de CNPJs e progresso -------------------------------
  // progresso = { concluidos: { "<dígitos>": { status, captura, relatorio, origem, t } } } em chrome.storage.local
  // um registro por pasta raiz (o da RFB_CNPJ, dos testes, fica guardado à parte e não interfere)
  const chaveDaPasta = (pasta) => (pasta === 'RFB_CNPJ' ? 'situacao_fiscal_progresso' : `situacao_fiscal_progresso:${pasta}`);
  let CHAVE_PROGRESSO = chaveDaPasta(PASTA_RAIZ);

  // Configuração da janela da extensão: { pasta, documentos: ['CNPJ;NOME', ...] }. Sem configuração salva, grava o
  // padrão deste arquivo (a janela abre preenchida com ele).
  const CHAVE_CONFIG = 'situacao_fiscal_config';
  let configPronta = false;
  async function carregarConfig() {
    if (!temStorage()) return;
    const r = await chrome.storage.local.get(CHAVE_CONFIG);
    const cfg = r[CHAVE_CONFIG];
    if (!cfg || !cfg.pasta || !Array.isArray(cfg.documentos) || !cfg.documentos.length) {
      await chrome.storage.local.set({ [CHAVE_CONFIG]: { pasta: PASTA_RAIZ, documentos: DOCUMENTOS, padrao: true, t: Date.now() } });
      log(`configuração padrão: pasta "${PASTA_RAIZ}", ${FILA.length} CNPJ(s)`);
      return;
    }
    PASTA_RAIZ = String(cfg.pasta);
    CHAVE_PROGRESSO = chaveDaPasta(PASTA_RAIZ);
    FILA = paraFila(cfg.documentos);
    log(`configuração da janela: pasta "${PASTA_RAIZ}", ${FILA.length} CNPJ(s)`);
  }
  let progressoMemoria = null; // usado só fora da extensão (teste)
  const temStorage = () => typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local;

  async function lerProgresso() {
    if (!temStorage()) { atualizarPlacar(progressoMemoria); return progressoMemoria; }
    const r = await chrome.storage.local.get(CHAVE_PROGRESSO);
    atualizarPlacar(r[CHAVE_PROGRESSO]);
    return r[CHAVE_PROGRESSO] || null;
  }
  async function gravarProgresso(p) {
    atualizarPlacar(p);
    if (!temStorage()) { progressoMemoria = p; return; }
    await chrome.storage.local.set({ [CHAVE_PROGRESSO]: p });
  }

  // Sem registro para esta pasta raiz: começa a lista do zero (os resultados dos testes em RFB_CNPJ não contam).
  async function carregarProgresso() {
    let p = await lerProgresso();
    if (p) return p;
    p = { concluidos: {} };
    log(`primeira execução com a pasta "${PASTA_RAIZ}": a lista começa do primeiro CNPJ`);
    await gravarProgresso(p);
    return p;
  }

  async function registrarConclusao(ctx, resultado) {
    const p = (await lerProgresso()) || { concluidos: {} };
    p.concluidos[ctx.digitos] = { ...resultado, documento: ctx.documento, origem: 'esta extensão', versao: 2, t: Date.now() };
    if (p.parciais) delete p.parciais[ctx.digitos];
    if (p.recuperacao && p.recuperacao.digitos === ctx.digitos) delete p.recuperacao;
    if (p.pendentes) delete p.pendentes[ctx.digitos];
    await gravarProgresso(p);
  }

  // ---- recuperação de falha temporária: guarda o estado, espera, recarrega e retoma o MESMO CNPJ ----
  // tentativa = 1, 2, 3… deste CNPJ
  function esperaIndicada(e, tentativa = 1) {
    const m = norm(e.message).match(/(\d+)\s*minuto/);
    if (m) return Number(m[1]) * 60000;
    if (e.tipoFalha === 'download') return tentativa <= 1 ? ESPERA_DOWNLOAD_1A_MS : ESPERA_FALHA_PORTAL_MS; // persistiu: alguns minutos
    return e.tipoFalha === 'portal' ? ESPERA_FALHA_PORTAL_MS : ESPERA_CARREGAMENTO_MS;
  }
  const limiteRecargas = (e) => (e.tipoFalha === 'download' ? MAX_RECARGAS_DOWNLOAD : MAX_RECARGAS_POR_CNPJ);

  // Marca o CNPJ como PENDENTE (arquivos já salvos continuam registrados) para nova tentativa no fim da lista.
  async function registrarPendente(ctx, e) {
    const p = (await lerProgresso()) || { concluidos: {} };
    p.pendentes = p.pendentes || {};
    p.pendentes[ctx.digitos] = { documento: ctx.documento, nome: ctx.nome, etapa: etapaAtual, motivo: e.message,
      arquivos: (p.parciais || {})[ctx.digitos] || {}, t: Date.now() };
    if (p.recuperacao && p.recuperacao.digitos === ctx.digitos) delete p.recuperacao;
    await gravarProgresso(p);
    limparPendente();
  }
  const mmss = (ms) => { const s = Math.ceil(ms / 1000); return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`; };

  let recuperacaoEmCurso = false; // uma única recarga por tentativa, mesmo se dois gatilhos dispararem
  async function recuperarFalha(ctx, e) {
    if (recuperacaoEmCurso) { log('recuperação já em andamento; segundo gatilho ignorado:', e.message); return; }
    recuperacaoEmCurso = true;
    const p = (await lerProgresso()) || { concluidos: {} };
    const rec = p.recuperacao && p.recuperacao.digitos === ctx.digitos ? p.recuperacao : { digitos: ctx.digitos, tentativas: 0 };
    rec.tentativas += 1;
    Object.assign(rec, { documento: ctx.documento, etapa: etapaAtual, motivo: e.message,
      arquivos: (p.parciais || {})[ctx.digitos] || {}, t: Date.now() });
    limparPendente(); // depois do F5 o fluxo normal confere a Representação Atual (não clica às cegas)
    const limite = limiteRecargas(e);
    if (rec.tentativas > limite) {
      // fica PENDENTE para nova tentativa; os arquivos já salvos (parciais) continuam registrados para a retomada
      p.pendentes = p.pendentes || {};
      p.pendentes[ctx.digitos] = { documento: ctx.documento, nome: ctx.nome, etapa: rec.etapa, motivo: e.message, arquivos: rec.arquivos, t: Date.now() };
      delete p.recuperacao;
      await gravarProgresso(p);
      mostrarAviso(`${ctx.documento} ficou PENDENTE após ${limite} recargas (${rec.etapa || 'etapa desconhecida'}):\n"${e.message}"\nSeguindo para o próximo CNPJ…`, 'erro');
      await sleep(5000);
    } else {
      p.recuperacao = rec;
      await gravarProgresso(p);
      const espera = esperaIndicada(e, rec.tentativas);
      const ate = Date.now() + espera;
      log(`falha temporária (${e.tipoFalha}) em ${ctx.documento} (${rec.etapa}); tentativa ${rec.tentativas}/${limite}; ` +
        `espera ${Math.round(espera / 1000)} s; arquivos já salvos:`, rec.arquivos, '— motivo:', e.message);
      const titulo = e.tipoFalha === 'processando' ? 'Portal ainda em processamento'
        : e.tipoFalha === 'download' ? 'Falha ao baixar o documento (será tentado de novo)' : 'Falha temporária do portal';
      while (Date.now() < ate) {
        if (!URL_ALVO.test(location.href)) return; // saiu da página: não recarrega
        mostrarAviso(`${titulo} — ${ctx.documento}\n"${e.message}"\n${rec.etapa ? `Parou em: ${rec.etapa}. ` : ''}` +
          `Tentativa ${rec.tentativas}/${limite}: recarregando em ${mmss(ate - Date.now())}…`, 'erro');
        await sleep(1000);
      }
    }
    if (URL_ALVO.test(location.href)) location.reload();
  }

  // Arquivos já salvos de um CNPJ ainda não concluído: { captura?, certidao?, relatorio? } (retomada sem duplicar).
  async function lerParcial(digitos) {
    const p = (await lerProgresso()) || {};
    return { ...((p.parciais || {})[digitos] || {}) };
  }
  async function gravarParcial(digitos, novo) {
    const p = (await lerProgresso()) || { concluidos: {} };
    p.parciais = p.parciais || {};
    p.parciais[digitos] = { ...(p.parciais[digitos] || {}), ...novo };
    await gravarProgresso(p);
  }

  // Conclusões das versões anteriores com "Sem pendência" e nenhum documento baixado não valem mais
  // (antes a extensão encerrava sem olhar os botões de download): esses CNPJs são processados de novo.
  const concluidoValido = (c) => !!c && (c.versao >= 2 || c.status === 'Erro de procuração' || !!c.relatorio || !!c.certidao);
  // próximo CNPJ: nem concluído nem PENDENTE nesta rodada (os pendentes voltam na próxima execução)
  const proximoIndice = (p) => FILA.findIndex((f) => {
    const d = soDigitos(f.documento);
    return !concluidoValido(p.concluidos[d]) && !(p.pendentes && p.pendentes[d]);
  });

  // Intervalo entre empresas: conta a partir da conclusão; espera também a página parar de carregar.
  async function aguardarIntervalo() {
    const inicio = Date.now();
    for (;;) {
      conferir();
      const falta = INTERVALO_ENTRE_EMPRESAS_MS - (Date.now() - inicio);
      const carregando = carregandoVisiveis().length > 0;
      if (falta <= 0 && !carregando) break;
      if (Date.now() - inicio > INTERVALO_ENTRE_EMPRESAS_MS + TIMEOUT_CARREGANDO_MS) break; // não trava a fila para sempre
      log(falta > 0 ? `intervalo entre empresas: ${Math.ceil(falta / 1000)} s` : 'aguardando a página terminar de carregar');
      await sleep(1000);
    }
  }

  async function iniciar(motivo) {
    if (execucao) { log(`já há uma execução nesta aba; ignorando (${motivo})`); return; }
    if (concluidaNestaVisita) { log(`fluxo já concluído nesta visita; ignorando (${motivo})`); return; }
    execucao = { cancelada: false };
    const minha = execucao;
    log(`iniciando (${motivo})`);
    let ctxAtual = null;
    try {
      let pendente = lerPendente();
      // marca de "Representar já clicado" de um CNPJ que não está na lista atual (a lista mudou na janela): ignora
      if (pendente && !FILA.some((f) => soDigitos(f.documento) === soDigitos(pendente.documento))) {
        log(`marca de representação de ${pendente.documento} ignorada: não está na lista atual`);
        limparPendente();
        pendente = null;
      }
      let progresso = await carregarProgresso();
      for (const [dig, c] of Object.entries(progresso.concluidos)) {
        if (!FILA.some((f) => soDigitos(f.documento) === dig)) continue;
        if (concluidoValido(c)) log(`${dig} já concluído (${c.status || c.origem}${c.relatorio ? `: ${c.relatorio}` : ''})`);
        else log(`${dig} será processado de novo: a conclusão anterior ("${c.status}") não verificou os botões de download`);
      }
      if (progresso.recuperacao) {
        const r = progresso.recuperacao;
        log(`retomando ${r.documento} após falha temporária (tentativa ${r.tentativas}/${MAX_RECARGAS_POR_CNPJ}); parou em ${r.etapa || '?'}; já salvos:`, r.arquivos);
      }
      // um CNPJ por vez; ao concluir, avança UMA vez para o próximo; termina após o último
      for (;;) {
        conferir();
        progresso = (await lerProgresso()) || progresso;
        const i = pendente ? FILA.findIndex((f) => soDigitos(f.documento) === soDigitos(pendente.documento)) : proximoIndice(progresso);
        if (i < 0) {
          limparPendente();
          const pend = Object.values(progresso.pendentes || {});
          if (pend.length && (progresso.rodadaPendentes || 0) < RODADAS_PENDENTES) {
            // fim da lista com pendentes: tenta esses de novo, na mesma execução
            progresso.rodadaPendentes = (progresso.rodadaPendentes || 0) + 1;
            delete progresso.pendentes;
            await gravarProgresso(progresso);
            log(`fim da lista: nova tentativa (${progresso.rodadaPendentes}/${RODADAS_PENDENTES}) dos pendentes:`, pend.map((x) => x.documento));
            mostrarAviso(`Fim da lista — tentando de novo ${pend.length} CNPJ(s) pendente(s)…`);
            await aguardarIntervalo();
            continue;
          }
          delete progresso.rodadaPendentes;
          if (pend.length) {
            // pendentes voltam na próxima execução (F5)
            delete progresso.pendentes;
            await gravarProgresso(progresso);
            mostrarAviso(`Lista concluída com ${pend.length} CNPJ(s) PENDENTE(S) por falha do portal:\n` +
              pend.map((x) => `• ${x.documento} (${x.etapa || '?'}): ${x.motivo}`).join('\n') +
              '\nAperte F5 mais tarde para tentar de novo só esses.', 'erro');
          } else {
            await gravarProgresso(progresso);
            mostrarAviso(`Lista concluída: ${FILA.length} CNPJ(s) processado(s). Execução encerrada.`, 'ok');
          }
          break;
        }
        // cada CNPJ começa com os PRÓPRIOS dados (nada do CNPJ anterior)
        const ctx = novoContexto(FILA[i], i);
        ctxAtual = ctx;
        const rotulo = `${ctx.documento}${ctx.nome ? ` — ${ctx.nome}` : ''}`;
        log(`CNPJ ${i + 1}/${FILA.length}: ${rotulo} (${ctx.digitos})`);
        mostrarAviso(`CNPJ ${i + 1}/${FILA.length}: ${rotulo}`);
        await sleep(800);
        let resultado;
        try {
          resultado = pendente ? await depoisDaRecarga(pendente, ctx) : await fluxo(ctx);
        } catch (e) {
          // portal "processando" por tempo demais: este CNPJ fica PENDENTE e a fila segue (sem recarregar)
          const processando = e.temporario && e.tipoFalha === 'processando';
          if (!processando && !e.pularParaProximo) throw e;
          pendente = null;
          await registrarPendente(ctx, e);
          log(`${ctx.documento} PENDENTE (${e.message}); seguindo para o próximo CNPJ`);
          mostrarAviso(`${ctx.documento} — ${processando ? `portal ainda em processamento após ${Math.round(ESPERA_PROCESSANDO_NA_PAGINA_MS / 1000)} s` : e.message}.\n` +
            'Ficou PENDENTE (nova tentativa no fim da lista). Seguindo para o próximo CNPJ…', 'erro');
          ctxAtual = null;
          await aguardarIntervalo();
          continue;
        }
        pendente = null;
        await registrarConclusao(ctx, resultado);
        log(`CNPJ ${i + 1}/${FILA.length} concluído: ${ctx.documento} — ${resultado.status}`);
        ctxAtual = null;
        progresso = (await lerProgresso()) || progresso;
        if (proximoIndice(progresso) >= 0) await aguardarIntervalo(); // ≥ 5 s antes de abrir o perfil de novo
      }
      concluidaNestaVisita = true;
    } catch (e) {
      if (e.cancelada) log('execução cancelada (saiu da página)');
      else if (e.temporario && ctxAtual) {
        // falha temporária: guarda o estado, espera e recarrega (o finally libera a execução antes do F5)
        const ctxFalha = ctxAtual;
        setTimeout(() => recuperarFalha(ctxFalha, e).catch((x) => mostrarAviso(`Erro na recuperação: ${x.message}`, 'erro')), 0);
      } else {
        limparPendente();
        if (e.etapaMsg || e instanceof ErroEtapa || /^Etapa \d/.test(e.message)) mostrarAviso(e.message, e.tipo || 'erro');
        else mostrarAviso(`Erro inesperado: ${e && e.message}`, 'erro');
      }
    } finally {
      if (execucao === minha) execucao = null;
    }
  }

  function cancelar() {
    if (execucao) execucao.cancelada = true;
    concluidaNestaVisita = false;
  }

  function verificarUrl(motivo = 'mudança de URL') {
    if (!configPronta) return; // só começa depois de ler a pasta e a lista da janela da extensão
    const noAlvo = URL_ALVO.test(location.href);
    if (noAlvo && !estavaNoAlvo) { estavaNoAlvo = true; iniciar(motivo); }
    else if (!noAlvo && estavaNoAlvo) {
      estavaNoAlvo = false;
      if (execucao && execucao.aguardandoResposta) {
        // a marca de "Representar já clicado" fica guardada: se o portal voltar a esta página, não clica de novo
        mostrarAviso(`Resposta do portal: navegou para ${location.href}`, 'ok');
      }
      cancelar();
    }
  }

  window.addEventListener('hashchange', () => verificarUrl('hashchange'));
  window.addEventListener('popstate', () => verificarUrl('popstate'));
  setInterval(() => verificarUrl('vigia da URL'), INTERVALO_URL_MS);
  try {
    chrome.runtime.onMessage.addListener((msg) => {
      if (!msg || msg.origem !== 'Situacao_Fiscal') return;
      if (/^relatorio-/.test(msg.tipo || '')) { if (ouvinteRelatorio) ouvinteRelatorio(msg); return; }
      if (msg.tipo === 'url-mudou') verificarUrl('navegação no portal');
      // (o ícone da extensão agora abre a janela de configuração; zerar o progresso é feito por lá)
    });
  } catch (_) { /* fora da extensão (teste) */ }

  carregarConfig()
    .catch((e) => log('não consegui ler a configuração da janela; usando o padrão:', e && e.message))
    .finally(() => { configPronta = true; verificarUrl('página aberta'); });
})();
```

---

## `Situacao_Fiscal/popup.html`

**Arquivo:** `popup.html` · **Caminho:** `Autom_Situacao_Fiscal/Situacao_Fiscal/popup.html` · 79 linhas · 4692 bytes — Janela da extensão (ícone): pasta de destino e lista de CNPJs

```html
<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<title>Situacao_Fiscal</title>
<style>
  :root { --azul: #1f4e79; --verde: #1e7b3a; --verm: #b03a2e; --borda: #c9d3de; --fundo: #f6f8fb; --texto: #1d2733; --cinza: #5b6b7c; }
  * { box-sizing: border-box; }
  body { margin: 0; width: 440px; font: 13px/1.45 Arial, sans-serif; color: var(--texto); background: #fff; }
  header { background: var(--azul); color: #fff; padding: 10px 14px; display: flex; justify-content: space-between; align-items: baseline; }
  header h1 { margin: 0; font-size: 15px; }
  header span { font-size: 11px; opacity: .85; }
  main { padding: 12px 14px 14px; }
  .aviso { border: 1px solid #e0b400; background: #fff8d6; border-radius: 6px; padding: 9px 11px; margin-bottom: 12px; }
  .aviso strong { display: block; margin-bottom: 3px; }
  .estado { margin-top: 7px; font-weight: bold; }
  .estado.ok { color: var(--verde); }
  .estado.nao { color: var(--verm); }
  label { display: block; font-weight: bold; margin: 10px 0 4px; }
  .dica { color: var(--cinza); font-size: 11.5px; margin-top: 3px; }
  input[type=text], textarea { width: 100%; border: 1px solid var(--borda); border-radius: 5px; padding: 7px 8px; font: inherit; color: inherit; }
  textarea { height: 170px; resize: vertical; font: 12px/1.4 Consolas, monospace; white-space: pre; }
  input:focus, textarea:focus { outline: 2px solid #8fb4dc; border-color: var(--azul); }
  .contagem { margin-top: 5px; font-size: 12px; }
  .contagem .bom { color: var(--verde); font-weight: bold; }
  .contagem .ruim { color: var(--verm); font-weight: bold; }
  .erros { color: var(--verm); font-size: 11.5px; margin: 4px 0 0; padding-left: 16px; max-height: 70px; overflow: auto; }
  .progresso { background: var(--fundo); border: 1px solid var(--borda); border-radius: 6px; padding: 8px 10px; margin-top: 12px; }
  .barra { height: 8px; background: #dde5ee; border-radius: 4px; margin-top: 5px; overflow: hidden; }
  .barra i { display: block; height: 100%; width: 0; background: var(--verde); }
  .botoes { display: flex; gap: 8px; margin-top: 12px; }
  button { font: inherit; border-radius: 5px; padding: 8px 12px; cursor: pointer; border: 1px solid var(--azul); }
  button.prim { background: var(--azul); color: #fff; flex: 1; font-weight: bold; }
  button.sec { background: #fff; color: var(--azul); }
  button.perigo { background: #fff; color: var(--verm); border-color: var(--verm); }
  button.perigo.confirmar { background: var(--verm); color: #fff; }
  button:disabled { opacity: .5; cursor: default; }
  .msg { margin-top: 10px; font-size: 12px; min-height: 16px; }
  .msg.ok { color: var(--verde); } .msg.erro { color: var(--verm); }
  a { color: var(--azul); }
</style>
</head>
<body>
<header><h1>Situacao_Fiscal</h1><span id="versao"></span></header>
<main>
  <div class="aviso">
    <strong>⚠ Antes de iniciar</strong>
    Entre no <b>e-CAC</b> com o certificado e deixe aberta a página <b>Minhas Dívidas e Pendências</b>.
    A automação só roda nessa página.
    <div id="estadoPagina" class="estado">Procurando a página…</div>
    <div id="abrirPagina" hidden style="margin-top:6px"><button class="sec" id="btnAbrir" type="button">Abrir Minhas Dívidas e Pendências</button></div>
  </div>

  <label for="pasta">Pasta de destino dos downloads</label>
  <input type="text" id="pasta" placeholder="ex.: Situacao_Fiscal_Assecon/PRISCILLA_ASSECON" spellcheck="false">
  <div class="dica" id="caminho">Fica dentro da pasta Downloads. Use "/" para criar subpastas.</div>

  <label for="cnpjs">CNPJs (um por linha)</label>
  <textarea id="cnpjs" spellcheck="false" placeholder="00.351.766/0001-10;OXIL GASES EQUIPAMENTOS COMERCIO LTDA.&#10;02105151000130;CONSTRUTORA FIBRA LTDA&#10;02.106.023/0001-00"></textarea>
  <div class="dica">Formato: <b>CNPJ</b> ou <b>CNPJ;NOME DA EMPRESA</b> (o nome vira o nome da pasta). Pode colar do Excel (CNPJ e nome em duas colunas).</div>
  <div class="contagem" id="contagem"></div>
  <ul class="erros" id="erros" hidden></ul>

  <div class="progresso">
    <div id="progressoTexto">Nesta pasta: —</div>
    <div class="barra"><i id="progressoBarra"></i></div>
  </div>

  <div class="botoes">
    <button class="prim" id="btnIniciar" type="button">Salvar e iniciar</button>
    <button class="perigo" id="btnZerar" type="button" title="Apaga o registro de concluídos desta pasta (os arquivos salvos ficam)">Zerar progresso</button>
  </div>
  <div class="dica">"Salvar e iniciar" recarrega a página do portal. Se uma lista estiver rodando com a mesma pasta, ela continua de onde parou.</div>
  <div class="msg" id="msg"></div>
</main>
<script src="popup.js"></script>
</body>
</html>
```

---

## `Situacao_Fiscal/popup.js`

**Arquivo:** `popup.js` · **Caminho:** `Autom_Situacao_Fiscal/Situacao_Fiscal/popup.js` · 179 linhas · 8600 bytes — Validação e gravação da configuração da janela

```javascript
// Situacao_Fiscal — janela da extensão (clique no ícone): pasta de destino + lista de CNPJs.
// Grava em chrome.storage.local['situacao_fiscal_config'] = { pasta, documentos: ['CNPJ;NOME', ...], t }.
// O content.js lê essa configuração ao abrir a página do portal.
'use strict';

const CHAVE_CONFIG = 'situacao_fiscal_config';
const URL_PAGINA = 'https://servicos.receitafederal.gov.br/servico/pendencias/#/analise-pendencias';
const RE_PAGINA = /^https:\/\/servicos\.receitafederal\.gov\.br\/servico\/pendencias\/?#\/analise-pendencias/;
const $ = (id) => document.getElementById(id);
const soDigitos = (s) => String(s || '').replace(/\D/g, '');

// ---------------- validação ----------------
function cnpjValido(d) {
  if (!/^\d{14}$/.test(d) || /^(\d)\1{13}$/.test(d)) return false;
  const dv = (base) => {
    let soma = 0, peso = base.length - 7;
    for (const c of base) { soma += Number(c) * peso; peso = peso === 2 ? 9 : peso - 1; }
    const r = soma % 11;
    return r < 2 ? 0 : 11 - r;
  };
  const d1 = dv(d.slice(0, 12));
  const d2 = dv(d.slice(0, 12) + d1);
  return d.endsWith(`${d1}${d2}`);
}
const formatarCnpj = (d) => `${d.slice(0, 2)}.${d.slice(2, 5)}.${d.slice(5, 8)}/${d.slice(8, 12)}-${d.slice(12)}`;

// Nome de pasta aceito pelo Windows: sem <>:"|?*, sem "." ou ".." e sem ponto/espaço no fim de cada parte.
function limparPasta(texto) {
  const partes = String(texto || '').split(/[\\/]+/)
    .map((p) => p.replace(/[<>:"|?*\u0000-\u001f]/g, '_').trim().replace(/[. ]+$/, ''))
    .filter((p) => p && p !== '.' && p !== '..');
  return partes.join('/');
}

// Cada linha: "CNPJ", "CNPJ;NOME" ou "CNPJ<TAB>NOME" (colado do Excel). O Excel tira os zeros à esquerda:
// com 12 ou 13 dígitos, completa com zeros e aceita se os dígitos verificadores baterem.
function lerLista(texto) {
  const itens = [], erros = [], vistos = new Set();
  let repetidos = 0;
  String(texto || '').split(/\r?\n/).forEach((linha, i) => {
    if (!linha.trim()) return;
    const m = linha.match(/^\s*([^;\t]*)[;\t]?(.*)$/);
    const bruto = m[1].trim();
    const nome = m[2].replace(/[;\t]+/g, ' ').replace(/\s+/g, ' ').trim();
    let d = soDigitos(bruto);
    if (d.length >= 12 && d.length < 14) d = d.padStart(14, '0');
    if (!/^[\d.\-/\s]+$/.test(bruto) || !cnpjValido(d)) { erros.push(`Linha ${i + 1}: "${bruto || linha.trim()}" não é um CNPJ válido`); return; }
    if (vistos.has(d)) { repetidos += 1; return; }
    vistos.add(d);
    itens.push(nome ? `${formatarCnpj(d)};${nome}` : formatarCnpj(d));
  });
  return { itens, erros, repetidos };
}

// ---------------- progresso (mesma regra do content.js) ----------------
const chaveProgresso = (pasta) => (pasta === 'RFB_CNPJ' ? 'situacao_fiscal_progresso' : `situacao_fiscal_progresso:${pasta}`);
const concluidoValido = (c) => !!c && (c.versao >= 2 || c.status === 'Erro de procuração' || !!c.relatorio || !!c.certidao);

async function mostrarProgresso() {
  const pasta = limparPasta($('pasta').value);
  const { itens } = lerLista($('cnpjs').value);
  if (!pasta || !itens.length) { $('progressoTexto').textContent = 'Nesta pasta: —'; $('progressoBarra').style.width = '0'; return; }
  const r = await chrome.storage.local.get(chaveProgresso(pasta));
  const p = r[chaveProgresso(pasta)] || { concluidos: {} };
  let feitos = 0, pend = 0;
  for (const item of itens) {
    const d = soDigitos(item.split(';')[0]);
    if (concluidoValido((p.concluidos || {})[d])) feitos += 1;
    else if (p.pendentes && p.pendentes[d]) pend += 1;
  }
  const pct = Math.floor((feitos / itens.length) * 100);
  $('progressoTexto').textContent = `Nesta pasta: ${feitos} de ${itens.length} analisados (${pct}%) · faltam ${itens.length - feitos}` +
    (pend ? ` (${pend} pendente${pend > 1 ? 's' : ''})` : '');
  $('progressoBarra').style.width = `${pct}%`;
}

// ---------------- tela ----------------
function atualizarTela() {
  const pasta = limparPasta($('pasta').value);
  $('caminho').textContent = pasta
    ? `Os arquivos vão para: Downloads\\${pasta.replace(/\//g, '\\')}\\<NOME DA EMPRESA>\\`
    : 'Fica dentro da pasta Downloads. Use "/" para criar subpastas.';
  const { itens, erros, repetidos } = lerLista($('cnpjs').value);
  $('contagem').innerHTML = '';
  const bom = document.createElement('span');
  bom.className = 'bom';
  bom.textContent = `${itens.length} CNPJ(s) válido(s)`;
  $('contagem').append(bom);
  if (repetidos) $('contagem').append(` · ${repetidos} repetido(s) ignorado(s)`);
  if (erros.length) {
    const ruim = document.createElement('span');
    ruim.className = 'ruim';
    ruim.textContent = ` · ${erros.length} com erro`;
    $('contagem').append(ruim);
  }
  $('erros').hidden = !erros.length;
  $('erros').replaceChildren(...erros.slice(0, 50).map((e) => { const li = document.createElement('li'); li.textContent = e; return li; }));
  $('btnIniciar').disabled = !pasta || !itens.length || erros.length > 0;
  mostrarProgresso().catch(() => {});
  desarmarZerar();
}

function mensagem(texto, tipo = '') { $('msg').className = `msg ${tipo}`; $('msg').textContent = texto; }

async function abaDoPortal() {
  const abas = await chrome.tabs.query({ url: 'https://servicos.receitafederal.gov.br/servico/pendencias/*' });
  return abas.find((a) => RE_PAGINA.test(a.url || '')) || null;
}

async function mostrarEstadoPagina() {
  const aba = await abaDoPortal().catch(() => null);
  $('estadoPagina').className = `estado ${aba ? 'ok' : 'nao'}`;
  $('estadoPagina').textContent = aba ? '✔ Página aberta — pronta para iniciar.' : '✖ A página não está aberta no Chrome.';
  $('abrirPagina').hidden = !!aba;
  return aba;
}

async function salvarEIniciar() {
  const pasta = limparPasta($('pasta').value);
  const { itens, erros } = lerLista($('cnpjs').value);
  if (!pasta) return mensagem('Informe a pasta de destino.', 'erro');
  if (!itens.length) return mensagem('Informe pelo menos um CNPJ.', 'erro');
  if (erros.length) return mensagem('Corrija os CNPJs com erro antes de iniciar.', 'erro');
  await chrome.storage.local.set({ [CHAVE_CONFIG]: { pasta, documentos: itens, t: Date.now() } });
  $('pasta').value = pasta;
  const aba = await mostrarEstadoPagina();
  if (!aba) {
    mensagem('Configuração salva. Abra o e-CAC e a página Minhas Dívidas e Pendências: a automação começa sozinha.', 'erro');
    return;
  }
  await chrome.tabs.update(aba.id, { active: true });
  await chrome.windows.update(aba.windowId, { focused: true }).catch(() => {});
  await chrome.tabs.reload(aba.id);
  mensagem(`Salvo: ${itens.length} CNPJ(s) em Downloads\\${pasta.replace(/\//g, '\\')}. Iniciando na página do portal…`, 'ok');
  setTimeout(() => window.close(), 1800);
}

// Zerar pede dois cliques (o 2º confirma) e só apaga o registro desta pasta; os arquivos já salvos continuam.
let zerarArmado = null;
function desarmarZerar() {
  clearTimeout(zerarArmado); zerarArmado = null;
  $('btnZerar').classList.remove('confirmar');
  $('btnZerar').textContent = 'Zerar progresso';
}
async function zerar() {
  const pasta = limparPasta($('pasta').value);
  if (!pasta) return mensagem('Informe a pasta cujo progresso será zerado.', 'erro');
  if (!zerarArmado) {
    $('btnZerar').classList.add('confirmar');
    $('btnZerar').textContent = 'Confirmar?';
    mensagem(`Clique de novo para zerar o progresso de "${pasta}" (a lista recomeça do 1º CNPJ; os arquivos ficam).`, 'erro');
    zerarArmado = setTimeout(desarmarZerar, 5000);
    return;
  }
  desarmarZerar();
  await chrome.storage.local.set({ [chaveProgresso(pasta)]: { concluidos: {} } });
  await mostrarProgresso();
  mensagem(`Progresso de "${pasta}" zerado. Clique em "Salvar e iniciar" para começar do 1º CNPJ.`, 'ok');
}

async function iniciarTela() {
  $('versao').textContent = `v${chrome.runtime.getManifest().version}`;
  const r = await chrome.storage.local.get(CHAVE_CONFIG);
  const cfg = r[CHAVE_CONFIG];
  if (cfg) {
    $('pasta').value = cfg.pasta || '';
    $('cnpjs').value = (cfg.documentos || []).join('\n');
  }
  atualizarTela();
  await mostrarEstadoPagina();
  $('pasta').addEventListener('input', atualizarTela);
  $('cnpjs').addEventListener('input', atualizarTela);
  $('btnIniciar').addEventListener('click', () => salvarEIniciar().catch((e) => mensagem(`Erro: ${e.message}`, 'erro')));
  $('btnZerar').addEventListener('click', () => zerar().catch((e) => mensagem(`Erro: ${e.message}`, 'erro')));
  $('btnAbrir').addEventListener('click', () => chrome.tabs.create({ url: URL_PAGINA }));
}

iniciarTela().catch((e) => mensagem(`Erro: ${e.message}`, 'erro'));
```

---

## `Situacao_Fiscal/LEIA-ME.md`

**Arquivo:** `LEIA-ME.md` · **Caminho:** `Autom_Situacao_Fiscal/Situacao_Fiscal/LEIA-ME.md` · 182 linhas · 12786 bytes — Manual detalhado da extensão

````markdown
# Situacao_Fiscal — versão 1.1.1

## Janela da extensão (clique no ícone)

Mostra um aviso, lembrando que é preciso **entrar no e-CAC e deixar aberta a página Minhas Dívidas e Pendências**,
e diz se essa página está aberta no Chrome. Se não estiver, oferece o botão para abri-la. Na janela:

- **Pasta de destino dos downloads:** fica sempre dentro de Downloads. Use `/` para criar subpastas, por exemplo
  `Situacao_Fiscal_Assecon/PRISCILLA_ASSECON`. Os caracteres que o Windows não aceita viram `_`.
- **CNPJs:** um por linha, no formato `CNPJ` ou `CNPJ;NOME DA EMPRESA` (o nome vira o nome da pasta). Pode colar do
  Excel, com o CNPJ e o nome em duas colunas. O CNPJ é conferido pelos dígitos verificadores. Os repetidos são
  ignorados. Se o Excel tirou os zeros à esquerda, eles são repostos.
- **Placar da pasta:** quantos já foram analisados e quantos faltam.
- **Salvar e iniciar:** grava a configuração e recarrega a página do portal, e a lista começa ou continua. Cada pasta
  tem o próprio progresso: numa pasta nova, começa do 1º CNPJ; na mesma pasta, continua de onde parou.
- **Zerar progresso:** precisa de dois cliques. Apaga só o registro de concluídos da pasta; os arquivos continuam.

A configuração fica em `chrome.storage.local['situacao_fiscal_config']`. Sem configuração salva, valem a lista
`DOCUMENTOS` e a `PASTA_RAIZ` do `content.js`, gravadas como padrão na primeira vez.

**Rodada atual (certificado da Priscilla):** os 208 CNPJs vão para `Situacao_Fiscal_Assecon/PRISCILLA_ASSECON`. A 1ª
rodada, com o certificado da Assecon, está em `Situacao_Fiscal_Assecon\ASSECON HUB CONTABILIDADE\`.

**Placar:** o aviso no canto inferior esquerdo mostra sempre, no topo, quantos CNPJs da lista já foram analisados e
quantos faltam, com uma barra de progresso. Ex.: `Analisados: 207 de 208 (99%) · Faltam: 1 (1 pendente)`. "Analisado"
é o CNPJ concluído, inclusive o erro de procuração com evidência salva.

Processa uma **lista de CNPJs**, um por vez. Para cada um, na página **Minhas Dívidas e Pendências**
(`https://servicos.receitafederal.gov.br/servico/pendencias/#/analise-pendencias`):

1. reconhece a tela (título + blocos **Dados Cadastrais** e **Resultado da Análise**) e registra a estrutura no console;
2. aceita os cookies, se o aviso estiver visível (um único clique em **Aceitar**);
3. abre o perfil no canto superior direito (avatar + identificação + seta);
4. confirma o painel lateral (**Representar** e **Representações Recentes**);
5. digita o CPF/CNPJ em **Digite o CPF ou CNPJ** (só os dígitos; a máscara do portal formata) e confere o valor;
6. abre **Digite um perfil de representação** e escolhe a opção com texto exatamente **Procurador**;
7. espera o botão azul **Representar** habilitar e clica uma única vez;
8. espera **Representação Atual** e compara o CNPJ ao lado de "Procurador de:" com o pedido. Se divergir, para sem salvar.
   Se o portal **recusar** (ex.: "Sua autorização como procurador não permite acesso a este serviço."), confere o CNPJ
   no campo, recorta da seção **Trocar Representação** até o campo **Procurador** (CNPJ, mensagem e perfil; sem o
   botão), salva o PDF de evidência e segue para o próximo CNPJ;
   Se a empresa **já estiver** em Representação Atual (ex.: retomada após F5), não representa de novo e vai à etapa 9.
   A extensão **nunca encerra uma representação**: se aparecer a confirmação "Encerrar representação — Você tem
   certeza…?", clica em **Cancelar** e continua o processo de onde estava. O CNPJ da própria conta logada
   (`10.754.473/0001-38`) segue o fluxo normal de Trocar Representação; se o portal recusar, salva a evidência;
9. fecha o painel com um clique no fundo escurecido e confere que a página mostra o CNPJ representado;
10. lê o **status** e a **mensagem** do Resultado da Análise (registra, por exemplo, "débito a vencer"). Se for
    **Com pendência**, captura a tela e salva em PDF antes de rolar;
11. em **qualquer** status, rola a página de forma gradual (passando pelo Detalhamento da Análise) até os botões do
    rodapé, vê quais existem e baixa **um por vez**: **Baixar Certidão** → `RFB_<CNPJ>.pdf`, depois
    **Baixar Relatório** → nome original. Só avança para o próximo CNPJ com os arquivos confirmados.

**Falha no download (certidão ou relatório)** — a própria extensão recarrega e tenta de novo, sem F5 manual:

- gatilhos: o portal mostra um aviso de falha (ex.: "Não foi possível emitir a certidão. Tente novamente daqui alguns
  minutos", código **043**) antes de o download começar, **ou** o download não começa em 30 s após o clique;
- o primeiro gatilho encerra a tentativa e dispara **uma única** recarga. Antes do F5, a extensão guarda o CNPJ, a
  etapa e os arquivos já salvos;
- depois do F5, confere o mesmo CNPJ (Representação Atual e Dados Cadastrais) e baixa **só o documento que falta**.
  Um documento só conta como salvo quando o download termina. Se o download já começou, a extensão acompanha até o
  fim;
- espera antes da recarga: 15 s na 1ª (`ESPERA_DOWNLOAD_1A_MS`); se persistir, 2 min ("alguns minutos",
  `ESPERA_FALHA_PORTAL_MS`). No máximo `MAX_RECARGAS_DOWNLOAD` (4) recargas; esgotadas, o CNPJ fica **PENDENTE**,
  com o motivo registrado, e a fila segue (nova tentativa no fim da lista).

Só um arquivo salvo **fora da pasta esperada** para a execução com aviso vermelho e pede F5, por segurança.

## Falhas temporárias do portal

Quando o portal mostra "Não foi possível concluir a ação para o contribuinte… tente novamente dentro de alguns
minutos", fica carregando sem progresso (`TIMEOUT_CARREGANDO_MS`, 60 s) ou não confirma a representação:

1. guarda o CNPJ atual, a etapa em que parou e os arquivos já salvos;
2. espera (o número de minutos que o portal indicar; "alguns minutos" = `ESPERA_FALHA_PORTAL_MS`, 2 min;
   carregamento travado = `ESPERA_CARREGAMENTO_MS`, 15 s), com contagem regressiva no aviso;
3. recarrega a página (F5) e retoma o **mesmo** CNPJ: se ele continua em Representação Atual, vai direto à análise;
   se a representação se perdeu, refaz CNPJ + Procurador + Representar. Só baixa o que ainda falta;
4. no máximo `MAX_RECARGAS_POR_CNPJ` (3) recargas por CNPJ. Persistindo, o CNPJ fica **PENDENTE** e a fila segue.
   No fim, o aviso lista os pendentes; um F5 depois tenta de novo só esses.

### "Estamos processando sua solicitação. Tente novamente em instantes."

Reconhecida pelo texto (a data e a hora depois dela são ignoradas), em qualquer etapa — inclusive na etapa 1, em que
a tela "em processamento" já vale como página reconhecida (o perfil continua no cabeçalho):

1. a extensão acompanha a página por até `ESPERA_PROCESSANDO_NA_PAGINA_MS` (60 s); se o resultado aparecer, confere o
   CNPJ em Dados Cadastrais e segue normalmente;
2. se demorar mais, o CNPJ fica **PENDENTE** (arquivos já salvos preservados) e a extensão **segue para o próximo
   CNPJ**, sem recarregar: abre o perfil e usa Trocar Representação a partir da própria tela "em processamento";
3. no fim da lista, tenta os pendentes de novo (`RODADAS_PENDENTES`, 1 vez). Se ainda falharem, o aviso final lista
   os pendentes; um F5 mais tarde tenta só esses.

### Recarga depois de "Representar" com a empresa anterior

Se o portal recarregar a página logo depois de **Representar** e ela voltar mostrando a empresa **anterior** (a
representação não pegou), a extensão repete o **mesmo CNPJ**: abre o perfil, Trocar Representação, CNPJ, Procurador e
Representar. Até `MAX_TENTATIVAS_REPRESENTAR` (3) tentativas seguidas; depois, o CNPJ fica PENDENTE e a fila segue.

## Intervalo entre empresas

Depois de concluir uma empresa (downloads ou evidência de erro de procuração salvos), espera pelo menos
`INTERVALO_ENTRE_EMPRESAS_MS` (5 s) e a página parar de carregar antes de abrir o perfil para a próxima.

## Vários downloads

A extensão libera, **só para `servicos.receitafederal.gov.br`**, a permissão do Chrome "Downloads automáticos"
(evita o bloqueio "Este site tentou baixar vários arquivos"). Ela é aplicada na instalação e antes de cada download.
Para conferir ou desfazer: `chrome://settings/content/automaticDownloads`. Os documentos continuam sendo baixados um
por vez, e cada arquivo é conferido na pasta da empresa certa.

## Onde os arquivos ficam

Em **`C:\Users\PANORAMA-PC\Downloads\Situacao_Fiscal_Assecon\`** (dentro dos Downloads do Chrome — o Chrome não
deixa extensões gravarem fora dela). A raiz é `PASTA_RAIZ` no início de `content.js`.

```
Situacao_Fiscal_Assecon/<EMPRESA>/Com_Pendencia_<CNPJ>.pdf                          (só com pendência)
Situacao_Fiscal_Assecon/<EMPRESA>/RFB_<CNPJ>.pdf                                    (certidão, quando o portal oferece)
Situacao_Fiscal_Assecon/<EMPRESA>/situação fiscal/<nome original do relatório>.pdf
Situacao_Fiscal_Assecon/<EMPRESA>/Erro_de_Procuracao/Erro_de_Procuracao_<CNPJ>.pdf  (quando o portal recusa)
```

- `<EMPRESA>` = o nome escrito na lista depois do `;` (ex.: `PRATICA CONSULTORIA & CONSTRUCOES LTDA`). Sem nome na
  lista, usa o nome de Dados Cadastrais; sem nenhum dos dois, os dígitos do CNPJ. Caracteres que o Windows não aceita
  (`<>:"/\|?*`) viram `_`; ponto no fim do nome é retirado.
- Nome repetido na lista (ex.: as filiais `47.377.778/0002` a `/0007`, todas "… LTDA PE") ganha o nº da filial no
  fim: `… LTDA PE 0002`, `… LTDA PE 0003`…
- `<CNPJ>` (nos nomes dos arquivos) = os 14 dígitos confirmados, com os zeros à esquerda, ex.: `04662526000198`.
- Cada pasta raiz tem o próprio registro de progresso: com `Situacao_Fiscal_Assecon` a lista começa do primeiro CNPJ.
  Os resultados dos testes anteriores ficaram em `Downloads\RFB_CNPJ` (com registro à parte).

Em `chrome://settings/downloads`, deixe **desligado** "Perguntar onde salvar cada arquivo", senão o Chrome abre a
janela de salvar para o relatório.

## Lista de CNPJs

No início de `content.js`, edite a lista `DOCUMENTOS` (uma linha por empresa, na ordem desejada, no formato
`CNPJ;NOME DA EMPRESA`; o nome dá nome à pasta e aparece nos avisos):

```js
const DOCUMENTOS = [
  ...
  '02.940.168/0001-02;FCA TECNOLOGIA DE INFORMACAO LTDA',
  '04.662.526/0001-98;PRATICA CONSULTORIA & CONSTRUCOES LTDA',
];
```

- Ao concluir um CNPJ, a extensão registra a conclusão (`chrome.storage.local`) e avança **uma vez** para o próximo,
  na mesma aba: abre o perfil, usa **Trocar Representação**, espera **Representação Atual** mostrar o novo CNPJ
  (enquanto mostrar o anterior, aguarda) e repete a análise. Depois do último, encerra.
- Os itens já concluídos são pulados ao abrir/recarregar a página. Na primeira vez com esta versão, um CNPJ cujo
  relatório já está em `RFB_CNPJ/<CNPJ>/situação fiscal/` conta como concluído (não refaz nem baixa de novo).
- Cada CNPJ começa com os próprios dados; comparação, nomes de arquivo e pastas saem do CNPJ confirmado.
- Recusa da representação = CNPJ concluído com "Erro de procuração — evidência salva"; a fila continua.
- Se um CNPJ falhar de outro jeito (divergência, tempo esgotado…), a execução para nele e mostra o motivo.
- **Ícone da extensão** = abre a janela de configuração (pasta + lista). Zerar o registro de concluídos é o botão
  **Zerar progresso** da janela, com dois cliques.

Se o portal recarregar a página logo depois de **Representar**, a extensão não clica de novo: se a página já mostra a
empresa pedida, segue para as etapas 9 a 11 (proteção válida por 5 minutos).

## Instalar

1. Abra `chrome://extensions` e ligue o **Modo do desenvolvedor**.
2. Clique em **Carregar sem compactação** e escolha esta pasta `Situacao_Fiscal`.
3. Depois de editar arquivos, clique no ícone de recarregar (↻) da extensão e recarregue a página.

## Testar

- Abra Minhas Dívidas e Pendências e aperte F5. Deixe a aba **visível** durante a captura da tela (etapa 10).
- O aviso no canto inferior esquerdo mostra a etapa; verde ao fim, vermelho com a etapa e o motivo se algo falhar.
- Detalhes no console (F12), com o prefixo `[Situacao_Fiscal]`.
- Tempos e velocidades (seta e digitação, separadas): bloco **CONFIGURAÇÃO** no início de `content.js`.

## Arquivos

- `manifest.json` — Manifest V3; o content script roda só em `servicos.receitafederal.gov.br`.
  `<all_urls>` é exigido pelo Chrome para capturar a tela (`captureVisibleTab`).
- `background.js` — navegação interna do portal, botão da extensão, captura da tela em PDF e redirecionamento do
  download do relatório para a pasta da empresa.
- `content.js` — reconhecimento da página, seta animada e o fluxo das 11 etapas.
````

---

## `ferramentas/lista_cnpjs.txt`

**Arquivo:** `lista_cnpjs.txt` · **Caminho:** `Autom_Situacao_Fiscal/ferramentas/lista_cnpjs.txt` · 209 linhas · 11700 bytes — Lista de CNPJs (CNPJ;NOME)

```text
00.351.766/0001-10;OXIL GASES EQUIPAMENTOS COMERCIO LTDA.
00.563.631/0001-19;JARDIM MOTO PECAS LTDA
02.105.151/0001-30;CONSTRUTORA FIBRA LTDA
02.106.023/0001-00;CONDOMINIO DO EDIFICIO COLOMBO
02.767.953/0001-05;JBR PARTNERS SERVICOS LTDA
02.940.168/0001-02;FCA TECNOLOGIA DE INFORMACAO LTDA
03.679.839/0001-96;LIDIANY DE ALBUQUERQUE LEMOS
04.025.127/0001-16;ARGAMASSAS SOLOSSANTINI E PRE MOLDADOS LTDA
04.327.791/0001-10;PLANET PET COMERCIO E SERVICOS VETERINARIOS LTDA
04.662.526/0001-98;PRATICA CONSULTORIA & CONSTRUCOES LTDA
05.379.833/0001-29;MUSA TROPICAL LTDA
05.379.833/0002-00;MUSA TROPICAL LTDA PE
05.790.893/0001-30;KESIO TRANSPORTES LTDA
06.000.805/0001-11;AZEVEDO & OLIVEIRA SERVICOS LTDA
06.914.565/0001-60;MITRA MINERACAO E LOCACAO DE EQUIPAMENTOS LTDA
06.914.565/0002-41;MITRA MINERACAO E LOCACAO DE EQUIPAMENTOS LTDA PB
07.378.462/0001-96;M. M. DIESEL LTDA
07.556.361/0001-68;ZILDEMBERG DE SOUSA RABELO
07.595.014/0001-44;G. C. AUTOMACAO LTDA
08.014.585/0001-00;AULETTE APOIO ADMINISTRATIVO LTDA
09.865.460/0001-57;RESTAURANTE COSTA BRAVA LTDA
10.358.365/0001-46;F & D FISIOTERAPIA LTDA
10.595.650/0001-80;NORTEXTIL NORDESTE TEXTIL REP COM E ASS LTDA
10.754.473/0001-38;ASSECON HUB CONTABILIDADE, CONSULTORIA E PLANEJAMENTO TRIBUTARIO LTDA
10.820.066/0001-81;SOLOS SERVICOS DO BRASIL LTDA
11.228.970/0001-65;SKITUR D. SANTINI PARQUES TURISTICOS LTDA
11.836.288/0001-55;IMOBILIARIA FIBRA LTDA
11.932.891/0001-30;MANA REPRESENTACOES COMERCIAIS LTDA
12.096.200/0001-79;PERNAMBUCO PISO CONSTRUCOES E SERVICOS LTDA
12.258.407/0001-00;SUPORTEC - SUPORTE EM SERVICOS DE INFORMATICA LTDA
12.355.091/0001-67;LA URSA PRODUCOES CULTURAIS LTDA
12.497.218/0001-82;SANDERSON RODRIGUES CAVALCANTI DOS SANTOS
12.901.802/0001-51;ROCHA CLIMATIZACAO LTDA
13.009.233/0001-05;J. D. SERVICOS DE MECANICA DE AUTOS LTDA.
13.259.754/0001-02;COLOMBO REPRESENTACOES LTDA
13.419.101/0001-43;GL CONSTRUCOES LTDA
14.147.345/0001-87;JMC IMOBILIARIA LTDA
14.298.373/0001-03;PERNAMBUCO PISCINAS COMERCIO E SERVICOS LTDA
14.529.829/0001-90;BBA MATERIAIS PARA CONSTRUCAO LTDA
14.754.104/0001-04;CE LOGISTICA INTEGRADA LTDA
15.024.222/0001-11;CRIATIVAS CERIMONIAL E ASSESSORIA DE EVENTOS LTDA
15.174.566/0001-07;VPA PARTICIPACOES LTDA
15.586.487/0001-03;ANA MARIA DA SILVA - SERVICOS CONTABEIS LTDA
15.863.081/0001-20;BARMONT CONSULTORIA E REPRESENTACAO LTDA
16.366.121/0001-91;FK REPRESENTACOES COMERCIAIS E CONSULTORIA LTDA
16.942.752/0001-01;CANTARELLI COMERCIO VAREJISTA DE ROUPAS E ACESSORIOS LTDA
17.354.744/0001-07;PLUS HOME CONSTRUCOES LTDA
17.504.941/0001-65;LAURO DE FARIAS TAVARES LAVA JATO
17.658.085/0001-00;MPE TREINAMENTO & CONSULTORIA LTDA
18.035.940/0001-81;GAS BRAS TECNOLOGIA EM GASES LTDA
18.604.375/0001-26;C.P.B. CONSTRUTORA PAULO BORGES LTDA
18.727.813/0001-43;LK DE ARAUJO TRANSPORTES DE CARGAS LTDA
18.747.177/0001-11;FISIO DO TRABALHO CONSULTORIA & SERVICOS LTDA
19.651.564/0001-12;TERRA FIRME EMPREENDIMENTOS LTDA
20.297.739/0001-14;MOVIMENTAR PROMOCAO DE SAUDE DO TRABALHO LTDA
20.898.850/0001-66;TECNOCOM ENGENHARIA LTDA
20.937.437/0001-63;METALNORDESTE MONTAGENS E SERVICOS LTDA
21.294.976/0001-94;MMA TECNOLOGIA-TI E AUTOMACAO COMERCIAL LTDA
21.347.194/0001-76;D GRAUS ENGENHARIA LTDA
21.794.062/0001-92;ASOS OCUPACIONAL LTDA
22.884.706/0001-04;J A RIBEIRO SERVICOS E REPRESENTACOES LTDA
23.085.619/0001-41;NAHAS LOCACOES DE ESPACOS, TREINAMENTOS E ALUGUEIS DE IMOVEIS LTDA
23.239.974/0001-28;MADA CORRETORA DE SEGUROS LTDA
23.398.612/0001-80;ANTONIO FELIX FOTOGRAFIA LTDA
23.837.442/0001-92;BRINKALHANDO BUFFET INFANTIL LTDA
23.975.573/0001-36;UNIENG ENGENHARIA LTDA
24.134.405/0001-80;CONJUNTO RESIDENCIAL USINA CERAMICA DO CORDEIRO
24.847.552/0001-06;NOVA MARCA PROJETOS E ENGENHARIA LTDA
25.187.046/0001-92;FAMILIA MANA COMERCIO VAREJISTA DE ARTIGOS DE VESTUARIO E ACESSORIOS LTDA
25.274.221/0001-89;FERREIRA & DANTAS ENGENHARIA LTDA
26.247.531/0001-77;JE ENGENHARIA LTDA
26.247.994/0001-39;CALDAS MAIA CONSTRUTORA LTDA
26.796.129/0001-41;RCR ENGENHARIA E GERENCIAMENTO LTDA
26.871.958/0001-41;D&B CONSULTORIA LTDA
26.950.919/0001-30;IZABEL MELO DE LIMA ACADEMIA
27.347.247/0001-35;VIGOR CONSULTORIA E SERVICOS LTDA
27.709.935/0001-06;AWDRY MARCIO DA SILVA
27.728.176/0001-10;REFERENCIA FACTORING SOCIEDADE DE FOMENTO COMERCIAL LTDA
27.820.582/0001-09;JOSE ANTERO VIEIRA FILHO
27.907.882/0001-20;INFINIT ENGENHARIA E PROJETOS LTDA
28.462.750/0001-02;GR3 MAESTRIA EM GINASTICA LTDA
28.717.348/0001-13;SANDRO AZEVEDO SERVICOS LTDA
29.410.072/0001-99;COMERCIO DE GASES E EQUIPAMENTOS LTDA
29.413.756/0001-44;VENETO LOCADORA DE MAQUINAS E EQUIPAMENTOS LTDA
29.652.788/0001-00;OREN CORRETORA DE SEGUROS LTDA
30.017.694/0001-30;BRUNO NEVES MATHEUS DUTRA - CONSULTORIA IMOBILIARIA
30.492.473/0001-14;MARTON ANTONIO DA SILVA
30.732.910/0001-20;LUSOBRAS INCORPORACAO E SERVICOS DE ENGENHARIA LTDA
31.249.591/0001-69;JVP BAR E RESTAURANTE LTDA
31.323.817/0001-24;RS ENGENHARIA E SERVICOS LTDA
31.399.696/0001-02;31.399.696 JOELMIR DE OLIVEIRA
31.946.781/0001-35;GLEBESON SERAFIM DA SILVA 04267481407
31.982.478/0001-98;EDLEUSA MIRANDA PEREIRA SOCIEDADE INDIVIDUAL DE ADVOCACIA
32.084.687/0001-87;SOMATEC DESENVOLVIMENTO DE OBRAS LTDA
32.309.830/0001-91;JU FEITOZA MKT DIGITAL LTDA
32.941.058/0001-26;FABRICIO DA SILVA
33.072.274/0001-45;JRM & FAM REPRESENTACOES COMERCIAIS DE BRINQUEDOS E ARTIGOS LTDA
33.546.098/0001-36;DIESEL SERVICOS DE MANUTENCAO E REPARACAO MECANICA LTDA
33.683.321/0001-97;D FIBRA AMBIENTAL ,FABRICACAO, INSTALACAO E CONSTRUCAO DE OBRAS LTDA
33.689.471/0001-08;FLY LOCADORA DE VEICULOS LTDA
33.807.491/0001-36;JE ENGENHARIA EMPREENDIMENTOS VITORIA V, VI E VII SCP
34.017.942/0001-02;MPL REPRESENTACOES LTDA
35.211.448/0001-39;MM DIESEL SERVICOS DE ELETRONICA E COMERCIO DE PECAS LTDA
35.229.495/0001-00;ROSANGELA DA SILVA LIMA COMERCIO DE PECAS E SERVICOS DE MOTOS
35.327.709/0001-80;CONDOMINIO DO EDIFICIO CHATEAU LYON
35.439.014/0001-90;35.439.014 RAFAELLY DE ARAUJO JUVENAL
35.471.841/0001-61;DEBORAH S T SANTIAGO
35.495.169/0001-44;IMPULSO COMERCIAL EDUCACAO CORPORATIVA E CONSULTORIA LTDA
38.005.389/0001-30;NORDESTE LOCADORA DE VEICULO LTDA
38.184.450/0001-54;SINGULAR ENGENHARIA E CONSTRUCAO LTDA
38.252.962/0001-00;TAVARES MARKETING GROUP LTDA
40.723.311/0001-01;SOLUTECH - SUPORTE EM SERVICOS DE INFORMATICA LTDA
41.041.901/0001-09;GERTROX COMERCIO DE MAQUINAS E FERRAMENTAS LTDA
41.115.457/0001-29;GABRIEL C. DA SILVA COMERCIO DE BOMBAS E SOLUCOES HIDRAULICAS LTDA
41.175.771/0001-05;MARIANNA SAMPAIO SERPA ANDRADE - LAUDOS ODONTOLOGICOS
41.233.081/0001-57;GILDO ANSELMO DE OLIVEIRA
41.326.049/0001-16;GLL CONSTRUCOES E SERVICOS DE REFORMAS LTDA
41.405.818/0001-71;MARCIA BARBOSA SERVICOS ADMINISTRATIVOS LTDA
42.377.207/0001-20;WE MANUTENCAO E REPRESENTACAO LTDA
42.887.533/0001-87;ROSSI ENGENHARIA ELETRICA LTDA
42.919.913/0001-56;HANGAR DO DRONE, ASSISTENCIA TECNICA, VENDAS E TREINAMENTOS LTDA
43.039.005/0001-30;SANTINI E MENDES LTDA
43.176.206/0001-80;PE DUTRA CONSULTORIA EMPRESARIAL LTDA
43.533.088/0001-10;OLIVEIRA PRINCIPE & TAVARES ADVOCACIA
44.132.869/0001-65;FARMACIA PESSOA LTDA
44.132.869/0002-46;FARMACIA PESSOA LTDA PE
44.232.720/0001-58;MORGANA TOSCANO GOMES - SERVICOS
44.480.096/0001-08;DBG EMPREENDIMENTOS DE LAZER LTDA
44.669.923/0001-06;LETICIA SIQUEIRA CAVALCANTE & CIA LTDA
45.146.708/0001-93;GSSA ENGENHARIA & CONSULTORIA LTDA
45.201.851/0001-30;MOACY SANTOS FERREIRA - GESTAO E SERVICOS DE ENGENHARIA
45.315.376/0001-23;ANNA CANAS EDUCACIONAL LTDA
46.254.688/0001-37;JAIR EUCLIDES DE OLIVEIRA JUNIOR - JR DIESEL
46.806.564/0001-17;SUNSET RESIDENCE FRANCES SPE LTDA
46.806.564/0002-06;SUNSET RESIDENCE FRANCES SPE LTDA AL
46.807.957/0001-45;46.807.957 NATHALIA LOPES WANDERLEY E SILVA
46.855.199/0001-30;I S ASSESSORIA LTDA
47.257.925/0001-86;BMAF TECNOLOGIA LTDA
47.377.778/0001-88;FERNANDO ANTONIO TAVARES DE LIMA - EDUCACIONAL LTDA
47.377.778/0002-69;FERNANDO ANTONIO TAVARES DE LIMA - EDUCACIONAL LTDA PE
47.377.778/0003-40;FERNANDO ANTONIO TAVARES DE LIMA - EDUCACIONAL LTDA PE
47.377.778/0004-20;FERNANDO ANTONIO TAVARES DE LIMA - EDUCACIONAL LTDA PE
47.377.778/0005-01;FERNANDO ANTONIO TAVARES DE LIMA - EDUCACIONAL LTDA PE
47.377.778/0006-92;FERNANDO ANTONIO TAVARES DE LIMA - EDUCACIONAL LTDA PE
47.377.778/0007-73;FERNANDO ANTONIO TAVARES DE LIMA - EDUCACIONAL LTDA PE
47.505.140/0001-85;BRUNO JOSE MOREIRA BRAGA 84668121487
47.828.976/0001-10;G&Z GASES ESPECIAIS COM. E TRANSP. LTDA
47.913.830/0001-73;MERELUANA ALINE BARROS DA SILVA 09405655442
48.000.353/0001-18;G H TAVEIRA CONSULTORIA LTDA
48.475.543/0001-91;CASA DI GRANO DISTRIBUIDORA DE FARINHAS LTDA
48.893.270/0001-03;EVL REPRESENTACOES LTDA
49.401.644/0001-80;CARBOPLUS SERVICOS DE ESCRITORIO LTDA
49.451.414/0001-26;U. E. ENGENHARIA E CONSTRUCAO LTDA
49.585.956/0001-91;JOSE DEIVSON DO NASCIMENTO - SERVICOS DE MANUTENCAO
50.199.704/0001-03;TECNOCOM ENGENHARIA LTDA SCP
50.469.019/0001-50;ONSITE SOLUTION PROVIDER LTDA
51.314.754/0001-57;WINE 48 LTDA
51.339.135/0001-17;UBIRACY DO AMARAL DIAGNOSTICO EM ANATOMIA PATOLOGICA LTDA
51.406.327/0001-07;NOVA MARCA PORTAS E ESQUADRIAS LTDA
51.435.924/0001-51;51.435.924 ANNE GLAYCE MORAIS DA SILVA NASCIMENTO
51.745.220/0001-85;MJFA SERVICOS VETERINARIOS LTDA
52.328.377/0001-78;EXITO SERVICOS ADMINISTRATIVOS LTDA
52.368.325/0001-25;COSTA II RESTAURANTE LTDA
52.437.943/0001-80;DOGSHIP PET TECH SERVICOS LTDA
52.440.780/0001-94;JERIMOON COMERCIO DE ARTIGOS E ACESSORIOS LTDA
52.967.691/0001-09;52.967.691 RUAN HENRIQUE GOMES DE ALMEIDA
53.007.769/0001-06;RESI ENGENHARIA LTDA
53.053.305/0001-28;LUCAS CARVALHO MACHADO - SOCIEDADE INDIVIDUAL DE ADVOCACIA
54.169.607/0001-29;SPEEDO LOCADORA DE VEICULOS LTDA
54.330.770/0001-21;54.330.770 EVA DE OLIVEIRA SOBRAL BRAGA
54.390.136/0001-84;J & S SOLUCOES EM TECNOLOGIA LTDA
54.468.850/0001-48;54.468.850 CAROLINA PEPE DE CARVALHO
54.673.309/0001-71;MIXSANTINI INDUSTRIA E COMERCIO LTDA
54.708.742/0001-03;EDUARDO MARTINS SOCIEDADE INDIVIDUAL DE ADVOCACIA
55.129.749/0001-25;SANA INSTALACOES E SERVICOS LTDA
55.335.929/0001-63;FAST SOLUTIONS COMERCIO E SERVICOS LTDA
55.968.276/0001-50;SINGULAR ENGENHARIA LTDA.
56.414.611/0001-30;BLESSED STORE COMERCIO LTDA
56.414.611/0002-11;BLESSED STORE COMERCIO LTDA PE
56.414.611/0003-00;BLESSED STORE COMERCIO LTDA AL
57.371.792/0001-28;DREAM TOURS AGENCIA DE TURISMO E SERVICOS LTDA
57.536.996/0001-71;EVOLTEC ELETRONICA LTDA
57.739.030/0001-31;BERG RABELO PRODUCOES LTDA
57.766.383/0001-20;THIAGO CYSNEIROS SOCIEDADE INDIVIDUAL DE ADVOCACIA
58.076.370/0001-92;D FIBRA CONSTRUCOES E SERVICOS LTDA
58.103.660/0001-88;JNS CONSTRUCOES E SERVICOS LTDA
58.278.519/0001-16;MAAS PATRIMONIAL LTDA
58.524.268/0001-02;58.524.268 SAMUEL DA SILVA OLIVEIRA
58.779.803/0001-76;58.779.803 THIAGO ABNER LESSA SANTIAGO SILVA
59.131.776/0001-93;CARLOS FELIPE LIMA DA SILVA - PE PISCINA AGUAZUL
59.155.514/0001-69;KEKA PATRIMONIAL LTDA
59.218.381/0001-22;PRESENTEAR CARTOES E PRESENTES LTDA
59.391.808/0001-90;TOSCANO SERVICOS DE APOIO A EMPRESAS LTDA
60.588.187/0001-18;PRISCILLA OLIVEIRA DE CARVALHO - SOCIEDADE INDIVIDUAL DE ADVOCACIA
60.883.613/0001-46;SANTANA PROJETOS E ENGENHARIA LTDA
62.187.605/0001-90;HSX SOLUCOES EMPRESARIAIS LTDA
62.357.639/0001-86;ECOASSESSORIA E ENGENHARIA LTDA
62.475.980/0001-36;INSTITUTO EDUCACIONAL GOUVEIA LTDA
62.528.743/0001-96;INCORPORADORA GOUVEIA LTDA
62.862.944/0001-25;PV3 PARTICIPACOES LTDA
63.274.746/0001-03;63.274.746 JOAO DIOGO FEITOSA
63.986.506/0001-31;EA CONSULTORIA E TREINAMENTOS LTDA
64.145.906/0001-87;SUNWAVE RESIDENCE LTDA
64.444.591/0001-79;MAVIDA SEGUROS LTDA
64.713.114/0001-61;PROLOOP ENGENHARIA E PROJETOS DE AUTOMACAO LTDA
64.778.451/0001-37;ADRESOURCES MODELAGEM DE RECURSOS MINERAIS LTDA
65.497.199/0001-50;GRANSAFRA EMBALAGENS LTDA
69.904.274/0001-01;CONDOMINIO DO EDIFICIO MONTE CARMELO
```

---

## `ferramentas/validar_lista.js`

**Arquivo:** `validar_lista.js` · **Caminho:** `Autom_Situacao_Fiscal/ferramentas/validar_lista.js` · 26 linhas · 1555 bytes — Valida a lista

```javascript
// Valida a lista (CNPJ;NOME): formato, dígitos verificadores, repetidos e nomes de pasta repetidos.
const fs = require('fs');
const linhas = fs.readFileSync(process.argv[2], 'utf8').split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
const dv = (b) => { const w = b.length === 12 ? [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2] : [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2];
  const s = [...b].reduce((a, c, i) => a + c * w[i], 0) % 11; return s < 2 ? 0 : 11 - s; };
const problemas = [];
const vistos = new Map();
const nomes = new Map();
for (const l of linhas) {
  const [doc, ...n] = l.split(';');
  const nome = n.join(';').trim();
  const d = doc.replace(/\D/g, '');
  if (!/^\d{2}\.\d{3}\.\d{3}\/\d{4}-\d{2}$/.test(doc.trim())) problemas.push(`formato: ${l}`);
  if (d.length !== 14) problemas.push(`não tem 14 dígitos: ${l}`);
  else { const b = d.slice(0, 12), d1 = dv(b), d2 = dv(b + d1); if (d !== b + d1 + d2) problemas.push(`dígito verificador inválido: ${l}`); }
  if (!nome) problemas.push(`sem nome: ${l}`);
  if (vistos.has(d)) problemas.push(`CNPJ repetido: ${l}`);
  vistos.set(d, l);
  const chave = nome.replace(/[<>:"/\\|?*]/g, '_').replace(/\s+/g, ' ').trim().replace(/[. ]+$/, '').toUpperCase();
  nomes.set(chave, [...(nomes.get(chave) || []), doc.trim()]);
}
console.log('itens:', linhas.length);
console.log('problemas:', problemas.length ? problemas : 'nenhum');
const dup = [...nomes].filter(([, v]) => v.length > 1);
console.log('nomes de pasta repetidos:', dup.length ? dup.map(([k, v]) => `${k} -> ${v.join(', ')}`) : 'nenhum');
```

---

## `ferramentas/aplicar_lista.js`

**Arquivo:** `aplicar_lista.js` · **Caminho:** `Autom_Situacao_Fiscal/ferramentas/aplicar_lista.js` · 11 linhas · 729 bytes — Grava a lista no content.js

```javascript
// Substitui o bloco "const DOCUMENTOS = [ ... ];" do content.js pela lista do arquivo (uma linha por empresa).
const fs = require('fs');
const [, , arqLista, arqContent] = process.argv;
const linhas = fs.readFileSync(arqLista, 'utf8').split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
const corpo = linhas.map((l) => `    ${JSON.stringify(l).replace(/^"|"$/g, "'").replace(/\\"/g, '"')},`).join('\n');
const src = fs.readFileSync(arqContent, 'utf8');
const re = /const DOCUMENTOS = \[[\s\S]*?\n  \];/;
if (!re.test(src)) throw new Error('bloco DOCUMENTOS não encontrado');
fs.writeFileSync(arqContent, src.replace(re, `const DOCUMENTOS = [\n${corpo}\n  ];`), 'utf8');
console.log('lista aplicada:', linhas.length, 'itens');
```

---

## `ferramentas/analisar_progresso.js`

**Arquivo:** `analisar_progresso.js` · **Caminho:** `Autom_Situacao_Fiscal/ferramentas/analisar_progresso.js` · 79 linhas · 5018 bytes — Cruza a lista com as pastas salvas

```javascript
// Cruza a lista DOCUMENTOS do content.js com as pastas em Downloads\Situacao_Fiscal_Assecon.
// Uso: node analisar_progresso.js <content.js> <pasta raiz> <saida.csv>
const fs = require('fs');
const path = require('path');
const [, , arqContent, raiz, saidaCsv] = process.argv;

const src = fs.readFileSync(arqContent, 'utf8');
const bloco = src.match(/const DOCUMENTOS = \[([\s\S]*?)\n  \];/)[1];
const linhas = [...bloco.matchAll(/'([^']+)'/g)].map((m) => m[1]);
const limpo = (s) => String(s || '').replace(/[<>:"/\\|?*\x00-\x1f]/g, '_').replace(/\s+/g, ' ').trim().replace(/[. ]+$/, '').slice(0, 120);
const fila = linhas.map((l, i) => {
  const [doc, ...n] = l.split(';');
  return { ordem: i + 1, documento: doc.trim(), digitos: doc.replace(/\D/g, ''), nome: n.join(';').trim() };
});
for (const f of fila) {
  let nome = limpo(f.nome) || f.digitos;
  if (fila.filter((g) => limpo(g.nome).toUpperCase() === nome.toUpperCase()).length > 1) nome = `${nome} ${f.digitos.slice(8, 12)}`;
  f.pasta = nome;
}

const existentes = fs.existsSync(raiz) ? fs.readdirSync(raiz, { withFileTypes: true }).filter((d) => d.isDirectory()).map((d) => d.name) : [];
const porMaiuscula = new Map(existentes.map((n) => [n.toUpperCase(), n]));
const listar = (dir) => (fs.existsSync(dir) ? fs.readdirSync(dir, { withFileTypes: true }) : []);

const resultado = fila.map((f) => {
  const real = porMaiuscula.get(f.pasta.toUpperCase());
  const r = { ...f, existe: !!real, captura: false, certidao: false, relatorio: false, erroProcuracao: false, arquivos: 0, ultima: null };
  if (real) {
    const dir = path.join(raiz, real);
    const marca = (p) => { const t = fs.statSync(p).mtime; if (!r.ultima || t > r.ultima) r.ultima = t; r.arquivos++; };
    for (const e of listar(dir)) {
      const p = path.join(dir, e.name);
      if (e.isFile()) {
        marca(p);
        if (/^Com_Pendencia_/i.test(e.name)) r.captura = true;
        if (/^RFB_\d+\.pdf$/i.test(e.name)) r.certidao = true;
      } else if (/situa..o fiscal/i.test(e.name)) {
        for (const x of listar(p)) if (x.isFile()) { marca(path.join(p, x.name)); r.relatorio = true; }
      } else if (/Erro_de_Procuracao/i.test(e.name)) {
        for (const x of listar(p)) if (x.isFile()) { marca(path.join(p, x.name)); r.erroProcuracao = true; }
      }
    }
  }
  if (r.erroProcuracao) r.situacao = 'Concluído — erro de procuração (evidência salva)';
  else if (r.relatorio) r.situacao = r.certidao ? 'Concluído — certidão + relatório' : (r.captura ? 'Concluído — com pendência (captura + relatório)' : 'Concluído — relatório');
  else if (r.certidao) r.situacao = 'Incompleto? — só certidão (falta relatório, ou o portal não ofereceu)';
  else if (r.captura) r.situacao = 'Incompleto — só captura (faltam certidão/relatório)';
  else if (r.existe) r.situacao = 'Incompleto — pasta vazia';
  else r.situacao = 'Não processado';
  return r;
});

const extras = existentes.filter((n) => !fila.some((f) => f.pasta.toUpperCase() === n.toUpperCase()));
const grupos = {};
for (const r of resultado) (grupos[r.situacao] = grupos[r.situacao] || []).push(r);

console.log(`Lista: ${fila.length} CNPJs | pastas encontradas: ${existentes.length}`);
for (const [k, v] of Object.entries(grupos)) console.log(`${String(v.length).padStart(4)}  ${k}`);
const feitos = resultado.filter((r) => r.existe).sort((a, b) => b.ultima - a.ultima);
if (feitos.length) {
  const u = feitos[0];
  console.log(`\nÚltimo arquivo salvo: ${u.ultima.toLocaleString('pt-BR')} — nº ${u.ordem} ${u.documento} ${u.nome}`);
}
const maiorOrdemFeita = Math.max(0, ...resultado.filter((r) => r.situacao.startsWith('Concluído')).map((r) => r.ordem));
console.log(`Maior posição concluída na lista: ${maiorOrdemFeita}`);
const naoFeitosAntes = resultado.filter((r) => !r.situacao.startsWith('Concluído') && r.ordem < maiorOrdemFeita);
console.log(`\nNão concluídos ANTES da posição ${maiorOrdemFeita} (pendentes/pulados): ${naoFeitosAntes.length}`);
naoFeitosAntes.forEach((r) => console.log(`  nº ${r.ordem}  ${r.documento}  ${r.nome}  →  ${r.situacao}`));
const depois = resultado.filter((r) => r.ordem > maiorOrdemFeita);
console.log(`\nDepois da posição ${maiorOrdemFeita}: ${depois.length} CNPJs (${depois.filter((r) => r.existe).length} com pasta)`);
if (depois.length) console.log(`  próximo da fila: nº ${depois[0].ordem} ${depois[0].documento} ${depois[0].nome}`);
console.log(`\nPastas fora da lista: ${extras.length ? extras.join(' | ') : 'nenhuma'}`);

const csv = ['Ordem;CNPJ;Empresa;Situação;Certidão;Relatório;Captura pendência;Erro procuração;Arquivos;Último arquivo']
  .concat(resultado.map((r) => [r.ordem, r.documento, r.nome, r.situacao, r.certidao ? 'sim' : '', r.relatorio ? 'sim' : '',
    r.captura ? 'sim' : '', r.erroProcuracao ? 'sim' : '', r.arquivos, r.ultima ? r.ultima.toLocaleString('pt-BR') : ''].join(';')));
fs.writeFileSync(saidaCsv, '﻿' + csv.join('\r\n'), 'utf8');
console.log(`\nPlanilha: ${saidaCsv}`);
```

---

## `ferramentas/gerar_codigo_completo.js`

**Arquivo:** `gerar_codigo_completo.js` · **Caminho:** `Autom_Situacao_Fiscal/ferramentas/gerar_codigo_completo.js` · 55 linhas · 3163 bytes — Gera esta página

```javascript
// Gera CODIGO_COMPLETO.md: cada arquivo do projeto identificado por nome e caminho, com o conteúdo integral.
// Uso (na pasta Autom_Situacao_Fiscal):  node ferramentas\gerar_codigo_completo.js
const fs = require('fs');
const path = require('path');

const raiz = path.resolve(__dirname, '..');
const ARQUIVOS = [
  ['README.md', 'markdown', 'Como instalar e executar'],
  ['Situacao_Fiscal/manifest.json', 'json', 'Manifesto da extensão (nome, versão, permissões)'],
  ['Situacao_Fiscal/background.js', 'javascript', 'Service worker: captura em PDF, downloads, pastas, permissões'],
  ['Situacao_Fiscal/content.js', 'javascript', 'Fluxo da automação, seta, lista de CNPJs e configurações'],
  ['Situacao_Fiscal/popup.html', 'html', 'Janela da extensão (ícone): pasta de destino e lista de CNPJs'],
  ['Situacao_Fiscal/popup.js', 'javascript', 'Validação e gravação da configuração da janela'],
  ['Situacao_Fiscal/LEIA-ME.md', 'markdown', 'Manual detalhado da extensão'],
  ['ferramentas/lista_cnpjs.txt', 'text', 'Lista de CNPJs (CNPJ;NOME)'],
  ['ferramentas/validar_lista.js', 'javascript', 'Valida a lista'],
  ['ferramentas/aplicar_lista.js', 'javascript', 'Grava a lista no content.js'],
  ['ferramentas/analisar_progresso.js', 'javascript', 'Cruza a lista com as pastas salvas'],
  ['ferramentas/gerar_codigo_completo.js', 'javascript', 'Gera esta página'],
  ['CLAUDE.md', 'markdown', 'Instruções para o Claude continuar o projeto'],
  ['HISTORICO.md', 'markdown', 'Histórico de criação (decisões, problemas, regras, pendências)'],
];

const manifesto = JSON.parse(fs.readFileSync(path.join(raiz, 'Situacao_Fiscal/manifest.json'), 'utf8'));
const agora = new Date().toLocaleString('pt-BR');
const partes = [
  '# Autom_Situacao_Fiscal — código completo',
  '',
  `Extensão **${manifesto.name}**, versão **${manifesto.version}**. Página gerada em ${agora} por ` +
    '`ferramentas/gerar_codigo_completo.js`.',
  '',
  'Para reconstruir o projeto, crie cada arquivo no caminho indicado (relativo à pasta `Autom_Situacao_Fiscal`) e cole ' +
    'o conteúdo do bloco logo abaixo dele, do início ao fim, sem a linha de abertura e a de fechamento do bloco. ' +
    'Os arquivos são UTF-8.',
  '',
  '## Arquivos',
  '',
  ...ARQUIVOS.map(([p, , d], i) => `${i + 1}. \`${p}\` — ${d}`),
  '',
];

for (const [rel, lang, desc] of ARQUIVOS) {
  const texto = fs.readFileSync(path.join(raiz, rel), 'utf8').replace(/^﻿/, '');
  // cerca maior que qualquer sequência de crases dentro do arquivo
  const maior = Math.max(2, ...(texto.match(/`+/g) || ['']).map((s) => s.length));
  const cerca = '`'.repeat(maior + 1);
  const linhas = texto.split(/\r?\n/).length;
  partes.push('---', '', `## \`${rel}\``, '', `**Arquivo:** \`${path.basename(rel)}\` · **Caminho:** \`Autom_Situacao_Fiscal/${rel}\` · ` +
    `${linhas} linhas · ${Buffer.byteLength(texto, 'utf8')} bytes — ${desc}`, '', `${cerca}${lang}`, texto.replace(/\s+$/, ''), cerca, '');
}

const destino = path.join(raiz, 'CODIGO_COMPLETO.md');
fs.writeFileSync(destino, partes.join('\n'), 'utf8');
console.log(`gerado: ${destino} (${ARQUIVOS.length} arquivos)`);
```

---

## `CLAUDE.md`

**Arquivo:** `CLAUDE.md` · **Caminho:** `Autom_Situacao_Fiscal/CLAUDE.md` · 24 linhas · 1516 bytes — Instruções para o Claude continuar o projeto

```markdown
# Autom_Situacao_Fiscal — instruções para o Claude

Este projeto é a extensão do Chrome **Situacao_Fiscal**, que automatiza a situação fiscal no portal da Receita
Federal para a Assecon. Antes de qualquer ajuste:

1. Leia `HISTORICO.md` (decisões, regras de cada situação, o que falta) e `README.md`.
2. Leia a versão atual do código em `Situacao_Fiscal/` (`content.js`, `background.js`, `manifest.json`).
3. O Chrome executa a cópia em `C:\Users\PANORAMA-PC\Desktop\ATM_SIT_FISCAL\Situacao_Fiscal`. Faça cada ajuste nas
   **duas** pastas, que devem ficar idênticas (confira por hash). Não mude a pasta carregada no Chrome: o ID da
   extensão mudaria e o progresso dos CNPJs seria perdido.

Depois de cada ajuste:

- aumente `version` no `manifest.json` e o título do `LEIA-ME.md`;
- valide com `node --check` e, para mudanças de fluxo, numa página que imita o portal (carregando o `content.js`
  real com `URL_ALVO` trocada e `chrome.*` simulado). Apague a página de teste ao terminar;
- regenere `CODIGO_COMPLETO.md`: `node ferramentas\gerar_codigo_completo.js`;
- acrescente uma linha na tabela "Linha do tempo" do `HISTORICO.md` (versão, o que mudou, por quê) e atualize
  "Regras" e "O que ainda precisa de ajuste";
- lembre o usuário de clicar em ↻ na extensão. Desde a v1.1.0, o ícone abre a janela de configuração (pasta +
  CNPJs). A pasta e a lista em uso vêm da janela (`situacao_fiscal_config`), não só do `content.js`.

Respostas ao usuário em português do Brasil.
```

---

## `HISTORICO.md`

**Arquivo:** `HISTORICO.md` · **Caminho:** `Autom_Situacao_Fiscal/HISTORICO.md` · 131 linhas · 14932 bytes — Histórico de criação (decisões, problemas, regras, pendências)

```markdown
# Autom_Situacao_Fiscal — histórico de criação

Registro de como a extensão **Situacao_Fiscal** foi construída, entre 11/11/2026 e 13/11/2026: decisões e motivos,
problemas encontrados, soluções, regras de cada situação e o que ainda precisa de ajuste. Versão atual: **1.1.1**.

## Contexto

- Usuário: escritório contábil **Assecon Hub Contabilidade** (CNPJ titular `10.754.473/0001-38`). Ele acessa o
  e-CAC como **Procurador** de clientes e precisa da situação fiscal de cada um.
- Portal: `https://servicos.receitafederal.gov.br/servico/pendencias/#/analise-pendencias`
  (**Minhas Dívidas e Pendências**). É uma SPA em Angular, com componentes do padrão gov.br.
- Projeto irmão de referência: `C:\Users\PANORAMA-PC\Downloads\Auto_PGFN` (extensão Automação_PGFN). Copiamos o
  estilo: bloco CONFIGURAÇÃO no topo, seta animada, aviso no canto inferior esquerdo e prefixo no console.
- Pastas: o Chrome executa `C:\Users\PANORAMA-PC\Desktop\ATM_SIT_FISCAL\Situacao_Fiscal`. A cópia de referência
  (página do projeto) fica em `C:\Users\PANORAMA-PC\Documents\Autom_Situacao_Fiscal`. As duas devem ficar iguais.
- Resultados: `C:\Users\PANORAMA-PC\Downloads\Situacao_Fiscal_Assecon\<EMPRESA>\…`.

## Decisões de base (e por quê)

- **Extensão MV3 com JavaScript puro**, sem Playwright nem Selenium: pedido do usuário; roda no Chrome já logado.
- **Seta visual** com `pointer-events:none`, movimento contínuo com aceleração e desaceleração e pausa antes do
  clique. O destino é calculado por `getBoundingClientRect` no momento do clique, o que funciona com qualquer
  resolução e zoom. O clique é feito com eventos sintéticos (pointerdown, mousedown, pointerup, mouseup, click), uma
  única vez, no elemento real.
- **Detecção da página pela URL completa**, incluindo o trecho após `#`. O content script roda em todo o host, e o
  service worker avisa as mudanças de SPA (`webNavigation.onHistoryStateUpdated` e `onReferenceFragmentUpdated`). Há
  também um vigia da URL a cada 400 ms.
- **Leitura do DOM por texto e posição na tela**, não por classes do Angular, que mudam. Exemplos: o painel é o
  contêiner à direita com "Representar" e "Representações Recentes"; o perfil é o controle no canto superior direito
  com avatar, CNPJ e seta.
- **Downloads só dentro da pasta de Downloads**, porque é uma limitação do Chrome. A pasta raiz é configurável.
- **A captura da tela vira PDF dentro da própria extensão:** `captureVisibleTab` gera um JPEG e um gerador de PDF
  mínimo, escrito à mão, monta o arquivo. Exige `<all_urls>` em `host_permissions`.
- **O relatório e a certidão do portal** são redirecionados com `downloads.onDeterminingFilename`, um download por
  vez. A "espera" do download fica guardada em `storage.session`, porque o service worker pode reiniciar.
- **Progresso em `chrome.storage.local`**, numa chave por pasta raiz (`situacao_fiscal_progresso:<PASTA_RAIZ>`):
  concluídos, parciais (arquivos já salvos), pendentes, recuperação e rodada de pendentes.

## Linha do tempo (versão → o que mudou → por quê)

| Versão | Mudança | Motivo / problema |
|---|---|---|
| 0.1.0 | Reconhece a página, aceita cookies, abre o perfil e para com o painel aberto | 1ª etapa pedida |
| — | `quadro()` com timer de reserva | `requestAnimationFrame` pausa em aba oculta e a seta travava |
| 0.2.0 | Preenche o CNPJ (só dígitos, a máscara do portal formata), escolhe Procurador e clica em Representar | 2ª etapa |
| 0.2.1 | Seletor de perfil achado por placeholder, nome acessível, texto visível ou posição; seta azul como 2ª tentativa; velocidades separadas | O seletor não é um `<input placeholder>` simples (estilo ng-select) |
| 0.2.2 | Lista de perfis reconhecida pela **posição na tela** e por `elementFromPoint` | A lista fica dentro do componente do campo e era descartada como "parte do campo" |
| 0.2.3 | Botão Representar = o mais próximo **abaixo do seletor**; o painel nunca conta como "mensagem do portal" | O título "^ Representar" também é botão e era clicado por engano; o texto do painel virava "resposta" falsa |
| 0.3.0 | Confirma a Representação Atual; fecha o painel pelo fundo escurecido (ou ×); captura em PDF; baixa o relatório | Etapas 8 a 11 |
| 0.4.0 | Lista de CNPJs com registro de progresso; troca por Trocar Representação; espera a Representação Atual mudar | Processar vários CNPJs |
| — | Correção: o ouvinte `onDeterminingFilename` precisa confirmar também os downloads da própria extensão | A captura saía como `download (3).pdf` |
| 0.5.0 | Recusa de procuração: recorte da seção Trocar Representação até o campo Procurador, salvo em `Erro_de_Procuracao/`; a fila continua | "Sua autorização como procurador não permite acesso a este serviço." |
| — | Mensagem de recusa considerada "desta tentativa" só se sumir e voltar, ou se aparecer num elemento novo | Recusas seguidas reutilizam o mesmo elemento com o mesmo texto |
| 0.6.0 | Em **qualquer** status, rola até o rodapé e baixa **Baixar Certidão** (`RFB_<CNPJ>.pdf`) e **Baixar Relatório** (nome original), um por vez; parciais permitem retomar sem duplicar | "Sem pendência" encerrava sem baixar os documentos |
| 0.7.0 | Pasta com o **nome da empresa**, e não com o CNPJ | Pedido do usuário |
| 0.8.0 | Falha temporária ("Não foi possível concluir a ação…", carregamento travado, sem confirmação): guarda o estado, espera, F5, retoma o mesmo CNPJ (até 3 vezes; depois pendente); intervalo de 5 s entre empresas; downloads múltiplos permitidos só no portal (`contentSettings.automaticDownloads`) | A página falhava ou travava; o Chrome bloqueava o 2º download |
| — | A Representação Atual é lida mesmo com indicador de carregamento visível | Um spinner preso impedia a leitura e dava "sem confirmação" |
| 0.9.0 | Lista ampliada; o CNPJ do titular tentava encerrar a representação | A Assecon está na lista |
| 0.9.1 | Diálogo "Encerrar representação" → sempre **Cancelar** e seguir; o titular passa pelo fluxo normal | Pedido do usuário: nunca encerrar uma representação |
| 1.0.0 | Lista oficial de **208 CNPJs**; raiz `Situacao_Fiscal_Assecon` com progresso próprio; filiais com o mesmo nome ganham o nº da filial na pasta | Execução de produção; seis filiais "FERNANDO … LTDA PE" com o mesmo nome |
| 1.0.1 | "Estamos processando sua solicitação. Tente novamente em instantes." reconhecida pelo texto, em toda espera | A etapa 9 parava aos 30 s: o texto não estava na lista de falhas e não havia spinner, então virava erro comum |
| 1.0.2 | A tela "processando" vale como página na etapa 1; se passar de 60 s, o CNPJ fica pendente e a fila segue **sem F5**; no fim, 1 nova rodada dos pendentes | Pedido do usuário: "se demorar muito, segue para o próximo" |
| 1.0.3 | Página recarregada após Representar e voltando com a **empresa anterior** → repete o **mesmo CNPJ** (até 3 vezes; depois pendente) | Antes, a extensão parava com "Representação solicitada, sem confirmação do portal" |
| 1.0.4 (13/11) | Falha de download vira recuperação **automática**: o aviso de falha do portal (ex.: 043 "Não foi possível emitir a certidão. Tente novamente daqui alguns minutos"), visto antes de o download começar, ou o download que não começa em 30 s → salva o estado, **uma** recarga e tenta de novo só o documento que falta. Espera de 15 s na 1ª vez e de 2 min depois; até 4 recargas; depois, pendente com o motivo | Etapa 11 parava em "Aperte F5". Causas: (1) o texto 043 não estava em `RE_FALHA_TEMPORARIA`; (2) a espera do download não olhava a tela; (3) o laço de downloads transformava todo erro comum em parada com "Aperte F5" |
| 1.0.5 (13/11) | **Placar** no topo de todo aviso: "Analisados: X de 208 (N%) · Faltam: Y (Z pendentes)", com uma barra de 20 blocos. Vem do registro de progresso (`atualizarPlacar`, chamado a cada leitura e gravação). "Analisado" = concluído, inclusive erro de procuração. A barra só fica cheia em 100% | Pedido do usuário: ver quantos CNPJs já foram analisados e quantos faltam, "para ter um norte" |
| 1.0.6 (13/11) | `PASTA_RAIZ` = `Situacao_Fiscal_Assecon/PRISCILLA_ASSECON`: a lista inteira roda de novo com o certificado da Priscilla, com registro de progresso novo (a chave depende da raiz) | O usuário moveu a 1ª rodada (Assecon) para `Situacao_Fiscal_Assecon\ASSECON HUB CONTABILIDADE`, criou `PRISCILLA_ASSECON` e pediu para rodar todos os CNPJs de novo |
| 1.1.0 (13/11) | **Janela no ícone** (`popup.html`/`popup.js`): aviso de que o e-CAC e a página precisam estar abertos (e se a página está aberta, com botão para abrir), campo da **pasta de destino** (dentro de Downloads; subpastas com `/`), campo dos **CNPJs** (`CNPJ` ou `CNPJ;NOME`, colar do Excel; dígitos verificadores conferidos; repetidos ignorados; zeros à esquerda repostos), placar da pasta, **Salvar e iniciar** (grava `situacao_fiscal_config` e recarrega a aba do portal) e **Zerar progresso** (dois cliques). O `content.js` lê a configuração antes de começar (`carregarConfig`; sem ela, grava o padrão do arquivo) e ignora a marca de "Representar já clicado" de CNPJ fora da lista. O ícone não recomeça mais a lista | Pedido do usuário: uma interface para escolher a pasta e os CNPJs, com o aviso do e-CAC aberto. Evita editar o código a cada nova lista ou certificado |
| 1.1.1 (13/11) | Os avisos da tela vão só para o console comum (`console.log`), nunca para `console.error`; a contagem regressiva da recuperação ("recarregando em 1:38…") é registrada uma vez, não a cada segundo | O botão **Erros** do card ficou cheio de mensagens repetidas, como o 035 da Nova Marca Portas (51.406.327/0001-07) a cada segundo. Não eram falhas de código: o Chrome copia todo `console.error` de extensão para essa lista |

## Regras de cada situação (comportamento atual)

- **Cookies:** se o aviso estiver visível, clica uma vez em Aceitar.
- **Painel já aberto:** não clica no perfil de novo.
- **CNPJ já no campo:** aproveita o valor e não digita de novo.
- **Lista de perfis já aberta:** vai direto à opção (outro clique fecharia a lista).
- **Empresa já em Representação Atual** (retomada): não representa de novo e vai à análise.
- **Representação Atual ainda com a empresa anterior:** aguarda. Se aparecer uma 3ª empresa, há divergência: para sem salvar.
- **Recusa de procuração:** confere o CNPJ no campo, salva o recorte em PDF e segue para o próximo CNPJ.
- **Diálogo "Encerrar representação":** sempre Cancelar e continuar.
- **Com pendência:** salva a captura antes de rolar a página.
- **Qualquer status:** baixa a certidão e depois o relatório, os que existirem, um por vez, e confere a pasta.
- **Download que falha** (aviso do portal antes de começar, como o 043, ou nada em 30 s): uma única recarga
  automática e nova tentativa só do documento que falta. Espera de 15 s e depois de 2 min, até 4 recargas; depois,
  pendente com o motivo. Um documento só conta como salvo quando o download termina. Só um arquivo salvo fora da
  pasta esperada para a execução e pede F5 manual.
- **"Processando…":** acompanha a página por até 60 s; depois, o CNPJ fica pendente e a fila segue.
- **"Não foi possível concluir…", carregamento > 60 s ou sem confirmação:** espera, recarrega a página e retoma (até
  3 vezes); depois, pendente.
- **Recarga após Representar com a empresa anterior:** repete o mesmo CNPJ (até 3 vezes); depois, pendente.
- **Pendentes:** 1 nova rodada no fim da lista. Os que sobrarem são listados no aviso final; um F5 tenta só esses.
- **Entre empresas:** espera pelo menos 5 s depois de concluir, e só segue com a página parada.
- **Placar:** todo aviso mostra no topo quantos CNPJs foram analisados, quantos faltam e quantos estão pendentes.
- **Ícone da extensão (v1.1.0):** abre a janela de configuração, com o aviso do e-CAC, a pasta, os CNPJs validados,
  o placar e os botões "Salvar e iniciar" e "Zerar progresso" (dois cliques). Lista ou pasta inválida não deixa
  iniciar.

## Como testamos

Não há como automatizar o portal real daqui, porque o login é manual. Cada mudança foi validada numa **página que
imita o portal**, servida localmente, que carrega o `content.js` real com a URL alvo trocada e o `chrome.*`
simulado. A página reproduzia cada problema relatado pelo usuário (seletor estilo ng-select, lista absoluta, título
"Representar" clicável, `role=dialog`, recusa repetida, "processando", F5, downloads). As páginas de teste foram
apagadas depois de cada validação, a pedido do usuário. O teste no portal real é feito pelo usuário, com prints.

## Estado em 13/11/2026

- Lista: 208 CNPJs. Na análise das pastas, **126 concluídos** (50 com pendência, 39 com certidão + relatório e 37 com
  erro de procuração) e **82 faltando**: nº 129 a 208, mais a nº 29 (Pernambuco Piso, "processando") e a nº 43 (Ana
  Maria da Silva), sem arquivos. A execução parou na nº 128 (DBG Empreendimentos), em 12/11 às 11:12.
- A Downloads\RFB_CNPJ, com os testes, foi apagada a pedido do usuário.
- Ainda em 13/11, às 10:18, a lista terminou: **207 de 208 concluídos** (82 com pendência, 68 com certidão +
  relatório e 57 com erro de procuração). Falta só a nº 202, EA Consultoria e Treinamentos (63.986.506/0001-31),
  pendente porque o portal ficou em "Estamos processando".
- Às 10:31, o usuário moveu esses resultados para `Situacao_Fiscal_Assecon\ASSECON HUB CONTABILIDADE` (e um .zip) e
  pediu uma 2ª rodada com o certificado da **Priscilla**: v1.0.6, raiz `Situacao_Fiscal_Assecon\PRISCILLA_ASSECON`,
  lista inteira do zero.

## O que ainda precisa de ajuste ou atenção

- **Não testado no portal real:** a v1.0.3 (repetir o mesmo CNPJ quando a recarga mostra a empresa anterior), o
  caminho "pendente sem F5" da v1.0.2 e a recuperação de download da v1.0.4 (testada na página simulada nos gatilhos
  "aviso 043", "sem início em 30 s" e "043 persistente até o limite") só foram validados na página que imita o portal.
- Se o portal começar o download **depois** que a extensão desistiu da tentativa, o arquivo cai na raiz de Downloads
  com o nome original. A espera no service worker já foi cancelada; a nova tentativa baixa o documento no lugar certo.
- O registro de progresso fica no Chrome e não pode ser lido de fora; a análise do que falta é feita pelas pastas
  (`ferramentas/analisar_progresso.js`).
- Trocar a pasta carregada no Chrome muda o ID da extensão e zera o progresso.
- O recorte da recusa e o gerador de PDF dependem de `captureVisibleTab`, com a aba visível.
- Se o portal mudar textos ("Representação Atual", "Trocar Representação", "Procurador de:", "Baixar Certidão",
  "Baixar Relatório", as mensagens de falha), os seletores por texto precisam de ajuste.
```
