// Situacao_Fiscal — janela da extensão (clique no ícone): pasta de destino + lista de CNPJs.
// Grava em chrome.storage.local['situacao_fiscal_config'] = { pasta, documentos: ['CNPJ;NOME', ...], t }.
// O content.js lê essa configuração ao abrir a página do portal.
'use strict';

const CHAVE_CONFIG = 'situacao_fiscal_config';
const URL_PAGINA = 'https://servicos.receitafederal.gov.br/servico/pendencias/#/analise-pendencias';
const RE_PAGINA = /^https:\/\/servicos\.receitafederal\.gov\.br\/servico\/pendencias\/?#\/analise-pendencias/;
const $ = (id) => document.getElementById(id);
const soDigitos = (s) => String(s || '').replace(/\D/g, '');

// ---------------- validação ----------------
function cnpjValido(d) {
  if (!/^\d{14}$/.test(d) || /^(\d)\1{13}$/.test(d)) return false;
  const dv = (base) => {
    let soma = 0, peso = base.length - 7;
    for (const c of base) { soma += Number(c) * peso; peso = peso === 2 ? 9 : peso - 1; }
    const r = soma % 11;
    return r < 2 ? 0 : 11 - r;
  };
  const d1 = dv(d.slice(0, 12));
  const d2 = dv(d.slice(0, 12) + d1);
  return d.endsWith(`${d1}${d2}`);
}
const formatarCnpj = (d) => `${d.slice(0, 2)}.${d.slice(2, 5)}.${d.slice(5, 8)}/${d.slice(8, 12)}-${d.slice(12)}`;

// Nome de pasta aceito pelo Windows: sem <>:"|?*, sem "." ou ".." e sem ponto/espaço no fim de cada parte.
function limparPasta(texto) {
  const partes = String(texto || '').split(/[\\/]+/)
    .map((p) => p.replace(/[<>:"|?*\u0000-\u001f]/g, '_').trim().replace(/[. ]+$/, ''))
    .filter((p) => p && p !== '.' && p !== '..');
  return partes.join('/');
}

// Cada linha: "CNPJ", "CNPJ;NOME" ou "CNPJ<TAB>NOME" (colado do Excel). O Excel tira os zeros à esquerda:
// com 12 ou 13 dígitos, completa com zeros e aceita se os dígitos verificadores baterem.
function lerLista(texto) {
  const itens = [], erros = [], vistos = new Set();
  let repetidos = 0;
  String(texto || '').split(/\r?\n/).forEach((linha, i) => {
    if (!linha.trim()) return;
    const m = linha.match(/^\s*([^;\t]*)[;\t]?(.*)$/);
    const bruto = m[1].trim();
    const nome = m[2].replace(/[;\t]+/g, ' ').replace(/\s+/g, ' ').trim();
    let d = soDigitos(bruto);
    if (d.length >= 12 && d.length < 14) d = d.padStart(14, '0');
    if (!/^[\d.\-/\s]+$/.test(bruto) || !cnpjValido(d)) { erros.push(`Linha ${i + 1}: "${bruto || linha.trim()}" não é um CNPJ válido`); return; }
    if (vistos.has(d)) { repetidos += 1; return; }
    vistos.add(d);
    itens.push(nome ? `${formatarCnpj(d)};${nome}` : formatarCnpj(d));
  });
  return { itens, erros, repetidos };
}

// ---------------- progresso (mesma regra do content.js) ----------------
const chaveProgresso = (pasta) => (pasta === 'RFB_CNPJ' ? 'situacao_fiscal_progresso' : `situacao_fiscal_progresso:${pasta}`);
const concluidoValido = (c) => !!c && (c.versao >= 2 || c.status === 'Erro de procuração' || !!c.relatorio || !!c.certidao);

async function mostrarProgresso() {
  const pasta = limparPasta($('pasta').value);
  const { itens } = lerLista($('cnpjs').value);
  if (!pasta || !itens.length) { $('progressoTexto').textContent = 'Nesta pasta: —'; $('progressoBarra').style.width = '0'; return; }
  const r = await chrome.storage.local.get(chaveProgresso(pasta));
  const p = r[chaveProgresso(pasta)] || { concluidos: {} };
  let feitos = 0, pend = 0;
  for (const item of itens) {
    const d = soDigitos(item.split(';')[0]);
    if (concluidoValido((p.concluidos || {})[d])) feitos += 1;
    else if (p.pendentes && p.pendentes[d]) pend += 1;
  }
  const pct = Math.floor((feitos / itens.length) * 100);
  $('progressoTexto').textContent = `Nesta pasta: ${feitos} de ${itens.length} analisados (${pct}%) · faltam ${itens.length - feitos}` +
    (pend ? ` (${pend} pendente${pend > 1 ? 's' : ''})` : '');
  $('progressoBarra').style.width = `${pct}%`;
}

// ---------------- tela ----------------
function atualizarTela() {
  const pasta = limparPasta($('pasta').value);
  $('caminho').textContent = pasta
    ? `Os arquivos vão para: Downloads\\${pasta.replace(/\//g, '\\')}\\<NOME DA EMPRESA>\\`
    : 'Fica dentro da pasta Downloads. Use "/" para criar subpastas.';
  const { itens, erros, repetidos } = lerLista($('cnpjs').value);
  $('contagem').innerHTML = '';
  const bom = document.createElement('span');
  bom.className = 'bom';
  bom.textContent = `${itens.length} CNPJ(s) válido(s)`;
  $('contagem').append(bom);
  if (repetidos) $('contagem').append(` · ${repetidos} repetido(s) ignorado(s)`);
  if (erros.length) {
    const ruim = document.createElement('span');
    ruim.className = 'ruim';
    ruim.textContent = ` · ${erros.length} com erro`;
    $('contagem').append(ruim);
  }
  $('erros').hidden = !erros.length;
  $('erros').replaceChildren(...erros.slice(0, 50).map((e) => { const li = document.createElement('li'); li.textContent = e; return li; }));
  $('btnIniciar').disabled = !pasta || !itens.length || erros.length > 0;
  mostrarProgresso().catch(() => {});
  desarmarZerar();
}

function mensagem(texto, tipo = '') { $('msg').className = `msg ${tipo}`; $('msg').textContent = texto; }

async function abaDoPortal() {
  const abas = await chrome.tabs.query({ url: 'https://servicos.receitafederal.gov.br/servico/pendencias/*' });
  return abas.find((a) => RE_PAGINA.test(a.url || '')) || null;
}

async function mostrarEstadoPagina() {
  const aba = await abaDoPortal().catch(() => null);
  $('estadoPagina').className = `estado ${aba ? 'ok' : 'nao'}`;
  $('estadoPagina').textContent = aba ? '✔ Página aberta — pronta para iniciar.' : '✖ A página não está aberta no Chrome.';
  $('abrirPagina').hidden = !!aba;
  return aba;
}

async function salvarEIniciar() {
  const pasta = limparPasta($('pasta').value);
  const { itens, erros } = lerLista($('cnpjs').value);
  if (!pasta) return mensagem('Informe a pasta de destino.', 'erro');
  if (!itens.length) return mensagem('Informe pelo menos um CNPJ.', 'erro');
  if (erros.length) return mensagem('Corrija os CNPJs com erro antes de iniciar.', 'erro');
  await chrome.storage.local.set({ [CHAVE_CONFIG]: { pasta, documentos: itens, t: Date.now() } });
  $('pasta').value = pasta;
  const aba = await mostrarEstadoPagina();
  if (!aba) {
    mensagem('Configuração salva. Abra o e-CAC e a página Minhas Dívidas e Pendências: a automação começa sozinha.', 'erro');
    return;
  }
  await chrome.tabs.update(aba.id, { active: true });
  await chrome.windows.update(aba.windowId, { focused: true }).catch(() => {});
  await chrome.tabs.reload(aba.id);
  mensagem(`Salvo: ${itens.length} CNPJ(s) em Downloads\\${pasta.replace(/\//g, '\\')}. Iniciando na página do portal…`, 'ok');
  setTimeout(() => window.close(), 1800);
}

// Zerar pede dois cliques (o 2º confirma) e só apaga o registro desta pasta; os arquivos já salvos continuam.
let zerarArmado = null;
function desarmarZerar() {
  clearTimeout(zerarArmado); zerarArmado = null;
  $('btnZerar').classList.remove('confirmar');
  $('btnZerar').textContent = 'Zerar progresso';
}
async function zerar() {
  const pasta = limparPasta($('pasta').value);
  if (!pasta) return mensagem('Informe a pasta cujo progresso será zerado.', 'erro');
  if (!zerarArmado) {
    $('btnZerar').classList.add('confirmar');
    $('btnZerar').textContent = 'Confirmar?';
    mensagem(`Clique de novo para zerar o progresso de "${pasta}" (a lista recomeça do 1º CNPJ; os arquivos ficam).`, 'erro');
    zerarArmado = setTimeout(desarmarZerar, 5000);
    return;
  }
  desarmarZerar();
  await chrome.storage.local.set({ [chaveProgresso(pasta)]: { concluidos: {} } });
  await mostrarProgresso();
  mensagem(`Progresso de "${pasta}" zerado. Clique em "Salvar e iniciar" para começar do 1º CNPJ.`, 'ok');
}

async function iniciarTela() {
  $('versao').textContent = `v${chrome.runtime.getManifest().version}`;
  const r = await chrome.storage.local.get(CHAVE_CONFIG);
  const cfg = r[CHAVE_CONFIG];
  if (cfg) {
    $('pasta').value = cfg.pasta || '';
    $('cnpjs').value = (cfg.documentos || []).join('\n');
  }
  atualizarTela();
  await mostrarEstadoPagina();
  $('pasta').addEventListener('input', atualizarTela);
  $('cnpjs').addEventListener('input', atualizarTela);
  $('btnIniciar').addEventListener('click', () => salvarEIniciar().catch((e) => mensagem(`Erro: ${e.message}`, 'erro')));
  $('btnZerar').addEventListener('click', () => zerar().catch((e) => mensagem(`Erro: ${e.message}`, 'erro')));
  $('btnAbrir').addEventListener('click', () => chrome.tabs.create({ url: URL_PAGINA }));
}

iniciarTela().catch((e) => mensagem(`Erro: ${e.message}`, 'erro'));
