# Situacao_Fiscal — versão 1.1.1

## Janela da extensão (clique no ícone)

Mostra um aviso, lembrando que é preciso **entrar no e-CAC e deixar aberta a página Minhas Dívidas e Pendências**,
e diz se essa página está aberta no Chrome. Se não estiver, oferece o botão para abri-la. Na janela:

- **Pasta de destino dos downloads:** fica sempre dentro de Downloads. Use `/` para criar subpastas, por exemplo
  `Situacao_Fiscal_Assecon/PRISCILLA_ASSECON`. Os caracteres que o Windows não aceita viram `_`.
- **CNPJs:** um por linha, no formato `CNPJ` ou `CNPJ;NOME DA EMPRESA` (o nome vira o nome da pasta). Pode colar do
  Excel, com o CNPJ e o nome em duas colunas. O CNPJ é conferido pelos dígitos verificadores. Os repetidos são
  ignorados. Se o Excel tirou os zeros à esquerda, eles são repostos.
- **Placar da pasta:** quantos já foram analisados e quantos faltam.
- **Salvar e iniciar:** grava a configuração e recarrega a página do portal, e a lista começa ou continua. Cada pasta
  tem o próprio progresso: numa pasta nova, começa do 1º CNPJ; na mesma pasta, continua de onde parou.
- **Zerar progresso:** precisa de dois cliques. Apaga só o registro de concluídos da pasta; os arquivos continuam.

A configuração fica em `chrome.storage.local['situacao_fiscal_config']`. Sem configuração salva, valem a lista
`DOCUMENTOS` e a `PASTA_RAIZ` do `content.js`, gravadas como padrão na primeira vez.

**Rodada atual (certificado da Priscilla):** os 208 CNPJs vão para `Situacao_Fiscal_Assecon/PRISCILLA_ASSECON`. A 1ª
rodada, com o certificado da Assecon, está em `Situacao_Fiscal_Assecon\ASSECON HUB CONTABILIDADE\`.

**Placar:** o aviso no canto inferior esquerdo mostra sempre, no topo, quantos CNPJs da lista já foram analisados e
quantos faltam, com uma barra de progresso. Ex.: `Analisados: 207 de 208 (99%) · Faltam: 1 (1 pendente)`. "Analisado"
é o CNPJ concluído, inclusive o erro de procuração com evidência salva.

Processa uma **lista de CNPJs**, um por vez. Para cada um, na página **Minhas Dívidas e Pendências**
(`https://servicos.receitafederal.gov.br/servico/pendencias/#/analise-pendencias`):

1. reconhece a tela (título + blocos **Dados Cadastrais** e **Resultado da Análise**) e registra a estrutura no console;
2. aceita os cookies, se o aviso estiver visível (um único clique em **Aceitar**);
3. abre o perfil no canto superior direito (avatar + identificação + seta);
4. confirma o painel lateral (**Representar** e **Representações Recentes**);
5. digita o CPF/CNPJ em **Digite o CPF ou CNPJ** (só os dígitos; a máscara do portal formata) e confere o valor;
6. abre **Digite um perfil de representação** e escolhe a opção com texto exatamente **Procurador**;
7. espera o botão azul **Representar** habilitar e clica uma única vez;
8. espera **Representação Atual** e compara o CNPJ ao lado de "Procurador de:" com o pedido. Se divergir, para sem salvar.
   Se o portal **recusar** (ex.: "Sua autorização como procurador não permite acesso a este serviço."), confere o CNPJ
   no campo, recorta da seção **Trocar Representação** até o campo **Procurador** (CNPJ, mensagem e perfil; sem o
   botão), salva o PDF de evidência e segue para o próximo CNPJ;
   Se a empresa **já estiver** em Representação Atual (ex.: retomada após F5), não representa de novo e vai à etapa 9.
   A extensão **nunca encerra uma representação**: se aparecer a confirmação "Encerrar representação — Você tem
   certeza…?", clica em **Cancelar** e continua o processo de onde estava. O CNPJ da própria conta logada
   (`10.754.473/0001-38`) segue o fluxo normal de Trocar Representação; se o portal recusar, salva a evidência;
9. fecha o painel com um clique no fundo escurecido e confere que a página mostra o CNPJ representado;
10. lê o **status** e a **mensagem** do Resultado da Análise (registra, por exemplo, "débito a vencer"). Se for
    **Com pendência**, captura a tela e salva em PDF antes de rolar;
11. em **qualquer** status, rola a página de forma gradual (passando pelo Detalhamento da Análise) até os botões do
    rodapé, vê quais existem e baixa **um por vez**: **Baixar Certidão** → `RFB_<CNPJ>.pdf`, depois
    **Baixar Relatório** → nome original. Só avança para o próximo CNPJ com os arquivos confirmados.

**Falha no download (certidão ou relatório)** — a própria extensão recarrega e tenta de novo, sem F5 manual:

- gatilhos: o portal mostra um aviso de falha (ex.: "Não foi possível emitir a certidão. Tente novamente daqui alguns
  minutos", código **043**) antes de o download começar, **ou** o download não começa em 30 s após o clique;
- o primeiro gatilho encerra a tentativa e dispara **uma única** recarga. Antes do F5, a extensão guarda o CNPJ, a
  etapa e os arquivos já salvos;
- depois do F5, confere o mesmo CNPJ (Representação Atual e Dados Cadastrais) e baixa **só o documento que falta**.
  Um documento só conta como salvo quando o download termina. Se o download já começou, a extensão acompanha até o
  fim;
- espera antes da recarga: 15 s na 1ª (`ESPERA_DOWNLOAD_1A_MS`); se persistir, 2 min ("alguns minutos",
  `ESPERA_FALHA_PORTAL_MS`). No máximo `MAX_RECARGAS_DOWNLOAD` (4) recargas; esgotadas, o CNPJ fica **PENDENTE**,
  com o motivo registrado, e a fila segue (nova tentativa no fim da lista).

Só um arquivo salvo **fora da pasta esperada** para a execução com aviso vermelho e pede F5, por segurança.

## Falhas temporárias do portal

Quando o portal mostra "Não foi possível concluir a ação para o contribuinte… tente novamente dentro de alguns
minutos", fica carregando sem progresso (`TIMEOUT_CARREGANDO_MS`, 60 s) ou não confirma a representação:

1. guarda o CNPJ atual, a etapa em que parou e os arquivos já salvos;
2. espera (o número de minutos que o portal indicar; "alguns minutos" = `ESPERA_FALHA_PORTAL_MS`, 2 min;
   carregamento travado = `ESPERA_CARREGAMENTO_MS`, 15 s), com contagem regressiva no aviso;
3. recarrega a página (F5) e retoma o **mesmo** CNPJ: se ele continua em Representação Atual, vai direto à análise;
   se a representação se perdeu, refaz CNPJ + Procurador + Representar. Só baixa o que ainda falta;
4. no máximo `MAX_RECARGAS_POR_CNPJ` (3) recargas por CNPJ. Persistindo, o CNPJ fica **PENDENTE** e a fila segue.
   No fim, o aviso lista os pendentes; um F5 depois tenta de novo só esses.

### "Estamos processando sua solicitação. Tente novamente em instantes."

Reconhecida pelo texto (a data e a hora depois dela são ignoradas), em qualquer etapa — inclusive na etapa 1, em que
a tela "em processamento" já vale como página reconhecida (o perfil continua no cabeçalho):

1. a extensão acompanha a página por até `ESPERA_PROCESSANDO_NA_PAGINA_MS` (60 s); se o resultado aparecer, confere o
   CNPJ em Dados Cadastrais e segue normalmente;
2. se demorar mais, o CNPJ fica **PENDENTE** (arquivos já salvos preservados) e a extensão **segue para o próximo
   CNPJ**, sem recarregar: abre o perfil e usa Trocar Representação a partir da própria tela "em processamento";
3. no fim da lista, tenta os pendentes de novo (`RODADAS_PENDENTES`, 1 vez). Se ainda falharem, o aviso final lista
   os pendentes; um F5 mais tarde tenta só esses.

### Recarga depois de "Representar" com a empresa anterior

Se o portal recarregar a página logo depois de **Representar** e ela voltar mostrando a empresa **anterior** (a
representação não pegou), a extensão repete o **mesmo CNPJ**: abre o perfil, Trocar Representação, CNPJ, Procurador e
Representar. Até `MAX_TENTATIVAS_REPRESENTAR` (3) tentativas seguidas; depois, o CNPJ fica PENDENTE e a fila segue.

## Intervalo entre empresas

Depois de concluir uma empresa (downloads ou evidência de erro de procuração salvos), espera pelo menos
`INTERVALO_ENTRE_EMPRESAS_MS` (5 s) e a página parar de carregar antes de abrir o perfil para a próxima.

## Vários downloads

A extensão libera, **só para `servicos.receitafederal.gov.br`**, a permissão do Chrome "Downloads automáticos"
(evita o bloqueio "Este site tentou baixar vários arquivos"). Ela é aplicada na instalação e antes de cada download.
Para conferir ou desfazer: `chrome://settings/content/automaticDownloads`. Os documentos continuam sendo baixados um
por vez, e cada arquivo é conferido na pasta da empresa certa.

## Onde os arquivos ficam

Em **`C:\Users\PANORAMA-PC\Downloads\Situacao_Fiscal_Assecon\`** (dentro dos Downloads do Chrome — o Chrome não
deixa extensões gravarem fora dela). A raiz é `PASTA_RAIZ` no início de `content.js`.

```
Situacao_Fiscal_Assecon/<EMPRESA>/Com_Pendencia_<CNPJ>.pdf                          (só com pendência)
Situacao_Fiscal_Assecon/<EMPRESA>/RFB_<CNPJ>.pdf                                    (certidão, quando o portal oferece)
Situacao_Fiscal_Assecon/<EMPRESA>/situação fiscal/<nome original do relatório>.pdf
Situacao_Fiscal_Assecon/<EMPRESA>/Erro_de_Procuracao/Erro_de_Procuracao_<CNPJ>.pdf  (quando o portal recusa)
```

- `<EMPRESA>` = o nome escrito na lista depois do `;` (ex.: `PRATICA CONSULTORIA & CONSTRUCOES LTDA`). Sem nome na
  lista, usa o nome de Dados Cadastrais; sem nenhum dos dois, os dígitos do CNPJ. Caracteres que o Windows não aceita
  (`<>:"/\|?*`) viram `_`; ponto no fim do nome é retirado.
- Nome repetido na lista (ex.: as filiais `47.377.778/0002` a `/0007`, todas "… LTDA PE") ganha o nº da filial no
  fim: `… LTDA PE 0002`, `… LTDA PE 0003`…
- `<CNPJ>` (nos nomes dos arquivos) = os 14 dígitos confirmados, com os zeros à esquerda, ex.: `04662526000198`.
- Cada pasta raiz tem o próprio registro de progresso: com `Situacao_Fiscal_Assecon` a lista começa do primeiro CNPJ.
  Os resultados dos testes anteriores ficaram em `Downloads\RFB_CNPJ` (com registro à parte).

Em `chrome://settings/downloads`, deixe **desligado** "Perguntar onde salvar cada arquivo", senão o Chrome abre a
janela de salvar para o relatório.

## Lista de CNPJs

No início de `content.js`, edite a lista `DOCUMENTOS` (uma linha por empresa, na ordem desejada, no formato
`CNPJ;NOME DA EMPRESA`; o nome dá nome à pasta e aparece nos avisos):

```js
const DOCUMENTOS = [
  ...
  '02.940.168/0001-02;FCA TECNOLOGIA DE INFORMACAO LTDA',
  '04.662.526/0001-98;PRATICA CONSULTORIA & CONSTRUCOES LTDA',
];
```

- Ao concluir um CNPJ, a extensão registra a conclusão (`chrome.storage.local`) e avança **uma vez** para o próximo,
  na mesma aba: abre o perfil, usa **Trocar Representação**, espera **Representação Atual** mostrar o novo CNPJ
  (enquanto mostrar o anterior, aguarda) e repete a análise. Depois do último, encerra.
- Os itens já concluídos são pulados ao abrir/recarregar a página. Na primeira vez com esta versão, um CNPJ cujo
  relatório já está em `RFB_CNPJ/<CNPJ>/situação fiscal/` conta como concluído (não refaz nem baixa de novo).
- Cada CNPJ começa com os próprios dados; comparação, nomes de arquivo e pastas saem do CNPJ confirmado.
- Recusa da representação = CNPJ concluído com "Erro de procuração — evidência salva"; a fila continua.
- Se um CNPJ falhar de outro jeito (divergência, tempo esgotado…), a execução para nele e mostra o motivo.
- **Ícone da extensão** = abre a janela de configuração (pasta + lista). Zerar o registro de concluídos é o botão
  **Zerar progresso** da janela, com dois cliques.

Se o portal recarregar a página logo depois de **Representar**, a extensão não clica de novo: se a página já mostra a
empresa pedida, segue para as etapas 9 a 11 (proteção válida por 5 minutos).

## Instalar

1. Abra `chrome://extensions` e ligue o **Modo do desenvolvedor**.
2. Clique em **Carregar sem compactação** e escolha esta pasta `Situacao_Fiscal`.
3. Depois de editar arquivos, clique no ícone de recarregar (↻) da extensão e recarregue a página.

## Testar

- Abra Minhas Dívidas e Pendências e aperte F5. Deixe a aba **visível** durante a captura da tela (etapa 10).
- O aviso no canto inferior esquerdo mostra a etapa; verde ao fim, vermelho com a etapa e o motivo se algo falhar.
- Detalhes no console (F12), com o prefixo `[Situacao_Fiscal]`.
- Tempos e velocidades (seta e digitação, separadas): bloco **CONFIGURAÇÃO** no início de `content.js`.

## Arquivos

- `manifest.json` — Manifest V3; o content script roda só em `servicos.receitafederal.gov.br`.
  `<all_urls>` é exigido pelo Chrome para capturar a tela (`captureVisibleTab`).
- `background.js` — navegação interna do portal, botão da extensão, captura da tela em PDF e redirecionamento do
  download do relatório para a pasta da empresa.
- `content.js` — reconhecimento da página, seta animada e o fluxo das 11 etapas.
