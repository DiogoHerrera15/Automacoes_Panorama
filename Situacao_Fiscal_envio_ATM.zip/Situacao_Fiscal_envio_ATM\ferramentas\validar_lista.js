// Valida a lista (CNPJ;NOME): formato, dígitos verificadores, repetidos e nomes de pasta repetidos.
const fs = require('fs');
const linhas = fs.readFileSync(process.argv[2], 'utf8').split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
const dv = (b) => { const w = b.length === 12 ? [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2] : [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2];
  const s = [...b].reduce((a, c, i) => a + c * w[i], 0) % 11; return s < 2 ? 0 : 11 - s; };
const problemas = [];
const vistos = new Map();
const nomes = new Map();
for (const l of linhas) {
  const [doc, ...n] = l.split(';');
  const nome = n.join(';').trim();
  const d = doc.replace(/\D/g, '');
  if (!/^\d{2}\.\d{3}\.\d{3}\/\d{4}-\d{2}$/.test(doc.trim())) problemas.push(`formato: ${l}`);
  if (d.length !== 14) problemas.push(`não tem 14 dígitos: ${l}`);
  else { const b = d.slice(0, 12), d1 = dv(b), d2 = dv(b + d1); if (d !== b + d1 + d2) problemas.push(`dígito verificador inválido: ${l}`); }
  if (!nome) problemas.push(`sem nome: ${l}`);
  if (vistos.has(d)) problemas.push(`CNPJ repetido: ${l}`);
  vistos.set(d, l);
  const chave = nome.replace(/[<>:"/\\|?*]/g, '_').replace(/\s+/g, ' ').trim().replace(/[. ]+$/, '').toUpperCase();
  nomes.set(chave, [...(nomes.get(chave) || []), doc.trim()]);
}
console.log('itens:', linhas.length);
console.log('problemas:', problemas.length ? problemas : 'nenhum');
const dup = [...nomes].filter(([, v]) => v.length > 1);
console.log('nomes de pasta repetidos:', dup.length ? dup.map(([k, v]) => `${k} -> ${v.join(', ')}`) : 'nenhum');
