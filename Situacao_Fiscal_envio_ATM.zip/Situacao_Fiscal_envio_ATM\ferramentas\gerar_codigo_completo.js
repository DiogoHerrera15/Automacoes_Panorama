// Gera CODIGO_COMPLETO.md: cada arquivo do projeto identificado por nome e caminho, com o conteúdo integral.
// Uso (na pasta Autom_Situacao_Fiscal):  node ferramentas\gerar_codigo_completo.js
const fs = require('fs');
const path = require('path');

const raiz = path.resolve(__dirname, '..');
const ARQUIVOS = [
  ['README.md', 'markdown', 'Como instalar e executar'],
  ['Situacao_Fiscal/manifest.json', 'json', 'Manifesto da extensão (nome, versão, permissões)'],
  ['Situacao_Fiscal/background.js', 'javascript', 'Service worker: captura em PDF, downloads, pastas, permissões'],
  ['Situacao_Fiscal/content.js', 'javascript', 'Fluxo da automação, seta, lista de CNPJs e configurações'],
  ['Situacao_Fiscal/popup.html', 'html', 'Janela da extensão (ícone): pasta de destino e lista de CNPJs'],
  ['Situacao_Fiscal/popup.js', 'javascript', 'Validação e gravação da configuração da janela'],
  ['Situacao_Fiscal/LEIA-ME.md', 'markdown', 'Manual detalhado da extensão'],
  ['ferramentas/lista_cnpjs.txt', 'text', 'Lista de CNPJs (CNPJ;NOME)'],
  ['ferramentas/validar_lista.js', 'javascript', 'Valida a lista'],
  ['ferramentas/aplicar_lista.js', 'javascript', 'Grava a lista no content.js'],
  ['ferramentas/analisar_progresso.js', 'javascript', 'Cruza a lista com as pastas salvas'],
  ['ferramentas/gerar_codigo_completo.js', 'javascript', 'Gera esta página'],
  ['CLAUDE.md', 'markdown', 'Instruções para o Claude continuar o projeto'],
  ['HISTORICO.md', 'markdown', 'Histórico de criação (decisões, problemas, regras, pendências)'],
];

const manifesto = JSON.parse(fs.readFileSync(path.join(raiz, 'Situacao_Fiscal/manifest.json'), 'utf8'));
const agora = new Date().toLocaleString('pt-BR');
const partes = [
  '# Autom_Situacao_Fiscal — código completo',
  '',
  `Extensão **${manifesto.name}**, versão **${manifesto.version}**. Página gerada em ${agora} por ` +
    '`ferramentas/gerar_codigo_completo.js`.',
  '',
  'Para reconstruir o projeto, crie cada arquivo no caminho indicado (relativo à pasta `Autom_Situacao_Fiscal`) e cole ' +
    'o conteúdo do bloco logo abaixo dele, do início ao fim, sem a linha de abertura e a de fechamento do bloco. ' +
    'Os arquivos são UTF-8.',
  '',
  '## Arquivos',
  '',
  ...ARQUIVOS.map(([p, , d], i) => `${i + 1}. \`${p}\` — ${d}`),
  '',
];

for (const [rel, lang, desc] of ARQUIVOS) {
  const texto = fs.readFileSync(path.join(raiz, rel), 'utf8').replace(/^﻿/, '');
  // cerca maior que qualquer sequência de crases dentro do arquivo
  const maior = Math.max(2, ...(texto.match(/`+/g) || ['']).map((s) => s.length));
  const cerca = '`'.repeat(maior + 1);
  const linhas = texto.split(/\r?\n/).length;
  partes.push('---', '', `## \`${rel}\``, '', `**Arquivo:** \`${path.basename(rel)}\` · **Caminho:** \`Autom_Situacao_Fiscal/${rel}\` · ` +
    `${linhas} linhas · ${Buffer.byteLength(texto, 'utf8')} bytes — ${desc}`, '', `${cerca}${lang}`, texto.replace(/\s+$/, ''), cerca, '');
}

const destino = path.join(raiz, 'CODIGO_COMPLETO.md');
fs.writeFileSync(destino, partes.join('\n'), 'utf8');
console.log(`gerado: ${destino} (${ARQUIVOS.length} arquivos)`);
