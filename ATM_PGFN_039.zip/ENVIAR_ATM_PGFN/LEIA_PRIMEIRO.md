# Automação PGFN — pacote completo (código, extensão, documentação e testes)

Versão: **extensão 0.39.0**, ajudante do Windows **1.9**, preparada em 11/11/2026.

## Por onde começar
1. **`ATM_PGFN\README.md`**: manual de uso e instalação (o que instalar, como ativar a extensão, como usar a interface e o que fazer em cada erro).
2. **`ATM_PGFN\CONTEXTO_NOVO_CHAT.md`**: explicação técnica completa (componentes, comunicação entre eles, fluxo de execução, arquivos de saída, regras).
3. **`ATM_PGFN\ESTADO_ATUAL.md`**: situação atual, últimas mudanças e o que ainda não foi testado no site real.
4. **`ATM_PGFN\HISTORICO_PROJETO.md`**: histórico das fases do desenvolvimento.
5. **`ATM_PGFN\Desenvolvimento\CONTINUIDADE_AUTOMACAO_PGFN_ate_v0.33.md`**: documento de continuidade anterior (até a 0.33).

## O que há em cada pasta
| Pasta | Conteúdo |
|---|---|
| `Extensao_Chrome\` | Extensão do Chrome (Manifest V3): `manifest.json`, `background.js` (service worker: downloads, prints, comunicação com o ajudante), `content.js` (automação das páginas e-CAC → Regularize → SISPAR), `pagina.js`, `offscreen.*` |
| `Ajudante_Windows\` | Ajudante (native messaging, PowerShell): janela "Salvar como", conferência de arquivos no disco, registro de PDFs salvos, comunicação com o orquestrador; instaladores |
| `Automacao\` | Orquestrador (`orquestrador.ps1`): percorre a lista de CNPJs, abre e fecha o Chrome, vigia travamentos, grava o andamento |
| `Interface\` | Interface WinForms: código `AutomacaoPGFN.cs`, `compilar.bat` e o `Automacao_PGFN.exe` já compilado |
| `Instalador\` | `instalar.ps1` (instalação na máquina) e `gerar_pacote.ps1` (gera o ATM_PGFN.zip) |
| `Configuracoes\` | Listas de CNPJs criadas pela interface (aqui só `exemplo_lista.json`, com dados fictícios) |
| `Desenvolvimento\testes\` | Simuladores das páginas (e-CAC, login, Regularize, SISPAR), servidor de testes (`server.js`), Chrome simulado e todos os testes automáticos |
| `Desenvolvimento\ferramentas\` | Ferramentas de desenvolvimento (sincronização entre pastas, utilitários) |
| raiz | `Instalar.bat` (instalação inicial) e `Iniciar.bat` (abre a interface) |

## O que foi retirado de propósito (dados de clientes)
- As **listas de CNPJs reais** e o **andamento** (`Configuracoes\*.json`), o **log do ajudante** (`ajudante.log`) e as **conversas exportadas** (`Historico_conversas\`).
- Nos documentos e nos testes, os **CNPJs reais foram trocados por CNPJs fictícios válidos**, sempre o mesmo fictício para o mesmo CNPJ, para os exemplos e os testes continuarem coerentes. Os **nomes de empresas e certificados** foram trocados por nomes genéricos (ex.: `CERT_A`, `EMPRESA CLIENTE 1 LTDA`).
- Nenhum certificado, senha, PIN ou token faz parte do projeto.

## Observações
- Os testes em `Desenvolvimento\testes` foram escritos no computador de desenvolvimento: alguns têm caminhos fixos desse computador e precisam de ajuste para rodar em outro.
- Para instalar em outra máquina basta esta pasta `ATM_PGFN`: rodar `Instalar.bat` e seguir o `README.md`.
