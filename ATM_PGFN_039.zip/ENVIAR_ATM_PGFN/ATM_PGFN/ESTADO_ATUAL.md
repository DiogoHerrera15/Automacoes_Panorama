# ESTADO ATUAL — Automação PGFN (10/11/2026, atualizado às 15:15 — v0.36.0 + ajudante 1.8)

> Situação real do projeto. A primeira versão deste arquivo (10/11, de manhã) foi feita sem mudar código.
> As seções **00000** (0.36.0), **0000** (0.35.0), **000** (0.34.1), **00** (0.34.0) e **0** (0.33.1) trazem as atualizações; o resto foi revisto onde mudou.

> **0.36.1 (10/11, 16:00):** ver a seção **000000** logo abaixo (print da falta de procuração).
> **0.37.0 (10/11, 17:00):** ver a seção **0000000** logo abaixo (procuração cancelada).
> **0.38.0 + ajudante 1.9 (11/11, 11:30):** ver a seção **00000000** logo abaixo (certificado fora da parte visível da lista).
> **0.39.0 (11/11, 13:15):** ver a seção **000000000** logo abaixo (aviso de Caixa Postal encerra a análise do CNPJ).

---

## 000000000. Atualização 11/11, 13:15 — aviso de Caixa Postal encerra a análise do CNPJ (v0.39.0)

- **Pedido:** nova regra que **substitui** o clique em "Ir para a Caixa Postal":
  1. print com o aviso visível, antes de qualquer outra ação;
  2. confirmar o CNPJ em processamento;
  3. salvar em `<certificado>/<CNPJ>/Caixa_Postal_<CNPJ>.pdf`;
  4. conferir o PDF; se falhar, usar a rotina existente de recuperação de salvamento;
  5. registrar "Aviso de Caixa Postal" como motivo do encerramento, atualizar o contador e ir direto para o próximo CNPJ.
  - Só quando o aviso aparecer.
- **`content.js` (`tratarAvisoCaixaPostal`, refeita):**
  - **não clica em nada** (nem em "Ir para a Caixa Postal");
  - o cabeçalho do e-CAC tem que mostrar o CNPJ em processamento (o do orquestrador);
  - print pela rotina existente `printDoAviso`: aviso visível, conferência no disco e dentro da pasta do CNPJ;
  - até 3 tentativas; uma nova tentativa não duplica o arquivo;
  - print já registrado e no disco → não salva de novo;
  - sucesso → erro definitivo `[caixa_postal] Aviso de Caixa Postal: …` com o caminho do print. O "Sair com Segurança" vem no fim do CNPJ;
  - 3 falhas → `[falha_salvamento]` (rotina existente): o CNPJ fica pendente (erro), é refeito na próxima execução, e a fila segue.
- **Escolha feita:** se o aviso for de **outro perfil** (ex.: do titular do certificado, antes da troca de perfil) ou o cabeçalho não puder ser lido, a automação **não salva** (a pasta seria a errada) e **pausa** como antes, até você resolver e voltar à página inicial. Nesse caso o CNPJ em processamento não é encerrado.
- **Orquestrador:**
  - situação final nova **`caixa_postal`**: não é refeita sozinha e não tem recuperação nem pausa;
  - contador `caixaPostal` na linha PROGRESSO (" | aviso de Caixa Postal N", só quando N > 0) e em `ultima_execucao.json`;
  - log "resultado: Aviso de Caixa Postal".
- **Interface (as duas compiladas):**
  - contador "Aviso de Caixa Postal: N" (entra no total e no %);
  - resumo da última execução;
  - **"Refazer sem procuração"** também volta esses CNPJs a pendente (use depois de ler as mensagens);
  - autoteste novo.
- **Ajudante:** só o resumo de fim de lista; a versão continua 1.9.
- **[não testado] no site real:** o aviso ainda não apareceu em nenhuma execução registrada.
- **Testes executados (11/11):**
  - **Simulador do e-CAC com o `content.js` real:**
    1. aviso do CNPJ da vez → print com o aviso na tela e o CNPJ no topo, sem visita à Caixa Postal, `[caixa_postal]`, "Sair com Segurança";
    2. pasta do certificado + 1ª captura com falha → 2ª tentativa salva **um** PDF em `CERT_TESTE_1/<CNPJ>/Caixa_Postal_<CNPJ>.pdf`;
    3. 3 falhas → `[falha_salvamento]`, sem registro falso, "Sair com Segurança";
    4. aviso do titular antes da troca → pausa, sem print e sem clique.
  - **`teste_caixa_postal.ps1` (novo; orquestrador e ajudante reais):** 11 verificações OK na Auto e na ATM:
    - situação `caixa_postal`;
    - fila seguiu (3 aberturas, sem recuperação ou pausa);
    - PROGRESSO e resumo com o contador;
    - a 2ª execução não refaz;
    - depois do "Refazer", só ele é refeito.
  - **Autoteste da interface:** TUDO OK nas duas.
  - **Regressão:** `teste_proc_cancelada`, `teste_sem_procuracao`, `teste_falha_salvamento`, `teste_sessao_pgfn`, `teste_fim_lista`: OK.
  - **Pacote:** zip 0.39.0 (21 arquivos) e portabilidade: OK.

---

## 00000000. Atualização 11/11, 11:30 — certificado só aparece depois de rolar a lista (v0.38.0 + ajudante 1.9)

- **Caso real (11/11 10:19):** a janela "Selecione um certificado" do Chrome mostra 3 linhas e tem barra de rolagem; o certificado configurado era o 4º, fora da parte visível. O ajudante 1.8 só lia as linhas que a acessibilidade mostra, que são as **visíveis**. Resultado: "achei 0 certificado(s)…" e PAUSA.
- **Descobertas na janela real (diagnóstico com prints, Chrome de teste):**
  - a acessibilidade da tabela só expõe as linhas visíveis, mas o **foco** (célula "Tema" da linha selecionada) traz o **nome completo**, mesmo cortado na tela;
  - a "linha mãe" informada pelo Chrome é reaproveitada entre as linhas: ler o nome por ela dava nomes trocados. O nome vem sempre do **próprio foco**;
  - **clicar no cabeçalho "Tema" reordena a lista.** Com a lista rolada, a 1ª linha fica meio escondida atrás do cabeçalho, e clicar nela acerta o cabeçalho (foi o que bagunçou a 1ª versão da correção);
  - quando a janela abre, o foco **já está** na lista.
- **Ajudante 1.9 (`salvar_como.ps1`):**
  - **`Linha-Em-Foco`:** nome, serial e chave da linha em foco. Só vale se o foco estiver numa célula dentro da janela de certificados; fora dela, nenhuma tecla é enviada;
  - **`Esperar-Foco-Mudar`:** espera o foco mudar de fato depois de cada tecla, até ~1,2 s;
  - **`Percorrer-Lista`:**
    - se o foco não está na lista, clica numa linha **inteiramente** visível, nunca no cabeçalho;
    - **Home**, depois **seta para baixo** até a linha em foco parar de mudar (última linha). Nunca usa Enter;
  - **`Certificado`:**
    - percorre a lista toda e conta as correspondências (`Nome-Confere`, mesmo critério: exato, sem acento e sem espaços nas pontas);
    - ≠ 1 → erro com o motivo ("achei N … entre os M da lista (percorrida até o fim)") e a lista lida → a extensão **pausa** como antes;
    - = 1 → Home e desce até ela, conferindo cada passo contra a lista lida (se a lista mudou, não escolhe). Na conferência final, nome **e serial** da linha selecionada têm que ser os do escolhido; só então clica em **OK**;
    - não há mais clique na linha antes do OK: a seleção pelo teclado já é a do Chrome;
  - versão 1.9.
- **Extensão 0.38.0 (`background.js`):** `chamarAjudante(pedido, limiteMs)`. O pedido de certificado tem 180 s; os outros continuam com 50 s.
- **[não testado] o login completo** (o teste real clica em **Cancelar**, não em OK). A 1ª execução real vai mostrar o login com o certificado escolhido.
- **Testes executados (11/11):**
  - **`teste_certificado_real.js` (novo; janela REAL do Chrome, perfil temporário, 4 certificados, 3 visíveis):**
    - nome inexistente → lista inteira lida (4), nada escolhido;
    - o **4º**, fora da parte visível (o mesmo do caso de 10:19), → selecionado, conferido (nome+serial) e botão de teste;
    - o 3º → idem.
    - **OK com o ajudante da Auto e com o da ATM.**
  - **1ª tentativa reprovada** (nomes trocados e lista reordenada), corrigida depois do diagnóstico com prints (`diag_cert*.ps1/js`, no scratchpad).
  - **Regressão:** `teste_fim_lista` (versão 1.9), `teste_sem_procuracao`, `teste_proc_cancelada`, `teste_falha_salvamento`, `teste_sessao_pgfn`, `teste_pasta_certificado`, `teste_procurar_documento` e os testes do background (colisão, salvamento, background, sair, próximo, registro): OK.
  - **Pacote:** zip 0.38.0 (21 arquivos) e portabilidade: OK.

---

## 0000000. Atualização 10/11, 17:00 — "Procuração cancelada" na troca de perfil (v0.37.0)

- **Caso real (10/11 16:52):** certificado de pessoa física (nome omitido), CNPJ 90.000.027/0001-77. Na janela "Alterar perfil de acesso" o e-CAC mostrou "A procuração eletrônica cadastrada para o detentor … do certificado digital apresentado foi cancelada em 17/07/2025". A automação não reconhecia esse aviso e ficou em "aguardando a tela carregar para conferir o topo".
- **Reconhecimento:** pelo trecho **"foi cancelada em"** (`TEXTO_PROC_CANCELADA`), porque a data e o titular variam. Ele é conferido antes de "Não existe procuração eletrônica" na espera de `conferirTopo`, que é interrompida na hora.
- **`content.js`, `tratarProcuracaoCancelada(cnpj)`:**
  1. confere que o campo "Procurador de pessoa jurídica - CNPJ" (`acharCampo`) tem o CNPJ da vez. Se não tiver, gera um erro comum (refeito na próxima execução), **sem print e sem classificar**;
  2. lê a data do aviso só para o log e a mensagem;
  3. tira o print com a mensagem, a data e o CNPJ na tela, antes de fechar a janela, pela rotina existente (`printDoAviso`, generalização da `printSemProcuracao`, mais `salvarPrintEmPdf`);
  4. salva em `Documentos_arrecadacao\<pasta do certificado>\<CNPJ>\Procuracao_Cancelada\Procuracao_Cancelada_<CNPJ>.pdf` (o Chrome cria a pasta, ou reutiliza a existente);
  5. confere no disco (existe, `%PDF`, bytes) e que ficou dentro da pasta do CNPJ;
  6. fecha a janela pelo X e lança `[procuracao_cancelada] Pendente por procuração cancelada: …` (`definitivo`, sem repetir por lentidão);
  7. o "Sair com Segurança" vem no fim do CNPJ, como no "sem procuração".
- **Orquestrador:**
  - situação nova **`procuracao_cancelada`**, em `$FINAIS`: encerra a tentativa, sem recuperação nem pausa, e não é refeita sozinha;
  - contador `procCancelada` em `Contagem`, `ultima_execucao.json` e na linha PROGRESSO (" | procuração cancelada N" só quando N > 0; a linha antiga fica igual);
  - log: "resultado: Pendente por procuração cancelada …".
- **Ajudante:** só o resumo de fim de lista mostra ", N com procuração cancelada". A versão continua 1.8; o protocolo não mudou.
- **Interface (as duas compiladas):**
  - contador "Procuração cancelada: N" (quando houver), que também entra no total e no %;
  - resumo da última execução;
  - **"Refazer sem procuração"** também volta os `procuracao_cancelada` a pendente; o botão fica ativo se houver algum;
  - autoteste novo.
- **[não testado] no site real.**
- **Testes executados (10/11, 17:00–17:25):**
  - **Simulador do e-CAC com o `content.js` real** (`index.html?cancelada=…`):
    - print em `CERT_TESTE/90000017000131/Procuracao_Cancelada/Procuracao_Cancelada_90000017000131.pdf` com mensagem, data (17/07/2025) e CNPJ no campo na tela, janela fechada **depois**, `[procuracao_cancelada]` com o caminho, "Sair com Segurança" feito;
    - campo com outro CNPJ (`outrocampo=1`) → sem print, sem classificação, erro comum;
    - "sem procuração" e troca de perfil normal continuam iguais.
  - **`teste_proc_cancelada.ps1` (novo; orquestrador e ajudante reais):** 11 verificações OK na Auto e na ATM:
    - situação `procuracao_cancelada`;
    - fila seguiu (3 aberturas, sem recuperação ou pausa);
    - PROGRESSO e resumo com o contador;
    - 2ª execução não refaz;
    - depois do "Refazer", só ela é refeita.
  - **Autoteste da interface:** TUDO OK nas duas (caso novo "procuração cancelada volta a pendente, erro intacto").
  - **Regressão:** `teste_sem_procuracao` (Auto e ATM, depois de manter a linha PROGRESSO antiga quando não há cancelada), `teste_falha_salvamento`, `teste_sessao_pgfn`, `teste_fim_lista`, `teste_pasta_certificado`, vigia (conclui, trava-uma-vez, pausa, janela) e os testes do background (colisão, salvamento, background, sair do e-CAC, próximo, registro): OK.
  - **Pacote:** zip 0.37.0 (21 arquivos) e `teste_portabilidade.js`: OK.

---

## 000000. Atualização 10/11, 16:00 — print do "Não existe procuração eletrônica" conferido (v0.36.1)

- **Pedido:** confirmar que a automação tira o print quando o e-CAC diz "Não existe procuração eletrônica para o detentor do certificado digital apresentado" **com a mensagem visível**, salva `Sem_Procuracao_<CNPJ>.pdf` na pasta do CNPJ dentro da pasta do certificado e só depois segue o fluxo. A alteração devia ficar restrita à captura e ao salvamento.
- **O que já existia (0.34.0):** com o orquestrador, `conferirTopo` → `tratarSemProcuracao` já salvava o print **antes** de fechar a janela pelo X, antes do "Sair com Segurança" e antes do próximo CNPJ. O destino era `Documentos_arrecadacao\<pasta do certificado>\<CNPJ>\Sem_Procuracao_<CNPJ>.pdf` (`pastaDocumentos()` usa `pastaCertificado` do orquestrador).
- **O que faltava, agora feito (`content.js`, função nova `printSemProcuracao`):**
  - antes da captura, confere que a frase ainda está visível e rola até ela se estiver fora da tela. Se a frase sumiu, **não** salva um print sem a mensagem e escreve no aviso/erro "a mensagem … não estava mais na tela; não salvei o print";
  - depois da captura, confere o PDF no disco (existe, é `%PDF`, tem bytes). Antes, se a conferência não respondesse, o print era dado como salvo;
  - **modo manual** (sem orquestrador, lista de teste): antes ia direto ao F5 sem print. Agora salva o mesmo print antes do F5 ou do erro final. Hoje a lista manual é vazia, então isso só vale se ela for preenchida.
- **Sem alteração:** nome do arquivo, pastas, fechamento pelo X, "Sair com Segurança", situação `sem_procuracao` no orquestrador, demais etapas.
- **Testes executados (simulador do e-CAC com o `content.js` real):**
  - orquestrador sem pasta → `Documentos_arrecadacao/90000017000131/Sem_Procuracao_90000017000131.pdf`, print com a mensagem na tela (`comAviso:true`), janela fechada **depois** do print, erro `[sem_procuracao]` com o caminho;
  - orquestrador com pasta do certificado `CERT_TESTE` e janela em iframe → `Documentos_arrecadacao/CERT_TESTE/90000017000131/Sem_Procuracao_…pdf`, com a mensagem;
  - mensagem que some antes do print (`some=1000`) → nenhum print, motivo no erro, fluxo `[sem_procuracao]` mantido;
  - modo manual com lista de 2 CNPJs (cópia temporária) → print com a mensagem e depois F5 para o próximo;
  - regressão `teste_sem_procuracao.ps1` (orquestrador real): TUDO OK; sincronização com a ATM; zip (21 arquivos, 0.36.1) e `teste_portabilidade.js`: OK.
- **[não testado] no site real:** a captura na janela verdadeira do e-CAC.
- **Simulador:** `index.html` ganhou `some=<ms>` (a mensagem some) e `orqPasta` no sessionStorage (pasta do certificado).

---

## 00000. Atualização 10/11, 15:15 — "Você não tem permissão de acesso ou ele expirou" no SISPAR (v0.36.0)

- **O que aconteceu (real, CERT_B, CNPJ 90000026000122, 3 negociações):**
  - às 14:52, ao abrir "Emissão de Documento → Documento de arrecadação" para a 3ª negociação (depois das contas 5465828 e 5465856, já conferidas), o SISPAR (`resumoParcelamentoDarfInternet.jsf`) respondeu "Erro: Você não tem permissão de acesso ou ele expirou. Feche o navegador, retorne ao Regularize e tente novamente";
  - a automação **não reconheceu** o erro nessa tela. A espera da lista/negociação em `percorrerDeferidas` só procurava PDF, detalhe e lista, então o erro virou "não encontrei a tabela…" e foi tratado como **lentidão**: repetiu 2 vezes na mesma página, à toa;
  - às 14:54:51 apareceu a página de acesso do e-CAC **sem o botão "Entrar com gov.br"**, e `loginEcac` entrou em **PAUSA "aguardando você" sem prazo** (o vigia não age em pausa). O orquestrador ficou esperando. Às 14:54:29 houve um `versao` no ajudante, que é o sinal de que a extensão foi recarregada ou reiniciada no meio da execução.
- **Causa:** o acesso ao SISPAR é por sessão, aberta pelo Regularize. Quando ela se perde ou expira, nada na mesma janela resolve; é preciso entrar de novo pelo Regularize. O texto já existia (`TEXTO_SEM_PERMISSAO`) e era reconhecido em 2 etapas, mas não na análise das negociações, e nessas etapas o erro fazia o orquestrador avançar para o próximo CNPJ, em vez de refazer o mesmo.
- **Correções:**
  - **`content.js`:**
    - a espera em `percorrerDeferidas` reconhece o erro (também depois do tempo esgotado);
    - `erroSemPermissao`, com o orquestrador, registra no log certificado, CNPJ, conta, prestação, etapa e página, mostra o aviso (vai ao orquestrador como progresso = checkpoint), grava o estado e lança um erro **definitivo** (sem repetições na mesma página) com a marca `[sessao_pgfn]`. O caminho normal do erro salva o relatório parcial e encerra a sessão do e-CAC ("Sair com Segurança", pelo `orq-finalizar`);
    - `loginEcac`: página de acesso sem o botão → recarrega 1 vez → continuando sem o botão, avisa o orquestrador com `[lentidao]` (Chrome reaberto no mesmo CNPJ) em vez de pausar sem prazo. Captcha continua sendo pausa para você.
  - **`orquestrador.ps1`:** `[sessao_pgfn]` entra na recuperação automática: fecha o Chrome da automação (só os processos dele) e refaz o **MESMO CNPJ**, com o mesmo certificado e a mesma lista, **até 3 vezes**. Os PDFs já salvos não são emitidos de novo (registro permanente), e prints do dia não se repetem. Persistindo: o CNPJ fica `erro` (pendente, refeito na próxima execução), a linha "fica pendente (com erro) e a fila segue para o próximo CNPJ", **sem pausa**. O travamento comum continua como antes (3 recuperações e PAUSA).
  - **Inalterados:** background, ajudante, interface, login normal, certificado, Regularize, emissão, salvamento, Caixa Postal, erros 500/10000/93003 e vigia.
- **Testes executados:**
  - `teste_sessao_pgfn.ps1` (novo, orquestrador real):
    - A) erro 1 vez → o mesmo CNPJ é refeito e concluído (2 aberturas dele), sem avançar antes, sem refazer a lista; contador 3/3 com 0 erro;
    - B) erro sempre → 4 aberturas (1 + 3), fica `erro`, sem pausa, e o próximo é processado; contador "2 concluídos, 1 com erro". TUDO OK.
  - Simulador SISPAR (`sisparnet?docres=com&cert=X&semperm=2`, extensão real): na 2ª abertura do menu aparece o erro; reconhecido na hora, com 0 repetições de lentidão, relatório parcial salvo e `erro: … [sessao_pgfn] …` com certificado, CNPJ, conta, etapa e página.
  - Login simulado: `/autenticacao?sembotao=1` → 2 carregamentos (1 recarga) e `erro: [lentidao] login: …`, sem pausa; `?captcha=1` → PAUSA (inalterado); login normal → certificado e e-CAC (inalterado).
  - Regressão: ver HISTORICO, Fase 11.
- **[pendente]**
  - recarregar a extensão (**0.36.0**) **com a automação parada** (recarregar no meio da execução derruba os scripts das abas abertas);
  - a execução real de 14:47 (CNPJ 90000026000122) estava parada na PAUSA do login às 15:00. Ao clicar em Parar e depois em Iniciar, ele é refeito; as contas 5465828 e 5465856 já têm print do dia, que não se repete.

---

## 0000. Atualização 10/11, 14:40 — salvamento do PDF: número de download repetido e "encerrar e avançar" (v0.35.0 + ajudante 1.8)

- **O que aconteceu (real, 13:41, certificado CERT_B, lista "lista_b_cnpjs", CNPJ 90000002000173):**
  - conta 5535214: o PDF foi salvo às 13:40:33 e o print `print_confirmacao_conta_5535214.pdf` às 13:41:01 (download nº 279 do perfil normal, feito pela extensão);
  - conta 14652591, prestação 0011: o clique no link do PDF 7172631466259011 foi às 13:41:52. Três segundos depois veio "o arquivo salvo (print_confirmacao_conta_5535214.pdf) não é o documento desta prestação", e a automação entrou em **PAUSA sem prazo**;
  - o PDF real foi salvo à mão às 13:42:26 como `7172631466259011.pdf` na pasta do CNPJ, mas a pausa não o reconheceu, porque a mesma confusão se repetiu a cada nova espera;
  - o Chrome foi fechado às 13:43 e o CNPJ ficou pendente. Ficaram 3 de 21 concluídos.
- **Causa (confirmada em teste com o código antigo):**
  - o PDF do site (janela anônima) e o print da conta anterior (perfil normal, da extensão) tinham o **mesmo número de download**. Na associação, o item do site ficou com o perfil errado, ou a busca por número devolveu só o item do outro perfil. Com isso, o `statusDownload`/`onChanged` do background leu o **print** como resultado do documento. É o mesmo padrão de 09/11 (print de uma conta, documento da próxima);
  - a conferência (`validarSalvo`) barrou o print, como deve, mas marcou o erro como **não repetível** (`r.ok` verdadeiro): sem nova tentativa, foi direto para `aguardarSalvamentoManual`, que **pausa sem prazo**. Uma pausa "aguardando você" não conta como travamento, por isso o vigia não agiu e a fila parou;
  - o teste `teste_colisao_bg.js` com o `background.js` 0.34.0 devolve exatamente `print_confirmacao_conta_5535214.pdf` como resultado. Com o 0.35.0, o print é ignorado.
- **Correções (pontuais):**
  - **`background.js`:** todo download associado guarda **número + perfil + origem** (`site` ou `extensao`). A nova `acharItemAssociado` só aceita o item que confere nos três; se a busca por número não o devolver, procura entre os downloads recentes. O `onChanged` registra só o item certo de cada prestação, e o `registrarFimDownload` recusa item de outro perfil ou origem. Sem perfil no item, vale o da aba que clicou. Também foi criada a ação `procurar-documento` (repassa ao ajudante).
  - **`salvar_como.ps1` (1.8):** nova ação `procurar-documento`. Procura na pasta do CNPJ o PDF desta prestação pelo nome pedido (ou `(1)`) ou pelo número do documento, só entre arquivos gravados depois do início da prestação, e confere o `%PDF`. Nunca aceita print, documento de outra conta ou arquivo que não é PDF. Só lê.
  - **`content.js`:**
    - `validarSalvo` identifica "outro arquivo" (print, relatório…) e o torna **repetível**;
    - `conferirSalvoAtrasado` procura o PDF no disco antes de cada nova tentativa (não duplica);
    - **com o orquestrador**, depois de 3 tentativas, `desistirDoSalvamento`:
      1. confere o disco uma última vez;
      2. fecha só a janela "Salvar como" deste documento e desarma a espera;
      3. salva a evidência `Falha_Salvamento_<CNPJ>_conta_<conta>_prest_<prest>.pdf`;
      4. marca a prestação "PENDENTE - documento NÃO baixado" com o motivo;
      5. lança erro **definitivo** `[falha_salvamento]`, que não é lentidão: relatório parcial, "Sair com Segurança", próximo CNPJ.
    - Sem orquestrador (modo manual), a pausa continua como antes.
  - **`orquestrador.ps1`:** a linha "resultado: erro - falha de salvamento (pendente; refeito na próxima execução; seguindo para o próximo CNPJ)". O CNPJ fica `erro`, entra no contador como "com erro" e é refeito no próximo Iniciar, sem repetir os PDFs já salvos (registro permanente).
  - **Inalterados:** login, certificados, interface, Deferida, cálculo e emissão, nomes e pastas, Caixa Postal, prints, erros 500/10000/93003 e vigia.
- **Política de recuperação do salvamento (nova):** até 3 tentativas do link do PDF, cada uma com até 3 tentativas do ajudante na janela "Salvar como". Antes de cada nova tentativa, procura o PDF no disco. Persistindo a falha: evidência, registro (CNPJ, conta, prestação, motivo), janela fechada, sessão encerrada e próximo CNPJ. Nunca pausa sem prazo com o orquestrador, e nunca considera concluído um documento não salvo.
- **Testes executados:**
  - `teste_colisao_bg.js` (novo, 4 casos): mesmo nº nos dois perfis com busca devolvendo só o print; item sem perfil; associação antiga sem origem; `procurar-documento`. TUDO OK no 0.35.0 (Auto e ATM). No 0.34.0 o caso B **falha com o print**, o que confirma a causa.
  - `teste_procurar_documento.js` (novo, ajudante 1.8): print, documento de outra conta, não-PDF, número do documento, arquivo antigo, `(1)` e pasta inválida. TUDO OK (Auto e ATM).
  - Simulador de páginas (`sisparnet.html`, extensão real):
    1. `sc=errado&cert=…`: 3 cliques, disco conferido antes de cada tentativa, janela fechada, evidência salva, relatório parcial, `erro: [falha_salvamento]`, sem PAUSA e sem registrar o print;
    2. `&disco=1`: PDF achado no disco pelo número depois de 1 clique, registrado, fluxo seguiu;
    3. modo manual: 3 tentativas, PAUSA e pessoa simulada salvando, fluxo seguiu;
    4. fluxo normal com a janela "Salvar como": OK.
  - `teste_falha_salvamento.ps1` (novo, orquestrador real): o CNPJ com falha fica `erro`, a fila segue (3 aberturas, sem refazer na hora), o contador mostra "3 de 3, 2 concluídos, 1 com erro" e a 2ª execução refaz só esse. TUDO OK (Auto e ATM).
  - Regressão: `teste_salvamento_bg`, `teste_background`, `teste_registro_bg`, `teste_downloads`, `teste_ajudante`, `teste_proximo`, `teste_sair_ecac`, `teste_fim_lista`, `teste_sem_procuracao`, `teste_pasta_certificado` e portabilidade com o zip novo (0.35.0, 21 arquivos). Todos OK.
- **[pendente]**
  - recarregar a extensão (**0.35.0**) e testar no site real;
  - o CNPJ 90000002000173 (CERT_B) está pendente. O PDF da prestação 0011 da conta 14652591, salvo à mão às 13:42 (`7172631466259011.pdf`, 162 KB, PDF íntegro), foi **registrado no registro permanente** às 14:35 pelo próprio ajudante (`registro-gravar`, chave `90000002000173|14652591|11|2026-11`). Na próxima execução essa prestação **não é emitida de novo**; o arquivo fica com o nome do site.

---

## 000. Atualização 10/11, 12:50 — pastas avulsas da CERT_A consolidadas e pasta do certificado sempre definida (orquestrador 0.34.1)

- **Reorganização (feita nos arquivos existentes, sem novo download):**
  - Em `Auto_PGFN\Documentos_arrecadacao` havia **25 pastas avulsas** `<CNPJ>`, fora da pasta do certificado, com 116 arquivos. São todas da CERT_A:
    - 13 têm o certificado CERT_A no `orquestrador\andamento.json` antigo;
    - 12 são dos testes manuais de 06/11, antes de existir pasta por certificado.
  - Comparação por **SHA-256** com `CERTIFICADO_EXEMPLO_A_LTDA_90000001000129\<CNPJ>`:
    - **48 arquivos copiados** (novos), cada um conferido por hash depois da cópia, com PDF íntegro (`%PDF-` … `%%EOF`) e CSV legível;
    - **68 duplicados** não copiados (já existiam na CERT_A, inclusive cópias internas como `(1)` e PDFs com nome numérico);
    - **3 com o mesmo nome e conteúdo diferente**, copiados com o sufixo ` (avulsa 1)`: `90000028000111\sem_cadastro_regularize (avulsa 1).pdf`, `90000010000110\print_confirmacao_conta_12581379 (avulsa 1).pdf` e `…12581384 (avulsa 1).pdf`;
    - **16 pastas de CNPJ novas** dentro da CERT_A, que agora tem **38 pastas e 187 arquivos** (antes: 22 e 139);
    - **0 erros**. Conferido depois: os 116 arquivos avulsos têm cópia idêntica na CERT_A.
  - **As 25 pastas avulsas foram movidas** (não apagadas) para `Auto_PGFN\_recuperacao\pastas_avulsas_CERT_A_2026-11-10_1242\`, junto com `relatorio_consolidacao.csv` (arquivo, ação, destino e SHA-256). `Documentos_arrecadacao` agora só tem a pasta da CERT_A. O usuário pode apagar a área de recuperação quando quiser.
  - Observação: o `sem_cadastro_regularize.pdf` de 90000029000166, 90000028000111, 90000030000190 e 90000016000197 é **idêntico byte a byte** entre os 4 CNPJs (a página do Regularize não mostra o CNPJ). Não é erro da cópia.
- **Por que estavam fora da CERT_A:**
  - 06/11: modo manual da extensão (sem orquestrador), que salva em `Documentos_arrecadacao\<CNPJ>`;
  - 09/11 até 15:26: orquestrador com o `cnpjs.json` antigo (certificado por trecho, `"CERTIFICADO EXEMPLO A"`, sem `pasta` e sem `exato`). Nesse formato, o orquestrador deixava `pasta` vazia e a extensão (`pastaDocumentos()`) caía na raiz.
- **Correção (`orquestrador.ps1` 0.34.1):** a montagem da fila sempre define a pasta do certificado:
  - com `pasta` na configuração (formato da interface): inalterado;
  - sem `pasta`: o nome do certificado convertido (`Pasta-Certificado`). Se for trecho e existir **uma** pasta em `Documentos_arrecadacao` que começa com esse nome (ex.: `CERTIFICADO_EXEMPLO_A` → `CERTIFICADO_EXEMPLO_A_LTDA_90000001000129`), usa essa, para não criar outra.
  - Extensão, ajudante, nomes de arquivo e interface **não mudaram**. A interface já gravava `pasta` para todo certificado.
- **Testes:**
  - novo `teste_pasta_certificado.ps1`: trecho → pasta existente; certificado novo → nome convertido; formato da interface inalterado; nenhum CNPJ sem pasta. TUDO OK na Auto e na ATM;
  - regressão `teste_sem_procuracao` e `teste_fim_lista`: TUDO OK;
  - parser do `.ps1` sem erros; zip gerado de novo.
- **Pacote para outra máquina (13:00):** o `README.md` do `ATM_PGFN.zip` (manual de quem instala) foi atualizado para 0.34.0, ajudante 1.7 e orquestrador 0.34.1: contador, fim da lista, Refazer sem procuração, `Sem_Procuracao_<CNPJ>.pdf`, pasta por certificado e `.csv`. Zip gerado de novo e conferido (21 arquivos, sem dados de cliente).
- **Limitação que continua:** o **modo manual** da extensão (sem orquestrador e sem interface) não sabe o certificado e ainda salva em `Documentos_arrecadacao\<CNPJ>`. Pela interface é sempre `Certificado → CNPJ → documentos`.

## 00. Atualização 10/11 — sem procuração definitivo, "Sair" com a janela aberta e contador (v0.34.0 + ajudante 1.7)

- **O que aconteceu (real, 09:51):**
  - O Iniciar de novo da "Lista_23_cnpjs" tentou pela **3ª vez** o 90000025000188.
  - O e-CAC disse de novo "Não existe procuração eletrônica…". A janela "Alterar perfil de acesso" ficou aberta e o "Sair com Segurança" não encerrou a sessão.
- **Causas:**
  - A falta de procuração era registrada como `erro`, e todo `erro` é refeito.
  - Não havia print.
  - O "Sair" era clicado com a janela por cima, e o log não dizia se a sessão foi encerrada.
- **[implementado]:**
  - **Situação `sem_procuracao` (final):**
    - print `Sem_Procuracao_<CNPJ>.pdf` com a mensagem;
    - janela fechada pelo X;
    - sem F5 nem nova tentativa;
    - o `erro` antigo de procuração é migrado sozinho, e o 90000025000188 vira `sem_procuracao` no próximo Iniciar, **sem acessar o e-CAC** e **sem o print**. Para gerar o print, use "Refazer sem procuração" e Iniciar.
  - **"Sair com Segurança":** fecha a janela, confirma que a página saiu, tenta 2 vezes e depois usa o endereço do botão. Sem loop.
    - O log diz "Sessão do e-CAC: encerrada" ou "não confirmada (motivo)".
  - **Contador:**
    - **na interface:** total, analisados, progresso %, concluídos, com erro, sem procuração, restantes, barra, CNPJ atual e etapa;
    - **no log:** linha PROGRESSO no início e depois de cada CNPJ terminado;
    - **no resumo final** (`ultima_execucao.json`).
    - Vem do andamento, então sobrevive a reinícios.
  - **Botão "Refazer sem procuração"** na interface.
  - **Arquivos alterados**, nas duas pastas: `content.js`, `background.js`, `manifest.json` (0.34.0), `orquestrador.ps1`, `salvar_como.ps1` (1.7) e `AutomacaoPGFN.cs` (compilada). Detalhes em `CONTEXTO_NOVO_CHAT.md` 6.9.
- **[simulado] Testes:**
  - **Simulador de páginas com a extensão real,** 4 cenários:
    - X sem texto;
    - X "×";
    - janela sem X (falha ao fechar, sem loop);
    - "Sair" normal.
  - **`teste_sem_procuracao.ps1`, novo:** 12 verificações, OK na Auto e na ATM.
  - **Regressão OK:**
    - `teste_fim_lista` e `teste_sair_ecac`;
    - `teste_background`, `teste_registro_bg`, `teste_salvamento_bg` e `teste_downloads`;
    - o vigia: `conclui`, `trava-uma-vez`, `pausa`, `janela` e `trava` com Retomar e Parar;
    - o `--autoteste` das duas interfaces e o print da janela;
    - `teste_portabilidade` com o zip novo.
- **[não testado] no site real:** o X da janela verdadeira do e-CAC, o print `Sem_Procuracao` e o "Sair" depois dele. O contador da interface também ainda não foi visto durante uma lista real.
- **Para o usuário:**
  1. Recarregar a extensão e conferir **0.34.0**.
  2. Fechar e abrir a interface (a janela aberta ainda é a versão anterior).
  3. Na "Lista_23_cnpjs", o próximo Iniciar não acessa mais o 90000025000188 e termina com "nada a fazer".

---

## 0. Atualização 10/11 — "congelamento" no fim da lista (v0.33.1 + ajudante 1.6)

- **O que aconteceu (real):**
  - A execução de "Lista_23_cnpjs" (08:18–09:19) **continuou de onde parou** e **terminou a lista**: 22 de 23 concluídos. O único com erro foi o 90000025000188, por não haver procuração.
  - A tela ficou no "Logout realizado com sucesso", com o aviso "o orquestrador fecha o Chrome e segue". Isso parecia travamento, mas **não havia próximo CNPJ**, e esse aviso estava errado para o último CNPJ.
  - Nada bloqueava a página: não havia janela nem diálogo. No log não houve TRAVAMENTO, recuperação nem pausa.
- **Atenção:** nessa execução a extensão no Chrome **ainda não era a 0.33.0**, porque não tinha sido recarregada.
  - **Prova:** nenhum pedido `orq-progresso` nem `registro-gravar` no `ajudante.log`, e o `registro_salvos.json` não existe.
  - O orquestrador 0.33 rodou bem com a extensão anterior.
- **Correção [implementada]:**
  - **Orquestrador:** grava `ultima_execucao.json` ao sair, com `terminou`, `parada`, `chrome_fechado` ou `erro` e a contagem.
  - **Ajudante 1.6:** o `orq-atual` explica o fim; também informa quando o orquestrador morreu no meio.
  - **Extensão 0.33.1:** mostra "AUTOMAÇÃO TERMINADA às HH:MM … Nada está travado; pode fechar o Chrome" e não pede login.
  - **Interface:** mostra "TERMINADA em …" com a contagem.
  - **Arquivos alterados**, nas duas pastas:
    - `orquestrador.ps1` (`$ARQ_ULTIMA`, `$encerramento`, `finally`);
    - `salvar_como.ps1` (`Orq-Ultima`, `Orq-Atual`, versão 1.6);
    - `background.js` (`orq-atual`);
    - `content.js` (`fluxoLogin`);
    - `manifest.json` (0.33.1);
    - `AutomacaoPGFN.cs` (`UltimaExecucao()`), compilada nas duas pastas.
  - **Neste PC:** foi criado `Auto_PGFN\orquestrador\ultima_execucao.json` com os dados reais das 09:19.
- **[simulado] Testes da 0.33.1:**
  - `teste_fim_lista.ps1`, novo: 8 cenários; OK na Auto e na ATM;
  - `teste_sair_ecac.js`, atualizado: OK;
  - regressão OK:
    - `teste_background`, `teste_registro_bg`, `teste_salvamento_bg` e `teste_downloads`;
    - o `--autoteste` das duas interfaces;
    - o vigia: `conclui`, `trava-uma-vez`, `pausa` de captcha, `janela` "Salvar como" real e `trava` com Retomar e Parar.
  - Sintaxe dos `.ps1` (parser) e dos `.js` (`node --check`) OK.
  - `ATM_PGFN.zip` gerado de novo (21 arquivos, extensão 0.33.1). `teste_portabilidade.js`, que espera agora o ajudante 1.6, OK com o zip novo extraído em outra pasta.
  - **Não foi testado em simulação:** a nova linha do `content.js` (`fluxoLogin` com `fim`) no simulador de páginas. Foi conferida só a sintaxe e a resposta do `background.js`/ajudante que ela usa.
- **[não testado] no site real:**
  - o aviso novo no fim de uma lista;
  - o vigia, o checkpoint e o registro em disco da extensão 0.33.
- **Para o usuário:** recarregar a extensão em `chrome://extensions` e conferir **0.33.1**. A lista "Lista_23_cnpjs" já está concluída. Rodar de novo só tentaria o 90000025000188, que continua sem procuração.
>
> **Legenda:**
> - **[real]**: confirmado no site real (pelos registros ou pelos prints do usuário);
> - **[simulado]**: validado só no simulador ou nos testes;
> - **[não testado]**: ainda sem teste.

---

## 1. Versões e instalação

| Componente | Versão/estado |
|---|---|
| Extensão | **0.34.0** nas duas pastas (a 0.33.1 veio antes, no mesmo dia). Neste PC, a carregada no Chrome é a da `Auto_PGFN` (ID `hljabalaigcloapogemdonfjdpenfiff`). **O usuário precisa clicar em "Recarregar"**: na execução de 10/11 ainda rodava a versão anterior à 0.33.0. |
| Ajudante do Windows | **1.7** (`salvar_como.ps1`). Registrado no HKCU apontando para `Auto_PGFN\ajudante_salvar_como\salvar_como.bat`. Sem reinstalar: o Chrome chama o `.ps1` a cada pedido. |
| Orquestrador | com vigia de travamentos (0.33.0) e log que não derruba a execução. |
| Interface | `Automacao_PGFN.exe`: na `Auto_PGFN` fica na raiz; na `ATM_PGFN`, em `Interface\`. Compilada com as últimas mudanças (motivo da pausa, conta e parcela). |
| ATM_PGFN | pasta de distribuição pronta, mais `Downloads\ATM_PGFN.zip` (21 arquivos, sem dados de clientes). **Não ativada neste PC.** |
| Backup | `Downloads\Backup_Auto_PGFN_2026-11-09_1610.zip` (projeto antes da ATM; sem os documentos) |

---

## 2. Funcionalidades concluídas

| Funcionalidade | Situação |
|---|---|
| Login gov.br com certificado escolhido pelo ajudante (mouse real; nome exato) | [real]: primeiro login automático em 09/11 às 09:37 (v0.28.1); seleção por nome exato desde a 0.32.0 (17:12, "CERT_A … LTDA:90000001000129") |
| e-CAC: troca de perfil, conferência do topo, "sem procuração", "Continuar no e-CAC" | [real] |
| Dívida Ativa → Regularize (CIENTE, notificações, NEGOCIAR, ACESSAR) → SISPAR (CONSULTAR, CONTINUAR, aba própria) | [real] |
| Sem cadastro no Regularize / sem "Todos os serviços do Regularize" / sem negociação / sem "Deferida" (prints e avanço) | [real] |
| Análise das "DEFERIDA E CONSOLIDADA", coluna "Emissão" até o mês atual, ícone laranja = já emitido | [real] |
| Emissão: janela de cálculo, Emitir, PDF, Voltar | [real] |
| Janela com "Calcular" (parcelas antigas): calcula com o valor apresentado, sem digitar nada | [real]: conta 5585667 (CNPJ 90000009000195), parcelas 0013 em diante (12/2022…), 36 documentos emitidos e salvos entre 13:30 e 14:01 de 09/11 com a 0.30.1 |
| Salvamento: renomeação, "Salvar como" pelo ajudante, número + perfil, correção do nome, conferência no disco | [real] (16:52 e 16:56 sem falha); recuperação de janela travada [simulado, com janela real do Windows] |
| Prints de confirmação e relatório .csv | [real] |
| Registro contra emissão repetida no mês (Chrome e, desde a 0.33, também em disco) | [real] para o do Chrome; [simulado] para o do disco |
| Cookies da PGFN ("Permitir") | [simulado]; implementado depois de visto no site real |
| Caixa Postal (print sem abrir mensagens; pausa se exigir leitura) | [simulado]; o aviso real **não apareceu** nos registros das execuções |
| Lentidão (repete, F5, `[lentidao]`) | [simulado] |
| Erro 93003 (espera 60, 180 e 300 s; "Sair com Segurança" no fim de cada CNPJ) | [simulado]; depois da correção, o 93003 **não voltou** nas execuções reais |
| Erro 10000 (print + não concluído) | [simulado] (o erro real foi o que motivou o pedido) |
| Erro 500 (5 tentativas; depois print) | [simulado] (o erro real foi o que motivou o pedido) |
| Orquestrador: um CNPJ por vez, Chrome fechado e reaberto, andamento, retomada | [real] |
| Vigia de travamentos: fecha "Salvar como", reabre o Chrome no mesmo CNPJ, pausa sem pular | [simulado] (orquestrador e ajudante reais com Chrome simulado) — **[não testado] no real** |
| Interface: configurações, validação de CNPJ, certificado exato, Iniciar/Pausar/Retomar/Parar, acompanhamento | Iniciar [real] (rodou a lista "Lista_23_cnpjs"); pausar, retomar e parar [simulado] |
| Pastas por certificado `…\<CERTIFICADO>\<CNPJ>` | [real] (ex.: 90000012000109 às 17:11) |
| Portabilidade `ATM_PGFN` (zip extraído em outra pasta) | [simulado]; **[não testado]** a extensão da ATM conversando com o ajudante pelo Chrome e o outro PC real |

---

## 3. Onde o desenvolvimento parou

### Últimas alterações (09/11, noite)
- **Versão 0.33.0 + ajudante 1.5:**
  - vigia de travamentos e checkpoint (`progresso.json`);
  - registro dos PDFs salvos também em disco (`registro_salvos.json`);
  - prints repetidos evitados na retomada;
  - pausa no lugar de pular o CNPJ;
  - motivo da pausa e conta/parcela na interface.
- **Antes disso (17:16):** a correção do orquestrador que morria quando o log estava ocupado, e a `CNPJS_TESTE` vazia.

### Última execução real (09/11, 16:3x–17:12)
- **Configuração:** "Lista_23_cnpjs" (`Auto_PGFN\configuracoes\audi_23_cnpjs.json`).
- **Às 17:12:** o orquestrador parou (causa: log ocupado, já corrigida). A extensão caiu no modo manual e analisou o CNPJ de teste 90000006000151; nada foi emitido.
- **Situação da lista "Lista_23_cnpjs":** 10 concluídos, 1 com erro, 1 em andamento e 11 pendentes.
  - **Com erro:** 90000025000188, porque não existe procuração eletrônica do certificado para esse CNPJ. É regra do site, não falha da automação.
  - **Em andamento:** 90000031000135, interrompido no login; será refeito.
  - **Pendentes:** 90000032000180, 90000033000124, 90000034000179, 90000035000113, 90000010000110, 90000036000168, 90000037000102, 90000038000157, 90000003000118, 90000039000100, 90000040000126.
- **Desde então:** nenhuma execução real com a 0.33.0.

### Execução real de 10/11 (08:18–09:19)
"Lista_23_cnpjs" continuou do 90000031000135 e **terminou**: 22 de 23 concluídos; o 90000025000188 está sem procuração. Detalhes na seção 0.

### Próxima ação esperada do usuário
**Atualizado para a 0.34.0:** veja a seção 00. O texto abaixo é da 0.33.1.

Recarregar a extensão (conferir **0.33.1**) e, na próxima lista, observar o aviso "AUTOMAÇÃO TERMINADA" no fim e o `ajudante.log`, que deve ter pedidos `orq-progresso`: a prova de que a 0.33 está rodando.

---

## 4. Problemas conhecidos e não resolvidos de vez

1. **Teste real da extensão 0.33.x:**
   - **Só simulação até agora:** o checkpoint, o registro em disco, o anti-duplicado de prints e o aviso de fim (0.33.1). Em 10/11 a extensão carregada era a anterior.
   - **Já rodou no real (10/11):** o orquestrador 0.33.
   - **Limitação:** o vigia vive no orquestrador; se ele morrer, nada reinicia sozinho. A tela avisa e o Iniciar continua.
2. **Emitido mas não salvo:**
   - **Caso:** se uma prestação for emitida e o PDF não chegar a ser salvo (a pessoa fecha ou a página recarrega), na próxima execução o ícone aparece **laranja** ("já emitido"). A automação **não emite de novo** (correto), mas **também não baixa** o documento que já existe.
   - **Exemplo:** 09/11 11:16, conta 5585667, parcela 0013. Já houve "cliquei em Emitir, mas voltei à negociação sem ver o PDF salvo".
   - **[não implementado]:** baixar o documento de um ícone laranja.
3. **Duas configurações com os mesmos 23 CNPJs:** "Lista_23_cnpjs" e "Lista do cnpjs.json (importada)", que foi salva por cima com os 23. Isso pode confundir. Sugestão: o usuário excluir a importada pela interface; o andamento fica guardado em cópia.
4. **CNPJs a conferir com o usuário:**
   - **90000041000170 (VPA):** dígito verificador inválido; ficou fora da lista de 23. Talvez seja 90000013000153 (antigo de teste). **Não confirmado.**
   - **90.000.004/0001-62** (lista antiga): era inválido. Na lista nova veio **90000036000168** (válido).
5. **Resíduos antigos nas pastas (apagar só com autorização):**
   - `Sem_Deferido_90000008000140 (1).pdf`;
   - `print_confirmacao_conta_16887494 (1).pdf` e `…16887495 (1).pdf` (CNPJ 90000006000151);
   - o `.htm` antigo na pasta 90000014000106.
6. **Relatórios com o print no lugar do documento:** de 09/11 (14h24 META 90000010000110; 14h35 GEO 90000011000164), na coluna "Arquivo" de 3 linhas, por causa da falha corrigida na 0.31.0. Os PDFs certos foram salvos à mão. Os relatórios não foram alterados.
7. **Janela "Salvar como":**
   - **Por que aparece:** a janela anônima abre a "Salvar como" mesmo com a opção desligada no perfil normal, observação de 06/11 ainda não confirmada.
   - **Como evitar:** desligar "Perguntar onde salvar cada arquivo" em `chrome://settings/downloads`. A automação **não muda** essa configuração sozinha (regra do usuário).
   - **Hoje:** o ajudante trata a janela.
8. **ATM_PGFN neste PC:** ainda não ativada. Para ativar:
   1. remover a extensão antiga;
   2. carregar `ATM_PGFN\Extensao_Chrome`;
   3. rodar `ATM_PGFN\Instalar.bat`, que registra o ajudante para o novo ID.
9. **Pontos nunca vistos no site real:** captcha do hCaptcha invisível no "Entrar com gov.br" (nunca apareceu desafio nos registros); certificado A3 ou PIN; gov.br pedindo 2 fatores. Em todos eles a automação pausa; não testado no real.
10. **Teste desatualizado:** `teste_pdf.js`. Vários testes têm caminhos fixos (`Downloads\Auto_PGFN` ou a pasta temporária antiga); ajustar antes de usar.

---

## 5. Melhorias pendentes ou sugeridas (não pedidas como obrigatórias)

- **Reaproveitar a sessão:** usar a mesma sessão do e-CAC para CNPJs do mesmo certificado, sem fechar o Chrome entre eles. Ideia citada em 09/11; não implementada.
- **Documento já emitido:** baixar o documento de uma prestação "laranja" quando não houver PDF salvo (item 2 da seção 4).
- **Status "pendente" no orquestrador:** hoje os erros 500 e 10000 ficam como "erro", com a mensagem "pendente por erro interno" e "não concluído". São refeitos na próxima execução. O usuário pediu "pendente"; foi explicado e ficou assim.
- **Chrome Web Store:** publicar a extensão evitaria o "Modo do desenvolvedor". Não foi feito.

---

## 6. Próximos passos sugeridos (em ordem)

1. **Continuar a lista:** o usuário roda "Lista_23_cnpjs" com a 0.33.0. Acompanhar o `orquestrador.log` (procurar "TRAVAMENTO", "recuperação" e "PAUSA") e o `ajudante.log`.
2. **Se travar:** analisar o log e o checkpoint do andamento antes de qualquer mudança.
3. **Outro PC:** ativar a ATM_PGFN no outro computador e validar a comunicação extensão ↔ ajudante (o passo 4 do `Instalar.bat` deve mostrar "ajudante respondeu").
4. **Decisões pendentes com o usuário:** CNPJ da VPA; excluir a configuração importada; limpar os resíduos da seção 4; baixar documentos "laranja" sem PDF salvo.
5. **A cada mudança:** levar para as duas pastas, gerar o zip de novo, atualizar este arquivo e o `HISTORICO_PROJETO.md`, e lembrar de recarregar a extensão.
