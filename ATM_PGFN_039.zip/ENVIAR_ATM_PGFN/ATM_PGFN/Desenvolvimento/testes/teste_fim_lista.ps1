﻿param([string]$Orig = 'C:\Users\PANORAMA-PC\Downloads\Auto_PGFN', [string]$PastaOrq = 'orquestrador', [string]$PastaAj = 'ajudante_salvar_como')
# 0.33.1 — fim da lista: o orquestrador grava ultima_execucao.json e o ajudante (orq-atual) explica o fim para a extensão.
# Orquestrador e ajudante REAIS copiados para uma pasta temporária isolada; "Chrome" simulado.
$ErrorActionPreference = 'Stop'
$SCR = 'C:\Users\PANORA~1\AppData\Local\Temp\claude\09de981ed91e3b47\727c250a-0de5-4b90-b949-7cf9fc86e5a8\scratchpad\testes'
$falhas = 0
function Ok($nome, $cond, $extra) { if ($cond) { "OK    $nome" } else { $script:falhas++; "FALHA $nome  $extra" } }
function Preparar {
  $T = Join-Path $env:TEMP ('pgfn_fim_' + (Get-Random))
  New-Item -ItemType Directory "$T\$PastaOrq", "$T\$PastaAj" | Out-Null
  Copy-Item "$Orig\$PastaOrq\orquestrador.ps1" "$T\$PastaOrq\"
  Copy-Item "$Orig\$PastaAj\salvar_como.ps1", "$Orig\$PastaAj\salvar_como.bat" "$T\$PastaAj\"
  '{"nome":"Lista T","certificados":[{"certificado":"EMPRESA TESTE:1","exato":true,"pasta":"EMPRESA_TESTE_1","cnpjs":["11.444.777/0001-61","11.222.333/0001-81"]}]}' | Set-Content "$T\c.json" -Encoding UTF8
  return $T
}
function Rodar($T, [scriptblock]$durante) {
  $env:PGFN_SIM = 'conclui'; $env:PGFN_SIM_CONTADOR = "$T\aberturas.txt"
  $p = Start-Process powershell -PassThru -WindowStyle Hidden -ArgumentList '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "$T\$PastaOrq\orquestrador.ps1",
    '-Config', "$T\c.json", '-Andamento', "$T\a.json", '-ChromeSimulado', "$SCR\chrome_simulado.ps1", '-MinutosTravamento', '1'
  if ($durante) { & $durante }
  [void]$p.WaitForExit(300000)
  Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" | Where-Object { $_.CommandLine -like '*pgfn_chrome_simulado*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
}
function Ajudante($T, $pedido) {
  $msg = Join-Path $env:TEMP ('pgfn_t_' + (Get-Random) + '.bin')
  $corpo = [Text.Encoding]::UTF8.GetBytes(($pedido | ConvertTo-Json -Compress))
  [IO.File]::WriteAllBytes($msg, [byte[]]([BitConverter]::GetBytes([int]$corpo.Length) + $corpo))
  $psi = New-Object Diagnostics.ProcessStartInfo 'cmd.exe', ("/d /s /c `"`"$T\$PastaAj\salvar_como.bat`" chrome-extension://teste/ < `"$msg`"`"")
  $psi.UseShellExecute = $false; $psi.RedirectStandardOutput = $true; $psi.CreateNoWindow = $true
  $pr = [Diagnostics.Process]::Start($psi); $ms = New-Object IO.MemoryStream; $pr.StandardOutput.BaseStream.CopyTo($ms); [void]$pr.WaitForExit(30000)
  Remove-Item $msg; $b = $ms.ToArray()
  return ([Text.Encoding]::UTF8.GetString($b, 4, $b.Length - 4) | ConvertFrom-Json)
}

"=== A. lista inteira termina (2 CNPJs) ==="
$T = Preparar
Rodar $T $null
$u = Get-Content "$T\$PastaOrq\ultima_execucao.json" -Raw -Encoding UTF8 | ConvertFrom-Json
Ok 'ultima_execucao: terminou' ($u.encerramento -eq 'terminou') ($u | ConvertTo-Json -Compress)
Ok 'contagem 2 de 2, 0 erro, 0 pendente' ($u.total -eq 2 -and $u.concluidos -eq 2 -and $u.erros -eq 0 -and $u.pendentes -eq 0)
Ok 'nome da lista' ($u.nome -eq 'Lista T')
Ok 'atual.json e execucao.json apagados' (-not (Test-Path "$T\$PastaOrq\atual.json") -and -not (Test-Path "$T\$PastaOrq\execucao.json"))
$r = Ajudante $T @{ acao = 'orq-atual' }
"  ajudante: $($r | ConvertTo-Json -Compress)"
Ok 'ajudante: ativo=false, fim=true' ($r.ok -and -not $r.ativo -and $r.fim -and $r.encerramento -eq 'terminou')
Ok 'ajudante: motivo AUTOMAÇÃO TERMINADA com contagem' ($r.motivo -like 'AUTOMAÇÃO TERMINADA*Lista T*2 de 2 CNPJ(s) concluído(s)*Nada está travado*')
Ok 'Chrome aberto 2 vezes (um por CNPJ)' ((Get-Content "$T\aberturas.txt") -eq '2')
$log = Get-Content "$T\$PastaOrq\orquestrador.log" -Raw -Encoding UTF8
Ok 'log: fim 2 de 2' ($log -like '*fim: 2 de 2 CNPJ(s) concluído(s)*')

"=== B. nova execução apaga o resumo antigo; lista já concluída = nada a fazer (resumo antigo fica) ==="
Rodar $T $null
Ok 'nada a fazer não estraga o resumo' ((Get-Content "$T\$PastaOrq\ultima_execucao.json" -Raw) -like '*terminou*')
Remove-Item $T -Recurse -Force

"=== C. parada pela interface no meio da lista ==="
$T = Preparar
Rodar $T { $lim = (Get-Date).AddMinutes(2); while (-not (Test-Path "$T\$PastaOrq\atual.json") -and (Get-Date) -lt $lim) { Start-Sleep 1 }
  New-Item -ItemType File "$T\$PastaOrq\parar.flag" | Out-Null }
$u = Get-Content "$T\$PastaOrq\ultima_execucao.json" -Raw -Encoding UTF8 | ConvertFrom-Json
Ok 'ultima_execucao: parada, 1 concluído e 1 pendente' ($u.encerramento -eq 'parada' -and $u.concluidos -eq 1 -and $u.pendentes -eq 1) ($u | ConvertTo-Json -Compress)
$r = Ajudante $T @{ acao = 'orq-atual' }
Ok 'ajudante: motivo PARADA, Iniciar continua' ($r.fim -and $r.motivo -like 'automação PARADA*1 de 2*Iniciar continua de onde parou*') $r.motivo
"=== D. retomada depois da parada: só o pendente é feito; resumo vira terminou 2 de 2 ==="
Remove-Item "$T\aberturas.txt"
Rodar $T $null
$u = Get-Content "$T\$PastaOrq\ultima_execucao.json" -Raw -Encoding UTF8 | ConvertFrom-Json
Ok 'retomou só o pendente (1 abertura) e terminou 2 de 2' ((Get-Content "$T\aberturas.txt") -eq '1' -and $u.encerramento -eq 'terminou' -and $u.concluidos -eq 2)

"=== E. orquestrador morto com atual.json ainda lá ==="
'{"cnpj":"11444777000161","sessao":"x","pid":999999}' | Set-Content "$T\$PastaOrq\atual.json" -Encoding UTF8
$r = Ajudante $T @{ acao = 'orq-atual' }
Ok 'ajudante: parado=true com explicação' (-not $r.ativo -and $r.parado -and $r.motivo -like '*parou antes de terminar*Iniciar*') $r.motivo
Remove-Item "$T\$PastaOrq\atual.json"
"=== F. resumo com mais de 12 h não vale ==="
$u.fim = (Get-Date).AddHours(-13).ToString('o'); [IO.File]::WriteAllText("$T\$PastaOrq\ultima_execucao.json", ($u | ConvertTo-Json), (New-Object Text.UTF8Encoding $false))
$r = Ajudante $T @{ acao = 'orq-atual' }
Ok 'ajudante: sem motivo (como antes)' ($r.ok -and -not $r.ativo -and -not $r.fim -and -not $r.motivo)
"=== G. sem nenhum arquivo ==="
Remove-Item "$T\$PastaOrq\ultima_execucao.json"
$r = Ajudante $T @{ acao = 'orq-atual' }
Ok 'ajudante: ativo=false (como antes)' ($r.ok -and -not $r.ativo -and -not $r.fim)
$r = Ajudante $T @{ acao = 'versao' }
Ok 'versão 1.9' ($r.versao -eq '1.9')
Remove-Item $T -Recurse -Force
""; if ($falhas) { "$falhas FALHA(S)" } else { 'TUDO OK' }
