// background.js de verdade: salvamento do PDF com número de download repetido nos dois perfis, janela "Salvar como",
// falhas do ajudante, fechamento controlado e download sem nome sugerido.
const fs = require('fs');
const path = require('path');
const assert = require('assert');
const vm = require('vm');
const arq = path.join(process.env.USERPROFILE, 'Downloads', 'Auto_PGFN', 'Automação_PGFN', 'background.js');
const sess = {};
const ouv = { mudou: [] };
const itens = []; // vários perfis: o mesmo id pode aparecer duas vezes
const nativas = []; // pedidos ao ajudante
let respostaAjudante = () => ({ ok: true });
const cancelados = [];
const chrome = {
  offscreen: { hasDocument: async () => true, createDocument: async () => {} },
  contentSettings: { automaticDownloads: { set: async () => {} } },
  action: { onClicked: { addListener: () => {} } },
  runtime: { id: 'EXT', onInstalled: { addListener: () => {} }, onStartup: { addListener: () => {} },
    onMessage: { addListener: (f) => { ouv.msg = f; } },
    sendNativeMessage: async (host, p) => { nativas.push(p); const r = respostaAjudante(p); if (r instanceof Error) throw r; return r; } },
  downloads: {
    onDeterminingFilename: { addListener: (f) => { ouv.nome = f; } },
    onChanged: { addListener: (f) => { ouv.mudou.push(f); }, removeListener: () => {} },
    download: async () => 999,
    search: async (q) => itens.filter((i) => (q.id === undefined || i.id === q.id) &&
      (!q.startedAfter || new Date(i.startTime) > new Date(q.startedAfter))).map((i) => ({ ...i })),
    cancel: async (id) => { cancelados.push(id); },
  },
  tabs: { query: async () => [], onCreated: { addListener: () => {} }, onRemoved: { addListener: () => {} },
    onUpdated: { addListener: () => {} }, remove: async () => {}, update: async () => ({}), create: async () => ({}), sendMessage: async () => null },
  windows: { update: async () => ({}) },
  storage: { session: {
    get: async (k) => (k in sess ? { [k]: sess[k] } : {}),
    set: async (o) => { Object.assign(sess, JSON.parse(JSON.stringify(o))); },
    remove: async (k) => { delete sess[k]; },
  }, local: { get: async () => ({}), set: async () => {} } },
};
vm.runInNewContext(fs.readFileSync(arq, 'utf8'), { chrome, console: { log: () => {}, warn: () => {} }, URL, Date, Promise, TextEncoder, btoa, atob, setTimeout, clearTimeout });
const ABA = { id: 7, windowId: 1, incognito: true };
const enviar = (msg) => new Promise((r) => { if (!ouv.msg(msg, { tab: ABA, url: 'https://sisparnet.pgfn.fazenda.gov.br/x' }, r)) setImmediate(() => r(undefined)); });
const sugerir = (item) => new Promise((r) => { ouv.nome(item, (s) => r(s)); });
const espera = (ms) => new Promise((r) => setTimeout(r, ms));
const mudou = async (id, estado) => { for (const f of ouv.mudou) await f({ id, state: { current: estado } }); await espera(10); };
const PASTA = 'Auto_PGFN/Documentos_arrecadacao/90000010000110';
const NOME = '90000010000110;EMPRESA CLIENTE 6 LTDA;11-2026;conta 12581384;prest 0020';
const resultado = (chave) => sess.download_resultados[chave];
const voltarRelogio = (chave, campo, ms) => { sess.download_resultados[chave][campo] -= ms; };
const status = async (chave) => { const s = await enviar({ tipo: 'download-status', chave }); await espera(30); return s; };

(async () => {
  // ---------- 1) número repetido: print (perfil normal, 190) x PDF do site (janela anônima, 190) ----------
  itens.push({ id: 190, incognito: false, byExtensionId: 'EXT', state: 'complete', startTime: '2026-11-09T17:22:13Z',
    filename: 'C:\\Users\\X\\Downloads\\Auto_PGFN\\Documentos_arrecadacao\\90000010000110\\print_confirmacao_conta_12581379.pdf' });
  let chave = '12581384|0020';
  await enviar({ tipo: 'download-limpar', chave });
  assert.strictEqual(await enviar({ tipo: 'download-preparar', chave, pasta: PASTA, nome: NOME, numero: '7172631317956373' }), true);
  const pdf = { id: 190, incognito: true, state: 'in_progress', filename: '', startTime: new Date().toISOString(), mime: 'application/pdf' };
  itens.push(pdf);
  const sg = await sugerir({ ...pdf, filename: '7172631317956373.pdf' });
  assert.strictEqual(sg.filename, `${PASTA}/${NOME}.pdf`);
  await espera(1600);
  respostaAjudante = (p) => (p.acao === 'confirmar' ? { ok: true, clicou: 'Salvar', corrigido: 'C:\\...\\' + p.nome } : { ok: true });
  let st = await status(chave);
  assert.ok(st.aguardandoSalvar, 'a janela "Salvar como" do download ANÔNIMO foi percebida (antes: lia o print, já completo)');
  await espera(30);
  const conf = nativas.find((p) => p.acao === 'confirmar');
  assert.ok(conf && conf.numero === '7172631317956373' && conf.nome === `${NOME}.pdf`, 'o ajudante recebe o nome e o número do documento');
  assert.strictEqual(resultado(chave).ajudante, 'salvou');
  // o print (perfil normal, mesmo número) termina de novo/avisa: não pode virar o documento
  await mudou(190, 'complete');
  assert.strictEqual(resultado(chave).ok, undefined, 'o aviso do print não conta como o PDF');
  pdf.state = 'complete'; pdf.filename = `C:\\Users\\X\\Downloads\\${PASTA.replace(/\//g, '\\')}\\${NOME}.pdf`; pdf.fileSize = 105292;
  itens[1] = pdf;
  await mudou(190, 'complete');
  st = await status(chave);
  assert.ok(st.ok && st.caminho.endsWith(`${NOME}.pdf`), `o resultado é o PDF da prestação, não o print: ${st.caminho}`);
  console.log('1 ok: número de download repetido nos dois perfis');

  // ---------- 2) falha temporária do ajudante (comunicação), depois salva ----------
  chave = '1029524|0117';
  await enviar({ tipo: 'download-limpar', chave });
  await enviar({ tipo: 'download-preparar', chave, pasta: PASTA, nome: 'X;Y;11-2026', numero: '7172631318468216' });
  const pdf2 = { id: 195, incognito: true, state: 'in_progress', filename: '', startTime: new Date().toISOString(), mime: 'application/pdf' };
  itens.push(pdf2);
  await sugerir({ ...pdf2 });
  await espera(1600);
  let n = 0;
  respostaAjudante = (p) => (p.acao !== 'confirmar' ? { ok: true } : ++n === 1 ? new Error('Native host has exited.') : { ok: true, clicou: 'Salvar' });
  await status(chave);
  assert.strictEqual(resultado(chave).ajudante, 'falhou', '1ª chamada: falha de comunicação');
  await status(chave); // logo depois: espera a pausa entre tentativas
  assert.strictEqual(n, 1, 'não repete sem a pausa');
  voltarRelogio(chave, 'tAjudanteFim', 10000);
  await status(chave);
  assert.strictEqual(n, 2); assert.strictEqual(resultado(chave).ajudante, 'salvou');
  console.log('2 ok: falha temporária do ajudante, salvo na 2ª tentativa');

  // ---------- 3) ajudante falha 3 vezes: esgotado -> fechar a janela de forma controlada ----------
  chave = '5270112|0061';
  await enviar({ tipo: 'download-limpar', chave });
  await enviar({ tipo: 'download-preparar', chave, pasta: PASTA, nome: 'X;Y;11-2026;conta 5270112;prest 0061', numero: '7172631318602150' });
  const pdf3 = { id: 196, incognito: true, state: 'in_progress', filename: '', startTime: new Date().toISOString(), mime: 'application/pdf' };
  itens.push(pdf3);
  await sugerir({ ...pdf3 });
  await espera(1600);
  n = 0;
  respostaAjudante = (p) => (p.acao === 'confirmar' ? (++n, { ok: false, erro: 'cliquei em "Salvar", mas a janela não fechou' })
    : p.acao === 'cancelar' ? { ok: true, fechou: true } : { ok: true });
  for (let i = 0; i < 6; i++) { await status(chave); if (resultado(chave).tAjudanteFim) voltarRelogio(chave, 'tAjudanteFim', 10000); }
  assert.strictEqual(n, 3, 'no máximo 3 chamadas'); assert.strictEqual(resultado(chave).ajudante, 'esgotado');
  st = await status(chave);
  assert.ok(st.aguardandoSalvar && st.ajudante === 'esgotado', 'a aba vê "esgotado"');
  const f = await enviar({ tipo: 'download-fechar-janela', chave });
  assert.ok(f.ok && f.fechou, JSON.stringify(f));
  const canc = nativas.filter((p) => p.acao === 'cancelar').at(-1);
  assert.ok(canc.numero === '7172631318602150' && /prest 0061\.pdf$/.test(canc.nome), 'cancelar só a janela deste documento');
  assert.deepStrictEqual(cancelados, [196]);
  pdf3.state = 'interrupted'; pdf3.error = 'USER_CANCELED';
  await mudou(196, 'interrupted');
  st = await status(chave);
  assert.ok(st.ok === false && st.cancelado, 'download cancelado registrado como não salvo');
  await status(chave); assert.strictEqual(n, 3, 'depois de fechada, o ajudante não é chamado de novo');
  console.log('3 ok: 3 falhas -> janela fechada de forma controlada, sem loop');

  // ---------- 4) chamada ao ajudante perdida ("chamando" sem fim): nova tentativa depois de 70 s ----------
  chave = 'k4|0001';
  await enviar({ tipo: 'download-limpar', chave });
  await enviar({ tipo: 'download-preparar', chave, pasta: PASTA, nome: 'A;B;11-2026', numero: '1234567890' });
  const pdf4 = { id: 300, incognito: true, state: 'in_progress', filename: '', startTime: new Date().toISOString() };
  itens.push(pdf4); await sugerir({ ...pdf4 }); await espera(1600);
  sess.download_resultados[chave] = { ...resultado(chave), ajudante: 'chamando', ajudanteTentativas: 1, tAjudante: Date.now() - 80000 };
  n = 0; respostaAjudante = (p) => (p.acao === 'confirmar' ? (++n, { ok: true }) : { ok: true });
  await status(chave);
  assert.strictEqual(n, 1); assert.strictEqual(resultado(chave).ajudanteTentativas, 2);
  console.log('4 ok: chamada perdida ao ajudante é refeita');

  // ---------- 5) o Chrome não chamou o ouvinte do nome: procura o download do site ----------
  chave = 'k5|0002';
  await enviar({ tipo: 'download-limpar', chave });
  const desde = Date.now();
  await enviar({ tipo: 'download-preparar', chave, pasta: PASTA, nome: 'A;B;12-2026', numero: '5555555555' });
  await espera(20);
  itens.push({ id: 400, incognito: false, byExtensionId: 'EXT', state: 'complete', startTime: new Date().toISOString(), filename: 'C:\\print.pdf' });
  let p = await enviar({ tipo: 'download-procurar', chave, desde, numero: '5555555555' });
  assert.ok(!p.achou, 'print da extensão nunca é tomado como documento');
  itens.push({ id: 401, incognito: true, state: 'in_progress', filename: '', startTime: new Date().toISOString(), url: 'https://sisparnet/x' });
  itens.push({ id: 402, incognito: true, state: 'in_progress', filename: '', startTime: new Date().toISOString(), url: 'https://sisparnet/y' });
  p = await enviar({ tipo: 'download-procurar', chave, desde, numero: '5555555555' });
  assert.ok(!p.achou && p.candidatos === 2, 'dois candidatos sem o número: não escolhe');
  itens.find((i) => i.id === 402).state = 'interrupted';
  p = await enviar({ tipo: 'download-procurar', chave, desde, numero: '5555555555' });
  assert.ok(p.achou, 'um candidato: associa');
  assert.strictEqual(resultado(chave).id, 401); assert.strictEqual(resultado(chave).anonimo, true);
  assert.strictEqual(sess.download_espera, undefined, 'espera desarmada (não renomeia outro download)');
  console.log('5 ok: download sem nome sugerido encontrado com segurança');
  console.log('salvamento (background): todos os testes passaram');
})().catch((e) => { console.error(e); process.exit(1); });
