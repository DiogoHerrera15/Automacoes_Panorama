﻿param([string]$Orig = 'C:\Users\PANORAMA-PC\Downloads\Auto_PGFN', [string]$PastaOrq = 'orquestrador', [string]$PastaAj = 'ajudante_salvar_como')
# 0.37.0 — procuração cancelada: situação própria "procuracao_cancelada" (Pendente por procuração cancelada), encerra a
# tentativa (sem recuperação), contador próprio, segue para o próximo CNPJ e não é refeito até "Refazer sem procuração".
# Orquestrador e ajudante REAIS em pasta temporária; "Chrome" simulado.
$ErrorActionPreference = 'Stop'
$SCR = Split-Path -Parent $MyInvocation.MyCommand.Path
$falhas = 0
function Ok($nome, $cond, $extra) { if ($cond) { "OK    $nome" } else { $script:falhas++; "FALHA $nome  $extra" } }
$T = Join-Path $env:TEMP ('pgfn_cancel_' + (Get-Random))
New-Item -ItemType Directory "$T\$PastaOrq", "$T\$PastaAj" | Out-Null
Copy-Item "$Orig\$PastaOrq\orquestrador.ps1" "$T\$PastaOrq\"
Copy-Item "$Orig\$PastaAj\salvar_como.ps1", "$Orig\$PastaAj\salvar_como.bat" "$T\$PastaAj\"
'{"nome":"Lista PC","certificados":[{"certificado":"EMPRESA TESTE:1","exato":true,"pasta":"EMPRESA_TESTE_1","cnpjs":["11.444.777/0001-61","90.000.023/0001-99","90.000.006/0001-51"]}]}' | Set-Content "$T\c.json" -Encoding UTF8
function Rodar([string]$cancel = '90000023000199') {
  $env:PGFN_SIM = 'conclui'; $env:PGFN_SIM_CONTADOR = "$T\aberturas.txt"; $env:PGFN_SIM_CANCELADA = $cancel
  Remove-Item "$T\aberturas.txt" -ErrorAction SilentlyContinue
  $p = Start-Process powershell -PassThru -WindowStyle Hidden -ArgumentList '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "$T\$PastaOrq\orquestrador.ps1",
    '-Config', "$T\c.json", '-Andamento', "$T\a.json", '-ChromeSimulado', "$SCR\chrome_simulado.ps1", '-MinutosTravamento', '1'
  [void]$p.WaitForExit(300000)
  Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" | Where-Object { $_.CommandLine -like '*pgfn_chrome_simulado*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
  $env:PGFN_SIM_CANCELADA = ''
}
"=== 1ª execução ==="
Rodar
$a = Get-Content "$T\a.json" -Raw -Encoding UTF8 | ConvertFrom-Json
$log = Get-Content "$T\$PastaOrq\orquestrador.log" -Raw -Encoding UTF8
Ok 'cancelada registrada como procuracao_cancelada' ($a.'90000023000199'.situacao -eq 'procuracao_cancelada') $a.'90000023000199'.situacao
Ok 'mensagem guarda a marca e o print' ($a.'90000023000199'.mensagem -like '*[[]procuracao_cancelada]*Procuracao_Cancelada_90000023000199.pdf*')
Ok 'os outros dois concluídos (fila seguiu)' ($a.'11444777000161'.situacao -eq 'concluido' -and $a.'90000006000151'.situacao -eq 'concluido')
Ok '3 aberturas do Chrome (sem recuperação da cancelada)' ((Get-Content "$T\aberturas.txt") -eq '3') (Get-Content "$T\aberturas.txt")
Ok 'não virou recuperação/travamento/pausa' ($log -notmatch 'recuperação automática' -and $log -notmatch 'TRAVAMENTO' -and $log -notmatch 'PAUSA')
Ok 'log: Pendente por procuração cancelada' ($log -like '*resultado: Pendente por procuração cancelada*')
Ok 'log: PROGRESSO com contador próprio' ($log -like '*PROGRESSO: 2 de 3 analisados (66%) | concluídos 1 | com erro 0 | sem procuração 0 | procuração cancelada 1 | restantes 1*' -and $log -like '*PROGRESSO: 3 de 3 analisados (100%) | concluídos 2 | com erro 0 | sem procuração 0 | procuração cancelada 1 | restantes 0*')
$u = Get-Content "$T\$PastaOrq\ultima_execucao.json" -Raw -Encoding UTF8 | ConvertFrom-Json
Ok 'resumo: 2 concluídos, 1 procuração cancelada, 0 restantes, 100%' ($u.concluidos -eq 2 -and $u.procCancelada -eq 1 -and $u.erros -eq 0 -and $u.pendentes -eq 0 -and $u.percentual -eq 100) ($u | ConvertTo-Json -Compress)
"=== 2ª execução: não é refeita sozinha ==="
Rodar
$log2 = (Get-Content "$T\$PastaOrq\orquestrador.log" -Encoding UTF8 | Select-Object -Last 12) -join "`n"
Ok 'cancelada não é tentada de novo (nada a fazer, Chrome não abre)' ($log2 -like '*nada a fazer.*' -and -not (Test-Path "$T\aberturas.txt"))
"=== procuração renovada: Refazer + 3ª execução refaz só ela ==="
$j = Get-Content "$T\a.json" -Raw -Encoding UTF8 | ConvertFrom-Json
foreach ($p in $j.PSObject.Properties) { if ($p.Value.situacao -eq 'procuracao_cancelada') { $p.Value.situacao = 'pendente' } }
[IO.File]::WriteAllText("$T\a.json", ($j | ConvertTo-Json -Depth 5), (New-Object Text.UTF8Encoding $false))
Rodar ''
$a = Get-Content "$T\a.json" -Raw -Encoding UTF8 | ConvertFrom-Json
Ok 'refeita só ela (1 abertura) e agora concluída' ((Get-Content "$T\aberturas.txt") -eq '1' -and $a.'90000023000199'.situacao -eq 'concluido')
Remove-Item $T -Recurse -Force
""; if ($falhas) { "$falhas FALHA(S)" } else { 'TUDO OK' }
