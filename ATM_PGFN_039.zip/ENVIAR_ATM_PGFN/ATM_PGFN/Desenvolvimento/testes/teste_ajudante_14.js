// Ajudante 1.4: orq-atual com pasta do certificado e seleção exata; escolha exata do certificado (função real).
const { spawn, spawnSync } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');
const assert = require('assert');
const ORIG = path.join(process.env.USERPROFILE, 'Downloads', 'Auto_PGFN', 'ajudante_salvar_como', 'salvar_como.ps1');
const T = fs.mkdtempSync(path.join(os.tmpdir(), 'pgfn_aj14_'));
fs.mkdirSync(path.join(T, 'ajudante_salvar_como')); fs.mkdirSync(path.join(T, 'orquestrador'));
const AJ = path.join(T, 'ajudante_salvar_como', 'salvar_como.ps1');
fs.copyFileSync(ORIG, AJ);
const pedir = (pedido) => new Promise((ok) => {
  const p = spawn('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', AJ]);
  const partes = []; p.stdout.on('data', (d) => partes.push(d));
  p.on('close', () => { const b = Buffer.concat(partes); ok(JSON.parse(b.slice(4, 4 + b.readInt32LE(0)).toString('utf8'))); });
  const j = Buffer.from(JSON.stringify(pedido), 'utf8'); const c = Buffer.alloc(4); c.writeInt32LE(j.length); p.stdin.end(Buffer.concat([c, j]));
});
(async () => {
  assert.strictEqual((await pedir({ acao: 'versao' })).versao, '1.4');
  const atual = (extra) => fs.writeFileSync(path.join(T, 'orquestrador', 'atual.json'), JSON.stringify({ cnpj: '11222333000181', certificado: 'EMPRESA B:1', sessao: 's', pid: process.pid, ...extra }));
  atual({ pastaCertificado: 'EMPRESA_B_1', certificadoExato: true });
  let r = await pedir({ acao: 'orq-atual' });
  assert.ok(r.ativo && r.pastaCertificado === 'EMPRESA_B_1' && r.certificadoExato === true, JSON.stringify(r));
  atual({ pastaCertificado: '../fora', certificadoExato: false });
  r = await pedir({ acao: 'orq-atual' });
  assert.ok(r.ativo && !('pastaCertificado' in r) && !('certificadoExato' in r), 'pasta inválida é ignorada: ' + JSON.stringify(r));
  atual({}); // atual.json antigo (sem os campos novos): como antes
  r = await pedir({ acao: 'orq-atual' });
  assert.ok(r.ativo && !r.pastaCertificado, JSON.stringify(r));
  console.log('ok: orq-atual com pasta do certificado / exato; pasta inválida ignorada; formato antigo');

  // função real Escolher-Certificados (extraída do script), com "certificados" de mentira
  const teste = `
$ErrorActionPreference='Stop'
$src = Get-Content -LiteralPath '${AJ.replace(/'/g, "''")}' -Raw -Encoding UTF8
$ast = [System.Management.Automation.Language.Parser]::ParseInput($src, [ref]$null, [ref]$null)
foreach ($n in 'Sem-Acento','Escolher-Certificados') { $f = $ast.Find({ param($x) $x -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $x.Name -eq $n }, $true); Invoke-Expression $f.Extent.Text }
function C($n) { [pscustomobject]@{ Current = [pscustomobject]@{ Name = $n } } }
$temas = @((C 'CERTIFICADO EXEMPLO A LTDA:90000001000129'), (C 'CERTIFICADO EXEMPLO A LTDA:1189542800016'), (C 'Empresa Ação:1'), (C 'EMPRESA ACAO:1'))
$r = @()
$r += @(Escolher-Certificados $temas 'CERTIFICADO EXEMPLO A LTDA:90000001000129' $true).Count  # 1 (não pega o ...016)
$r += @(Escolher-Certificados $temas 'CERTIFICADO EXEMPLO A' $true).Count                       # 0 (trecho não vale)
$r += @(Escolher-Certificados $temas 'empresa acao:1' $true).Count                                        # 2 (duplicados: pede confirmação)
$r += @(Escolher-Certificados $temas 'CERTIFICADO EXEMPLO A LTDA:90000001000129' $false).Count # 1 (modo antigo, trecho)
$r += @(Escolher-Certificados $temas 'CERTIFICADO EXEMPLO A' $false).Count                      # 2 (modo antigo: ambíguo = não escolhe)
$r -join ','`;
  const s = spawnSync('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', teste], { encoding: 'utf8' });
  assert.strictEqual(s.stdout.trim(), '1,0,2,1,2', s.stdout + s.stderr);
  console.log('ok: escolha exata (nome inteiro; trecho não vale; duplicados = 2, não escolhe; modo antigo preservado)');
  fs.rmSync(T, { recursive: true, force: true });
  console.log('ajudante 1.4: todos os testes passaram');
})().catch((e) => { console.error(e); process.exit(1); });
