// background.js de verdade: a aba do e-CAC viaja com o andamento e recebe o próximo CNPJ.
const fs = require('fs');
const path = require('path');
const assert = require('assert');
const vm = require('vm');
const arq = path.join(process.env.USERPROFILE, 'Downloads', 'Auto_PGFN', 'Automação_PGFN', 'background.js');
const sess = {};
const ouv = {};
const feito = { ativou: [], recarregou: [], fechou: [] };
const nada = { addListener: () => {} };
const chrome = {
  offscreen: { hasDocument: async () => true, createDocument: async () => {} },
  contentSettings: { automaticDownloads: { set: async (o) => { (globalThis.__cs = globalThis.__cs || []).push(o); } } },
  action: { onClicked: nada },
  runtime: { id: 'EXT', onInstalled: { addListener: () => {} }, onStartup: { addListener: () => {} }, onMessage: { addListener: (f) => { ouv.msg = f; } } },
  downloads: { onDeterminingFilename: nada, onChanged: nada },
  tabs: { query: async () => [],
    onCreated: nada, onRemoved: nada, onUpdated: nada,
    get: async (id) => { if (id === 99) throw new Error('não existe'); return { id }; },
    update: async (id) => { feito.ativou.push(id); }, reload: async (id) => { feito.recarregou.push(id); },
    remove: async (id) => { feito.fechou.push(id); }, create: async () => ({}), sendMessage: async () => null,
  },
  storage: { session: {
    get: async (k) => (k in sess ? { [k]: sess[k] } : {}),
    set: async (o) => { Object.assign(sess, o); },
    remove: async (k) => { delete sess[k]; },
  } },
};
vm.runInNewContext(fs.readFileSync(arq, 'utf8'), { chrome, console, URL, Date, Promise, setTimeout: (f) => setTimeout(f, 5) });
const enviar = (msg, aba, url) => new Promise((r) => { if (!ouv.msg(msg, { tab: { id: aba, windowId: 1 }, url }, r)) setImmediate(() => r(undefined)); });
const espera = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  // e-CAC (aba 1) -> Regularize (aba 2): o Regularize fica sabendo qual é a aba do e-CAC
  await enviar({ tipo: 'transferencia-iniciar', cnpj: '90000005000107', concluidos: [] }, 1, 'https://cav.receita.fazenda.gov.br/ecac/');
  const eReg = await enviar({ tipo: 'estado-ler' }, 2, 'https://www.regularize.pgfn.gov.br/');
  assert.strictEqual(eReg.abaEcac, 1);
  // Regularize -> SISPAR (aba 3): a aba do e-CAC e a do Regularize viajam juntas
  await enviar({ tipo: 'transferencia-iniciar', destino: 'sisparnet', cnpj: '90000005000107', abaEcac: 1, concluidos: [] }, 2, 'https://www.regularize.pgfn.gov.br/');
  const eSis = await enviar({ tipo: 'estado-ler' }, 3, 'https://sisparnet.pgfn.fazenda.gov.br/x');
  assert.strictEqual(eSis.abaEcac, 1); assert.strictEqual(eSis.abaRegularize, 2);
  // próximo CNPJ: o e-CAC recebe o andamento novo e recarrega; Regularize e SISPAR fecham
  assert.strictEqual(await enviar({ tipo: 'proximo-cnpj', cnpj: '90000003000118', concluidos: ['90000005000107'], abaEcac: 1, abaRegularize: 2 }, 3), true);
  const eEcac = sess.aba_1;
  assert.strictEqual(eEcac.cnpj, '90000003000118'); assert.strictEqual(eEcac.etapa, 0); assert.deepStrictEqual(eEcac.concluidos, ['90000005000107']);
  assert.deepStrictEqual(feito.ativou, [1]); assert.deepStrictEqual(feito.recarregou, [1]);
  await espera(30);
  assert.deepStrictEqual(feito.fechou.sort(), [2, 3]);
  // aba do e-CAC fechada ou CNPJ inválido: recusa
  assert.strictEqual(await enviar({ tipo: 'proximo-cnpj', cnpj: '90000003000118', abaEcac: 99 }, 3), false);
  assert.strictEqual(await enviar({ tipo: 'proximo-cnpj', cnpj: 'x', abaEcac: 1 }, 3), false);
  console.log('próximo CNPJ: todos os testes passaram');
})().catch((e) => { console.error(e); process.exit(1); });
