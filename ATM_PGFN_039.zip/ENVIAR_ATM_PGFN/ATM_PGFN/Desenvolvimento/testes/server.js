const http = require('http');
const fs = require('fs');
const path = require('path');
const CONTENT = process.env.PGFN_CONTENT || path.join(process.env.USERPROFILE, 'Downloads', 'Auto_PGFN', 'Automação_PGFN', 'content.js');
const atender = (req, res) => {
  const u = new URL(req.url, 'http://localhost');
  if (u.pathname === '/content.js') {
    // acelera só os tempos do teste; o arquivo em si não muda
    const src = fs.readFileSync(CONTENT, 'utf8')
      .replace("const CNPJS_TESTE = ['90000005000107'];", process.env.PGFN_DOIS ? "const CNPJS_TESTE = ['90000005000107', '90000003000118'];" : "const CNPJS_TESTE = ['90000005000107'];")
      .replace('const ESPERA_DOCUMENTO_MS = 45000;', 'const ESPERA_DOCUMENTO_MS = 9000;')
      .replace("/(^|\\.)cav\\.receita\\.fazenda\\.gov\\.br$/.test(location.hostname) && /^\\/autenticacao/i.test(location.pathname)", "/^\\/autenticacao/i.test(location.pathname)")
      .replace('const ESPERAS_93003_S = [60, 180, 300];', 'const ESPERAS_93003_S = [3, 3, 3];')
      .replace('const ESPERAS_500_S = [15, 30, 60, 90, 120];', 'const ESPERAS_500_S = [2, 2, 2, 2, 2];')
      .replace("/(^|\\.)sso\\.acesso\\.gov\\.br$/.test(location.hostname)", "location.pathname === '/sso'")
      .replace('const ESPERA_LOGIN_MS = 30000;', 'const ESPERA_LOGIN_MS = 6000;')
      .replace('const LENTIDAO_MOUSE = 1.1;', 'const LENTIDAO_MOUSE = 0.25;')
      .replace('const TIMEOUT_ELEMENTO_MS = 20000;', 'const TIMEOUT_ELEMENTO_MS = 2500;')
      .replace('const TIMEOUT_JANELA_MS = 8000;', 'const TIMEOUT_JANELA_MS = 800;')
      .replace('const TIMEOUT_TROCA_PERFIL_MS = 45000;', 'const TIMEOUT_TROCA_PERFIL_MS = 3000;')
      .replace('const LENTIDAO_DIGITACAO = 1.8;', 'const LENTIDAO_DIGITACAO = 0.3;')
      .replace('const TIMEOUT_REGULARIZE_MS = 45000;', 'const TIMEOUT_REGULARIZE_MS = 15000;')
      .replace('const ESPERA_AVISO_CIENTE_MS = 10000;', 'const ESPERA_AVISO_CIENTE_MS = 2500;')
      .replace('const ESPERA_ABRIR_JANELA_MS = 10000;', 'const ESPERA_ABRIR_JANELA_MS = 800;')
      .replace('const ESPERA_REACAO_CONTINUAR_MS = 15000;', 'const ESPERA_REACAO_CONTINUAR_MS = 1500;')
      .replace('/(^|\\.)regularize\\.pgfn\\.gov\\.br$/.test(location.hostname)', "location.pathname === '/regularize'")
      .replace('/[/.]regularize\\.pgfn\\.gov\\.br$/.test(o)', 'o.endsWith(":8765")')
      .replace('!/(^|\\.)(cav\\.receita\\.fazenda|regularize\\.pgfn|sisparnet\\.pgfn\\.fazenda|sso\\.acesso)\\.gov\\.br$/.test(location.hostname)', 'false')
      .replace('/(^|\\.)sisparnet\\.pgfn\\.fazenda\\.gov\\.br$/.test(location.hostname)', "location.pathname === '/sisparnet'")
      .replace('const ESPERA_ANTES_DE_REPETIR_MS = [6000, 10000];', 'const ESPERA_ANTES_DE_REPETIR_MS = [400, 700];');
    // auto.flag presente = testa o modo automático (sem clique manual)
    const final = fs.existsSync(path.join(__dirname, 'auto.flag'))
      ? src.replace('const CLIQUE_MANUAL_NO_DOCUMENTO = true;', 'const CLIQUE_MANUAL_NO_DOCUMENTO = false;') : src;
    res.writeHead(200, { 'content-type': 'text/javascript; charset=utf-8' });
    return res.end(final);
  }
  if (u.pathname === '/pagina.js') {
    res.writeHead(200, { 'content-type': 'text/javascript; charset=utf-8' });
    return res.end(fs.readFileSync(path.join(path.dirname(CONTENT), 'pagina.js'), 'utf8'));
  }
  if (u.pathname === '/autenticacao' || u.pathname === '/sso' || u.pathname.startsWith('/autenticacao/Error/')) {
    res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' });
    return res.end(fs.readFileSync(path.join(__dirname, 'login.html')));
  }
  if (u.pathname === '/sisparnet') {
    res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' });
    return res.end(fs.readFileSync(path.join(__dirname, 'sisparnet.html')));
  }
  if (u.pathname === '/net') {
    res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' });
    return res.end(fs.readFileSync(path.join(__dirname, 'net.html')));
  }
  if (u.pathname === '/regularize') {
    res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' });
    return res.end(fs.readFileSync(path.join(__dirname, 'regularize.html')));
  }
  res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' });
  res.end(fs.readFileSync(path.join(__dirname, 'index.html')));
};
http.createServer(atender).listen(8765, () => console.log('mock em 8765'));
http.createServer(atender).listen(8766, () => console.log('quadro em 8766 (outra origem)'));
