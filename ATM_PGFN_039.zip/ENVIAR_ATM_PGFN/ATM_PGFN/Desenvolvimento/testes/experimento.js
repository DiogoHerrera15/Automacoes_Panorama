const { spawn, spawnSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const T = __dirname;
const O = path.join(T, 'outra_pasta');
const espera = (ms) => new Promise((r) => setTimeout(r, ms));
(async () => {
  for (const m of ['uia', 'settext', 'settext+change']) {
    const sa = path.join(T, `exp_${m.replace('+', '_')}.txt`);
    try { fs.unlinkSync(sa); } catch (_) {}
    const p = spawn('powershell.exe', ['-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-File', path.join(T, 'abrir_dialogo.ps1'), '-Dir', O, '-Nome', '111222333', '-Saida', sa]);
    await espera(3000);
    const alvo = path.join(O, `certo_${m.replace('+', '_')}.pdf`);
    const r = spawnSync('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', path.join(T, 'experimento_nome.ps1'), '-Metodo', m, '-Texto', alvo], { encoding: 'utf8' });
    await espera(2000);
    console.log(m, '=>', (r.stdout || '').trim(), '|', (r.stderr || '').split('\n')[0], '|', fs.existsSync(sa) ? fs.readFileSync(sa, 'utf8') : '(sem resultado)');
    p.kill();
  }
})();
