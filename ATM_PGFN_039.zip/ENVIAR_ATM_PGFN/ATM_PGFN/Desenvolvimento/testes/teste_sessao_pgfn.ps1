﻿param([string]$Orig = 'C:\Users\PANORAMA-PC\Downloads\Auto_PGFN', [string]$PastaOrq = 'orquestrador', [string]$PastaAj = 'ajudante_salvar_como')
# 0.36.0 — "Você não tem permissão de acesso ou ele expirou" no SISPAR ("[sessao_pgfn]"): o orquestrador refaz o MESMO CNPJ
# com o Chrome reaberto (não avança na hora, não refaz a lista); até 3 recuperações; persistindo, fica pendente (erro) e a
# fila segue, sem pausa. Orquestrador e ajudante REAIS em pasta temporária; "Chrome" simulado.
$ErrorActionPreference = 'Stop'
$SCR = Split-Path -Parent $MyInvocation.MyCommand.Path
$falhas = 0
function Ok($nome, $cond, $extra) { if ($cond) { "OK    $nome" } else { $script:falhas++; "FALHA $nome  $extra" } }
$T = Join-Path $env:TEMP ('pgfn_sessao_' + (Get-Random))
New-Item -ItemType Directory "$T\$PastaOrq" | Out-Null
if ($PastaAj -ne $PastaOrq) { New-Item -ItemType Directory "$T\$PastaAj" | Out-Null }
Copy-Item "$Orig\$PastaOrq\orquestrador.ps1" "$T\$PastaOrq\"
Copy-Item "$Orig\$PastaAj\salvar_como.ps1", "$Orig\$PastaAj\salvar_como.bat" "$T\$PastaAj\"
'{"nome":"Lista SP","certificados":[{"certificado":"EMPRESA TESTE:1","exato":true,"pasta":"EMPRESA_TESTE_1","cnpjs":["11.444.777/0001-61","90.000.026/0001-22","90.000.006/0001-51"]}]}' | Set-Content "$T\c.json" -Encoding UTF8
function Rodar([string]$sessao) {
  $env:PGFN_SIM = 'conclui'; $env:PGFN_SIM_CONTADOR = "$T\aberturas.txt"; $env:PGFN_SIM_SESSAO = $sessao
  Remove-Item "$T\aberturas.txt*", "$T\$PastaOrq\orquestrador.log", "$T\a.json" -ErrorAction SilentlyContinue
  $p = Start-Process powershell -PassThru -WindowStyle Hidden -ArgumentList '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "$T\$PastaOrq\orquestrador.ps1",
    '-Config', "$T\c.json", '-Andamento', "$T\a.json", '-ChromeSimulado', "$SCR\chrome_simulado.ps1", '-MinutosTravamento', '1'
  [void]$p.WaitForExit(600000)
  Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" | Where-Object { $_.CommandLine -like '*chrome_simulado*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
  $env:PGFN_SIM_SESSAO = ''
}
"=== A) o 2º CNPJ perde o acesso ao SISPAR 1 vez e se recupera ==="
Rodar '90000026000122:1'
$a = Get-Content "$T\a.json" -Raw -Encoding UTF8 | ConvertFrom-Json
$log = Get-Content "$T\$PastaOrq\orquestrador.log" -Raw -Encoding UTF8
Ok 'refez o MESMO CNPJ e concluiu' ($a.'90000026000122'.situacao -eq 'concluido') $a.'90000026000122'.situacao
Ok '2 aberturas desse CNPJ (erro + recuperação), 4 no total' ((Get-Content "$T\aberturas.txt.90000026000122") -eq '2' -and (Get-Content "$T\aberturas.txt") -eq '4') "$(Get-Content "$T\aberturas.txt.90000026000122") / $(Get-Content "$T\aberturas.txt")"
Ok 'log: erro reconhecido e recuperação no mesmo CNPJ' ($log.Contains('erro - acesso ao SISPAR expirado') -and $log.Contains('recuperação automática: refazendo o MESMO CNPJ com o Chrome reaberto (1 de 3)'))
Ok 'log: certificado, CNPJ e conta registrados' ($log.Contains('[sessao_pgfn]') -and $log.Contains('CNPJ 90000026000122, conta 5465828'))
Ok 'não avançou antes de recuperar: a ordem foi 1º, 2º (2x), 3º' ($log.IndexOf('===== CNPJ 90000006000151') -gt $log.LastIndexOf('===== CNPJ 90000026000122'))
Ok 'os outros concluídos; lista não refeita' ($a.'11444777000161'.situacao -eq 'concluido' -and $a.'90000006000151'.situacao -eq 'concluido' -and ([regex]::Matches($log, '===== CNPJ 11444777000161')).Count -eq 1)
Ok 'contador: 3 de 3, 3 concluídos, 0 com erro (recuperação não conta como erro)' ($log.Contains('PROGRESSO: 3 de 3 analisados (100%) | concluídos 3 | com erro 0'))
"=== B) o 2º CNPJ perde o acesso sempre: 3 recuperações e segue (sem pausa) ==="
Rodar '90000026000122:99'
$a = Get-Content "$T\a.json" -Raw -Encoding UTF8 | ConvertFrom-Json
$log = Get-Content "$T\$PastaOrq\orquestrador.log" -Raw -Encoding UTF8
Ok '4 aberturas desse CNPJ (1 + 3 recuperações), nunca infinito' ((Get-Content "$T\aberturas.txt.90000026000122") -eq '4') (Get-Content "$T\aberturas.txt.90000026000122")
Ok 'fica pendente (erro), não concluído' ($a.'90000026000122'.situacao -eq 'erro' -and ([string]$a.'90000026000122'.mensagem).Contains('[sessao_pgfn] sem recuperação depois de 3 tentativas')) "$($a.'90000026000122'.situacao) | $($a.'90000026000122'.mensagem)"
Ok 'sem pausa (não criou pausar.flag) e o próximo foi processado' (-not ($log -match 'PAUSA') -and $a.'90000006000151'.situacao -eq 'concluido')
Ok 'log: segue para o próximo' ($log.Contains('fica pendente (com erro) e a fila segue para o próximo CNPJ'))
Ok 'contador: 3 de 3, 2 concluídos, 1 com erro' ($log.Contains('PROGRESSO: 3 de 3 analisados (100%) | concluídos 2 | com erro 1'))
Remove-Item $T -Recurse -Force
""; if ($falhas) { "$falhas FALHA(S)" } else { 'TUDO OK' }
