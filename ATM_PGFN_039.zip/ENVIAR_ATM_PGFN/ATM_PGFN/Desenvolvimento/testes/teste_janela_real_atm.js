// Ajudante de verdade (salvar_como.ps1) contra janelas "Salvar como" de verdade do Windows, abertas por um processo
// powershell no lugar do Chrome (PGFN_AJUDANTE_PROCESSO=powershell). Protocolo do Chrome: 4 bytes + JSON.
const { spawn, spawnSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const assert = require('assert');
const AQUI = __dirname;
const AJUDANTE = String.raw`C:\Users\PANORA~1\AppData\Local\Temp\portabilidade_1747241556\ATM_PGFN\Ajudante_Windows\salvar_como.ps1`;
const CNPJ = '00000000000191'; // pasta de teste (apagada no fim)
const PASTA = `ATM_PGFN/Documentos_arrecadacao/CERT_PORTAB/${CNPJ}`;
const DESTINO = path.join(process.env.USERPROFILE, 'Downloads', 'ATM_PGFN', 'Documentos_arrecadacao', 'CERT_PORTAB', CNPJ);
const OUTRA = path.join(AQUI, `outra_pasta_${Date.now()}`);
const NOME = `${CNPJ};EMPRESA TESTE LTDA;11-2026`;
const NUMERO = '7172631318468216';
const espera = (ms) => new Promise((r) => setTimeout(r, ms));

function ajudante(pedido) {
  return new Promise((ok, falha) => {
    const p = spawn('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', AJUDANTE],
      { env: { ...process.env, PGFN_AJUDANTE_PROCESSO: 'powershell' } });
    const partes = [];
    p.stdout.on('data', (d) => partes.push(d));
    p.on('close', () => {
      const b = Buffer.concat(partes);
      if (b.length < 4) return falha(new Error('sem resposta: ' + b.toString()));
      ok(JSON.parse(b.slice(4, 4 + b.readInt32LE(0)).toString('utf8')));
    });
    const j = Buffer.from(JSON.stringify(pedido), 'utf8');
    const cab = Buffer.alloc(4); cab.writeInt32LE(j.length);
    p.stdin.end(Buffer.concat([cab, j]));
  });
}
let n = 0;
function abrirJanela(dir, nome, atraso = 0) {
  const saida = path.join(AQUI, `saida_${++n}.txt`);
  try { fs.unlinkSync(saida); } catch (_) {}
  const p = spawn('powershell.exe', ['-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-File', path.join(AQUI, 'abrir_dialogo.ps1'),
    '-Dir', dir, '-Nome', nome, '-Saida', saida, '-Atraso', String(atraso)], { detached: false });
  return { p, resultado: async (ms = 8000) => { const fim = Date.now() + ms; while (Date.now() < fim) { if (fs.existsSync(saida)) return fs.readFileSync(saida, 'utf8'); await espera(200); } return null; } };
}
const conferir = (c) => ajudante({ acao: 'conferir', caminho: c });

(async () => {
  fs.rmSync(DESTINO, { recursive: true, force: true });
  fs.mkdirSync(DESTINO, { recursive: true });
  fs.mkdirSync(OUTRA, { recursive: true });
  const t0 = Date.now();

  // A) normal: pasta do CNPJ e nome certos -> "Salvar"
  let j = abrirJanela(DESTINO, NOME);
  await espera(2500);
  let r = await ajudante({ acao: 'confirmar', pasta: PASTA, nome: `${NOME}.pdf`, numero: NUMERO, timeoutMs: 20000 });
  assert.ok(r.ok && !r.corrigido, 'A: ' + JSON.stringify(r));
  let s = await j.resultado();
  assert.strictEqual(s, `SALVO|${path.join(DESTINO, NOME + '.pdf')}`, 'A: ' + s);
  let c = await conferir(path.join(DESTINO, NOME + '.pdf'));
  assert.ok(c.existe && c.pdf && c.bytes > 0);
  console.log('A ok: salvamento normal');

  // B) caso de 09/11: janela com o nome do site (nÃºmero do documento) e outra pasta -> escreve o caminho certo
  j = abrirJanela(OUTRA, NUMERO);
  await espera(2500);
  r = await ajudante({ acao: 'confirmar', pasta: PASTA, nome: `${NOME};conta 1029524;prest 0117.pdf`, numero: NUMERO, timeoutMs: 20000 });
  assert.ok(r.ok && r.corrigido, 'B: ' + JSON.stringify(r));
  s = await j.resultado();
  assert.strictEqual(s, `SALVO|${path.join(DESTINO, NOME + ';conta 1029524;prest 0117.pdf')}`, 'B: ' + s);
  assert.ok(!fs.existsSync(path.join(OUTRA, NUMERO + '.pdf')), 'B: nada salvo na outra pasta');
  console.log('B ok: nome do site + pasta errada corrigidos na janela');

  // C) arquivo jÃ¡ existente: nÃ£o sobrescreve, salva "(1)"
  const antes = fs.readFileSync(path.join(DESTINO, NOME + '.pdf'));
  fs.writeFileSync(path.join(DESTINO, NOME + '.pdf'), '%PDF-1.4\n% ORIGINAL\n');
  j = abrirJanela(DESTINO, NOME);
  await espera(2500);
  r = await ajudante({ acao: 'confirmar', pasta: PASTA, nome: `${NOME}.pdf`, numero: NUMERO, timeoutMs: 20000 });
  assert.ok(r.ok && /\(1\)\.pdf$/.test(r.corrigido || ''), 'C: ' + JSON.stringify(r));
  s = await j.resultado();
  assert.strictEqual(s, `SALVO|${path.join(DESTINO, NOME + ' (1).pdf')}`, 'C: ' + s);
  assert.ok(fs.readFileSync(path.join(DESTINO, NOME + '.pdf'), 'utf8').includes('ORIGINAL'), 'C: o original continua intacto');
  console.log('C ok: arquivo existente preservado, salvo como "(1)"');

  // D) demora na abertura da janela (6 s depois do pedido)
  j = abrirJanela(DESTINO, NUMERO, 6000);
  r = await ajudante({ acao: 'confirmar', pasta: PASTA, nome: `${NOME};conta 9;prest 0001.pdf`, numero: NUMERO, timeoutMs: 30000 });
  assert.ok(r.ok, 'D: ' + JSON.stringify(r));
  s = await j.resultado();
  assert.strictEqual(s, `SALVO|${path.join(DESTINO, NOME + ';conta 9;prest 0001.pdf')}`, 'D: ' + s);
  console.log('D ok: janela que demorou a abrir');

  // E) janela de OUTRO arquivo: o ajudante nÃ£o toca
  j = abrirJanela(OUTRA, 'relatorio qualquer');
  await espera(2500);
  r = await ajudante({ acao: 'confirmar', pasta: PASTA, nome: `${NOME};x.pdf`, numero: NUMERO, timeoutMs: 4000 });
  assert.ok(!r.ok && /outro arquivo/.test(r.erro), 'E: ' + JSON.stringify(r));
  r = await ajudante({ acao: 'cancelar', pasta: PASTA, nome: `${NOME};x.pdf`, numero: NUMERO, timeoutMs: 3000 });
  assert.ok(r.ok && r.fechou === false, 'E: cancelar nÃ£o fecha janela de outro arquivo ' + JSON.stringify(r));
  assert.strictEqual(await j.resultado(500), null, 'E: a janela de outro arquivo continua aberta');
  j.p.kill();
  console.log('E ok: janela de outro arquivo intocada');

  // F) fechar de forma controlada ("Cancelar") a janela deste documento
  j = abrirJanela(OUTRA, NUMERO);
  await espera(2500);
  r = await ajudante({ acao: 'janelas' });
  assert.ok(r.ok && r.abertas >= 1 && JSON.stringify(r.janelas).includes(NUMERO), 'F: detecta a janela aberta ' + JSON.stringify(r));
  r = await ajudante({ acao: 'cancelar', pasta: PASTA, nome: `${NOME};y.pdf`, numero: NUMERO, timeoutMs: 8000 });
  assert.ok(r.ok && r.fechou, 'F: ' + JSON.stringify(r));
  assert.strictEqual(await j.resultado(), 'CANCELADO');
  r = await ajudante({ acao: 'janelas' });
  assert.strictEqual(r.abertas, 0, 'F: nenhuma janela sobrou');
  console.log('F ok: janela fechada de forma controlada');

  fs.rmSync(DESTINO, { recursive: true, force: true });
  console.log(`janela real: todos os testes passaram (${Math.round((Date.now() - t0) / 1000)} s)`);
})().catch((e) => { console.error(e); process.exit(1); });
