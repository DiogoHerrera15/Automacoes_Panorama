param([string]$Metodo, [string]$Texto)
# Experimento: qual forma de escrever no campo "Nome" a janela "Salvar como" respeita ao clicar em "Salvar"?
Add-Type -AssemblyName UIAutomationClient, UIAutomationTypes
$AE = [System.Windows.Automation.AutomationElement]
$TS = [System.Windows.Automation.TreeScope]
$PC = [System.Windows.Automation.PropertyCondition]
Add-Type -Namespace Exp -Name Win -MemberDefinition @"
[DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern IntPtr SendMessage(IntPtr h, int msg, IntPtr w, string l);
[DllImport("user32.dll")] public static extern IntPtr SendMessage(IntPtr h, int msg, IntPtr w, IntPtr l);
[DllImport("user32.dll")] public static extern IntPtr GetParent(IntPtr h);
[DllImport("user32.dll")] public static extern int GetDlgCtrlID(IntPtr h);
"@
$ids = @(Get-Process -Name powershell | ForEach-Object { $_.Id })
$j = $null
foreach ($w in $AE::RootElement.FindAll($TS::Children, [System.Windows.Automation.Condition]::TrueCondition)) {
  if ($ids -contains $w.Current.ProcessId -and $w.Current.ClassName -eq '#32770' -and $w.Current.Name -eq 'Salvar como') { $j = $w }
}
if (-not $j) { 'sem janela'; exit 1 }
$campo = @($j.FindAll($TS::Descendants, (New-Object $PC($AE::ClassNameProperty, 'Edit'))) | Where-Object { $_.Current.AutomationId -eq '1001' })[0]
$h = [IntPtr]$campo.Current.NativeWindowHandle
switch ($Metodo) {
  'uia' { $campo.GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern).SetValue($Texto) }
  'settext' { [void][Exp.Win]::SendMessage($h, 0x000C, [IntPtr]::Zero, $Texto) }
  'settext+change' {
    [void][Exp.Win]::SendMessage($h, 0x000C, [IntPtr]::Zero, $Texto)
    $pai = [Exp.Win]::GetParent($h); $id = [Exp.Win]::GetDlgCtrlID($h)
    [void][Exp.Win]::SendMessage($pai, 0x0111, [IntPtr](($id -band 0xFFFF) -bor (0x0300 -shl 16)), $h) # WM_COMMAND EN_CHANGE
  }
}
Start-Sleep -Milliseconds 300
$salvar = @($j.FindAll($TS::Descendants, (New-Object $PC($AE::ClassNameProperty, 'Button'))) | Where-Object { $_.Current.AutomationId -eq '1' })[0]
[void][Exp.Win]::SendMessage([IntPtr]$salvar.Current.NativeWindowHandle, 0x00F5, [IntPtr]::Zero, [IntPtr]::Zero) # BM_CLICK
"clicou"
