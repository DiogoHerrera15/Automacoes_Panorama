// Ajudante 1.9 contra a janela "Selecione um certificado" DE VERDADE do Chrome (perfil temporário, só para o teste).
// Modo teste: seleciona e confere como no real, mas clica em "Cancelar" (não faz login). Não imprime nomes de certificados.
// Uso: node teste_certificado_real.js [caminho do salvar_como.ps1]
const { spawn, spawnSync } = require('child_process');
const fs = require('fs'), path = require('path'), os = require('os'), assert = require('assert');
const AJUDANTE = process.argv[2] || path.join(process.env.USERPROFILE, 'Downloads', 'Auto_PGFN', 'ajudante_salvar_como', 'salvar_como.ps1');
const CHROME = ['C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', 'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
  path.join(process.env.LOCALAPPDATA || '', 'Google\\Chrome\\Application\\chrome.exe')].find((p) => fs.existsSync(p));
const PERFIL = path.join(os.tmpdir(), `pgfn_cert_teste_${Date.now()}`);
const espera = (ms) => new Promise((r) => setTimeout(r, ms));
function ajudante(pedido) {
  return new Promise((ok, falha) => {
    const p = spawn('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', AJUDANTE]);
    const partes = []; p.stdout.on('data', (d) => partes.push(d));
    p.on('close', () => { const b = Buffer.concat(partes); if (b.length < 4) return falha(new Error('sem resposta: ' + b)); ok(JSON.parse(b.slice(4, 4 + b.readInt32LE(0)).toString('utf8'))); });
    const j = Buffer.from(JSON.stringify(pedido), 'utf8'); const cab = Buffer.alloc(4); cab.writeInt32LE(j.length); p.stdin.end(Buffer.concat([cab, j]));
  });
}
function fecharChromeDeTeste() {
  spawnSync('powershell.exe', ['-NoProfile', '-Command',
    `Get-CimInstance Win32_Process -Filter "Name='chrome.exe'" | Where-Object { $_.CommandLine -like '*${path.basename(PERFIL)}*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }`]);
}
function abrirChrome() {
  return spawn(CHROME, [`--user-data-dir=${PERFIL}`, '--no-first-run', '--no-default-browser-check', '--new-window', 'https://certificado.sso.acesso.gov.br/'], { detached: true, stdio: 'ignore' });
}
(async () => {
  assert.ok(CHROME, 'Chrome não encontrado');
  const t0 = Date.now();
  abrirChrome();
  // A) nome inexistente: percorre a lista INTEIRA e não escolhe nada
  let r = await ajudante({ acao: 'certificado', nome: 'CERTIFICADO QUE NAO EXISTE PGFN TESTE:00000000000191', exato: true, teste: true, timeoutMs: 40000 });
  assert.ok(!r.ok && /achei 0 certificado/.test(r.erro) && /percorrida até o fim/.test(r.erro), 'A: ' + r.erro);
  const lista = r.disponiveis || [];
  console.log(`A ok: lista percorrida até o fim, ${lista.length} certificado(s); nenhum escolhido (${r.erro.replace(/entre os \d+/, 'entre os N')})`);
  assert.ok(lista.length > 3, `A: a lista precisa ter mais de 3 certificados (rolagem) para o teste B; tem ${lista.length}`);
  assert.strictEqual(new Set(lista).size, lista.length, 'A: nenhuma linha lida duas vezes');
  // B) o ÚLTIMO certificado da lista (só aparece depois de rolar): achado, selecionado e conferido; botão final = Cancelar
  const alvo = lista[lista.length - 1];
  const repetidos = lista.filter((x) => x === alvo).length;
  assert.strictEqual(repetidos, 1);
  r = await ajudante({ acao: 'certificado', nome: alvo, exato: true, teste: true, timeoutMs: 40000 });
  assert.ok(r.ok && r.certificado === alvo && r.botao === 'Cancelar', 'B: ' + JSON.stringify({ ok: r.ok, erro: r.erro, botao: r.botao, igual: r.certificado === alvo }));
  console.log(`B ok: o ${lista.length}º (último) certificado, abaixo da parte visível, foi selecionado, conferido e a janela fechada pelo botão de teste`);
  // C) um do MEIO da lista, com a janela aberta de novo
  fecharChromeDeTeste(); await espera(1500); abrirChrome();
  const meio = lista[Math.floor(lista.length / 2)];
  r = await ajudante({ acao: 'certificado', nome: meio, exato: true, teste: true, timeoutMs: 40000 });
  assert.ok(r.ok && r.certificado === meio, 'C: ' + JSON.stringify({ ok: r.ok, erro: r.erro }));
  console.log(`C ok: o ${Math.floor(lista.length / 2) + 1}º certificado (meio da lista) selecionado e conferido`);
  fecharChromeDeTeste();
  await espera(1000);
  try { fs.rmSync(PERFIL, { recursive: true, force: true }); } catch (_) {}
  console.log(`certificado real (ajudante 1.9): todos os testes passaram (${Math.round((Date.now() - t0) / 1000)} s)`);
})().catch((e) => { console.error('FALHA:', e.message); fecharChromeDeTeste(); process.exit(1); });
