// Ajudante 1.8: "procurar-documento" acha o PDF da prestação na pasta do CNPJ pelo nome pedido ou pelo número do
// documento, só depois de "desde", e nunca toma o print, outro documento ou um arquivo que não é PDF.
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const assert = require('assert');
const AJ = process.argv[2] || path.join(process.env.USERPROFILE, 'Downloads', 'Auto_PGFN', 'ajudante_salvar_como', 'salvar_como.ps1');
const RAIZ = process.argv[3] || 'Auto_PGFN'; // ATM: 'ATM_PGFN'
const DOCS = path.join(process.env.USERPROFILE, 'Downloads', RAIZ, 'Documentos_arrecadacao');
const CERT = 'ZZTESTE_PROCURAR_' + Date.now();
const CNPJ = '90000002000173';
const DIR = path.join(DOCS, CERT, CNPJ);
const PASTA = `${RAIZ}/Documentos_arrecadacao/${CERT}/${CNPJ}`;
const NOME = `${CNPJ};EMPRESA CLIENTE 1 LTDA;11-2026;conta 14652591;prest 0011`;
const pedir = (pedido) => new Promise((ok) => {
  const p = spawn('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', AJ]);
  const partes = []; p.stdout.on('data', (d) => partes.push(d));
  p.on('close', () => { const b = Buffer.concat(partes); ok(JSON.parse(b.slice(4, 4 + b.readInt32LE(0)).toString('utf8'))); });
  const j = Buffer.from(JSON.stringify(pedido), 'utf8'); const c = Buffer.alloc(4); c.writeInt32LE(j.length); p.stdin.end(Buffer.concat([c, j]));
});
const PDF = Buffer.from('%PDF-1.4\n%teste\n%%EOF\n');
const escrever = (nome, conteudo, quando) => { const f = path.join(DIR, nome); fs.writeFileSync(f, conteudo); if (quando) fs.utimesSync(f, quando, quando); return f; };
(async () => {
  fs.mkdirSync(DIR, { recursive: true });
  try {
    assert.strictEqual((await pedir({ acao: 'versao' })).versao, '1.9');
    const desde = Date.now() - 60000;
    const pedido = { acao: 'procurar-documento', pasta: PASTA, nome: `${NOME}.pdf`, numero: '7172631466259011', desde };
    // só o print da conta anterior e o documento de OUTRA conta: nada
    escrever('print_confirmacao_conta_5535214.pdf', PDF);
    escrever(`${CNPJ};EMPRESA CLIENTE 1 LTDA;11-2026.pdf`, PDF);
    let r = await pedir(pedido);
    assert.ok(r.ok && !r.achou, 'print e documento de outra conta não valem: ' + JSON.stringify(r));
    console.log('ok: print de confirmação e documento de outra conta nunca são tomados');
    // arquivo com o número mas que não é PDF: não vale
    escrever('7172631466259011.pdf', Buffer.from('<html>erro</html>'));
    r = await pedir(pedido);
    assert.ok(r.ok && !r.achou && r.invalidos === 1, 'arquivo com o número mas sem %PDF: ' + JSON.stringify(r));
    console.log('ok: arquivo com o nome certo mas que não é PDF é recusado');
    // o número do documento (nome dado pelo site, como o salvo à mão em 10/11): acha
    escrever('7172631466259011.pdf', PDF);
    r = await pedir(pedido);
    assert.ok(r.ok && r.achou && r.caminho.endsWith('7172631466259011.pdf') && r.pdf, JSON.stringify(r));
    console.log('ok: PDF salvo com o número do documento é encontrado');
    // salvo ANTES do início desta prestação (outra execução): não vale
    fs.unlinkSync(path.join(DIR, '7172631466259011.pdf'));
    escrever(`${NOME}.pdf`, PDF, new Date(desde - 3600000));
    r = await pedir(pedido);
    assert.ok(r.ok && !r.achou, 'arquivo antigo (antes de "desde") não vale: ' + JSON.stringify(r));
    // nome pedido com "(1)", gravado agora: acha
    escrever(`${NOME} (1).pdf`, PDF);
    r = await pedir(pedido);
    assert.ok(r.ok && r.achou && r.caminho.endsWith(`${NOME} (1).pdf`), JSON.stringify(r));
    console.log('ok: nome pedido (com "(1)") gravado depois do início é encontrado; o antigo não');
    r = await pedir({ ...pedido, pasta: `${RAIZ}/Outra/90000002000173` });
    assert.ok(!r.ok, 'pasta fora de Documentos_arrecadacao recusada');
    console.log('ok: pasta fora de Documentos_arrecadacao recusada');
    console.log('ajudante 1.8 (procurar-documento): todos os testes passaram');
  } finally {
    fs.rmSync(path.join(DOCS, CERT), { recursive: true, force: true });
  }
})().catch((e) => { console.error(e); process.exit(1); });
