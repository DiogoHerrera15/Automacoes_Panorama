// Executa o background.js de verdade com uma imitação da API do Chrome.
const fs = require('fs');
const path = require('path');
const assert = require('assert');
const vm = require('vm');
const arq = path.join(process.env.USERPROFILE, 'Downloads', 'Auto_PGFN', 'Automação_PGFN', 'background.js');
const sess = {};
const ouv = {};
const criadas = [];
const chrome = {
  offscreen: { hasDocument: async () => true, createDocument: async () => {} },
  contentSettings: { automaticDownloads: { set: async (o) => { (globalThis.__cs = globalThis.__cs || []).push(o); } } },
  action: { onClicked: { addListener: () => {} } },
  downloads: { onDeterminingFilename: { addListener: () => {} }, onChanged: { addListener: () => {} } },
  runtime: { onInstalled: { addListener: () => {} }, onStartup: { addListener: () => {} }, onMessage: { addListener: (f) => { ouv.msg = f; } } },
  tabs: { query: async () => [],
    onCreated: { addListener: (f) => { ouv.criada = f; } },
    onRemoved: { addListener: () => {} },
    onUpdated: { addListener: () => {} },
    create: async (o) => { criadas.push(o); return {}; },
    sendMessage: async (id, d) => { if (d.alvo === 'falha') throw new Error('sem receptor'); return { id, alvo: d.alvo }; },
  },
  storage: { session: {
    get: async (k) => (k in sess ? { [k]: sess[k] } : {}),
    set: async (o) => { Object.assign(sess, o); },
    remove: async (k) => { delete sess[k]; },
  } },
};
vm.runInNewContext(fs.readFileSync(arq, 'utf8'), { chrome, console, URL, Date, Promise });
const enviar = (msg, aba, url) => new Promise((r) => {
  const assincrono = ouv.msg(msg, { tab: { id: aba, windowId: 9 }, url }, r);
  if (!assincrono) setImmediate(() => r(undefined));
});
const norm = (o) => JSON.parse(JSON.stringify(o));
const ECAC = 'https://cav.receita.fazenda.gov.br/ecac/';
const REG = 'https://www.regularize.pgfn.gov.br/home';

(async () => {
  assert.strictEqual(await enviar({ tipo: 'estado-ler' }, 2, REG), null, 'sem transferência o Regularize não assume nada');
  await enviar({ tipo: 'transferencia-iniciar', cnpj: '90000003000118', confirmado: 'Procurador de: X' }, 1, ECAC);
  assert.strictEqual(await enviar({ tipo: 'estado-ler' }, 3, ECAC), null, 'outra aba do e-CAC não assume');
  await ouv.criada();
  let s = await enviar({ tipo: 'transferencia-status' }, 1, ECAC);
  assert.ok(s.abriu && !s.concluida, 'aba nova marca abriu');
  const e = norm(await enviar({ tipo: 'estado-ler' }, 2, REG));
  assert.strictEqual(e.cnpj, '90000003000118'); assert.strictEqual(e.etapa, 0); assert.strictEqual(e.confirmado, 'Procurador de: X');
  s = await enviar({ tipo: 'transferencia-status' }, 1, ECAC);
  assert.ok(s.concluida, 'origem vê concluída');
  assert.strictEqual(await enviar({ tipo: 'estado-ler' }, 5, REG), null, 'só uma aba assume');
  await enviar({ tipo: 'estado-gravar', estado: { encerrado: true, t: 1 } }, 2, REG);
  assert.ok((await enviar({ tipo: 'estado-ler' }, 2, REG)).encerrado, 'recarregar não reassume');
  assert.strictEqual(await enviar({ tipo: 'abrir-url', url: 'https://malicioso.example/x' }, 1, ECAC), false, 'domínio de fora é recusado');
  assert.strictEqual(await enviar({ tipo: 'abrir-url', url: 'http://regularize.pgfn.gov.br/' }, 1, ECAC), false, 'http é recusado');
  assert.strictEqual(await enviar({ tipo: 'abrir-url', url: 'https://cav.receita.fazenda.gov.br/ecac/Aplicacao.aspx?id=1' }, 1, ECAC), true);
  assert.strictEqual(await enviar({ tipo: 'abrir-url', url: 'https://sisparnet.pgfn.fazenda.gov.br/x' }, 1, ECAC), true, 'outro ambiente do SISPAR é aceito');
  assert.strictEqual(await enviar({ tipo: 'abrir-url', url: 'https://pgfn.fazenda.gov.br.malicioso.example/x' }, 1, ECAC), false, 'domínio parecido é recusado');
  criadas.splice(1);
  assert.strictEqual(criadas.length, 1); assert.strictEqual(criadas[0].windowId, 9); assert.strictEqual(criadas[0].openerTabId, 1);
  // transferência para a aba própria do SISPAR (vinda do "CONTINUAR")
  const SISPAR = 'https://sisparnet.pgfn.fazenda.gov.br/sisparInternet/autenticacao.jsf?token=x';
  await enviar({ tipo: 'transferencia-iniciar', destino: 'sisparnet', cnpj: '90000003000118', confirmado: 'P', empresa: 'SOLSERV' }, 2, REG);
  assert.strictEqual(await enviar({ tipo: 'estado-ler' }, 8, REG), null, 'o Regularize não assume a transferência do SISPAR');
  const es = norm(await enviar({ tipo: 'estado-ler' }, 9, SISPAR));
  assert.strictEqual(es.cnpj, '90000003000118'); assert.strictEqual(es.empresa, 'SOLSERV'); assert.strictEqual(es.etapa, 0);
  assert.ok((await enviar({ tipo: 'transferencia-status' }, 2, REG)).concluida, 'origem vê concluída');
  assert.strictEqual(norm(await enviar({ tipo: 'ao-quadro', dados: { alvo: 'consultar' } }, 7, REG)).alvo, 'consultar', 'repassa aos quadros da aba');
  assert.strictEqual(await enviar({ tipo: 'ao-quadro', dados: { alvo: 'falha' } }, 7, REG), null, 'sem quadro que responda devolve null');
  console.log('background: todos os testes passaram');
})().catch((e) => { console.error(e); process.exit(1); });
