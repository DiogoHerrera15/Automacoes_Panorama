// background.js de verdade: registro-ver usa o do Chrome e, se faltar, o do disco (ajudante); registro-gravar grava nos
// dois; orq-progresso vai para o ajudante.
const fs = require('fs');
const path = require('path');
const assert = require('assert');
const vm = require('vm');
const arq = path.join(process.env.USERPROFILE, 'Downloads', 'Auto_PGFN', 'Automação_PGFN', 'background.js');
const local = {}; const sess = {}; const ouv = {}; const nativas = [];
const disco = { 'K-DISCO': { arquivo: 'C:\\x\\Auto_PGFN\\doc_disco.pdf' } };
const nada = { addListener: () => {} };
const chrome = {
  offscreen: { hasDocument: async () => true, createDocument: async () => {} },
  contentSettings: { automaticDownloads: { set: async () => {} } }, action: { onClicked: nada },
  runtime: { id: 'EXT', onInstalled: nada, onStartup: nada, onMessage: { addListener: (f) => { ouv.msg = f; } },
    sendNativeMessage: async (h, p) => { nativas.push(p);
      if (p.acao === 'registro-ver') return { ok: true, registro: disco[p.chave] || null };
      if (p.acao === 'registro-gravar') { disco[p.chave] = { arquivo: p.arquivo }; return { ok: true }; }
      return { ok: true }; } },
  downloads: { onDeterminingFilename: nada, onChanged: nada, search: async () => [] },
  tabs: { query: async () => [], onCreated: nada, onRemoved: nada, onUpdated: nada },
  storage: { session: { get: async (k) => (k in sess ? { [k]: sess[k] } : {}), set: async (o) => Object.assign(sess, o), remove: async (k) => { delete sess[k]; } },
    local: { get: async (k) => (k in local ? { [k]: local[k] } : {}), set: async (o) => Object.assign(local, JSON.parse(JSON.stringify(o))) } },
};
vm.runInNewContext(fs.readFileSync(arq, 'utf8'), { chrome, console: { log() {}, warn() {} }, URL, Date, Promise, setTimeout, clearTimeout });
const enviar = (msg) => new Promise((r) => { if (!ouv.msg(msg, { tab: { id: 3, windowId: 1 }, url: 'https://x' }, r)) setImmediate(() => r(undefined)); });
(async () => {
  assert.strictEqual(await enviar({ tipo: 'registro-ver', chave: 'NADA' }), null, 'nem no Chrome nem no disco: null');
  const d = await enviar({ tipo: 'registro-ver', chave: 'K-DISCO' });
  assert.ok(d && d.arquivo.endsWith('doc_disco.pdf'), 'Chrome sem registro (perfil limpo): vale o do disco');
  assert.strictEqual(await enviar({ tipo: 'registro-gravar', chave: 'K-NOVA', arquivo: 'C:\\x\\a.pdf' }), true);
  assert.ok(local.registro_downloads['K-NOVA'] && disco['K-NOVA'], 'gravado no Chrome e no disco');
  const n0 = nativas.length;
  const l = await enviar({ tipo: 'registro-ver', chave: 'K-NOVA' });
  assert.ok(l && l.arquivo === 'C:\\x\\a.pdf' && nativas.length === n0, 'achado no Chrome: nem consulta o disco');
  await enviar({ tipo: 'orq-progresso', sessao: 's', cnpj: '1', texto: 't', checkpoint: { conta: '9' } });
  assert.ok(nativas.some((p) => p.acao === 'orq-progresso' && p.checkpoint.conta === '9'), 'orq-progresso vai ao ajudante');
  console.log('registro (background): todos os testes passaram');
})().catch((e) => { console.error(e); process.exit(1); });
