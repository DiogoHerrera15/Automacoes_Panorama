﻿param([string]$Cenario, [switch]$ControlarPausa)
# Teste do vigia de travamentos com o orquestrador e o ajudante REAIS, copiados para uma pasta temporária isolada.
$ErrorActionPreference = 'Stop'
$ORIG = 'C:\Users\PANORAMA-PC\Downloads\ATM_PGFN'
$T = Join-Path $env:TEMP ('pgfn_vigia_' + $Cenario + '_' + (Get-Random))
New-Item -ItemType Directory "$T\Automacao", "$T\Ajudante_Windows" | Out-Null
Copy-Item "$ORIG\Automacao\orquestrador.ps1" "$T\Automacao\"
Copy-Item "$ORIG\Ajudante_Windows\salvar_como.ps1", "$ORIG\Ajudante_Windows\salvar_como.bat" "$T\Ajudante_Windows\"
$cfg = "$T\c.json"
'{"nome":"T","certificados":[{"certificado":"EMPRESA TESTE:1","exato":true,"pasta":"EMPRESA_TESTE_1","cnpjs":["11.444.777/0001-61"]}]}' | Set-Content $cfg -Encoding UTF8
$env:PGFN_SIM = $Cenario
$env:PGFN_SIM_CONTADOR = "$T\aberturas.txt"
$env:PGFN_SIM_DIALOGO = 'C:\Users\PANORA~1\AppData\Local\Temp\claude\09de981ed91e3b47\727c250a-0de5-4b90-b949-7cf9fc86e5a8\scratchpad\testes\abrir_dialogo.ps1'
$env:PGFN_AJUDANTE_PROCESSO = 'powershell' # a janela "Salvar como" do teste é de um powershell, não do Chrome
$sim = 'C:\Users\PANORA~1\AppData\Local\Temp\claude\09de981ed91e3b47\727c250a-0de5-4b90-b949-7cf9fc86e5a8\scratchpad\testes\chrome_simulado.ps1'
$p = Start-Process powershell -PassThru -WindowStyle Hidden -ArgumentList '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "$T\Automacao\orquestrador.ps1",
  '-Config', $cfg, '-Andamento', "$T\a.json", '-ChromeSimulado', $sim, '-MinutosTravamento', '0.25', '-SegundosRecuperacao', '12', '-RecuperacoesMax', '2'
if ($ControlarPausa) {
  # espera a pausa do orquestrador; "Retomar" uma vez; na 2ª pausa, "Parar"
  $flag = "$T\Automacao\pausar.flag"
  $limite = (Get-Date).AddMinutes(6)
  while (-not (Test-Path $flag) -and (Get-Date) -lt $limite) { Start-Sleep 2 }
  "pausa 1: $(Get-Content $flag -Raw -Encoding UTF8)"
  Remove-Item $flag # Retomar
  while (-not (Test-Path $flag) -and (Get-Date) -lt $limite) { Start-Sleep 2 }
  "pausa 2 depois de retomar: $(Test-Path $flag)"
  New-Item -ItemType File "$T\Automacao\parar.flag" | Out-Null # Parar
}
$p.WaitForExit(600000) | Out-Null
Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" | Where-Object { $_.CommandLine -like '*pgfn_chrome_simulado*' -or $_.CommandLine -like '*abrir_dialogo*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
"--- aberturas do Chrome: $(Get-Content "$T\aberturas.txt")"
"--- log:"
Get-Content "$T\Automacao\orquestrador.log" -Encoding UTF8 | ForEach-Object { $_.Substring(11) } | Where-Object { $_ -notmatch '^\d\d:\d\d:\d\d   (11444777000161 |configura)' }
$a = Get-Content "$T\a.json" -Raw -Encoding UTF8 | ConvertFrom-Json
"--- andamento: $($a.'11444777000161'.situacao) | $($a.'11444777000161'.mensagem)"
"--- checkpoint: $($a.'11444777000161'.checkpoint | ConvertTo-Json -Compress)"
Remove-Item $T -Recurse -Force -ErrorAction SilentlyContinue
