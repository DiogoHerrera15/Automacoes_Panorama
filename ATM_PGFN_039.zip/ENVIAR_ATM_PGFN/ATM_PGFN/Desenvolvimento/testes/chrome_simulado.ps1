﻿param([string]$Pasta, [string]$Marca)
# Faz o papel do Chrome com a extensão (teste do vigia de travamentos). Cenário em $env:PGFN_SIM; conta as aberturas
# em $env:PGFN_SIM_CONTADOR. Escreve sinal.json/progresso.json como o ajudante escreveria.
$ErrorActionPreference = 'Stop'
$n = 1 + [int](Get-Content -LiteralPath $env:PGFN_SIM_CONTADOR -ErrorAction SilentlyContinue)
Set-Content -LiteralPath $env:PGFN_SIM_CONTADOR -Value $n
Start-Sleep -Seconds 2
$at = Get-Content -LiteralPath (Join-Path $Pasta 'atual.json') -Raw -Encoding UTF8 | ConvertFrom-Json
function Gravar($arq, $obj) { [IO.File]::WriteAllText((Join-Path $Pasta $arq), ($obj | ConvertTo-Json -Depth 5), (New-Object Text.UTF8Encoding $false)) }
function Sinal($sit, $msg) { Gravar 'sinal.json' @{ sessao = $at.sessao; cnpj = $at.cnpj; situacao = $sit; mensagem = $msg; t = (Get-Date).ToString('o') } }
function Progresso($txt, $parcela) { Gravar 'progresso.json' @{ sessao = $at.sessao; cnpj = $at.cnpj; texto = $txt; t = (Get-Date).ToString('o')
  checkpoint = @{ certificado = $at.certificado; cnpj = $at.cnpj; etapa = 'analisar as negociações'; conta = '1234567'; parcela = $parcela; salvos = 2 } } }
Sinal 'em_andamento' 'login: entrando com gov.br'
Progresso 'conta 1234567: conferindo a coluna Emissão' '0003'
# 0.34.0: PGFN_SIM_SEMPROC=<cnpj>: esse CNPJ responde "sem procuração" (como a extensão 0.34 avisa); os outros seguem o cenário
if ($env:PGFN_SIM_SEMPROC -and $at.cnpj -eq $env:PGFN_SIM_SEMPROC) {
  Start-Sleep 2
  Sinal 'erro' "etapa 6 (conferir o CNPJ no topo): [sem_procuracao] Não existe procuração eletrônica do certificado ""$($at.certificado)"" para o CNPJ $($at.cnpj).`nPrint salvo em PDF:`nC:\x\Sem_Procuracao_$($at.cnpj).pdf`nSessão do e-CAC: encerrada (""Sair com Segurança"")"
  while ($true) { Start-Sleep 5 }
}
# 0.37.0: PGFN_SIM_CANCELADA=<cnpj>: esse CNPJ responde "procuração cancelada" (como a extensão 0.37 avisa)
if ($env:PGFN_SIM_CANCELADA -and $at.cnpj -eq $env:PGFN_SIM_CANCELADA) {
  Start-Sleep 2
  Sinal 'erro' "etapa 6 (conferir o CNPJ no topo): [procuracao_cancelada] Pendente por procuração cancelada: Procuração eletrônica do certificado ""$($at.certificado)"" para o CNPJ $($at.cnpj) cancelada em 17/07/2025.`nPrint salvo em PDF:`nC:\x\$($at.cnpj)\Procuracao_Cancelada\Procuracao_Cancelada_$($at.cnpj).pdf`nSessão do e-CAC: encerrada (""Sair com Segurança"")"
  while ($true) { Start-Sleep 5 }
}
# 0.39.0: PGFN_SIM_CAIXA=<cnpj>: esse CNPJ responde "Aviso de Caixa Postal" (como a extensão 0.39 avisa)
if ($env:PGFN_SIM_CAIXA -and $at.cnpj -eq $env:PGFN_SIM_CAIXA) {
  Start-Sleep 2
  Sinal 'erro' "etapa 7 (abrir ""Dívida Ativa da União""): [caixa_postal] Aviso de Caixa Postal: Aviso de Caixa Postal no e-CAC para o CNPJ $($at.cnpj) (certificado ""$($at.certificado)""): mensagens importantes não lidas.`nPrint salvo em PDF:`nC:\x\$($at.cnpj)\Caixa_Postal_$($at.cnpj).pdf`nSessão do e-CAC: encerrada (""Sair com Segurança"")"
  while ($true) { Start-Sleep 5 }
}
# 0.35.0: PGFN_SIM_FALHA_SALV=<cnpj>: esse CNPJ termina com falha de salvamento (3 tentativas esgotadas, como a extensão 0.35 avisa)
if ($env:PGFN_SIM_FALHA_SALV -and $at.cnpj -eq $env:PGFN_SIM_FALHA_SALV) {
  Start-Sleep 2
  Progresso 'conta 14652591, prestação 0011: o arquivo salvo (print_confirmacao_conta_5535214.pdf) não é o documento desta prestação; tentativa 3 de 3' '0011'
  Start-Sleep 2
  Sinal 'erro' "etapa 3 (analisar as negociações ""DEFERIDA E CONSOLIDADA""): [falha_salvamento] conta 14652591, prestação 0011: o PDF não foi salvo depois de 3 tentativa(s) (o arquivo salvo (print_confirmacao_conta_5535214.pdf) não é o documento desta prestação). Evidência: C:\x\Falha_Salvamento_$($at.cnpj)_conta_14652591_prest_0011.pdf. O CNPJ fica pendente para a próxima execução`nSessão do e-CAC: encerrada (""Sair com Segurança"")"
  while ($true) { Start-Sleep 5 }
}
# 0.36.0: PGFN_SIM_SESSAO=<cnpj>:<vezes>: as <vezes> primeiras aberturas DESSE CNPJ respondem "[sessao_pgfn]" (SISPAR sem
# permissão); depois conclui. <vezes> = 99: sempre. Conta as aberturas do CNPJ em <contador>.<cnpj>.
if ($env:PGFN_SIM_SESSAO) {
  $cfgS = $env:PGFN_SIM_SESSAO -split ':'
  if ($at.cnpj -eq $cfgS[0]) {
    $arqN = "$($env:PGFN_SIM_CONTADOR).$($at.cnpj)"
    $k = 1 + [int](Get-Content -LiteralPath $arqN -ErrorAction SilentlyContinue); Set-Content -LiteralPath $arqN -Value $k
    if ($k -le [int]$cfgS[1]) {
      Start-Sleep 2
      Progresso 'O SISPAR respondeu "Você não tem permissão de acesso ou ele expirou" (conta 5465828); encerrando a sessão…' '0003'
      Start-Sleep 1
      Sinal 'erro' "etapa 3 (analisar as negociações ""DEFERIDA E CONSOLIDADA""): [sessao_pgfn] o site da PGFN respondeu ""Você não tem permissão de acesso ou ele expirou"" (certificado $($at.certificado), CNPJ $($at.cnpj), conta 5465828, etapa ""analisar as negociações""); refazendo o mesmo CNPJ com o Chrome reaberto`nSessão do e-CAC: encerrada (""Sair com Segurança"")"
      while ($true) { Start-Sleep 5 }
    }
  }
}
switch ($env:PGFN_SIM) {
  'conclui' { 1..3 | ForEach-Object { Start-Sleep 3; Progresso "passo $_" '0003' }; Sinal 'concluido' 'Perfil: teste; concluído' }
  'trava' { while ($true) { Start-Sleep 5 } } # nada muda: travado
  'trava-uma-vez' { if ($n -eq 1) { while ($true) { Start-Sleep 5 } }; Start-Sleep 3; Progresso 'retomado: PDF da prestação 0003 já salvo antes, neste mês: não emiti de novo' '0003'; Start-Sleep 3; Sinal 'concluido' 'retomado e concluído' }
  'pausa' { # esperando você por mais tempo que o limite do vigia: não pode contar como travamento
    Progresso 'PAUSA: apareceu um captcha' $null; Sinal 'aguardando_humano' 'apareceu um captcha no gov.br'
    $fim = (Get-Date).AddSeconds(40); while ((Get-Date) -lt $fim) { Start-Sleep 12; Sinal 'aguardando_humano' 'apareceu um captcha no gov.br' }
    Progresso 'captcha resolvido; continuando' $null; Sinal 'em_andamento' 'continuando'; Start-Sleep 3; Sinal 'concluido' 'concluído depois da pausa' }
  'janela' { # trava com uma janela "Salvar como" aberta; quando ela é fechada, a "extensão" segue sozinha
    $saida = Join-Path $env:TEMP 'pgfn_sim_janela.txt'; Remove-Item $saida -ErrorAction SilentlyContinue
    Start-Process powershell -ArgumentList '-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-File', $env:PGFN_SIM_DIALOGO, '-Dir', $env:TEMP, '-Nome', '7172631399999999', '-Saida', $saida
    while (-not (Test-Path $saida)) { Start-Sleep 1 }
    Progresso 'janela "Salvar como" fechada; clicando no link do PDF de novo (tentativa 2 de 3)' '0003'; Start-Sleep 3
    Progresso 'conta 1234567: PDF da prestação 0003 salvo' '0003'; Start-Sleep 2; Sinal 'concluido' "concluído depois da janela ($(Get-Content $saida))" }
}
while ($true) { Start-Sleep 5 } # o "Chrome" continua aberto até o orquestrador fechar
