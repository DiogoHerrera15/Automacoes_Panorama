// Validação da pasta ATM_PGFN extraída do ATM_PGFN.zip em OUTRO lugar (nada do projeto original é usado).
const { spawn, spawnSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const assert = require('assert');
const RAIZ = fs.realpathSync.native(path.join(fs.readFileSync(path.join(process.env.TEMP, 'pgfn_portab.txt'), 'utf8').trim(), 'ATM_PGFN'));
const AJ = path.join(RAIZ, 'Ajudante_Windows', 'salvar_como.ps1');
const BAT = path.join(RAIZ, 'Ajudante_Windows', 'salvar_como.bat');
const pedir = (pedido, viaBat) => new Promise((ok) => {
  // pelo .bat, com os argumentos que o Chrome passa (como o Chrome chama o ajudante)
  const p = viaBat ? spawn('cmd.exe', ['/d', '/s', '/c', `"${BAT}" chrome-extension://teste/ --parent-window=0`], { windowsVerbatimArguments: true })
    : spawn('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', AJ]);
  const partes = []; p.stdout.on('data', (d) => partes.push(d));
  p.on('close', () => { const b = Buffer.concat(partes); ok(b.length >= 4 && b.readInt32LE(0) === b.length - 4 ? JSON.parse(b.slice(4).toString('utf8')) : { cru: b.toString() }); });
  const j = Buffer.from(JSON.stringify(pedido), 'utf8'); const c = Buffer.alloc(4); c.writeInt32LE(j.length); p.stdin.end(Buffer.concat([c, j]));
});
(async () => {
  console.log('pasta testada:', RAIZ);
  // 1) interface
  const saida = path.join(process.env.TEMP, 'autoteste_portab.txt');
  const r1 = spawnSync(path.join(RAIZ, 'Interface', 'Automacao_PGFN.exe'), ['--autoteste', saida]);
  const txt = fs.readFileSync(saida, 'utf8');
  assert.strictEqual(r1.status, 0, txt);
  assert.ok(txt.includes('raiz ATM_PGFN: ' + RAIZ), 'a interface achou a raiz na pasta extraída: ' + txt);
  console.log('ok 1: interface abre e acha a raiz e os componentes na pasta extraída');
  // 2) ajudante pelo .bat (protocolo do Chrome)
  let r = await pedir({ acao: 'versao' }, true);
  assert.strictEqual(r.versao, '1.9', JSON.stringify(r));
  fs.writeFileSync(path.join(RAIZ, 'Automacao', 'atual.json'), JSON.stringify({ cnpj: '11444777000161', certificado: 'EMPRESA EXEMPLO LTDA:11444777000161', sessao: 's', pid: process.pid, pastaCertificado: 'EMPRESA_EXEMPLO_LTDA_11444777000161', certificadoExato: true }));
  r = await pedir({ acao: 'orq-atual' }, true);
  assert.ok(r.ativo && r.cnpj === '11444777000161' && r.pastaCertificado === 'EMPRESA_EXEMPLO_LTDA_11444777000161', 'o ajudante lê Automacao\\atual.json da pasta extraída: ' + JSON.stringify(r));
  fs.unlinkSync(path.join(RAIZ, 'Automacao', 'atual.json'));
  r = await pedir({ acao: 'orq-atual' }, true);
  assert.ok(r.ok && !r.ativo, JSON.stringify(r));
  r = await pedir({ acao: 'conferir', caminho: 'C:\\Windows\\win.ini' });
  assert.ok(!r.ok && /fora da pasta ATM_PGFN/.test(r.erro), 'só lê dentro de ATM_PGFN: ' + JSON.stringify(r));
  const log = fs.readFileSync(path.join(RAIZ, 'Ajudante_Windows', 'ajudante.log'), 'utf8');
  assert.ok(log.includes('"acao":"orq-atual"'), 'log do ajudante na pasta extraída');
  console.log('ok 2: ajudante (pelo .bat, protocolo do Chrome) responde 1.4, lê o CNPJ da vez em Automacao\\ e grava o próprio log');
  console.log('validação de portabilidade: tudo OK');
})().catch((e) => { console.error(e); process.exit(1); });
