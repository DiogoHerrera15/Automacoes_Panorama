// Gera um PDF pelo capturarEmPdf de verdade (API do Chrome imitada) e grava em disco para conferir com o pypdf.
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');
const arq = path.join(process.env.USERPROFILE, 'Downloads', 'Auto_PGFN', 'Automação_PGFN', 'background.js');
const JPEG = 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAMCAgMCAgMDAwMEAwMEBQgFBQQEBQoHBwYIDAoMDAsKCwsNDhIQDQ4RDgsLEBYQERMUFRUVDA8XGBYUGBIUFRT/2wBDAQMEBAUEBQkFBQkUDQsNFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBT/wAARCAAgADADASIAAhEBAxEB/8QAFgABAQEAAAAAAAAAAAAAAAAAAAcJ/8QALBAAAQEEBA8AAAAAAAAAAAAAAAIBAwQGBQcSEwgRFBUYISIxOFFWhKW00//EABYBAQEBAAAAAAAAAAAAAAAAAAAFBv/EABwRAAAGAwAAAAAAAAAAAAAAAAABAgMEESFhgf/aAAwDAQACEQMRAD8AgMhyHTtZk1wMtS1A5ypqNvMnhb526t2Hanitp4pKWYkoU3W1m7mV3QRrz6H8tA/cYCPFZI/fejEGuhr5892K6SEEVVee7GTgwW5LZrWZ3dY5oZF6CNefQ/loH7kinyQ6dqzmuOlqZYHNtNQVjKIW+dvbFt2l4nadqUluNK0t1Nbv5m6JkXh3cVk8dj6MOIE92U6aFkVVeObCdBbjNktBnd1nuhAwAXhDAAAAAAAAAAH/2Q==';
let baixado = null;
const ouv = {};
const chrome = {
  action: { onClicked: { addListener: () => {} } },
  runtime: { onMessage: { addListener: (f) => { ouv.msg = f; } } },
  tabs: {
    onCreated: { addListener: () => {} }, onRemoved: { addListener: () => {} },
    get: async (id) => ({ id, active: id !== 99, windowId: 1 }),
    captureVisibleTab: async () => JPEG,
  },
  downloads: {
    download: async (o) => { baixado = o; return 7; },
    search: async () => [{ filename: 'C:\\Users\\x\\Downloads\\' + baixado.filename.replace(/\//g, '\\'), state: 'complete' }],
    onChanged: { addListener: (f) => setTimeout(() => f({ id: 7, state: { current: 'complete' } }), 5), removeListener: () => {} },
  },
  storage: { session: { get: async () => ({}), set: async () => {}, remove: async () => {} } },
};
const ctx = { chrome, console, URL, Date, Promise, TextEncoder, atob, btoa, setTimeout, clearTimeout, Blob,
  createImageBitmap: async () => ({ width: 48, height: 32 }) };
vm.runInNewContext(fs.readFileSync(arq, 'utf8'), ctx);
const enviar = (msg, aba) => new Promise((r) => { if (!ouv.msg(msg, { tab: { id: aba, windowId: 1 }, url: 'https://www.regularize.pgfn.gov.br/' }, r)) r(undefined); });

(async () => {
  const NOME = '90000017000131;RM TERCEIRIZACAO E EMPRESA CLIENTE 2 LTDA.pdf';
  const r = await enviar({ tipo: 'capturar', pasta: 'Auto_PGFN/Sem_parcelamento', nome: NOME }, 3);
  assert.ok(r.ok && !r.nomeAjustado, JSON.stringify(r));
  assert.strictEqual(baixado.filename, 'Auto_PGFN/Sem_parcelamento/' + NOME);
  assert.ok((await enviar({ tipo: 'capturar', pasta: 'Auto_PGFN/Sem_parcelamento', nome: '90000022000144;JOSÉ & FILHOS (MATRIZ), S/N.pdf' }, 3)).ok === false, 'barra no nome é recusada');
  assert.ok((await enviar({ tipo: 'capturar', pasta: 'Auto_PGFN/Sem_parcelamento', nome: '90000022000144;JOSÉ & FILHOS (MATRIZ) LTDA.pdf' }, 3)).ok, 'acento, & e parênteses passam');
  // o Chrome recusando o ";": salva com "_"
  const original = chrome.downloads.download;
  chrome.downloads.download = async (o) => { if (o.filename.includes(';')) throw new Error('Invalid filename'); return original(o); };
  const ajustado = await enviar({ tipo: 'capturar', pasta: 'Auto_PGFN/Sem_parcelamento', nome: NOME }, 3);
  assert.ok(ajustado.ok && ajustado.nomeAjustado && baixado.filename.endsWith('90000017000131_RM TERCEIRIZACAO E EMPRESA CLIENTE 2 LTDA.pdf'), JSON.stringify(ajustado));
  chrome.downloads.download = original;
  await enviar({ tipo: 'capturar', pasta: 'Auto_PGFN/Sem_parcelamento', nome: NOME }, 3);
  assert.strictEqual(baixado.saveAs, false);
  fs.writeFileSync(path.join(__dirname, 'saida.pdf'), Buffer.from(baixado.url.split(',')[1], 'base64'));
  assert.strictEqual((await enviar({ tipo: 'capturar', pasta: '../fora', nome: 'x.pdf' }, 3)).ok, false, 'pasta com .. é recusada');
  assert.strictEqual((await enviar({ tipo: 'capturar', pasta: 'Auto_PGFN/Sem_parcelamento', nome: '../x.pdf' }, 3)).ok, false, 'nome com .. é recusado');
  const fundo = await enviar({ tipo: 'capturar', pasta: 'Auto_PGFN/Sem_parcelamento', nome: 'a.pdf' }, 99);
  assert.ok(!fundo.ok && /primeiro plano/.test(fundo.erro), 'aba em segundo plano dá erro claro');
  console.log('pdf: testes passaram; caminho:', r.caminho);
})().catch((e) => { console.error(e); process.exit(1); });
