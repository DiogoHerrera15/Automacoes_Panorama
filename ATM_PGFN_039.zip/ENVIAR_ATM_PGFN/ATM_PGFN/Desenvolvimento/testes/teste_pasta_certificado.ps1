﻿param([string]$Orig = 'C:\Users\PANORAMA-PC\Downloads\Auto_PGFN', [string]$PastaOrq = 'orquestrador', [string]$PastaAj = 'ajudante_salvar_como')
# 0.34.1 — a pasta do CERTIFICADO é sempre definida (Certificado -> CNPJ -> documentos), mesmo com cnpjs.json antigo
# (sem "pasta" e sem "exato"). Orquestrador REAL em pasta temporária; "Chrome" simulado (não grava documentos).
$ErrorActionPreference = 'Stop'
$SCR = Split-Path -Parent $MyInvocation.MyCommand.Path
$falhas = 0
function Ok($nome, $cond, $extra) { if ($cond) { "OK    $nome" } else { $script:falhas++; "FALHA $nome  $extra" } }
$T = Join-Path $env:TEMP ('pgfn_pasta_' + (Get-Random))
New-Item -ItemType Directory "$T\$PastaOrq", "$T\$PastaAj" | Out-Null
Copy-Item "$Orig\$PastaOrq\orquestrador.ps1" "$T\$PastaOrq\"
Copy-Item "$Orig\$PastaAj\salvar_como.ps1", "$Orig\$PastaAj\salvar_como.bat" "$T\$PastaAj\"
# pasta de certificado já existente com nome completo (simula a CERT_A); o trecho do nome deve achar ela
$docs = Join-Path $env:USERPROFILE 'Downloads\Auto_PGFN\Documentos_arrecadacao'
$fake = Join-Path $docs 'ZZTESTE_CERT_PASTA_LTDA_11222333000181'
New-Item -ItemType Directory $fake -Force | Out-Null
try {
  # grupo 1: formato antigo, nome por trecho, sem pasta/exato -> deve usar a pasta existente
  # grupo 2: formato antigo, certificado sem pasta existente -> nome convertido
  # grupo 3: formato da interface (exato + pasta) -> inalterado
  '{"certificados":[{"certificado":"ZZTESTE CERT PASTA","cnpjs":["11.444.777/0001-61"]},{"certificado":"Empresa Nova Ação","cnpjs":["90.000.006/0001-51"]},{"certificado":"EMPRESA TESTE:1","exato":true,"pasta":"EMPRESA_TESTE_1","cnpjs":["11.222.333/0001-81"]}]}' | Set-Content "$T\c.json" -Encoding UTF8
  $env:PGFN_SIM = 'conclui'; $env:PGFN_SIM_CONTADOR = "$T\aberturas.txt"
  $p = Start-Process powershell -PassThru -WindowStyle Hidden -ArgumentList '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "$T\$PastaOrq\orquestrador.ps1",
    '-Config', "$T\c.json", '-Andamento', "$T\a.json", '-ChromeSimulado', "$SCR\chrome_simulado.ps1", '-MinutosTravamento', '1'
  [void]$p.WaitForExit(300000)
  Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" | Where-Object { $_.CommandLine -like '*pgfn_chrome_simulado*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
  $log = Get-Content "$T\$PastaOrq\orquestrador.log" -Raw -Encoding UTF8
  Ok 'trecho do nome -> pasta do certificado já existente' ($log -like '*pasta: Documentos_arrecadacao\ZZTESTE_CERT_PASTA_LTDA_11222333000181\11444777000161*')
  Ok 'sem pasta existente -> nome do certificado convertido' ($log -like '*pasta: Documentos_arrecadacao\EMPRESA_NOVA_ACAO\90000006000151*')
  Ok 'formato da interface (pasta definida) inalterado' ($log -like '*pasta: Documentos_arrecadacao\EMPRESA_TESTE_1\11222333000181*')
  Ok 'nenhum CNPJ sem pasta de certificado' (([regex]::Matches($log, '  pasta: ')).Count -eq 3) ([regex]::Matches($log, '  pasta: ')).Count
  $a = Get-Content "$T\a.json" -Raw -Encoding UTF8 | ConvertFrom-Json
  Ok 'os 3 concluídos (fluxo normal)' (@($a.PSObject.Properties | Where-Object { $_.Value.situacao -eq 'concluido' }).Count -eq 3)
} finally {
  Remove-Item $fake -Force -ErrorAction SilentlyContinue
  Remove-Item $T -Recurse -Force -ErrorAction SilentlyContinue
}
""; if ($falhas) { "$falhas FALHA(S)" } else { 'TUDO OK' }
