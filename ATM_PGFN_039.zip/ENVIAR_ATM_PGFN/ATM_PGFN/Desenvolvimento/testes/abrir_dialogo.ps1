param([string]$Dir, [string]$Nome, [string]$Saida, [int]$Atraso = 0)
# Abre uma janela "Salvar como" de verdade (a mesma janela comum do Windows que o Chrome usa) e, se clicarem em
# "Salvar", grava um PDF mínimo no caminho escolhido (como o Chrome faria). Resultado em $Saida.
Add-Type -AssemblyName System.Windows.Forms
if ($Atraso) { Start-Sleep -Milliseconds $Atraso }
$d = New-Object System.Windows.Forms.SaveFileDialog
$d.Title = 'Salvar como'
$d.Filter = 'Arquivo PDF|*.pdf'
$d.InitialDirectory = $Dir
$d.FileName = $Nome
$d.OverwritePrompt = $true
$d.AutoUpgradeEnabled = $true
$r = $d.ShowDialog()
if ($r -eq [System.Windows.Forms.DialogResult]::OK) {
  [IO.File]::WriteAllText($d.FileName, "%PDF-1.4`n% teste do ajudante`n")
  [IO.File]::WriteAllText($Saida, "SALVO|" + $d.FileName)
} else {
  [IO.File]::WriteAllText($Saida, "CANCELADO")
}
