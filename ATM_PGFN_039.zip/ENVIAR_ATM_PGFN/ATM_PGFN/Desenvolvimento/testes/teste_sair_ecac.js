// background.js de verdade: no fim do CNPJ ("orq-finalizar"), primeiro "Sair com Segurança" nas abas do e-CAC da
// janela ANÔNIMA (nunca no Chrome normal, nunca na página de login), depois o aviso ao orquestrador; e, a partir daí,
// o login automático fica desligado ("orq-atual" responde ativo:false sem chamar o ajudante).
const fs = require('fs');
const path = require('path');
const assert = require('assert');
const vm = require('vm');
const arq = path.join(process.env.USERPROFILE, 'Downloads', 'Auto_PGFN', 'Automação_PGFN', 'background.js');

function montar(trava = false) {
  const sess = {}, ouv = {}, eventos = [], ctl = {};
  const urls = { 5: 'https://cav.receita.fazenda.gov.br/ecac/', 6: 'https://cav.receita.fazenda.gov.br/autenticacao/login', 7: 'https://cav.receita.fazenda.gov.br/ecac/' };
  const abas = [
    { id: 5, incognito: true, status: 'complete' }, // e-CAC da automação (anônima)
    { id: 6, incognito: true, status: 'complete' }, // página de login (nada a encerrar)
    { id: 7, incognito: false, status: 'complete' }, // e-CAC do Chrome normal: NUNCA tocar
    { id: 9, incognito: true, status: 'complete', url: 'https://sisparnet.pgfn.fazenda.gov.br/x' },
  ];
  const nada = { addListener: () => {} };
  const chrome = {
    offscreen: { hasDocument: async () => true, createDocument: async () => {} },
    contentSettings: { automaticDownloads: { set: async () => {} } },
    action: { onClicked: nada },
    scripting: { executeScript: async () => [{ result: true }] },
    runtime: { id: 'EXT', onInstalled: nada, onStartup: nada, onMessage: { addListener: (f) => { ouv.msg = f; } },
      sendNativeMessage: async (host, m) => { eventos.push(`ajudante:${m.acao}:${m.situacao || ''}`);
        if (m.acao === 'orq-atual' && ctl.respostaOrq === 'erro') throw new Error('sem ajudante');
        return m.acao === 'orq-atual' ? (ctl.respostaOrq || { ok: true, ativo: true, cnpj: '1' }) : { ok: true }; } },
    downloads: { onDeterminingFilename: nada, onChanged: nada, search: async () => [] },
    tabs: { onCreated: nada, onRemoved: nada, onUpdated: nada,
      query: async (q) => abas.map((a) => ({ ...a, url: a.url || urls[a.id] })).filter((a) => !q.url || a.url.startsWith(q.url.replace('*', ''))),
      sendMessage: (id, m) => { eventos.push(`aba${id}:${m.tipo}`); if (trava) return new Promise(() => {}); urls[id] = 'https://cav.receita.fazenda.gov.br/autenticacao/sair'; return Promise.resolve({ ok: true, clicou: true }); },
      update: async (id, o) => { if (o.active) eventos.push(`frente:aba${id}`); return {}; },
      get: async (id) => ({ id, url: urls[id], status: 'complete' }) },
    windows: { update: async (id) => { eventos.push(`janela${id}`); return {}; } },
    storage: { session: { get: async (k) => (k in sess ? { [k]: sess[k] } : {}), set: async (o) => { Object.assign(sess, o); }, remove: async (k) => { delete sess[k]; } },
      local: { get: async () => ({}), set: async () => {} } },
  };
  vm.runInNewContext(fs.readFileSync(arq, 'utf8'), { chrome, console: { log() {}, warn() {}, error() {} }, URL, Date, Promise, setTimeout, clearTimeout });
  const enviar = (msg, tab) => new Promise((r) => { if (!ouv.msg(msg, { tab, url: tab.url }, r)) setImmediate(() => r(undefined)); });
  return { enviar, eventos, set respostaOrq(v) { ctl.respostaOrq = v; } };
}

(async () => {
  // A) fim do CNPJ na janela anônima da automação
  let t = montar();
  const sispar = { id: 9, incognito: true, url: 'https://sisparnet.pgfn.fazenda.gov.br/x' };
  let r = await t.enviar({ tipo: 'orq-atual' }, sispar);
  assert.strictEqual(r.ativo, true, 'antes do fim: orquestrador ativo');
  r = await t.enviar({ tipo: 'orq-finalizar', sessao: 's', cnpj: '1', situacao: 'concluido', mensagem: 'ok' }, sispar);
  assert.deepStrictEqual(t.eventos.filter((e) => e.startsWith('aba')), ['aba5:sair-ecac'], 'só a aba do e-CAC anônima recebe "sair" (não a de login, não a do Chrome normal)');
  const iSair = t.eventos.indexOf('aba5:sair-ecac'), iAviso = t.eventos.indexOf('ajudante:orq-informar:concluido');
  assert.ok(iSair >= 0 && iAviso > iSair, 'sai do e-CAC ANTES de avisar o orquestrador');
  assert.ok(t.eventos.indexOf('frente:aba5') >= 0 && t.eventos.indexOf('frente:aba5') < iSair, 'a aba do e-CAC vem para a frente antes do "Sair"');
  const chamadasAntes = t.eventos.length;
  r = await t.enviar({ tipo: 'orq-atual' }, { id: 6, incognito: true, url: 'https://cav.receita.fazenda.gov.br/autenticacao/login' });
  assert.strictEqual(r.ativo, false, 'depois de sair: login automático desligado (mesmo com o orquestrador ainda ativo)');
  assert.ok(/fecha o Chrome e segue para o próximo/.test(r.motivo) && !r.fim, 'orquestrador ainda rodando: aviso "segue para o próximo"');
  // 0.33.1: só consulta o ajudante para saber se a lista terminou (orq-atual), nada mais
  assert.deepStrictEqual(t.eventos.slice(chamadasAntes), ['ajudante:orq-atual:'], 'só consulta orq-atual');
  console.log('A ok:', t.eventos.join(' | '));

  // A2) 0.33.1: depois de sair, o orquestrador TERMINOU a lista (último CNPJ): o aviso diz que terminou, sem login
  t.respostaOrq = { ok: true, ativo: false, fim: true, encerramento: 'terminou', motivo: 'AUTOMAÇÃO TERMINADA às 09:19: a lista chegou ao fim' };
  r = await t.enviar({ tipo: 'orq-atual' }, { id: 6, incognito: true, url: 'https://cav.receita.fazenda.gov.br/autenticacao/login' });
  assert.ok(r.ativo === false && r.fim === true && r.encerramento === 'terminou' && /TERMINADA/.test(r.motivo), 'lista terminada: fim + motivo do ajudante');
  // A3) ajudante sem resposta: continua desligado, com o aviso de antes
  t.respostaOrq = 'erro';
  r = await t.enviar({ tipo: 'orq-atual' }, { id: 6, incognito: true, url: 'https://cav.receita.fazenda.gov.br/autenticacao/login' });
  assert.ok(r.ativo === false && !r.fim && /segue para o próximo/.test(r.motivo), 'ajudante falhou: desligado como antes');
  console.log('A2/A3 ok: fim da lista e ajudante sem resposta');

  // B) fora da janela anônima (não é a automação): não encerra nada, só avisa
  t = montar();
  await t.enviar({ tipo: 'orq-finalizar', sessao: 's', cnpj: '1', situacao: 'erro', mensagem: 'x' }, { id: 7, incognito: false, url: 'https://cav.receita.fazenda.gov.br/ecac/' });
  assert.ok(!t.eventos.some((e) => e.startsWith('aba')), 'Chrome normal: nenhuma sessão encerrada');
  assert.ok(t.eventos.includes('ajudante:orq-informar:erro'), 'o aviso ao orquestrador sai mesmo assim');
  r = await t.enviar({ tipo: 'orq-atual' }, { id: 7, incognito: false, url: 'x' });
  assert.strictEqual(r.ativo, true, 'sem sair, o login automático continua ligado');
  console.log('B ok:', t.eventos.join(' | '));

  // C) a aba do e-CAC não responde (o caso de 09/11 11:00): o aviso ao orquestrador sai mesmo assim, em até ~26 s
  t = montar(true);
  const t0 = Date.now();
  await t.enviar({ tipo: 'orq-finalizar', sessao: 's', cnpj: '1', situacao: 'concluido', mensagem: 'ok' }, sispar);
  const seg = (Date.now() - t0) / 1000;
  assert.ok(t.eventos.includes('ajudante:orq-informar:concluido'), 'com a aba travada, o "concluido" chega ao orquestrador');
  assert.ok(seg < 60, `(0.34: aba tem até 45 s) não fica esperando para sempre (${seg} s)`);
  console.log(`C ok (${seg.toFixed(1)} s):`, t.eventos.join(' | '));
  console.log('TUDO OK');
})().catch((e) => { console.error('FALHOU:', e.message); process.exit(1); });
