// background.js de verdade: com a janela "Salvar como" aberta, chama o ajudante uma vez (pasta e nome certos);
// sem o ajudante instalado, avisa "semAjudante" e não fica chamando.
const fs = require('fs');
const path = require('path');
const assert = require('assert');
const vm = require('vm');
const arq = path.join(process.env.USERPROFILE, 'Downloads', 'Auto_PGFN', 'Automação_PGFN', 'background.js');
const sess = {};
const ouv = {};
const nativas = [];
let respostaNativa = { ok: true, clicou: 'Salvar' };
const item = { id: 7, state: 'in_progress', filename: '' };
const nada = { addListener: () => {} };
const chrome = {
  offscreen: { hasDocument: async () => true, createDocument: async () => {} },
  contentSettings: { automaticDownloads: { set: async (o) => { (globalThis.__cs = globalThis.__cs || []).push(o); } } },
  action: { onClicked: nada },
  runtime: { id: 'EXT', onInstalled: { addListener: () => {} }, onStartup: { addListener: () => {} }, onMessage: { addListener: (f) => { ouv.msg = f; } },
    sendNativeMessage: async (host, m) => { nativas.push({ host, m }); if (respostaNativa instanceof Error) throw respostaNativa; return respostaNativa; } },
  downloads: { onDeterminingFilename: { addListener: (f) => { ouv.nome = f; } }, onChanged: nada, search: async () => [item],
    cancel: async (id) => { (globalThis.__cancelados = globalThis.__cancelados || []).push(id); } },
  tabs: { query: async () => [], onCreated: nada, onRemoved: nada, onUpdated: nada },
  storage: { session: {
    get: async (k) => (k in sess ? { [k]: sess[k] } : {}),
    set: async (o) => { Object.assign(sess, o); },
    remove: async (k) => { delete sess[k]; },
  } },
};
vm.runInNewContext(fs.readFileSync(arq, 'utf8'), { chrome, console, URL, Date, Promise, setTimeout, clearTimeout });
const enviar = (msg) => new Promise((r) => { if (!ouv.msg(msg, { tab: { id: 3, windowId: 1 }, url: 'https://sisparnet.pgfn.fazenda.gov.br/x' }, r)) setImmediate(() => r(undefined)); });
const espera = (ms) => new Promise((r) => setTimeout(r, ms));
const PASTA = 'Auto_PGFN/Documentos_arrecadacao/90000013000153';
const NOME = '90000013000153;VPA VIGILANCIA & SEGURANCA LTDA;10-2026';

(async () => {
  await enviar({ tipo: 'download-preparar', chave: 'c1', pasta: PASTA, nome: NOME });
  await new Promise((r) => ouv.nome({ id: 7, filename: 'doc.pdf', mime: 'application/pdf', url: 'https://x' }, r));
  await espera(1600); // a janela "Salvar como" fica esperando
  let st = await enviar({ tipo: 'download-status', chave: 'c1' });
  assert.ok(st.aguardandoSalvar, 'percebe a janela Salvar como');
  for (let i = 0; i < 5; i++) await enviar({ tipo: 'download-status', chave: 'c1' }); // a aba consulta várias vezes
  await espera(50);
  assert.strictEqual(nativas.length, 1, 'chama o ajudante uma vez só');
  assert.strictEqual(nativas[0].host, 'com.auto_pgfn.salvar_como');
  assert.deepStrictEqual(JSON.parse(JSON.stringify(nativas[0].m)), { acao: 'confirmar', pasta: PASTA, nome: `${NOME}.pdf`, numero: '', timeoutMs: 30000 });
  st = await enviar({ tipo: 'download-status', chave: 'c1' });
  assert.strictEqual(st.ajudante, 'salvou');
  // sem o ajudante instalado
  respostaNativa = new Error('Specified native messaging host not found.');
  await enviar({ tipo: 'download-preparar', chave: 'c2', pasta: PASTA, nome: NOME + ' 2' });
  await new Promise((r) => ouv.nome({ id: 7, filename: 'doc.pdf', mime: 'application/pdf', url: 'https://x' }, r));
  await espera(1600);
  await enviar({ tipo: 'download-status', chave: 'c2' }); await espera(30);
  for (let i = 0; i < 5; i++) await enviar({ tipo: 'download-status', chave: 'c2' });
  await espera(30);
  st = await enviar({ tipo: 'download-status', chave: 'c2' });
  assert.ok(st.ajudanteResposta.semAjudante, 'sem ajudante: avisa para instalar');
  assert.strictEqual(nativas.filter((n) => n.m.nome === `${NOME} 2.pdf`).length, 1, 'sem ajudante: não fica chamando');
  // conferir o arquivo
  respostaNativa = { ok: true, existe: true, pdf: true, bytes: 1000 };
  const c = await enviar({ tipo: 'conferir-arquivo', caminho: 'C:\\x\\Auto_PGFN\\a.pdf' });
  assert.ok(c.pdf && c.existe);
  // vários downloads: liberados só para o SISPAR, antes de cada documento
  assert.ok(globalThis.__cs.length >= 1 && globalThis.__cs.every((o) => o.primaryPattern === 'https://sisparnet.pgfn.fazenda.gov.br/*' && o.setting === 'allow'));
  assert.ok(globalThis.__cs.every((o) => o.scope === 'regular'), 'janela normal: só o escopo normal');
  globalThis.__cs = [];
  await new Promise((r) => ouv.msg({ tipo: 'download-preparar', chave: 'c3', pasta: PASTA, nome: NOME + ' 3' }, { tab: { id: 4, incognito: true } }, r));
  assert.deepStrictEqual(globalThis.__cs.map((o) => o.scope).sort(), ['incognito_session_only', 'regular'], 'janela anônima: também o escopo anônimo');
  // o site devolveu HTML no lugar do PDF: cancela e avisa (não salva como documento)
  const sug = await new Promise((r) => ouv.nome({ id: 9, filename: 'resultadoDarfInternet.htm', mime: 'text/html', url: 'https://x' }, r));
  assert.strictEqual(sug, undefined, 'não renomeia o HTML para a pasta do CNPJ');
  await espera(20);
  assert.deepStrictEqual(globalThis.__cancelados, [9]);
  st = await enviar({ tipo: 'download-status', chave: 'c3' });
  assert.ok(st.ok === false && st.naoPdf, 'status: não é PDF');
  // nova tentativa limpa o resultado anterior
  await enviar({ tipo: 'download-limpar', chave: 'c3' });
  assert.strictEqual(await enviar({ tipo: 'download-status', chave: 'c3' }), null);
  console.log('ajudante: todos os testes passaram');
})().catch((e) => { console.error(e); process.exit(1); });
