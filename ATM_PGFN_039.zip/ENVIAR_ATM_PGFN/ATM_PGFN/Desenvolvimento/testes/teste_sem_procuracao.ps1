﻿param([string]$Orig = 'C:\Users\PANORAMA-PC\Downloads\Auto_PGFN', [string]$PastaOrq = 'orquestrador', [string]$PastaAj = 'ajudante_salvar_como')
# 0.34.0 — sem procuração vira situação FINAL (não é tentado de novo), contador de progresso no log e no resumo,
# migração do "erro" antigo de procuração. Orquestrador e ajudante REAIS em pasta temporária; "Chrome" simulado.
$ErrorActionPreference = 'Stop'
$SCR = 'C:\Users\PANORA~1\AppData\Local\Temp\claude\09de981ed91e3b47\727c250a-0de5-4b90-b949-7cf9fc86e5a8\scratchpad\testes'
$falhas = 0
function Ok($nome, $cond, $extra) { if ($cond) { "OK    $nome" } else { $script:falhas++; "FALHA $nome  $extra" } }
$T = Join-Path $env:TEMP ('pgfn_semproc_' + (Get-Random))
New-Item -ItemType Directory "$T\$PastaOrq", "$T\$PastaAj" | Out-Null
Copy-Item "$Orig\$PastaOrq\orquestrador.ps1" "$T\$PastaOrq\"
Copy-Item "$Orig\$PastaAj\salvar_como.ps1", "$Orig\$PastaAj\salvar_como.bat" "$T\$PastaAj\"
# 3 CNPJs: o do meio sem procuração; um 4º que já era "erro" de procuração (andamento antigo) deve ser migrado e pulado
'{"nome":"Lista SP","certificados":[{"certificado":"EMPRESA TESTE:1","exato":true,"pasta":"EMPRESA_TESTE_1","cnpjs":["11.444.777/0001-61","11.222.333/0001-81","90.000.006/0001-51","90.000.025/0001-88"]}]}' | Set-Content "$T\c.json" -Encoding UTF8
'{"90000025000188":{"situacao":"erro","certificado":"EMPRESA TESTE:1","mensagem":"etapa 6 (conferir o CNPJ no topo): não existe procuração eletrônica deste login para nenhum dos CNPJs de teste (90.000.025/0001-88)","tentativas":3}}' | Set-Content "$T\a.json" -Encoding UTF8
function Rodar([string]$semProc = '11222333000181') {
  $env:PGFN_SIM = 'conclui'; $env:PGFN_SIM_CONTADOR = "$T\aberturas.txt"; $env:PGFN_SIM_SEMPROC = $semProc
  Remove-Item "$T\aberturas.txt" -ErrorAction SilentlyContinue
  $p = Start-Process powershell -PassThru -WindowStyle Hidden -ArgumentList '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "$T\$PastaOrq\orquestrador.ps1",
    '-Config', "$T\c.json", '-Andamento', "$T\a.json", '-ChromeSimulado', "$SCR\chrome_simulado.ps1", '-MinutosTravamento', '1'
  [void]$p.WaitForExit(300000)
  Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" | Where-Object { $_.CommandLine -like '*pgfn_chrome_simulado*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
  $env:PGFN_SIM_SEMPROC = ''
}
"=== 1ª execução ==="
Rodar
$a = Get-Content "$T\a.json" -Raw -Encoding UTF8 | ConvertFrom-Json
$log = Get-Content "$T\$PastaOrq\orquestrador.log" -Raw -Encoding UTF8
Ok 'sem procuração registrado como sem_procuracao' ($a.'11222333000181'.situacao -eq 'sem_procuracao') $a.'11222333000181'.situacao
Ok 'os outros dois concluídos' ($a.'11444777000161'.situacao -eq 'concluido' -and $a.'90000006000151'.situacao -eq 'concluido')
Ok 'erro antigo de procuração migrado para sem_procuracao' ($a.'90000025000188'.situacao -eq 'sem_procuracao' -and $a.'90000025000188'.tentativas -eq 3) $a.'90000025000188'.situacao
Ok 'migrado NÃO foi acessado (3 aberturas do Chrome, não 4)' ((Get-Content "$T\aberturas.txt") -eq '3') (Get-Content "$T\aberturas.txt")
Ok 'sem procuração não virou recuperação/travamento' ($log -notmatch 'recuperação automática' -and $log -notmatch 'TRAVAMENTO')
Ok 'log: resultado sem_procuracao (não será tentado de novo)' ($log -like '*resultado: sem_procuracao (não será tentado de novo)*')
Ok 'log: sessão do e-CAC registrada' ($log -like '*Sessão do e-CAC: encerrada*')
Ok 'log: PROGRESSO no início (1 de 4: o migrado)' ($log -like '*PROGRESSO: 1 de 4 analisados (25%) | concluídos 0 | com erro 0 | sem procuração 1 | restantes 3*')
Ok 'log: PROGRESSO depois de cada CNPJ' ($log -like '*PROGRESSO: 2 de 4 analisados (50%)*' -and $log -like '*PROGRESSO: 3 de 4 analisados (75%) | concluídos 1 | com erro 0 | sem procuração 2 | restantes 1*' -and $log -like '*PROGRESSO: 4 de 4 analisados (100%) | concluídos 2 | com erro 0 | sem procuração 2 | restantes 0*')
$u = Get-Content "$T\$PastaOrq\ultima_execucao.json" -Raw -Encoding UTF8 | ConvertFrom-Json
Ok 'resumo: 2 concluídos, 2 sem procuração, 0 restantes, 100%' ($u.concluidos -eq 2 -and $u.semProcuracao -eq 2 -and $u.pendentes -eq 0 -and $u.percentual -eq 100 -and $u.encerramento -eq 'terminou') ($u | ConvertTo-Json -Compress)
"=== 2ª execução: nada a repetir ==="
Rodar
$log2 = (Get-Content "$T\$PastaOrq\orquestrador.log" -Encoding UTF8 | Select-Object -Last 12) -join "`n"
Ok 'sem procuração não é tentado de novo (nada a fazer, Chrome não abre)' ($log2 -like '*nada a fazer.*' -and -not (Test-Path "$T\aberturas.txt"))
"=== procuração criada: Refazer sem procuração + 3ª execução refaz só esses ==="
# a mesma regra do botão (Execucao.RefazerSemProcuracao, testada no --autoteste da interface), aqui em PowerShell
$j = Get-Content "$T\a.json" -Raw -Encoding UTF8 | ConvertFrom-Json
foreach ($p in $j.PSObject.Properties) { if ($p.Value.situacao -eq 'sem_procuracao') { $p.Value.situacao = 'pendente' } }
[IO.File]::WriteAllText("$T\a.json", ($j | ConvertTo-Json -Depth 5), (New-Object Text.UTF8Encoding $false))
Rodar ''
$a = Get-Content "$T\a.json" -Raw -Encoding UTF8 | ConvertFrom-Json
Ok 'refeitos só os 2 (2 aberturas) e agora concluídos' ((Get-Content "$T\aberturas.txt") -eq '2' -and $a.'11222333000181'.situacao -eq 'concluido' -and $a.'90000025000188'.situacao -eq 'concluido')
Remove-Item $T -Recurse -Force
""; if ($falhas) { "$falhas FALHA(S)" } else { 'TUDO OK' }
