﻿param([string]$Orig = 'C:\Users\PANORAMA-PC\Downloads\Auto_PGFN', [string]$PastaOrq = 'orquestrador', [string]$PastaAj = 'ajudante_salvar_como')
# 0.35.0 — falha de salvamento esgotada (3 tentativas) num CNPJ: o orquestrador NÃO refaz o mesmo CNPJ nem trava a fila;
# registra "erro" (pendente), segue para o próximo e, na execução seguinte, refaz só esse. Orquestrador e ajudante REAIS
# em pasta temporária; "Chrome" simulado.
$ErrorActionPreference = 'Stop'
$SCR = Split-Path -Parent $MyInvocation.MyCommand.Path
$falhas = 0
function Ok($nome, $cond, $extra) { if ($cond) { "OK    $nome" } else { $script:falhas++; "FALHA $nome  $extra" } }
$T = Join-Path $env:TEMP ('pgfn_falhasalv_' + (Get-Random))
New-Item -ItemType Directory "$T\$PastaOrq" | Out-Null
if ($PastaAj -ne $PastaOrq) { New-Item -ItemType Directory "$T\$PastaAj" | Out-Null }
Copy-Item "$Orig\$PastaOrq\orquestrador.ps1" "$T\$PastaOrq\"
Copy-Item "$Orig\$PastaAj\salvar_como.ps1", "$Orig\$PastaAj\salvar_como.bat" "$T\$PastaAj\"
'{"nome":"Lista FS","certificados":[{"certificado":"EMPRESA TESTE:1","exato":true,"pasta":"EMPRESA_TESTE_1","cnpjs":["11.444.777/0001-61","90.000.002/0001-73","90.000.006/0001-51"]}]}' | Set-Content "$T\c.json" -Encoding UTF8
function Rodar([string]$falha) {
  $env:PGFN_SIM = 'conclui'; $env:PGFN_SIM_CONTADOR = "$T\aberturas.txt"; $env:PGFN_SIM_FALHA_SALV = $falha
  Remove-Item "$T\aberturas.txt" -ErrorAction SilentlyContinue
  $p = Start-Process powershell -PassThru -WindowStyle Hidden -ArgumentList '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "$T\$PastaOrq\orquestrador.ps1",
    '-Config', "$T\c.json", '-Andamento', "$T\a.json", '-ChromeSimulado', "$SCR\chrome_simulado.ps1", '-MinutosTravamento', '1'
  [void]$p.WaitForExit(300000)
  Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" | Where-Object { $_.CommandLine -like '*chrome_simulado*' -and $_.CommandLine -like "*$T*" } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
  $env:PGFN_SIM_FALHA_SALV = ''
}
"=== 1ª execução: o 2º CNPJ tem falha de salvamento ==="
Rodar '90000002000173'
$a = Get-Content "$T\a.json" -Raw -Encoding UTF8 | ConvertFrom-Json
$log = Get-Content "$T\$PastaOrq\orquestrador.log" -Raw -Encoding UTF8
Ok 'CNPJ com falha de salvamento fica "erro" (pendente), nunca concluído' ($a.'90000002000173'.situacao -eq 'erro') $a.'90000002000173'.situacao
Ok 'mensagem registra conta, prestação, motivo e evidência' (([string]$a.'90000002000173'.mensagem).Contains('[falha_salvamento] conta 14652591, prestação 0011') -and ([string]$a.'90000002000173'.mensagem).Contains('Falha_Salvamento_90000002000173')) ([string]$a.'90000002000173'.mensagem)
Ok 'o próximo CNPJ foi processado (fila não travou)' ($a.'90000006000151'.situacao -eq 'concluido' -and $a.'11444777000161'.situacao -eq 'concluido')
Ok '3 aberturas: o CNPJ com falha NÃO foi refeito na hora (não é lentidão)' ((Get-Content "$T\aberturas.txt") -eq '3') (Get-Content "$T\aberturas.txt")
Ok 'log: resultado de falha de salvamento, seguindo para o próximo' ($log -like '*resultado: erro - falha de salvamento (pendente; refeito na próxima execução; seguindo para o próximo CNPJ)*')
Ok 'não virou travamento nem recuperação automática' ($log -notmatch 'TRAVAMENTO' -and $log -notmatch 'recuperação automática')
Ok 'contador: 3 de 3 analisados, 2 concluídos, 1 com erro' ($log -like '*PROGRESSO: 3 de 3 analisados (100%) | concluídos 2 | com erro 1 | sem procuração 0 | restantes 0*')
"=== 2ª execução: refaz só o CNPJ que falhou ==="
Rodar ''
$a = Get-Content "$T\a.json" -Raw -Encoding UTF8 | ConvertFrom-Json
Ok 'só 1 abertura (o pendente) e agora concluído' ((Get-Content "$T\aberturas.txt") -eq '1' -and $a.'90000002000173'.situacao -eq 'concluido') "$(Get-Content "$T\aberturas.txt") $($a.'90000002000173'.situacao)"
Remove-Item $T -Recurse -Force
""; if ($falhas) { "$falhas FALHA(S)" } else { 'TUDO OK' }
