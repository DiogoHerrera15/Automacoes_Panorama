// Ajudante 1.5 (cópia isolada): orq-progresso, registro em disco (com 8 gravações AO MESMO TEMPO) e registro-ver.
const { spawn } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');
const assert = require('assert');
const ORIG = path.join(process.env.USERPROFILE, 'Downloads', 'Auto_PGFN', 'ajudante_salvar_como', 'salvar_como.ps1');
const T = fs.mkdtempSync(path.join(os.tmpdir(), 'pgfn_aj15_'));
fs.mkdirSync(path.join(T, 'ajudante_salvar_como')); fs.mkdirSync(path.join(T, 'orquestrador'));
const AJ = path.join(T, 'ajudante_salvar_como', 'salvar_como.ps1');
fs.copyFileSync(ORIG, AJ);
const pedir = (pedido) => new Promise((ok) => {
  const p = spawn('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', AJ]);
  const partes = []; p.stdout.on('data', (d) => partes.push(d));
  p.on('close', () => { const b = Buffer.concat(partes); ok(JSON.parse(b.slice(4, 4 + b.readInt32LE(0)).toString('utf8'))); });
  const j = Buffer.from(JSON.stringify(pedido), 'utf8'); const c = Buffer.alloc(4); c.writeInt32LE(j.length); p.stdin.end(Buffer.concat([c, j]));
});
(async () => {
  assert.strictEqual((await pedir({ acao: 'versao' })).versao, '1.5');
  fs.writeFileSync(path.join(T, 'orquestrador', 'atual.json'), JSON.stringify({ cnpj: '11444777000161', certificado: 'X', sessao: 's1', pid: process.pid }));
  let r = await pedir({ acao: 'orq-progresso', sessao: 's1', cnpj: '11444777000161', texto: 'conta 1: conferindo', checkpoint: { conta: '1', parcela: '0003', salvos: 2 } });
  assert.ok(r.ok, JSON.stringify(r));
  const pg = JSON.parse(fs.readFileSync(path.join(T, 'orquestrador', 'progresso.json'), 'utf8').replace(/^\uFEFF/, ''));
  assert.ok(pg.texto === 'conta 1: conferindo' && pg.checkpoint.parcela === '0003', JSON.stringify(pg));
  r = await pedir({ acao: 'orq-progresso', sessao: 'OUTRA', cnpj: '11444777000161', texto: 'x' });
  assert.ok(!r.ok, 'sessão diferente é recusada');
  console.log('ok: orq-progresso grava a última ação e o checkpoint (e recusa outra sessão)');
  // 8 gravações simultâneas: nenhuma pode se perder (trava/mutex)
  const chaves = Array.from({ length: 8 }, (_, i) => `11444777000161|123|${String(i + 1).padStart(4, '0')}|2026-11`);
  const res = await Promise.all(chaves.map((k, i) => pedir({ acao: 'registro-gravar', chave: k, arquivo: `C:\\x\\ATM_PGFN\\doc${i}.pdf` })));
  assert.ok(res.every((x) => x.ok), JSON.stringify(res));
  const reg = JSON.parse(fs.readFileSync(path.join(T, 'orquestrador', 'registro_salvos.json'), 'utf8').replace(/^\uFEFF/, ''));
  assert.strictEqual(Object.keys(reg).length, 8, 'as 8 chaves estão no arquivo: ' + Object.keys(reg).join(', '));
  r = await pedir({ acao: 'registro-ver', chave: chaves[5] });
  assert.ok(r.ok && r.registro && r.registro.arquivo.endsWith('doc5.pdf'), JSON.stringify(r));
  r = await pedir({ acao: 'registro-ver', chave: 'nao-existe' });
  assert.ok(r.ok && !r.registro, JSON.stringify(r));
  console.log('ok: registro em disco: 8 gravações simultâneas sem perda; registro-ver acha e não acha');
  fs.rmSync(T, { recursive: true, force: true });
  console.log('ajudante 1.5: todos os testes passaram');
})().catch((e) => { console.error(e); process.exit(1); });
