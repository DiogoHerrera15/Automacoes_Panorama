// 0.35.0 — background.js de verdade, caso real de 10/11/2026 (conta 14652591, prestação 0011): o print da conta anterior
// (perfil normal, feito pela extensão, nº 279) e o PDF do site (janela anônima, nº 279) com o MESMO número. O Chrome pode
// devolver na busca por número só o item do outro perfil. O print nunca pode virar o resultado do documento.
const fs = require('fs');
const path = require('path');
const assert = require('assert');
const vm = require('vm');
const arq = process.argv[2] || path.join(process.env.USERPROFILE, 'Downloads', 'Auto_PGFN', 'Automação_PGFN', 'background.js');
const sess = {};
const ouv = { mudou: [] };
const itens = [];
const nativas = [];
let soPrimeiroPorId = true; // como o Chrome pode fazer: search({id}) devolve UM item (o do perfil normal primeiro)
const chrome = {
  offscreen: { hasDocument: async () => true, createDocument: async () => {} },
  contentSettings: { automaticDownloads: { set: async () => {} } },
  action: { onClicked: { addListener: () => {} } },
  runtime: { id: 'EXT', onInstalled: { addListener: () => {} }, onStartup: { addListener: () => {} },
    onMessage: { addListener: (f) => { ouv.msg = f; } },
    sendNativeMessage: async (host, p) => { nativas.push(p); return p.acao === 'procurar-documento' ? { ok: true, achou: false } : { ok: true }; } },
  downloads: {
    onDeterminingFilename: { addListener: (f) => { ouv.nome = f; } },
    onChanged: { addListener: (f) => { ouv.mudou.push(f); }, removeListener: () => {} },
    download: async () => 999,
    search: async (q) => {
      let r = itens.filter((i) => (q.id === undefined || i.id === q.id) &&
        (!q.startedAfter || new Date(i.startTime) > new Date(q.startedAfter))).map((i) => ({ ...i }));
      if (q.id !== undefined && soPrimeiroPorId) r = r.sort((a, b) => (a.incognito ? 1 : 0) - (b.incognito ? 1 : 0)).slice(0, 1);
      return r;
    },
    cancel: async () => {},
  },
  tabs: { query: async () => [], onCreated: { addListener: () => {} }, onRemoved: { addListener: () => {} },
    onUpdated: { addListener: () => {} }, remove: async () => {}, update: async () => ({}), create: async () => ({}), sendMessage: async () => null },
  windows: { update: async () => ({}) },
  storage: { session: {
    get: async (k) => (k in sess ? { [k]: sess[k] } : {}),
    set: async (o) => { Object.assign(sess, JSON.parse(JSON.stringify(o))); },
    remove: async (k) => { delete sess[k]; },
  }, local: { get: async () => ({}), set: async () => {} } },
};
vm.runInNewContext(fs.readFileSync(arq, 'utf8'), { chrome, console: { log: () => {}, warn: () => {} }, URL, Date, Promise, TextEncoder, btoa, atob, setTimeout, clearTimeout });
const ABA = { id: 7, windowId: 1, incognito: true };
const enviar = (msg) => new Promise((r) => { if (!ouv.msg(msg, { tab: ABA, url: 'https://sisparnet.pgfn.fazenda.gov.br/x' }, r)) setImmediate(() => r(undefined)); });
const sugerir = (item) => new Promise((r) => { ouv.nome(item, (s) => r(s)); });
const espera = (ms) => new Promise((r) => setTimeout(r, ms));
const mudou = async (id, estado) => { for (const f of ouv.mudou) await f({ id, state: { current: estado } }); await espera(10); };
const PASTA = 'Auto_PGFN/Documentos_arrecadacao/CERTIFICADO_EXEMPLO_B_LTDA_90000024000133/90000002000173';
const NOME = '90000002000173;EMPRESA CLIENTE 1 LTDA;11-2026;conta 14652591;prest 0011';
const PRINT = 'C:\\Users\\X\\Downloads\\Auto_PGFN\\Documentos_arrecadacao\\CERTIFICADO_EXEMPLO_B_LTDA_90000024000133\\90000002000173\\print_confirmacao_conta_5535214.pdf';
const resultado = (chave) => sess.download_resultados[chave];
const status = async (chave) => { const s = await enviar({ tipo: 'download-status', chave }); await espera(30); return s; };

(async () => {
  // print da conta anterior: perfil normal, da extensão, nº 279, completo
  itens.push({ id: 279, incognito: false, byExtensionId: 'EXT', state: 'complete', startTime: new Date(Date.now() - 50000).toISOString(),
    filename: PRINT, fileSize: 667439, mime: 'application/pdf' });
  // ---------- A) o PDF do site, nº 279 na janela anônima, terminando; a busca por número só devolve o print ----------
  let chave = '14652591|0011';
  if (!process.env.PGFN_SO_B) {
  await enviar({ tipo: 'download-limpar', chave });
  assert.strictEqual(await enviar({ tipo: 'download-preparar', chave, pasta: PASTA, nome: NOME, numero: '7172631466259011' }), true);
  const pdf = { id: 279, incognito: true, state: 'in_progress', filename: '', startTime: new Date().toISOString(), mime: 'application/pdf',
    url: 'https://sisparnet.pgfn.fazenda.gov.br/doc' };
  itens.push(pdf);
  const sg = await sugerir({ ...pdf, filename: '7172631466259011.pdf' });
  assert.strictEqual(sg.filename, `${PASTA}/${NOME}.pdf`);
  assert.strictEqual(resultado(chave).anonimo, true);
  if (!process.env.PGFN_VERSAO_ANTIGA) assert.strictEqual(resultado(chave).origem, 'site');
  // aviso de fim com o número 279 (o do print, ou um aviso repetido): não pode virar o documento
  await mudou(279, 'complete');
  let st = await status(chave);
  assert.ok(st.ok === undefined, `o print NÃO é o resultado da prestação (antes da 0.35.0: ok com ${PRINT}): ${JSON.stringify(st)}`);
  // o PDF do site termina; a busca por número continua devolvendo só o print: tem que achar o item certo pelos recentes
  pdf.state = 'complete'; pdf.filename = `C:\\Users\\X\\Downloads\\${PASTA.replace(/\//g, '\\')}\\${NOME}.pdf`; pdf.fileSize = 162192;
  await mudou(279, 'complete');
  st = await status(chave);
  assert.ok(st.ok && st.caminho.endsWith(`${NOME}.pdf`) && !/print_confirmacao/.test(st.caminho), `resultado = o PDF da prestação: ${JSON.stringify(st)}`);
  console.log('A ok: mesmo nº nos dois perfis e busca por número devolvendo só o print -> resultado é o PDF certo');
  }

  // ---------- B) o Chrome não informa o perfil no item (incognito ausente): vale o perfil da aba que clicou ----------
  chave = 'kB|0001';
  await enviar({ tipo: 'download-limpar', chave });
  await enviar({ tipo: 'download-preparar', chave, pasta: PASTA, nome: 'A;B;11-2026;conta 1;prest 0001', numero: '1111111111' });
  itens.push({ id: 280, incognito: false, byExtensionId: 'EXT', state: 'complete', startTime: new Date().toISOString(), filename: PRINT });
  const semPerfil = { id: 280, state: 'in_progress', filename: '', startTime: new Date().toISOString(), mime: 'application/pdf' };
  await sugerir({ ...semPerfil });
  let stB = await status(chave);
  assert.ok(stB.ok === undefined, `o print nº 280 do perfil normal não é tomado (era o defeito de 10/11): ${JSON.stringify(stB)}`);
  assert.strictEqual(resultado(chave).anonimo, true, 'sem "incognito" no item: usa o perfil da aba (anônima)');
  console.log('B ok: item sem perfil -> perfil da aba; print com o mesmo número ignorado');

  // ---------- C) registrarFimDownload direto com o item errado (registro antigo sem "origem"): ignorado ----------
  chave = 'kC|0002';
  sess.download_resultados[chave] = { iniciado: true, id: 279, anonimo: true, tInicio: Date.now(), pasta: PASTA, nome: 'X.pdf' };
  sess.download_ids['a279'] = chave;
  soPrimeiroPorId = false;
  itens.find((i) => i.id === 279 && i.incognito).state = 'in_progress';
  await mudou(279, 'complete');
  assert.strictEqual(resultado(chave).ok, undefined, 'sem origem registrada vale "site": o print (da extensão) é ignorado');
  console.log('C ok: associação antiga (sem origem) não aceita o print da extensão');

  // ---------- D) procurar-documento chega ao ajudante com pasta, nome .pdf, número e "desde" ----------
  const r = await enviar({ tipo: 'procurar-documento', pasta: PASTA, nome: NOME, numero: '7172631466259011', desde: 123 });
  const pe = nativas.filter((p) => p.acao === 'procurar-documento').at(-1);
  assert.ok(r && r.ok && pe && pe.nome === `${NOME}.pdf` && pe.numero === '7172631466259011' && pe.desde === 123 && pe.pasta === PASTA, JSON.stringify(pe));
  const ruim = await enviar({ tipo: 'procurar-documento', pasta: '../x', nome: NOME });
  assert.ok(ruim && !ruim.ok, 'pasta inválida recusada');
  console.log('D ok: procurar-documento repassado ao ajudante (e pasta inválida recusada)');
  console.log('colisão de número de download (background 0.35.0): todos os testes passaram');
})().catch((e) => { console.error(e); process.exit(1); });
