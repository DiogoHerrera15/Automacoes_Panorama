// background.js de verdade: download feito pelo site é renomeado só quando armado; aba nova com PDF; relatório.
const fs = require('fs');
const path = require('path');
const assert = require('assert');
const vm = require('vm');
const arq = path.join(process.env.USERPROFILE, 'Downloads', 'Auto_PGFN', 'Automação_PGFN', 'background.js');
const sess = {};
const ouv = {};
const baixados = [];
const sugeridos = [];
const fechadas = [];
const ativadas = [];
let proxId = 100;
const itens = {};
const chrome = {
  offscreen: { hasDocument: async () => true, createDocument: async () => {} },
  contentSettings: { automaticDownloads: { set: async (o) => { (globalThis.__cs = globalThis.__cs || []).push(o); } } },
  action: { onClicked: { addListener: () => {} } },
  runtime: { id: 'EXT', onInstalled: { addListener: () => {} }, onStartup: { addListener: () => {} }, onMessage: { addListener: (f) => { ouv.msg = f; } } },
  downloads: {
    onDeterminingFilename: { addListener: (f) => { ouv.nome = f; } },
    onChanged: { addListener: (f) => { (ouv.mudou = ouv.mudou || []).push(f); }, removeListener: () => {} },
    download: async (o) => { const id = proxId++; baixados.push(o); ouv.nome({ id, url: o.url, byExtensionId: 'EXT', filename: '' }, (sg) => sugeridos.push(sg)); itens[id] = { id, filename: 'C:\\Downloads\\' + o.filename, state: 'complete', byExtensionId: 'EXT' };
      setTimeout(() => ouv.mudou.forEach((f) => f({ id, state: { current: 'complete' } })), 5); return id; },
    search: async ({ id }) => (itens[id] ? [itens[id]] : []),
  },
  tabs: { query: async () => [],
    onCreated: { addListener: () => {} }, onRemoved: { addListener: () => {} },
    onUpdated: { addListener: (f) => { const ant = ouv.atualizada; ouv.atualizada = async (...a) => { if (ant) await ant(...a); return f(...a); }; } },
    remove: async (id) => { fechadas.push(id); }, update: async (id) => { ativadas.push(id); return {}; },
    create: async () => ({}), sendMessage: async () => null,
  },
  storage: { session: {
    get: async (k) => (k in sess ? { [k]: sess[k] } : {}),
    set: async (o) => { Object.assign(sess, o); },
    remove: async (k) => { delete sess[k]; },
  } },
};
vm.runInNewContext(fs.readFileSync(arq, 'utf8'), { chrome, console, URL, Date, Promise, TextEncoder, btoa, setTimeout, clearTimeout });
const enviar = (msg, aba = 7) => new Promise((r) => { if (!ouv.msg(msg, { tab: { id: aba, windowId: 1 }, url: 'https://sisparnet.pgfn.fazenda.gov.br/x' }, r)) setImmediate(() => r(undefined)); });
const sugerir = (item) => new Promise((r) => { const ret = ouv.nome(item, (s) => r(s)); if (ret !== true) { /* síncrono */ } });
const espera = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  // sem armar: download do site fica como está
  assert.strictEqual(await sugerir({ id: 1, filename: 'darf.pdf', url: 'https://x' }), undefined);
  // armado: renomeia, uma vez só
  assert.strictEqual(await enviar({ tipo: 'download-preparar', chave: '6444569|0033', pasta: 'Auto_PGFN/Documentos_arrecadacao', nome: '90000003000118;SOLSERV;09-2026' }), true);
  assert.deepStrictEqual(JSON.parse(JSON.stringify(await sugerir({ id: 2, filename: 'documento.PDF', url: 'https://x' }))),
    { filename: 'Auto_PGFN/Documentos_arrecadacao/90000003000118;SOLSERV;09-2026.pdf', conflictAction: 'uniquify' });
  assert.strictEqual(await sugerir({ id: 3, filename: 'outro.pdf', url: 'https://x' }), undefined, 'o segundo download não é renomeado');
  itens[2] = { id: 2, state: 'complete', filename: 'C:\\Downloads\\Auto_PGFN\\Documentos_arrecadacao\\90000003000118;SOLSERV;09-2026.pdf' };
  for (const f of ouv.mudou) await f({ id: 2, state: { current: 'complete' } });
  await espera(20);
  let st = await enviar({ tipo: 'download-status', chave: '6444569|0033' });
  assert.ok(st.ok && /09-2026\.pdf$/.test(st.caminho), 'status ok com o caminho');
  // downloads da própria extensão nunca são renomeados
  await enviar({ tipo: 'download-preparar', chave: 'k2', pasta: 'Auto_PGFN/Documentos_arrecadacao', nome: 'A;B;10-2026' });
  assert.strictEqual(await sugerir({ id: 4, filename: 'print.pdf', byExtensionId: 'EXT' }), undefined);
  // documento abriu numa aba nova (aberta pela aba 7): baixa o endereço com o nome, fecha a aba e volta
  await ouv.atualizada(55, { status: 'complete' }, { id: 55, openerTabId: 7, url: 'https://sisparnet.pgfn.fazenda.gov.br/doc.pdf' });
  await espera(20);
  assert.strictEqual(baixados.at(-1).filename, 'Auto_PGFN/Documentos_arrecadacao/A;B;10-2026.pdf');
  assert.deepStrictEqual(fechadas, [55]); assert.deepStrictEqual(ativadas, [7]);
  st = await enviar({ tipo: 'download-status', chave: 'k2' });
  assert.ok(st.ok, 'aba nova vira download ok');
  // nome com barra é recusado
  assert.strictEqual(await enviar({ tipo: 'download-preparar', chave: 'k3', pasta: 'Auto_PGFN/x', nome: '../fora' }), false);
  assert.strictEqual(await enviar({ tipo: 'download-url', chave: 'k3', url: 'https://malicioso.example/a.pdf', pasta: 'Auto_PGFN/x', nome: 'a' }), false);
  // relatório
  const r = await enviar({ tipo: 'salvar-texto', pasta: 'Auto_PGFN/Relatorios', nome: '1;X;relatorio 2026-11-06 10h00.csv', texto: 'a;b\r\nç' });
  assert.ok(r.ok, JSON.stringify(r));
  assert.ok(baixados.at(-1).url.startsWith('data:text/csv;charset=utf-8;base64,'));
  // download da própria extensão: o ouvinte devolve o nome pedido (sem isso o Chrome salvava como "download.csv")
  assert.strictEqual(sugeridos.at(-1).filename, 'Auto_PGFN/Relatorios/1;X;relatorio 2026-11-06 10h00.csv');
  assert.ok(sugeridos.every((sg) => sg && sg.filename), 'todo download da extensão recebe o nome pedido');
  console.log('downloads: todos os testes passaram');
})().catch((e) => { console.error(e); process.exit(1); });
