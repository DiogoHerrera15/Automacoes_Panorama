﻿param([string]$Botao, [switch]$ConfirmarSim)
# Clica num botão da interface (teste): acha pelo texto e manda BM_CLICK (PostMessage: não trava na pergunta).
# Com -ConfirmarSim, responde "Sim" na caixa de pergunta que aparecer.
Add-Type -AssemblyName UIAutomationClient, UIAutomationTypes
Add-Type -Namespace T -Name W -MemberDefinition @"
[DllImport("user32.dll")] public static extern bool PostMessage(IntPtr h, int m, IntPtr w, IntPtr l);
[DllImport("user32.dll")] public static extern bool IsWindowEnabled(IntPtr h);
"@
$AE = [System.Windows.Automation.AutomationElement]; $TS = [System.Windows.Automation.TreeScope]; $PC = [System.Windows.Automation.PropertyCondition]
$p = Get-Process Automacao_PGFN | Select-Object -First 1
function Achar($nome) {
  $c = New-Object System.Windows.Automation.AndCondition((New-Object $PC($AE::ProcessIdProperty, $p.Id)), (New-Object $PC($AE::NameProperty, $nome)))
  return $AE::RootElement.FindFirst($TS::Descendants, $c)
}
$b = Achar $Botao
if (-not $b) { "botão '$Botao' não achado"; exit 1 }
$h = [IntPtr]$b.Current.NativeWindowHandle
if (-not [T.W]::IsWindowEnabled($h)) { "botão '$Botao' desabilitado"; exit 2 }
[void][T.W]::PostMessage($h, 0x00F5, [IntPtr]::Zero, [IntPtr]::Zero)
"clicou '$Botao'"
if ($ConfirmarSim) {
  for ($i = 0; $i -lt 20; $i++) {
    Start-Sleep -Milliseconds 300
    $sim = Achar 'Sim'; if (-not $sim) { $sim = Achar 'Yes' }
    if ($sim) { [void][T.W]::PostMessage([IntPtr]$sim.Current.NativeWindowHandle, 0x00F5, [IntPtr]::Zero, [IntPtr]::Zero); 'respondeu Sim'; break }
  }
}
