﻿param([string]$Titulo, [string]$Saida)
Add-Type -AssemblyName System.Drawing
Add-Type @"
using System; using System.Runtime.InteropServices;
public class Jan { [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out R r); [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
[DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
public struct R { public int L, T, Ri, B; } }
"@
[void][Jan]::SetProcessDPIAware()
$p = Get-Process | Where-Object { $_.MainWindowTitle -eq $Titulo } | Select-Object -First 1
if (-not $p) { 'janela não encontrada'; exit 1 }
[void][Jan]::SetForegroundWindow($p.MainWindowHandle); Start-Sleep -Milliseconds 700
$r = New-Object Jan+R; [void][Jan]::GetWindowRect($p.MainWindowHandle, [ref]$r)
$bmp = New-Object Drawing.Bitmap ($r.Ri - $r.L), ($r.B - $r.T)
$g = [Drawing.Graphics]::FromImage($bmp); $g.CopyFromScreen($r.L, $r.T, 0, 0, $bmp.Size)
$bmp.Save($Saida, [Drawing.Imaging.ImageFormat]::Png); "ok $($bmp.Width)x$($bmp.Height)"
