// Substituições exatas e conferidas (cada trecho tem que existir exatamente "vezes" vezes). Preserva BOM e fim de linha.
const fs = require('fs');
const path = require('path');
const [base, lista] = process.argv.slice(2);
const regras = JSON.parse(fs.readFileSync(lista, 'utf8').replace(/^﻿/, ''));
let erros = 0;
for (const r of regras) {
  const arq = path.join(base, r.arquivo);
  let buf = fs.readFileSync(arq);
  const bom = buf[0] === 0xef && buf[1] === 0xbb && buf[2] === 0xbf;
  let t = buf.toString('utf8').replace(/^﻿/, '');
  const crlf = t.includes('\r\n');
  const de = crlf ? r.de.replace(/\r?\n/g, '\r\n') : r.de;
  const para = crlf ? r.para.replace(/\r?\n/g, '\r\n') : r.para;
  const n = t.split(de).length - 1;
  const esperado = r.vezes || 1;
  if (n !== esperado) { console.log(`ERRO ${r.arquivo}: achei ${n} (esperava ${esperado}) de: ${r.de.slice(0, 80)}`); erros++; continue; }
  t = t.split(de).join(para);
  fs.writeFileSync(arq, (bom ? '﻿' : '') + t, 'utf8');
  console.log(`ok   ${r.arquivo}: ${r.de.slice(0, 60).replace(/\s+/g, ' ')}`);
}
process.exit(erros ? 1 : 0);
