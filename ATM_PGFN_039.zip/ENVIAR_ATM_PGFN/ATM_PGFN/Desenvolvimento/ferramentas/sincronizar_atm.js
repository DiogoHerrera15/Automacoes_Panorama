// Leva as mudanças da Auto_PGFN para a ATM_PGFN: copia os arquivos e reaplica só as trocas de caminho da ATM
// (as mesmas regras usadas na criação da ATM, menos a do CNPJS_TESTE, que já veio vazio da Auto).
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');
const S = __dirname;
const AUTO = path.join(process.env.USERPROFILE, 'Downloads', 'Auto_PGFN');
const ATM = path.join(process.env.USERPROFILE, 'Downloads', 'ATM_PGFN');
const copias = [
  ['Automação_PGFN/content.js', 'Extensao_Chrome/content.js'],
  ['Automação_PGFN/background.js', 'Extensao_Chrome/background.js'],
  ['Automação_PGFN/manifest.json', 'Extensao_Chrome/manifest.json'],
  ['ajudante_salvar_como/salvar_como.ps1', 'Ajudante_Windows/salvar_como.ps1'],
  ['orquestrador/orquestrador.ps1', 'Automacao/orquestrador.ps1'],
];
for (const [de, para] of copias) fs.copyFileSync(path.join(AUTO, de), path.join(ATM, para));
const ler = (f) => JSON.parse(fs.readFileSync(path.join(S, f), 'utf8').replace(/^﻿/, ''));
const alvos = new Set(copias.map((c) => c[1]));
const regras = [...ler('regras_atm.json'), ...ler('regras_atm2.json')]
  .filter((r) => alvos.has(r.arquivo) && !r.de.includes('CNPJS_TESTE'));
// o orquestrador da Auto já tem o novo registro: o ajudante vive em Ajudante_Windows na ATM
fs.writeFileSync(path.join(S, 'regras_sinc.json'), JSON.stringify(regras, null, 1), 'utf8');
console.log(execFileSync('node', [path.join(S, 'substituir.js'), ATM, path.join(S, 'regras_sinc.json')], { encoding: 'utf8' }));
