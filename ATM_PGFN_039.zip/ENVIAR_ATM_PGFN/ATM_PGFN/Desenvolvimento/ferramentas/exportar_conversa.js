// Exporta a conversa (arquivo .jsonl do Claude Code) para Markdown legível, em ordem cronológica:
// mensagens do usuário (texto e, entre colchetes, imagens/anexos) e respostas de texto do Claude.
// NÃO inclui: saída das ferramentas (comandos, leituras de arquivo), raciocínio interno, avisos do sistema.
// Remove e-mail e trechos de sistema. Uso: node exportar_conversa.js <entrada.jsonl> <saida.md> <titulo>
const fs = require('fs');
const [entrada, saida, titulo] = process.argv.slice(2);
const linhas = fs.readFileSync(entrada, 'utf8').split('\n').filter(Boolean);
const limpar = (t) => String(t)
  .replace(/<system-reminder>[\s\S]*?<\/system-reminder>/g, '')
  .replace(/<(command-[a-z-]+|local-command-[a-z-]+)>[\s\S]*?<\/\1>/g, '')
  .replace(/<\/?pasted_content[^>]*>/g, '')
  .replace(/[\w.+-]+@[\w-]+\.[\w.]+/g, '[e-mail removido]')
  .replace(/([?&](token|access_token|code|chave|session|sessao)=)[^\s&"')]+/gi, '$1[removido]')
  .replace(/\beyJ[\w-]{10,}\.[\w.-]+/g, '[token removido]')
  .trim();
const partes = [];
let n = 0;
for (const l of linhas) {
  let o; try { o = JSON.parse(l); } catch (_) { continue; }
  if (o.isSidechain) continue;
  const quando = o.timestamp ? new Date(o.timestamp).toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo' }) : '';
  if (o.type === 'user' && o.message) {
    if (o.isCompactSummary) { partes.push(`\n---\n\n### [${quando}] (resumo automático da conversa até aqui — feito pelo sistema quando o contexto encheu)\n\n${limpar(typeof o.message.content === 'string' ? o.message.content : o.message.content.map((c) => c.text || '').join('\n'))}\n`); continue; }
    const c = o.message.content;
    let texto = '';
    if (typeof c === 'string') texto = limpar(c);
    else if (Array.isArray(c)) {
      if (c.some((x) => x.type === 'tool_result')) continue; // resultado de ferramenta
      texto = c.map((x) => x.type === 'text' ? limpar(x.text) : x.type === 'image' ? '[imagem enviada]' : '').filter(Boolean).join('\n\n');
    }
    // avisos automáticos (fim de tarefa em segundo plano, instruções de sistema, habilidades): não são mensagens do usuário
    texto = texto.replace(/^\[Image: source:[^\]]*\]\s*/gm, '').trim();
    if (!texto || /^\[Request interrupted/.test(texto) || /^<task-notification>/.test(texto) ||
      /^(Base directory for this skill|Codebase and user instructions|Caveat:)/.test(texto)) continue;
    n++;
    partes.push(`\n---\n\n## [${quando}] USUÁRIO (mensagem ${n})\n\n${texto}\n`);
  } else if (o.type === 'assistant' && o.message && Array.isArray(o.message.content)) {
    const texto = o.message.content.filter((x) => x.type === 'text').map((x) => limpar(x.text)).filter(Boolean).join('\n\n');
    if (texto) partes.push(`\n**Claude** [${quando}]:\n\n${texto}\n`);
  }
}
const cab = `# ${titulo}\n\nExportado automaticamente do arquivo da conversa (${entrada.split(/[\\/]/).pop()}).\n` +
  'Contém as mensagens do usuário e as respostas em texto do Claude, em ordem cronológica. NÃO contém a saída das ' +
  'ferramentas (comandos, leituras de arquivos, testes), o raciocínio interno nem as imagens (só a indicação "[imagem enviada]").\n' +
  `Mensagens do usuário: ${n}.\n`;
fs.writeFileSync(saida, cab + partes.join(''), 'utf8');
console.log(saida, n, 'mensagens do usuário', Math.round(fs.statSync(saida).size / 1024), 'KB');
