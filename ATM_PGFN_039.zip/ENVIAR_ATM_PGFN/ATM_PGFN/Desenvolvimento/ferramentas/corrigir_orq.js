// Corrige os acentos estragados nos comentários e aplica o "catch" que registra erro inesperado, nos dois orquestradores.
const fs = require('fs');
const arqs = process.argv.slice(2);
for (const arq of arqs) {
  let t = fs.readFileSync(arq, 'utf8');
  const bom = t.charCodeAt(0) === 0xfeff;
  t = t.replace(/^﻿/, '');
  // UTF-8 lido como Latin-1 (ex.: "Ã£" -> "ã"): volta cada par ao caractere certo
  t = t.replace(/Ã[\u0080-¿]/g, (m) => Buffer.from(m, 'latin1').toString('utf8'));
  if (/Ã/.test(t)) throw new Error(arq + ': ainda há acento estragado');
  const crlf = t.includes('\r\n') ? '\r\n' : '\n';
  const de = '} finally {' + crlf + '  Remove-Item -LiteralPath $ARQ_ATUAL -ErrorAction SilentlyContinue # sem orquestrador, a extensão volta ao modo manual';
  const n = t.split(de).length - 1;
  if (n !== 1) throw new Error(arq + ': trecho do finally achado ' + n + ' vez(es)');
  const para = '} catch {' + crlf +
    '  # erro inesperado: fica registrado (antes o orquestrador fechava sem dizer por quê)' + crlf +
    '  Log "ERRO no orquestrador: $($_.Exception.Message) (linha $($_.InvocationInfo.ScriptLineNumber)). Rode Iniciar de novo para continuar."' + crlf + de;
  t = t.replace(de, para);
  fs.writeFileSync(arq, (bom ? '﻿' : '') + t, 'utf8');
  console.log('ok', arq);
}
