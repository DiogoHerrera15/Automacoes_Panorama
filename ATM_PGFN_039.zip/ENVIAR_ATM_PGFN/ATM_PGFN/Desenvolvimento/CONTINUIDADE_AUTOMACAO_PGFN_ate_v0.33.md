# CONTINUIDADE — Automação PGFN (e-CAC → Regularize → SISPAR)

> Documento para retomar o desenvolvimento numa nova conversa **exatamente de onde paramos**.
> Gerado em 09/11/2026. Projeto em `C:\Users\PANORAMA-PC\Downloads\Auto_PGFN\`.
> **Não reinicie o projeto, não recrie funcionalidades e não mude a arquitetura sem necessidade.**
> Complementa o `README.md` da mesma pasta, que tem o detalhe técnico de cada etapa.

---

## 0. Resumo de uma página

| Item | Situação |
|---|---|
| **Versão atual da extensão** | **0.32.0** (`Automação_PGFN\manifest.json`) + ajudante **1.4** + interface `Automacao_PGFN.exe` — configurações por certificado, pasta `Documentos_arrecadacao\<CERTIFICADO>\<CNPJ>`, seleção exata do certificado, pausar/retomar/parar; 0.31.2: erro 500 do e-CAC: até 5 tentativas e depois print; erro 10000 da Receita: print + CNPJ não concluído; 0.31.0: salvamento robusto da janela "Salvar como" (número de download x perfil, nome corrigido na janela, fechamento controlado, pausa só quando esgotar); 0.30.1: janela com "Calcular" calcula sozinha (seção 6) |
| **Ajudante do Windows** | versão **1.2** (`ajudante_salvar_como\salvar_como.ps1`), instalado no registro (HKCU) |
| **Orquestrador** | `orquestrador\orquestrador.ps1`; em uso real com a lista de 21 CNPJs |
| **Como rodar (independente do Claude)** | `INICIAR_AUTOMACAO.bat` (janela própria com o CNPJ no título, etapas, erros e resumo final), `VER_ANDAMENTO.bat` (situação de cada CNPJ), `INSTALAR.bat` (instalação guiada em outro PC; `instalacao\instalar.ps1 -SoVerificar` só confere), `instalacao\GERAR_PACOTE.bat` (zip em `pacotes\` sem dados de clientes), `LEIA-ME.txt`. Os .bat precisam de fim de linha CRLF e os .ps1 de BOM UTF-8 (PowerShell 5.1) |
| **Fluxo de um CNPJ (login manual)** | **funciona no site real**: troca de perfil, Regularize, SISPAR, emissão, downloads, prints, relatório e pastas por CNPJ |
| **Em desenvolvimento** | troca automática de CNPJ: fecha todo o Chrome, reabre anônimo, faz login gov.br com certificado e processa a lista de `cnpjs.json` |
| **Onde paramos** | no teste real do orquestrador, o Chrome abriu o login do e-CAC, mas **o fluxo de login da extensão não disparou** na página `https://cav.receita.fazenda.gov.br/autenticacao` (detalhes na seção 8) |
| **Primeira ação na próxima conversa** | diagnosticar por que o content script não iniciou o login nessa página (seção 9), sem mexer no que já funciona |

---

## 1. Objetivo do projeto e regras do usuário

Extensão do Chrome (Manifest V3, **sem Playwright e sem Selenium**) que automatiza, como uma pessoa faria, este caminho:
**e-CAC → Regularize (PGFN) → SISPAR → emissão dos documentos de arrecadação das negociações "DEFERIDA E CONSOLIDADA"**,
salvando tudo numa pasta por CNPJ.

### Preferências e restrições (obrigatórias)
- Responder sempre em **português do Brasil**.
- **Preservar tudo o que já funciona.** Mudar só o necessário para cada pedido.
- **Preservar integralmente o método de download, salvamento, nomes e organização dos arquivos.**
- **Seta do mouse desenhada** e movimento **humanizado e aleatório**: curvas de Bézier, 4 tipos de aceleração, ritmo por página, tremor, pausas e micro-ajustes. Nada de cliques instantâneos ou sequências rápidas demais. Na janela nativa de certificado, usar o **mouse real** com movimento suave.
- **Esperar cada elemento com tempo limite** e mostrar uma mensagem clara, em vez de travar. O **aviso fica no canto inferior esquerdo**.
- **Nunca digitar login ou senha.** **Nunca clicar em "DESISTIR".** **Não burlar captcha.** Se aparecer captcha, PIN, senha ou confirmação de segurança, **pausar** e deixar o usuário resolver, e depois retomar sem reiniciar.
- **Não alterar configurações de segurança do Chrome automaticamente**: informar o usuário. Exceções que ele autorizou:
  - liberar "downloads automáticos" **só** para `sisparnet.pgfn.fazenda.gov.br`;
  - instalar o ajudante do Windows no HKCU;
  - **fechar todo o Chrome** a cada CNPJ (decisão dele: "Fechar todo o Chrome").
- **Certificado:** escolher pelo nome configurado; **nunca escolher outro** se não achar. O CERT_A é só de desenvolvimento e teste e **não pode ficar fixo no código**.
- Usar sempre o **CNPJ em processamento** para pastas e nomes; nunca associar documento ao cliente errado.
- Evitar downloads e emissões repetidos; registrar o andamento; permitir retomar sem repetir os concluídos.
- A extensão antiga `Documents\simplificado\parcelamento_simplificado` é **só referência**: não modificar.
- Depois de cada mudança no código da extensão, o usuário precisa **Recarregar** a extensão em `chrome://extensions`. Sempre lembrá-lo disso.
- O usuário testa no site real e manda prints. O desenvolvimento é validado antes num **simulador local** (seção 10).

---

## 2. Arquitetura e arquivos

```
Downloads\Auto_PGFN\
├── Automação_PGFN\                 ← extensão (carregar sem compactação em chrome://extensions)
│   ├── manifest.json               v0.28.0; permissões: storage, downloads, offscreen, nativeMessaging, contentSettings; host <all_urls>
│   ├── content.js                  seta, buscas, etapas do e-CAC/Regularize/SISPAR, análise e emissão, login gov.br (≈175 KB)
│   ├── background.js               service worker: estado por aba, passagens entre abas, downloads/renomeação, prints PDF, ajudante, orquestrador
│   ├── pagina.js                   mundo MAIN: intercepta window.open do "CONTINUAR" do SISPAR (abre a aba nova uma vez, como no manual)
│   ├── offscreen.html / .js        documento invisível: junta as partes do print da página inteira num PDF (print_confirmacao)
├── ajudante_salvar_como\           ← ajudante do Windows (native messaging "com.auto_pgfn.salvar_como")
│   ├── salvar_como.ps1             ações: confirmar (janela Salvar como), conferir (PDF no disco), versao, orq-atual, orq-informar, certificado
│   ├── salvar_como.bat             o Chrome chama este .bat. NUNCA escrever nada na saída padrão nele (ver 0.28.1 na seção 6)
│   ├── instalar_ajudante.bat/.ps1  acha o ID da extensão no Chrome e registra em HKCU\Software\Google\Chrome\NativeMessagingHosts
│   ├── desinstalar_ajudante.bat
│   ├── com_auto_pgfn_salvar_como.json  manifesto do host (allowed_origins: chrome-extension://hljabalaigcloapogemdonfjdpenfiff/)
│   ├── ajudante.log                registro de cada pedido e resposta
├── orquestrador\                   ← troca automática de CNPJ (em desenvolvimento)
│   ├── orquestrador.ps1            fecha todo o Chrome, abre anônimo, acompanha a extensão, grava andamento
│   ├── iniciar_orquestrador.bat
│   ├── atual.json                  (temporário) CNPJ da vez, certificado, sessão, PID do orquestrador
│   ├── sinal.json                  (temporário) andamento informado pela extensão
│   ├── andamento.json              situação de cada CNPJ (em_andamento | concluido | erro)
│   └── orquestrador.log
├── cnpjs.json                      certificados → lista de CNPJs (desde 09/11: CERT_A → 21 CNPJs de teste, na ordem enviada; 90.000.004/0001-62 tem DV inválido e vira "erro" sem abrir o Chrome)
├── Documentos_arrecadacao\<CNPJ>\  ← TODOS os arquivos de cada CNPJ (ver seção 4)
├── README.md                       documentação técnica detalhada (atualizada até a 0.28.0)
└── CONTINUIDADE_AUTOMACAO_PGFN.md  este arquivo
```

- **ID da extensão** (carregada sem compactação no perfil "Default", chamado "Suporte Panorama Fiscal"): `hljabalaigcloapogemdonfjdpenfiff`. Se a pasta mudar, o ID muda; aí é preciso rodar `instalar_ajudante.bat` de novo.
- **Ambiente:** Chrome **157.0.8103.38** no Windows 10.
  - O Chrome 157 **não aceita `--load-extension`**.
  - "Permitir no modo anônimo" está ligado.
  - No perfil normal, "Perguntar onde salvar" está **desligado**. Mesmo assim, **na janela anônima o Chrome abre "Salvar como"**; o ajudante resolve.
- **Simulador e testes** (fora do projeto, pasta temporária da conversa; podem ter sido apagados): `%TEMP%\claude\...\scratchpad\mock\`. Contém `server.js` (portas 8765/8766), `index.html` (e-CAC), `regularize.html`, `net.html`, `sisparnet.html`, `login.html` e os testes `teste_background.js`, `teste_downloads.js`, `teste_proximo.js` e `teste_ajudante.js`. Ver a seção 10.

---

## 3. Fluxo que já funciona (um CNPJ; login feito pelo usuário)

### 3.1 e-CAC (`cav.receita.fazenda.gov.br`)
1. **Início sozinho:** começa ao abrir ou recarregar a tela inicial ("Prezado Contribuinte"). Depois de encerrada, só recomeça pelo ícone da extensão.
2. **Aviso "Prepare-se para a evolução…":** clica em **"Continuar no e-CAC por enquanto"**, nunca em "Acessar o portal".
3. **Topo:** lê "Titular" e "Procurador de:".
4. **Alterar perfil:** clica em "Alterar perfil de acesso", digita o CNPJ tecla a tecla em "Procurador de pessoa jurídica - CNPJ" e clica no "Alterar" **da mesma linha**.
5. **Conferência do topo:**
   - se travar, faz F5 e tenta de novo, até 2 vezes;
   - se aparecer "Não existe procuração eletrônica", passa ao próximo CNPJ da lista.
6. **Dívida Ativa:** clica no bloco "Dívida Ativa da União" e depois em **"PGFN - Todos os serviços do Regularize"**.
   - Se essa opção não aparecer em 8 s com o painel aberto, **pula o CNPJ** e segue para o próximo, sem salvar nada.

### 3.2 Regularize (`www.regularize.pgfn.gov.br`), numa janela nova que assume o andamento
1. **Sem cadastro:** se aparecer **"Você ainda não está cadastrado no REGULARIZE…"**, tira o print e salva **`sem_cadastro_regularize.pdf`** na pasta do CNPJ. Não segue o fluxo e vai para o próximo CNPJ.
2. **Aviso "Atenção!":** clica em **CIENTE**.
3. **Aviso de notificações** ("Fique atento: você tem novas notificações…"): clica em **FECHAR**, nunca em "VER AGORA". Confere nas duas páginas.
4. **NEGOCIAR DÍVIDA:** clica e, no bloco "Acesso ao Sistema de Negociações - Parcelamento ou Acordo de Transação", clica em **ACESSAR**.
5. **CONSULTAR:** dentro do quadro do SISPAR (iframe de outro domínio, tratado por um "agente" no próprio iframe), clica em **CONSULTAR** e depois em **CONTINUAR**, nunca em DESISTIR.
6. **Aba nova:** o SISPAR abre numa aba própria, `sisparnet.pgfn.fazenda.gov.br`.
   - Causa já resolvida: o simulador faz `window.open(url)||location.replace(url)`. Num clique simulado, a janela é bloqueada e o SISPAR carregava dentro do iframe, onde perdia a sessão ("Sessão encerrada").
   - Solução: o `pagina.js` intercepta e a extensão abre a aba **uma vez**, porque o token é de uso único.

### 3.3 SISPAR (aba `sisparnet`)
1. **Menu:** passa o mouse em **"Emissão de Documento"**, sem clicar, desce até **"Documento de arrecadação"** e clica, não em "…Avulso".
2. **Sem parcelamento:** se aparecer "Não foram encontradas solicitações de negociação", salva o print em PDF `CNPJ;NOME.pdf` na pasta do CNPJ.
3. **Tabela de negociações:** clica em **"Situação da conta"** para ordenar.
   - **Nenhuma "DEFERIDA E CONSOLIDADA":** confere a linha "Usuário:", tira o print e salva **`Sem_Deferido_<CNPJ>.pdf`**.
4. **Para cada conta "DEFERIDA E CONSOLIDADA"**, guardada pelo Número da Conta, uma por vez:
   1. seleciona a linha e clica em **"Documento de Arrecadação" abaixo da tabela**, não o item do menu;
   2. na página da negociação, confere "Nr. Referência Conta" e "Contribuinte:", que tem de ser o CNPJ ativo;
   3. **rola com a "roda do mouse"** pela tabela "Prestação" e confere a coluna **"Emissão"** até o **mês atual**. Meses futuros não contam.

   O que fazer em cada ícone da coluna "Emissão":

   | Ícone | Situação | O que a automação faz |
   |---|---|---|
   | verificado azul | regular | nada |
   | **laranja com exclamação** | **já emitido** | não emite de novo; confere a data do documento |
   | impressora (ou outro ícone clicável com saldo devedor) | pendência | emite o documento (passo 4) |
   | desconhecido | — | anota como "VERIFICAR" no relatório |

   4. **Emissão** de cada pendência:
      1. clica na impressora; abre a janela "Cálculo e demonstrativo…";
      2. confere "Parcela para emissão" e clica em **Emitir**;
      3. na página do PDF (`resultadoDarfInternet.jsf`), clica no link do PDF;
      4. o download é renomeado e salvo, depois **conferido**: completo, `.pdf`, na pasta do CNPJ e começando com `%PDF` no disco (pelo ajudante);
      5. clica em **Voltar**.
   5. **Fim da conta:** volta à tela "Prestação", faz a **conferência final** pelo que o sistema mostra e salva o **print de confirmação em PDF** da página inteira.
   6. Volta à lista pelo menu, ordena de novo e passa à próxima conta.
5. **Relatório** `.csv` na pasta do CNPJ, com uma linha por prestação e a situação na tela final.
6. **Fim do CNPJ:** passa ao próximo da lista. A aba do e-CAC recebe o próximo CNPJ e as abas do Regularize e do SISPAR são fechadas.

### 3.4 Proteções que já existem
- **Registro de downloads** (`chrome.storage.local`, chave CNPJ|conta|prestação|mês): não emite de novo no mesmo mês.
- **Retomada:** cada passo da emissão fica gravado; a página nova continua do ponto certo, sem repetir "Emitir".
- **Downloads da página:**
  - um download HTML no lugar do PDF é **cancelado**;
  - o atalho "baixar o endereço do link" **nunca** baixa a própria página (o link é `#`);
  - se nada chegar, tenta o link do PDF **mais uma vez**, sem emitir de novo.
- **Vários arquivos:** o aviso "vários arquivos" do Chrome é evitado liberando `automaticDownloads` só para `https://sisparnet.pgfn.fazenda.gov.br/*`, inclusive na janela anônima.
- **Salvar como:** a janela "Salvar como" é confirmada pelo **ajudante**. Ele clica em Salvar só se a pasta for `…\Auto_PGFN\Documentos_arrecadacao\<CNPJ>`, o nome bater e o tipo for PDF. Nunca substitui arquivo. No Chrome, a caixa "Tipo" não é legível; vale o tipo recebido do site mais a checagem do `%PDF`.

---

## 4. Salvamento e organização (NÃO ALTERAR)

Diretório principal: `Downloads\Auto_PGFN\Documentos_arrecadacao\<CNPJ só dígitos>\`. A pasta é criada sozinha.
Antes de salvar, a automação confere o CNPJ em processamento: 14 dígitos e igual à linha "Usuário:" da tela.

| Arquivo | Quando |
|---|---|
| `CNPJ;NOME;MM-AAAA.pdf` | documento de cada prestação pendente (competência = mês do vencimento) |
| `CNPJ;NOME;MM-AAAA;conta X;prest Y.pdf` | mesma competência já salva nesta execução |
| `CNPJ;NOME.pdf` | print "sem parcelamento" |
| `Sem_Deferido_<CNPJ>.pdf` | nenhuma "DEFERIDA E CONSOLIDADA" |
| `sem_cadastro_regularize.pdf` | CNPJ sem cadastro no Regularize |
| `print_confirmacao.pdf`, ou `print_confirmacao_conta_<conta>.pdf` se houver várias negociações | situação final da tela "Prestação" (página inteira) |
| `CNPJ;NOME;relatorio AAAA-MM-DD HHhMM[ (parcial)].csv` | relatório da execução |

Mecânica (no `background.js`):
- **Downloads da página:** `onDeterminingFilename` renomeia **só** o primeiro download depois de "armar" a espera (`download-preparar`).
- **Downloads da própria extensão** (prints e relatório): recebem o nome pedido (mapa `nomesPedidos`). Sem isso, caíam como "download.pdf".
- **Prints de uma tela:** `captureVisibleTab` vira JPEG dentro de um PDF de uma página.
- **Print de confirmação:** várias partes fotografadas, juntadas no `offscreen.js` e salvas como PDF por um endereço `blob:`. Um endereço `data:` acima de 2 MB é recusado.

---

## 5. Desenvolvimento em andamento: orquestrador e vários certificados

### Decisões do usuário (aprovadas em 09/11/2026)
- **Fechar todo o Chrome** a cada CNPJ, sem confirmação, e **reabrir em modo anônimo**.
- Endereço de entrada: **`https://cav.receita.fazenda.gov.br/autenticacao`**.
- Login: **"Entrar com gov.br"** → **"Seu certificado digital"** → janela "Selecione um certificado" → certificado do grupo.
- `cnpjs.json` com **vários certificados**, cada um com a sua lista de CNPJs. CERT_A só para teste. Depois de validar com o CERT_A, o usuário manda as listas restantes.

### Como foi implementado (0.28.0 + ajudante 1.2)
- **`cnpjs.json`:** `{ "certificados": [ { "certificado": "CERTIFICADO EXEMPLO A", "cnpjs": ["90000006000151"] } ] }`.
- **`orquestrador.ps1`**, para cada CNPJ não concluído:
  1. espera não haver `.crdownload`;
  2. fecha todo o Chrome (`CloseMainWindow`, depois `Stop-Process -Force`);
  3. grava `atual.json` (cnpj, certificado, sessão guid, PID);
  4. abre `chrome.exe --incognito --no-first-run <url>`;
  5. lê `sinal.json` a cada 3 s até "concluido" ou "erro";
  6. grava `andamento.json`.

  Regras do acompanhamento:
  - **Prazo:** 30 min sem sinal geram erro, exceto em "aguardando_humano", que não tem prazo.
  - **Chrome fechado** antes do fim gera erro.
  - **Concluídos** não se repetem.
  - **Status no `andamento.json`:** todos os CNPJs da lista entram como `pendente` ao iniciar; depois `em_andamento`, `concluido` ou `erro` (com o motivo). CNPJ com dígito verificador inválido vira `erro` sem abrir o Chrome.
  - **Parâmetros de teste:** `-PerfilChrome <pasta>` fecha e abre só um Chrome com esse perfil; `-UrlInicial`; `-SoMostrar`.
- **Ajudante, ações novas:**
  - **`orq-atual`:** devolve o CNPJ da vez, se o PID do orquestrador estiver vivo.
  - **`orq-informar`:** só aceita a sessão e o CNPJ definidos.
  - **`certificado`:** acha a janela "Selecione um certificado" e escolhe pela coluna "Tema", que deve ter **exatamente 1** com o nome. Leva o **mouse real** com Bézier e pausas até a linha e clica. **Confere que o foco** ficou no certificado e só então clica em OK; com `teste:true`, clica em Cancelar.
- **Extensão:**
  - **Lista de CNPJs:** `LISTA_CNPJS` vem do orquestrador (via `orq-atual`); sem orquestrador, usa `CNPJS_TESTE`.
  - **`informarOrq`:** em cada etapa ("em_andamento"), no fim ("concluido" ou "erro") e nas pausas ("aguardando_humano").
  - **Fim do CNPJ:** `estado.cnpjFinalizado` marca o fim verdadeiro.
  - **Páginas de login:** `fluxoLogin()` roda em `cav…/autenticacao*` e em `sso.acesso.gov.br`:
    - clica em "Entrar com gov.br" (um `input type=image alt="Acesso Gov BR"` com `onclick="validarHcaptcha('govBr')"`, ou seja, um hCaptcha invisível);
    - depois clica em "Seu certificado digital" (texto exato) e pede `certificado-selecionar` ao ajudante;
    - se aparecer captcha, uma tela desconhecida ou um certificado não encontrado, **pausa** com aviso.

### Descobertas técnicas importantes
- **A janela "Selecione um certificado" do Chrome é legível.** Linhas como `CERTIFICADO EXEMPLO A LTDA:90000001000129 | AC SyngularID Multipla | 4AA7C7369B30E53D0C28` e `EMPRESA CLIENTE 3 LTDA:90000007000104 | AC SOLUTI Multipla v5`; botões OK, Cancelar e "Informações do certificado".
- **`SelectionItem.Select()` pela acessibilidade FECHA a janela**, como um cancelar. Por isso o ajudante usa o clique real do mouse.
- **Depois do clique,** a CORRETA, que vem selecionada de fábrica, continua aparecendo como "selecionada" na acessibilidade. O sinal confiável é o **foco**.
- **A janela não fecha sozinha:** ficou mais de 50 s aberta sem ninguém mexer.
- **Sessão anônima já aberta:** abrir `certificado.sso.acesso.gov.br` nela reaproveita o certificado escolhido antes e vai direto para "Portal Logado". Para testar a janela, usar um Chrome com perfil temporário (`--user-data-dir`).

### Testes já feitos (todos sem tocar no Chrome do usuário)
- **Ajudante, certificado (Chrome temporário):** com nome inexistente, recusou e listou os disponíveis (4 s). Com o CERT_A, selecionou com o mouse, conferiu o foco e clicou em Cancelar (9 s).
- **Ajudante, orquestração:** `orq-atual` e `orq-informar` funcionando, incluindo recusar outro CNPJ e reconhecer orquestrador parado.
- **Orquestrador com Chrome temporário e "extensão falsa":** um CNPJ concluído e um com erro; a segunda execução repetiu só o com erro (tentativa 2).
- **Simulador:** login (Entrar com gov.br → Seu certificado digital → pedido do CERT_A → e-CAC) e pausa com captcha OK. O fluxo antigo do SISPAR continua igual.

---

## 6. Histórico do desenvolvimento (versões)

| Versão | O que entrou |
|---|---|
| até 0.11 | e-CAC (troca de perfil, F5 em travamento, "sem procuração"), Dívida Ativa, Regularize (CIENTE, NEGOCIAR, ACESSAR), quadro do SISPAR com agente no iframe, CONSULTAR/CONTINUAR |
| 0.12 | causa do "Sessão encerrada" (window.open bloqueado e SISPAR no iframe): `pagina.js` + aba nova uma vez só |
| 0.13–0.13.1 | eventos de hover corretos no menu "Emissão de Documento"; clique que recarrega a página sem repetir (`antesDoClique`) |
| 0.14 | todas as "DEFERIDA E CONSOLIDADA", uma por vez, pelo botão abaixo da tabela |
| 0.15 | coluna "Emissão": rolagem com a roda, competência até o mês atual, relatório .csv |
| 0.16 | janela "Cálculo e demonstrativo" → Emitir → página do PDF → link → Voltar; pasta por CNPJ; conferência do "Contribuinte" |
| 0.17 | aviso "Continuar no e-CAC"; janela "Salvar como" (espera manual); registro de downloads por mês |
| 0.18 | pula o CNPJ sem "PGFN - Todos os serviços do Regularize" |
| 0.19 | `Sem_Deferido_<CNPJ>.pdf`; próximo CNPJ na aba do e-CAC |
| 0.20 | fecha o aviso de notificações da PGFN (FECHAR) |
| 0.21 | **tudo na pasta do CNPJ** (antes havia Sem_parcelamento/Relatorios); correção de "download.pdf/.csv" (nomes da própria extensão); arquivos antigos movidos |
| 0.22 | conferência final e print de confirmação da página inteira (offscreen) |
| 0.23 | print de confirmação em **PDF**; ícone **laranja = já emitido** |
| 0.24 | ajudante do Windows (native messaging): confirma "Salvar como" e confere o PDF no disco |
| 0.25 | "vários downloads" liberado só no SISPAR (contentSettings); download HTML cancelado; correção do `.htm` (o atalho baixava a própria página); nova tentativa do link do PDF |
| 0.26 | ajudante tolera a caixa "Tipo" ilegível do Chrome; registro `ajudante.log`; checagem do ajudante no início do CNPJ |
| 0.27 | tela "Você ainda não está cadastrado no REGULARIZE" → `sem_cadastro_regularize.pdf` |
| **0.28** | **orquestrador + `cnpjs.json` + login gov.br com certificado + avisos ao orquestrador** (em teste) |
| **0.28.1** | login não disparava: a aba aberta na partida do Chrome carregava antes da extensão subir e ficava sem o content.js. Correção: permissão `scripting`; o background confere as páginas de login (`cav…/autenticacao*`, `sso.acesso.gov.br`) e injeta o content.js se faltar; o content.js tem trava contra cópia dupla (`window.__autoPgfnCarregado`). Orquestrador: se em 40 s não houver `orq-atual` no `ajudante.log`, abre o endereço de novo na janela anônima (até 2 vezes). **Causa principal (achada depois):** a linha de diagnóstico `echo … %*>> chamadas.log` no `salvar_como.bat` (09/11 ~08:58). O Chrome chama o host com `--parent-window=0`; o `0>>` virava redirecionamento e o texto ia para a saída padrão, quebrando o protocolo (tamanho lido = 825178416). Toda chamada ao ajudante falhava ("login automático desligado: o ajudante do Windows não respondeu"). Linha removida; testado imitando o Chrome: `versao` e `orq-atual` OK |
| **0.29.0** | **Lentidão:** em `executar()`, erro de lentidão (tempo esgotado / "não apareceu", "não abriu"…; erros de regra nunca) → espera 6–10 s e repete a MESMA etapa até 2× → recarrega a página (F5) e retoma, até 2× por aba (e-CAC; Regularize só antes do CONTINUAR, recomeçando pela espera da página; SISPAR nunca recarrega) → senão erro marcado `[lentidao]`. Não repetem: aguardar janela do Regularize, CONTINUAR, conferir o topo, próximo CNPJ. **Orquestrador:** erro `[lentidao]` ou "sem dar sinal" → refaz o MESMO CNPJ com Chrome reaberto até 2×; depois fica "erro" (não concluído). **Caixa Postal:** aviso "Você possui mensagens importantes…" tratado em `fecharAvisoEcac()`: clica em "Ir para a Caixa Postal", print da página inteira (conteúdo com rolagem interna esticado) em `<CNPJ do cabeçalho>\Caixa_Postal_<CNPJ>.pdf` (registro em storage.local: nunca salva de novo), volta ao endereço de antes e continua o mesmo CNPJ. NÃO abre mensagens (pode valer como ciência de intimação): se o aviso voltar, PAUSA ("aguardando_humano", sem prazo) até a página inicial do e-CAC voltar sem ele. Validado no simulador (Caixa Postal 1 visita, Caixa Postal com pausa e retomada, lentidão superada, lentidão até o limite, fluxo SISPAR completo) |
| **0.29.1** | **Erro 93003** ("número máximo de dispositivos conectados", 09/11 10:32). **Causa:** o orquestrador fecha o Chrome à força a cada CNPJ sem sair do e-CAC; cada login ficava contando como dispositivo no servidor (≈9 logins em ~1 h, nenhum logout). Além disso, a página do erro (`/autenticacao/Error/Erro/93003`) era tratada como página de login e a automação clicou na barra "gov.br" dela. **Correção:** o aviso final ao orquestrador virou `orq-finalizar` (content `finalizarOrq`): o background primeiro manda "Sair com Segurança" (`sair-ecac`) a cada aba do e-CAC da janela ANÔNIMA (nunca Chrome normal, nunca página de login), espera a página mudar (até 15 s), DEPOIS avisa o orquestrador; a partir daí `orq-atual` responde ativo:false (sem novo login até o Chrome fechar). Na página do 93003: espera 60/180/300 s e volta a `/autenticacao` (contagem em sessionStorage `pgfn_tentativas_93003`, zera quando o e-CAC abre); na 4ª recusa PAUSA ("aguardando_humano", sem prazo, o CNPJ não é pulado). Sessões abertas antes desta versão (e em outros navegadores) não podem ser encerradas pela automação; expiram sozinhas. Validado: testes do background (novo `teste_sair_ecac.js` + os 4 antigos, com o harness ajustado para `tabs.query` e vários `onUpdated`) e simulador (93003 2× e entra; 93003 sempre → pausa após 3; clique em "Sair com Segurança"). **Possível melhoria futura (não feita):** reaproveitar a mesma sessão para os CNPJs do mesmo certificado, sem fechar o Chrome entre eles |
| **0.29.2** | **Fim do CNPJ travava** (09/11 10:59, CNPJ 90000008000140): o "Sair com Segurança" era pedido à aba do e-CAC, que estava ATRÁS da do SISPAR; em segundo plano o Chrome atrasa os tempos da página e a seta não chegava ao botão; sem tempo máximo, o "concluido" nunca saía. Correção no background: a aba do e-CAC vem para a frente antes do pedido, a resposta tem limite de 25 s e a saída inteira 60 s; o aviso ao orquestrador SEMPRE sai. Teste `teste_sair_ecac.js` com aba travada: "concluido" em ~26 s. **Orquestrador:** Chrome fechado antes do fim = você parou: o CNPJ volta a "pendente (interrompido)" e o orquestrador ENCERRA (antes marcava erro e abria o próximo, gerando logins em sequência) |
| **0.30.0** | **Janela de emissão com cálculo prévio** (09/11 11:16, CNPJ 90000009000195, conta 5585667, prestação 0013): a janela "Cálculo e demonstrativo" pode ter "RECEITA BRUTA APURADA NO MES ANTERIOR" (0,00) + "Calcular", com "Emitir" DESABILITADO até calcular; a automação clicava no Emitir desabilitado e parava. Agora (`calcularNaJanela`, chamada em `baixarDocumento` quando `exigeCalculo`): PAUSA "aguardando_humano" (sem prazo) pedindo a receita — a automação NUNCA digita valor financeiro; você digita e clica em "Calcular" (se só digitar e sair do campo, ela clica); ela confere mesma parcela, "Valor da Prestação" > 0 e "Emitir" habilitado e segue o "Emitir" de sempre (PDF, conferência no disco, "Voltar"). "Voltar" na janela = parcela "PENDENTE - documento NÃO baixado" com o motivo no relatório, e segue para as demais. Agente: `ler janelaEmissao` devolve `exigeCalculo`, `receita`, `receitaEmFoco`, `valorNumero` (campo "Valor da Prestação"), `emitirHabilitado`; alvos `calcular`, `cookiesPermitir`. **Cookies da PGFN:** `aceitarCookiesPgfn()` clica em "Permitir" do aviso ("…Declaração de Cookies") no início de cada etapa da aba do SISPAR e antes de cada emissão; sem aviso, nada. Validado no simulador (`sisparnet?docres=com&calc=1`: receita digitada → Calcular automático → emitida; Voltar → não emitida e registrada; e `docres=com` convencional: 3 emissões, 3 prints, como antes). **Atenção:** na conta 5585667 as prestações 0013 em diante estão em aberto; pela regra atual cada uma até o mês atual é uma pendência a emitir, e cada janela vai pedir a receita |
| **0.30.1** | **Decisão do usuário (09/11 13:17):** na janela com "Calcular" NÃO é preciso informar a receita: basta "Calcular" e "Emitir". A 0.30.0 pausava sempre que havia "Calcular" (condição `janela.exigeCalculo` → pausa direta em `calcularNaJanela`). Agora: 1º clica em "Calcular" com o valor que o sistema já mostra (nunca digita nem altera) e espera até 20 s o sistema liberar o "Emitir" com "Valor da Prestação" > 0 → segue sozinha para o "Emitir" de sempre (PDF, conferência, "Voltar", próxima parcela). Só se o sistema NÃO liberar, PAUSA pedindo o dado (como na 0.30.0; o valor de comparação para o "Calcular" automático é o usado no 1º cálculo). Validado no simulador: `calc=1` (0,00 libera: 3 parcelas emitidas sem pausa, 3 prints, relatório) e `calc=exige` (0,00 não libera → pausa → receita informada → "Calcular" → emitida) |
| **0.31.0** (+ ajudante **1.3**) | **Janela "Salvar como" travada** (09/11 14:23, CNPJ 90000010000110, conta 12581384, prest. 0020; e 14:32, CNPJ 90000011000164, conta 1029524, prest. 0117). **Causa (provada pelo histórico de downloads do Chrome e pelos relatórios):** os downloads da extensão (prints, relatórios) ficam no perfil NORMAL; os PDFs do site, na janela ANÔNIMA, e cada perfil numera os seus — o mesmo número existia nos dois (190 = print da conta 12581379 e PDF da conta 12581384; 195 e 196 no outro CNPJ). Só acontecia no 2º PDF em diante de uma sessão, depois de um print. Efeitos: (1) o Chrome perdia o nome sugerido e a janela abria com o nome do site ("7172631317956373"); (2) a extensão lia o item errado (o print, já completo): ou nem chamava o ajudante (caso 2), ou chamava e o ajudante recusava a janela por nome diferente (caso 1); (3) quando a pessoa salvava à mão, o relatório registrava **o print da outra conta como documento** (falso "documento baixado"). **Correção:** background identifica cada download por número + perfil (`chaveId`, `acharDownload`, `registrarFimDownload`); `download-procurar` acha o download do site sem nome sugerido (só com 1 candidato, nunca da extensão); ajudante chamado até 3× com pausa (falha de comunicação conta; chamada perdida >70 s é refeita), depois `esgotado`; `download-fechar-janela` = ajudante `cancelar` (botão "Cancelar" só da janela DESTE documento). **Ajudante 1.3:** aceita a janela com o nome pedido ou com o número do documento; se pasta/nome não forem os certos (ou o arquivo já existir), escreve o caminho completo livre (`...\<CNPJ>\<nome>.pdf`, ou `(1)`, nunca sobrescreve) no campo "Nome" com WM_SETTEXT + EN_CHANGE (só WM_SETTEXT a janela ignora — testado) e clica em "Salvar"; ações novas `cancelar` e `janelas`. **content.js:** rotina única de salvamento (`validarSalvo`, `registrarSalvo`, `conferirSalvoAtrasado`, `aguardarSalvamentoManual`); o arquivo tem que ser DESTA prestação (nome pedido ou número do documento), na pasta do CNPJ, `%PDF` no disco; link do PDF até 3× (antes de repetir confere se o PDF chegou atrasado); esgotado → PAUSA "aguardando_humano" sem prazo, até o PDF certo estar salvo (nunca segue em silêncio); na página do PDF nunca recarrega (reenviaria a emissão). Logs `[salvamento] CNPJ, conta, prestação, arquivo` no console e avisos ao orquestrador. **Validado:** `teste_salvamento_bg.js` (número repetido nos dois perfis — falha na versão antiga, passa na nova; falha temporária do ajudante; 3 falhas → fechar; chamada perdida; download sem nome); `teste_janela_real.js` com janelas "Salvar como" REAIS do Windows (normal; nome do site + pasta errada corrigidos; arquivo existente → "(1)"; janela que demora 6 s; janela de outro arquivo intocada; cancelar controlado); simulador `sc=esgota|sempre|atrasado|errado` e fluxo normal |
| **0.31.1** | **Erro 10000 da Receita Federal** (09/11 15:18, `/autenticacao/Error/Erro/10000`: "Prezado Usuário, não foi possível validar os seus dados nas bases cadastrais da Receita Federal. Por favor, tente mais tarde."). Antes: a página era tratada como login e a automação pausava sem achar "Entrar com gov.br". Agora (`telaErro10000` / `tratarErro10000`, em `fluxoLogin` logo depois do 93003): só com o texto exato E (endereço `/erro/10000` ou "Código: 10000"); CNPJ = o da vez no orquestrador (`ORQ.cnpj`, com DV conferido; sem ele → PAUSA, nada salvo); print da página inteira em `Documentos_arrecadacao\<CNPJ>\Problema_receita_federal_<CNPJ>.pdf` (nunca sobrescreve: "(1)"), conferido no disco (%PDF) e na pasta; falha no print → PAUSA; senão `finalizarOrq('erro', …)` = não concluído (o orquestrador segue para o próximo e tenta de novo na próxima execução; a mensagem não tem "[lentidao]", então não repete na hora). Uma vez só por página: sem recarregar nem tentar login. Validado no simulador: 10000 → print + conferência + erro; CNPJ inválido → pausa sem print; disco ruim → pausa; outro erro (77777) → não tratado como 10000; login normal intacto |
| **0.31.2** | **Erro 500 do e-CAC** (09/11 15:27, `/autenticacao/Error/ErrorHttp?500;`: "Atenção. (Código: 500 - …) Ocorreu um erro interno na aplicação."). Antes: a automação ficava em "login: aguardando a página de acesso do e-CAC carregar…". Agora (`telaErro500` / `tratarErro500`, em `fluxoLogin` depois do 93003 e do 10000): só com o texto "Ocorreu um erro interno na aplicação" E (endereço `ErrorHttp?500` ou "Código: 500"). Até 5 tentativas POR CNPJ (contagem em sessionStorage `pgfn_tentativas_500_<CNPJ>`, não zera com recarga nem quando o acesso volta), esperas 15/30/60/90/120 s; tentativas 1–2 recarregam a página, 3–5 voltam a `/autenticacao` e refazem o login (uma entrada por tentativa). Voltou o acesso: segue o mesmo CNPJ pelo fluxo normal (andamento gravado; registro impede emitir de novo). Esgotadas: print `Documentos_arrecadacao\<CNPJ>\Erro_500_<CNPJ>.pdf` (função comum `salvarPrintDeErro`, também usada pelo 10000; conferido no disco/pasta; falha → PAUSA) e `finalizarOrq('erro', "Não concluído (pendente por erro interno da Receita Federal)…")` — o orquestrador segue para o próximo e o tenta na próxima execução. CNPJ da vez desconhecido → PAUSA. Validado no simulador: erro some na 3ª tentativa → login e e-CAC (contagem 3); erro permanente → exatamente 5 tentativas, print, conferência, fim; 10000 e 93003 continuam com seus tratamentos |
| **0.32.0** (+ ajudante **1.4**) | **Interface de configuração** (`Automacao_PGFN.exe`, C# WinForms compilado com o csc.exe do .NET Framework 4 do Windows: `interface\AutomacaoPGFN.cs` + `interface\compilar.bat`). Configurações em `configuracoes\<nome>.json` (formato do cnpjs.json + `exato: true` + `pasta`) e andamento próprio em `configuracoes\<nome>.andamento.json`. Na 1ª abertura importa o `cnpjs.json` (nome do certificado trocado pelo nome exato do Windows) e copia o `orquestrador\andamento.json` (nada refeito). Lista de certificados = Windows Pessoal com chave privada e "Autenticação de Cliente" (nome = CN, o mesmo do Chrome). Iniciar: confere certificado com EXATAMENTE o nome (não existe/vencido → não começa; 2+ iguais → confirmação e, no login, pausa para você escolher), ajudante instalado, e chama `orquestrador.ps1 -Config … -Andamento …` (janela minimizada). Acompanhamento a cada 2 s (execucao.json, atual.json do mesmo pid, sinal.json, andamento, fim do orquestrador.log). Pausar/Retomar/Parar = `orquestrador\pausar.flag` / `parar.flag`, sempre ENTRE CNPJs. "Nova rodada" guarda o andamento em cópia. **Orquestrador:** `-ArquivoAndamento` (alias `-Andamento`; o nome `$Andamento` colidia com a tabela `$andamento`), `pasta`/`exato` por grupo (`Pasta-Certificado`: sem acento, maiúsculas, `[A-Z0-9_-]`, até 80), `atual.json` com `pastaCertificado` e `certificadoExato`, `execucao.json` (uma execução por vez), flags, `-SemChrome` (teste; grava `atual_teste.json`, nunca o real). **Extensão:** `pastaDocumentos()` = `Documentos_arrecadacao/<pastaCertificado>` com orquestrador (modo manual: como antes) — usado por `pastaDoCliente` (documentos, prints, relatório, sem cadastro, sem deferido), Caixa Postal e prints de erro 500/10000; `certificado-selecionar` com `exato`. **Ajudante 1.4:** `orq-atual` devolve `pastaCertificado` (validada) e `certificadoExato`; `Escolher-Certificados` (exato = nome inteiro, normalizado; sem exato = trecho, como antes); `Caminho-Livre` aceita `Documentos_arrecadacao/<CERT>/<CNPJ>`. Documentos antigos (`Documentos_arrecadacao\<CNPJ>`) ficam onde estão. **Validado:** autoteste da interface (`Automacao_PGFN.exe --autoteste <arquivo>`: DV, lista, repetidos, pasta igual à do orquestrador, certificado exato x trecho x duplicados, gravar/ler); telas capturadas; botões Retomar/Parar clicados por automação; orquestrador sem Chrome (execucao.json, atual com pasta/exato, 2ª execução recusada, pausa, retomada, parada, andamento próprio, andamento antigo intocado); ajudante 1.4 (orq-atual, escolha exata real); janela "Salvar como" real na pasta do certificado (6 cenários); simulador SISPAR com orquestrador: PDFs e prints em `CERT_TESTE_A\<CNPJ>`; regressão node; instalador `-SoVerificar`; pacote v0.32.0 sem dados de clientes. **Não testado:** execução real no e-CAC pela interface (só 1 certificado neste computador) |
| **ATM_PGFN** (09/11 ~16:30) | **Pasta de distribuição** `Downloads\ATM_PGFN` (cópia; `Auto_PGFN` intacta + `Downloads\Backup_Auto_PGFN_2026-11-09_1610.zip`) e `Downloads\ATM_PGFN.zip` (21 arquivos, sem dados). Estrutura: `Interface\` (exe + .cs + compilar.bat; o exe acha a raiz subindo um nível), `Automacao\` (orquestrador.ps1; logs/atual/sinal), `Extensao_Chrome\`, `Ajudante_Windows\`, `Configuracoes\`, `Instalador\` (instalar.ps1, gerar_pacote.ps1), `Instalar.bat`, `Iniciar.bat`, `README.md`. Mudanças só de caminho: subpasta dos downloads `ATM_PGFN/Documentos_arrecadacao` (content.js `PASTA_DOCUMENTOS`; ajudante `$RAIZ`), ajudante lê `..\Automacao`, orquestrador lê `..\Ajudante_Windows\ajudante.log`, interface `Automacao`/`Configuracoes` e saída = pasta de downloads do Chrome + `ATM_PGFN\Documentos_arrecadacao`; instalador não exige mais Downloads; `CNPJS_TESTE = []`; testes sem dados de clientes. **Pendente:** neste computador o ajudante registrado e a extensão carregada ainda são os da `Auto_PGFN` — para usar a ATM: remover a extensão antiga, carregar `ATM_PGFN\Extensao_Chrome` (ID novo), rodar `ATM_PGFN\Instalar.bat`. Comunicação extensão↔ajudante pelo Chrome com a ATM ainda não testada (precisa desse passo manual) |
| **0.33.0** (+ ajudante **1.5**) | **Vigia de travamentos e retomada.** Investigação (09/11): travamentos reais do dia já corrigidos antes (10:59 0.29.2; 11:16 0.30.x; 14:2x 0.31.0; 17:12 log ocupado derrubava o orquestrador → `Log` com repetição/`AppendAllText`, `Gravar-Json` com repetição, `catch` que registra erro). Faltava: vigia só com 30 min "sem sinal" e depois pulava o CNPJ; sinal só por etapa; prints repetidos "(1)" na retomada; registro de PDFs só no Chrome. **content.js:** `mostrarAviso` → `registrarProgresso` (texto mudou, no máx. a cada 15 s) → `orq-progresso` com checkpoint (certificado, CNPJ, etapa, conta, parcela, fase, PDFs salvos); `printJaSalvo`/`hojeIso`: print de confirmação com chave dia+situação (verificadas, com documento, pendentes) e prints simples (sem cadastro/sem deferido/sem parcelamento) por dia — não salva de novo se já salvo e ainda no disco; `CNPJS_TESTE = []`. **background:** `orq-progresso`; `registro-ver` cai para o disco se o Chrome não tiver; `registro-gravar` grava nos dois. **Ajudante 1.5:** `orq-progresso` → `progresso.json`; `registro-ver/gravar` → `registro_salvos.json` (mutex `Local\pgfn_registro_salvos`); `cancelar-todas`. **Orquestrador:** `-MinutosTravamento` (8; ou `minutosTravamento` na configuração), `-SegundosRecuperacao` (90), `-RecuperacoesMax` (3), `-ChromeSimulado` (teste); progresso = sinal ou progresso.json da sessão; pausa para você (aguardando_humano sem progresso novo, ou aviso "PAUSA") não conta; travou → 1º `Tratar-Janelas-Salvar` (janelas → cancelar-todas) e espera; senão "[travamento]" → Chrome reaberto no MESMO CNPJ (Fechar-Chrome também fecha "Salvar como" antes); esgotou → PAUSA (`pausar.flag` com o motivo; Retomar = mesmo CNPJ de novo; Parar = encerra, CNPJ pendente) — vale também para "[lentidao]" (antes virava erro e seguia); checkpoint gravado no andamento. **Interface:** motivo da pausa e conta/parcela na etapa. **Validado:** orquestrador+ajudante reais com Chrome simulado (conclui; trava 1x → recupera; pausa de captcha 40 s com limite 15 s → sem falso alarme; trava com janela "Salvar como" REAL → fecha e segue sem reabrir; trava sempre → 2 recuperações → PAUSA → Retomar → PAUSA → Parar, CNPJ pendente) na Auto e na ATM; ajudante 1.5 (8 gravações simultâneas sem perda); background (registro do disco); simulador SISPAR (progresso com checkpoint; 2ª rodada sem emissão nem clique repetido; print com mesma situação não repetido); regressão node. **Não testado no e-CAC real.** |

### Problemas e soluções que vale lembrar
- **"Sessão encerrada / Acesso Expirado":** o token do SISPAR é de uso único. Nunca abrir o endereço duas vezes.
- **`.htm` salvo como documento:** o Chrome bloqueou o 2º download ("vários arquivos") e o atalho baixou a própria página `resultadoDarfInternet.jsf#`. Corrigido na 0.25.
- **Print e relatórios como "download":** o ouvinte de nomes respondia sem nome aos downloads da extensão. Corrigido na 0.21.
- **ERR_CERT_AUTHORITY_INVALID no e-CAC (06/11):** não era da automação. O certificado do site (SERPRO → GlobalSign Root R46) era válido no Windows; foi passageiro. Orientação: não clicar em "Avançadas".
- **Painel do navegador da conversa oculto:** os testes no simulador precisam de `resize_window 1280x800` em cada aba, senão a largura é 0 e nada fica "visível".

---

## 7. Execuções reais registradas (pastas existentes)

| CNPJ | Resultado nas pastas |
|---|---|
| 90000003000118 (SOLSERV) | PDF 11-2026 + 2 relatórios |
| 90000005000107 | `Sem_Deferido_90000005000107.pdf` (movido do Downloads) |
| 90000012000109 (INOVE) | relatório + print_confirmacao.png/pdf (prestação 0012 com ícone laranja) |
| 90000013000153 (VPA) | PDFs 10-2026 e 11-2026, relatório, print_confirmacao |
| 90000014000106 (ALFORGE) | PDFs + `.htm` (lixo da falha corrigida na 0.25; pode apagar) + relatório parcial + print |
| 90000015000142 (ALFOSERVICE) | PDF 11-2026, relatório, print_confirmacao |
| 90000016000197 | `sem_cadastro_regularize.pdf` |
| 90000017000131, 90000018000186, 90000019000120 | print "sem parcelamento" (`CNPJ;NOME.pdf`) |
| 90000006000151 (PE MOBILIDADE) | **09/11 08:04–08:07**: 4 PDFs, relatório, 2 prints de confirmação. O `ajudante.log` mostra a janela "Salvar como" **confirmada pelo ajudante sem clique manual** nos 4 documentos |

Fora das pastas (não são da automação): `Downloads\7172630933066053.pdf` (DARF da INOVE baixado à mão em 05/11) e `Downloads\download (2).pdf` (print da extensão antiga).

---

## 8. Onde paramos exatamente (09/11/2026, 08:52–09:00)

1. O usuário autorizou ("Pode iniciar") o teste real do orquestrador com o CERT_A e o CNPJ 90000006000151.
2. O orquestrador fechou todo o Chrome (23 processos) e abriu a janela anônima em `https://cav.receita.fazenda.gov.br/autenticacao`.
3. **A extensão não iniciou o login nessa página:** nenhum aviso apareceu e o ajudante não recebeu o pedido `orq-atual`.
4. **Diagnóstico até aqui:**
   - **Sem bloqueio:** não há política do Chrome que bloqueie, o registro HKCU existe e o manifesto do host é válido.
   - **O background 0.28 está carregado:** depois de reiniciar o Chrome, às **08:58:52** o `ajudante.log` registrou um pedido `versao` (o ajudante respondeu "1.2"). Só o código novo faz essa chamada ao iniciar. Logo, o Chrome **consegue** chamar o ajudante. Isso corrige a hipótese, dita ao usuário, de "versão antiga carregada".
   - **O que falhou:** o **content script na página de login** não chegou a chamar `orq-atual`.
     - Nesse teste, `atual.json` existia, com PID de um processo vivo de diagnóstico.
     - O aviso novo "login automático desligado…" também não foi visto pela leitura via acessibilidade.
     - Hipóteses: o content script não rodou ou parou antes nessa página; ou o aviso existe, mas não foi lido.
   - **`chamadas.log`** (eco no `.bat`) ficou com **0 bytes**, embora criado às 08:58:51. O `echo` com `%*` provavelmente falhou por causa dos argumentos do Chrome. Não é confiável; usar o `ajudante.log`.
5. **Estado deixado:**
   - **Orquestrador:** parado. O processo de diagnóstico foi encerrado e `atual.json`/`sinal.json` foram apagados.
   - **`andamento.json`:** 90000006000151 = "em_andamento", tentativa 1. Não é final, então será reprocessado.
   - **Chrome:** aberto com a janela anônima do login, uma busca do Google "lchrome://extensions…" (tentativa fracassada de digitar na barra) e uma "Nova guia".
   - **Pedido ao usuário:** "Recarregar" a extensão em `chrome://extensions` e avisar. Ainda sem resposta.
6. **Nenhum documento foi baixado ou salvo** nesse teste.

---

## 9. Próximos passos (ordem sugerida)

1. **Primeira ação na nova conversa:** descobrir por que `fluxoLogin()` não rodou em `cav…/autenticacao`.
   - **Console da página:** pedir ao usuário para abrir F12 → Console na página de login e procurar `[Automação_PGFN]` ou erros; ver também os erros da extensão em `chrome://extensions`.
   - **Conferir no código:**
     - a página real pode estar em `/autenticacao/` com redirecionamento (o caminho tem de começar com `/autenticacao`);
     - o content script pode estar saindo antes do IIFE final, por alguma exceção no carregamento só nessa página;
     - a ordem de declaração de `NA_LOGIN_ECAC`/`NO_SSO` em relação ao IIFE;
     - se `mensagem({tipo:'orq-atual'})` responde.
   - **Cuidado:** o aviso fica num `div` com `pointer-events:none`; a leitura via acessibilidade pode não enxergá-lo. Confirmar com print do usuário.
2. **Depois de corrigir:** pedir para recarregar a extensão e rodar `orquestrador\iniciar_orquestrador.bat` com o CERT_A e 1 CNPJ. Acompanhar `orquestrador.log` e `ajudante.log`.
3. **Login real por partes:**
   - o hCaptcha invisível do botão "Entrar com gov.br" aceita o clique simulado? Se aparecer desafio, a automação pausa;
   - o clique em "Seu certificado digital" no gov.br real;
   - a escolha do CERT_A com **OK** de verdade.
4. **Conferir o fim:** a extensão envia "concluido", o orquestrador fecha o Chrome e passa ao próximo. Testar com 2 CNPJs do CERT_A.
5. **Listas definitivas:** receber do usuário as listas de CNPJs e outros certificados e preencher `cnpjs.json`.
6. **Limpezas opcionais, pedindo antes:**
   - `chamadas.log` e o eco no `salvar_como.bat`;
   - o `.htm` na pasta 90000014000106;
   - mover `7172630933066053.pdf` para a pasta 90000012000109 (não foi pedido).

### Dúvidas técnicas em aberto
- O hCaptcha invisível do e-CAC aceita o clique simulado da extensão? (Não testado.)
- Certificado A3 (token) pede PIN numa janela do Windows: a automação pausa e não digita nada. Por enquanto só A1 foi visto.
- O gov.br pode pedir autorização ou 2 fatores em algum caso: pausa prevista.
- Com o Chrome fechado à força, o perfil normal mostra "restaurar páginas"; não afeta o anônimo.
- Durante a escolha do certificado, o ajudante usa o **mouse do Windows**: o usuário não deve mexer no mouse nesses segundos.

---

## 10. Como testar (para a próxima conversa)

- **Simulador** (se a pasta temporária ainda existir; senão, recriar pelos mesmos princípios):
  - iniciar com `node server.js`;
  - URLs: `http://localhost:8765/?limpar=1&perfil=A` (e-CAC), `/regularize`, `/sisparnet?docres=com`, `/autenticacao` e `/sso` (login);
  - parâmetros: `nodef=1`, `falha1=1`, `cadastro=1`, `notif=1`, `avisoecac=1`, `captcha=1`.
  - O `server.js` acelera os tempos e troca os testes de domínio por caminhos.
- **Testes do service worker:** `node teste_background.js`, `teste_downloads.js`, `teste_proximo.js` e `teste_ajudante.js`.
- **Ajudante direto:** `chamar.js <bat> <arquivo.json>` fala o protocolo do Chrome (4 bytes de tamanho + JSON).
- **Janela de certificado sem login:** Chrome com `--user-data-dir=<pasta temporária> --incognito https://certificado.sso.acesso.gov.br/`, com o ajudante em `teste:true`, que termina em Cancelar.
- **Nunca** ler conteúdo de outras janelas do usuário (ex.: WhatsApp). Filtrar sempre por título ou processo do Chrome de teste.

---

## 11. Imagens enviadas pelo usuário (referência)

As imagens ficam numa pasta temporária da conversa (`%TEMP%\claude\…\images\`, de `6.png` a `77.webp`) e **não passam automaticamente para outra conversa**. As que importam para continuar estão marcadas com **⭐**; reenvie-as se for preciso rever a tela.

**Fase e-CAC e Regularize (imagens 6–53, antes do resumo da conversa):**
- tela inicial do e-CAC e cabeçalho Titular/Procurador;
- janela "Alterar perfil de acesso" e campo "Procurador de pessoa jurídica - CNPJ";
- bloco "Dívida Ativa da União" e opção "PGFN - Todos os serviços do Regularize";
- aviso "Atenção! CIENTE" do Regularize, cartão "NEGOCIAR DÍVIDA" e bloco "Acesso ao Sistema de Negociações" com ACESSAR;
- Sistema de Negociações (CONSULTAR) e aviso do SISPAR (CONTINUAR/DESISTIR);
- erro "Sessão encerrada";
- menu "Emissão de Documento" → "Documento de arrecadação";
- mensagem "Não foram encontradas solicitações…";
- tabela de negociações e coluna "Situação da conta".

**Daí em diante:**

| Imagem | O que mostra | Uso |
|---|---|---|
| 54–55 | página da negociação: "Dados da Negociações" e tabela "Prestação" com a coluna "Emissão" (verificados), aviso de cookies | análise da coluna Emissão (0.15) |
| 56–58 | janela "Cálculo e demonstrativo…" (Parcela 55, Voltar/Emitir), botão Emitir, página `resultadoDarfInternet.jsf` com o link do PDF | fluxo de emissão (0.16) |
| 59–60 | janela "Salvar como" na pasta `Documentos_arrecadacao\90000003000118` com o nome preenchido | Salvar como (0.17) |
| 61 | aviso do e-CAC "Prepare-se para a evolução…" (Continuar no e-CAC por enquanto) | 0.17 |
| 62 | e-CAC: painel "Dívida Ativa" sem "PGFN - Todos os serviços do Regularize" + erro da automação | pular CNPJ (0.18) |
| 63 ⭐ | tabela do 90.000.005/0001-07 sem "DEFERIDA E CONSOLIDADA" | Sem_Deferido (0.19) |
| 64 | aviso "Fique atento: novas notificações… VER AGORA / FECHAR" | 0.20 |
| 65 | Explorer: `Documentos_arrecadacao` só com a pasta 90000003000118 | organização por CNPJ (0.21) |
| 66 ⭐ | tela "Prestação" (para o print de confirmação) | 0.22 |
| 67 | pasta 90000012000109 com relatório e print_confirmacao.png | PDF + ícone laranja (0.23) |
| 68 | "Salvar como" na pasta 90000013000153 (VPA) aguardando | ajudante (0.24) |
| 69–71 ⭐ | "Salvar como" na pasta 90000014000106; lista de downloads com o `.htm`; aviso "fazer o download de vários arquivos" | 0.25 |
| 72 | "Salvar como" na pasta 90000015000142 parado em "Conferindo…" | correção do Tipo (0.26) |
| 73 | "Sua conexão não é particular" (ERR_CERT_AUTHORITY_INVALID) no e-CAC | diagnóstico: não era da automação |
| 74 ⭐ | Regularize "Criar Cadastro" / "Você ainda não está cadastrado no REGULARIZE" | 0.27 |
| 75–76 ⭐ | página de login do e-CAC (`cav.receita.fazenda.gov.br/autenticacao/login`) com "Entrar com gov.br" | login automático (0.28) |
| 77 ⭐ | gov.br com a janela "Selecione um certificado" (CORRETA e CERT_A) | seleção de certificado (0.28) |

---

## 12. Como começar a próxima conversa

Mensagem sugerida:
> "Quero continuar a automação PGFN. Leia `C:\Users\PANORAMA-PC\Downloads\Auto_PGFN\CONTINUIDADE_AUTOMACAO_PGFN.md` e o `README.md` da mesma pasta. Estamos na versão 0.28.0, no teste real do orquestrador: o login automático não disparou na página do e-CAC."

Se possível, anexe também:
- print da página de login com o **Console (F12)** aberto;
- print de `chrome://extensions` mostrando a versão e eventuais erros da Automação_PGFN.
