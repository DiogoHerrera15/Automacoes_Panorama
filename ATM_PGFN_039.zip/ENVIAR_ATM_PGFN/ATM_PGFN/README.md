# Automação PGFN (ATM_PGFN)

Para cada CNPJ da sua lista, a automação:

1. entra no **e-CAC** com o seu **certificado digital**;
2. troca o perfil para o CNPJ;
3. abre o **Regularize** e o **SISPAR**;
4. confere as negociações **"DEFERIDA E CONSOLIDADA"**;
5. emite e salva os **documentos de arrecadação** pendentes, com prints de conferência e um relatório.

Tudo fica organizado por **certificado** e por **CNPJ**.

Funciona sozinha no Windows. Precisa só do Google Chrome e não depende do Claude nem de internet além dos sites da Receita e da PGFN.

---

## A. Instalação (uma vez em cada computador)

### 1. O que é preciso

| Item | Observação |
|---|---|
| Windows 10 ou 11 | Já traz o PowerShell e o .NET Framework 4, que a automação usa. Não é preciso instalar mais nada. |
| Google Chrome | Instalado normalmente. |
| Certificado digital A1 | Instalado no Windows, e o mesmo que aparece no Chrome quando você entra no e-CAC com certificado. Certificado A3 (token ou cartão) também funciona, desde que esteja conectado. |

Não é preciso ser administrador do computador.

### 2. Copiar a pasta

1. Copie o arquivo **`ATM_PGFN.zip`** para o computador.
2. Clique com o botão direito nele > **Extrair tudo…** e extraia na pasta **Downloads**. Vai ficar `Downloads\ATM_PGFN`.
   - Pode ficar em outra pasta, mas em Downloads os documentos gerados ficam junto da automação (veja a seção C).
3. Não renomeie as pastas de dentro de `ATM_PGFN`.

### 3. Rodar a instalação inicial

Dê dois cliques em **`Instalar.bat`**. Uma janela preta mostra cada passo:

- confere as pastas e o Chrome;
- mostra onde os documentos serão salvos;
- guia a instalação da extensão (item 4 abaixo);
- registra o ajudante do Windows e testa a comunicação;
- oferece criar o atalho **"Automação PGFN"** na Área de Trabalho.

Linhas em **verde (OK)** estão certas. Em **amarelo (!!)** ou **vermelho (XX)**, veja a seção D.

### 4. Instalar e ativar a extensão no Chrome

O `Instalar.bat` abre o Chrome e a pasta da extensão para você. No Chrome:

1. Na barra de endereço, abra **`chrome://extensions`**.
2. Ligue **"Modo do desenvolvedor"**, no canto superior direito.
3. Clique em **"Carregar sem compactação"**.
4. Escolha a pasta **`ATM_PGFN\Extensao_Chrome`** (a pasta que tem o arquivo `manifest.json`).
5. A extensão **Automação_PGFN** aparece na lista. Confira se a chave dela está **ligada (azul)**.
6. Clique em **"Detalhes"** e ligue **"Permitir no modo anônimo"**. Isso é obrigatório, porque a automação trabalha numa janela anônima.
7. Se existir **outra cópia antiga** da extensão Automação_PGFN, clique em **"Remover"** nela. Duas cópias ao mesmo tempo atrapalham.
8. Volte à janela do `Instalar.bat` e tecle **Enter**.

### 5. Ajudante do Windows (comunicação com a extensão)

O ajudante é um pequeno programa da pasta `Ajudante_Windows` que o Chrome chama sozinho. Ele:

- escolhe o certificado configurado na janela do Chrome;
- confirma a janela "Salvar como" na pasta certa e confere se o PDF foi salvo;
- passa à extensão o CNPJ da vez.

O `Instalar.bat` faz tudo isso:

- registra o ajudante para a sua extensão;
- testa a comunicação: aparece **`OK  ajudante respondeu: {"versao":"1.9","ok":true}`** (versão atual: extensão **0.39.0**, ajudante **1.9**).

Para conferir de novo a qualquer momento, sem mudar nada, rode no PowerShell:

```
powershell -ExecutionPolicy Bypass -File Instalador\instalar.ps1 -SoVerificar
```

Se você **mover a pasta ATM_PGFN** para outro lugar, rode o `Instalar.bat` de novo e carregue a extensão da nova pasta.

---

## B. Como usar a interface

### 1. Abrir

Dê dois cliques em **`Iniciar.bat`** ou no atalho **"Automação PGFN"** da Área de Trabalho.

### 2. Certificado digital

1. Clique em **"Nova"** e dê um nome à configuração (exemplo: `Clientes do certificado A`).
2. Em **"Certificado digital"**, escolha o certificado na lista.
   - A lista mostra os certificados instalados no Windows, com o nome exatamente como o Chrome mostra e a validade.
   - Se o certificado não aparecer, clique em **"Atualizar lista"** e veja a seção D.
3. Logo abaixo aparece a pasta onde os documentos desse certificado serão salvos.

A automação usa **só** o certificado com exatamente esse nome. Nunca escolhe outro parecido.

### 3. CNPJs: adicionar, editar e remover

- **Adicionar:** cole ou digite no quadro **"CNPJs"**, **um por linha**, com ou sem pontos, barra e traço.
- **Editar:** corrija direto no quadro.
- **Remover:** apague a linha.
- **"Validar e organizar":**
  - confere os dígitos verificadores;
  - remove CNPJs repetidos;
  - coloca os **inválidos no topo**, em vermelho, para você corrigir.

### 4. Salvar

Clique em **"Salvar configuração"**. Ela fica na lista **"Configurações salvas"**, à esquerda.

Você pode ter várias configurações, por exemplo uma por certificado ou por grupo de clientes. Para usar uma, clique nela na lista. Para apagar, use **"Excluir"**; os documentos já salvos **não** são apagados.

### 5. Iniciar

1. **Antes de iniciar:**
   - salve e feche o que estiver usando no Chrome, porque a automação fecha e reabre o Chrome a cada CNPJ;
   - não use o Chrome enquanto a automação roda.
2. Escolha a configuração e clique em **"▶ Iniciar"**.
3. A interface confere se o certificado existe no Windows com esse nome exato:
   - se não existir ou estiver vencido, a execução **não começa**;
   - se houver dois certificados com o mesmo nome, ela pede confirmação.
4. Confirme. A janela do **orquestrador**, que controla a execução, abre minimizada na barra de tarefas. Não a feche.

**Durante a execução:**

- **Captcha:** resolva na tela; a automação continua sozinha.
- **Mouse:** não mexa enquanto o certificado é escolhido (são alguns segundos).
- **Pausa:** se aparecer um aviso vermelho com **"PAUSA"** no canto da página, a automação está esperando você fazer o que o aviso pede.

### 6. Acompanhar o progresso e os logs

A parte **"Execução"** da interface mostra, atualizando a cada 2 segundos:

- certificado e CNPJ em processamento (por exemplo, `3 de 20`);
- **contador:**
  - total de CNPJs, analisados e **percentual**, com uma barra de progresso;
  - **concluídos**, **com erro**, **sem procuração**, **procuração cancelada** e **aviso de Caixa Postal** (esses dois só aparecem quando houver) e **restantes**;
  - conta cada CNPJ uma vez só; uma nova tentativa do mesmo CNPJ não conta de novo;
  - vem do andamento salvo no disco, então continua certo se a automação ou o computador for reiniciado;
- etapa atual (o que a automação está fazendo agora);
- o **registro (log)** completo, também gravado em `Automacao\orquestrador.log`. Depois de cada CNPJ o log ganha uma linha `PROGRESSO: X de N analisados (P%) | concluídos … | com erro … | sem procuração … | restantes …`.

**Quando a lista termina:** a interface mostra **"TERMINADA em …"** com o resumo, e a página do e-CAC avisa **"AUTOMAÇÃO TERMINADA"**, sem nada travado. Pode fechar o Chrome. Se a execução foi parada antes do fim, a interface mostra **"Parada …"**; clique em **Iniciar** para continuar de onde parou.

### 7. Pausar, retomar e encerrar

| Botão | O que faz |
|---|---|
| **Pausar** | O CNPJ atual termina normalmente e o **próximo** espera. |
| **Retomar** | Continua a partir do próximo CNPJ. |
| **Parar após o CNPJ atual** | Encerra depois do CNPJ em processamento; os demais ficam pendentes. |
| Fechar o Chrome | Para na hora; o CNPJ da vez volta a pendente. |
| **Refazer sem procuração** | Volta para pendente só os CNPJs marcados como "sem procuração", "procuração cancelada" ou "aviso de Caixa Postal". Use depois de criar ou renovar a procuração eletrônica no e-CAC, ou depois de ler as mensagens da Caixa Postal. Guarda uma cópia do andamento antes; os outros CNPJs não mudam. Só fica ativo sem execução em andamento. |
| **Nova rodada (zerar andamento)** | Todos os CNPJs voltam a pendente. Use, por exemplo, no mês seguinte. Documentos já salvos não são apagados, e documento já emitido no mês não é emitido de novo. |

Clicar em **"Iniciar"** de novo **continua de onde parou**: os CNPJs concluídos, os "sem procuração", os "procuração cancelada" e os "aviso de Caixa Postal" não se repetem; os pendentes e os com erro são feitos de novo.

### 8. Onde ficam os documentos

Clique em **"Abrir pasta dos documentos"**, ou veja a seção C.

---

## C. Organização dos arquivos

Os resultados são organizados **automaticamente** por certificado e CNPJ, dentro do **diretório de saída**:

```
<pasta de downloads do Chrome>\ATM_PGFN\Documentos_arrecadacao\
   NOME_DO_CERTIFICADO_A\
      12345678000195\
         12345678000195;EMPRESA;11-2026.pdf         (documento de arrecadação)
         print_confirmacao_conta_1234567.pdf        (print de conferência)
         12345678000195;EMPRESA;relatorio ....csv   (relatório, abre no Excel)
         Caixa_Postal_12345678000195.pdf            (print do aviso de mensagens na Caixa Postal)
         Erro_500_12345678000195.pdf                (se o e-CAC falhar)
         Sem_Procuracao_12345678000195.pdf          (se o certificado não tiver procuração do CNPJ)
         Procuracao_Cancelada\
            Procuracao_Cancelada_12345678000195.pdf (se a procuração do CNPJ foi cancelada)
         Falha_Salvamento_12345678000195_conta_..._prest_....pdf  (evidência: PDF não salvo depois de 3 tentativas)
   NOME_DO_CERTIFICADO_B\
      ...
```

- **Sempre por certificado:** cada CNPJ fica dentro da pasta do **seu** certificado (`Certificado → CNPJ → documentos`), também com configurações antigas.
- **Relatório `.csv`:** é uma planilha em texto, separada por ponto e vírgula. Abre como planilha no Excel ou no LibreOffice; se o computador não tiver nenhum dos dois, abre como texto (Bloco de Notas, VS Code).

- **Onde fica o diretório de saída:** dentro da pasta de downloads do Chrome, porque o Chrome só salva lá dentro. Normalmente é `Downloads`. Com a `ATM_PGFN` em Downloads, os documentos ficam em `Downloads\ATM_PGFN\Documentos_arrecadacao`, junto da automação.
- **Nada é sobrescrito:** um arquivo com o mesmo nome recebe "(1)".
- **Sem emissão repetida:** a automação não emite de novo um documento que já salvou no mesmo mês.

### Pastas da ATM_PGFN

| Pasta / arquivo | Conteúdo |
|---|---|
| `Iniciar.bat` | Abre a interface. |
| `Instalar.bat` | Instalação guiada; pode rodar de novo, não apaga nada. |
| `Interface\` | A interface (`Automacao_PGFN.exe`), o código dela e o `compilar.bat`, que a refaz se precisar. |
| `Automacao\` | Orquestrador, que controla os CNPJs um a um, e o registro `orquestrador.log`. |
| `Extensao_Chrome\` | A extensão do Chrome. |
| `Ajudante_Windows\` | Ajudante do Windows e o registro `ajudante.log`. |
| `Configuracoes\` | Suas configurações e o andamento de cada uma. |
| `Instalador\` | Instalador e `gerar_pacote.ps1`, que gera um novo `ATM_PGFN.zip` sem dados de clientes. |

A automação **não guarda** senha, PIN, chave privada nem cópia do certificado: só o **nome** dele.

---

## D. Solução de problemas

### Extensão não detectada

- **Reconferir:** rode o `Instalar.bat`. Ele diz se a extensão foi carregada **desta** pasta.
- **No `chrome://extensions`:**
  - a extensão tem que estar **ligada**, carregada da pasta `ATM_PGFN\Extensao_Chrome`;
  - **"Permitir no modo anônimo"** tem que estar ligado;
  - não pode haver outra cópia antiga.
- **Depois de copiar uma versão nova** da pasta: clique em **"Recarregar"** (seta circular) na extensão.

### Ajudante do Windows sem comunicação

- **Aviso:** a página mostra "ajudante do Windows não respondeu", ou o login automático não começa.
- **Resolver:**
  1. Rode o `Instalar.bat`. No passo 4 deve aparecer `ajudante respondeu`.
  2. Se a pasta foi movida, rode o `Instalar.bat` de novo, porque o registro aponta para a pasta antiga.
  3. Recarregue a extensão em `chrome://extensions`.
- **Registro:** cada conversa com o ajudante fica em `Ajudante_Windows\ajudante.log`.

### Certificado não encontrado

- **A interface só lista** certificados pessoais com chave privada e uso "Autenticação de Cliente":
  - **A1:** confira se ele foi instalado para o **seu usuário** do Windows;
  - **A3:** conecte o token ou cartão e clique em **"Atualizar lista"**.
- **Vencido:** se o certificado aparece como **vencido**, a execução não começa. Renove-o.
- **Dois certificados com o mesmo nome:** a automação **pausa** na janela "Selecione um certificado" para você escolher qual usar.
- **Lista com barra de rolagem (muitos certificados):** a janela do Chrome mostra poucas linhas por vez. Desde a versão 0.38.0 a automação percorre a lista **inteira**: vai à primeira linha e desce uma por uma, com o teclado, até a última, lendo o nome completo mesmo quando aparece cortado na coluna "Tema".
  - **Um único com o nome configurado:** ela o seleciona, confere a seleção e clica em **OK**.
  - **Nenhum ou mais de um:** ela **pausa**, informa quantos certificados leu e o motivo, e espera você escolher.
  - O certificado que o Chrome destaca primeiro só é confirmado se for o configurado.
  - Não mexa no mouse nem no teclado enquanto a janela de certificados estiver aberta (são poucos segundos).

### Falhas no login do e-CAC

- **Captcha, PIN ou senha:** a automação pausa e espera você; ela **nunca** digita PIN ou senha.
- **Erro 93003** ("número máximo de dispositivos conectados"): a automação espera e tenta 3 vezes; depois pausa. Saia do e-CAC ("Sair com Segurança") em outros navegadores ou computadores.
- **Erro 500** ("erro interno na aplicação"): até 5 tentativas com espera crescente; depois salva `Erro_500_<CNPJ>.pdf` e segue. O CNPJ fica para a próxima execução.
- **Erro 10000** ("não foi possível validar os seus dados"): salva `Problema_receita_federal_<CNPJ>.pdf` e segue para o próximo CNPJ.
- **"Não existe procuração eletrônica"** (na troca de perfil): não é lentidão, e recarregar não resolve. A automação:
  1. salva o print `Sem_Procuracao_<CNPJ>.pdf` **com a mensagem na tela** em `Documentos_arrecadacao\<pasta do certificado>\<CNPJ>\` e confere o arquivo no disco (se a mensagem já tiver sumido, não salva um print sem ela e avisa no log);
  2. fecha a janela "Alterar perfil de acesso" pelo X;
  3. sai do e-CAC com **"Sair com Segurança"** e confere a saída (até 2 tentativas; o log registra "Sessão do e-CAC: encerrada" ou "não confirmada");
  4. marca o CNPJ como **sem procuração** e segue para o próximo. Ele não é tentado de novo.

  Depois de criar a procuração no e-CAC, use o botão **"Refazer sem procuração"** e clique em **Iniciar**.
- **"A procuração eletrônica … foi cancelada em <data>"** (na troca de perfil): é diferente da falta de procuração. A automação:
  1. confere que o campo "Procurador de pessoa jurídica - CNPJ" tem o CNPJ da vez (se não tiver, não salva o print e não classifica: o CNPJ fica com erro e é refeito na próxima execução);
  2. salva o print com a mensagem, a data e o CNPJ na tela em `Documentos_arrecadacao\<pasta do certificado>\<CNPJ>\Procuracao_Cancelada\Procuracao_Cancelada_<CNPJ>.pdf` e confere o arquivo no disco;
  3. fecha a janela pelo X e sai do e-CAC com **"Sair com Segurança"**;
  4. marca o CNPJ como **"Pendente por procuração cancelada"** (contador "Procuração cancelada") e segue para o próximo. Ele não é tentado de novo sozinho.

  Depois de renovar a procuração no e-CAC, use **"Refazer sem procuração"** e clique em **Iniciar**.
- **Aviso de Caixa Postal** ("Você possui mensagens importantes … ainda não lidas na sua Caixa Postal"). Desde a versão 0.39.0 a automação **não clica** em "Ir para a Caixa Postal" nem abre mensagens. Ela:
  1. confere que o cabeçalho do e-CAC mostra o CNPJ em processamento;
  2. salva o print **com o aviso na tela** em `Documentos_arrecadacao\<pasta do certificado>\<CNPJ>\Caixa_Postal_<CNPJ>.pdf` e confere o arquivo no disco. Se não conseguir salvar depois de 3 tentativas, o CNPJ fica **com erro** (falha de salvamento) e é refeito na próxima execução;
  3. sai do e-CAC com **"Sair com Segurança"**;
  4. marca o CNPJ como **"Aviso de Caixa Postal"** (contador próprio), encerra a análise dele e segue para o próximo. Ele não é tentado de novo sozinho.

  Se o aviso for de **outro perfil** (por exemplo, do titular do certificado, antes da troca para o CNPJ) ou o cabeçalho não puder ser lido, a automação **não salva** (a pasta seria a errada) e **pausa** até você resolver e voltar à página inicial do e-CAC.

  Depois de ler as mensagens na Caixa Postal, use **"Refazer sem procuração"** e clique em **Iniciar**.

### "Você não tem permissão de acesso ou ele expirou" (SISPAR)

O acesso ao sistema de parcelamento expirou ou se perdeu, e recarregar a página não resolve. A automação reconhece a mensagem e registra no log o certificado, o CNPJ, a conta e a etapa. Em seguida, ela:

1. salva o relatório parcial;
2. sai do e-CAC com "Sair com Segurança";
3. reabre o Chrome e refaz o **mesmo CNPJ**, até 3 vezes, sem emitir de novo os PDFs já salvos.

Se o erro continuar nas 3 tentativas, o CNPJ fica **com erro** (pendente, refeito no próximo Iniciar) e a automação segue para o próximo, sem pausar.

Se a página de acesso do e-CAC abrir **sem o botão "Entrar com gov.br"**, a automação recarrega a página 1 vez. Continuando sem o botão, ela reabre o Chrome no mesmo CNPJ. Captcha continua sendo com você.

**Não recarregue a extensão com a automação rodando:** as abas abertas param de funcionar. Recarregue só com a automação parada.

### Travamentos em downloads e salvamentos

- **Janela "Salvar como" aberta:** o ajudante confere a pasta e o nome, corrige se precisar e clica em "Salvar", com até 3 tentativas. Se não conseguir, fecha a janela e clica no link do PDF de novo, também até 3 vezes.
- **PDF certo:** a automação só aceita o PDF **desta** prestação (nome pedido ou número do documento, na pasta do CNPJ, começando com `%PDF`). Um print de conferência ou o documento de outra conta **nunca** conta como o documento. Antes de clicar de novo no link, ela procura o PDF na pasta do CNPJ, para não baixar repetido.
- **Tentativas esgotadas (desde a 0.35.0):** a automação **não fica pausada**. Ela:
  1. salva o print `Falha_Salvamento_<CNPJ>_conta_<conta>_prest_<prestação>.pdf` na pasta do CNPJ;
  2. registra a conta, a prestação e o motivo no log e no relatório ("PENDENTE - documento NÃO baixado");
  3. fecha só a janela "Salvar como" desse documento, sai do e-CAC com "Sair com Segurança" e segue para o **próximo CNPJ**.

  O CNPJ fica **com erro** (pendente) e é refeito no próximo **Iniciar**, sem emitir de novo os PDFs que já foram salvos. Sem a interface (extensão sozinha), continua a pausa para você salvar à mão.
- **Evitar a janela "Salvar como":** em `chrome://settings/downloads`, desligue **"Perguntar onde salvar cada arquivo antes de fazer download"**.
- **Aviso "fazer download de vários arquivos":** a automação libera isso sozinha, só para o site do SISPAR.

### A automação parou de avançar (travamento)

Ela se recupera sozinha; você não precisa fazer nada:

1. **Detecta:** se a extensão fica **8 minutos sem nenhum progresso** e não está esperando você (captcha, PAUSA), o orquestrador registra **"TRAVAMENTO"** no log, com o ponto exato: CNPJ, conta, parcela e PDFs já salvos.
2. **Janela "Salvar como":** primeiro confere se há uma aberta. Se houver, fecha de forma controlada e espera a automação seguir.
3. **Reabre o Chrome:** se não resolver, reabre o Chrome **no mesmo CNPJ**, até 3 vezes.
   - PDFs já salvos não são emitidos de novo.
   - Prints do mesmo dia, com a mesma situação na tela, não são repetidos.
4. **Pausa:** se ainda assim não andar, a automação **pausa** e mostra isso na interface. O CNPJ **não é pulado**. Clique em **Retomar** para tentar de novo, ou em **Parar**.

Pausas para você (captcha, PIN, Caixa Postal, cálculo, salvar à mão) **não** contam como travamento.

Para mudar os 8 minutos, coloque `"minutosTravamento": 10` no arquivo da configuração, dentro de `Configuracoes\`.

### Consultar os logs e retomar uma execução

- **Registro completo:** aparece na interface e fica em `Automacao\orquestrador.log`. Os registros do ajudante ficam em `Ajudante_Windows\ajudante.log`.
- **Situação de cada CNPJ:** fica em `Configuracoes\<nome>.andamento.json`; a interface mostra os totais.
- **Retomar:** abra a interface, escolha a mesma configuração e clique em **"Iniciar"**. A execução continua dos CNPJs pendentes e com erro; concluídos e sem procuração não se repetem.
- **Resumo da última execução:** fica em `Automacao\ultima_execucao.json`, mostrado na interface.

### Gerar o pacote para outro computador

Rode no PowerShell:

```
powershell -ExecutionPolicy Bypass -File Instalador\gerar_pacote.ps1
```

Isso gera `ATM_PGFN.zip` ao lado da pasta. O pacote leva só programas e documentação; ficam de fora:

- configurações;
- andamentos;
- registros;
- documentos.
