﻿# Orquestrador da Automação_PGFN: processa os CNPJs de cnpjs.json, um por vez, cada um num Chrome novo.
# Para cada CNPJ ainda não concluído:
#   1. espera não haver download em andamento e FECHA TODO O CHROME (todas as janelas e perfis; sem confirmação);
#   2. grava atual.json (CNPJ da vez, certificado, sessão) — a extensão lê por meio do ajudante do Windows;
#   3. abre o Chrome em janela ANÔNIMA no login do e-CAC; a extensão entra com o gov.br e o certificado configurado e
#      faz o fluxo de sempre (perfil, Regularize, SISPAR, emissões, prints), salvando na pasta do CNPJ;
#   4. acompanha o andamento (sinal.json) até "concluido" ou "erro" e grava em andamento.json.
# CNPJ concluído não é repetido nas próximas execuções; os com erro são tentados de novo.
# Captcha, PIN, senha ou confirmação de segurança: a extensão pausa ("aguardando_humano") e o orquestrador espera.
#
# Uso: pela interface (Iniciar.bat / Interface\Automacao_PGFN.exe); ou: powershell -ExecutionPolicy Bypass -File orquestrador.ps1 -Config <arquivo.json>
# Parâmetros de teste: -PerfilChrome <pasta> fecha/abre só um Chrome com esse perfil; -UrlInicial <endereço>.
#
# Interface (Automacao_PGFN.exe, desde 0.32.0): chama com -Config <configuração escolhida> -Andamento <andamento dela>.
# Cada grupo da configuração pode ter "pasta" (pasta do certificado dentro de Documentos_arrecadacao) e "exato": true
# (o certificado é escolhido só pelo nome inteiro, nunca por aproximação). Pausa/parada pedidas pela interface:
# pausar.flag (não começa o próximo CNPJ enquanto existir) e parar.flag (encerra depois do CNPJ atual).
param(
  [string]$Config = '',
  [Alias('Andamento')][string]$ArquivoAndamento = '', # (não pode se chamar $Andamento: colide com a tabela $andamento)
  [string]$UrlInicial = 'https://cav.receita.fazenda.gov.br/autenticacao',
  [string]$PerfilChrome = '',
  [int]$MinutosSemSinal = 30, # (antigo; o vigia de travamentos usa -MinutosTravamento)
  # Vigia de travamentos (0.33.0): sem progresso da extensão por este tempo (e sem pausa para você) = travamento.
  # Também configurável na configuração: "minutosTravamento".
  [double]$MinutosTravamento = 8,
  [double]$SegundosRecuperacao = 90, # depois de fechar uma janela "Salvar como" travada, espera isto pelo progresso
  [int]$RecuperacoesMax = 3,          # Chrome reaberto no MESMO CNPJ até este número; depois PAUSA (nunca pula o CNPJ)
  [string]$ChromeSimulado = '',       # teste: script que faz o papel do Chrome/extensão (escreve sinal/progresso)
  [switch]$SemChrome, # teste: não fecha/abre o Chrome (só a fila, pausa e parada)
  [switch]$SoMostrar
)
$ErrorActionPreference = 'Stop'
$AQUI = $PSScriptRoot
$BASE = Split-Path $AQUI -Parent
if (-not $Config) { $Config = Join-Path $BASE 'cnpjs.json' } # (modo antigo, sem a interface)
$ARQ_ATUAL = Join-Path $AQUI $(if ($SemChrome) { 'atual_teste.json' } else { 'atual.json' }) # teste: a extensão nunca vê
$ARQ_SINAL = Join-Path $AQUI 'sinal.json'
$ARQ_PROGRESSO = Join-Path $AQUI 'progresso.json' # última ação + checkpoint da extensão (vigia de travamentos)
$ARQ_ANDAMENTO = if ($ArquivoAndamento) { $ArquivoAndamento } else { Join-Path $AQUI 'andamento.json' }
$ARQ_PAUSAR = Join-Path $AQUI 'pausar.flag'
$ARQ_PARAR = Join-Path $AQUI 'parar.flag'
$ARQ_EXECUCAO = Join-Path $AQUI 'execucao.json'
# 0.33.1: como a última execução TERMINOU (lista terminada, parada, erro), com a contagem. A extensão (pelo ajudante) e a
# interface mostram isso; antes, no último CNPJ a tela ficava na página "Logout realizado" com o aviso "o orquestrador
# fecha o Chrome e segue", o que parecia um travamento (10/11/2026 09:19), mas a lista já tinha terminado.
$ARQ_ULTIMA = Join-Path $AQUI $(if ($SemChrome) { 'ultima_execucao_teste.json' } else { 'ultima_execucao.json' })
$ARQ_LOG = Join-Path $AQUI 'orquestrador.log'
# situações que não se repetem. 0.34.0: "sem_procuracao" (o e-CAC disse que o certificado não tem procuração eletrônica
# do CNPJ) também é final: antes era "erro" e voltava a cada Iniciar. Refazer: botão "Refazer sem procuração" da interface.
# 0.37.0: "procuracao_cancelada" (e-CAC: a procuração "foi cancelada em" uma data) = "Pendente por procuração cancelada":
# encerra a tentativa e não é refeito sozinho (só depois de renovar a procuração e clicar "Refazer sem procuração").
# 0.39.0: "caixa_postal" (aviso de mensagens importantes não lidas na Caixa Postal do e-CAC; print do aviso salvo) =
# "Aviso de Caixa Postal": encerra a análise do CNPJ e não é refeito sozinho (só com "Refazer sem procuração").
$FINAIS = @('concluido', 'sem_procuracao', 'procuracao_cancelada', 'caixa_postal')

# O registro NUNCA pode derrubar o orquestrador: em 09/11/2026 17:12 o arquivo do log estava ocupado por outro programa
# por um instante (antivírus/indexação/leitura), o Add-Content deu erro e o orquestrador fechou sem aviso no meio do
# login de um CNPJ; a extensão ficou sem o CNPJ da vez. Agora tenta de novo por até ~5 s e, se não der, segue sem a linha.
function Log($texto) {
  $linha = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + ' ' + $texto
  try { Write-Host $linha } catch { }
  for ($i = 0; $i -lt 25; $i++) {
    try { [IO.File]::AppendAllText($ARQ_LOG, $linha + "`r`n", (New-Object Text.UTF8Encoding $false)); return } catch { Start-Sleep -Milliseconds 200 }
  }
}
function Ler-Json($arq) { if (Test-Path -LiteralPath $arq) { return (Get-Content -LiteralPath $arq -Raw -Encoding UTF8 | ConvertFrom-Json) }; return $null }
function Gravar-Json($arq, $obj) {
  $tmp = "$arq.tmp"
  $texto = $obj | ConvertTo-Json -Depth 6
  # arquivo ocupado por um instante (interface lendo, antivírus): tenta de novo antes de desistir
  for ($i = 1; ; $i++) {
    try {
      [IO.File]::WriteAllText($tmp, $texto, (New-Object Text.UTF8Encoding $false))
      Move-Item -LiteralPath $tmp -Destination $arq -Force -ErrorAction Stop
      return
    } catch { if ($i -ge 25) { throw }; Start-Sleep -Milliseconds 200 }
  }
}

# ---- configuração ----
$cfg = Ler-Json $Config
if (-not $cfg -or -not $cfg.certificados) { throw "configuração não encontrada ou vazia: $Config" }
if ($cfg.PSObject.Properties['minutosTravamento'] -and [double]$cfg.minutosTravamento -gt 0) { $MinutosTravamento = [double]$cfg.minutosTravamento }
# Pasta do certificado: só letras sem acento, números, "_" e "-" (ex.: "EMPRESA_EXEMPLO_LTDA_11444777000161").
function Pasta-Certificado([string]$nome) {
  $s = $nome.Normalize([Text.NormalizationForm]::FormD) -replace '\p{Mn}', ''
  $s = ($s.ToUpper() -replace '[^A-Z0-9_-]+', '_').Trim('_', '-')
  if ($s.Length -gt 80) { $s = $s.Substring(0, 80).TrimEnd('_', '-') }
  return $s
}
$fila = @()
foreach ($g in $cfg.certificados) {
  $cert = [string]$g.certificado
  if (-not $cert.Trim()) { throw 'há um grupo sem "certificado" em cnpjs.json' }
  $pasta = ''
  if ($g.PSObject.Properties['pasta'] -and [string]$g.pasta) {
    $pasta = [string]$g.pasta
    if ($pasta -notmatch '^[A-Za-z0-9_-]{1,80}$') { throw "nome de pasta do certificado inválido: $pasta" }
  } else {
    # 0.34.1: sem "pasta" (cnpjs.json antigo, nome do certificado por trecho), os documentos iam para
    # Documentos_arrecadacao\<CNPJ>, fora da pasta do certificado. Agora sempre há pasta do certificado: se já existir
    # UMA pasta que começa com esse nome (ex.: trecho "CERTIFICADO EXEMPLO A" -> pasta
    # "CERTIFICADO_EXEMPLO_A_LTDA_90000001000129"), usa ela; senão, o nome do certificado convertido.
    $pasta = Pasta-Certificado $cert
    if (-not ($g.PSObject.Properties['exato'] -and $g.exato) -and $pasta) {
      $docs = Join-Path $env:USERPROFILE 'Downloads\Auto_PGFN\Documentos_arrecadacao'
      $ja = @(Get-ChildItem -LiteralPath $docs -Directory -ErrorAction SilentlyContinue |
              Where-Object { $_.Name -eq $pasta -or $_.Name.StartsWith($pasta + '_', [StringComparison]::OrdinalIgnoreCase) })
      if ($ja.Count -eq 1) { $pasta = $ja[0].Name }
    }
    if ($pasta -notmatch '^[A-Za-z0-9_-]{1,80}$') { $pasta = '' }
  }
  $exato = [bool]($g.PSObject.Properties['exato'] -and $g.exato)
  foreach ($c in $g.cnpjs) {
    $d = ([string]$c) -replace '\D', ''
    if ($d -notmatch '^\d{14}$') { throw "CNPJ inválido em cnpjs.json: $c" }
    $fila += [pscustomobject]@{ cnpj = $d; certificado = $cert; pasta = $pasta; exato = $exato }
  }
}
# andamento (hashtable cnpj -> registro)
$andamento = @{}
$lido = Ler-Json $ARQ_ANDAMENTO
if ($lido) { foreach ($p in $lido.PSObject.Properties) { $andamento[$p.Name] = $p.Value } }
# 0.34.0: "erro" antigo que já era falta de procuração (mensagem do e-CAC) vira "sem_procuracao": não é tentado de novo
foreach ($k in @($andamento.Keys)) {
  $r = $andamento[$k]
  if ($r -and [string]$r.situacao -eq 'erro' -and [string]$r.mensagem -match 'n[aã]o existe procura[cç][aã]o eletr[oô]nica') {
    $andamento[$k] = [pscustomobject]@{ situacao = 'sem_procuracao'; certificado = $r.certificado; inicio = $r.inicio; fim = $r.fim; tentativas = $r.tentativas
      mensagem = "[sem_procuracao] confirmado antes da 0.34.0 (sem print Sem_Procuracao; para gerar, use ""Refazer sem procuração""): $(([string]$r.mensagem -split "`n")[0])" }
  }
}
# Contador (0.34.0): total, concluídos, com erro/sem procuração, restantes (ainda não analisados) e % analisado.
# Vem do andamento (o checkpoint em disco): sobrevive a reinícios e cada CNPJ conta uma vez só.
function Contagem {
  $c = [ordered]@{ total = 0; concluidos = 0; erros = 0; semProcuracao = 0; procCancelada = 0; caixaPostal = 0; restantes = 0; percentual = 0 }
  foreach ($f in $fila) {
    $c.total++
    $s = if ($andamento[$f.cnpj]) { [string]$andamento[$f.cnpj].situacao } else { 'pendente' }
    switch ($s) { 'concluido' { $c.concluidos++ } 'erro' { $c.erros++ } 'sem_procuracao' { $c.semProcuracao++ } 'procuracao_cancelada' { $c.procCancelada++ } 'caixa_postal' { $c.caixaPostal++ } default { $c.restantes++ } }
  }
  if ($c.total) { $c.percentual = [int][math]::Floor(100 * ($c.total - $c.restantes) / $c.total) }
  return $c
}
function Log-Progresso {
  $c = Contagem
  # 0.37.0: "procuração cancelada N" só aparece quando houver algum (a linha fica igual à de antes nos outros casos)
  Log ("  PROGRESSO: {0} de {1} analisados ({2}%) | concluídos {3} | com erro {4} | sem procuração {5}{7}{8} | restantes {6}" -f
    ($c.total - $c.restantes), $c.total, $c.percentual, $c.concluidos, $c.erros, $c.semProcuracao, $c.restantes,
    $(if ($c.procCancelada) { " | procuração cancelada $($c.procCancelada)" } else { '' }),
    $(if ($c.caixaPostal) { " | aviso de Caixa Postal $($c.caixaPostal)" } else { '' })) # 0.39.0
}

$pendentes = @($fila | Where-Object { -not ($andamento[$_.cnpj] -and $FINAIS -contains $andamento[$_.cnpj].situacao) })
Log "configuração: $($fila.Count) CNPJ(s) em $(@($cfg.certificados).Count) certificado(s); pendentes: $($pendentes.Count)"
foreach ($f in $fila) {
  $sit = if ($andamento[$f.cnpj]) { $andamento[$f.cnpj].situacao } else { 'pendente' }
  Log "  $($f.cnpj)  [$($f.certificado)]  $sit"
}
Log-Progresso
if ($SoMostrar -or -not $pendentes.Count) { Log 'nada a fazer.'; return }
# uma execução por vez (atual.json e sinal.json são únicos): outra rodando = não começa
$outra = $null; try { $outra = Ler-Json $ARQ_EXECUCAO } catch { }
if ($outra -and $outra.pid -and [int]$outra.pid -ne $PID -and (Get-Process -Id ([int]$outra.pid) -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -match 'powershell' })) {
  Log "já há uma execução em andamento (processo $($outra.pid), configuração $($outra.config)); não comecei outra"
  return
}
Remove-Item -LiteralPath $ARQ_PARAR, $ARQ_PAUSAR -ErrorAction SilentlyContinue # pedidos de uma execução anterior não valem
Gravar-Json $ARQ_EXECUCAO ([ordered]@{ pid = $PID; config = $Config; andamento = $ARQ_ANDAMENTO; inicio = (Get-Date).ToString('o') })
Remove-Item -LiteralPath $ARQ_ULTIMA -ErrorAction SilentlyContinue # o resumo é da execução anterior
$encerramento = 'terminou' # terminou | parada | chrome_fechado | erro

# ---- Chrome ----
$CHROME = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe' -ErrorAction SilentlyContinue).'(default)'
if (-not $CHROME) { $CHROME = (Get-ItemProperty 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe' -ErrorAction SilentlyContinue).'(default)' }
if (-not $CHROME) { $CHROME = 'C:\Program Files\Google\Chrome\Application\chrome.exe' }

function Processos-Chrome {
  if ($SemChrome) { return @() }
  if ($ChromeSimulado) {
    return @(Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" | Where-Object { $_.CommandLine -like '*pgfn_chrome_simulado*' } |
      ForEach-Object { Get-Process -Id $_.ProcessId -ErrorAction SilentlyContinue })
  }
  if ($PerfilChrome) {
    return @(Get-CimInstance Win32_Process -Filter "Name='chrome.exe'" | Where-Object { $_.CommandLine -like "*$PerfilChrome*" } |
      ForEach-Object { Get-Process -Id $_.ProcessId -ErrorAction SilentlyContinue })
  }
  return @(Get-Process -Name chrome -ErrorAction SilentlyContinue)
}

# Antes de fechar: nenhum download em andamento (arquivos .crdownload) na pasta Downloads.
function Esperar-Downloads {
  $limite = (Get-Date).AddMinutes(3)
  while ((Get-Date) -lt $limite) {
    $em = @(Get-ChildItem -Path (Join-Path $env:USERPROFILE 'Downloads') -Recurse -Filter '*.crdownload' -ErrorAction SilentlyContinue)
    if (-not $em.Count) { return }
    Log "aguardando $($em.Count) download(s) em andamento terminar(em)…"
    Start-Sleep -Seconds 3
  }
  Log 'atenção: ainda há download em andamento após 3 min; fechando mesmo assim'
}

# Conversa com o ajudante do Windows do mesmo jeito que o Chrome (4 bytes de tamanho + JSON). Usado pelo vigia de
# travamentos para ver/fechar janelas "Salvar como". Sem resposta: devolve $null (nunca derruba o orquestrador).
function Chamar-Ajudante($pedido) {
  $msg = Join-Path $env:TEMP ("pgfn_orq_" + [guid]::NewGuid().ToString('N') + '.bin')
  try {
    $bat = Join-Path (Split-Path $ARQ_LOG_AJUDANTE -Parent) 'salvar_como.bat'
    $corpo = [Text.Encoding]::UTF8.GetBytes(($pedido | ConvertTo-Json -Compress))
    [IO.File]::WriteAllBytes($msg, [byte[]]([BitConverter]::GetBytes([int]$corpo.Length) + $corpo))
    $psi = New-Object Diagnostics.ProcessStartInfo 'cmd.exe', ("/d /s /c `"`"$bat`" chrome-extension://orquestrador/ --parent-window=0 < `"$msg`"`"")
    $psi.UseShellExecute = $false; $psi.RedirectStandardOutput = $true; $psi.CreateNoWindow = $true
    $p = [Diagnostics.Process]::Start($psi)
    $ms = New-Object IO.MemoryStream; $p.StandardOutput.BaseStream.CopyTo($ms); [void]$p.WaitForExit(30000)
    $b = $ms.ToArray()
    if ($b.Length -lt 4 -or [BitConverter]::ToInt32($b, 0) -ne $b.Length - 4) { return $null }
    return ([Text.Encoding]::UTF8.GetString($b, 4, $b.Length - 4) | ConvertFrom-Json)
  } catch { return $null } finally { Remove-Item -LiteralPath $msg -ErrorAction SilentlyContinue }
}

# Janela "Salvar como" aberta? Fecha (botão "Cancelar") antes de reiniciar o Chrome: nunca reinicia com ela aberta.
function Tratar-Janelas-Salvar($motivo) {
  $j = Chamar-Ajudante @{ acao = 'janelas' }
  if (-not $j -or -not $j.abertas) { return 0 }
  $nomes = @($j.janelas | ForEach-Object { [string]$_.nome }) -join ' | '
  Log "  $motivo`: $($j.abertas) janela(s) ""Salvar como"" aberta(s) ($nomes); fechando de forma controlada"
  $c = Chamar-Ajudante @{ acao = 'cancelar-todas' }
  Log ("  janelas fechadas: " + $(if ($c) { "$(@($c.fechadas).Count) (restam $($c.restantes))" } else { 'o ajudante não respondeu' }))
  return [int]$j.abertas
}

# Fecha TODO o Chrome: primeiro pede para as janelas fecharem; o que sobrar é encerrado à força (sem confirmações).
function Fechar-Chrome {
  $ps = Processos-Chrome
  if (-not $ps.Count) { return }
  [void](Tratar-Janelas-Salvar 'antes de fechar o Chrome')
  Esperar-Downloads
  Log "fechando o Chrome ($($ps.Count) processo(s))…"
  foreach ($p in $ps) { try { [void]$p.CloseMainWindow() } catch { } }
  $limite = (Get-Date).AddSeconds(8)
  while ((Get-Date) -lt $limite -and (Processos-Chrome).Count) { Start-Sleep -Milliseconds 500 }
  foreach ($p in (Processos-Chrome)) { try { Stop-Process -Id $p.Id -Force -ErrorAction Stop } catch { } }
  $limite = (Get-Date).AddSeconds(15)
  while ((Get-Date) -lt $limite -and (Processos-Chrome).Count) { Start-Sleep -Milliseconds 500 }
  if ((Processos-Chrome).Count) { throw 'não consegui fechar o Chrome' }
  Start-Sleep -Seconds 2
}

function Abrir-Chrome([switch]$DeNovo) {
  $argumentos = @('--incognito', '--no-first-run', '--no-default-browser-check')
  if ($PerfilChrome) { $argumentos += "--user-data-dir=`"$PerfilChrome`"" }
  $argumentos += $UrlInicial
  if ($DeNovo) { Log "abrindo de novo $UrlInicial na janela anônima (a extensão ainda não tinha começado o login)" }
  else { Log "abrindo o Chrome (anônimo) em $UrlInicial" }
  if ($ChromeSimulado) { # teste: um processo que faz o papel do Chrome com a extensão
    Start-Process powershell -WindowStyle Hidden -ArgumentList '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$ChromeSimulado`"", '-Pasta', "`"$AQUI`"", '-Marca', 'pgfn_chrome_simulado' | Out-Null
    return
  }
  Start-Process -FilePath $CHROME -ArgumentList $argumentos | Out-Null
}

# A extensão já consultou o CNPJ da vez (pedido "orq-atual" no ajudante.log) desde $desde?
# Na partida do Chrome, a primeira aba pode carregar antes de a extensão subir e ficar sem o script do login.
$ARQ_LOG_AJUDANTE = Join-Path $BASE 'Ajudante_Windows\ajudante.log'
function Extensao-Consultou($desde) {
  if (-not (Test-Path -LiteralPath $ARQ_LOG_AJUDANTE)) { return $false }
  $marca = $desde.ToString('yyyy-MM-dd HH:mm:ss')
  foreach ($l in (Get-Content -LiteralPath $ARQ_LOG_AJUDANTE -Tail 300 -Encoding UTF8)) {
    if ($l.Length -ge 19 -and $l.Substring(0, 19) -ge $marca -and $l -like '*pedido:*"acao":"orq-atual"*') { return $true }
  }
  return $false
}
$SEGUNDOS_ESPERA_EXTENSAO = 40
$REPETICOES_LENTIDAO = 2 # vezes que o mesmo CNPJ é refeito (Chrome reaberto) quando a falha foi lentidão
$REABERTURAS_MAX = 2

function Registrar($cnpj, $dados) {
  $andamento[$cnpj] = [pscustomobject]$dados
  $saida = [ordered]@{}
  foreach ($k in ($andamento.Keys | Sort-Object)) { $saida[$k] = $andamento[$k] }
  Gravar-Json $ARQ_ANDAMENTO $saida
}

# CNPJ com dígitos verificadores corretos? (um CNPJ digitado errado não chega a abrir o Chrome)
function Cnpj-Valido([string]$c) {
  if ($c -notmatch '^\d{14}$' -or $c -match '^(\d)\1{13}$') { return $false }
  $dv = {
    param($base)
    $peso = $base.Length - 7; $soma = 0
    foreach ($ch in $base.ToCharArray()) { $soma += [int][string]$ch * $peso; $peso--; if ($peso -lt 2) { $peso = 9 } }
    $r = $soma % 11; if ($r -lt 2) { 0 } else { 11 - $r }
  }
  $d1 = & $dv $c.Substring(0, 12); $d2 = & $dv ($c.Substring(0, 12) + $d1)
  return ("$d1$d2" -eq $c.Substring(12))
}

# Situação de todos os CNPJs da lista desde já: pendente | em_andamento | concluido | erro (retomada sem perder nada).
foreach ($f in $fila) {
  if (-not $andamento[$f.cnpj]) { $andamento[$f.cnpj] = [pscustomobject]@{ situacao = 'pendente'; certificado = $f.certificado; inicio = $null; fim = $null; mensagem = ''; tentativas = 0 } }
}
if ($fila.Count) { Registrar $fila[0].cnpj $andamento[$fila[0].cnpj] }

# ---- um CNPJ por vez ----
try {
  $posicao = 0
  foreach ($item in $pendentes) {
    # pedidos da interface, sempre ENTRE um CNPJ e outro (nunca no meio de uma emissão)
    if (Test-Path -LiteralPath $ARQ_PARAR) { Log 'parada pedida pela interface: encerrando antes do próximo CNPJ'; Remove-Item -LiteralPath $ARQ_PARAR -ErrorAction SilentlyContinue; $encerramento = 'parada'; break }
    if (Test-Path -LiteralPath $ARQ_PAUSAR) {
      Log "pausa pedida pela interface: o próximo CNPJ ($($item.cnpj)) espera até você clicar em Retomar"
      while ((Test-Path -LiteralPath $ARQ_PAUSAR) -and -not (Test-Path -LiteralPath $ARQ_PARAR)) { Start-Sleep -Seconds 2 }
      if (Test-Path -LiteralPath $ARQ_PARAR) { Log 'parada pedida pela interface durante a pausa: encerrando'; Remove-Item -LiteralPath $ARQ_PARAR, $ARQ_PAUSAR -ErrorAction SilentlyContinue; $encerramento = 'parada'; break }
      Log 'retomado pela interface'
    }
    $posicao++
    try { $Host.UI.RawUI.WindowTitle = "Automação PGFN - CNPJ $($item.cnpj) ($posicao de $($pendentes.Count))" } catch { }
    $tent = if ($andamento[$item.cnpj] -and $andamento[$item.cnpj].tentativas) { [int]$andamento[$item.cnpj].tentativas + 1 } else { 1 }
    if (-not (Cnpj-Valido $item.cnpj)) {
      Log "===== CNPJ $($item.cnpj)  (certificado: $($item.certificado); tentativa $tent) ====="
      $mensagem = 'CNPJ com dígito verificador inválido em cnpjs.json (confira a digitação); não processado'
      Registrar $item.cnpj @{ situacao = 'erro'; certificado = $item.certificado; inicio = (Get-Date).ToString('o'); fim = (Get-Date).ToString('o'); mensagem = $mensagem; tentativas = $tent }
      Log "  resultado: erro"; Log "    $mensagem"
      continue
    }
    # Lentidão, travamento ou falha temporária (a extensão marca a mensagem com "[lentidao]"; o vigia marca
    # "[travamento]"): o MESMO CNPJ é refeito com o Chrome reaberto, até $RecuperacoesMax vezes (os PDFs já salvos não
    # são emitidos de novo: registro no Chrome e em disco). Não deu: PAUSA esperando você (Retomar = tenta de novo este
    # CNPJ; Parar = encerra). Nunca passa ao próximo CNPJ por causa de travamento (0.33.0; antes ficava "erro" e seguia).
    $recuperacoes = 0
    $pararTudo = $false
    do {
    $sessao = [guid]::NewGuid().ToString()
    $tent = if ($andamento[$item.cnpj] -and $andamento[$item.cnpj].tentativas) { [int]$andamento[$item.cnpj].tentativas + 1 } else { 1 }
    Log "===== CNPJ $($item.cnpj)  (certificado: $($item.certificado); tentativa $tent) ====="
    Fechar-Chrome
    Remove-Item -LiteralPath $ARQ_SINAL, $ARQ_PROGRESSO -ErrorAction SilentlyContinue
    Gravar-Json $ARQ_ATUAL ([ordered]@{ cnpj = $item.cnpj; certificado = $item.certificado; pastaCertificado = $item.pasta;
      certificadoExato = $item.exato; sessao = $sessao; pid = $PID; t = (Get-Date).ToString('o') })
    if ($item.pasta) { Log "  pasta: Documentos_arrecadacao\$($item.pasta)\$($item.cnpj)" }
    $inicio = Get-Date
    Registrar $item.cnpj @{ situacao = 'em_andamento'; certificado = $item.certificado; inicio = $inicio.ToString('o'); fim = $null; mensagem = ''; tentativas = $tent }
    if ($SemChrome) { # teste da fila: nada de Chrome; o CNPJ volta a pendente
      Start-Sleep -Seconds 6
      Registrar $item.cnpj @{ situacao = 'pendente'; certificado = $item.certificado; inicio = $inicio.ToString('o'); fim = (Get-Date).ToString('o'); mensagem = 'teste sem Chrome'; tentativas = $tent }
      Log '  [teste sem Chrome] passou pela fila'
      break
    }
    Abrir-Chrome
    $extensaoOk = $false; $reaberturas = 0; $aberturaEm = Get-Date

    $ultimoSinal = Get-Date; $ultimoT = ''; $ultimaSit = ''; $resultado = $null; $mensagem = ''
    $ultimoProgT = ''; $ultimaAcao = ''; $checkpoint = $null; $recuperouLeve = $false; $tSinal = $null; $tProg = $null; $textoProg = ''
    while (-not $resultado) {
      Start-Sleep -Seconds 3
      # a extensão começou? Se não, abre o endereço de novo (só no início; nunca depois que ela respondeu)
      if (-not $extensaoOk) {
        if ((Test-Path -LiteralPath $ARQ_SINAL) -or (Extensao-Consultou $inicio)) { $extensaoOk = $true; Log '  extensão ativa (consultou o CNPJ da vez)' }
        elseif (((Get-Date) - $aberturaEm).TotalSeconds -gt $SEGUNDOS_ESPERA_EXTENSAO -and (Processos-Chrome).Count) {
          if ($reaberturas -lt $REABERTURAS_MAX) { $reaberturas++; Abrir-Chrome -DeNovo; $aberturaEm = Get-Date }
          else { $extensaoOk = $true; Log '  atenção: a extensão não consultou o orquestrador; confira se ela está ligada e "Permitir no modo anônimo"' }
        }
      }
      $s = $null; try { $s = Ler-Json $ARQ_SINAL } catch { }
      if ($s -and $s.sessao -eq $sessao) {
        if ([string]$s.t -ne $ultimoT) {
          $ultimoT = [string]$s.t; $ultimoSinal = Get-Date; $tSinal = Get-Date
          $ultimaAcao = ([string]$s.mensagem -split "`n")[0]
          if ($s.situacao -ne $ultimaSit -or $s.situacao -eq 'em_andamento') {
            $resumo = ([string]$s.mensagem -split "`n")[0]
            if ($s.situacao -ne 'em_andamento' -or $resumo -ne $ultimoResumo) { Log "  [$($s.situacao)] $resumo" }
            $ultimoResumo = $resumo
          }
          $ultimaSit = $s.situacao
        }
        if ($s.situacao -in @('concluido', 'erro')) { $resultado = $s.situacao; $mensagem = [string]$s.mensagem }
      }
      # progresso da extensão (cada mudança do aviso na tela): última ação e ponto exato (checkpoint)
      $pg = $null; try { $pg = Ler-Json $ARQ_PROGRESSO } catch { }
      if ($pg -and $pg.sessao -eq $sessao -and [string]$pg.t -ne $ultimoProgT) {
        $ultimoProgT = [string]$pg.t; $ultimoSinal = Get-Date; $tProg = Get-Date
        $textoProg = [string]$pg.texto; $ultimaAcao = $textoProg; $checkpoint = $pg.checkpoint
      }
      # esperando você (captcha, PIN, Caixa Postal, cálculo, salvar à mão…): pausa intencional, sem tempo limite. Vale até
      # a extensão mostrar progresso de novo depois do aviso de pausa.
      $esperandoVoce = $ultimaSit -eq 'aguardando_humano' -and (-not $tProg -or $tProg -le $tSinal -or $textoProg -like 'PAUSA*')
      if ($esperandoVoce) { $ultimoSinal = Get-Date }
      # ---- vigia de travamentos: sem progresso e sem pausa por $MinutosTravamento ----
      $parado = ((Get-Date) - $ultimoSinal).TotalMinutes
      if (-not $resultado -and $parado -gt $MinutosTravamento) {
        $ponto = if ($checkpoint) { "etapa: $($checkpoint.etapa); conta: $($checkpoint.conta); parcela: $($checkpoint.parcela); PDFs salvos: $($checkpoint.salvos)" } else { 'sem checkpoint' }
        $descricao = "sem progresso há $([math]::Round($parado, 1)) min (última ação: $ultimaAcao; $ponto)"
        if (-not $recuperouLeve) {
          # 1º passo: algo bloqueando? (janela "Salvar como"). Fecha e dá um tempo para a própria extensão seguir.
          $recuperouLeve = $true
          Log "  TRAVAMENTO: $descricao"
          if (Tratar-Janelas-Salvar 'recuperação') {
            Log "  esperando $SegundosRecuperacao s pelo progresso depois de fechar a janela…"
            $ultimoSinal = (Get-Date).AddMinutes(-$MinutosTravamento).AddSeconds($SegundosRecuperacao)
          } else { $resultado = 'erro'; $mensagem = "[travamento] $descricao" }
        } else { $resultado = 'erro'; $mensagem = "[travamento] $descricao" }
      }
      # Chrome fechado antes do fim = você parou a automação: o CNPJ volta a "pendente" e o orquestrador ENCERRA (não abre
      # outro Chrome nem passa ao próximo; cada abertura seria mais um login no e-CAC, que tem limite de sessões: erro 93003)
      if (-not $resultado -and -not (Processos-Chrome).Count) { $resultado = 'interrompido'; $mensagem = 'o Chrome foi fechado antes de a automação terminar este CNPJ' }
    }
    $situacao = if ($resultado -eq 'interrompido') { 'pendente' } elseif ($resultado -eq 'erro' -and $mensagem.Contains('[sem_procuracao]')) { 'sem_procuracao' } elseif ($resultado -eq 'erro' -and $mensagem.Contains('[procuracao_cancelada]')) { 'procuracao_cancelada' } elseif ($resultado -eq 'erro' -and $mensagem.Contains('[caixa_postal]')) { 'caixa_postal' } else { $resultado }
    $msgReg = if ($resultado -eq 'interrompido') { "interrompido: $mensagem; será feito na próxima execução" } else { $mensagem }
    Registrar $item.cnpj @{ situacao = $situacao; certificado = $item.certificado; inicio = $inicio.ToString('o'); fim = (Get-Date).ToString('o'); mensagem = $msgReg; tentativas = $tent; checkpoint = $checkpoint }
    # 0.35.0: "[falha_salvamento]" = o PDF de uma prestação não foi salvo depois de 3 tentativas; o CNPJ fica "erro"
    # (pendente, refeito na próxima execução sem repetir os PDFs já salvos) e a fila segue para o próximo
    Log "  resultado: $(if ($situacao -eq 'sem_procuracao') { 'sem_procuracao (não será tentado de novo)' } elseif ($situacao -eq 'caixa_postal') { 'Aviso de Caixa Postal (caixa_postal; análise encerrada com o print do aviso; não será tentado de novo até "Refazer sem procuração")' } elseif ($situacao -eq 'procuracao_cancelada') { 'Pendente por procuração cancelada (procuracao_cancelada; não será tentado de novo até "Refazer sem procuração")' } elseif ($situacao -eq 'erro' -and $mensagem.Contains('[falha_salvamento]')) { 'erro - falha de salvamento (pendente; refeito na próxima execução; seguindo para o próximo CNPJ)' } elseif ($situacao -eq 'erro' -and $mensagem.Contains('[sessao_pgfn]')) { 'erro - acesso ao SISPAR expirado ("Você não tem permissão de acesso ou ele expirou")' } else { $resultado })"
    foreach ($l in ($mensagem -split "`n")) { if ($l.Trim()) { Log "    $l" } }
    # 0.36.0: "[sessao_pgfn]" = o SISPAR respondeu "Você não tem permissão de acesso ou ele expirou" (acesso perdido).
    # Só se resolve entrando de novo pelo Regularize: refaz o MESMO CNPJ com o Chrome reaberto (como a lentidão).
    $sessaoPgfn = $resultado -eq 'erro' -and $mensagem.Contains('[sessao_pgfn]')
    $lento = $resultado -eq 'erro' -and ($sessaoPgfn -or $mensagem.Contains('[lentidao]') -or $mensagem.Contains('sem dar sinal') -or $mensagem.Contains('[travamento]'))
    $repetir = $false
    if ($lento) {
      $recuperacoes++
      if ($recuperacoes -le $RecuperacoesMax) {
        Log "  recuperação automática: refazendo o MESMO CNPJ com o Chrome reaberto ($recuperacoes de $RecuperacoesMax); PDFs já salvos não são emitidos de novo"
        $repetir = $true
        Start-Sleep -Seconds 10
      } elseif ($sessaoPgfn) {
        # acesso ao SISPAR perdido de novo em todas as tentativas: o CNPJ fica pendente ("erro", refeito na próxima
        # execução) e a fila segue (não pausa: não há o que você fazer na tela)
        Log "  o CNPJ $($item.cnpj) não se recuperou depois de $RecuperacoesMax tentativas (acesso ao SISPAR expirado/perdido): fica pendente (com erro) e a fila segue para o próximo CNPJ"
        Registrar $item.cnpj @{ situacao = 'erro'; certificado = $item.certificado; inicio = $inicio.ToString('o'); fim = (Get-Date).ToString('o'); mensagem = "[sessao_pgfn] sem recuperação depois de $RecuperacoesMax tentativas: $(($mensagem -split "`n")[0])"; tentativas = $tent; checkpoint = $checkpoint }
      } else {
        # não se recuperou: PAUSA (nunca pula o CNPJ por travamento)
        $motivo = "o CNPJ $($item.cnpj) não se recuperou depois de $RecuperacoesMax tentativas ($(($mensagem -split "`n")[0])). Clique em Retomar para tentar de novo este CNPJ, ou em Parar."
        Log "  PAUSA: $motivo"
        Registrar $item.cnpj @{ situacao = 'pendente'; certificado = $item.certificado; inicio = $inicio.ToString('o'); fim = (Get-Date).ToString('o'); mensagem = "travamento sem recuperação; aguardando você: $(($mensagem -split "`n")[0])"; tentativas = $tent; checkpoint = $checkpoint }
        [IO.File]::WriteAllText($ARQ_PAUSAR, "PAUSA (travamento): $motivo", (New-Object Text.UTF8Encoding $false))
        while ((Test-Path -LiteralPath $ARQ_PAUSAR) -and -not (Test-Path -LiteralPath $ARQ_PARAR)) { Start-Sleep -Seconds 2 }
        if (Test-Path -LiteralPath $ARQ_PARAR) {
          Log '  parada pedida durante a pausa: encerrando (o CNPJ fica pendente para a próxima execução)'
          Remove-Item -LiteralPath $ARQ_PARAR, $ARQ_PAUSAR -ErrorAction SilentlyContinue
          $pararTudo = $true
        } else {
          Log '  retomado: tentando de novo o MESMO CNPJ'
          $recuperacoes = 0
          $repetir = $true
        }
      }
    }
    } while ($repetir)
    Log-Progresso # 0.34.0: só depois do CNPJ terminado (uma tentativa de recuperação não conta como "com erro")
    if ($pararTudo) { $encerramento = 'parada'; break }
    if ($resultado -eq 'interrompido') {
      Log '  o Chrome foi fechado: entendi que você parou a automação. Orquestrador encerrado; rode de novo para continuar deste CNPJ.'
      $encerramento = 'chrome_fechado'
      break
    }
  }
} catch {
  # erro inesperado: fica registrado (antes o orquestrador fechava sem dizer por quê)
  $encerramento = 'erro'
  Log "ERRO no orquestrador: $($_.Exception.Message) (linha $($_.InvocationInfo.ScriptLineNumber)). Rode Iniciar de novo para continuar."
} finally {
  # resumo de como terminou ANTES de apagar atual.json: assim a extensão nunca fica sem explicação na tela
  try {
    $c = Contagem
    Gravar-Json $ARQ_ULTIMA ([ordered]@{ encerramento = $encerramento; config = $Config; nome = [string]$cfg.nome; fim = (Get-Date).ToString('o');
      total = $c.total; concluidos = $c.concluidos; erros = $c.erros; semProcuracao = $c.semProcuracao; procCancelada = $c.procCancelada; caixaPostal = $c.caixaPostal; pendentes = $c.restantes; percentual = $c.percentual })
  } catch { }
  Remove-Item -LiteralPath $ARQ_ATUAL -ErrorAction SilentlyContinue # sem orquestrador, a extensão volta ao modo manual
  Remove-Item -LiteralPath $ARQ_EXECUCAO, $ARQ_PAUSAR -ErrorAction SilentlyContinue
}
$conc = @($fila | Where-Object { $andamento[$_.cnpj] -and $andamento[$_.cnpj].situacao -eq 'concluido' }).Count
Log "fim: $conc de $($fila.Count) CNPJ(s) concluído(s). Andamento em $ARQ_ANDAMENTO"
# resumo na tela: a situação de cada CNPJ da lista
Log '----- situação de cada CNPJ -----'
foreach ($f in $fila) {
  $a = $andamento[$f.cnpj]
  $sit = if ($a) { [string]$a.situacao } else { 'pendente' }
  $motivo = if ($a -and $sit -ne 'concluido') { ([string]$a.mensagem -split "`n")[0] } else { '' }
  Log ("  {0}  {1,-12} {2}" -f $f.cnpj, $sit, $motivo)
}
try { $Host.UI.RawUI.WindowTitle = "Automação PGFN - terminado ($conc de $($fila.Count) concluídos)" } catch { }
