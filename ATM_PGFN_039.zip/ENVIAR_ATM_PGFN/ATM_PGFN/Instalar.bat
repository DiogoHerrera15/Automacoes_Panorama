@echo off
rem Instalacao guiada da Automacao PGFN (pasta ATM_PGFN). Pode rodar de novo quando quiser: nao apaga nada.
title Instalacao - Automacao PGFN
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Instalador\instalar.ps1" %*
echo.
pause
