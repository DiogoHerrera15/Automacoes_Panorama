@echo off
rem Abre a interface da Automacao PGFN (certificado, CNPJs, Iniciar/Pausar/Retomar/Parar e acompanhamento).
if not exist "%~dp0Interface\Automacao_PGFN.exe" (
  echo Interface nao encontrada. Gerando com o .NET do Windows...
  call "%~dp0Interface\compilar.bat"
)
if not exist "%~dp0Interface\Automacao_PGFN.exe" (
  echo Nao consegui abrir a interface. Rode Instalar.bat e veja o README.md.
  pause
  exit /b 1
)
start "" "%~dp0Interface\Automacao_PGFN.exe"
