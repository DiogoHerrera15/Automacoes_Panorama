# HISTÓRICO DO PROJETO — Automação PGFN

> Histórico cronológico de pedidos, decisões, problemas e soluções, de **05/11/2026 a 10/11/2026** (última atualização: Fase 7, v0.33.1).
> Fontes: as duas conversas exportadas em `Historico_conversas\` (texto integral das mensagens e respostas), o documento
> técnico `Desenvolvimento\CONTINUIDADE_AUTOMACAO_PGFN_ate_v0.33.md` e o código atual.
>
> **Legenda usada em cada item:**
>
> | Marca | Significado |
> |---|---|
> | **[P]** | pedido do usuário |
> | **[I]** | implementado no código |
> | **[T-sim]** | testado no simulador local ou em testes automáticos |
> | **[T-real]** | confirmado no site real (e-CAC/PGFN) pelos registros ou pelos prints do usuário |
> | **[pendente]** | ainda não feito ou não confirmado |

---

## Fase 1 — Criação da extensão: e-CAC → Regularize → SISPAR (05/11/2026)

- **[P] 13:30 — Pedido inicial.**
  - Extensão Chrome Manifest V3, sem Playwright ou Selenium.
  - Seta de mouse desenhada, com movimento humano.
  - Esperar cada elemento com tempo limite e uma mensagem clara.
  - Fluxo inicial: e-CAC → "Alterar perfil de acesso" → digitar o CNPJ.
  - CNPJs de teste iniciais: 90000017000131 e 90000003000118.
- **[P] 13:41** — Nome da extensão: **Automação_PGFN**.
- **[I] até a v0.11** — Fluxo completo até o SISPAR:
  - **e-CAC:** troca de perfil com o CNPJ digitado tecla a tecla; F5 quando a tela trava (pedido das 16:05); tratamento de "sem procuração".
  - **Dívida Ativa:** "PGFN - Todos os serviços do Regularize".
  - **Regularize:** CIENTE → NEGOCIAR DÍVIDA → ACESSAR.
  - **SISPAR:** o quadro (iframe de outro domínio) é controlado por um "agente" que roda dentro dele; CONSULTAR → CONTINUAR, nunca DESISTIR.
- **[P] 16:42 — Nome dos arquivos** `cnpj;nome_da_empresa`, com uma pasta por situação (essas pastas foram unificadas na v0.21).
- **[P] 17:10–17:32 — Erro "Sessão encerrada" no SISPAR.**
  - Funcionava à mão e falhava na automação; o usuário pediu também para randomizar o mouse.
  - **[I] v0.12 — Causa:** o `window.open` era bloqueado e o SISPAR carregava dentro do iframe, perdendo a sessão; o token do SISPAR é de uso único.
  - **Solução:** o `pagina.js` (mundo MAIN) intercepta a abertura, e a extensão abre a aba nova **uma única vez**.
- **[P] 17:47 — Menu "Emissão de Documento".** Só se passa o mouse (hover), sem clicar, até "Documento de arrecadação".
  - **[I] v0.13–0.13.1.**

## Fase 2 — Análise, emissão, downloads e pastas (06/11/2026)

- **[P] 08:37–09:06 — Hover correto no menu;** depois, processar todas as negociações **"DEFERIDA E CONSOLIDADA"**, uma por vez.
  - **[I] v0.13.1 e v0.14.**
- **[P] 10:25 — Coluna "Emissão"** da tabela "Prestação": rolar com a roda do mouse e conferir até o mês atual.
  - **[I] v0.15**, mais o relatório `.csv`.
- **[P] 10:49 — Emissão:** impressora → janela "Cálculo e demonstrativo" (conferir a parcela) → **Emitir** → página do PDF → link → **Voltar**.
  - **[I] v0.16**, com pasta por CNPJ e conferência do "Contribuinte".
- **[P] 11:12 — Janela "Salvar como" do Chrome.** **[I] v0.17:** espera manual, aviso "Continuar no e-CAC" e registro de downloads por mês.
- **[P] 13:10 — CNPJ sem "PGFN - Todos os serviços do Regularize"** → pular. **[I] v0.18.**
- **[P] 13:31 — Nenhuma "Deferida e consolidada"** → `Sem_Deferido_<CNPJ>.pdf`. **[I] v0.19**, mais o próximo CNPJ na aba do e-CAC.
- **[P] 14:11 — Aviso de notificações da PGFN** → FECHAR (nunca "VER AGORA"). **[I] v0.20.**
- **[P] 14:23 — Tudo de cada CNPJ numa pasta só.** **[I] v0.21**; também corrigiu os nomes "download.pdf/.csv".
- **[P] 14:37 — Print de confirmação** da página inteira depois da análise. **[I] v0.22** (documento offscreen).
- **[P] 15:00 — Print em PDF;** o ícone **laranja** significa "já emitido". **[I] v0.23.**
- **[P] 15:25 — Confirmar a janela "Salvar como" automaticamente.**
  - **[I] v0.24 — Ajudante do Windows** (native messaging `com.auto_pgfn.salvar_como`): confirma a janela e confere o PDF no disco.
  - **[P] 16:09** — o usuário autorizou instalar o ajudante ("Sim, instale").
- **[P] 16:00 — Vários downloads bloqueados pelo Chrome.**
  - **[I] v0.25:** `automaticDownloads` liberado **só** para o sisparnet; um download HTML no lugar do PDF é cancelado.
  - Corrigido também o `.htm` salvo como documento, porque o atalho baixava a própria página.
- **[P] 16:16 — O ajudante ainda não estava ativo.** **[I] v0.26:** tolera a caixa "Tipo" ilegível do Chrome, grava o `ajudante.log` e confere o ajudante no início.
- **[P] 16:36 — Tela "Você ainda não está cadastrado no REGULARIZE"** → `sem_cadastro_regularize.pdf`. **[I] v0.27.**
- **[T-real]** Várias execuções reais nesse dia, com CNPJs de teste (detalhe em `Desenvolvimento\CONTINUIDADE…`, seção 7).

## Fase 3 — Orquestrador e vários certificados (09/11/2026, manhã)

- **[T-real] 08:04–08:07** — CNPJ 90000006000151: 4 PDFs salvos com a janela "Salvar como" confirmada pelo ajudante, sem clique manual.
- **[P] 08:21 — Troca automática de CNPJ entre execuções.**
  - **[P] 08:32 — Decisões do usuário:**
    - **"Fechar todo o Chrome"** a cada CNPJ e reabrir em modo anônimo;
    - entrada por `https://cav.receita.fazenda.gov.br/autenticacao` (pedido das 08:35);
    - login: gov.br → "Seu certificado digital" → certificado configurado;
    - vários certificados, cada um com a sua lista. O CERT_A serve **só para teste** e não pode ficar fixo no código.
- **[I] v0.28.0 + ajudante 1.2:**
  - **Orquestrador** `orquestrador.ps1`:
    - lê o `cnpjs.json` e cuida de um CNPJ por vez;
    - escreve `atual.json` (CNPJ da vez), lê `sinal.json` (andamento informado pela extensão) e grava `andamento.json` (situação de cada CNPJ).
  - **Ajudante:** ações `orq-atual`, `orq-informar` e `certificado`. Na escolha do certificado, usa o **mouse real**, confere o foco e só então clica em OK.
- **[pendente → resolvido na Fase 4]** 08:52 — Primeiro teste real: o login automático não começou.
- **09:01 — Fim da conversa 1.** O chat ficou longo e foi gerado o `CONTINUIDADE_AUTOMACAO_PGFN.md`.

## Fase 4 — Estabilização em uso real (09/11/2026, conversa 2)

- **[P] 09:06** — Continuar sem reiniciar.
- **[P] 09:14** — Processar uma lista de **21 CNPJs**:
  - em sequência, com situação de cada um (pendente, em processamento, concluído, erro);
  - retomada de onde parou;
  - CERT_A só para teste.
- **[P] 09:30 — "Login automático desligado: ajudante não respondeu".**
  - **[I] v0.28.1 — Causa:** uma linha de diagnóstico no `salvar_como.bat` (`echo … %*>> chamadas.log`). O Chrome passa `--parent-window=0`; o `0>>` virava redirecionamento e o texto ia para a saída padrão, quebrando o protocolo.
  - **Correções:** a linha foi removida; a extensão injeta o `content.js` na página de login se ele faltar; o orquestrador reabre o endereço se a extensão não der sinal em 40 s.
  - **[T-real]** O login automático passou a funcionar.
- **[P] 09:45 — Pergunta sobre as "Deferida e consolidada".** O usuário perguntou se a parada na análise era intencional e pediu explicação antes de mudar o código.
- **[P] 10:11 — Lentidão e aviso da Caixa Postal.** **[I] v0.29.0:**
  - **Lentidão:** repete a etapa até 2 vezes; depois recarrega a página (F5) até 2 vezes; depois marca erro `[lentidao]`, e o orquestrador refaz o mesmo CNPJ.
  - **Caixa Postal ("Você possui mensagens importantes"):** salva `Caixa_Postal_<CNPJ>.pdf` sem abrir nenhuma mensagem e continua. Se o e-CAC exigir a leitura, pausa.
  - **[T-sim]** OK.
- **[P] 10:38 — Erro 93003** ("número máximo de dispositivos conectados").
  - **[I] v0.29.1 — Causa:** o Chrome era fechado sem sair do e-CAC, então cada CNPJ deixava uma sessão aberta.
  - **Correções:**
    - "Sair com Segurança" antes do aviso final ao orquestrador;
    - na página do 93003, espera 60, 180 e 300 s e tenta de novo; depois pausa. Nunca pula o CNPJ.
  - **[T-sim]** OK. **[T-real]** O erro não voltou a aparecer nos registros depois disso.
- **[P] 11:01 — Travou no fim de um CNPJ.**
  - **[I] v0.29.2:** a aba do e-CAC, que estava atrás das outras, vem para a frente antes do "Sair"; há tempo máximo de 25 e 60 s.
  - Chrome fechado pelo usuário = o CNPJ volta a pendente e o orquestrador **para** (não abre o próximo).
- **[P] 11:04 — Rodar sem depender do Claude, e distribuir.**
  - **[I]** `INICIAR_AUTOMACAO.bat`, `VER_ANDAMENTO.bat`, `INSTALAR.bat` e `instalacao\instalar.ps1`.
  - **[I]** `GERAR_PACOTE.bat` (zip sem dados) e `LEIA-ME.txt`.
- **[P] 12:59 — Cookies e parcelas com cálculo prévio.**
  - **Cookies:** aceitar o aviso da PGFN ("Permitir").
  - **Janela de emissão com "Receita bruta" e "Calcular":** a regra do usuário era **não inventar valores financeiros**.
  - **[I] v0.30.0:** clica em "Permitir"; a janela com "Calcular" **pausava** pedindo a receita.
- **[P] 13:20 — Decisão do usuário:** "não é necessário informar nenhum valor; basta clicar em Calcular".
  - **[I] v0.30.1:** clica em "Calcular" com o valor já apresentado, sem digitar nada, e emite.
  - Só pausa se o sistema não liberar o "Emitir" com "Valor da Prestação" maior que 0.
  - **[T-sim]** OK. **[T-real]** 13:30–14:01: conta 5585667, parcelas 0013 em diante, 36 documentos emitidos e salvos.
- **[P] 14:40 — Janela "Salvar como" travada** (14:23, CNPJ 90000010000110; 14:32, CNPJ 90000011000164).
  - **[I] v0.31.0 + ajudante 1.3 — Causa provada:**
    - os downloads da extensão (prints e relatórios) ficam no perfil **normal** do Chrome; os PDFs do site, na janela **anônima**;
    - cada perfil numera os seus downloads, e o **mesmo número** existia nos dois;
    - resultado: o Chrome perdia o nome sugerido, a extensão lia o item errado e o relatório chegou a registrar o print de outra conta como documento.
  - **Correções:**
    - identificação do download por **número + perfil**;
    - o ajudante escreve o caminho certo no campo "Nome" (WM_SETTEXT + EN_CHANGE), nunca sobrescreve (usa "(1)") e fecha a janela de forma controlada;
    - até 3 tentativas do link do PDF; depois, pausa;
    - validação: o arquivo tem de ser desta prestação, estar na pasta do CNPJ e começar com `%PDF` no disco.
  - **[T-sim]** OK, inclusive com janelas "Salvar como" reais do Windows. **[T-real]** Os salvamentos das 16:52 e 16:56 passaram de primeira.
  - Os dois CNPJs afetados foram marcados como concluídos, a pedido (os PDFs foram salvos à mão).
- **[P] 15:20 — Erro 10000 da Receita** ("não foi possível validar os seus dados").
  - **[I] v0.31.1:** salva `Problema_receita_federal_<CNPJ>.pdf` e encerra o CNPJ como "erro" (não concluído). **[T-sim]**
- **[P] 15:29 — Erro 500 do e-CAC** ("Ocorreu um erro interno").
  - **[I] v0.31.2:** até 5 tentativas por CNPJ, com espera crescente (15 a 120 s). As 2 primeiras recarregam a página; as outras voltam ao login.
  - Esgotadas as tentativas, salva `Erro_500_<CNPJ>.pdf` e encerra como "erro". **[T-sim]**

## Fase 5 — Interface, certificados e pastas por certificado (09/11/2026, tarde)

- **[P] 15:41 — Interface para vários certificados e listas.**
  - Escolher o certificado pelo **nome exato**; avisar se houver duplicados e não começar se ele não existir.
  - Organizar as pastas em `<CERTIFICADO>\<CNPJ>`.
  - Acompanhar a execução, com Pausar e Retomar.
- **[I] v0.32.0 + ajudante 1.4 — `Automacao_PGFN.exe`** (C# WinForms compilado pelo .NET do Windows):
  - configurações em `configuracoes\` e andamento próprio por configuração;
  - validação de CNPJ, remoção de repetidos, seleção exata do certificado;
  - Pausar, Retomar e Parar, sempre entre um CNPJ e outro.
  - **[T-sim]** autoteste, telas capturadas, orquestrador sem Chrome e simulador.
- **[P] 16:08 — Pasta `ATM_PGFN` portátil para distribuição.**
  - **[I]** `Downloads\ATM_PGFN` (cópia; a `Auto_PGFN` ficou intacta, mais um backup em zip): `Instalar.bat`, `Iniciar.bat`, `README.md` e `ATM_PGFN.zip`.
  - Documentos passam a ir para `<Downloads do Chrome>\ATM_PGFN\Documentos_arrecadacao\<CERT>\<CNPJ>`.
  - **[T-sim]** zip extraído em outra pasta e validado (interface, ajudante pelo protocolo do Chrome, "Salvar como" real, orquestrador, instalador).
  - **[pendente]** a comunicação extensão ↔ ajudante pelo Chrome usando a ATM.
- **[P] 16:21–16:30 — Uso da interface.** Passo a passo para o outro PC; colar só os CNPJs, um por linha.
  - O usuário salvou a lista de 23 CNPJs (a configuração "Lista_23_cnpjs").
  - A lista importada também ficou com os mesmos 23, salva por cima.
- **[P] 17:16 — "Travou aqui"** (às 17:12).
  - **[I] — Causa provada:** o arquivo de log estava ocupado por um instante, o `Add-Content` deu erro e o orquestrador fechou sem avisar.
  - Sem o orquestrador, a extensão caiu no modo manual e processou o CNPJ de teste fixo (90000006000151).
  - **Correções:** o log tenta de novo e nunca derruba o orquestrador; o erro inesperado fica registrado; `CNPJS_TESTE = []`.
  - **[T-sim]** log travado por 8 s: antes o orquestrador morria; agora continua.

## Fase 6 — Recuperação automática de travamentos (09/11/2026, noite)

- **[P] 17:25 — Detectar e recuperar travamentos, checkpoint, salvamento mais robusto, sem duplicados.**
- **[I] v0.33.0 + ajudante 1.5:**
  - **Sinal de progresso:** a extensão envia `orq-progresso` sempre que o aviso da tela muda, no máximo a cada 15 s. O checkpoint vai junto: certificado, CNPJ, etapa, conta, parcela, fase e PDFs salvos.
  - **Vigia do orquestrador:**
    - 8 min sem progresso e sem pausa para o usuário = travamento;
    - primeiro fecha uma janela "Salvar como" aberta, se houver, e espera a automação seguir;
    - depois reabre o Chrome **no mesmo CNPJ**, até 3 vezes;
    - depois **PAUSA**: Retomar tenta de novo, Parar deixa o CNPJ pendente. Nunca pula o CNPJ.
  - **Registro dos PDFs salvos também em disco** (`registro_salvos.json`), protegido contra duas gravações ao mesmo tempo.
  - **Prints do mesmo dia com a mesma situação** não são salvos de novo.
  - **Interface:** mostra o motivo da pausa e a conta e a parcela em processamento.
  - **[T-sim]**
    - orquestrador e ajudante reais com Chrome simulado: normal, trava uma vez, pausa de captcha, trava com "Salvar como" real, trava sempre (pausa, Retomar, Parar);
    - 8 gravações simultâneas no registro sem perda;
    - simulador do SISPAR: uma segunda rodada sem emissão repetida.
  - **[pendente]** teste real.
- **[P] 10/11 — Este pedido:** documentar tudo para continuar em outro chat. Nenhuma mudança na automação.

## Fase 7 — "Congelamento" no fim da lista (10/11/2026, manhã) — v0.33.1 + ajudante 1.6

- **[T-real] 10/11, 08:18–09:19 — Execução real com o orquestrador 0.33 (13 pendentes):** o usuário rodou "Lista_23_cnpjs" e a automação **continuou de onde tinha parado**, a partir do 90000031000135.
  - **Atenção:** a extensão carregada no Chrome **não** era a 0.33.0, porque não foi recarregada. O `ajudante.log` não tem nenhum pedido `orq-progresso` nem `registro-gravar`, que só a 0.33.0 envia, e o `registro_salvos.json` não existe.
  - Portanto o checkpoint, o registro em disco e o anti-duplicado de prints da extensão 0.33 **continuam sem teste real**. O orquestrador 0.33 rodou sem problemas com a extensão anterior.
  - Fez os 11 pendentes e tentou de novo o 90000025000188, que voltou a dar erro por não haver procuração.
  - **Resultado:** 22 de 23 concluídos às 09:19:10, segundo o `orquestrador.log`.
  - Não houve TRAVAMENTO, recuperação nem pausa no log. O vigia não precisou agir.
- **[P] 10/11, ~09:30 — "A página ficou congelada":**
  - **Print:** página do e-CAC "Logout realizado com sucesso". No canto, o aviso da extensão: "login automático desligado: a sessão do e-CAC foi encerrada no fim deste CNPJ; o orquestrador fecha o Chrome e segue. Faça o login você mesmo."
  - **Pedido:** detectar o bloqueio, fechá-lo, recuperar pelo checkpoint e continuar, sem duplicar nada.
- **Causa (verificada no `orquestrador.log`, no `ajudante.log` e no código): não era travamento.**
  - O CNPJ 90000040000126 era o **último** da lista. A extensão fez "Sair com Segurança" e avisou "concluido". O orquestrador registrou e **terminou a lista**, como deveria.
  - No fim da lista, o orquestrador **não fecha o Chrome**; ele só fecha antes de abrir o próximo CNPJ.
  - O aviso na tela era um texto fixo do `background.js` (`orq-atual` com `CHAVE_SAIU_ECAC`), que sempre dizia "o orquestrador fecha o Chrome e segue", **mesmo quando não havia próximo CNPJ**. Por isso parecia congelado.
  - Também não havia janela nem diálogo bloqueando: o aviso é só um texto da extensão (`pointer-events:none`). Não havia nada a fechar nem a recuperar.
- **[I] Correção pontual:** o fim da execução passou a ser registrado e mostrado com clareza.
  - **Orquestrador:** ao sair, no `finally` e antes de apagar o `atual.json`, grava `ultima_execucao.json`:
    - `encerramento`: `terminou`, `parada`, `chrome_fechado` ou `erro`;
    - `nome`, `config`, `fim`, `total`, `concluidos`, `erros`, `pendentes`.
    - A gravação é apagada no começo de cada nova execução. Nos testes `-SemChrome`, o arquivo é `ultima_execucao_teste.json`.
  - **Ajudante 1.6:** sem CNPJ da vez, o `orq-atual` lê o `ultima_execucao.json` (válido por 12 h) e devolve `fim:true` + `encerramento` + `motivo`, por exemplo: "AUTOMAÇÃO TERMINADA às 09:19: a lista "Lista_23_cnpjs" chegou ao fim (22 de 23 CNPJ(s) concluído(s), 1 com erro). Nada está travado; pode fechar o Chrome".
    - Se o `atual.json` existe mas o processo do orquestrador morreu: `parado:true` + "o orquestrador parou antes de terminar… Iniciar continua de onde parou".
  - **`background.js`:** depois do "Sair" do e-CAC, o `orq-atual` **consulta o ajudante**.
    - Se o orquestrador terminou ou parou, repassa o motivo.
    - Se ainda está rodando, ou o ajudante não responde, continua desligado com o aviso "…fecha o Chrome e segue para o próximo".
    - O login automático **nunca** é religado depois do "Sair".
  - **`content.js` (`fluxoLogin`):** com `fim:true`, mostra o motivo em verde, ou em vermelho se o encerramento foi `erro`, e **não** pede login.
  - **Interface:** sem execução em andamento, a linha de estado mostra como terminou a última. Exemplo: "TERMINADA em 10/11 09:19 (Lista_23_cnpjs): 22 de 23 concluídos, 1 com erro, 0 pendentes. Pode fechar o Chrome."
  - **Foi criado neste PC** o `Auto_PGFN\orquestrador\ultima_execucao.json` com os dados reais da execução das 09:19 (do log), para a tela já explicar o fim depois de recarregar a extensão.
  - **Não mudou:** vigia, checkpoint, salvamento, nomes, pastas, login, erros 500/10000/93003, Caixa Postal e prints.
  - **Decisão:** o orquestrador continua **sem fechar o Chrome no fim da lista**. A última tela fica à vista e ele não fecha janelas do usuário sem necessidade.
- **[T-sim]**
  - **`teste_fim_lista.ps1`, novo:** orquestrador e ajudante reais em pasta temporária, com Chrome simulado. Cenários:
    - lista de 2 CNPJs até o fim (`terminou` 2/2; motivo "AUTOMAÇÃO TERMINADA");
    - lista já concluída ("nada a fazer" não estraga o resumo);
    - Parar no meio (`parada`, 1 concluído e 1 pendente);
    - retomada depois de parar (só o pendente é refeito; `terminou` 2/2);
    - orquestrador morto com o `atual.json` ainda lá (`parado`);
    - resumo com mais de 12 h (ignorado);
    - sem arquivos (como antes);
    - versão 1.6.
    - Tudo OK na Auto_PGFN e na ATM_PGFN.
  - **`teste_sair_ecac.js`, atualizado:** depois do "Sair", consulta só o `orq-atual`, continua desligado com o orquestrador ativo, repassa o "terminou" e, sem ajudante, continua desligado. Tudo OK.
  - **Regressão OK:**
    - `teste_background`, `teste_registro_bg`, `teste_salvamento_bg` e `teste_downloads`;
    - o `--autoteste` das duas interfaces;
    - o vigia: `conclui`, `trava-uma-vez`, `pausa`, `janela` "Salvar como" real e `trava` com Retomar e Parar;
    - `teste_portabilidade.js` com o zip novo.
- **[pendente]** ver no site real o aviso novo no fim de uma lista. Exige recarregar a extensão para 0.33.1.

## Fase 8 — Sem procuração definitivo, "Sair" com a janela aberta e contador de progresso (10/11/2026) — v0.34.0 + ajudante 1.7

- **[T-real] 10/11, 09:51–09:52:** o usuário clicou em Iniciar de novo na "Lista_23_cnpjs".
  - O `ajudante.log` tem `orq-progresso`: a extensão já era a 0.33.x.
  - Como só restava o 90000025000188 ("erro"), ele foi tentado pela **3ª vez**. O e-CAC respondeu de novo "Não existe procuração eletrônica para o detentor 90.000.001/0001-29 do certificado digital apresentado".
  - **Print do usuário:** a janela "Alterar perfil de acesso" ficou aberta com o aviso, a seta em "Sair com Segurança" e o aviso "fim do CNPJ: encerrando a sessão do e-CAC…". A página não saiu.
- **[P]** tratar a falta de procuração de forma definitiva: detectar, print `Sem_Procuracao_<CNPJ>.pdf`, registrar, não repetir, fechar a janela pelo X, "Sair com Segurança" confirmado e seguir. Também pediu um **contador** de CNPJs: total, concluídos, com erro, restantes, atual e %.
- **Causa (no código e nos logs):**
  1. **Repetição:** o orquestrador só considerava final a situação `concluido` (`$FINAIS`). A falta de procuração virava `erro`, e todo `erro` é refeito no próximo Iniciar, como deve ser para 500, 10000 e lentidão. Por isso o mesmo CNPJ foi tentado 3 vezes.
     - O tratamento na extensão (`conferirTopo`) vinha do modo de teste: anota e tenta o próximo da `CNPJS_TESTE`.
     - Com o orquestrador só há um CNPJ, então ela lançava o erro "…para nenhum dos CNPJs de teste", **sem print**.
  2. **"Sair" preso:** no fim do CNPJ, o `sairComSeguranca` clicava em "Sair com Segurança" com a janela "Alterar perfil de acesso" **aberta por cima**, e o e-CAC não encerrou a sessão.
     - O `background.js` esperou 15 s pela mudança de página, não houve, e avisou o orquestrador do mesmo jeito.
     - O log não dizia se a sessão foi encerrada. Uma sessão aberta conta para o limite do erro 93003.
     - Como era o último CNPJ da lista, o Chrome ficou nessa tela.
- **[I] Correções:**
  - **`content.js`:**
    - **`tratarSemProcuracao(cnpj)`:** só com o orquestrador; no modo de teste, sem orquestrador, continua como antes.
      - Mostra o aviso e salva o print da tela **com a mensagem visível** em `<pasta do CNPJ>\Sem_Procuracao_<CNPJ>.pdf`, pela `salvarPrintEmPdf`, que não salva de novo no mesmo dia e nunca sobrescreve.
      - Confere o PDF no disco, fecha a janela pelo X e lança `[sem_procuracao] Não existe procuração eletrônica do certificado "<cert>" para o CNPJ <cnpj>…`.
      - Não recarrega (F5) nem repete. Esse erro não é tratado como lentidão: `ERRO_DEFINITIVO` já cobre "procuração".
    - **`fecharJanelaPerfil()`**, com `acharJanelaPerfilAberta()` e `acharXDaJanela()`, até 2 tentativas.
      - Fecha a janela "Alterar perfil de acesso" **só pelo X dela**.
      - Procura o X pelo título ou rótulo ("Fechar", "Close", `.ui-dialog-titlebar-close`), pelo texto "x"/"×" ou, como no e-CAC real (quadrado laranja sem texto), pelo pequeno elemento clicável no canto de cima à direita da caixa.
    - **`sairComSeguranca()`:**
      - primeiro fecha a janela;
      - "Sair com Segurança" não encontrado = sem sessão ativa, e devolve isso;
      - clica e espera 7 s; se a página não saiu, fecha a janela de novo e repete (2 vezes no máximo);
      - por último, abre o endereço (`href`) do próprio "Sair", se for um endereço real;
      - sem loop: devolve `clicou:false` e o motivo.
  - **`background.js`:**
    - a aba tem até 45 s para responder ao `sair-ecac` (antes 25 s) e o `orq-finalizar` tem até 75 s (antes 60 s);
    - a mensagem ao orquestrador ganha a linha **"Sessão do e-CAC: encerrada ("Sair com Segurança")"** ou **"não confirmada (motivo)"**.
  - **`orquestrador.ps1`:**
    - `$FINAIS = concluido, sem_procuracao`; o resultado `erro` com `[sem_procuracao]` é registrado como `sem_procuracao`, sem recuperação e sem nova tentativa;
    - **migração:** um `erro` antigo cuja mensagem é "não existe procuração eletrônica…" vira `sem_procuracao` ao carregar o andamento. Foi o caso do 90000025000188, que fica sem o print; para gerar o print, use "Refazer sem procuração";
    - **contador** `Contagem`/`Log-Progresso`: linha `PROGRESSO: X de N analisados (P%) | concluídos | com erro | sem procuração | restantes` no início, depois de cada CNPJ e no fim;
    - o `ultima_execucao.json` ganhou `semProcuracao` e `percentual`.
  - **Ajudante 1.7:** o resumo do fim inclui "N sem procuração".
  - **Interface:**
    - **contador:** "Total de CNPJs · Analisados · Progresso %", "Concluídos · Com erro · Sem procuração · Restantes", **barra de progresso**, CNPJ em processamento e etapa. Lê o andamento, que é o checkpoint em disco: sobrevive a reinícios e conta cada CNPJ uma vez (`Distinct`);
    - **botão "Refazer sem procuração":** depois de criar a procuração, os `sem_procuracao` voltam a `pendente`. Guarda cópia `.antes_refazer_<data>` e não mexe nos outros;
    - **`--autoteste`:** novo teste do refazer.
  - **Não mudou:** login, certificado, troca de perfil normal, Dívida Ativa, Regularize, SISPAR, cálculo, emissão, downloads, nomes, pastas, Caixa Postal, erros 500/10000/93003 e vigia.
- **[T-sim]**
  - **Simulador de páginas** (`index.html`, ganhou o X sem texto, "Sair" que não funciona com a janela aberta e `capturar`/`conferir-arquivo`/`orq-finalizar`). Com `orq` + `semproc`, extensão 0.34 real no painel do navegador:
    1. **X sem texto:** print `Sem_Procuracao_90000003000118.pdf` com o aviso visível, janela fechada pelo X (1 clique), "Sair" clicado 1 vez **sem** a janela, sessão encerrada e `[sem_procuracao]` enviado;
    2. **X com "×":** igual;
    3. **janela sem X** (falha ao fechar): print salvo, "Sair" tentado 2 vezes e parou, com `clicou:false` e o motivo, e "(não consegui fechar a janela…)" na mensagem. Sem loop;
    4. **página normal sem janela:** "Sair" clicado 1 vez e saiu (regressão).
  - **`teste_sem_procuracao.ps1`, novo** (orquestrador e ajudante reais, com Chrome simulado):
    - 4 CNPJs, 1 sem procuração e 1 `erro` antigo de procuração;
    - registra `sem_procuracao`; migra o antigo sem abrir o Chrome para ele (3 aberturas); sem recuperação nem travamento;
    - linhas PROGRESSO 1/4 (25%) → 2/4 → 3/4 → 4/4 (100%) e a linha da sessão do e-CAC no log;
    - resumo com 2 concluídos, 2 sem procuração e 100%;
    - **2ª execução:** "nada a fazer" e o Chrome não abre;
    - **depois de "refazer":** só os 2 são refeitos.
    - OK na Auto e na ATM.
  - **Regressão:**
    - `teste_fim_lista` (8 cenários);
    - `teste_sair_ecac` (limite do caso C ajustado para os 45 s);
    - `teste_background`, `teste_registro_bg`, `teste_salvamento_bg` e `teste_downloads`;
    - vigia: `conclui`, `trava-uma-vez`, `pausa`, `janela` e `trava` com Retomar e Parar;
    - `--autoteste` das duas interfaces, com print da janela conferido;
    - `teste_portabilidade` com o zip novo;
    - sintaxe dos `.ps1` e `node --check`.
- **[pendente]**
  - ver no site real o X da janela verdadeira do e-CAC, o print e o "Sair" depois do sem procuração (precisa recarregar a extensão para **0.34.0**);
  - confirmar na tela real o contador da interface durante uma lista.

## Fase 9 — Pastas avulsas consolidadas na CERT_A e pasta do certificado sempre definida (10/11/2026, 12:50) — orquestrador 0.34.1
- **Pedido:** as pastas `<CNPJ>` soltas em `Documentos_arrecadacao` (dos testes) eram da CERT_A. Juntar tudo na pasta do certificado sem duplicar, apagar as avulsas depois de validar e corrigir o destino dos próximos salvamentos.
- **Feito nos arquivos existentes (sem novo download):**
  - 25 pastas avulsas e 116 arquivos comparados por SHA-256 com a pasta da CERT_A;
  - 48 copiados e conferidos (hash, PDF íntegro, CSV legível), 68 duplicados ignorados e 3 com nome igual e conteúdo diferente gravados com ` (avulsa 1)`;
  - 16 pastas de CNPJ novas na CERT_A, que ficou com 38 pastas e 187 arquivos; 0 erros;
  - as avulsas foram movidas para `Auto_PGFN\_recuperacao\pastas_avulsas_CERT_A_2026-11-10_1242\`, com `relatorio_consolidacao.csv`.
- **Causa:** o modo manual de 06/11 e o `cnpjs.json` antigo de 09/11 (sem `pasta`/`exato`) deixavam a pasta do certificado vazia, e a extensão salvava em `Documentos_arrecadacao\<CNPJ>`.
- **Correção:** `orquestrador.ps1` sempre define a pasta do certificado. Usa a pasta da configuração; senão, uma pasta existente que começa com o nome do certificado; senão, o nome convertido. Nada mais foi alterado.
- **Testes:** `teste_pasta_certificado.ps1` (novo), `teste_sem_procuracao` e `teste_fim_lista`, TUDO OK nas duas pastas.- **README.md do pacote (10/11, 13:00):** o manual que vai no `ATM_PGFN.zip` estava em 09/11 e foi atualizado: ajudante 1.7 e extensão 0.34.0 no teste do `Instalar.bat`; contador (percentual, barra, concluídos, com erro, sem procuração, restantes, linha `PROGRESSO` no log); "TERMINADA"/"Parada" no fim; botão **Refazer sem procuração**; arquivo `Sem_Procuracao_<CNPJ>.pdf` e o tratamento da falta de procuração; pasta sempre por certificado; `.csv` abre no Excel/LibreOffice; `ultima_execucao.json`. Zip gerado de novo e conferido: README igual ao da pasta, 21 arquivos, nenhum dado de cliente.
## Fase 10 — Salvamento do PDF: número de download repetido e "encerrar e avançar" (10/11/2026, 14:40) — v0.35.0 + ajudante 1.8
- **Pedido:** com o certificado CERT_B, o salvamento travou (imagem: conta 14652591, prestação 0011, PDF 7172631466259011, "o arquivo salvo (print_confirmacao_conta_5535214.pdf) não é o documento desta prestação"). Corrigir a origem e, se a recuperação falhar, não pausar sem prazo: até 3 tentativas, evidência, registro, encerrar a sessão e seguir para o próximo CNPJ.
- **Causa:**
  - o print da conta anterior (perfil normal, da extensão) e o PDF do site (janela anônima) tinham o mesmo número de download, e o background leu o print como resultado do documento (mesmo padrão de 09/11);
  - a conferência barrou, mas como "não repetível", e foi para a pausa sem prazo, que o vigia não trata como travamento. A pausa repetia a confusão, então nem o PDF salvo à mão (`7172631466259011.pdf`) foi reconhecido.
- **Correções:**
  - `background.js`: download = número + perfil + origem (`acharItemAssociado`/`itemConfere`), e `procurar-documento`;
  - ajudante 1.8: `Procurar-Documento` (o PDF no disco, por nome ou número, depois do início da prestação, com `%PDF`);
  - `content.js`: arquivo de outra coisa é repetível; disco conferido antes de cada nova tentativa; com o orquestrador, `desistirDoSalvamento` (evidência `Falha_Salvamento_…pdf`, registro, janela fechada, erro definitivo `[falha_salvamento]` → "Sair com Segurança" → próximo CNPJ);
  - `orquestrador.ps1`: linha de resultado própria.
- **Também:** o PDF salvo à mão (CERT_B 90000002000173, conta 14652591, prestação 0011) foi registrado no registro permanente, para não ser emitido de novo.
- **Testes:**
  - `teste_colisao_bg.js` (novo; no 0.34.0 reproduz o print como resultado), `teste_procurar_documento.js` (novo) e `teste_falha_salvamento.ps1` (novo);
  - simulador: 4 cenários;
  - regressão completa e portabilidade com o zip novo. Tudo OK nas duas pastas.
- **Pendente:** recarregar a extensão (0.35.0) e validar no site real.
## Fase 11 — SISPAR "Você não tem permissão de acesso ou ele expirou" e página de acesso sem botão (10/11/2026, 15:15) — v0.36.0
- **Pedido:** com o certificado CERT_B (CNPJ 90000026000122, 3ª negociação), o SISPAR respondeu "Você não tem permissão de acesso ou ele expirou. Feche o navegador, retorne ao Regularize e tente novamente". A automação deve reconhecer o erro, registrar e salvar o checkpoint, encerrar a sessão, reabrir o Chrome e refazer o MESMO CNPJ (até 3 vezes), sem duplicar documentos. Persistindo, deixar pendente e avançar.
- **Causa:**
  - na análise das negociações o erro não era reconhecido: virou "não encontrei a tabela…", foi tratado como lentidão e repetido na mesma página, o que não adianta;
  - depois, a página de acesso do e-CAC sem o botão "Entrar com gov.br" levou a uma pausa "aguardando você" sem prazo. Houve um recarregamento da extensão no meio da execução (`versao` às 14:54:29).
  - Nas outras 2 etapas em que o erro já era reconhecido, o orquestrador avançava para o próximo CNPJ em vez de refazer o mesmo.
- **Correções:**
  - `content.js`: `percorrerDeferidas` reconhece o erro; `erroSemPermissao` (com o orquestrador) registra o contexto e lança `[sessao_pgfn]` definitivo; `loginEcac` sem o botão faz 1 recarga e depois `[lentidao]`, sem pausa (captcha continua pausa);
  - `orquestrador.ps1`: `[sessao_pgfn]` → recuperação no mesmo CNPJ (3x) → depois `erro` e próximo, sem pausa. O travamento comum não mudou.
- **Testes:**
  - `teste_sessao_pgfn.ps1` (novo, 12 verificações, A e B), TUDO OK;
  - simulador SISPAR `semperm=2` (reconhecido, 0 repetições, `[sessao_pgfn]`);
  - login sem botão, captcha e login normal;
  - regressão: `teste_falha_salvamento`, `teste_sem_procuracao`, `teste_fim_lista`, `teste_pasta_certificado`, os 5 cenários do vigia (o travamento comum continua pausando), `teste_colisao_bg`, `teste_salvamento_bg`, `teste_background`, `teste_sair_ecac`, `teste_proximo` e portabilidade do zip novo (0.36.0, 21 arquivos, sem dados de cliente). Tudo OK.
- **Pendente:** recarregar a extensão (0.36.0) com a automação parada e validar no site real.
## Fase 12 — Print da falta de procuração conferido (10/11/2026, 16:00) — v0.36.1
- **[P]** confirmar que o print `Sem_Procuracao_<CNPJ>.pdf` é tirado com a mensagem "Não existe procuração eletrônica…" visível, na pasta do CNPJ dentro da pasta do certificado, antes de fechar a janela, sair ou avançar; acrescentar a captura onde faltasse; mexer só na captura e no salvamento.
- **Constatado:** com o orquestrador já funcionava desde a 0.34.0 (print → X → `[sem_procuracao]` → "Sair" → próximo).
- **[C] Faltava:**
  - a conferência de que a frase ainda estava na tela no momento do print;
  - tratar como problema a falta de resposta da conferência do disco;
  - o print no modo manual (sem orquestrador), que ia direto ao F5.
- **[A]** `content.js`: função `printSemProcuracao` (usada nos dois caminhos); manifest 0.36.1.
- **[T]** no simulador:
  - com e sem pasta do certificado;
  - janela em iframe;
  - mensagem que some (sem print, com o motivo);
  - modo manual com lista (print antes do F5).
- **[T] Regressão:** `teste_sem_procuracao.ps1` TUDO OK; ATM sincronizada; zip 0.36.1 (21 arquivos) e portabilidade OK.
- **Pendente:** validar no site real; recarregar a extensão (0.36.1) com a automação parada.

## Fase 13 — Procuração cancelada (10/11/2026, 17:00) — v0.37.0
- **[P]** reconhecer o aviso "A procuração eletrônica cadastrada … foi cancelada em <data>" na janela "Alterar perfil de acesso", pelo trecho "foi cancelada em" (a data e o titular variam):
  - interromper a espera;
  - conferir o CNPJ do campo PJ;
  - tirar o print com a mensagem, a data e o CNPJ visíveis antes de fechar;
  - salvar em `<certificado>/<CNPJ>/Procuracao_Cancelada/Procuracao_Cancelada_<CNPJ>.pdf`;
  - confirmar o salvamento;
  - registrar "Pendente por procuração cancelada", com classificação própria e contador;
  - seguir para o próximo CNPJ, reaproveitando a rotina de captura.
- **[C]** caso real em 10/11 16:52 (CNPJ 90.000.027/0001-77): sem reconhecimento, a automação ficava em "aguardando a tela carregar para conferir o topo".
- **[A] `content.js`:**
  - `TEXTO_PROC_CANCELADA` e `tratarProcuracaoCancelada`;
  - `printDoAviso` (generalização da `printSemProcuracao`, que passou a usá-la);
  - `acharJanelaPerfilAberta` também pela frase nova;
  - manifest 0.37.0.
- **[A] `orquestrador.ps1`:**
  - `procuracao_cancelada` em `$FINAIS`;
  - `procCancelada` na `Contagem`, na linha PROGRESSO (só quando > 0) e no `ultima_execucao.json`;
  - log "Pendente por procuração cancelada".
- **[A] Ajudante:** só o texto do resumo (continua 1.8).
- **[A] Interface (Auto e ATM, compiladas):**
  - contador "Procuração cancelada";
  - o "Refazer sem procuração" inclui as canceladas;
  - autoteste novo.
- **[T] Testes:**
  - simulador: CNPJ certo, campo com outro CNPJ, sem procuração e troca normal;
  - `teste_proc_cancelada.ps1` (novo), Auto e ATM;
  - autoteste da interface nas duas;
  - regressão completa;
  - zip e portabilidade.
  - O `teste_sem_procuracao` falhou na 1ª rodada porque a linha PROGRESSO tinha mudado de formato. Agora o trecho novo só aparece quando há canceladas, e o teste voltou a passar.
- **Pendente:** validar no site real; recarregar a extensão (0.37.0) e reabrir a interface, com a automação parada.

## Fase 14 — Certificado fora da parte visível da lista (11/11/2026, 11:30) — v0.38.0 + ajudante 1.9
- **[P]** na janela "Selecione um certificado" (3 linhas visíveis, com rolagem), procurar o certificado configurado até o fim da lista:
  - focar a lista e começar pela 1ª linha;
  - ler o nome completo mesmo cortado;
  - rolar até a última linha;
  - uma única correspondência exata → selecionar, conferir e OK;
  - nenhuma ou várias → registrar o motivo e pausar;
  - nunca confirmar o destacado pelo Chrome se não for o configurado;
  - validar com um certificado que só aparece depois de rolar.
- **[C]** 11/11 10:19: "achei 0 certificado(s)…" porque a acessibilidade só expõe as linhas visíveis (o configurado era o 4º).
- **[A] Ajudante 1.9:**
  - `Linha-Em-Foco`, `Esperar-Foco-Mudar`, `Percorrer-Lista` (Home + seta ↓ pelo teclado, com o foco conferido dentro da janela antes de cada tecla);
  - `Nome-Confere`;
  - `Certificado` refeito: busca completa → contagem → seleção passo a passo conferida → conferência final nome+serial → OK.
- **[A] Extensão 0.38.0:** `chamarAjudante` com prazo por pedido (certificado 180 s).
- **[C] 1ª versão reprovada no teste real:** lia o nome pela "linha mãe" (reaproveitada pelo Chrome) e clicava numa linha meio escondida atrás do cabeçalho, o que ordenava a lista por "Tema". Corrigido: o nome vem do próprio foco; sem clique quando o foco já está na lista; clique só em linha inteira visível; sem clique antes do OK.
- **[E]** durante a troca da versão nos testes, um comando PowerShell trocou caracteres soltos em 3 arquivos de teste do scratchpad; restaurados das cópias da ATM, conferidos caractere a caractere.
- **[T] Testes:**
  - `teste_certificado_real.js` (novo, janela real, modo teste com Cancelar) OK com o ajudante da Auto e com o da ATM;
  - regressão completa OK;
  - zip e portabilidade OK.
- **Pendente:** o login completo com OK no site real (1ª execução); recarregar a extensão (0.38.0) com a automação parada. O ajudante 1.9 vale na hora: é lido a cada pedido.

## Fase 15 — Aviso de Caixa Postal encerra a análise do CNPJ (11/11/2026, 13:15) — v0.39.0
- **[P]** nova regra, que substitui o clique em "Ir para a Caixa Postal". Quando o aviso aparecer:
  1. print com o aviso visível, antes de fechar ou abrir a Caixa Postal;
  2. confirmar o CNPJ em processamento e salvar em `<certificado>/<CNPJ>/Caixa_Postal_<CNPJ>.pdf`;
  3. conferir o PDF; falha → rotina existente de recuperação de salvamento;
  4. registrar "Aviso de Caixa Postal" como motivo do encerramento, atualizar o contador e ir direto para o próximo CNPJ.
  - Só quando o aviso aparecer.
- **[A] Extensão 0.39.0 (`content.js`, `tratarAvisoCaixaPostal` refeita):**
  - não clica em nada;
  - o cabeçalho tem que ser o CNPJ em processamento;
  - print pela rotina existente (`printDoAviso`), conferido no disco, até 3 tentativas sem duplicar;
  - lança `[caixa_postal]` (definitivo);
  - 3 falhas → `[falha_salvamento]` (o CNPJ fica pendente e a fila segue);
  - aviso de outro perfil (ex.: do titular, antes da troca) ou cabeçalho ilegível → não salva e pausa, como antes.
- **[A] Orquestrador:** situação final `caixa_postal`, contador `caixaPostal` (PROGRESSO, `ultima_execucao.json`), log "Aviso de Caixa Postal".
- **[A] Interface:** contador "Aviso de Caixa Postal: N"; "Refazer sem procuração" também volta esses CNPJs a pendente; autoteste.
- **[A] Ajudante:** só o resumo de fim de lista (", N com aviso de Caixa Postal"); a versão continua 1.9.
- **[T] Testes:**
  - simulador do e-CAC com o `content.js` real, 4 cenários OK (aviso do CNPJ, 1 falha de captura, 3 falhas, aviso do titular);
  - `teste_caixa_postal.ps1` (novo) OK na Auto e na ATM;
  - regressão, autoteste das duas interfaces, zip e portabilidade OK.
- **Pendente:** o aviso real ainda não apareceu em nenhuma execução registrada (não testado no site real). Recarregar a extensão (0.39.0) com a automação parada.
