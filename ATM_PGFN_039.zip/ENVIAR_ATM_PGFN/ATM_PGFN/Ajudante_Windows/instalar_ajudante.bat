@echo off
rem Instala o ajudante "Salvar como" da Automacao_PGFN (usuario atual; nao precisa de administrador).
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalar_ajudante.ps1" %*
pause