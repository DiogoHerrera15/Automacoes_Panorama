@echo off
rem Ajudante da Automacao_PGFN: o Chrome chama este arquivo (native messaging) para confirmar a janela "Salvar como".
rem NADA pode ser escrito na saida padrao antes do PowerShell: ela e o canal do protocolo com o Chrome.
rem (Um "echo ... %*>> arquivo" aqui quebrava tudo: o Chrome passa "--parent-window=0" e o "0>>" desviava o texto
rem para a saida padrao.) O registro de cada pedido fica no ajudante.log, gravado pelo salvar_como.ps1.
powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0salvar_como.ps1"