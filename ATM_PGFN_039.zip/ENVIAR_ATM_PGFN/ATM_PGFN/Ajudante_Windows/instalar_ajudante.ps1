﻿# Instala o ajudante "Salvar como" da Automação_PGFN para o usuário atual do Windows (não precisa de administrador).
# O que faz:
#  1. acha o ID da extensão Automação_PGFN nos perfis do Chrome (só lê; ou use -IdExtensao);
#  2. grava com_auto_pgfn_salvar_como.json nesta pasta (diz ao Chrome qual programa chamar e qual extensão pode chamar);
#  3. registra esse arquivo em HKCU\Software\Google\Chrome\NativeMessagingHosts\com.auto_pgfn.salvar_como.
# Para remover: desinstalar_ajudante.bat.
param([string]$IdExtensao = '', [switch]$SoTestar)
$ErrorActionPreference = 'Stop'
$aqui = Split-Path -Parent $MyInvocation.MyCommand.Path
$NOME = 'com.auto_pgfn.salvar_como'

if (-not $IdExtensao) {
  $achados = @()
  $raiz = Join-Path $env:LOCALAPPDATA 'Google\Chrome\User Data'
  foreach ($arq in (Get-ChildItem -Path $raiz -Recurse -Depth 1 -Include 'Secure Preferences', 'Preferences' -File -ErrorAction SilentlyContinue)) {
    try { $prefs = Get-Content -LiteralPath $arq.FullName -Raw -Encoding UTF8 | ConvertFrom-Json } catch { continue }
    $ext = $prefs.extensions.settings
    if (-not $ext) { continue }
    foreach ($p in $ext.PSObject.Properties) {
      $caminho = [string]$p.Value.path
      if ($caminho -and ($caminho.TrimEnd('\') -ieq (Join-Path (Split-Path $aqui -Parent) 'Extensao_Chrome'))) { $achados += [pscustomobject]@{ id = $p.Name; caminho = $caminho; perfil = $arq.Directory.Name } }
    }
  }
  $achados = @($achados | Sort-Object id -Unique)
  if ($achados.Count -eq 0) {
    Write-Host 'Não achei a extensão (pasta ATM_PGFN\Extensao_Chrome) no Chrome. Abra chrome://extensions, copie o ID dela e rode:'
    Write-Host '  powershell -ExecutionPolicy Bypass -File instalar_ajudante.ps1 -IdExtensao <ID>'
    exit 1
  }
  if ($achados.Count -gt 1) { Write-Host "Achei a extensão em mais de um lugar; autorizando todos: $($achados.id -join ', ')" }
  $ids = $achados.id
} else {
  $ids = @($IdExtensao.Trim())
}
foreach ($i in $ids) { if ($i -notmatch '^[a-p]{32}$') { Write-Host "ID inválido: $i"; exit 1 } }

$manifesto = [ordered]@{
  name = $NOME
  description = 'Automação_PGFN: confirma a janela Salvar como do Chrome na pasta do CNPJ e confere o PDF salvo'
  path = (Join-Path $aqui 'salvar_como.bat')
  type = 'stdio'
  allowed_origins = @($ids | ForEach-Object { "chrome-extension://$_/" })
}
$arqManifesto = Join-Path $aqui 'com_auto_pgfn_salvar_como.json'
if ($SoTestar) { Write-Host "TESTE (nada gravado). IDs: $($ids -join ', ')"; $manifesto | ConvertTo-Json; exit 0 }
[IO.File]::WriteAllText($arqManifesto, ($manifesto | ConvertTo-Json), (New-Object Text.UTF8Encoding $false))
$chave = "HKCU:\Software\Google\Chrome\NativeMessagingHosts\$NOME"
New-Item -Path $chave -Force | Out-Null
Set-ItemProperty -Path $chave -Name '(default)' -Value $arqManifesto
Write-Host "Ajudante instalado para a extensão $($ids -join ', ')."
Write-Host "Manifesto: $arqManifesto"
Write-Host 'Agora recarregue a extensão em chrome://extensions.'
