@echo off
rem Remove o ajudante "Salvar como" da Automacao_PGFN.
reg delete "HKCU\Software\Google\Chrome\NativeMessagingHosts\com.auto_pgfn.salvar_como" /f
del "%~dp0com_auto_pgfn_salvar_como.json" 2>nul
echo Ajudante removido.
pause