﻿# Ajudante da Automação_PGFN (native messaging do Chrome).
# A extensão não consegue clicar na janela "Salvar como" do Windows, porque ela não faz parte da página. Este
# script recebe um pedido da extensão, acha essa janela, confere a pasta, o nome e o tipo, e só então clica em
# "Salvar". Também confere se o PDF salvo existe e começa com "%PDF".
#
# Regras de segurança:
# - só mexe em janelas "Salvar como"/"Save As" do próprio Chrome (processo chrome.exe);
# - só mexe na janela do documento pedido (nome pedido ou o número do documento que o site deu); se a pasta não for
#   ...\ATM_PGFN\Documentos_arrecadacao\[<CERTIFICADO>\]<CNPJ> ou o nome não for o pedido, escreve o caminho completo certo no campo
#   "Nome" antes de clicar em "Salvar" (desde 1.3; antes só recusava e a janela ficava aberta);
# - "cancelar": fecha (botão "Cancelar") só a janela desse documento, para a extensão tentar de novo;
# - nunca sobrescreve: se o Windows perguntar se quer substituir, responde "Não" e cancela;
# - só lê arquivos dentro de uma pasta ATM_PGFN.
#
# Protocolo: uma mensagem por chamada (chrome.runtime.sendNativeMessage). Entrada e saída em JSON, precedidas de 4
# bytes com o tamanho (formato do Chrome).
$ErrorActionPreference = 'Stop'

function Ler-Mensagem {
  $entrada = [Console]::OpenStandardInput()
  $cab = New-Object byte[] 4
  $lidos = 0
  while ($lidos -lt 4) { $n = $entrada.Read($cab, $lidos, 4 - $lidos); if ($n -le 0) { return $null }; $lidos += $n }
  $tam = [BitConverter]::ToInt32($cab, 0)
  $buf = New-Object byte[] $tam
  $lidos = 0
  while ($lidos -lt $tam) { $n = $entrada.Read($buf, $lidos, $tam - $lidos); if ($n -le 0) { break }; $lidos += $n }
  return ([Text.Encoding]::UTF8.GetString($buf, 0, $lidos) | ConvertFrom-Json)
}

function Responder($obj) {
  $json = $obj | ConvertTo-Json -Compress -Depth 5
  $bytes = [Text.Encoding]::UTF8.GetBytes($json)
  $saida = [Console]::OpenStandardOutput()
  $saida.Write([BitConverter]::GetBytes([int]$bytes.Length), 0, 4)
  $saida.Write($bytes, 0, $bytes.Length)
  $saida.Flush()
}

Add-Type -AssemblyName UIAutomationClient, UIAutomationTypes
$AE = [System.Windows.Automation.AutomationElement]
$TS = [System.Windows.Automation.TreeScope]
$PC = [System.Windows.Automation.PropertyCondition]
# Em teste, o processo dono da janela pode ser outro (ex.: powershell); no uso normal é sempre o Chrome.
$PROCESSO = if ($env:PGFN_AJUDANTE_PROCESSO) { $env:PGFN_AJUDANTE_PROCESSO } else { 'chrome' }
$TITULOS = @('Salvar como', 'Save As')

# Win32: lê o texto de um campo (inclui o "&", que a acessibilidade esconde) e clica num botão pelo identificador.
Add-Type -Namespace PgfnAjudante -Name Win -MemberDefinition @"
[DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern IntPtr SendMessage(IntPtr h, int msg, IntPtr w, System.Text.StringBuilder l);
[DllImport("user32.dll")] public static extern IntPtr SendMessage(IntPtr h, int msg, IntPtr w, IntPtr l);
[DllImport("user32.dll", CharSet = CharSet.Unicode, EntryPoint = "SendMessageW")] public static extern IntPtr SendTexto(IntPtr h, int msg, IntPtr w, string l);
[DllImport("user32.dll")] public static extern IntPtr GetParent(IntPtr h);
[DllImport("user32.dll")] public static extern int GetDlgCtrlID(IntPtr h);
"@
function Texto-Win32($el) {
  $h = [IntPtr]$el.Current.NativeWindowHandle
  if ($h -eq [IntPtr]::Zero) { return $null }
  $n = [int][PgfnAjudante.Win]::SendMessage($h, 0x000E, [IntPtr]::Zero, [IntPtr]::Zero) # WM_GETTEXTLENGTH
  $sb = New-Object System.Text.StringBuilder ($n + 1)
  [void][PgfnAjudante.Win]::SendMessage($h, 0x000D, [IntPtr]($n + 1), $sb) # WM_GETTEXT
  return $sb.ToString()
}
function Clicar($el) {
  try { $el.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern).Invoke(); return } catch { }
  $h = [IntPtr]$el.Current.NativeWindowHandle
  if ($h -ne [IntPtr]::Zero) { [void][PgfnAjudante.Win]::SendMessage($h, 0x00F5, [IntPtr]::Zero, [IntPtr]::Zero) } # BM_CLICK
}

# Elementos da janela pela classe de janela do Windows (vale mesmo quando a acessibilidade mostra tudo como "Pane").
function Todos($el, $classe) {
  return @($el.FindAll($TS::Descendants, (New-Object $PC($AE::ClassNameProperty, $classe))))
}
function Por-Id($el, $classe, $id) {
  return (Todos $el $classe | Where-Object { $_.Current.AutomationId -eq $id } | Select-Object -First 1)
}

# Janelas "Salvar como" do Chrome (de nível superior ou filhas de uma janela do Chrome).
function Achar-Janelas {
  $achadas = @()
  $dialogo = New-Object $PC($AE::ClassNameProperty, '#32770')
  $ids = @(Get-Process -Name $PROCESSO -ErrorAction SilentlyContinue | ForEach-Object { $_.Id }) # uma consulta só (mais rápido)
  foreach ($w in $AE::RootElement.FindAll($TS::Children, [System.Windows.Automation.Condition]::TrueCondition)) {
    if ($ids -notcontains $w.Current.ProcessId) { continue }
    $candidatas = @()
    if ($w.Current.ClassName -eq '#32770') { $candidatas += $w }
    $candidatas += @($w.FindAll($TS::Children, $dialogo))
    foreach ($c in $candidatas) { if ($TITULOS -contains $c.Current.Name) { $achadas += $c } }
  }
  return $achadas
}

# Campo "Nome": o Edit 1001 que fica dentro da caixa do nome (o endereço também usa o id 1001, mas é outra classe).
function Nome-Da-Janela($janela) {
  $campo = Por-Id $janela 'Edit' '1001'
  if (-not $campo) { return $null }
  try { $v = $campo.GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern).Current.Value; if ($v) { return $v } } catch { }
  $t = Texto-Win32 $campo
  if ($t) { return $t }
  return $campo.Current.Name
}

function Pasta-Da-Janela($janela) {
  # barra de endereço: "Endereço: C:\...\<CNPJ>" (ou "Address: ...")
  foreach ($b in (Todos $janela 'ToolbarWindow32')) {
    if ($b.Current.Name -match '^(Endere\S*|Address)\s*:\s*(.+)$') { return $Matches[2].Trim() }
  }
  return $null
}

function Tipo-Da-Janela($janela, $nome) {
  # caixa "Tipo": o Chrome mostra "Arquivo PDF"; a janela comum do Windows mostra "Arquivo PDF (*.pdf)". É a caixa que
  # não é a do nome (a do nome tem o campo de texto 1001 dentro, e o nome dela é o próprio nome do arquivo).
  foreach ($c in (Todos $janela 'ComboBox')) {
    $n = $c.Current.Name
    if ($c.Current.AutomationId -eq 'FileTypeControlHost') { return $n }
    if (-not $n -or $n -eq $nome) { continue }
    if (@(Todos $c 'Edit').Count) { continue }
    return $n
  }
  return $null
}
function Sem-Pdf($n) { return ($n -replace '(?i)\.pdf$', '').Trim() }

# Pasta de downloads do Chrome (onde ele cria ATM_PGFN\Documentos_arrecadacao): a configurada no Chrome; senão a
# pasta Downloads do Windows; senão a pasta acima de ATM_PGFN (onde este ajudante está). Vale a primeira que já tiver
# ATM_PGFN; se nenhuma tiver, a primeira que existir.
$RAIZ = 'ATM_PGFN' # subpasta dos downloads onde a extensão salva (igual ao PASTA_DOCUMENTOS do content.js)
function Pasta-Downloads {
  $c = @()
  try {
    $pref = Join-Path $env:LOCALAPPDATA 'Google\Chrome\User Data\Default\Preferences'
    if (Test-Path -LiteralPath $pref) {
      $p = Get-Content -LiteralPath $pref -Raw -Encoding UTF8 | ConvertFrom-Json
      if ($p.download -and $p.download.default_directory) { $c += [string]$p.download.default_directory }
    }
  } catch { }
  try { $c += [Environment]::ExpandEnvironmentVariables((Get-ItemProperty 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders').'{374DE290-123F-4565-9164-39C4925E467B}') } catch { }
  $c += (Split-Path (Split-Path $PSScriptRoot -Parent) -Parent)
  foreach ($d in $c) { if ($d -and (Test-Path -LiteralPath (Join-Path $d $RAIZ))) { return $d } }
  foreach ($d in $c) { if ($d -and (Test-Path -LiteralPath $d)) { return $d } }
  return $null
}

# Caminho final do documento: <Downloads>\ATM_PGFN\Documentos_arrecadacao\[<CERTIFICADO>\]<CNPJ>\<nome>.pdf. Nunca sobrescreve: se o
# arquivo já existir, usa "<nome> (1).pdf", "(2)"... (como o Chrome faz).
function Caminho-Livre($pedido) {
  # Documentos_arrecadacao/<CNPJ> ou, desde 1.4, Documentos_arrecadacao/<CERTIFICADO>/<CNPJ>
  if ([string]$pedido.pasta -notmatch ('^' + $RAIZ + '/Documentos_arrecadacao/([A-Za-z0-9_-]{1,80}/)?\d{14}$')) { return $null }
  $base = Pasta-Downloads
  if (-not $base) { return $null }
  $dir = Join-Path $base (([string]$pedido.pasta) -replace '/', '\')
  if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
  $nome = Sem-Pdf $pedido.nome
  $alvo = Join-Path $dir "$nome.pdf"
  for ($i = 1; (Test-Path -LiteralPath $alvo) -and $i -le 20; $i++) { $alvo = Join-Path $dir "$nome ($i).pdf" }
  if (Test-Path -LiteralPath $alvo) { return $null }
  return $alvo
}

# Escreve no campo "Nome" e confere o que ficou. Só trocar o texto (WM_SETTEXT) não basta: a janela salva com o nome
# antigo (testado em 09/11/2026). Ela só usa o texto novo depois do aviso de "campo alterado" (EN_CHANGE) ao campo pai.
function Escrever-Nome($janela, $texto) {
  $campo = Por-Id $janela 'Edit' '1001'
  if (-not $campo) { return $false }
  $h = [IntPtr]$campo.Current.NativeWindowHandle
  if ($h -eq [IntPtr]::Zero) { return $false }
  [void][PgfnAjudante.Win]::SendTexto($h, 0x000C, [IntPtr]::Zero, $texto) # WM_SETTEXT
  $pai = [PgfnAjudante.Win]::GetParent($h)
  $id = [PgfnAjudante.Win]::GetDlgCtrlID($h)
  [void][PgfnAjudante.Win]::SendMessage($pai, 0x0111, [IntPtr](($id -band 0xFFFF) -bor (0x0300 -shl 16)), $h) # WM_COMMAND + EN_CHANGE
  Start-Sleep -Milliseconds 250
  return ((Texto-Win32 $campo) -eq $texto)
}

# A janela é deste documento? Nome pedido, ou o nome que o site deu (o número do documento, quando o Chrome perde o
# nome sugerido pela extensão). Janela de qualquer outro arquivo nunca é tocada.
function Janela-Do-Documento($nome, $pedido) {
  if (-not $nome) { return $false }
  $n = Sem-Pdf $nome
  $esperado = Sem-Pdf $pedido.nome
  if ($n -eq $esperado -or $n -match ('^' + [regex]::Escape($esperado) + ' \(\d+\)$')) { return $true }
  $num = [string]$pedido.numero
  return ($num -match '^\d{6,30}$' -and ($n -eq $num -or $n -eq "0$num" -or $n -match ('^0?' + $num + ' \(\d+\)$')))
}

function Confirmar($pedido) {
  $ms = if ($pedido.timeoutMs) { [int]$pedido.timeoutMs } else { 20000 }
  $limite = (Get-Date).AddMilliseconds($ms)
  $cnpj = ($pedido.pasta -split '/')[-1]
  $sufixo = '\' + (([string]$pedido.pasta) -replace '/', '\')
  $nomeEsperado = Sem-Pdf $pedido.nome
  $ultimo = 'a janela "Salvar como" não apareceu'
  $info = @{ pastaNaJanela = $null; nomeNaJanela = $null; tipoNaJanela = $null }
  while ((Get-Date) -lt $limite) {
    foreach ($j in (Achar-Janelas)) {
      $nome = Nome-Da-Janela $j
      $pasta = Pasta-Da-Janela $j
      $tipo = Tipo-Da-Janela $j $nome
      $info = @{ pastaNaJanela = $pasta; nomeNaJanela = $nome; tipoNaJanela = $tipo }
      if (-not $nome) { $ultimo = 'a janela "Salvar como" ainda não terminou de abrir (campo Nome vazio)'; continue }
      if (-not (Janela-Do-Documento $nome $pedido)) { $ultimo = "a janela aberta é de outro arquivo ($nome), não de $nomeEsperado"; continue }
      # tipo: se a janela mostrar o tipo, tem que ser PDF. No Chrome a caixa "Tipo" nem sempre é legível pela acessibilidade;
      # aí vale o tipo que a extensão recebeu do site (o nome pedido termina em .pdf) e, depois, a conferência do "%PDF" no disco.
      if ($tipo -and $tipo -notmatch '(?i)pdf') { $ultimo = "o tipo na janela ($tipo) não é PDF"; continue }
      if (-not $tipo -and $pedido.nome -notmatch '(?i)\.pdf$') { $ultimo = 'não consegui ler o tipo na janela e o arquivo pedido não é .pdf'; continue }
      $salvar = Por-Id $j 'Button' '1'
      if (-not $salvar) { $ultimo = 'não achei o botão "Salvar" na janela'; continue }
      $pastaCerta = $pasta -and $pasta.TrimEnd('\').EndsWith($sufixo, [StringComparison]::OrdinalIgnoreCase)
      $jaExiste = $pastaCerta -and (Test-Path -LiteralPath (Join-Path $pasta.TrimEnd('\') "$nomeEsperado.pdf"))
      if (-not $pastaCerta -or (Sem-Pdf $nome) -ne $nomeEsperado -or $jaExiste) {
        # pasta diferente/ilegível, nome do site ou arquivo já existente: escreve o caminho completo e livre no campo
        # "Nome" (a janela do Windows salva exatamente nele), sem sobrescrever nada
        $alvo = Caminho-Livre $pedido
        if (-not $alvo) { $ultimo = "não consegui montar o caminho da pasta do CNPJ $cnpj"; continue }
        if (-not (Escrever-Nome $j $alvo)) { $ultimo = 'não consegui escrever o nome certo no campo "Nome"'; continue }
        $info.corrigido = $alvo
      }
      Clicar $salvar
      # espera a janela fechar; se o Windows perguntar se quer substituir um arquivo, não substitui
      $fim = (Get-Date).AddSeconds(8)
      while ((Get-Date) -lt $fim) {
        Start-Sleep -Milliseconds 300
        $abertas = @(Achar-Janelas)
        if (-not ($abertas | Where-Object { $_.Current.ProcessId -eq $j.Current.ProcessId })) {
          return (@{ ok = $true; clicou = 'Salvar' } + $info)
        }
        $pergunta = $AE::RootElement.FindFirst($TS::Descendants, (New-Object $PC($AE::NameProperty, 'Confirmar Salvar como')))
        if ($pergunta) {
          $nao = $pergunta.FindFirst($TS::Descendants, (New-Object $PC($AE::AutomationIdProperty, 'CommandButton_7')))
          if ($nao) { Clicar $nao }
          Start-Sleep -Milliseconds 400
          $cancelar = Por-Id $j 'Button' '2'
          if ($cancelar) { Clicar $cancelar }
          return (@{ ok = $false; erro = 'já existe um arquivo com esse nome; não substituí e cancelei' } + $info)
        }
      }
      return (@{ ok = $false; erro = 'cliquei em "Salvar", mas a janela não fechou' } + $info)
    }
    Start-Sleep -Milliseconds 400
  }
  return @{ ok = $false; erro = $ultimo; janelaVista = $info }
}

# Fecha de forma controlada (botão "Cancelar") a janela "Salvar como" DESTE documento, para a extensão tentar de novo.
function Cancelar($pedido) {
  $ms = if ($pedido.timeoutMs) { [int]$pedido.timeoutMs } else { 8000 }
  $limite = (Get-Date).AddMilliseconds($ms)
  while ((Get-Date) -lt $limite) {
    foreach ($j in (Achar-Janelas)) {
      $nome = Nome-Da-Janela $j
      if (-not (Janela-Do-Documento $nome $pedido)) { continue }
      $cancelar = Por-Id $j 'Button' '2'
      if (-not $cancelar) { return @{ ok = $false; erro = 'não achei o botão "Cancelar"'; nomeNaJanela = $nome } }
      $proc = $j.Current.ProcessId
      Clicar $cancelar
      $fim = (Get-Date).AddSeconds(5)
      while ((Get-Date) -lt $fim) {
        Start-Sleep -Milliseconds 300
        if (-not (@(Achar-Janelas) | Where-Object { $_.Current.ProcessId -eq $proc -and (Janela-Do-Documento (Nome-Da-Janela $_) $pedido) })) {
          return @{ ok = $true; fechou = $true; nomeNaJanela = $nome }
        }
      }
      return @{ ok = $false; erro = 'cliquei em "Cancelar", mas a janela não fechou'; nomeNaJanela = $nome }
    }
    Start-Sleep -Milliseconds 400
  }
  return @{ ok = $true; fechou = $false; motivo = 'nenhuma janela "Salvar como" deste documento aberta' }
}

# Janelas "Salvar como" do Chrome abertas agora (para a extensão saber se há uma esperando).
function Janelas {
  $lista = @(foreach ($j in (Achar-Janelas)) { @{ nome = (Nome-Da-Janela $j); pasta = (Pasta-Da-Janela $j) } })
  return @{ ok = $true; abertas = $lista.Count; janelas = $lista }
}

function Conferir($pedido) {
  $caminho = [string]$pedido.caminho
  if (-not ($caminho -match ('\\' + $RAIZ + '\\'))) { return @{ ok = $false; erro = "caminho fora da pasta $RAIZ" } }
  if (-not (Test-Path -LiteralPath $caminho -PathType Leaf)) { return @{ ok = $true; existe = $false } }
  $f = Get-Item -LiteralPath $caminho
  $cab = ''
  if ($f.Length -ge 5) {
    $s = [IO.File]::OpenRead($caminho)
    try { $b = New-Object byte[] 5; [void]$s.Read($b, 0, 5); $cab = [Text.Encoding]::ASCII.GetString($b) } finally { $s.Close() }
  }
  return @{ ok = $true; existe = $true; bytes = $f.Length; pdf = ($cab -eq '%PDF-') }
}

# 1.8 — O PDF desta prestação já está na pasta do CNPJ? Procura pelo nome pedido ("<nome>.pdf", "<nome> (1).pdf") ou
# pelo número do documento (nome que o site dá, ex.: "7172631466259011.pdf"), só entre os arquivos gravados depois de
# "desde" (início desta prestação), e confere o "%PDF". Nunca toma um print ou outro arquivo como o documento: o nome tem
# que ser o deste documento (mesma regra da janela "Salvar como"). Só lê; não move nem apaga nada.
function Procurar-Documento($pedido) {
  if ([string]$pedido.pasta -notmatch ('^' + $RAIZ + '/Documentos_arrecadacao/([A-Za-z0-9_-]{1,80}/)?\d{14}$')) { return @{ ok = $false; erro = 'pasta fora de Documentos_arrecadacao' } }
  $base = Pasta-Downloads
  if (-not $base) { return @{ ok = $false; erro = 'não achei a pasta de downloads com Auto_PGFN' } }
  $dir = Join-Path $base (([string]$pedido.pasta) -replace '/', '\')
  if (-not (Test-Path -LiteralPath $dir)) { return @{ ok = $true; achou = $false } }
  $desde = [DateTime]::MinValue
  if ([double]$pedido.desde -gt 0) { $desde = [DateTimeOffset]::FromUnixTimeMilliseconds([long]$pedido.desde).LocalDateTime.AddSeconds(-5) }
  $candidatos = @(Get-ChildItem -LiteralPath $dir -File -Filter '*.pdf' -ErrorAction SilentlyContinue |
    Where-Object { $_.LastWriteTime -ge $desde -and (Janela-Do-Documento $_.Name $pedido) } | Sort-Object LastWriteTime)
  $invalidos = 0
  foreach ($f in $candidatos) {
    $cab = ''
    if ($f.Length -ge 5) {
      try { $s = [IO.File]::OpenRead($f.FullName); try { $b = New-Object byte[] 5; [void]$s.Read($b, 0, 5); $cab = [Text.Encoding]::ASCII.GetString($b) } finally { $s.Close() } } catch { }
    }
    if ($cab -eq '%PDF-') { return @{ ok = $true; achou = $true; caminho = $f.FullName; bytes = $f.Length; pdf = $true; candidatos = $candidatos.Count } }
    $invalidos++
  }
  return @{ ok = $true; achou = $false; invalidos = $invalidos }
}

# ===================== orquestração (vários CNPJs e certificados) =====================
# O orquestrador (..\Automacao\orquestrador.ps1) grava em atual.json o CNPJ da vez; a extensão lê por aqui e avisa
# o andamento em sinal.json, que o orquestrador acompanha.
$ORQ = Join-Path (Split-Path $PSScriptRoot -Parent) 'Automacao'
function Ler-Json($arq) { try { if (Test-Path -LiteralPath $arq) { return (Get-Content -LiteralPath $arq -Raw -Encoding UTF8 | ConvertFrom-Json) } } catch { }; return $null }
function Gravar-Json($arq, $obj) {
  $tmp = "$arq.tmp"
  [IO.File]::WriteAllText($tmp, ($obj | ConvertTo-Json -Depth 5), (New-Object Text.UTF8Encoding $false))
  Move-Item -LiteralPath $tmp -Destination $arq -Force
}

# CNPJ da vez: só vale se o orquestrador que gravou ainda estiver rodando.
# Sem CNPJ da vez (1.6): como terminou a última execução (ultima_execucao.json, gravado pelo orquestrador ao sair), para a
# extensão mostrar "AUTOMAÇÃO TERMINADA" em vez de um aviso que parecia travamento. Só vale por 12 h.
function Orq-Ultima {
  $u = Ler-Json (Join-Path $ORQ 'ultima_execucao.json')
  $fim = $null; try { $fim = [datetime]::Parse([string]$u.fim) } catch { }
  if (-not $u -or -not $fim -or ((Get-Date) - $fim).TotalHours -gt 12) { return @{ ok = $true; ativo = $false } }
  $conta = "$([int]$u.concluidos) de $([int]$u.total) CNPJ(s) concluído(s)" + $(if ([int]$u.erros) { ", $([int]$u.erros) com erro" } else { '' }) +
    $(if ([int]$u.semProcuracao) { ", $([int]$u.semProcuracao) sem procuração" } else { '' }) +
    $(if ([int]$u.procCancelada) { ", $([int]$u.procCancelada) com procuração cancelada" } else { '' }) +
    $(if ([int]$u.caixaPostal) { ", $([int]$u.caixaPostal) com aviso de Caixa Postal" } else { '' }) +
    $(if ([int]$u.pendentes) { ", $([int]$u.pendentes) pendente(s)" } else { '' })
  $lista = if ([string]$u.nome) { " ""$([string]$u.nome)""" } else { '' }
  $quando = $fim.ToString('HH:mm')
  $motivo = switch ([string]$u.encerramento) {
    'terminou' { "AUTOMAÇÃO TERMINADA às $quando`: a lista$lista chegou ao fim ($conta). Nada está travado; pode fechar o Chrome. Detalhes na interface" }
    'parada' { "automação PARADA pela interface às $quando ($conta). Iniciar continua de onde parou" }
    'chrome_fechado' { "automação encerrada às $quando porque o Chrome foi fechado ($conta). Iniciar continua de onde parou" }
    default { "o orquestrador encerrou com erro às $quando ($conta); veja o log na interface. Iniciar continua de onde parou" }
  }
  return @{ ok = $true; ativo = $false; fim = $true; encerramento = [string]$u.encerramento; motivo = $motivo }
}

function Orq-Atual {
  $a = Ler-Json (Join-Path $ORQ 'atual.json')
  if (-not $a -or -not $a.cnpj) { return (Orq-Ultima) }
  if ($a.pid -and -not (Get-Process -Id ([int]$a.pid) -ErrorAction SilentlyContinue)) {
    return @{ ok = $true; ativo = $false; parado = $true; motivo = 'o orquestrador parou antes de terminar (processo encerrado). Abra a interface e clique em Iniciar: continua de onde parou' }
  }
  $r = @{ ok = $true; ativo = $true; cnpj = [string]$a.cnpj; certificado = [string]$a.certificado; sessao = [string]$a.sessao }
  # desde 1.4 (interface de configuração): pasta do certificado e seleção EXATA do certificado
  if ([string]$a.pastaCertificado -match '^[A-Za-z0-9_-]{1,80}$') { $r.pastaCertificado = [string]$a.pastaCertificado }
  if ($a.certificadoExato) { $r.certificadoExato = $true }
  return $r
}

# Andamento vindo da extensão. Só aceita o CNPJ e a sessão que o orquestrador definiu (nunca outro cliente).
function Orq-Informar($p) {
  $a = Ler-Json (Join-Path $ORQ 'atual.json')
  if (-not $a -or [string]$a.sessao -ne [string]$p.sessao -or [string]$a.cnpj -ne [string]$p.cnpj) {
    return @{ ok = $false; erro = 'sessão ou CNPJ diferente do que o orquestrador definiu' }
  }
  $msg = [string]$p.mensagem; if ($msg.Length -gt 4000) { $msg = $msg.Substring(0, 4000) }
  Gravar-Json (Join-Path $ORQ 'sinal.json') @{ sessao = [string]$p.sessao; cnpj = [string]$p.cnpj; situacao = [string]$p.situacao; mensagem = $msg; t = (Get-Date).ToString('o') }
  return @{ ok = $true }
}

# Progresso para o vigia de travamentos do orquestrador (1.5): última ação da extensão e o ponto exato (checkpoint:
# certificado, CNPJ, etapa, conta, parcela, PDFs salvos), em progresso.json. Mesma conferência de sessão/CNPJ.
function Orq-Progresso($p) {
  $a = Ler-Json (Join-Path $ORQ 'atual.json')
  if (-not $a -or [string]$a.sessao -ne [string]$p.sessao -or [string]$a.cnpj -ne [string]$p.cnpj) {
    return @{ ok = $false; erro = 'sessão ou CNPJ diferente do que o orquestrador definiu' }
  }
  $txt = [string]$p.texto; if ($txt.Length -gt 400) { $txt = $txt.Substring(0, 400) }
  Gravar-Json (Join-Path $ORQ 'progresso.json') @{ sessao = [string]$p.sessao; cnpj = [string]$p.cnpj; texto = $txt; checkpoint = $p.checkpoint; t = (Get-Date).ToString('o') }
  return @{ ok = $true }
}

# Registro em disco dos PDFs já salvos (1.5): o mesmo do Chrome (chave -> arquivo), em registro_salvos.json, para a
# proteção contra emissão/print repetido valer mesmo se o Chrome perder o dele. Trava (mutex) contra duas gravações juntas.
$ARQ_REGISTRO = Join-Path $ORQ 'registro_salvos.json'
function Com-Trava([scriptblock]$bloco) {
  $m = New-Object Threading.Mutex($false, 'Local\pgfn_registro_salvos')
  $tem = $false
  try { $tem = $m.WaitOne(15000) } catch [Threading.AbandonedMutexException] { $tem = $true }
  try { return (& $bloco) } finally { if ($tem) { $m.ReleaseMutex() }; $m.Dispose() }
}
function Registro-Ver($p) {
  $chave = [string]$p.chave
  if (-not $chave) { return @{ ok = $false; erro = 'sem chave' } }
  $r = Ler-Json $ARQ_REGISTRO
  $item = if ($r) { $r.PSObject.Properties[$chave] } else { $null }
  if (-not $item) { return @{ ok = $true; registro = $null } }
  return @{ ok = $true; registro = @{ arquivo = [string]$item.Value.arquivo; t = $item.Value.t } }
}
function Registro-Gravar($p) {
  $chave = [string]$p.chave; $arq = [string]$p.arquivo
  if (-not $chave -or $chave.Length -gt 600 -or -not $arq) { return @{ ok = $false; erro = 'chave ou arquivo inválido' } }
  return (Com-Trava {
    $r = Ler-Json $ARQ_REGISTRO
    $tudo = [ordered]@{}
    if ($r) { foreach ($x in $r.PSObject.Properties) { $tudo[$x.Name] = $x.Value } }
    $tudo[$chave] = [ordered]@{ arquivo = $arq; t = (Get-Date).ToString('o') }
    Gravar-Json $ARQ_REGISTRO $tudo
    @{ ok = $true }
  })
}

# Fecha (botão "Cancelar") TODAS as janelas "Salvar como" do Chrome. Só o vigia de travamentos do orquestrador usa,
# antes de reiniciar o Chrome travado (nunca reinicia com uma janela de salvamento aberta).
function Cancelar-Todas {
  $fechadas = @()
  foreach ($j in (Achar-Janelas)) {
    $nome = Nome-Da-Janela $j
    $cancelar = Por-Id $j 'Button' '2'
    if ($cancelar) { Clicar $cancelar; $fechadas += [string]$nome }
  }
  Start-Sleep -Milliseconds 800
  return @{ ok = $true; fechadas = $fechadas; restantes = @(Achar-Janelas).Count }
}

# ---- janela "Selecione um certificado" do Chrome ----
# Seleção com o MOUSE de verdade (movimento suave e pausas): pela acessibilidade, "selecionar" a linha fecha a janela.
# Conferência: depois do clique, o foco tem que estar exatamente no certificado configurado; só então clica em OK.
# Nunca escolhe outro certificado: se não achar exatamente um com o nome configurado, não clica em nada.
Add-Type -Namespace PgfnAjudante -Name Mouse -MemberDefinition @"
[DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
[DllImport("user32.dll")] public static extern bool GetCursorPos(out POINT p);
[DllImport("user32.dll")] public static extern void mouse_event(uint f, uint dx, uint dy, uint d, IntPtr e);
[DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
[DllImport("user32.dll")] public static extern void keybd_event(byte vk, byte scan, uint f, IntPtr e);
public struct POINT { public int X; public int Y; }
"@
# 1.9: tecla de navegação (só Home/Seta para baixo, nunca Enter) para percorrer a lista de certificados
function Tecla([byte]$vk) {
  [PgfnAjudante.Mouse]::keybd_event($vk, 0, 0, [IntPtr]::Zero)
  Start-Sleep -Milliseconds (Get-Random -Minimum 40 -Maximum 90)
  [PgfnAjudante.Mouse]::keybd_event($vk, 0, 2, [IntPtr]::Zero)
}
function Mouse-Mover($x, $y) {
  $p = New-Object PgfnAjudante.Mouse+POINT; [void][PgfnAjudante.Mouse]::GetCursorPos([ref]$p)
  $x0 = $p.X; $y0 = $p.Y; $dist = [math]::Sqrt(($x - $x0) * ($x - $x0) + ($y - $y0) * ($y - $y0))
  $passos = [int][math]::Max(20, [math]::Min(80, $dist / 8))
  $cx = $x0 + ($x - $x0) * (Get-Random -Minimum 0.25 -Maximum 0.5) + (Get-Random -Minimum -70 -Maximum 70)
  $cy = $y0 + ($y - $y0) * (Get-Random -Minimum 0.25 -Maximum 0.5) + (Get-Random -Minimum -70 -Maximum 70)
  for ($i = 1; $i -le $passos; $i++) {
    $t = $i / $passos; $e = if ($t -lt 0.5) { 4 * $t * $t * $t } else { 1 - [math]::Pow(-2 * $t + 2, 3) / 2 }; $u = 1 - $e
    [void][PgfnAjudante.Mouse]::SetCursorPos([int]($u * $u * $x0 + 2 * $u * $e * $cx + $e * $e * $x), [int]($u * $u * $y0 + 2 * $u * $e * $cy + $e * $e * $y))
    Start-Sleep -Milliseconds (Get-Random -Minimum 8 -Maximum 20)
  }
  [void][PgfnAjudante.Mouse]::SetCursorPos([int]$x, [int]$y)
}
function Mouse-Clicar {
  [PgfnAjudante.Mouse]::mouse_event(0x0002, 0, 0, 0, [IntPtr]::Zero)
  Start-Sleep -Milliseconds (Get-Random -Minimum 70 -Maximum 150)
  [PgfnAjudante.Mouse]::mouse_event(0x0004, 0, 0, 0, [IntPtr]::Zero)
}
function Centro-De($el) { $r = $el.Current.BoundingRectangle; return @([int]($r.X + $r.Width * (Get-Random -Minimum 0.3 -Maximum 0.6)), [int]($r.Y + $r.Height / 2)) }
function Sem-Acento($s) { return ([string]$s).Normalize([Text.NormalizationForm]::FormD) -replace '\p{Mn}', '' }

function Achar-Janela-Certificado {
  $ids = @(Get-Process -Name $PROCESSO -ErrorAction SilentlyContinue | ForEach-Object { $_.Id })
  foreach ($w in $AE::RootElement.FindAll($TS::Children, [System.Windows.Automation.Condition]::TrueCondition)) {
    if ($ids -notcontains $w.Current.ProcessId) { continue }
    foreach ($d in $w.FindAll($TS::Descendants, (New-Object $PC($AE::ControlTypeProperty, [System.Windows.Automation.ControlType]::Window)))) {
      if ((Sem-Acento $d.Current.Name) -match '^Selecione um certificado$|^Select a certificate$') { return $d }
    }
  }
  return $null
}

# Certificados da janela que correspondem ao nome configurado. $exato (interface de configuração): o nome inteiro tem
# que ser igual (sem diferença de maiúsculas/acentos/espaços nas pontas); nunca por aproximação. Sem $exato (cnpjs.json
# antigo): trecho do nome, como antes. Quem chama exige exatamente UM.
function Escolher-Certificados($temas, [string]$nome, [bool]$exato) {
  $norm = { param($s) ((Sem-Acento $s).ToUpper() -replace '\s+', ' ').Trim() }
  $alvo = & $norm $nome
  if ($exato) { return @($temas | Where-Object { (& $norm $_.Current.Name) -eq $alvo }) }
  return @($temas | Where-Object { (& $norm $_.Current.Name).Contains($alvo) })
}
# 1.9: o mesmo critério, sobre o NOME (texto) de uma linha
function Nome-Confere([string]$tema, [string]$nome, [bool]$exato) {
  $norm = { param($s) ((Sem-Acento $s).ToUpper() -replace '\s+', ' ').Trim() }
  $a = & $norm $tema; $b = & $norm $nome
  if ($exato) { return $a -eq $b }
  return $a.Contains($b)
}

# 1.9 — A tabela da janela só mostra à acessibilidade as linhas VISÍVEIS (10/11: 3 de uma lista maior, com barra de
# rolagem; o certificado configurado estava mais abaixo e a automação pausou com "achei 0"). Linha em foco na janela:
# { tema (nome completo, mesmo cortado na tela), serial, el (célula "Tema") } ou $null se o foco não está na lista da
# janela (aí nenhuma tecla é enviada: nunca digita em outra janela).
function Linha-Em-Foco($dlg) {
  $walker = [System.Windows.Automation.TreeWalker]::ControlViewWalker
  $f = $AE::FocusedElement
  if (-not $f -or $f.Current.ProcessId -ne $dlg.Current.ProcessId) { return $null }
  # o foco é a célula "Tema" da linha selecionada (nome completo, mesmo cortado na tela). A "linha mãe" que o Chrome
  # informa é reaproveitada entre as linhas e dava nomes trocados (teste de 11/11): o nome vem SEMPRE do próprio foco.
  if ($f.Current.ControlType -ne [System.Windows.Automation.ControlType]::DataItem -or -not $f.Current.Name) { return $null }
  # a célula tem que estar dentro da janela "Selecione um certificado"
  $dentro = $false
  for ($a = $f; $a; $a = $walker.GetParent($a)) { if ([System.Windows.Automation.Automation]::Compare($a, $dlg)) { $dentro = $true; break } }
  if (-not $dentro) { return $null }
  # serial (última coluna), só para distinguir certificados de mesmo nome; vazio se não der para ler
  $serial = ''; for ($c = $walker.GetNextSibling($f); $c; $c = $walker.GetNextSibling($c)) { if ($c.Current.Name) { $serial = [string]$c.Current.Name } }
  return @{ tema = [string]$f.Current.Name; serial = $serial; el = $f; chave = "$($f.Current.Name)|$serial" }
}
# Depois de uma tecla: espera a linha em foco MUDAR (até ~1,2 s). Devolve a linha nova, a mesma (não andou = fim da
# lista) ou $null (o foco saiu da lista).
function Esperar-Foco-Mudar($dlg, [string]$chaveAntes) {
  $fim = (Get-Date).AddMilliseconds(1200); $l = $null
  do {
    Start-Sleep -Milliseconds 120
    $l = Linha-Em-Foco $dlg
    if (-not $l) { continue }
    if ($l.chave -ne $chaveAntes) { Start-Sleep -Milliseconds 150; $l2 = Linha-Em-Foco $dlg; if ($l2) { return $l2 }; return $l }
  } while ((Get-Date) -lt $fim)
  return $l
}

# Percorre a lista INTEIRA com o teclado: foca a lista (clique numa linha visível), vai à 1ª linha (Home) e desce
# (seta para baixo) até a última (a linha em foco para de mudar). Devolve as linhas na ordem, ou { erro }.
function Percorrer-Lista($dlg, $visiveis) {
  $l = Linha-Em-Foco $dlg
  if (-not $l) {
    # o foco não está na lista (normalmente já está, quando a janela abre): clica numa linha INTEIRAMENTE visível.
    # Nunca no cabeçalho: o clique em "Tema" reordena a lista (teste de 11/11: a 1ª linha, meio escondida atrás do
    # cabeçalho depois de rolar, recebia o clique no cabeçalho e a ordem mudava no meio da busca).
    $grid = $dlg.FindFirst($TS::Descendants, (New-Object $PC($AE::ControlTypeProperty, [System.Windows.Automation.ControlType]::DataGrid)))
    $cab = 0
    if ($grid) {
      $w = [System.Windows.Automation.TreeWalker]::ControlViewWalker
      for ($x = $w.GetFirstChild($grid); $x; $x = $w.GetNextSibling($x)) { $c1 = $w.GetFirstChild($x); if ($c1 -and ([string]$c1.Current.Name) -match '^Tema|^Subject') { $cab = $x.Current.BoundingRectangle.Bottom } }
    }
    $fundo = if ($grid) { $grid.Current.BoundingRectangle.Bottom } else { [double]::MaxValue }
    $segura = @($visiveis | Where-Object { $r = $_.Current.BoundingRectangle; $r.Height -gt 5 -and $r.Top -ge ($cab + 2) -and $r.Bottom -le ($fundo - 2) })[0]
    if (-not $segura) { return @{ erro = 'não achei uma linha inteira visível para pôr o foco na lista de certificados' } }
    $c = Centro-De $segura
    Mouse-Mover $c[0] $c[1]; Start-Sleep -Milliseconds (Get-Random -Minimum 200 -Maximum 400); Mouse-Clicar
    Start-Sleep -Milliseconds (Get-Random -Minimum 400 -Maximum 700)
    $l = Linha-Em-Foco $dlg
    if (-not $l) { return @{ erro = 'não consegui pôr o foco na lista de certificados' } }
  }
  Tecla 0x24 # Home: 1ª linha
  $l2 = Esperar-Foco-Mudar $dlg $l.chave
  if (-not $l2) { return @{ erro = 'o foco saiu da lista de certificados durante a busca; parei de percorrer' } }
  $l = $l2
  $linhas = @()
  for ($i = 0; $i -lt 300; $i++) {
    $linhas += [pscustomobject]@{ tema = $l.tema; serial = $l.serial; chave = $l.chave }
    Start-Sleep -Milliseconds (Get-Random -Minimum 60 -Maximum 160)
    Tecla 0x28 # seta para baixo
    $n = Esperar-Foco-Mudar $dlg $l.chave
    if (-not $n) { return @{ erro = 'o foco saiu da lista de certificados durante a busca; parei de percorrer' } }
    if ($n.chave -eq $l.chave) { break } # a seta não andou: é a última linha
    $l = $n
  }
  return @{ linhas = $linhas }
}

function Certificado($p) {
  $nome = (Sem-Acento $p.nome).ToUpper().Trim()
  if (-not $nome) { return @{ ok = $false; erro = 'nome do certificado não configurado' } }
  [void][PgfnAjudante.Mouse]::SetProcessDPIAware()
  $ms = if ($p.timeoutMs) { [int]$p.timeoutMs } else { 40000 }
  $limite = (Get-Date).AddMilliseconds($ms)
  $dlg = $null
  while (-not $dlg -and (Get-Date) -lt $limite) { $dlg = Achar-Janela-Certificado; if (-not $dlg) { Start-Sleep -Milliseconds 500 } }
  if (-not $dlg) { return @{ ok = $false; erro = 'a janela "Selecione um certificado" não apareceu' } }
  Start-Sleep -Milliseconds (Get-Random -Minimum 900 -Maximum 1600) # a janela termina de abrir; "lê" a lista
  # coluna "Tema" (nome do titular): a 1ª célula de cada linha
  $walker = [System.Windows.Automation.TreeWalker]::ControlViewWalker
  $linhas = @($dlg.FindAll($TS::Descendants, (New-Object $PC($AE::ControlTypeProperty, [System.Windows.Automation.ControlType]::DataItem))) | Where-Object { -not $_.Current.Name })
  $temas = @(foreach ($l in $linhas) { $c = $walker.GetFirstChild($l); if ($c -and $c.Current.Name -and ([string]$c.Current.Name) -notmatch '^(Tema|Subject)\b') { $c } })
  $como = if ($p.exato) { 'com exatamente o nome configurado' } else { 'com o nome configurado' }
  if (-not $temas.Count) { return @{ ok = $false; erro = 'não consegui ler a lista de certificados da janela; não escolhi nenhum' } }
  # 1.9: a lista INTEIRA (rolando dentro da janela), não só as linhas visíveis
  $busca = Percorrer-Lista $dlg $temas
  if ($busca.erro) { return @{ ok = $false; erro = "$($busca.erro); não escolhi nenhum"; disponiveis = @($temas | ForEach-Object { $_.Current.Name }) } }
  $lista = @($busca.linhas)
  $disponiveis = @($lista | ForEach-Object { $_.tema })
  $idx = @(for ($i = 0; $i -lt $lista.Count; $i++) { if (Nome-Confere $lista[$i].tema $nome ([bool]$p.exato)) { $i } })
  if ($idx.Count -ne 1) {
    $extra = if ($idx.Count -gt 1) { ' (certificados repetidos: escolha você mesmo na janela para confirmar)' } else { '' }
    return @{ ok = $false; erro = "achei $($idx.Count) certificado(s) $como entre os $($lista.Count) da lista (percorrida até o fim); não escolhi nenhum$extra"; disponiveis = $disponiveis }
  }
  $alvoL = $lista[$idx[0]]
  $nomeAlvo = $alvoL.tema # guardado antes: depois do OK a janela some
  # seleciona a linha certa: Home e desce até ela (a seleção acompanha o foco)
  Start-Sleep -Milliseconds (Get-Random -Minimum 300 -Maximum 600)
  $l = Linha-Em-Foco $dlg
  if (-not $l) { return @{ ok = $false; erro = 'o foco saiu da lista de certificados; não escolhi nenhum'; disponiveis = $disponiveis } }
  if ($l.chave -ne $lista[0].chave) {
    Tecla 0x24 # Home
    $l = Esperar-Foco-Mudar $dlg $l.chave
  }
  for ($i = 0; $i -lt $idx[0]; $i++) {
    # cada passo tem que cair exatamente na linha lida na busca (senão a lista mudou: não escolhe)
    if (-not $l -or $l.chave -ne $lista[$i].chave) { return @{ ok = $false; erro = 'a lista de certificados não ficou igual à lida na busca; não escolhi nenhum'; disponiveis = $disponiveis } }
    Start-Sleep -Milliseconds (Get-Random -Minimum 60 -Maximum 160)
    Tecla 0x28
    $l = Esperar-Foco-Mudar $dlg $l.chave
  }
  Start-Sleep -Milliseconds (Get-Random -Minimum 500 -Maximum 900)
  # conferência: a linha em foco (selecionada) tem que ser exatamente o certificado escolhido (nome e serial)
  $foco = Linha-Em-Foco $dlg
  if (-not $foco -or $foco.tema -ne $nomeAlvo -or $foco.serial -ne $alvoL.serial) {
    $qual = if ($foco) { $foco.tema } else { '(nenhum)' }
    return @{ ok = $false; erro = "depois de selecionar, o certificado em foco é '$qual', não o configurado; não cliquei em OK"; disponiveis = $disponiveis }
  }
  # (sem clique na linha: a seleção pelo teclado já é a do Chrome, e um clique perto do cabeçalho reordenaria a lista)
  Start-Sleep -Milliseconds (Get-Random -Minimum 400 -Maximum 800)
  $foco = Linha-Em-Foco $dlg
  if (-not $foco -or $foco.tema -ne $nomeAlvo -or $foco.serial -ne $alvoL.serial) {
    $qual = if ($foco) { $foco.tema } else { '(nenhum)' }
    return @{ ok = $false; erro = "na conferência final, o certificado selecionado é '$qual', não o configurado; não cliquei em OK"; disponiveis = $disponiveis }
  }
  $botao = if ($p.teste) { 'Cancelar' } else { 'OK' }
  $b = @($dlg.FindAll($TS::Descendants, (New-Object $PC($AE::ControlTypeProperty, [System.Windows.Automation.ControlType]::Button))) | Where-Object { $_.Current.Name -eq $botao })[0]
  if (-not $b) { return @{ ok = $false; erro = "não achei o botão $botao" } }
  $k = Centro-De $b
  Start-Sleep -Milliseconds (Get-Random -Minimum 500 -Maximum 1000)
  Mouse-Mover $k[0] $k[1]; Start-Sleep -Milliseconds (Get-Random -Minimum 200 -Maximum 450); Mouse-Clicar
  $fim = (Get-Date).AddSeconds(8)
  while ((Get-Date) -lt $fim -and (Achar-Janela-Certificado)) { Start-Sleep -Milliseconds 300 }
  if (Achar-Janela-Certificado) { return @{ ok = $false; erro = "cliquei em $botao, mas a janela não fechou" } }
  return @{ ok = $true; certificado = $nomeAlvo; botao = $botao }
}

$LOG = Join-Path $PSScriptRoot 'ajudante.log'
function Registrar($texto) { try { Add-Content -LiteralPath $LOG -Value ((Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + ' ' + $texto) -Encoding UTF8 } catch { } }
try {
  $pedido = Ler-Mensagem
  if (-not $pedido) { exit 0 }
  Registrar ("pedido: " + ($pedido | ConvertTo-Json -Compress))
  $resposta = switch ($pedido.acao) {
    'confirmar' { Confirmar $pedido }
    'conferir' { Conferir $pedido }
    'cancelar' { Cancelar $pedido }
    'janelas' { Janelas }
    'cancelar-todas' { Cancelar-Todas }
    'orq-progresso' { Orq-Progresso $pedido }
    'registro-ver' { Registro-Ver $pedido }
    'registro-gravar' { Registro-Gravar $pedido }
    'procurar-documento' { Procurar-Documento $pedido }
    'versao' { @{ ok = $true; versao = '1.9' } }
    'orq-atual' { Orq-Atual }
    'orq-informar' { Orq-Informar $pedido }
    'certificado' { Certificado $pedido }
    default { @{ ok = $false; erro = "ação desconhecida: $($pedido.acao)" } }
  }
  Registrar ("resposta: " + ($resposta | ConvertTo-Json -Compress))
  Responder $resposta
} catch {
  Registrar ("erro: " + $_.Exception.Message)
  Responder @{ ok = $false; erro = $_.Exception.Message }
}
