﻿# Instalação guiada da Automação PGFN (pasta ATM_PGFN) neste computador — usuário atual do Windows, sem administrador.
# Confere e prepara tudo o que a automação precisa para rodar sozinha (sem o Claude):
#   1. as pastas da ATM_PGFN (pode estar em qualquer lugar do computador);
#   2. o Google Chrome e a pasta de downloads dele (onde ficam os documentos: <Downloads>\ATM_PGFN\Documentos_arrecadacao);
#   3. a extensão (pasta Extensao_Chrome) carregada no Chrome, com "Permitir no modo anônimo";
#   4. o ajudante do Windows registrado para ESTA pasta e respondendo como o Chrome espera;
#   5. a interface (Interface\Automacao_PGFN.exe) e o atalho na Área de Trabalho.
# Pode ser rodado de novo quando quiser (ex.: depois de mover a pasta): não apaga nada.
# -SoVerificar: só confere (sem perguntas nem mudanças).
param([switch]$SoVerificar)
$ErrorActionPreference = 'Stop'
$INST = $PSScriptRoot
$BASE = Split-Path $INST -Parent
$PASTA_EXT = Join-Path $BASE 'Extensao_Chrome'
$PASTA_AJ = Join-Path $BASE 'Ajudante_Windows'
$problemas = 0

function Titulo($t) { Write-Host ''; Write-Host "== $t" -ForegroundColor Cyan }
function Ok($t) { Write-Host "   OK  $t" -ForegroundColor Green }
function Aviso($t) { Write-Host "   !!  $t" -ForegroundColor Yellow; $script:problemas++ }
function Erro($t) { Write-Host "   XX  $t" -ForegroundColor Red; $script:problemas++ }
function Esperar($t) { if (-not $SoVerificar) { Write-Host ''; Read-Host "   $t (Enter para continuar)" | Out-Null } }

Write-Host ''
Write-Host '  Instalação da Automação PGFN (ATM_PGFN)' -ForegroundColor Cyan
Write-Host "  Pasta: $BASE"

# ---- 1. pastas ----
Titulo '1. Pasta ATM_PGFN'
$faltou = $false
foreach ($p in 'Extensao_Chrome\manifest.json', 'Ajudante_Windows\salvar_como.ps1', 'Ajudante_Windows\salvar_como.bat', 'Automacao\orquestrador.ps1', 'Interface\AutomacaoPGFN.cs') {
  if (-not (Test-Path -LiteralPath (Join-Path $BASE $p))) { Erro "falta $p (copie/extraia a pasta ATM_PGFN inteira)"; $faltou = $true }
}
if ($faltou) { if (-not $SoVerificar) { Read-Host '   Enter para sair' | Out-Null }; exit 1 }
if (-not $SoVerificar) { New-Item -ItemType Directory -Force -Path (Join-Path $BASE 'Configuracoes') | Out-Null }
Ok 'todos os componentes estão na pasta'

# ---- 2. Chrome ----
Titulo '2. Google Chrome'
$chrome = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe' -ErrorAction SilentlyContinue).'(default)'
if (-not $chrome) { $chrome = (Get-ItemProperty 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe' -ErrorAction SilentlyContinue).'(default)' }
if ($chrome -and (Test-Path -LiteralPath $chrome)) { Ok "Chrome: $chrome" } else { Erro 'Google Chrome não encontrado: instale o Chrome e rode de novo'; if (-not $SoVerificar) { Read-Host '   Enter para sair' | Out-Null }; exit 1 }
$dadosChrome = Join-Path $env:LOCALAPPDATA 'Google\Chrome\User Data'
$downloads = $null
try { $downloads = [Environment]::ExpandEnvironmentVariables((Get-ItemProperty 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders').'{374DE290-123F-4565-9164-39C4925E467B}') } catch { }
if (-not $downloads) { $downloads = Join-Path $env:USERPROFILE 'Downloads' }
try {
  $pr = Get-Content -LiteralPath (Join-Path $dadosChrome 'Default\Preferences') -Raw -Encoding UTF8 | ConvertFrom-Json
  if ($pr.download -and [string]$pr.download.default_directory) { $downloads = [string]$pr.download.default_directory }
} catch { }
Ok "documentos serão salvos em: $(Join-Path $downloads 'ATM_PGFN\Documentos_arrecadacao')\<CERTIFICADO>\<CNPJ>"

# ---- 3. extensão ----
Titulo '3. Extensão do Chrome (pasta Extensao_Chrome)'
function Achar-Extensao {
  $achados = @()
  foreach ($arq in (Get-ChildItem -Path $dadosChrome -Recurse -Depth 1 -Include 'Secure Preferences', 'Preferences' -File -ErrorAction SilentlyContinue)) {
    try { $prefs = Get-Content -LiteralPath $arq.FullName -Raw -Encoding UTF8 | ConvertFrom-Json } catch { continue }
    $ext = $prefs.extensions.settings
    if (-not $ext) { continue }
    foreach ($p in $ext.PSObject.Properties) {
      $caminho = [string]$p.Value.path
      if ($caminho -and ($caminho.TrimEnd('\') -ieq $PASTA_EXT.TrimEnd('\'))) {
        $achados += [pscustomobject]@{ id = $p.Name; anonimo = [bool]$p.Value.incognito; perfil = $arq.Directory.Name }
      }
    }
  }
  return @($achados | Sort-Object id, anonimo -Unique)
}
$ext = @(Achar-Extensao)
for ($volta = 0; -not $ext.Count -and -not $SoVerificar -and $volta -lt 3; $volta++) {
  Write-Host '   A extensão ainda não está carregada desta pasta. Vou abrir o Chrome e a pasta dela. No Chrome:'
  Write-Host '     1) em chrome://extensions, ligue "Modo do desenvolvedor" (canto superior direito);'
  Write-Host '     2) clique em "Carregar sem compactação" e escolha a pasta:'
  Write-Host "        $PASTA_EXT"
  Write-Host '     3) na extensão, clique em "Detalhes" e ligue "Permitir no modo anônimo".'
  Write-Host '     (Se houver outra cópia antiga da extensão Automação_PGFN, clique em "Remover" nela: duas cópias atrapalham.)'
  try { Start-Process -FilePath $chrome -ArgumentList 'chrome://extensions' } catch { }
  try { Start-Process explorer.exe -ArgumentList "`"$PASTA_EXT`"" } catch { }
  Esperar 'Quando terminar'
  Start-Sleep -Seconds 3 # o Chrome grava as configurações em seguida
  $ext = @(Achar-Extensao)
}
if (-not $ext.Count) { Erro "extensão não encontrada no Chrome (carregue a pasta $PASTA_EXT em chrome://extensions)"; $ids = @() }
else {
  $ids = @($ext.id | Sort-Object -Unique)
  Ok "extensão carregada desta pasta (ID $($ids -join ', '))"
  if (@($ext | Where-Object { $_.anonimo }).Count) { Ok '"Permitir no modo anônimo" ligado' }
  else { Aviso 'ligue "Permitir no modo anônimo" (chrome://extensions > Automação_PGFN > Detalhes): a automação abre o Chrome anônimo' }
}

# ---- 4. ajudante ----
Titulo '4. Ajudante do Windows (comunicação com a extensão)'
if ($ids.Count -and -not $SoVerificar) {
  & (Join-Path $PASTA_AJ 'instalar_ajudante.ps1') -IdExtensao $ids[0] | Out-Host
}
$chave = 'HKCU:\Software\Google\Chrome\NativeMessagingHosts\com.auto_pgfn.salvar_como'
$manif = (Get-ItemProperty $chave -ErrorAction SilentlyContinue).'(default)'
if (-not $manif -or -not (Test-Path -LiteralPath $manif)) { Erro 'ajudante não registrado no Windows' }
else {
  $m = Get-Content -LiteralPath $manif -Raw -Encoding UTF8 | ConvertFrom-Json
  $esperado = Join-Path $PASTA_AJ 'salvar_como.bat'
  if ([string]$m.path -ine $esperado) { Aviso "o ajudante registrado é de outra pasta ($($m.path)); rode Instalar.bat desta pasta para usar a ATM_PGFN" }
  else { Ok 'ajudante registrado para esta pasta' }
  if ($ids.Count -and -not (@($m.allowed_origins) -contains "chrome-extension://$($ids[0])/")) { Aviso 'o ajudante está registrado para outra extensão: rode Instalar.bat de novo' }
  elseif ($ids.Count) { Ok 'ajudante autorizado para a extensão desta pasta' }
  if (-not (Test-Path -LiteralPath $m.path)) { Erro "o ajudante aponta para um arquivo que não existe: $($m.path)" }
  else {
    # conversa com o ajudante exatamente como o Chrome faz (4 bytes de tamanho + JSON, com "--parent-window=0")
    $msg = Join-Path $env:TEMP ("pgfn_teste_" + [guid]::NewGuid().ToString('N') + '.bin')
    try {
      $corpo = [Text.Encoding]::UTF8.GetBytes('{"acao":"versao"}')
      [IO.File]::WriteAllBytes($msg, [byte[]]([BitConverter]::GetBytes([int]$corpo.Length) + $corpo))
      $psi = New-Object Diagnostics.ProcessStartInfo 'cmd.exe', ("/d /s /c `"`"$($m.path)`" chrome-extension://teste/ --parent-window=0 < `"$msg`"`"")
      $psi.UseShellExecute = $false; $psi.RedirectStandardOutput = $true; $psi.CreateNoWindow = $true
      $p = [Diagnostics.Process]::Start($psi)
      $ms = New-Object IO.MemoryStream; $p.StandardOutput.BaseStream.CopyTo($ms); [void]$p.WaitForExit(20000)
      $b = $ms.ToArray()
      $n = if ($b.Length -ge 4) { [BitConverter]::ToInt32($b, 0) } else { -1 }
      if ($n -eq $b.Length - 4) { Ok ("ajudante respondeu: " + [Text.Encoding]::UTF8.GetString($b, 4, $n)) }
      else { Erro 'o ajudante respondeu fora do formato que o Chrome entende (algo escreveu na saída antes dele)' }
    } catch { Erro "não consegui testar o ajudante: $($_.Exception.Message)" }
    finally { Remove-Item -LiteralPath $msg -ErrorAction SilentlyContinue }
  }
}

# ---- 5. interface e atalho ----
Titulo '5. Interface e atalho'
# a interface vem pronta (Interface\Automacao_PGFN.exe); se faltar, é compilada aqui com o .NET Framework do Windows
$exe = Join-Path $BASE 'Interface\Automacao_PGFN.exe'
if (-not (Test-Path -LiteralPath $exe) -and -not $SoVerificar) { & cmd /c "`"$(Join-Path $BASE 'Interface\compilar.bat')`"" | Out-Null }
if (Test-Path -LiteralPath $exe) { Ok 'interface pronta: Iniciar.bat (ou Interface\Automacao_PGFN.exe)' } else { Erro 'faltou Interface\Automacao_PGFN.exe (rode Interface\compilar.bat)' }
if (-not $SoVerificar) {
  $resp = Read-Host '   Criar o atalho "Automação PGFN" na Área de Trabalho? (S/N)'
  if ($resp -match '^[sS]') {
    $ws = New-Object -ComObject WScript.Shell
    $lnk = $ws.CreateShortcut((Join-Path ([Environment]::GetFolderPath('Desktop')) 'Automação PGFN.lnk'))
    $lnk.TargetPath = $exe; $lnk.WorkingDirectory = Split-Path $exe -Parent
    $lnk.IconLocation = "$chrome,0"; $lnk.Save()
    Ok 'atalho criado na Área de Trabalho'
  }
}

Write-Host ''
if ($problemas) { Write-Host "  Terminado com $problemas ponto(s) para conferir (acima, em amarelo/vermelho). Veja o README.md, Solução de problemas." -ForegroundColor Yellow }
else { Write-Host '  Tudo pronto. Para usar: Iniciar.bat (ou o atalho "Automação PGFN"): escolha o certificado, cole os CNPJs e clique em Iniciar.' -ForegroundColor Green }
Write-Host '  Depois de instalar ou atualizar a extensão, clique em "Recarregar" nela em chrome://extensions.'
