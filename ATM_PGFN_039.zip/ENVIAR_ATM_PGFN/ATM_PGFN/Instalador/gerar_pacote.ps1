﻿# Gera ATM_PGFN.zip para outro computador: a pasta ATM_PGFN pronta, SEM dados de clientes nem deste computador
# (configurações, andamentos, logs, atual/sinal, manifesto do ajudante, documentos). Quem recebe: extrai e roda Instalar.bat.
# Uso: Instalador\gerar_pacote.ps1 [-Saida <pasta>]  (padrão: a pasta acima de ATM_PGFN)
param([string]$Saida = '')
$ErrorActionPreference = 'Stop'
$BASE = Split-Path $PSScriptRoot -Parent
if (-not $Saida) { $Saida = Split-Path $BASE -Parent }
$tmp = Join-Path $env:TEMP ("pacote_atm_" + [guid]::NewGuid().ToString('N'))
$raiz = Join-Path $tmp 'ATM_PGFN'
New-Item -ItemType Directory -Force -Path $raiz | Out-Null
try {
  # só o que é necessário (lista fechada: nada de dados entra por engano)
  $itens = @(
    'Extensao_Chrome\manifest.json', 'Extensao_Chrome\background.js', 'Extensao_Chrome\content.js', 'Extensao_Chrome\pagina.js',
    'Extensao_Chrome\offscreen.html', 'Extensao_Chrome\offscreen.js',
    'Ajudante_Windows\salvar_como.bat', 'Ajudante_Windows\salvar_como.ps1', 'Ajudante_Windows\instalar_ajudante.bat',
    'Ajudante_Windows\instalar_ajudante.ps1', 'Ajudante_Windows\desinstalar_ajudante.bat',
    'Automacao\orquestrador.ps1',
    'Interface\Automacao_PGFN.exe', 'Interface\AutomacaoPGFN.cs', 'Interface\compilar.bat',
    'Instalador\instalar.ps1', 'Instalador\gerar_pacote.ps1',
    'Instalar.bat', 'Iniciar.bat', 'README.md'
  )
  foreach ($i in $itens) {
    $de = Join-Path $BASE $i
    if (-not (Test-Path -LiteralPath $de)) { throw "faltou no projeto: $i" }
    $para = Join-Path $raiz $i
    New-Item -ItemType Directory -Force -Path (Split-Path $para -Parent) | Out-Null
    Copy-Item -LiteralPath $de -Destination $para -Force
  }
  New-Item -ItemType Directory -Force -Path (Join-Path $raiz 'Configuracoes') | Out-Null
  [IO.File]::WriteAllText((Join-Path $raiz 'Configuracoes\LEIA.txt'), "Aqui ficam as configurações (certificado + CNPJs) criadas pela interface. Não edite à mão.`r`n", (New-Object Text.UTF8Encoding $true))
  # conferência: nenhum dado de cliente/computador no pacote
  $proibidos = @(Get-ChildItem -LiteralPath $raiz -Recurse -File | Where-Object { $_.Name -match '\.andamento\.json$|\.log$|^atual|^sinal|^execucao|com_auto_pgfn_salvar_como\.json|\.pfx$|\.p12$|cnpjs\.json$' })
  if ($proibidos.Count) { throw "arquivo que não pode ir no pacote: $($proibidos.Name -join ', ')" }
  $zip = Join-Path $Saida 'ATM_PGFN.zip'
  if (Test-Path -LiteralPath $zip) { Remove-Item -LiteralPath $zip -Force }
  Add-Type -AssemblyName System.IO.Compression.FileSystem
  [IO.Compression.ZipFile]::CreateFromDirectory($raiz, $zip, [IO.Compression.CompressionLevel]::Optimal, $true, [Text.Encoding]::UTF8)
  $versao = (Get-Content -LiteralPath (Join-Path $BASE 'Extensao_Chrome\manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json).version
  Write-Host ''
  Write-Host "  Pacote gerado ($(@(Get-ChildItem -LiteralPath $raiz -Recurse -File).Count) arquivos, extensão $versao):" -ForegroundColor Green
  Write-Host "  $zip"
  Write-Host '  Quem recebe: extrai a pasta ATM_PGFN (de preferência em Downloads) e roda Instalar.bat.'
} finally {
  Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue
}
