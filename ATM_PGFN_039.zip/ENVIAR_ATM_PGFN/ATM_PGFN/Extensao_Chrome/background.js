// Service worker: recebe o clique no ícone, guarda o andamento de cada aba e passa o andamento
// da aba do e-CAC para a janela nova do Regularize.
// Tudo fica no storage.session porque o script da página morre a cada mudança de página (e o service worker também dorme).
const PREFIXO = '[Automação_PGFN]';
const CHAVE_TRANSFERENCIA = 'transferencia';
const CHAVE_ULTIMA_ABA = 'ultima_aba_criada';
const VALIDADE_TRANSFERENCIA_MS = 120000;
const chaveDa = (idAba) => `aba_${idAba}`;

const hostDe = (url) => {
  try { return new URL(url).hostname; } catch (_) { return ''; }
};
// O endereço real tem "www.", que o Chrome esconde na barra de endereço.
// Para onde uma transferência pode ir: a página do Regularize (vinda do e-CAC) ou a aba própria do SISPAR (vinda do
// "CONTINUAR" no Regularize).
const DESTINOS = {
  regularize: /(^|\.)regularize\.pgfn\.gov\.br$/,
  sisparnet: /(^|\.)sisparnet\.pgfn\.fazenda\.gov\.br$/,
};
// O endereço a abrir vem da página: só aceita os domínios da própria automação.
const urlPermitida = (url) => {
  try {
    const u = new URL(url);
    return u.protocol === 'https:' && ['.receita.fazenda.gov.br', '.pgfn.gov.br', '.pgfn.fazenda.gov.br', '.estaleiro.serpro.gov.br']
      .some((d) => u.hostname.endsWith(d));
  } catch (_) {
    return false;
  }
};

async function lerTransferencia() {
  return (await chrome.storage.session.get(CHAVE_TRANSFERENCIA))[CHAVE_TRANSFERENCIA] || null;
}
const gravarTransferencia = (t) => chrome.storage.session.set({ [CHAVE_TRANSFERENCIA]: t });
const transferenciaPendente = (t) => t && !t.concluida && Date.now() - t.t < VALIDADE_TRANSFERENCIA_MS;

// ------------------------------- print da tela em PDF -------------------------------
// PDF mínimo de 1 página, do tamanho da imagem (96 dpi -> pontos), com o JPEG embutido.
function montarPdf(jpg, w, h) {
  const enc = new TextEncoder();
  const W = +(w * 0.75).toFixed(2);
  const H = +(h * 0.75).toFixed(2);
  const conteudo = `q ${W} 0 0 ${H} 0 0 cm /Im0 Do Q`;
  const partes = [];
  const offs = [];
  let pos = 0;
  const add = (x) => {
    const b = typeof x === 'string' ? enc.encode(x) : x;
    partes.push(b);
    pos += b.length;
  };
  const obj = (n, corpo) => {
    offs[n] = pos;
    add(`${n} 0 obj\n${corpo}\nendobj\n`);
  };
  add('%PDF-1.4\n');
  obj(1, '<< /Type /Catalog /Pages 2 0 R >>');
  obj(2, '<< /Type /Pages /Kids [3 0 R] /Count 1 >>');
  obj(3, `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${W} ${H}] /Resources << /XObject << /Im0 4 0 R >> >> /Contents 5 0 R >>`);
  offs[4] = pos;
  add(`4 0 obj\n<< /Type /XObject /Subtype /Image /Width ${w} /Height ${h} /ColorSpace /DeviceRGB ` +
      `/BitsPerComponent 8 /Filter /DCTDecode /Length ${jpg.length} >>\nstream\n`);
  add(jpg);
  add('\nendstream\nendobj\n');
  obj(5, `<< /Length ${conteudo.length} >>\nstream\n${conteudo}\nendstream`);
  const xref = pos;
  let t = 'xref\n0 6\n0000000000 65535 f \n';
  for (let n = 1; n <= 5; n++) t += `${String(offs[n]).padStart(10, '0')} 00000 n \n`;
  t += `trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF\n`;
  add(t);
  const saida = new Uint8Array(pos);
  let p = 0;
  for (const b of partes) { saida.set(b, p); p += b.length; }
  return saida;
}

function bytesParaBase64(bytes) {
  let s = '';
  for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
  return btoa(s);
}

function dataUrlParaBytes(dataUrl) {
  const bin = atob(dataUrl.slice(dataUrl.indexOf(',') + 1));
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return bytes;
}

// ------------------------------- número do download x perfil -------------------------------
// Os downloads da própria extensão (prints, relatórios) ficam no perfil NORMAL do Chrome; os PDFs do site, na janela
// ANÔNIMA. Cada perfil numera os seus downloads, e o mesmo número pode existir nos dois. Em 09/11/2026 o download 190
// era o print da conta 12581379 (perfil normal) e também o PDF da conta 12581384 (janela anônima): a extensão leu o
// item errado, o Chrome perdeu o nome sugerido (a janela "Salvar como" abriu com o nome do site, "7172631317956373") e
// o relatório registrou o print como se fosse o documento. Por isso todo download é identificado por número + perfil.
const chaveId = (id, anonimo) => `${anonimo ? 'a' : 'n'}${id}`;
async function acharDownload(id, anonimo) {
  const itens = await chrome.downloads.search({ id });
  if (anonimo === undefined || anonimo === null) return itens.length === 1 ? itens[0] : null; // sem o perfil: só se não houver dúvida
  return itens.find((i) => !!i.incognito === !!anonimo) || null;
}
// download feito pela própria extensão (print, relatório, PDF baixado pelo endereço)
async function acharDownloadDaExtensao(id) {
  const itens = await chrome.downloads.search({ id });
  return itens.find((i) => i.byExtensionId === chrome.runtime.id) || (itens.length === 1 ? itens[0] : null);
}

function esperarDownload(id, limiteMs = 15000) {
  return new Promise((resolve) => {
    const buscar = async () => {
      const item = await acharDownloadDaExtensao(id);
      return item ? { caminho: item.filename, estado: item.state } : null;
    };
    const fim = async () => {
      chrome.downloads.onChanged.removeListener(ouvir);
      clearTimeout(timer);
      resolve(await buscar());
    };
    const ouvir = async (d) => {
      if (d.id !== id || !d.state || (d.state.current !== 'complete' && d.state.current !== 'interrupted')) return;
      // o mesmo número pode ser de um download da janela anônima: só termina quando o DA EXTENSÃO terminar
      const r = await buscar();
      if (r && (r.estado === 'complete' || r.estado === 'interrupted')) fim();
    };
    const timer = setTimeout(fim, limiteMs);
    chrome.downloads.onChanged.addListener(ouvir);
  });
}

// Pasta dentro de Downloads (ex.: "ATM_PGFN/Documentos_arrecadacao/..."): só letras, números, "_" e "-", sem "..".
const pastaValida = (p) => typeof p === 'string' && /^[\w-]+(\/[\w-]+)*$/.test(p);
// Nome "CNPJ;NOME DA EMPRESA.pdf": aceita espaço, acento e ";", mas nada que vire pasta ou seja proibido no Windows.
const nomeValido = (n) => typeof n === 'string' && n.length <= 180 && /^[^\\/:*?"<>|\x00-\x1f]+\.pdf$/.test(n) && !/^\./.test(n);

// Nome pedido para cada download da própria extensão. Com um ouvinte de onDeterminingFilename registrado, o Chrome
// ignora o `filename` do downloads.download quando o ouvinte responde sem nome, e o arquivo cai em Downloads como
// "download.pdf"/"download.csv" (foi o que aconteceu com o print e os relatórios em 06/11/2026). Por isso o ouvinte
// devolve o nome guardado aqui.
const nomesPedidos = new Map(); // url -> "pasta/nome"

async function baixar(url, pasta, nome) {
  const filename = `${pasta}/${nome}`;
  nomesPedidos.set(url, filename);
  try {
    return await chrome.downloads.download({ url, filename, conflictAction: 'uniquify', saveAs: false });
  } finally {
    setTimeout(() => nomesPedidos.delete(url), 60000);
  }
}

// Tira o print da parte visível da aba, gera o PDF e salva em Downloads/<pasta>/<nome>.
async function capturarEmPdf({ pasta, nome }, idAba) {
  if (!pastaValida(pasta) || !nomeValido(nome)) throw new Error('nome de pasta/arquivo inválido');
  const aba = await chrome.tabs.get(idAba);
  if (!aba.active) throw new Error('a aba não está em primeiro plano; deixe-a visível durante o print');
  const dataUrl = await chrome.tabs.captureVisibleTab(aba.windowId, { format: 'jpeg', quality: 92 });
  const jpg = dataUrlParaBytes(dataUrl);
  const bmp = await createImageBitmap(new Blob([jpg], { type: 'image/jpeg' }));
  const pdf = montarPdf(jpg, bmp.width, bmp.height);
  const url = 'data:application/pdf;base64,' + bytesParaBase64(pdf);
  let nomeFinal = nome;
  let id;
  try {
    id = await baixar(url, pasta, nomeFinal);
  } catch (e) {
    // Se o Chrome recusar o nome (ex.: por causa do ";"), salva com "_" no lugar, para não perder o print.
    if (!/filename|nome/i.test(e.message) || !nome.includes(';')) throw e;
    nomeFinal = nome.replace(/;/g, '_');
    console.warn(PREFIXO, `o Chrome recusou o nome "${nome}" (${e.message}); salvando como "${nomeFinal}"`);
    id = await baixar(url, pasta, nomeFinal);
  }
  const r = await esperarDownload(id);
  if (r && r.estado === 'interrupted') throw new Error('o Chrome interrompeu o download do PDF');
  const caminho = (r && r.caminho) || `Downloads/${pasta}/${nomeFinal}`;
  console.log(PREFIXO, `PDF salvo em ${caminho}`);
  return { ok: true, caminho, nomeAjustado: nomeFinal !== nome };
}

// ------------------------------- documentos baixados pela própria página -------------------------------
// Antes de clicar no ícone de emissão, a aba "arma" uma espera: o próximo download (feito pelo site, não pela extensão)
// nos próximos segundos recebe o nome "CNPJ;NOME;MM-AAAA" e vai para a pasta pedida. O resultado fica guardado pela
// chave da prestação (conta|prestação), e a aba consulta até ele chegar. Sem espera armada, nada muda nos downloads.
const CHAVE_DL_ESPERA = 'download_espera';
const CHAVE_DL_IDS = 'download_ids';
const CHAVE_DL_RESULTADOS = 'download_resultados';
const lerSessao = async (k, padrao) => (await chrome.storage.session.get(k))[k] || padrao;
const baseValida = (n) => typeof n === 'string' && n.length <= 170 && /^[^\\/:*?"<>|\x00-\x1f]+$/.test(n) && !/^\./.test(n);

function extensaoDe(item) {
  if (/pdf/i.test(item.mime || '')) return '.pdf'; // o servidor pode mandar o PDF com nome ".jsf"
  const m = /\.([a-z0-9]{2,5})$/i.exec(item.filename || '');
  return m ? `.${m[1].toLowerCase()}` : '.pdf'; // sem extensão no nome do site: o documento de arrecadação é PDF
}

async function gravarResultadoDownload(chave, r) {
  const todos = await lerSessao(CHAVE_DL_RESULTADOS, {});
  todos[chave] = { ...(todos[chave] || {}), ...r, t: Date.now() };
  await chrome.storage.session.set({ [CHAVE_DL_RESULTADOS]: todos });
}

// origem: 'site' (PDF baixado pela página, na janela anônima) ou 'extensao' (baixado pela própria extensão).
async function associarDownload(id, chave, anonimo, origem = 'site') {
  const ids = await lerSessao(CHAVE_DL_IDS, {});
  ids[chaveId(id, anonimo)] = chave;
  await chrome.storage.session.set({ [CHAVE_DL_IDS]: ids });
  await gravarResultadoDownload(chave, { iniciado: true, id, anonimo: !!anonimo, origem, tInicio: Date.now() });
  console.log(PREFIXO, `[salvamento] ${chave}: download ${chaveId(id, anonimo)} (${origem}) associado`);
}

// 0.35.0 — O item é MESMO o download associado? Mesmo número, mesmo perfil e mesma origem. Em 10/11/2026 o PDF do site
// (janela anônima) e o print da conta anterior (perfil normal, feito pela extensão) tinham o mesmo número; a busca por
// número devolveu o print, e ele foi tomado como o documento (a conferência barrou, mas a prestação travou). O print
// nunca pode ser o resultado de um download do site, nem o contrário.
const itemConfere = (i, r) => !!i && i.id === r.id && !!i.incognito === !!r.anonimo &&
  ((r.origem || 'site') === 'extensao' ? i.byExtensionId === chrome.runtime.id : i.byExtensionId !== chrome.runtime.id);
async function acharItemAssociado(r) {
  if (!r || r.id === undefined || r.id === null) return null;
  let itens = (await chrome.downloads.search({ id: r.id })).filter((i) => itemConfere(i, r));
  // a busca por número pode devolver só o item do OUTRO perfil: procura entre os downloads recentes
  if (!itens.length) {
    const desde = new Date((r.tInicio || r.t || Date.now()) - 120000).toISOString();
    itens = (await chrome.downloads.search({ startedAfter: desde })).filter((i) => itemConfere(i, r));
  }
  return itens[0] || null;
}

// Download feito pela própria extensão (normalmente no perfil normal): associa pelo perfil real do item.
async function associarDownloadDaExtensao(id, chave) {
  const item = await acharDownloadDaExtensao(id);
  await associarDownload(id, chave, item ? item.incognito : false, 'extensao');
  if (item && (item.state === 'complete' || item.state === 'interrupted')) await registrarFimDownload(item, chave); // terminou antes
}

// Resultado final de um download associado (só o item do perfil certo).
async function registrarFimDownload(item, chave) {
  const atual = (await lerSessao(CHAVE_DL_RESULTADOS, {}))[chave];
  if (atual && atual.ok !== undefined && atual.id === item.id) return; // já registrado
  // 0.35.0: item de outro perfil/origem com o mesmo número (ex.: o print da conta anterior) não vale como resultado
  if (atual && atual.id !== undefined && atual.id !== null && !itemConfere(item, atual)) {
    console.warn(PREFIXO, `[salvamento] ${chave}: ignorei o download ${chaveId(item.id, item.incognito)} (${item.filename || '?'}): não é o associado (${chaveId(atual.id, atual.anonimo)}, ${atual.origem || 'site'})`);
    return;
  }
  await gravarResultadoDownload(chave, item.state === 'complete'
    ? { ok: true, caminho: item.filename, bytes: item.fileSize || item.bytesReceived || item.totalBytes || -1, mime: item.mime }
    : { ok: false, erro: item.error === 'USER_CANCELED' ? 'download cancelado (janela "Salvar como" fechada)' : (item.error || 'download interrompido'), cancelado: item.error === 'USER_CANCELED' });
  console.log(PREFIXO, `[salvamento] ${chave}: download ${chaveId(item.id, item.incognito)} terminou (${item.state}) ${item.filename || item.error || ''}`);
}

chrome.downloads.onDeterminingFilename.addListener((item, sugerir) => {
  // Downloads da própria extensão (prints, relatório, PDF baixado pelo endereço): devolve o nome pedido.
  if (item.byExtensionId === chrome.runtime.id) {
    const pedido = nomesPedidos.get(item.url) || nomesPedidos.get(item.finalUrl);
    if (pedido) sugerir({ filename: pedido, conflictAction: 'uniquify' }); else sugerir();
    return;
  }
  (async () => {
    const e = await lerSessao(CHAVE_DL_ESPERA, null);
    if (!e || Date.now() > e.ate) { sugerir(); return; }
    await chrome.storage.session.remove(CHAVE_DL_ESPERA); // só o primeiro download depois do clique
    // O site devolveu uma página HTML, não o PDF: cancela antes de salvar (não vai para a pasta do CNPJ como documento).
    if (/html/i.test(item.mime || '') || /\.html?$/i.test(item.filename || '')) {
      console.warn(PREFIXO, `download do site não é PDF (${item.mime || item.filename}); cancelado`);
      sugerir();
      chrome.downloads.cancel(item.id).catch(() => {});
      await gravarResultadoDownload(e.chave, { ok: false, naoPdf: true, erro: `o site devolveu uma página (${item.mime || 'HTML'}) em vez do PDF` });
      return;
    }
    const filename = `${e.pasta}/${e.nome}${extensaoDe(item)}`;
    console.log(PREFIXO, `download do site renomeado: ${item.filename || item.url} -> ${filename}`);
    // perfil do item; se o Chrome não informar, o da aba que clicou no link
    await associarDownload(item.id, e.chave, item.incognito === undefined ? !!e.anonimo : item.incognito, 'site');
    // para o ajudante conferir (e, se o Chrome perder o nome sugerido, colocar o certo na janela "Salvar como")
    await gravarResultadoDownload(e.chave, { pasta: e.pasta, nome: `${e.nome}${extensaoDe(item)}`, numero: e.numero || '' });
    sugerir({ filename, conflictAction: 'uniquify' });
  })().catch((err) => { console.warn(PREFIXO, 'renomear download:', err.message); try { sugerir(); } catch (_) { /* já sugerido */ } });
  return true; // resposta assíncrona
});

chrome.downloads.onChanged.addListener(async (d) => {
  if (!d.state || (d.state.current !== 'complete' && d.state.current !== 'interrupted')) return;
  const ids = await lerSessao(CHAVE_DL_IDS, {});
  // o aviso traz só o número; o mesmo número pode existir nos dois perfis: para cada prestação associada a esse número,
  // procura o SEU item (perfil e origem certos) e registra só se ele terminou
  const chaves = [ids[chaveId(d.id, true)], ids[chaveId(d.id, false)]].filter(Boolean);
  if (!chaves.length) return;
  const resultados = await lerSessao(CHAVE_DL_RESULTADOS, {});
  for (const chave of chaves) {
    const item = await acharItemAssociado(resultados[chave]);
    if (item && (item.state === 'complete' || item.state === 'interrupted')) await registrarFimDownload(item, chave);
  }
});

// Documento aberto numa aba nova (em vez de baixado): baixa o endereço dela com o nome certo, fecha essa aba e volta
// para a aba da automação. Só se nenhum download já tiver chegado para essa prestação (evita baixar duas vezes).
chrome.tabs.onUpdated.addListener(async (idAba, mudou, aba) => {
  if (mudou.status !== 'complete') return;
  const e = await lerSessao(CHAVE_DL_ESPERA, null);
  if (!e || Date.now() > e.ate || aba.openerTabId !== e.abaId || idAba === e.abaId) return;
  const r = (await lerSessao(CHAVE_DL_RESULTADOS, {}))[e.chave];
  if (r && r.iniciado) return;
  const url = aba.url || aba.pendingUrl || '';
  await chrome.storage.session.remove(CHAVE_DL_ESPERA);
  if (!urlPermitida(url)) {
    await gravarResultadoDownload(e.chave, { ok: false, abaNova: url.slice(0, 200),
      erro: `o documento abriu numa aba nova (${url.slice(0, 60)}…) que a extensão não consegue baixar` });
    chrome.tabs.update(e.abaId, { active: true }).catch(() => {});
    return;
  }
  try {
    const id = await baixar(url, e.pasta, `${e.nome}.pdf`);
    await associarDownloadDaExtensao(id, e.chave);
    chrome.tabs.remove(idAba).catch(() => {});
  } catch (err) {
    await gravarResultadoDownload(e.chave, { ok: false, erro: `aba nova com o documento, mas o download falhou: ${err.message}` });
  }
  chrome.tabs.update(e.abaId, { active: true }).catch(() => {});
});

// ------------------------------- vários downloads do SISPAR -------------------------------
// O Chrome bloqueia o 2º download automático de um site e pergunta "quer fazer o download de vários arquivos"
// (Permitir/Bloquear). A extensão não clica nesse aviso (é da janela do Chrome, não da página): ela libera a permissão
// "Downloads automáticos" SÓ para o site do SISPAR. A permissão some se a extensão for removida. Na janela anônima, vale
// até ela ser fechada; por isso é refeita antes de cada documento.
const SITES_DOWNLOADS = ['https://sisparnet.pgfn.fazenda.gov.br/*'];
async function liberarDownloadsAutomaticos(aba) {
  if (!chrome.contentSettings || !chrome.contentSettings.automaticDownloads) return;
  for (const primaryPattern of SITES_DOWNLOADS) {
    for (const scope of (aba && aba.incognito ? ['regular', 'incognito_session_only'] : ['regular'])) {
      try {
        await chrome.contentSettings.automaticDownloads.set({ primaryPattern, setting: 'allow', scope });
      } catch (e) {
        console.warn(PREFIXO, `não consegui liberar vários downloads em ${primaryPattern} (${scope}):`, e.message);
      }
    }
  }
}
chrome.runtime.onInstalled.addListener(() => liberarDownloadsAutomaticos(null));
chrome.runtime.onStartup.addListener(() => liberarDownloadsAutomaticos(null));
// Ao abrir o Chrome (ou recarregar a extensão): confere se o ajudante do Windows responde (fica no ajudante.log).
chrome.runtime.onStartup.addListener(() => chamarAjudante({ acao: 'versao' }).then((r) => console.log(PREFIXO, 'ajudante:', JSON.stringify(r))));
chrome.runtime.onInstalled.addListener(() => chamarAjudante({ acao: 'versao' }).then((r) => console.log(PREFIXO, 'ajudante:', JSON.stringify(r))));

// ------------------------------- página de login aberta na partida do Chrome -------------------------------
// O orquestrador abre o Chrome já no endereço do login. Essa aba pode carregar antes de a extensão terminar de subir e
// aí o Chrome não injeta o content.js nela (o login automático não começa). Conferimos as páginas de login e, se o
// script não estiver lá, injetamos o mesmo content.js (ele mesmo evita rodar duas vezes). Só nas páginas de login.
const URL_LOGIN = /^https:\/\/(cav\.receita\.fazenda\.gov\.br\/autenticacao|sso\.acesso\.gov\.br\/)/i;
async function garantirScriptLogin(abaId, url) {
  if (!URL_LOGIN.test(url || '') || !chrome.scripting) return;
  try {
    const [r] = await chrome.scripting.executeScript({ target: { tabId: abaId }, func: () => !!window.__autoPgfnCarregado });
    if (r && r.result) return;
    console.warn(PREFIXO, `página de login sem o script da extensão (aba ${abaId}); injetando`);
    await chrome.scripting.executeScript({ target: { tabId: abaId }, files: ['content.js'] });
  } catch (e) {
    console.warn(PREFIXO, 'injetar na página de login:', e.message);
  }
}
chrome.tabs.onUpdated.addListener((idAba, mudou, aba) => {
  // dá tempo ao Chrome de injetar pelo manifest (document_idle) antes de conferir
  if (mudou.status === 'complete' && URL_LOGIN.test(aba.url || '')) setTimeout(() => garantirScriptLogin(idAba, aba.url), 4000);
});
// service worker acabou de subir: confere as páginas de login que já estavam abertas
chrome.tabs.query({}).then((abas) => abas.forEach((a) => { if (a.status === 'complete') garantirScriptLogin(a.id, a.url); })).catch(() => {});

// Registro permanente (storage.local) dos PDFs já salvos: CNPJ|conta|prestação|mês da emissão -> arquivo.
const CHAVE_REGISTRO = 'registro_downloads';

// Situação do download de uma prestação. `aguardandoSalvar`: o download começou, mas o Chrome ainda não tem o
// caminho final, ou seja, a janela "Salvar como" está esperando a pessoa (opção "Perguntar onde salvar" ligada).
async function statusDownload(chave) {
  const r = (await lerSessao(CHAVE_DL_RESULTADOS, {}))[chave] || null;
  if (!r || r.ok !== undefined || r.id === undefined || r.id === null) return r;
  const item = await acharItemAssociado(r);
  if (item && (item.state === 'complete' || item.state === 'interrupted')) { // o aviso de fim se perdeu (ex.: service worker reiniciado)
    await registrarFimDownload(item, chave);
    return (await lerSessao(CHAVE_DL_RESULTADOS, {}))[chave] || null;
  }
  if (item && item.state === 'in_progress' && !item.filename && Date.now() - (r.tInicio || r.t) > 1500) {
    confirmarSalvarComo(chave, r); // sem esperar: a aba continua consultando o status
    const atual = (await lerSessao(CHAVE_DL_RESULTADOS, {}))[chave] || r;
    return { ...atual, aguardandoSalvar: true, tJanela: atual.tJanela || Date.now() };
  }
  return r;
}

// Nenhum download foi associado à prestação depois do clique (ex.: o Chrome não chamou o ouvinte do nome): procura o
// download do SITE (não da extensão) que começou depois do clique, na mesma janela (anônima ou não). Só associa se
// houver exatamente um candidato, para nunca pegar o arquivo de outra prestação.
async function procurarDownload(chave, desde, anonimo, numero) {
  const r = (await lerSessao(CHAVE_DL_RESULTADOS, {}))[chave];
  if (r && r.iniciado) return { achou: true, jaAssociado: true };
  const ids = await lerSessao(CHAVE_DL_IDS, {});
  const itens = (await chrome.downloads.search({ startedAfter: new Date(desde - 3000).toISOString() }))
    .filter((i) => i.byExtensionId !== chrome.runtime.id && !!i.incognito === !!anonimo && !ids[chaveId(i.id, i.incognito)])
    .filter((i) => !/html/i.test(i.mime || '') && i.state !== 'interrupted');
  const doNumero = numero ? itens.filter((i) => (i.filename || i.url || '').includes(numero)) : [];
  const alvo = doNumero.length === 1 ? doNumero[0] : itens.length === 1 ? itens[0] : null;
  if (!alvo) return { achou: false, candidatos: itens.length };
  await chrome.storage.session.remove(CHAVE_DL_ESPERA);
  await associarDownload(alvo.id, chave, alvo.incognito, 'site');
  if (alvo.state === 'complete') await registrarFimDownload(alvo, chave);
  console.log(PREFIXO, `[salvamento] ${chave}: download sem nome sugerido encontrado (${chaveId(alvo.id, alvo.incognito)}, ${alvo.filename || 'janela "Salvar como"'})`);
  return { achou: true };
}

// ------------------------------- ajudante do Windows (janela "Salvar como") -------------------------------
// A janela "Salvar como" é do Windows, não da página: a extensão não consegue clicar nela. O ajudante
// (ATM_PGFN\Ajudante_Windows, registrado uma vez pelo Instalar.bat) confere a pasta do CNPJ, o
// nome e o tipo PDF e só então clica em "Salvar". Duas tentativas por documento; sem o ajudante, a pessoa clica.
const AJUDANTE = 'com.auto_pgfn.salvar_como';

// ------------------------------- fim do CNPJ: "Sair com Segurança" no e-CAC -------------------------------
// O orquestrador fecha o Chrome a cada CNPJ. Fechado à força, o e-CAC não fica sabendo e conta a sessão como um
// "dispositivo conectado" até ela expirar; depois de alguns CNPJs, recusa o login (erro 93003). Por isso, antes do aviso
// final ao orquestrador, cada aba do e-CAC desta janela ANÔNIMA (a da automação; o Chrome normal nunca é tocado) clica
// em "Sair com Segurança". Depois disso o login automático fica desligado até o Chrome fechar.
const CHAVE_SAIU_ECAC = 'ecac_sessao_encerrada';
async function esperarAbaMudar(idAba, urlAntes, ms) {
  const fim = Date.now() + ms;
  while (Date.now() < fim) {
    await new Promise((r) => setTimeout(r, 500));
    const a = await chrome.tabs.get(idAba).catch(() => null);
    if (!a) return 'fechada';
    if ((a.url || '') !== urlAntes && a.status === 'complete') return a.url;
  }
  return null;
}
async function sairDoEcac(abaPedido) {
  if (!abaPedido || !abaPedido.incognito) return { ok: true, abas: [], motivo: 'fora da janela anônima da automação: nada encerrado' };
  cacheOrq = null;
  await chrome.storage.session.set({ [CHAVE_SAIU_ECAC]: Date.now() });
  const abas = (await chrome.tabs.query({ url: 'https://cav.receita.fazenda.gov.br/*' }))
    .filter((a) => a.incognito && !/^\/autenticacao/i.test(new URL(a.url).pathname));
  const resultado = [];
  for (const a of abas) {
    // A aba do e-CAC fica atrás da do SISPAR; em segundo plano o Chrome atrasa os tempos da página e a seta não chegava
    // ao botão (o fim do CNPJ travou em 09/11 11:00). Por isso ela vem para a frente antes, e há um tempo máximo.
    await chrome.tabs.update(a.id, { active: true }).catch(() => {});
    if (a.windowId !== undefined) await chrome.windows.update(a.windowId, { focused: true }).catch(() => {});
    await new Promise((ok) => setTimeout(ok, 800));
    let r;
    try {
      r = await Promise.race([
        chrome.tabs.sendMessage(a.id, { tipo: 'sair-ecac' }, { frameId: 0 }),
        // 0.34.0: 45 s (a aba pode fechar a janela "Alterar perfil" e clicar 2 vezes no "Sair")
        new Promise((_, falhar) => setTimeout(() => falhar(Object.assign(new Error('a aba não respondeu em 45 s'), { tempo: true })), 45000)),
      ]);
    } catch (e) {
      // a página mudou com o clique antes de responder; ou não respondeu a tempo (segue mesmo assim)
      r = e.tempo ? { clicou: false, erro: e.message } : { clicou: 'provavelmente', erro: e.message };
    }
    const depois = r && r.clicou ? await esperarAbaMudar(a.id, a.url, 15000) : null;
    resultado.push({ aba: a.id, ...r, depois });
  }
  return { ok: true, abas: resultado };
}
let cacheOrq = null; // { t, r }: CNPJ da vez lido do orquestrador
const chamadasAjudante = new Map(); // chave -> nº de chamadas em andamento/feitas

async function chamarAjudante(pedido, limiteMs = 50000) {
  try {
    // o ajudante tem 30 s para achar a janela; sem resposta em 50 s, desiste (não fica "conferindo" para sempre).
    // 0.38.0: o certificado tem mais tempo (a lista é percorrida inteira, linha a linha, depois de a janela abrir)
    return await Promise.race([
      chrome.runtime.sendNativeMessage(AJUDANTE, pedido),
      new Promise((_, rejeitar) => setTimeout(() => rejeitar(new Error(`o ajudante não respondeu em ${Math.round(limiteMs / 1000)} s`)), limiteMs)),
    ]);
  } catch (e) {
    return { ok: false, semAjudante: /not found|não encontrado|native messaging host|forbidden/i.test(e.message), erro: e.message };
  }
}

// Janela "Salvar como" aberta: o ajudante confere a pasta do CNPJ e o nome (e coloca o nome certo se o Chrome tiver
// aberto a janela com o nome do site) e clica em "Salvar". Até TENTATIVAS_AJUDANTE chamadas por documento, com pausa
// entre elas; depois, 'esgotado' (a aba decide: fecha a janela de forma controlada e tenta de novo, ou pausa).
const TENTATIVAS_AJUDANTE = 3;
const PAUSA_ENTRE_AJUDANTE_MS = [0, 4000, 8000];
const AJUDANTE_PRESO_MS = 70000; // 'chamando' há mais que isso: a chamada se perdeu (service worker reiniciado)
async function confirmarSalvarComo(chave, r) {
  const feitas = Math.max(chamadasAjudante.get(chave) || 0, r.ajudanteTentativas || 0);
  if (['salvou', 'esgotado', 'fechando', 'fechada'].includes(r.ajudante)) return;
  if (r.ajudante === 'chamando' && Date.now() - (r.tAjudante || 0) < AJUDANTE_PRESO_MS) return;
  if (r.ajudanteResposta && r.ajudanteResposta.semAjudante) {
    await gravarResultadoDownload(chave, { ajudante: 'esgotado' });
    return;
  }
  if (feitas >= TENTATIVAS_AJUDANTE) {
    await gravarResultadoDownload(chave, { ajudante: 'esgotado' });
    return;
  }
  if (r.ajudante === 'falhou' && Date.now() - (r.tAjudanteFim || r.t) < PAUSA_ENTRE_AJUDANTE_MS[Math.min(feitas, 2)]) return;
  chamadasAjudante.set(chave, feitas + 1);
  await gravarResultadoDownload(chave, { ajudante: 'chamando', ajudanteTentativas: feitas + 1, tAjudante: Date.now() });
  console.log(PREFIXO, `[salvamento] ${chave}: janela "Salvar como" aberta; ajudante, tentativa ${feitas + 1} de ${TENTATIVAS_AJUDANTE} (${r.pasta}/${r.nome})`);
  const resp = await chamarAjudante({ acao: 'confirmar', pasta: r.pasta, nome: r.nome, numero: r.numero || '', timeoutMs: 30000 });
  console.log(PREFIXO, `[salvamento] ${chave}: ajudante, tentativa ${feitas + 1}:`, JSON.stringify(resp));
  const ok = !!(resp && resp.ok);
  await gravarResultadoDownload(chave, {
    ajudante: ok ? 'salvou' : (resp && resp.semAjudante) || feitas + 1 >= TENTATIVAS_AJUDANTE ? 'esgotado' : 'falhou',
    ajudanteResposta: resp, tAjudanteFim: Date.now(),
  });
}

// Fecha a janela "Salvar como" desta prestação de forma controlada (botão "Cancelar"), para tentar de novo.
async function fecharSalvarComo(chave) {
  let r = (await lerSessao(CHAVE_DL_RESULTADOS, {}))[chave] || {};
  // o ajudante ainda está nesta janela: espera ele terminar (nunca dois comandos ao mesmo tempo na mesma janela)
  while (r.ajudante === 'chamando' && Date.now() - (r.tAjudante || 0) < AJUDANTE_PRESO_MS) {
    await new Promise((ok) => setTimeout(ok, 1000));
    r = (await lerSessao(CHAVE_DL_RESULTADOS, {}))[chave] || {};
  }
  if (r.ok) return { ok: true, fechou: false, motivo: 'o download terminou antes de fechar a janela' };
  await gravarResultadoDownload(chave, { ajudante: 'fechando' });
  const resp = await chamarAjudante({ acao: 'cancelar', pasta: r.pasta, nome: r.nome, numero: r.numero || '', timeoutMs: 8000 });
  console.log(PREFIXO, `[salvamento] ${chave}: fechar a janela "Salvar como":`, JSON.stringify(resp));
  // a janela fechada cancela o download no Chrome; se ainda constar "em andamento", cancela pela extensão
  if (r.id !== undefined && r.id !== null) {
    const item = await acharItemAssociado(r); // 0.35.0: só o download DESTE documento (perfil e origem certos)
    if (item && item.state === 'in_progress') {
      if (!item.filename) await chrome.downloads.cancel(item.id).catch(() => {});
    }
  }
  await gravarResultadoDownload(chave, { ajudante: 'fechada', ajudanteFechar: resp });
  return resp || { ok: false, erro: 'sem resposta do ajudante' };
}

// CNPJ terminado na aba do SISPAR: a aba do e-CAC recebe o próximo da lista (andamento do zero, com a lista dos
// concluídos) e recarrega; as abas do Regularize e do SISPAR desse CNPJ são fechadas, para não confundir a passagem.
async function proximoCnpj({ cnpj, concluidos, abaEcac, abaRegularize }, abaAtual) {
  if (!/^\d{14}$/.test(cnpj || '') || !abaEcac) return false;
  try { await chrome.tabs.get(abaEcac); } catch (_) { return false; } // a aba do e-CAC foi fechada
  await chrome.storage.session.set({ [chaveDa(abaEcac)]: {
    etapa: 0, cnpj, concluidos: Array.isArray(concluidos) ? concluidos : [], cursor: null, retomadas: 0, t: Date.now(),
  } });
  await chrome.tabs.update(abaEcac, { active: true });
  await chrome.tabs.reload(abaEcac);
  setTimeout(() => {
    [abaRegularize, abaAtual].filter((id) => id && id !== abaEcac).forEach((id) => chrome.tabs.remove(id).catch(() => {}));
  }, 2500);
  return true;
}

// ------------------------------- print da página inteira em PDF -------------------------------
// A aba rola de cima para baixo e pede uma foto de cada parte; no fim, as partes viram uma imagem só, cada uma na
// sua altura da página (y), e o PDF é salvo em Downloads/<pasta>/<nome>.
const partesDoPrint = new Map(); // id da aba -> [{ y, util, janela, dataUrl }]

async function fotografarParte(idAba, { y, util, janela }) {
  const aba = await chrome.tabs.get(idAba);
  if (!aba.active) throw new Error('a aba não está em primeiro plano; deixe-a visível durante o print');
  const dataUrl = await chrome.tabs.captureVisibleTab(aba.windowId, { format: 'png' });
  const lista = partesDoPrint.get(idAba) || [];
  lista.push({ y, util, janela, dataUrl });
  partesDoPrint.set(idAba, lista);
  return { ok: true, partes: lista.length };
}

async function montarPrint(idAba, { pasta, nome }) {
  if (!pastaValida(pasta) || typeof nome !== 'string' || !/^[^\\/:*?"<>|\x00-\x1f]+\.pdf$/.test(nome)) {
    throw new Error('nome de pasta/arquivo inválido');
  }
  const partes = partesDoPrint.get(idAba) || [];
  partesDoPrint.delete(idAba);
  if (!partes.length) throw new Error('nenhuma parte fotografada');
  // a montagem é no documento invisível da extensão (ver offscreen.js)
  if (!(await chrome.offscreen.hasDocument())) {
    await chrome.offscreen.createDocument({ url: 'offscreen.html', reasons: ['BLOBS'],
      justification: 'Montar o print de confirmação da página inteira em PDF' });
  }
  const m = await chrome.runtime.sendMessage({ alvo: 'offscreen', tipo: 'montar-pdf', partes });
  if (!m || !m.ok) throw new Error((m && m.erro) || 'a montagem do print falhou');
  try {
    const id = await baixar(m.url, pasta, nome);
    const r = await esperarDownload(id, 60000);
    if (r && r.estado === 'interrupted') throw new Error('o Chrome interrompeu o download do print');
    return { ok: true, caminho: (r && r.caminho) || `Downloads/${pasta}/${nome}`, partes: partes.length, bytes: m.bytes };
  } finally {
    chrome.runtime.sendMessage({ alvo: 'offscreen', tipo: 'liberar', url: m.url }).catch(() => {});
  }
}

// Texto (relatório .csv) salvo em Downloads/<pasta>/<nome>.
async function salvarTexto({ pasta, nome, texto }) {
  if (!pastaValida(pasta) || typeof nome !== 'string' || !/^[^\\/:*?"<>|\x00-\x1f]+\.csv$/.test(nome) || nome.length > 180) {
    throw new Error('nome de pasta/arquivo inválido');
  }
  const bytes = new TextEncoder().encode('﻿' + texto); // BOM: o Excel abre com acentos certos
  const id = await baixar('data:text/csv;charset=utf-8;base64,' + bytesParaBase64(bytes), pasta, nome);
  const r = await esperarDownload(id);
  if (r && r.estado === 'interrupted') throw new Error('o Chrome interrompeu o download do relatório');
  return { ok: true, caminho: (r && r.caminho) || `Downloads/${pasta}/${nome}` };
}

chrome.action.onClicked.addListener(async (aba) => {
  try {
    await chrome.tabs.sendMessage(aba.id, { tipo: 'icone' }, { frameId: 0 });
    await chrome.action.setBadgeText({ tabId: aba.id, text: '' });
    await chrome.action.setTitle({ tabId: aba.id, title: '' });
  } catch (e) {
    // Sem resposta: a aba não é do e-CAC/Regularize, ou foi aberta antes de a extensão ser carregada.
    console.warn(PREFIXO, 'sem resposta da aba:', e.message);
    await chrome.action.setBadgeBackgroundColor({ tabId: aba.id, color: '#b03a2e' });
    await chrome.action.setBadgeText({ tabId: aba.id, text: '!' });
    await chrome.action.setTitle({
      tabId: aba.id,
      title: 'Esta aba não está no e-CAC nem no Regularize. Se estiver, aperte F5 nela e clique de novo no ícone.',
    });
  }
});

// A primeira página do destino que carrega enquanto há transferência pendente assume o andamento.
async function lerEstado(idAba, url) {
  const chave = chaveDa(idAba);
  const t = await lerTransferencia();
  const destino = t && DESTINOS[t.destino || 'regularize'];
  if (transferenciaPendente(t) && destino && destino.test(hostDe(url)) && idAba !== t.origem) {
    {
      // abaEcac/abaRegularize: para, ao terminar o CNPJ, voltar ao e-CAC com o próximo da lista
      const estado = { etapa: 0, cnpj: t.cnpj, confirmado: t.confirmado, empresa: t.empresa, cursor: null, retomadas: 0, t: Date.now(),
        abaEcac: t.abaEcac || ((t.destino || 'regularize') === 'regularize' ? t.origem : null),
        abaRegularize: t.destino === 'sisparnet' ? t.origem : null, concluidos: t.concluidos || [] };
      await chrome.storage.session.set({ [chave]: estado });
      await gravarTransferencia({ ...t, abriu: true, concluida: true });
      return estado;
    }
  }
  return (await chrome.storage.session.get(chave))[chave] || null;
}

chrome.runtime.onMessage.addListener((msg, remetente, responder) => {
  const aba = remetente.tab;
  if (!aba) return false;
  const chave = chaveDa(aba.id);
  const responderCom = (promessa) => {
    promessa.then(responder, (e) => {
      console.warn(PREFIXO, msg.tipo, 'falhou:', e.message);
      responder(null);
    });
    return true;
  };

  switch (msg.tipo) {
    case 'estado-ler':
      return responderCom(lerEstado(aba.id, remetente.url));
    case 'estado-gravar':
      return responderCom((msg.estado
        ? chrome.storage.session.set({ [chave]: msg.estado })
        : chrome.storage.session.remove(chave)).then(() => true));
    case 'transferencia-iniciar':
      return responderCom(gravarTransferencia({
        origem: aba.id, destino: msg.destino || 'regularize', cnpj: msg.cnpj, confirmado: msg.confirmado, empresa: msg.empresa,
        abaEcac: msg.abaEcac || null, concluidos: Array.isArray(msg.concluidos) ? msg.concluidos : [],
        abriu: false, concluida: false, t: Date.now(),
      }).then(() => true));
    case 'transferencia-status':
      return responderCom(lerTransferencia());
    case 'aba-info':
      responder({ anonima: !!aba.incognito });
      return false;
    case 'capturar':
      return responderCom(capturarEmPdf(msg, aba.id).catch((e) => ({ ok: false, erro: e.message })));
    case 'download-preparar':
      if (!pastaValida(msg.pasta) || !baseValida(msg.nome)) { responder(false); return false; }
      // antes do clique: o 2º, 3º... PDF do site não pode esbarrar no aviso "vários arquivos" do Chrome
      return responderCom(liberarDownloadsAutomaticos(aba).then(() => chrome.storage.session.set({ [CHAVE_DL_ESPERA]: {
        abaId: aba.id, anonimo: !!aba.incognito, chave: msg.chave, pasta: msg.pasta, nome: msg.nome, ate: Date.now() + (msg.validadeMs || 60000),
        numero: /^\d{6,30}$/.test(msg.numero || '') ? msg.numero : '',
      } })).then(() => gravarResultadoDownload(msg.chave, { pasta: msg.pasta, nome: `${msg.nome}.pdf`,
        numero: /^\d{6,30}$/.test(msg.numero || '') ? msg.numero : '' })).then(() => true));
    case 'download-procurar':
      return responderCom(procurarDownload(msg.chave, Number(msg.desde) || Date.now() - 60000, !!aba.incognito, msg.numero || ''));
    case 'download-fechar-janela':
      return responderCom(fecharSalvarComo(msg.chave));
    case 'janelas-salvar-como':
      return responderCom(chamarAjudante({ acao: 'janelas' }));
    case 'download-limpar':
      return responderCom(lerSessao(CHAVE_DL_RESULTADOS, {}).then((t) => {
        delete t[msg.chave];
        chamadasAjudante.delete(msg.chave);
        return chrome.storage.session.set({ [CHAVE_DL_RESULTADOS]: t });
      }).then(() => true));
    case 'download-cancelar':
      return responderCom(chrome.storage.session.remove(CHAVE_DL_ESPERA).then(() => true));
    case 'download-status':
      return responderCom(statusDownload(msg.chave));
    // ---- orquestrador (vários CNPJs e certificados), sempre por meio do ajudante do Windows ----
    case 'orq-atual':
      return responderCom(chrome.storage.session.get(CHAVE_SAIU_ECAC).then((s) => {
        // a sessão do e-CAC já foi encerrada no fim deste CNPJ: nada de entrar de novo (o orquestrador fecha o Chrome)
        // 0.33.1: pergunta ao ajudante se o orquestrador ainda está rodando. No ÚLTIMO CNPJ da lista ele termina e não fecha
        // o Chrome; antes o aviso dizia "o orquestrador fecha o Chrome e segue" e parecia travado (10/11/2026 09:19).
        if (s[CHAVE_SAIU_ECAC]) {
          return chamarAjudante({ acao: 'orq-atual' }).catch(() => null).then((r) => {
            if (r && r.ok && !r.ativo && r.motivo) return { ok: true, ativo: false, fim: !!r.fim, parado: !!r.parado, encerramento: r.encerramento || '', motivo: r.motivo };
            return { ok: true, ativo: false, motivo: 'a sessão do e-CAC foi encerrada no fim deste CNPJ; o orquestrador fecha o Chrome e segue para o próximo' };
          });
        }
        // CNPJ da vez (guardado por 20 s para não chamar o ajudante a cada página)
        if (cacheOrq && Date.now() - cacheOrq.t < 20000) return cacheOrq.r;
        return chamarAjudante({ acao: 'orq-atual' }).then((r) => {
          if (r && r.ok) cacheOrq = { t: Date.now(), r };
          return r;
        });
      }));
    case 'orq-informar':
      return responderCom(chamarAjudante({ acao: 'orq-informar', sessao: msg.sessao, cnpj: msg.cnpj, situacao: msg.situacao, mensagem: msg.mensagem }));
    case 'orq-finalizar':
      // fim do CNPJ: primeiro "Sair com Segurança" no e-CAC (evita o erro 93003), depois o aviso ao orquestrador
      // tempo máximo para a saída: o aviso ao orquestrador SEMPRE sai (nunca fica parado esperando o "Sair")
      return responderCom(Promise.race([
        sairDoEcac(aba),
        new Promise((ok) => setTimeout(() => ok({ ok: false, erro: 'a saída do e-CAC passou de 75 s; seguindo' }), 75000)),
      ]).catch((e) => ({ ok: false, erro: e.message })).then((saida) => {
        console.log(PREFIXO, 'sessão do e-CAC no fim do CNPJ:', JSON.stringify(saida));
        // 0.34.0: o log do orquestrador diz se a sessão foi mesmo encerrada (antes não dava para saber)
        const abas = (saida && saida.abas) || [];
        const sessao = !saida || !saida.ok ? `não confirmada (${(saida && saida.erro) || 'sem resposta'})`
          : !abas.length ? (saida.motivo || 'nenhuma aba do e-CAC com login aberta')
            : abas.some((a) => a.depois) ? 'encerrada ("Sair com Segurança")'
              : `não confirmada (${abas.map((a) => a.motivo || a.erro || 'a página não mudou').join('; ')})`;
        return chamarAjudante({ acao: 'orq-informar', sessao: msg.sessao, cnpj: msg.cnpj, situacao: msg.situacao,
          mensagem: `${msg.mensagem || ''}\nSessão do e-CAC: ${sessao}` });
      }));
    case 'certificado-selecionar':
      // janela "Selecione um certificado" do Chrome: o ajudante escolhe o configurado (nunca outro) e clica em OK
      return responderCom(chamarAjudante({ acao: 'certificado', nome: msg.nome, exato: !!msg.exato, timeoutMs: 40000 }, 180000));
    case 'ajudante-status':
      // o ajudante do Windows responde? (versão) — conferido no começo de cada CNPJ
      return responderCom(chamarAjudante({ acao: 'versao' }));
    case 'procurar-documento': // 0.35.0: o PDF desta prestação já está no disco? (nome pedido ou número do documento)
      if (!pastaValida(msg.pasta) || !baseValida(msg.nome)) { responder({ ok: false, erro: 'pasta/nome inválidos' }); return false; }
      return responderCom(chamarAjudante({ acao: 'procurar-documento', pasta: msg.pasta, nome: `${msg.nome}.pdf`,
        numero: /^\d{6,30}$/.test(msg.numero || '') ? msg.numero : '', desde: Number(msg.desde) || 0 }));
    case 'conferir-arquivo':
      // o PDF existe no disco e começa com "%PDF"? (só com o ajudante instalado; sem ele, devolve semAjudante)
      return responderCom(chamarAjudante({ acao: 'conferir', caminho: msg.caminho }));
    case 'orq-progresso':
      // progresso + checkpoint para o vigia de travamentos do orquestrador (sem resposta esperada)
      return responderCom(chamarAjudante({ acao: 'orq-progresso', sessao: msg.sessao, cnpj: msg.cnpj, texto: msg.texto, checkpoint: msg.checkpoint }));
    // Registro dos PDFs já salvos: no Chrome (storage.local) e, desde a 0.33.0, também em disco pelo ajudante
    // (Automacao\registro_salvos.json). Se o Chrome perder o seu (perfil novo/limpo), o do disco ainda impede emitir de
    // novo e salvar print repetido.
    case 'registro-ver':
      return responderCom(chrome.storage.local.get(CHAVE_REGISTRO).then(async (r) => {
        const local = (r[CHAVE_REGISTRO] || {})[msg.chave];
        if (local) return local;
        const disco = await chamarAjudante({ acao: 'registro-ver', chave: msg.chave });
        return disco && disco.ok && disco.registro ? disco.registro : null;
      }));
    case 'registro-gravar':
      return responderCom(chrome.storage.local.get(CHAVE_REGISTRO).then((r) => {
        const todos = r[CHAVE_REGISTRO] || {};
        todos[msg.chave] = { arquivo: msg.arquivo, t: Date.now() };
        return chrome.storage.local.set({ [CHAVE_REGISTRO]: todos });
      }).then(() => chamarAjudante({ acao: 'registro-gravar', chave: msg.chave, arquivo: msg.arquivo })).then(() => true));
    case 'download-url':
      // a página tentou abrir o documento numa janela que o Chrome bloqueou: baixa o endereço com o nome certo
      if (!urlPermitida(msg.url) || !pastaValida(msg.pasta) || !baseValida(msg.nome)) { responder(false); return false; }
      return responderCom(chrome.storage.session.remove(CHAVE_DL_ESPERA)
        .then(() => baixar(msg.url, msg.pasta, `${msg.nome}.pdf`))
        .then((id) => associarDownloadDaExtensao(id, msg.chave)).then(() => true));
    case 'print-inicio':
      partesDoPrint.set(aba.id, []);
      responder(true);
      return false;
    case 'print-parte':
      return responderCom(fotografarParte(aba.id, msg).catch((e) => ({ ok: false, erro: e.message })));
    case 'print-salvar':
      return responderCom(montarPrint(aba.id, msg).catch((e) => ({ ok: false, erro: e.message })));
    case 'proximo-cnpj':
      return responderCom(proximoCnpj(msg, aba.id));
    case 'salvar-texto':
      return responderCom(salvarTexto(msg).catch((e) => ({ ok: false, erro: e.message })));
    case 'ao-quadro':
      // Vai para todos os quadros da aba; só responde o quadro que tem o elemento. Ninguém respondeu = null.
      return responderCom(chrome.tabs.sendMessage(aba.id, msg.dados).then((r) => r || null, () => null));
    case 'ultima-aba-criada':
      return responderCom(chrome.storage.session.get(CHAVE_ULTIMA_ABA).then((r) => r[CHAVE_ULTIMA_ABA] || 0));
    case 'abrir-url':
      if (!urlPermitida(msg.url)) { responder(false); return false; }
      return responderCom(chrome.tabs.create({ url: msg.url, windowId: aba.windowId, openerTabId: aba.id }).then(() => true));
    default:
      return false;
  }
});

// Uma aba ou janela nova enquanto a transferência está pendente: o clique abriu a janela.
chrome.tabs.onCreated.addListener(async () => {
  await chrome.storage.session.set({ [CHAVE_ULTIMA_ABA]: Date.now() });
  const t = await lerTransferencia();
  if (transferenciaPendente(t) && !t.abriu) await gravarTransferencia({ ...t, abriu: true });
});

chrome.tabs.onRemoved.addListener((idAba) => {
  chrome.storage.session.remove(chaveDa(idAba));
});
