// Roda no mundo da própria página (manifest: "world": "MAIN").
// 1) Anota o endereço que a página tenta abrir em janela nova (para diagnóstico e para o aviso de pop-up bloqueado).
// 2) No "CONTINUAR" do simulador do SISPAR, que faz `window.open(url, "_blank") || window.location.replace(url)`:
//    com o clique simulado o Chrome bloqueia a janela, e o simulador carrega o SISPAR DENTRO do quadro, onde a sessão
//    (cookie de terceiros) se perde ("Sessão encerrada"). Por isso, só quando a automação acabou de clicar em
//    "CONTINUAR" (marca data-pgfn-auto), a abertura é entregue à extensão, que abre a aba nova UMA vez, como no uso
//    manual. A página recebe uma "janela" de mentira para não carregar o endereço também no quadro (a chave de acesso
//    do endereço é de uso único).
(() => {
  const original = window.open;
  const raiz = () => document.documentElement;
  const janelaFalsa = (url) => ({
    closed: false, opener: null, focus() {}, blur() {}, close() {}, postMessage() {},
    location: { href: url, assign() {}, replace() {} },
  });
  window.open = function (url, alvo, recursos, ...resto) {
    let abs = null;
    try { abs = new URL(url, location.href).href; } catch (_) { /* endereço vazio ou inválido */ }
    const marca = Number(raiz().getAttribute('data-pgfn-auto') || 0);
    if (abs && /^https:\/\/sisparnet\.pgfn\.fazenda\.gov\.br\//.test(abs) && Date.now() - marca < 20000) {
      raiz().removeAttribute('data-pgfn-auto');
      raiz().setAttribute('data-pgfn-abrir', abs);
      document.dispatchEvent(new Event('pgfn-abrir-aba'));
      return janelaFalsa(abs);
    }
    const janela = original.call(this, url, alvo, recursos, ...resto);
    try {
      // Com "noopener"/"noreferrer" o window.open devolve null mesmo quando a janela abre: isso não é bloqueio.
      const semRetorno = /noopener|noreferrer/i.test(String(recursos || ''));
      if (abs) window.top.postMessage({ pgfnAbertura: { url: abs, bloqueada: !janela && !semRetorno } }, '*');
    } catch (_) { /* sem acesso ao topo */ }
    return janela;
  };
})();
