// Documento invisível da extensão (chrome.offscreen): junta as fotos das partes da página num PDF só e devolve um
// endereço blob:, que o service worker baixa. O service worker não consegue criar esse endereço sozinho, e um
// endereço data: acima de 2 MB é recusado pelo Chrome.
chrome.runtime.onMessage.addListener((msg, _remetente, responder) => {
  if (!msg || msg.alvo !== 'offscreen') return false;
  if (msg.tipo === 'montar-pdf') {
    montar(msg).then(responder, (e) => responder({ ok: false, erro: e.message }));
    return true;
  }
  if (msg.tipo === 'liberar') { try { URL.revokeObjectURL(msg.url); } catch (_) { /* já liberado */ } }
  return false;
});

async function montar({ partes }) {
  const imagens = await Promise.all(partes.map(async (p) => createImageBitmap(await (await fetch(p.dataUrl)).blob())));
  const escala = imagens[0].height / partes[0].janela; // pixels da foto por pixel da página
  const largura = imagens[0].width;
  let altura = Math.round(Math.max(...partes.map((p) => p.y + p.util)) * escala);
  const reduzir = Math.min(1, 30000 / altura); // limite de altura de imagem do navegador
  altura = Math.round(altura * reduzir);
  const tela = new OffscreenCanvas(Math.round(largura * reduzir), altura);
  const ctx = tela.getContext('2d');
  ctx.fillStyle = '#fff';
  ctx.fillRect(0, 0, tela.width, tela.height);
  partes.forEach((p, i) => {
    const h = Math.min(imagens[i].height, Math.round(p.util * escala));
    ctx.drawImage(imagens[i], 0, 0, largura, h, 0, Math.round(p.y * escala * reduzir), Math.round(largura * reduzir), Math.round(h * reduzir));
  });
  // Print de confirmação em PDF: a imagem da página inteira (JPEG de alta qualidade) numa página do tamanho dela.
  const jpg = new Uint8Array(await (await tela.convertToBlob({ type: 'image/jpeg', quality: 0.95 })).arrayBuffer());
  const pdf = montarPdf(jpg, tela.width, tela.height, escala);
  const blob = new Blob([pdf], { type: 'application/pdf' });
  return { ok: true, url: URL.createObjectURL(blob), bytes: blob.size, largura: tela.width, altura: tela.height };
}

// PDF mínimo de 1 página com o JPEG embutido (mesmo formato do print "sem parcelamento", em background.js).
// A página fica no tamanho da página da web (pixels da foto / escala da tela, a 96 dpi), limitada a 14400 pt, o maior
// tamanho de página que os leitores de PDF aceitam.
function montarPdf(jpg, w, h, escala = 1) {
  const enc = new TextEncoder();
  let W = (w / escala) * 0.75;
  let H = (h / escala) * 0.75;
  const ajuste = Math.min(1, 14400 / Math.max(W, H));
  W = +(W * ajuste).toFixed(2);
  H = +(H * ajuste).toFixed(2);
  const conteudo = `q ${W} 0 0 ${H} 0 0 cm /Im0 Do Q`;
  const partes = [];
  const offs = [];
  let pos = 0;
  const add = (x) => { const b = typeof x === 'string' ? enc.encode(x) : x; partes.push(b); pos += b.length; };
  const obj = (n, corpo) => { offs[n] = pos; add(`${n} 0 obj\n${corpo}\nendobj\n`); };
  add('%PDF-1.4\n');
  obj(1, '<< /Type /Catalog /Pages 2 0 R >>');
  obj(2, '<< /Type /Pages /Kids [3 0 R] /Count 1 >>');
  obj(3, `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${W} ${H}] /Resources << /XObject << /Im0 4 0 R >> >> /Contents 5 0 R >>`);
  offs[4] = pos;
  add(`4 0 obj\n<< /Type /XObject /Subtype /Image /Width ${w} /Height ${h} /ColorSpace /DeviceRGB ` +
      `/BitsPerComponent 8 /Filter /DCTDecode /Length ${jpg.length} >>\nstream\n`);
  add(jpg);
  add('\nendstream\nendobj\n');
  obj(5, `<< /Length ${conteudo.length} >>\nstream\n${conteudo}\nendstream`);
  const xref = pos;
  let t = 'xref\n0 6\n0000000000 65535 f \n';
  for (let n = 1; n <= 5; n++) t += `${String(offs[n]).padStart(10, '0')} 00000 n \n`;
  t += `trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF\n`;
  add(t);
  const saida = new Uint8Array(pos);
  let p = 0;
  for (const b of partes) { saida.set(b, p); p += b.length; }
  return saida;
}
