(() => {
  'use strict';
  // Uma cópia só por página: o background pode injetar este script de novo numa página de login aberta na partida do
  // Chrome (quando o Chrome não injetou); se o do manifest também rodar, a segunda cópia sai aqui.
  if (window.__autoPgfnCarregado) return;
  window.__autoPgfnCarregado = true;

  // O manifest carrega este script em todos os quadros dos sites da automação. A primeira coisa é sair de qualquer
  // lugar que não seja: a página do e-CAC, a do Regularize ou um quadro dentro do Regularize.
  const EM_QUADRO = window.top !== window;
  const QUADRO_DO_REGULARIZE = EM_QUADRO &&
    [...location.ancestorOrigins].some((o) => /[/.]regularize\.pgfn\.gov\.br$/.test(o));
  if (EM_QUADRO && !QUADRO_DO_REGULARIZE) return;
  if (!EM_QUADRO && !/(^|\.)(cav\.receita\.fazenda|regularize\.pgfn|sisparnet\.pgfn\.fazenda|sso\.acesso)\.gov\.br$/.test(location.hostname)) return;

  // ===================== CONFIGURAÇÃO (fácil de trocar) =====================
  // CNPJs de teste, em ordem: usa o primeiro que não seja o perfil já ativo. Se o e-CAC disser que não há procuração
  // eletrônica para ele, passa para o próximo da lista. Se o único que sobrar já estiver ativo, segue sem trocar.
  const CNPJS_TESTE = []; // modo manual (sem o orquestrador): vazio, para nunca processar um CNPJ fora da lista (09/11 17:12)
  // Com o orquestrador rodando (orquestrador\orquestrador.ps1), a lista é só o CNPJ da vez, definido em cnpjs.json.
  let LISTA_CNPJS = CNPJS_TESTE;
  let ORQ = null; // { cnpj, certificado, sessao } quando o orquestrador está ativo
  const TIMEOUT_ELEMENTO_MS = 20000;  // tempo máximo esperando cada elemento aparecer
  const TIMEOUT_JANELA_MS = 8000;     // depois de cada clique, tempo esperando a janela abrir
  const TENTATIVAS_ABRIR_JANELA = 3;  // quantas vezes clica em "Alterar perfil de acesso"
  const TIMEOUT_TROCA_PERFIL_MS = 45000; // depois de "Alterar", tempo esperando o topo mostrar o CNPJ novo
  const LIMITE_RECARGAS_PERFIL = 2;      // se a troca travar, recarrega a página (F5) e tenta de novo até este número de vezes
  const ESPERA_ABRIR_JANELA_MS = 10000;  // sem janela nova nesse tempo, considera bloqueada como pop-up (só e-CAC -> Regularize)
  const TIMEOUT_NOVA_JANELA_MS = 60000;  // tempo para a janela nova chegar ao Regularize
  const TIMEOUT_REGULARIZE_MS = 45000;   // tempo para a página do Regularize carregar
  const ESPERA_AVISO_CIENTE_MS = 10000;  // com a página pronta, tempo esperando o aviso "Atenção!" (ele pode não vir)
  const LENTIDAO_MOUSE = 1.1;         // maior = seta mais devagar
  const LENTIDAO_DIGITACAO = 1.8;     // maior = digitação mais devagar
  const VALIDADE_ANDAMENTO_MS = 600000; // andamento mais velho que isso (10 min) é ignorado
  const LIMITE_RETOMADAS = 12;        // mudanças de página seguidas antes de desistir
  const INICIAR_NA_TELA_INICIAL = true; // true = começa sozinha ao abrir/recarregar a tela inicial do e-CAC
  const ESPERA_TELA_INICIAL_MS = 6000;  // tempo para reconhecer a tela inicial ao carregar
  // Lentidão ou falha temporária (um elemento que não aparece no tempo): espera e repete a MESMA etapa; se continuar,
  // recarrega a página (F5) e retoma do mesmo ponto. Nunca passa ao próximo CNPJ por isso. Limites evitam repetição sem fim.
  const REPETICOES_POR_ETAPA = 2;          // repete a etapa (sem recarregar) até este número de vezes
  const ESPERA_ANTES_DE_REPETIR_MS = [6000, 10000]; // espera (aleatória entre os dois valores) antes de cada repetição
  const RECARGAS_POR_LENTIDAO = 2;         // depois, recarrega a página e retoma, até este número de vezes por aba
  // ==========================================================================

  const PREFIXO = '[Automação_PGFN]';
  const TEXTO_TITULAR = /titular \(acesso|procurador de:/i;
  const TEXTO_BOTAO = 'Alterar perfil de acesso';
  const TEXTO_JANELA = 'Escolha uma das opções e altere o perfil de acesso';
  const TEXTO_CAMPO = 'Procurador de pessoa jurídica - CNPJ';
  const OPCOES_JANELA = [
    'Procurador de pessoa física - CPF',
    TEXTO_CAMPO,
    'CNPJ matriz atuando como CNPJ filial',
    'Sucessora atuando como sucedida',
    'CNPJ vinculado ao Ente Federativo',
  ];
  const TEXTO_TELA_INICIAL = 'Prezado Contribuinte';
  const TEXTO_CONTINUAR_ECAC = 'Continuar no e-CAC por enquanto'; // aviso "Prepare-se para a evolução..." do e-CAC
  // aviso "Atenção! Você possui mensagens importantes (com o indicativo "!") ainda não lidas na sua Caixa Postal..."
  const TEXTO_AVISO_CAIXA_POSTAL = 'Você possui mensagens importantes';
  const TEXTO_IR_CAIXA_POSTAL = 'Ir para a Caixa Postal';
  const TEXTO_SAIR_SEGURANCA = 'Sair com Segurança'; // encerra a sessão do e-CAC no fim de cada CNPJ (evita o erro 93003)
  // erro 93003 do e-CAC: "Você atingiu o número máximo de dispositivos conectados simultaneamente com esta conta."
  const TEXTO_MAXIMO_DISPOSITIVOS = 'número máximo de dispositivos conectados';
  const ESPERAS_93003_S = [60, 180, 300]; // espera antes de cada nova tentativa de login (3 tentativas); depois, PAUSA
  const ESPERA_AVISO_ECAC_MS = 3000; // com a página carregada, tempo dando chance ao aviso aparecer
  const TEXTO_SEM_PROCURACAO = 'Não existe procuração eletrônica';
  // 0.37.0: "A procuração eletrônica cadastrada para o detentor … foi cancelada em DD/MM/AAAA" (data e titular variam)
  const TEXTO_PROC_CANCELADA = 'foi cancelada em';
  const TEXTO_DIVIDA = 'Dívida Ativa da União';
  const OPCOES_DIVIDA = [
    'Consulta Pendências - Situação Fiscal',
    'Opções da Lei nº 11.941/2009',
    'PGFN - Todos os serviços do Regularize',
  ];
  const TENTATIVAS_ABRIR_DIVIDA = 3;
  const TEXTO_REGULARIZE = 'PGFN - Todos os serviços do Regularize';
  const ESPERA_BLOCO_REGULARIZE_MS = 8000; // painel da Dívida Ativa aberto: tempo esperando essa opção antes de pular o CNPJ
  const TEXTO_CIENTE = 'CIENTE';
  const TEXTO_SEM_CADASTRO_REGULARIZE = 'Você ainda não está cadastrado no REGULARIZE';
  const TEXTO_AVISO_NOTIFICACOES = 'você tem novas notificações na caixa de mensagens da PGFN';
  const TEXTO_FECHAR_NOTIFICACOES = 'FECHAR';
  const ESPERA_AVISO_NOTIFICACOES_MS = 5000; // página carregada: tempo dando chance ao aviso de notificações aparecer
  const TENTATIVAS_CIENTE = 3;
  const TEXTO_NEGOCIAR = 'NEGOCIAR DÍVIDA';
  const TENTATIVAS_NEGOCIAR = 3;
  const TEXTO_BLOCO_ACESSO = 'Acesso ao Sistema de Negociações - Parcelamento ou Acordo de Transação';
  const TEXTO_PROXIMO_BLOCO = 'Revisão da Capacidade de Pagamento'; // o botão certo fica antes deste bloco
  const TEXTO_ACESSAR = 'ACESSAR';
  const ESPERA_REACAO_ACESSAR_MS = 3000; // sem janela nova nesse tempo, confere se foi bloqueada como pop-up
  const TEXTO_BOAS_VINDAS = 'Bem-vindo ao Sistema de Negociações da PGFN';
  const TEXTO_CONSULTAR = 'CONSULTAR';
  const OPCOES_SISTEMA = ['SIMULAR/NEGOCIAR', TEXTO_CONSULTAR, 'EMITIR GUIA', 'DÉBITO AUTOMÁTICO', 'CAPACIDADE DE PAGAMENTO', 'RECIBOS', 'DECLARAÇÃO DE RECEITA'];
  const TENTATIVAS_CONSULTAR = 3;
  const TEXTO_AVISO_SISPAR = 'Você será redirecionado para outro ambiente do sistema SISPAR';
  const TEXTO_CONTINUAR = 'CONTINUAR';
  const TENTATIVAS_CONTINUAR = 3;
  const ESPERA_REACAO_CONTINUAR_MS = 15000; // tempo observando a reação depois de cada clique em "CONTINUAR"
  const TEXTO_TELA_PGFN = 'Procuradoria Geral da Fazenda Nacional';
  const TEXTO_MENU_EMISSAO = 'Emissão de Documento';
  const TEXTO_DOC_ARRECADACAO = 'Documento de arrecadação'; // texto exato: não confunde com "...Avulso"
  const TENTATIVAS_MENU = 3;
  const TEXTO_TELA_EMISSAO = 'EMISSÃO DE DOCUMENTO DE ARRECADAÇÃO';
  const TEXTO_SEM_NEGOCIACAO = 'Não foram encontradas solicitações de negociação';
  const TEXTO_SEM_PERMISSAO = 'Você não tem permissão de acesso ou ele expirou';
  // DIAGNÓSTICO (temporário): true = a automação para na tela da PGFN e VOCÊ passa o mouse em "Emissão de Documento" e
  // clica em "Documento de arrecadação"; depois ela continua sozinha. Serve para saber se o erro de permissão vem do
  // clique da automação. false = a automação faz tudo.
  const CLIQUE_MANUAL_NO_DOCUMENTO = false;
  const ESPERA_CLIQUE_MANUAL_MS = 180000; // tempo esperando você clicar, no modo de diagnóstico
  const ESPERA_RESULTADO_MS = 15000; // tempo máximo esperando a mensagem de "sem negociação" ou a tabela
  const TEXTO_COL_SITUACAO = 'Situação da conta';
  const TEXTO_COL_CONTA = 'Número da Conta';
  const TEXTO_DEFERIDA = 'DEFERIDA E CONSOLIDADA';
  const TEXTO_BOTAO_DOC = 'Documento de Arrecadação'; // botão abaixo da tabela (mesmo texto da opção do menu)
  const TEXTO_TELA_DETALHE = 'EMISSÃO DE DOCUMENTO DE ARRECADAÇÃO - INTERNET';
  const TENTATIVAS_SELECIONAR = 2;
  const TENTATIVAS_ORDENAR = 2; // o 1º clique ordena; se ficar ao contrário, o 2º inverte // com a tela de emissão aberta, tempo esperando a mensagem de "sem negociação"
  // Pastas dentro da pasta de downloads do Chrome (o Chrome só salva lá dentro).
  // Diretório de saída (ATM_PGFN): <Downloads do Chrome>\ATM_PGFN\Documentos_arrecadacao. Dentro dele, uma pasta por
  // certificado e, nela, UMA pasta por CNPJ (só dígitos) com TUDO o que o CNPJ gera. Ver pastaDoCliente().
  const PASTA_DOCUMENTOS = 'ATM_PGFN/Documentos_arrecadacao';
  // Desde a 0.32.0, com o orquestrador (interface de configuração), a pasta do CNPJ fica dentro da pasta do CERTIFICADO:
  // Documentos_arrecadacao\<CERTIFICADO>\<CNPJ>. O nome da pasta do certificado vem do orquestrador (só letras, números,
  // "_" e "-"). Sem orquestrador (modo manual) ou sem esse nome, continua Documentos_arrecadacao\<CNPJ> (como antes).
  const pastaDocumentos = () => {
    const p = ORQ && ORQ.pastaCertificado;
    return /^[A-Za-z0-9_-]{1,80}$/.test(p || '') ? `${PASTA_DOCUMENTOS}/${p}` : PASTA_DOCUMENTOS;
  };
  // Página da negociação: tabela "Prestação", coluna "Emissão".
  const TEXTO_COL_PRESTACAO = 'Nr. Prestação';
  const TEXTO_COL_EMISSAO = 'Emissão';
  const ESPERA_SALVAR_COMO_MS = 180000; // janela "Salvar como" do Chrome aberta: tempo esperando a pessoa clicar em Salvar
  const ESPERA_DOCUMENTO_MS = 45000;  // depois do clique no link do PDF, tempo esperando o download chegar
  const TEXTO_JANELA_EMISSAO = 'Cálculo e demonstrativo de emissão de Documento de Arrecadação';
  const TEXTO_PARCELA_EMISSAO = 'Parcela para emissão';
  const TEXTO_EMITIR = 'Emitir';
  // janela de emissão com cálculo prévio (parcelas que dependem da receita bruta do mês anterior)
  const TEXTO_CALCULAR = 'Calcular';
  const TEXTO_RECEITA_BRUTA = 'Receita bruta apurada no mês anterior';
  const TEXTO_PERMITIR_COOKIES = 'Permitir'; // aviso de cookies das páginas da PGFN
  const TEXTO_VOLTAR = 'Voltar';
  // PDF não salvo (nada chegou, página no lugar do PDF, ou janela "Salvar como" que o ajudante não conseguiu confirmar e
  // foi fechada de forma controlada): clica no link do PDF de novo (o documento já está emitido; o link só baixa o mesmo
  // PDF). Esgotadas as tentativas: PAUSA para você salvar (nunca segue em silêncio).
  const TENTATIVAS_LINK_PDF = 3;
  const PROCURAR_DOWNLOAD_APOS_MS = 5000; // sem download associado depois do clique: procura o do site a cada 5 s
  const ROLAGEM_DENTE_PX = [70, 125]; // cada "dente" da roda do mouse rola entre estes valores
  const OPCOES_REGULARIZE = ['NEGOCIAR DÍVIDA', 'CONSULTAR DÍVIDA ATIVA', 'EMITIR GUIA DE PAGAMENTO'];
  // O endereço real tem "www.", que o Chrome esconde na barra de endereço.
  const NO_REGULARIZE = /(^|\.)regularize\.pgfn\.gov\.br$/.test(location.hostname);
  // Aba própria do SISPAR (aberta no "CONTINUAR", como no uso manual): aqui a tela da PGFN é a página principal.
  const NO_SISPARNET = !EM_QUADRO && /(^|\.)sisparnet\.pgfn\.fazenda\.gov\.br$/.test(location.hostname);
  const ID_SETA = 'pgfn-seta';
  const ID_AVISO = 'pgfn-aviso';

  let executando = false;
  let cancelado = false;
  let estado = null; // { etapa, cnpj, cursor, retomadas, t }
  let aberturaCapturada = null; // endereço que a página tentou abrir em janela nova (pagina.js)

  addEventListener('message', (e) => {
    if (e.data && e.data.pgfnAbertura) aberturaCapturada = e.data.pgfnAbertura;
  });

  // ------------------------------- utilitários -------------------------------
  const log = (...a) => console.log(PREFIXO, ...a);
  const rand = (a, b) => a + Math.random() * (b - a);
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  const norm = (s) => (s || '').replace(/\s+/g, ' ').trim().toLowerCase()
    .normalize('NFD').replace(/[̀-ͯ]/g, '');
  const chave = (s) => norm(s).replace(/[^a-z0-9]/g, '');
  const soDigitos = (s) => (s || '').replace(/\D/g, '');
  const formatarCnpj = (c) => c.replace(/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})$/, '$1.$2.$3/$4-$5');

  function erroCancelado() {
    const e = new Error('Automação parada pelo ícone da extensão.');
    e.cancelado = true;
    return e;
  }
  function conferirCancelado() { if (cancelado) throw erroCancelado(); }

  async function sleep(ms) {
    await new Promise((r) => setTimeout(r, ms));
    conferirCancelado();
  }

  // requestAnimationFrame não dispara em aba oculta; o timeout evita travar.
  const quadro = () => new Promise((r) => {
    let feito = false;
    const f = () => { if (!feito) { feito = true; r(); } };
    requestAnimationFrame(f);
    setTimeout(f, 50);
  });

  function cnpjValido(c) {
    if (!/^\d{14}$/.test(c) || /^(\d)\1+$/.test(c)) return false;
    const dv = (base) => {
      let soma = 0, peso = base.length - 7;
      for (let i = 0; i < base.length; i++) {
        soma += Number(base[i]) * peso--;
        if (peso < 2) peso = 9;
      }
      const r = soma % 11;
      return r < 2 ? 0 : 11 - r;
    };
    const d1 = dv(c.slice(0, 12));
    const d2 = dv(c.slice(0, 12) + d1);
    return d1 === Number(c[12]) && d2 === Number(c[13]);
  }

  // ------------------------------- andamento (sobrevive à mudança de página) -------------------------------
  async function mensagem(m) {
    try { return await chrome.runtime.sendMessage(m); } catch (e) {
      log('sem contato com o service worker:', e.message); // ex.: extensão recarregada com a página aberta
      return null;
    }
  }

  function gravarEstado() {
    if (estado) estado.t = Date.now();
    return mensagem({ tipo: 'estado-gravar', estado });
  }

  // ------------------------------- busca na página -------------------------------
  // Documento principal + iframes do mesmo domínio + shadow roots abertos.
  function todasRaizes() {
    const raizes = [document];
    for (let i = 0; i < raizes.length; i++) {
      for (const el of raizes[i].querySelectorAll('*')) {
        if (el.shadowRoot) raizes.push(el.shadowRoot);
        if (/^i?frame$/i.test(el.tagName)) {
          try { if (el.contentDocument && el.contentDocument.body) raizes.push(el.contentDocument); } catch (_) { /* outro domínio */ }
        }
      }
    }
    return raizes;
  }

  function visivel(el) {
    if (!el || !el.isConnected) return false;
    // sobe também pelos iframes e shadow roots: janela escondida esconde tudo que há dentro
    for (let e = el; e;) {
      const cs = getComputedStyle(e);
      if (cs.display === 'none' || cs.visibility === 'hidden' || Number(cs.opacity) <= 0.05) return false;
      const raiz = e.getRootNode();
      e = e.parentElement || raiz.host || (raiz.defaultView && raiz.defaultView.frameElement) || null;
    }
    // <span> inline pode não ter tamanho: olha até 4 ancestrais
    for (let e = el, i = 0; e && i < 4; e = e.parentElement, i++) {
      const r = e.getBoundingClientRect();
      if (r.width >= 1 && r.height >= 1) {
        const se = e.ownerDocument.scrollingElement; // escondido fora da página (não só rolado para fora da tela)
        return r.right + (se ? se.scrollLeft : 0) > 0 && r.bottom + (se ? se.scrollTop : 0) > 0;
      }
    }
    return false;
  }

  function acharTexto(texto) {
    const alvo = chave(texto);
    for (const raiz of todasRaizes()) {
      const w = (raiz.ownerDocument || raiz).createTreeWalker(raiz, NodeFilter.SHOW_TEXT);
      for (let n = w.nextNode(); n; n = w.nextNode()) {
        const pai = n.parentElement;
        if (!pai || pai.closest(`#${ID_AVISO}`) || ['SCRIPT', 'STYLE', 'NOSCRIPT'].includes(pai.tagName)) continue;
        if (chave(n.nodeValue).includes(alvo) && visivel(pai)) return pai;
      }
    }
    return null;
  }

  function acharCabecalho(regex) {
    for (const raiz of todasRaizes()) {
      const w = (raiz.ownerDocument || raiz).createTreeWalker(raiz, NodeFilter.SHOW_TEXT);
      for (let n = w.nextNode(); n; n = w.nextNode()) {
        const pai = n.parentElement;
        if (pai && !pai.closest(`#${ID_AVISO}`) && regex.test(n.nodeValue) && visivel(pai)) return pai;
      }
    }
    return null;
  }

  // Bloco do menu pelo texto exato (o texto inteiro do bloco, não um trecho de outra frase).
  function acharBlocoMenu(texto) {
    const alvo = chave(texto);
    for (const raiz of todasRaizes()) {
      const w = (raiz.ownerDocument || raiz).createTreeWalker(raiz, NodeFilter.SHOW_TEXT);
      for (let n = w.nextNode(); n; n = w.nextNode()) {
        const pai = n.parentElement;
        if (!pai || pai.closest(`#${ID_AVISO}`) || chave(n.nodeValue) !== alvo || !visivel(pai)) continue;
        return pai.closest('a, button, input, [role="button"], [onclick], li') || pai;
      }
      for (const e of raiz.querySelectorAll('input[value]')) {
        if (chave(e.value) === alvo && visivel(e)) return e;
      }
    }
    return null;
  }

  // O painel da Dívida Ativa está aberto? Pelo menos 2 das opções dele visíveis.
  const painelDividaAberto = () => OPCOES_DIVIDA.filter((o) => acharTexto(o)).length >= 2;

  // Lê do cabeçalho uma linha "<rótulo>: 00.000.000/0000-00 - NOME".
  function lerLinhaCabecalho(gatilho, rotulo) {
    const pai = acharCabecalho(gatilho);
    if (!pai) return null;
    const re = new RegExp(`${rotulo}\\s*([\\d./-]{11,18})\\s*-?\\s*(.{0,120})`, 'i');
    // Primeiro a própria linha de texto (assim o nome não leva junto o texto seguinte); se o CNPJ estiver em outra tag, o bloco todo.
    const linhas = [...pai.childNodes].filter((n) => n.nodeType === Node.TEXT_NODE).map((n) => n.nodeValue);
    let m = null;
    for (const t of [...linhas, pai.textContent || '']) {
      m = re.exec(t.replace(/\s+/g, ' '));
      if (m) break;
    }
    if (!m) return null;
    const nome = m[2].split(/respons[aá]vel legal|procurador de:|titular \(/i)[0].trim();
    return { doc: soDigitos(m[1]), docTexto: m[1], nome };
  }

  // Quem está ativo agora: "Procurador de:", se existir; senão, o "Titular" da primeira linha do cabeçalho.
  function lerPerfilAtual() {
    const procurador = lerLinhaCabecalho(/procurador de:/i, 'procurador de:');
    if (procurador) return { papel: 'Procurador de', ...procurador };
    const titular = lerLinhaCabecalho(/titular \(acesso/i, 'titular \\(acesso[^:]*:');
    return titular ? { papel: 'Titular', ...titular } : null;
  }

  function descreverPerfil(perfil) {
    return perfil
      ? `${perfil.papel}: ${perfil.docTexto}${perfil.nome ? ` - ${perfil.nome}` : ''}`
      : 'não consegui ler o CNPJ no cabeçalho';
  }

  // O primeiro da lista que não seja o perfil ativo nem um que já deu "sem procuração"; null se não sobrar nenhum.
  function escolherCnpj(perfil, semProcuracao = []) {
    const concluidos = (estado && estado.concluidos) || []; // já terminados nesta execução (vindos da aba do SISPAR)
    return LISTA_CNPJS.find((c) => !semProcuracao.includes(c) && !concluidos.includes(c) && !(perfil && perfil.doc === c)) || null;
  }

  function acharBotaoPerfil() {
    const el = acharTexto(TEXTO_BOTAO);
    if (el && !el.closest('[role="dialog"], .ui-dialog')) {
      return el.closest('a, button, input, [role="button"], [onclick]') || el;
    }
    // botão que leva o texto em title/alt/value
    const alvo = norm(TEXTO_BOTAO);
    for (const raiz of todasRaizes()) {
      for (const e of raiz.querySelectorAll('[title],[alt],input[value]')) {
        if ([e.title, e.alt, e.value].some((v) => norm(v) === alvo) && visivel(e)) return e;
      }
    }
    return null;
  }

  // Frase quebrada em várias tags (ex.: "Escolha uma das <b>opções</b>..."): não cabe num só nó de texto.
  function acharTextoDividido(texto) {
    const alvo = chave(texto);
    let melhor = null;
    for (const raiz of todasRaizes()) {
      for (const el of raiz.querySelectorAll('p, div, span, label, td, li, legend, h1, h2, h3, h4, h5, h6')) {
        if (el.closest(`#${ID_AVISO}`)) continue;
        const t = el.textContent || '';
        if (chave(t).includes(alvo) && (!melhor || t.length < melhor.textContent.length) && visivel(el)) melhor = el;
      }
    }
    return melhor;
  }

  // A janela é reconhecida pela frase de cima OU pela estrutura: pelo menos 3 das 5 opções visíveis.
  function acharJanela() {
    const frase = acharTexto(TEXTO_JANELA) || acharTextoDividido(TEXTO_JANELA);
    if (frase) return frase;
    const opcoes = OPCOES_JANELA.map((o) => acharTexto(o)).filter(Boolean);
    return opcoes.length >= 3 ? opcoes[0] : null;
  }

  const acharRotuloCampo = () => acharTexto(TEXTO_CAMPO);

  // O campo fica logo abaixo do rótulo, na mesma raiz (documento, iframe ou shadow).
  function acharCampoCnpj(rotulo) {
    const raiz = rotulo.getRootNode();
    if (rotulo.htmlFor) {
      const porId = raiz.getElementById(rotulo.htmlFor);
      if (porId && visivel(porId)) return porId;
    }
    const ignorados = ['hidden', 'button', 'submit', 'reset', 'image', 'checkbox', 'radio', 'file'];
    const rr = rotulo.getBoundingClientRect();
    return [...raiz.querySelectorAll('input, textarea')].find((i) => {
      if (ignorados.includes(i.type) || !visivel(i)) return false;
      if (!(rotulo.compareDocumentPosition(i) & Node.DOCUMENT_POSITION_FOLLOWING)) return false;
      const ri = i.getBoundingClientRect();
      return ri.top >= rr.top - 8 && ri.top - rr.top < 200;
    }) || null;
  }

  // O botão "Alterar" da MESMA linha do campo (a janela tem cinco botões iguais).
  function acharBotaoAlterarDoCampo(campo) {
    const raiz = campo.getRootNode();
    const rc = campo.getBoundingClientRect();
    const centro = rc.top + rc.height / 2;
    const textoDe = (e) => norm(e.tagName === 'INPUT' ? e.value : e.textContent);
    const todos = [...raiz.querySelectorAll('button, input[type="button"], input[type="submit"], a, [role="button"], span, div, td')]
      .filter((e) => {
        if (textoDe(e) !== 'alterar' || !visivel(e)) return false;
        if (!(campo.compareDocumentPosition(e) & Node.DOCUMENT_POSITION_FOLLOWING)) return false;
        const r = e.getBoundingClientRect();
        return Math.abs(r.top + r.height / 2 - centro) < 30;
      });
    const el = todos.filter((e) => !todos.some((o) => o !== e && e.contains(o)))[0];
    return el ? (el.closest('button, input, a, [role="button"]') || el) : null;
  }

  // O botão ACESSAR do bloco "Acesso ao Sistema de Negociações": o primeiro depois do título e antes do bloco seguinte.
  function acharBotaoAcessar() {
    const titulo = acharTexto(TEXTO_BLOCO_ACESSO);
    if (!titulo) return null;
    const proximo = acharTexto(TEXTO_PROXIMO_BLOCO);
    const depois = (a, b) => a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING;
    const todos = [...titulo.getRootNode().querySelectorAll('button, input[type="button"], input[type="submit"], a, [role="button"], span, div')]
      .filter((e) => {
        const texto = e.tagName === 'INPUT' ? e.value : e.textContent;
        if (chave(texto) !== chave(TEXTO_ACESSAR) || !visivel(e) || !depois(titulo, e)) return false;
        return !proximo || depois(e, proximo);
      });
    const el = todos.filter((e) => !todos.some((o) => o !== e && e.contains(o)))[0];
    return el ? (el.closest('button, input, a, [role="button"]') || el) : null;
  }

  // O botão está utilizável? Devolve o motivo quando não está (para a mensagem de erro ser útil).
  function motivoBotaoIndisponivel(el) {
    const r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return 'o botão está escondido';
    if (el.disabled || el.getAttribute('aria-disabled') === 'true') return 'o botão está desabilitado';
    if (getComputedStyle(el).pointerEvents === 'none') return 'o botão não aceita cliques';
    const topo = el.ownerDocument.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2);
    if (topo && !(topo === el || el.contains(topo) || topo.contains(el))) {
      return `há algo por cima do botão (<${topo.tagName.toLowerCase()}${topo.id ? '#' + topo.id : ''}>)`;
    }
    return null;
  }

  // Refaz a busca a cada ciclo: o elemento pode surgir, sumir ou ser trocado enquanto a tela carrega.
  async function esperar(buscar, descricao, timeout = TIMEOUT_ELEMENTO_MS) {
    const inicio = Date.now();
    for (;;) {
      conferirCancelado();
      const achado = await buscar();
      if (achado) return achado;
      if (Date.now() - inicio >= timeout) {
        const e = new Error(`não encontrei ${descricao} em ${Math.round(timeout / 1000)} s`);
        e.tempoEsgotado = true;
        throw e;
      }
      await sleep(150);
    }
  }

  // ------------------------------- avisos na tela -------------------------------
  function mostrarAviso(texto, tipo = 'info') {
    let box = document.getElementById(ID_AVISO);
    if (!box) {
      box = document.createElement('div');
      box.id = ID_AVISO;
      document.documentElement.appendChild(box);
    }
    const cor = { info: '#1f4e79', ok: '#1e7b3a', erro: '#b03a2e' }[tipo] || '#1f4e79';
    box.style.cssText =
      // canto inferior esquerdo (a pedido do usuário: no topo direito atrapalhava)
      'position:fixed!important;left:10px!important;bottom:10px!important;top:auto!important;right:auto!important;' +
      'max-width:360px!important;' +
      'z-index:2147483646!important;padding:10px 14px!important;border-radius:6px!important;' +
      `background:${cor}!important;color:#fff!important;font:13px/1.4 Arial,sans-serif!important;` +
      'box-shadow:0 2px 10px rgba(0,0,0,.3)!important;pointer-events:none!important;' +
      'word-break:break-word!important;white-space:pre-line!important;';
    box.textContent = `Automação_PGFN\n${texto}`;
    (tipo === 'erro' ? console.error : console.log)(PREFIXO, texto);
    try { registrarProgresso(texto); } catch (_) { /* aviso antes de a página terminar de carregar o script */ }
  }

  // ---- progresso e checkpoint para o vigia de travamentos do orquestrador (0.33.0) ----
  // Cada vez que o aviso da tela MUDA (a automação fez algo), o orquestrador fica sabendo (no máximo a cada 15 s), com o
  // ponto exato: certificado, CNPJ, etapa, conta, parcela e quantos PDFs já foram salvos. Sem mudança por muito tempo (e
  // sem pausa para você) = travamento. Não muda nada no fluxo: só informa.
  const progresso = { enviado: '', pendente: '', t: 0, timer: null };
  function checkpointAtual() {
    const c = { certificado: ORQ.certificado, cnpj: ORQ.cnpj };
    try {
      if (estado) {
        c.etapa = ETAPAS[estado.etapa] ? ETAPAS[estado.etapa].nome : String(estado.etapa);
        c.conta = estado.contaAtual || null;
        const a = estado.analises && estado.contaAtual && estado.analises[estado.contaAtual];
        c.parcela = a && a.baixando ? a.baixando.prest : null;
        c.fase = a && a.baixando ? a.baixando.fase : null;
        c.salvos = Object.keys(estado.baixados || {}).length;
      }
    } catch (_) { /* início da página: ainda sem etapas */ }
    return c;
  }
  function registrarProgresso(texto) {
    if (EM_QUADRO || !ORQ) return;
    progresso.pendente = String(texto || '').split('\n')[0].slice(0, 300);
    if (progresso.pendente === progresso.enviado || progresso.timer) return;
    progresso.timer = setTimeout(() => {
      progresso.timer = null;
      if (!ORQ || progresso.pendente === progresso.enviado) return;
      progresso.enviado = progresso.pendente;
      progresso.t = Date.now();
      mensagem({ tipo: 'orq-progresso', sessao: ORQ.sessao, cnpj: ORQ.cnpj, texto: progresso.enviado, checkpoint: checkpointAtual() });
    }, Math.max(0, 15000 - (Date.now() - progresso.t)));
  }

  // ------------------------------- seta do mouse -------------------------------
  const cursor = { el: null, x: 0, y: 0, hover: null };
  const PONTA = { x: 3, y: 2 }; // posição da ponta da seta dentro do desenho

  function criarSeta(posicao) {
    if (cursor.el) cursor.el.remove();
    const el = document.createElement('div');
    el.id = ID_SETA;
    el.style.cssText =
      'position:fixed!important;left:0!important;top:0!important;width:24px!important;height:28px!important;' +
      'z-index:2147483647!important;pointer-events:none!important;margin:0!important;padding:0!important;' +
      'transition:opacity .25s!important;opacity:0;will-change:transform;';
    el.innerHTML =
      '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="28" viewBox="0 0 24 28" style="display:block;overflow:visible">' +
      '<path d="M3 2 L3 20 L7.6 15.8 L10.8 22.8 L13.6 21.6 L10.5 14.8 L16.8 14.4 Z" ' +
      'fill="#111" stroke="#fff" stroke-width="1.4" stroke-linejoin="round"/></svg>';
    document.documentElement.appendChild(el);
    cursor.el = el;
    // depois de uma mudança de página, a seta continua de onde estava em vez de saltar
    cursor.x = posicao ? clamp(posicao.x, 0, innerWidth - 1) : rand(innerWidth * 0.35, innerWidth * 0.65);
    cursor.y = posicao ? clamp(posicao.y, 0, innerHeight - 1) : rand(innerHeight * 0.45, innerHeight * 0.75);
    posicionar();
    requestAnimationFrame(() => { el.style.opacity = '1'; });
  }

  function posicionar() {
    cursor.el.style.transform = `translate(${cursor.x - PONTA.x}px, ${cursor.y - PONTA.y}px)`;
  }

  function pulso() {
    const anel = document.createElement('div');
    anel.style.cssText =
      `position:fixed!important;left:${cursor.x - 14}px!important;top:${cursor.y - 14}px!important;` +
      'width:28px!important;height:28px!important;border-radius:50%!important;' +
      'border:2px solid rgba(31,78,121,.8)!important;z-index:2147483647!important;pointer-events:none!important;';
    document.documentElement.appendChild(anel);
    anel.animate(
      [{ transform: 'scale(.3)', opacity: 1 }, { transform: 'scale(1.5)', opacity: 0 }],
      { duration: 450, easing: 'ease-out' }
    ).onfinish = () => anel.remove();
  }

  // Posição do documento (iframe) dentro da janela principal.
  function deslocamento(doc) {
    let x = 0, y = 0;
    for (let w = doc.defaultView; w && w.frameElement; w = w.parent) {
      const f = w.frameElement;
      const r = f.getBoundingClientRect();
      x += r.left + f.clientLeft;
      y += r.top + f.clientTop;
    }
    return { x, y };
  }

  function retanguloNaJanela(el) {
    const r = el.getBoundingClientRect();
    const o = deslocamento(el.ownerDocument);
    return { left: r.left + o.x, top: r.top + o.y, right: r.right + o.x, bottom: r.bottom + o.y, width: r.width, height: r.height };
  }

  function disparar(el, tipo, extra = {}) {
    if (!el) return;
    const ponteiro = tipo.startsWith('pointer');
    const Ctor = ponteiro && typeof PointerEvent === 'function' ? PointerEvent : MouseEvent;
    const semBolha = tipo === 'mouseenter' || tipo === 'mouseleave' || tipo === 'pointerenter' || tipo === 'pointerleave';
    const o = deslocamento(el.ownerDocument);
    el.dispatchEvent(new Ctor(tipo, {
      bubbles: !semBolha, cancelable: true, composed: true, view: window,
      clientX: cursor.x - o.x, clientY: cursor.y - o.y, screenX: cursor.x, screenY: cursor.y,
      button: 0, buttons: tipo === 'mousedown' || tipo === 'pointerdown' ? 1 : 0,
      pointerId: 1, pointerType: 'mouse', isPrimary: true, ...extra,
    }));
  }

  function sobCursor() {
    let x = cursor.x, y = cursor.y;
    let el = document.elementFromPoint(x, y);
    while (el && /^i?frame$/i.test(el.tagName)) {
      let d = null;
      try { d = el.contentDocument; } catch (_) { /* outro domínio */ }
      if (!d) break;
      const r = el.getBoundingClientRect();
      x -= r.left + el.clientLeft;
      y -= r.top + el.clientTop;
      const dentro = d.elementFromPoint(x, y);
      if (!dentro) break;
      el = dentro;
    }
    return el;
  }

  // Como o navegador faz com o mouse de verdade: "saiu" e "entrou" dizem de onde e para onde (relatedTarget), e
  // mouseleave/mouseenter vão para cada ancestral que realmente ficou para trás ou foi alcançado. Sem isso, um menu de
  // "hover" acha que a seta saiu dele ao descer do título para a opção, e fecha.
  function cadeiaAte(el) {
    const lista = [];
    for (let e = el; e && e.nodeType === 1; e = e.parentElement) lista.push(e);
    return lista; // do elemento até o <html>
  }

  function atualizarHover() {
    const novo = sobCursor();
    const velho = cursor.hover && cursor.hover.isConnected ? cursor.hover : null;
    if (novo !== cursor.hover) {
      const mesmoDoc = velho && novo && velho.ownerDocument === novo.ownerDocument;
      const daVelha = velho ? cadeiaAte(velho) : [];
      const daNova = novo ? cadeiaAte(novo) : [];
      if (velho) {
        const rel = { relatedTarget: mesmoDoc ? novo : null };
        disparar(velho, 'pointerout', rel); disparar(velho, 'mouseout', rel);
        // sai só dos que não contêm o elemento novo
        daVelha.filter((e) => !(mesmoDoc && e.contains(novo))).forEach((e) => {
          disparar(e, 'pointerleave', rel); disparar(e, 'mouseleave', rel);
        });
      }
      if (novo) {
        const rel = { relatedTarget: mesmoDoc ? velho : null };
        disparar(novo, 'pointerover', rel); disparar(novo, 'mouseover', rel);
        // entra só nos que não continham o elemento antigo (de fora para dentro)
        daNova.filter((e) => !(mesmoDoc && e.contains(velho))).reverse().forEach((e) => {
          disparar(e, 'pointerenter', rel); disparar(e, 'mouseenter', rel);
        });
      }
      cursor.hover = novo;
    }
    if (novo) { disparar(novo, 'pointermove'); disparar(novo, 'mousemove'); }
  }

  // ---- movimento variado: cada deslocamento sorteia forma, ritmo e tremor, para nunca repetir o mesmo trajeto ----
  // Ritmo "da pessoa" nesta página: um pouco mais rápido ou mais lento a cada carregamento.
  const RITMO = rand(0.85, 1.2);
  const escolher = (lista) => lista[Math.floor(Math.random() * lista.length)];
  // Curvas de aceleração: todas começam devagar, aceleram e freiam, cada uma de um jeito.
  const ACELERACOES = [
    (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2),       // cúbica
    (t) => -(Math.cos(Math.PI * t) - 1) / 2,                                   // senoidal (mais macia)
    (t) => (t < 0.5 ? 16 * t ** 5 : 1 - Math.pow(-2 * t + 2, 5) / 2),          // quíntica (arranque e freada fortes)
    (t) => { const k = t < 0.4 ? t / 0.4 : 1; return t < 0.4 ? 0.55 * k * k : 0.55 + 0.45 * (1 - Math.pow(1 - (t - 0.4) / 0.6, 3)); }, // arranque rápido, chegada lenta
  ];

  // Um trecho do movimento: curva de Bézier com arco, aceleração e tremor sorteados.
  async function trecho(destX, destY, duracao, curvatura = 1) {
    const x0 = cursor.x, y0 = cursor.y;
    const dx = destX - x0, dy = destY - y0;
    const dist = Math.hypot(dx, dy) || 1;
    const nx = -dy / dist, ny = dx / dist;
    const lado = Math.random() < 0.5 ? -1 : 1; // arco para um lado ou para o outro
    const arco = lado * rand(0.03, 0.28) * dist * curvatura;
    const c1 = { x: x0 + dx * rand(0.15, 0.4) + nx * arco * rand(0.5, 1.4), y: y0 + dy * rand(0.15, 0.4) + ny * arco * rand(0.5, 1.4) };
    const c2 = { x: x0 + dx * rand(0.6, 0.9) + nx * arco * rand(0.05, 1), y: y0 + dy * rand(0.6, 0.9) + ny * arco * rand(0.05, 1) };
    const acelerar = escolher(ACELERACOES);
    const fase = rand(0, 6.28), fx = rand(25, 55), fy = rand(25, 55), forca = rand(0.3, 1.6);
    const inicio = performance.now();
    for (;;) {
      conferirCancelado();
      const t = clamp((performance.now() - inicio) / duracao, 0, 1);
      const e = acelerar(t);
      const u = 1 - e;
      const bx = u * u * u * x0 + 3 * u * u * e * c1.x + 3 * u * e * e * c2.x + e * e * e * destX;
      const by = u * u * u * y0 + 3 * u * u * e * c1.y + 3 * u * e * e * c2.y + e * e * e * destY;
      const tremor = (1 - t) * forca;
      cursor.x = bx + Math.sin(t * fx + fase) * tremor;
      cursor.y = by + Math.cos(t * fy + fase) * tremor;
      posicionar();
      atualizarHover();
      if (t >= 1) break;
      await quadro();
    }
    cursor.x = destX; cursor.y = destY;
    posicionar();
    atualizarHover();
  }

  // Sorteia o jeito de chegar ao alvo: direto, passando do ponto e voltando, desviando por um ponto no caminho,
  // ou freando perto do alvo com uma pequena hesitação. Termina às vezes com um micro ajuste.
  async function moverPara(x, y) {
    const dist = Math.hypot(x - cursor.x, y - cursor.y);
    if (dist < 3) return;
    const ritmo = RITMO * rand(0.8, 1.25) * LENTIDAO_MOUSE;
    const duracao = clamp((800 + dist * rand(1.1, 2.1) + rand(0, 400)) * ritmo, 900 * ritmo, 4200 * ritmo);
    const ux = (x - cursor.x) / dist, uy = (y - cursor.y) / dist;
    const formas = dist > 200 ? ['direto', 'passa', 'passa', 'desvio', 'freia'] : ['direto', 'direto', 'freia', 'passa'];
    const forma = escolher(formas);
    if (forma === 'passa') {
      // passa um pouco do alvo e corrige, como a mão faz
      const excesso = rand(5, 24);
      await trecho(x + ux * excesso + rand(-4, 4), y + uy * excesso + rand(-4, 4), duracao);
      await sleep(rand(60, 240));
      await trecho(x, y, rand(250, 560) * ritmo, rand(0.1, 0.5));
    } else if (forma === 'desvio') {
      // vai a um ponto fora da linha reta e de lá segue para o alvo
      const meio = rand(0.35, 0.65), afasta = (Math.random() < 0.5 ? -1 : 1) * rand(0.08, 0.22) * dist;
      const px = cursor.x + (x - cursor.x) * meio - uy * afasta, py = cursor.y + (y - cursor.y) * meio + ux * afasta;
      await trecho(px, py, duracao * rand(0.45, 0.6), rand(0.3, 0.8));
      if (Math.random() < 0.5) await sleep(rand(40, 180));
      await trecho(x, y, duracao * rand(0.45, 0.6), rand(0.3, 0.9));
    } else if (forma === 'freia') {
      // chega quase lá, hesita, e termina devagar
      const falta = rand(12, 40);
      await trecho(x - ux * falta + rand(-5, 5), y - uy * falta + rand(-5, 5), duracao * rand(0.7, 0.85));
      await sleep(rand(120, 380));
      await trecho(x, y, rand(300, 650) * ritmo, rand(0.1, 0.4));
    } else {
      await trecho(x, y, duracao, rand(0.4, 1.3));
    }
    if (Math.random() < 0.3) {
      // micro ajuste de 1 a 3 px, como quem confere a mira
      const ax = cursor.x, ay = cursor.y;
      await trecho(ax + rand(-3, 3), ay + rand(-3, 3), rand(80, 180), 0.2);
      await trecho(ax, ay, rand(80, 160), 0.2);
    }
    if (estado) { estado.cursor = { x: cursor.x, y: cursor.y }; gravarEstado(); }
    await sleep(rand(250, 900) * RITMO); // pausa antes de agir
  }

  async function moverAte(el) {
    const r = retanguloNaJanela(el);
    await moverPara(r.left + r.width * rand(0.3, 0.7), r.top + r.height * rand(0.3, 0.7));
  }

  async function clicarEm(el, descricao, antesDoClique) {
    const r = retanguloNaJanela(el);
    if (r.top < 40 || r.bottom > innerHeight - 40 || r.left < 0 || r.right > innerWidth) {
      el.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'nearest' });
      await sleep(700);
    }
    log(`movendo a seta até: ${descricao}`);
    await moverAte(el);
    let alvo = sobCursor();
    if (!alvo || !(alvo === el || el.contains(alvo) || alvo.contains(el))) {
      log(`outro elemento está sobre ${descricao}; clicando no próprio elemento`);
      alvo = el;
    }
    if (antesDoClique) await antesDoClique();
    log(`clicando em: ${descricao}`);
    pulso();
    disparar(alvo, 'pointerdown'); disparar(alvo, 'mousedown');
    if (/^(INPUT|TEXTAREA)$/.test(el.tagName)) el.focus();
    await sleep(rand(90, 190));
    disparar(alvo, 'pointerup'); disparar(alvo, 'mouseup');
    disparar(alvo, 'click', { detail: 1 });
  }

  // ------------------------------- digitação -------------------------------
  // Devolve false se a página cancelou o evento (preventDefault).
  function tecla(campo, tipo, t, extra = {}) {
    return campo.dispatchEvent(new KeyboardEvent(tipo, {
      key: t.key, code: t.code, keyCode: t.keyCode, which: t.keyCode,
      charCode: tipo === 'keypress' ? t.keyCode : 0,
      bubbles: true, cancelable: true, composed: true, view: window, ...extra,
    }));
  }

  async function digitar(campo, texto) {
    campo.focus();
    if (campo.value) {
      // apaga o que já houver, como quem seleciona tudo e aperta Backspace
      campo.select();
      const apagar = { key: 'Backspace', code: 'Backspace', keyCode: 8 };
      if (tecla(campo, 'keydown', apagar)) campo.ownerDocument.execCommand('delete');
      tecla(campo, 'keyup', apagar);
      await sleep(rand(250, 450));
    }
    for (const ch of texto) {
      const t = { key: ch, code: `Digit${ch}`, keyCode: ch.charCodeAt(0) };
      let tratada = !tecla(campo, 'keydown', t);
      if (!tratada) tratada = !tecla(campo, 'keypress', t);
      // se a máscara cancelou a tecla, ela mesma insere o caractere
      if (!tratada) campo.ownerDocument.execCommand('insertText', false, ch);
      tecla(campo, 'keyup', t);
      // ritmo de quem digita, com uma hesitação curta de vez em quando
      await sleep((rand(45, 130) + (Math.random() < 0.12 ? rand(90, 220) : 0)) * LENTIDAO_DIGITACAO);
    }
    await sleep(150);
  }

  // Plano B, só se a digitação não deixar o valor certo no campo. O evento paste deixa a máscara formatar; quem não
  // trata o paste recebe o texto pelos caminhos seguintes (um paste sintético não insere nada sozinho).
  async function colar(campo, texto) {
    const confere = () => soDigitos(campo.value) === texto;
    campo.focus();
    campo.select();
    const ctrl = { key: 'Control', code: 'ControlLeft', keyCode: 17 };
    const v = { key: 'v', code: 'KeyV', keyCode: 86 };
    tecla(campo, 'keydown', ctrl, { ctrlKey: true });
    await sleep(rand(60, 140));
    tecla(campo, 'keydown', v, { ctrlKey: true });
    const dados = new DataTransfer();
    dados.setData('text/plain', texto);
    const evento = new ClipboardEvent('paste', { clipboardData: dados, bubbles: true, cancelable: true, composed: true });
    campo.dispatchEvent(evento);
    log('evento paste disparado' + (evento.defaultPrevented ? ' (tratado pela página)' : ''));
    await sleep(rand(50, 120));
    tecla(campo, 'keyup', v, { ctrlKey: true });
    tecla(campo, 'keyup', ctrl);
    await sleep(250);
    if (confere()) return 'evento paste';

    campo.focus();
    campo.select();
    campo.ownerDocument.execCommand('insertText', false, texto);
    await sleep(250);
    if (confere()) return 'paste + insertText';

    const proto = campo.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, 'value').set.call(campo, texto);
    campo.dispatchEvent(new Event('input', { bubbles: true }));
    campo.dispatchEvent(new Event('change', { bubbles: true }));
    await sleep(250);
    return 'valor direto + input/change';
  }

  // ------------------------------- etapas -------------------------------
  // Para acrescentar um passo depois: escreva a função e inclua-a em ETAPAS, na ordem.
  // Aviso "Atenção! Prepare-se para a evolução dos serviços digitais da RFB": clica em "Continuar no e-CAC por
  // enquanto" (nunca em "Acessar o portal..."). `esperaMs`: quanto tempo dá para o aviso aparecer depois do carregamento.
  const acharContinuarEcac = () => {
    const el = acharBlocoMenu(TEXTO_CONTINUAR_ECAC) || acharTexto(TEXTO_CONTINUAR_ECAC);
    return el ? (el.closest('button, a, input, [role="button"]') || el) : null;
  };
  async function fecharAvisoEcac(esperaMs = 0) {
    const limite = Date.now() + esperaMs;
    let botao = acharContinuarEcac();
    let caixaPostal = acharIrCaixaPostal();
    while (!botao && !caixaPostal && Date.now() < limite) { await sleep(250); botao = acharContinuarEcac(); caixaPostal = acharIrCaixaPostal(); }
    if (caixaPostal) {
      await tratarAvisoCaixaPostal(); // 0.39.0: print do aviso e encerra o CNPJ (lança erro), ou pausa se não for dele
      botao = acharContinuarEcac();
    }
    if (!botao) return;
    mostrarAviso(`aviso do e-CAC na tela; clicando em "${TEXTO_CONTINUAR_ECAC}"…`);
    await sleep(rand(1200, 2000)); // "lê" o aviso
    await clicarEm(botao, `botão "${TEXTO_CONTINUAR_ECAC}"`);
    try {
      await esperar(() => !acharContinuarEcac(), 'o aviso do e-CAC fechar', TIMEOUT_JANELA_MS);
    } catch (e) {
      if (!e.tempoEsgotado) throw e;
      throw new Error(`cliquei em "${TEXTO_CONTINUAR_ECAC}" e o aviso do e-CAC não fechou`);
    }
    await sleep(rand(500, 900));
    const depois = acharIrCaixaPostal(); // o aviso da Caixa Postal pode vir logo depois deste
    if (depois) await tratarAvisoCaixaPostal();
  }

  // ------------------------------- aviso da Caixa Postal do e-CAC -------------------------------
  // "Atenção! Você possui mensagens importantes (com o indicativo "!") ainda não lidas na sua Caixa Postal...", com o
  // botão "Ir para a Caixa Postal". Até a 0.38.0 a automação clicava nele, salvava o print da Caixa Postal e voltava;
  // desde a 0.39.0 ela NÃO clica: salva o print do próprio aviso e encerra a análise do CNPJ (tratarAvisoCaixaPostal).
  // retomarCaixaPostal/salvarCaixaPostal ficam só para terminar uma visita deixada em andamento por uma versão antiga.
  // Nunca abre nenhuma mensagem: abrir pode valer como ciência de intimação.
  const acharIrCaixaPostal = () => {
    if (!acharTexto(TEXTO_AVISO_CAIXA_POSTAL)) return null;
    const el = acharBlocoMenu(TEXTO_IR_CAIXA_POSTAL);
    return el ? (el.closest('button, a, input, [role="button"]') || el) : null;
  };
  // de volta ao e-CAC normal: sem o aviso e com a tela inicial (ou o bloco da Dívida Ativa) visível
  const naPaginaInicialEcac = () => !acharIrCaixaPostal() && !!(acharTexto(TEXTO_TELA_INICIAL) || acharBlocoMenu(TEXTO_DIVIDA));

  // 0.39.0 — NOVA REGRA (substitui o clique em "Ir para a Caixa Postal"): com o aviso na tela, NÃO clica em nada.
  // 1) confirma que o cabeçalho é o CNPJ em processamento; 2) tira o print COM o aviso visível (printDoAviso, a mesma
  // rotina do Sem_Procuracao) em <certificado>/<CNPJ>/Caixa_Postal_<CNPJ>.pdf; 3) confere o PDF no disco (até
  // TENTATIVAS_PRINT_CAIXA_POSTAL vezes; uma nova tentativa não duplica: o print já no disco é reaproveitado); 4) encerra
  // a análise do CNPJ com a marca "[caixa_postal]" (situação final "caixa_postal" = "Aviso de Caixa Postal" no
  // orquestrador; contador próprio) e o orquestrador segue para o próximo CNPJ. Falha no salvamento = rotina existente
  // "[falha_salvamento]" (o CNPJ fica pendente, refeito na próxima execução, e a fila segue).
  // Aviso de OUTRO perfil (ex.: do titular do certificado, antes da troca) ou cabeçalho ilegível: não salva (a pasta
  // seria a errada) e PAUSA como antes, até você resolver e voltar à página inicial do e-CAC.
  const TENTATIVAS_PRINT_CAIXA_POSTAL = 3;
  async function tratarAvisoCaixaPostal() {
    const perfil = lerPerfilAtual();
    const noTopo = perfil && /^\d{14}$/.test(perfil.doc || '') ? perfil.doc : null;
    let cnpj = estado.cnpj || (ORQ && ORQ.cnpj) || null;
    if (!cnpj && !ORQ && noTopo && LISTA_CNPJS.includes(noTopo)) cnpj = noTopo; // modo manual, antes de escolher o CNPJ
    if (!cnpj || noTopo !== cnpj) {
      const motivo = !noTopo ? 'não consegui ler no cabeçalho de qual CNPJ ele é'
        : !cnpj ? `ele é de ${descreverPerfil(perfil)} e ainda não há CNPJ em processamento`
          : `ele é de ${descreverPerfil(perfil)}, não do CNPJ em processamento (${formatarCnpj(cnpj)})`;
      log(`aviso da Caixa Postal: ${motivo}; não salvei o print`);
      return esperarLeituraCaixaPostal(`apareceu o aviso de mensagens importantes da Caixa Postal, mas ${motivo}; não salvei ` +
        'o print para não errar a pasta. A automação não abre a Caixa Postal. Resolva e volte à página inicial do e-CAC');
    }
    const cert = (ORQ && ORQ.certificado) || '(certificado do login)';
    const texto = `Aviso de Caixa Postal no e-CAC para o CNPJ ${formatarCnpj(cnpj)} (certificado "${cert}"): mensagens importantes não lidas`;
    log(`aviso da Caixa Postal para ${cnpj}; salvando o print com o aviso na tela (sem abrir a Caixa Postal)`);
    mostrarAviso(`${texto}.\nSalvando o print do aviso…`, 'erro');
    await informarOrq('em_andamento', 'Aviso de Caixa Postal: salvando o print');
    const chaveReg = `caixa_postal|${cnpj}`;
    let caminho = await printJaSalvo(chaveReg), problema = null, tent = 0;
    if (caminho) log(`Caixa Postal de ${cnpj}: o print já estava salvo (${caminho}); não salvei de novo`);
    while (!caminho && tent < TENTATIVAS_PRINT_CAIXA_POSTAL) {
      tent++;
      const r = await printDoAviso(TEXTO_AVISO_CAIXA_POSTAL, `${pastaDocumentos()}/${cnpj}`, `Caixa_Postal_${cnpj}.pdf`, cnpj);
      if (!r.problema) { caminho = r.caminho; problema = null; break; }
      problema = r.problema;
      log(`Caixa Postal de ${cnpj}: tentativa ${tent} de ${TENTATIVAS_PRINT_CAIXA_POSTAL} do print: ${problema}`);
      if (tent < TENTATIVAS_PRINT_CAIXA_POSTAL) {
        mostrarAviso(`Caixa Postal: o print não foi confirmado (${problema}).\nTentando de novo (${tent + 1} de ${TENTATIVAS_PRINT_CAIXA_POSTAL})…`, 'erro');
        await sleep(rand(2500, 4000));
      }
    }
    if (!caminho) {
      throw Object.assign(new Error(`[falha_salvamento] Aviso de Caixa Postal (CNPJ ${formatarCnpj(cnpj)}): o print não foi ` +
        `salvo depois de ${tent} tentativa(s) (${problema}). O CNPJ fica pendente para a próxima execução`), { definitivo: true });
    }
    await mensagem({ tipo: 'registro-gravar', chave: chaveReg, arquivo: String(caminho).split('\n')[0] });
    log(`Caixa Postal de ${cnpj}: print salvo e conferido em ${caminho}; análise encerrada (Aviso de Caixa Postal)`);
    throw Object.assign(new Error(`[caixa_postal] Aviso de Caixa Postal: ${texto}. Análise deste CNPJ encerrada: leia as ` +
      'mensagens na Caixa Postal do e-CAC; este CNPJ não será tentado de novo até você pedir (interface: "Refazer sem procuração").\n' +
      `Print salvo em PDF:\n${caminho}`), { definitivo: true });
  }

  // Continua o que ficou da Caixa Postal numa página nova: o print (fase "ir"), a volta ao e-CAC (fase "voltar") ou a
  // espera pela leitura. Devolve a etapa de onde o CNPJ continua.
  async function retomarCaixaPostal() {
    const cp = estado.caixaPostalAtual;
    if (cp && cp.fase === 'ir') {
      await salvarCaixaPostal(cp);
      cp.fase = 'voltar';
      await gravarEstado();
      mostrarAviso(`Caixa Postal: print salvo.\n${estado.caixaPostal[cp.doc]}\nVoltando ao e-CAC para continuar este CNPJ…`, 'ok');
      await sleep(rand(1500, 2500));
      location.assign(cp.voltarPara);
      await new Promise(() => {}); // a página vai mudar: o script novo continua na fase "voltar"
    }
    if (cp) {
      delete estado.caixaPostalAtual;
      // mesma regra da retomada: antes de conferir o topo, a janela de troca de perfil é reaberta
      estado.etapa = cp.etapa < ETAPA_CONFERIR_TOPO ? Math.min(cp.etapa, estado.cnpj ? 1 : 0) : cp.etapa;
      await gravarEstado();
      await esperar(() => document.readyState === 'complete', 'o fim do carregamento da página', TIMEOUT_REGULARIZE_MS);
      const fim = Date.now() + 6000; // dá tempo ao aviso voltar
      while (Date.now() < fim && !acharIrCaixaPostal()) await sleep(250);
      if (acharIrCaixaPostal()) await esperarLeituraCaixaPostal(null, cp.doc);
    }
    if (estado.aguardandoCaixaPostal) await aguardarFimDaCaixaPostal();
    return estado.etapa;
  }

  async function salvarCaixaPostal(cp) {
    mostrarAviso('Caixa Postal: aguardando a página carregar…');
    await esperar(() => document.readyState === 'complete', 'o fim do carregamento da Caixa Postal', TIMEOUT_REGULARIZE_MS);
    await sleep(rand(3500, 5000)); // a lista de mensagens termina de chegar
    const perfil = lerPerfilAtual();
    if (perfil && perfil.doc && perfil.doc !== cp.doc) {
      throw new Error(`a Caixa Postal aberta é de ${descreverPerfil(perfil)}, mas o aviso era de ${formatarCnpj(cp.doc)}; não salvei o print`);
    }
    const chaveReg = `caixa_postal|${cp.doc}`;
    const ja = await mensagem({ tipo: 'registro-ver', chave: chaveReg });
    let caminho;
    if (ja && ja.arquivo) {
      caminho = ja.arquivo; // nunca substitui (nem duplica) um print já salvo
      log(`Caixa Postal de ${cp.doc} já tinha print salvo (${caminho}); não salvei de novo`);
    } else {
      mostrarAviso('Caixa Postal: salvando o print da página inteira…');
      caminho = await printPaginaInteiraAqui(`${pastaDocumentos()}/${cp.doc}`, `Caixa_Postal_${cp.doc}.pdf`);
      await mensagem({ tipo: 'registro-gravar', chave: chaveReg, arquivo: caminho });
      log(`Caixa Postal de ${cp.doc}: print salvo em ${caminho}`);
    }
    estado.caixaPostal = { ...(estado.caixaPostal || {}), [cp.doc]: caminho };
  }

  // O e-CAC continua com o aviso (mensagens importantes não lidas): PAUSA, sem prazo, até a página inicial voltar sem ele.
  async function esperarLeituraCaixaPostal(motivo, doc) {
    estado.aguardandoCaixaPostal = motivo || ('o e-CAC continua exigindo a leitura das mensagens importantes da Caixa Postal ' +
      `(${formatarCnpj(doc)}). O print já foi salvo. A automação não abre mensagens (abrir pode valer como ciência de ` +
      'intimação). Leia você mesmo e volte à página inicial do e-CAC: a automação continua sozinha este CNPJ');
    await gravarEstado();
    await aguardarFimDaCaixaPostal();
  }

  async function aguardarFimDaCaixaPostal() {
    const texto = estado.aguardandoCaixaPostal;
    mostrarAviso(`PAUSA: ${texto}`, 'erro');
    await informarOrq('aguardando_humano', texto);
    let ultimo = Date.now();
    await sleep(1500);
    while (!naPaginaInicialEcac()) {
      await sleep(1000);
      if (Date.now() - ultimo >= 60000) { // o orquestrador sabe que é espera por você (sem prazo)
        ultimo = Date.now();
        await informarOrq('aguardando_humano', texto);
        await gravarEstado();
      }
    }
    delete estado.aguardandoCaixaPostal;
    mostrarAviso('Caixa Postal resolvida; continuando a análise deste CNPJ…', 'ok');
    await informarOrq('em_andamento', 'Caixa Postal resolvida; continuando');
    await gravarEstado();
    await sleep(rand(1200, 2000));
  }

  // Print da página inteira AQUI (e-CAC), no mesmo formato do print de confirmação: partes de cima para baixo juntadas
  // num PDF. Conteúdo que rola por dentro (quadro do mesmo endereço ou caixa com barra de rolagem) é esticado durante o
  // print, para entrar inteiro; depois tudo volta como estava. Salvo com o nome pedido (nunca substitui: "uniquify").
  async function printPaginaInteiraAqui(pasta, nome) {
    const op = (o, extra = {}) => Promise.resolve(responderOp({ tipo: 'quadro-op', op: o, alvo: 'pagina', ...extra })).then((r) => r || null);
    const mexidos = []; // [elemento, estilo original]
    const soltar = (el, css) => { if (!mexidos.some(([e]) => e === el)) mexidos.push([el, el.style.cssText]); el.style.cssText += css; };
    const LIVRE = ';height:auto!important;max-height:none!important;overflow:visible!important;';
    for (const f of document.querySelectorAll('iframe')) {
      let d = null;
      try { d = f.contentDocument; } catch (_) { /* quadro de outro endereço: não dá para medir */ }
      if (!d || !d.documentElement || !visivel(f)) continue;
      const h = Math.max(d.documentElement.scrollHeight, d.body ? d.body.scrollHeight : 0);
      if (h <= f.clientHeight + 10) continue;
      soltar(f, `;height:${h + 20}px!important;max-height:none!important;`);
      for (let a = f.parentElement; a && a !== document.body; a = a.parentElement) {
        if (getComputedStyle(a).overflowY !== 'visible' || a.style.height) soltar(a, LIVRE);
      }
    }
    for (const el of document.querySelectorAll('body *')) {
      if (el.id === ID_AVISO || el.tagName === 'IFRAME' || el.clientHeight < innerHeight * 0.3) continue;
      if (/(auto|scroll)/.test(getComputedStyle(el).overflowY) && el.scrollHeight > el.clientHeight + 10) soltar(el, LIVRE);
    }
    for (const el of [document.documentElement, document.body]) {
      if (el && getComputedStyle(el).overflowY === 'hidden') soltar(el, ';overflow-y:auto!important;height:auto!important;');
    }
    const caixa = document.getElementById(ID_AVISO);
    let r;
    try {
      if (caixa) caixa.style.visibility = 'hidden';
      if (cursor.el) cursor.el.style.visibility = 'hidden';
      await sleep(900); // o navegador redesenha com o conteúdo esticado
      await op('rodape', { esconder: true });
      await op('irPara', { y: 0 });
      await mensagem({ tipo: 'print-inicio' });
      for (let parte = 0; parte < 60; parte++) {
        await sleep(650); // redesenho da tela (e o limite do Chrome: 2 prints por segundo)
        const p = await op('ler');
        const ok = await mensagem({ tipo: 'print-parte', y: p.topo, util: p.util, janela: p.janela });
        if (!ok || !ok.ok) throw new Error(`não consegui fotografar a tela: ${(ok && ok.erro) || 'sem resposta da extensão'}`);
        if (p.topo + p.util >= p.altura - 1) break;
        await op('irPara', { y: p.topo + p.util });
      }
      r = await mensagem({ tipo: 'print-salvar', pasta, nome });
    } finally {
      await op('rodape', { esconder: false });
      for (const [el, css] of mexidos.reverse()) el.style.cssText = css;
      await op('irPara', { y: 0 });
      if (caixa) caixa.style.visibility = '';
      if (cursor.el) cursor.el.style.visibility = '';
    }
    if (!r || !r.ok) throw new Error(`não consegui salvar o ${nome}: ${(r && r.erro) || 'sem resposta da extensão'}`);
    return r.caminho;
  }

  // Se a página mudar no meio, o script recomeça na página nova e retoma pela etapa gravada.
  async function analisarPagina() {
    mostrarAviso('analisando a página…');
    await esperar(() => document.readyState === 'complete', 'o fim do carregamento da página');
    await fecharAvisoEcac(ESPERA_AVISO_ECAC_MS);
    await esperar(() => acharCabecalho(TEXTO_TITULAR), 'o cabeçalho do e-CAC ("Titular" ou "Procurador de:")');
    // O cabeçalho é o que guia a automação: é ele que diz em qual CNPJ/empresa estamos agora.
    const perfil = lerPerfilAtual();
    const textoPerfil = descreverPerfil(perfil);
    if (!estado.cnpj) {
      estado.cnpj = escolherCnpj(perfil, estado.semProcuracao);
      // Nenhum outro para trocar, mas o perfil ativo é um da lista: usa ele mesmo, sem trocar.
      if (!estado.cnpj && perfil && LISTA_CNPJS.includes(perfil.doc) && !(estado.semProcuracao || []).includes(perfil.doc) &&
        !(estado.concluidos || []).includes(perfil.doc)) {
        estado.cnpj = perfil.doc;
      }
      if (!estado.cnpj) throw new Error('não sobrou nenhum CNPJ de teste para usar');
      if (!cnpjValido(estado.cnpj)) log(`atenção: o CNPJ ${estado.cnpj} não tem dígitos verificadores válidos`);
    }
    // O topo já mostra o CNPJ (já estava ativo, ou a troca terminou durante um F5 por trava): não troca de novo.
    estado.pularTroca = !!(perfil && perfil.doc === estado.cnpj);
    if (estado.pularTroca) {
      mostrarAviso(`Estamos em: ${textoPerfil}\nO perfil já é o CNPJ ${formatarCnpj(estado.cnpj)}: seguindo sem trocar.`);
      await sleep(rand(1200, 2000));
      return;
    }
    mostrarAviso(`Estamos em: ${textoPerfil}\nVou usar o CNPJ ${formatarCnpj(estado.cnpj)}`);
    await sleep(rand(1800, 2800)); // "lê" a tela antes de agir
  }

  async function abrirJanela() {
    if (estado.pularTroca) return;
    await fecharAvisoEcac();
    if (acharJanela() || acharRotuloCampo()) {
      log('a janela já está aberta; pulando o clique');
      return;
    }
    let motivo = null;
    for (let tent = 1; tent <= TENTATIVAS_ABRIR_JANELA; tent++) {
      mostrarAviso(tent === 1
        ? `procurando "${TEXTO_BOTAO}"…`
        : `a janela não abriu; tentando de novo (${tent} de ${TENTATIVAS_ABRIR_JANELA})…`);
      const botao = await esperar(acharBotaoPerfil, `o botão "${TEXTO_BOTAO}"`);
      motivo = motivoBotaoIndisponivel(botao);
      if (motivo) log(`botão com problema: ${motivo}`);
      await clicarEm(botao, `botão "${TEXTO_BOTAO}"`);
      if (tent === TENTATIVAS_ABRIR_JANELA && botao.isConnected && botao.click) {
        await sleep(rand(500, 900));
        botao.click(); // última tentativa: também o clique nativo
      }
      mostrarAviso('aguardando a janela abrir…');
      try {
        await esperar(() => acharJanela() || acharRotuloCampo(), 'a janela', TIMEOUT_JANELA_MS);
        return;
      } catch (e) {
        if (!e.tempoEsgotado) throw e;
      }
    }
    throw new Error(`cliquei ${TENTATIVAS_ABRIR_JANELA} vezes em "${TEXTO_BOTAO}" e a janela não abriu` +
      (motivo ? ` (${motivo})` : ''));
  }

  async function conferirJanela() {
    if (estado.pularTroca) return;
    mostrarAviso('conferindo a janela…');
    const titulo = await esperar(acharJanela, 'a janela "Alterar perfil de acesso" (frase de cima ou as opções)');
    log(`janela reconhecida por: "${(titulo.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 80)}"`);
    await sleep(rand(900, 1500)); // deixa a janela terminar de abrir
    await moverAte(titulo);
    const faltando = OPCOES_JANELA.filter((o) => !acharTexto(o));
    log(`opções da janela: ${OPCOES_JANELA.length - faltando.length} de ${OPCOES_JANELA.length}` +
      (faltando.length ? `; não achei: ${faltando.join(' | ')}` : ''));
  }

  const acharCampo = () => {
    const rotulo = acharRotuloCampo();
    return rotulo && acharCampoCnpj(rotulo);
  };

  async function digitarCnpj() {
    if (estado.pularTroca) return;
    mostrarAviso(`procurando o campo "${TEXTO_CAMPO}"…`);
    const campo = await esperar(acharCampo, `o campo "${TEXTO_CAMPO}"`);
    await clicarEm(campo, 'campo do CNPJ');
    await sleep(rand(250, 500));
    mostrarAviso(`digitando o CNPJ ${formatarCnpj(estado.cnpj)}…`);
    await digitar(campo, estado.cnpj);
    let metodo = 'digitação';
    if (soDigitos(campo.value) !== estado.cnpj) {
      log(`a digitação deixou "${campo.value}"; tentando colar`);
      metodo = await colar(campo, estado.cnpj);
    }
    if (soDigitos(campo.value) !== estado.cnpj) {
      throw new Error(`o campo ficou com "${campo.value}" em vez de ${formatarCnpj(estado.cnpj)}`);
    }
    log(`CNPJ preenchido via ${metodo}; valor no campo: "${campo.value}"`);
  }

  async function clicarAlterar() {
    if (estado.pularTroca) return;
    mostrarAviso('procurando o botão "Alterar" do CNPJ…');
    const campo = await esperar(acharCampo, `o campo "${TEXTO_CAMPO}"`);
    if (soDigitos(campo.value) !== estado.cnpj) {
      throw new Error(`o campo está com "${campo.value}" em vez de ${formatarCnpj(estado.cnpj)}; não cliquei em "Alterar"`);
    }
    const botao = await esperar(() => acharBotaoAlterarDoCampo(campo), 'o botão "Alterar" ao lado do campo do CNPJ');
    await sleep(rand(400, 900));
    mostrarAviso('clicando em "Alterar"…');
    // A página vai recarregar: grava ANTES do clique que, ao voltar, a etapa é conferir o topo.
    await clicarEm(botao, 'botão "Alterar" do CNPJ', async () => {
      estado.etapa = ETAPA_CONFERIR_TOPO;
      await gravarEstado();
    });
  }

  async function conferirTopo() {
    mostrarAviso(`aguardando a tela carregar para conferir o topo (esperado: ${formatarCnpj(estado.cnpj)})…`);
    let resultado;
    try {
      resultado = await esperar(() => {
        if (acharTexto(TEXTO_PROC_CANCELADA)) return 'procuração cancelada';
        if (acharTexto(TEXTO_SEM_PROCURACAO)) return 'sem procuração';
        if (document.readyState !== 'complete') return null;
        const perfil = lerPerfilAtual();
        return perfil && perfil.doc === estado.cnpj;
      }, 'o CNPJ novo no topo', TIMEOUT_TROCA_PERFIL_MS);
    } catch (e) {
      if (!e.tempoEsgotado) throw e;
      const feitas = estado.recargasPerfil || 0;
      if (feitas < LIMITE_RECARGAS_PERFIL) {
        // Travou (ex.: "Aguarde a validação dos dados…" sem fim): F5 e recomeça a troca, com o mesmo CNPJ.
        estado.recargasPerfil = feitas + 1;
        estado.etapa = 0;
        estado.pularTroca = false;
        mostrarAviso(`A troca de perfil travou por ${Math.round(TIMEOUT_TROCA_PERFIL_MS / 1000)} s.\n` +
          `Recarregando a página (F5) e tentando de novo (${estado.recargasPerfil} de ${LIMITE_RECARGAS_PERFIL})…`);
        log(`troca de perfil travada; recarregando (${estado.recargasPerfil} de ${LIMITE_RECARGAS_PERFIL})`);
        await gravarEstado();
        await sleep(1500);
        location.reload();
        await new Promise(() => {}); // a página vai recarregar: o script novo continua de onde parou
      }
      throw new Error(`o topo não mudou para ${formatarCnpj(estado.cnpj)} em ${Math.round(TIMEOUT_TROCA_PERFIL_MS / 1000)} s, ` +
        `mesmo depois de recarregar a página ${feitas} vez(es). No topo está: ${descreverPerfil(lerPerfilAtual())}. ` +
        'O e-CAC pode ter mostrado um aviso, ou o login atual não tem procuração deste CNPJ');
    }
    if (resultado === 'procuração cancelada') await tratarProcuracaoCancelada(estado.cnpj); // sempre lança erro
    if (resultado === 'sem procuração') {
      // O login atual não tem procuração deste CNPJ: anota e recomeça com o próximo da lista (F5 limpa a janela e o aviso).
      estado.semProcuracao = [...(estado.semProcuracao || []), estado.cnpj];
      const anterior = estado.cnpj;
      const proximo = escolherCnpj(lerPerfilAtual(), estado.semProcuracao);
      // 0.34.0: com o orquestrador (um CNPJ só), "sem procuração" é DEFINITIVO: print, janela fechada e o CNPJ fica
      // "sem_procuracao" (o orquestrador não tenta de novo nas próximas execuções). Antes virava "erro" e era refeito
      // a cada Iniciar (10/11: 3ª tentativa do 90000025000188), e o "Sair" era clicado com a janela aberta por cima.
      if (!proximo && ORQ) await tratarSemProcuracao(anterior);
      // 0.36.1: sem o orquestrador (lista de teste) também salva o print, com a mensagem ainda na tela (antes do F5)
      mostrarAviso(`O e-CAC disse: não existe procuração eletrônica para ${formatarCnpj(anterior)}.\nSalvando o print da mensagem…`, 'erro');
      const pr = await printSemProcuracao(anterior);
      log(`sem procuração para ${anterior}: ${pr.problema || `print salvo em ${pr.caminho}`}`);
      const sobrePrint = pr.problema ? `\nATENÇÃO: ${pr.problema}` : `\nPrint salvo em PDF:\n${pr.caminho}`;
      if (!proximo) {
        throw new Error(`não existe procuração eletrônica deste login para nenhum dos CNPJs de teste ` +
          `(${estado.semProcuracao.map(formatarCnpj).join(', ')})${sobrePrint}`);
      }
      mostrarAviso(`O e-CAC disse: não existe procuração eletrônica para ${formatarCnpj(anterior)}.${sobrePrint}\n` +
        `Recarregando a página e tentando o próximo CNPJ: ${formatarCnpj(proximo)}…`);
      log(`sem procuração para ${anterior}; próximo: ${proximo}`);
      estado.cnpj = proximo;
      estado.recargasPerfil = 0;
      estado.pularTroca = false;
      estado.etapa = 0;
      await gravarEstado();
      await sleep(rand(2500, 3500)); // tempo para ler o aviso
      location.reload();
      await new Promise(() => {}); // a página vai recarregar: o script novo continua com o próximo CNPJ
    }
    await sleep(rand(1000, 1800)); // "olha" o cabeçalho antes de concluir
    const perfilNovo = lerPerfilAtual();
    estado.confirmado = descreverPerfil(perfilNovo);
    estado.empresa = perfilNovo && perfilNovo.nome; // usado no nome dos arquivos salvos
    log(`perfil confirmado no topo: ${estado.confirmado}`);
  }

  // ---- sem procuração eletrônica (0.34.0) ----
  // Janela "Alterar perfil de acesso" aberta? Fecha pelo X dela (nunca por outro botão). true = fechou ou não havia.
  function acharJanelaPerfilAberta() {
    const ref = acharTexto(TEXTO_SEM_PROCURACAO) || acharTexto(TEXTO_PROC_CANCELADA) || acharJanela();
    return ref && visivel(ref) ? ref : null;
  }
  function acharXDaJanela(ref) {
    const ehX = (e) => visivel(e) && (
      e.matches('.ui-dialog-titlebar-close, [aria-label="Close" i], [aria-label="Fechar" i], [title="Fechar" i], [title="Close" i]') ||
      (/^[x×✕✖]$/i.test((e.textContent || e.value || e.alt || '').trim()) && e.getBoundingClientRect().width < 40));
    // sobe da frase da janela até o contêiner que tem um X (a primeira caixa que contém o título e o X)
    for (let a = ref.parentElement, n = 0; a && a !== a.ownerDocument.body && n < 12; a = a.parentElement, n++) {
      const x = [...a.querySelectorAll('a, button, span, div, input, img, [role="button"]')].find((e) => ehX(e) && !e.closest(`#${ID_AVISO}`));
      if (x) return x.closest('a, button, input, [role="button"]') || x;
    }
    // X só com imagem/ícone (sem texto nem título): o elemento clicável pequeno no canto de cima à direita da caixa
    for (let a = ref.parentElement, n = 0; a && a !== a.ownerDocument.body && n < 12; a = a.parentElement, n++) {
      const c = a.getBoundingClientRect();
      if (c.width < 300 || c.height < 150) continue;
      const canto = [...a.querySelectorAll('a, button, input[type="image"], input[type="button"], img, [role="button"], [onclick]')].find((e) => {
        const r = e.getBoundingClientRect();
        return visivel(e) && r.width > 4 && r.width <= 40 && r.height <= 40 && r.top - c.top < 60 && c.right - r.right < 60;
      });
      if (canto) return canto.closest('a, button, input, [role="button"]') || canto;
    }
    return null;
  }
  async function fecharJanelaPerfil() {
    for (let tent = 1; tent <= 2; tent++) {
      const ref = acharJanelaPerfilAberta();
      if (!ref) return true;
      const x = acharXDaJanela(ref);
      if (!x) { log('janela "Alterar perfil de acesso" aberta, mas não achei o X dela'); return false; }
      mostrarAviso('fechando a janela "Alterar perfil de acesso" pelo X…');
      if (!cursor.el) criarSeta(null);
      await clicarEm(x, 'X da janela "Alterar perfil de acesso"');
      try { await esperar(() => !acharJanelaPerfilAberta(), 'a janela fechar', 4000); return true; } catch (e) { if (!e.tempoEsgotado) throw e; }
    }
    return !acharJanelaPerfilAberta();
  }
  // 0.36.1: print Sem_Procuracao_<CNPJ>.pdf COM a mensagem na tela (antes de fechar a janela, sair ou ir ao próximo).
  // Confere que a frase está visível (rola até ela se estiver fora da tela) antes e depois da captura e que o PDF está no
  // disco. Sem a frase na tela não salva (um print sem a mensagem não serve de prova). Devolve { caminho, problema }.
  // 0.37.0: a mesma rotina serve ao aviso de procuração cancelada (printDoAviso com outra frase, pasta e nome).
  const printSemProcuracao = (cnpj) =>
    printDoAviso(TEXTO_SEM_PROCURACAO, `${pastaDocumentos()}/${cnpj}`, `Sem_Procuracao_${cnpj}.pdf`, cnpj);
  async function printDoAviso(fraseAviso, pasta, nome, cnpj) {
    let caminho = null, problema = null;
    try {
      await sleep(rand(800, 1400)); // deixa a janela terminar de desenhar
      const frase = acharTexto(fraseAviso);
      if (!frase) throw new Error(`a mensagem "${fraseAviso}" não estava mais na tela; não salvei o print`);
      const r = frase.getBoundingClientRect(), vh = frase.ownerDocument.defaultView.innerHeight;
      if (r.top < 0 || r.bottom > vh) { frase.scrollIntoView({ block: 'center' }); await sleep(500); }
      caminho = await salvarPrintEmPdf(pasta, nome);
      if (!acharTexto(fraseAviso)) log('aviso: a mensagem sumiu logo depois do print; confira o PDF');
      const arq = String(caminho).split('\n')[0];
      const disco = await mensagem({ tipo: 'conferir-arquivo', caminho: arq });
      if (!disco || !disco.ok) problema = `não consegui conferir o print no disco (${caminho})`;
      else if (!disco.existe || !disco.pdf || !disco.bytes) problema = `o print não ficou salvo corretamente (${caminho})`;
      else if (cnpj && !new RegExp(`[\\\\/]${cnpj}[\\\\/]`).test(arq)) problema = `o print foi salvo fora da pasta do CNPJ (${caminho})`;
    } catch (e) {
      if (e.cancelado) throw e;
      problema = `não consegui salvar o print: ${e.message}`;
    }
    return { caminho, problema };
  }

  // 0.37.0 — "A procuração eletrônica cadastrada para o detentor … foi cancelada em DD/MM/AAAA" na janela "Alterar perfil
  // de acesso". Não é lentidão nem falta de cadastro: classificação própria ("[procuracao_cancelada]", situação
  // "procuracao_cancelada" no orquestrador = pendente por procuração cancelada; não é tentado de novo sozinho).
  // Confere que o campo "Procurador de pessoa jurídica - CNPJ" tem o CNPJ da vez, tira o print com a mensagem, a data e o
  // CNPJ na tela (antes de fechar a janela) em <certificado>/<CNPJ>/Procuracao_Cancelada/Procuracao_Cancelada_<CNPJ>.pdf,
  // confere o arquivo, fecha a janela pelo X e encerra a tentativa (o "Sair com Segurança" vem no fim do CNPJ).
  async function tratarProcuracaoCancelada(cnpj) {
    const cert = (ORQ && ORQ.certificado) || '(certificado do login)';
    const frase = acharTexto(TEXTO_PROC_CANCELADA);
    const caixa = frase && (frase.closest('div, p, td, li, span') || frase);
    const textoAviso = ((caixa && (caixa.parentElement || caixa).textContent) || '').replace(/\s+/g, ' ').trim();
    const data = (/cancelada em\s*(\d{2}\/\d{2}\/\d{4})/i.exec(textoAviso) || [])[1] || '(data não lida)';
    const campo = acharCampo();
    const noCampo = soDigitos((campo && campo.value) || '');
    if (noCampo !== cnpj) {
      // o aviso não é, com certeza, do CNPJ da vez: não salva o print na pasta dele nem o classifica
      throw new Error(`o e-CAC avisou que uma procuração foi cancelada em ${data}, mas o campo "${TEXTO_CAMPO}" está com ` +
        `"${(campo && campo.value) || '(vazio)'}" em vez de ${formatarCnpj(cnpj)}; não salvei o print nem marquei o CNPJ`);
    }
    const texto = `Procuração eletrônica do certificado "${cert}" para o CNPJ ${formatarCnpj(cnpj)} cancelada em ${data}`;
    log(`procuração cancelada: CNPJ ${cnpj}, certificado ${cert}, cancelada em ${data}; aviso: "${textoAviso.slice(0, 200)}"`);
    mostrarAviso(`${texto}.\nSalvando o print da mensagem…`, 'erro');
    await informarOrq('em_andamento', 'procuração cancelada; salvando o print');
    const { caminho, problema } = await printDoAviso(TEXTO_PROC_CANCELADA,
      `${pastaDocumentos()}/${cnpj}/Procuracao_Cancelada`, `Procuracao_Cancelada_${cnpj}.pdf`, cnpj);
    log(`procuração cancelada, CNPJ ${cnpj}: ${problema || `print salvo em ${caminho}`}`);
    const fechou = await fecharJanelaPerfil();
    throw Object.assign(new Error(`[procuracao_cancelada] Pendente por procuração cancelada: ${texto}. ` +
      'Não concluído: renove a procuração eletrônica no e-CAC; este CNPJ não será tentado de novo até você pedir ' +
      '(interface: "Refazer sem procuração").\n' +
      (problema ? `ATENÇÃO: ${problema}` : `Print salvo em PDF:\n${caminho}`) +
      (fechou ? '' : '\n(não consegui fechar a janela "Alterar perfil de acesso")')), { definitivo: true });
  }

  // O e-CAC disse "Não existe procuração eletrônica…" para o CNPJ da vez (o do orquestrador). Não insiste (nem F5:
  // falta de autorização não se resolve recarregando): print Sem_Procuracao_<CNPJ>.pdf na pasta do CNPJ, fecha a janela
  // e encerra o CNPJ como "[sem_procuracao]" (o "Sair com Segurança" vem depois, no fim do CNPJ).
  async function tratarSemProcuracao(cnpj) {
    const cert = (ORQ && ORQ.certificado) || '(certificado do login)';
    const texto = `Não existe procuração eletrônica do certificado "${cert}" para o CNPJ ${formatarCnpj(cnpj)}`;
    mostrarAviso(`${texto}.\nSalvando o print da mensagem…`, 'erro');
    await informarOrq('em_andamento', 'sem procuração eletrônica; salvando o print');
    const { caminho, problema } = await printSemProcuracao(cnpj);
    log(`sem procuração, CNPJ ${cnpj}, certificado ${cert}: ${problema || `print salvo em ${caminho}`}`);
    const fechou = await fecharJanelaPerfil();
    throw new Error(`[sem_procuracao] ${texto}. Não concluído: falta a procuração eletrônica no e-CAC; ` +
      'este CNPJ não será tentado de novo até você pedir (interface: "Refazer sem procuração").\n' +
      (problema ? `ATENÇÃO: ${problema}` : `Print salvo em PDF:\n${caminho}`) +
      (fechou ? '' : '\n(não consegui fechar a janela "Alterar perfil de acesso")'));
  }

  async function abrirDividaAtiva() {
    await fecharAvisoEcac(ESPERA_AVISO_ECAC_MS); // depois da troca de perfil a página recarrega e o aviso pode voltar
    for (let tent = 1; tent <= TENTATIVAS_ABRIR_DIVIDA; tent++) {
      if (painelDividaAberto()) {
        log('o painel da Dívida Ativa já está aberto; pulando o clique');
        return;
      }
      mostrarAviso(tent === 1
        ? `procurando o bloco "${TEXTO_DIVIDA}"…`
        : `o painel não abriu; tentando de novo (${tent} de ${TENTATIVAS_ABRIR_DIVIDA})…`);
      const bloco = await esperar(() => acharBlocoMenu(TEXTO_DIVIDA), `o bloco "${TEXTO_DIVIDA}"`);
      await sleep(rand(600, 1200)); // "procura" o bloco na tela
      mostrarAviso(`clicando em "${TEXTO_DIVIDA}"…`);
      await clicarEm(bloco, `bloco "${TEXTO_DIVIDA}"`);
      mostrarAviso('aguardando as opções da Dívida Ativa aparecerem…');
      try {
        await esperar(painelDividaAberto, 'as opções da Dívida Ativa', TIMEOUT_JANELA_MS);
        return;
      } catch (e) {
        if (!e.tempoEsgotado) throw e;
      }
    }
    throw new Error(`cliquei ${TENTATIVAS_ABRIR_DIVIDA} vezes em "${TEXTO_DIVIDA}" e as opções não apareceram`);
  }

  // Endereço do link, quando é um endereço de verdade (não "#" nem "javascript:").
  function enderecoDoLink(el) {
    const a = el.closest('a') || el.querySelector('a');
    if (!a || !/^https?:/i.test(a.href)) return null;
    return a.href.split('#')[0] === location.href.split('#')[0] ? null : a.href;
  }

  // CNPJ sem acesso à PGFN: o painel da Dívida Ativa abre sem "PGFN - Todos os serviços do Regularize". Pula o CNPJ
  // (sem salvar nada) e recomeça com o próximo da lista; sem próximo, termina normalmente.
  async function pularCnpjSemRegularize() {
    estado.pulados = [...(estado.pulados || []), estado.cnpj];
    const anterior = estado.cnpj;
    const proximo = escolherCnpj(lerPerfilAtual(), [...(estado.semProcuracao || []), ...estado.pulados]);
    log(`CNPJ ${anterior} sem "${TEXTO_REGULARIZE}"; ${proximo ? `próximo: ${proximo}` : 'nenhum outro na lista'}`);
    if (!proximo) {
      estado.fim = `O CNPJ ${formatarCnpj(anterior)} não tem "${TEXTO_REGULARIZE}" (sem acesso à PGFN): pulei.\n` +
        'Não há outro CNPJ na lista. Fim.';
      estado.cnpjFinalizado = true;
      estado.etapa = ETAPAS.length; // encerra a execução normalmente (sem erro)
      return;
    }
    mostrarAviso(`O CNPJ ${formatarCnpj(anterior)} não tem "${TEXTO_REGULARIZE}": pulando.\n` +
      `Recarregando a página e seguindo com ${formatarCnpj(proximo)}…`);
    Object.assign(estado, { cnpj: proximo, etapa: 0, recargasPerfil: 0, pularTroca: false, confirmado: null, empresa: null });
    await gravarEstado();
    await sleep(rand(1500, 2500));
    location.reload();
    await new Promise(() => {}); // a página vai recarregar: o script novo continua com o próximo CNPJ
  }

  async function clicarRegularize() {
    mostrarAviso(`procurando "${TEXTO_REGULARIZE}"…`);
    let opcao;
    try {
      opcao = await esperar(() => acharBlocoMenu(TEXTO_REGULARIZE), `a opção "${TEXTO_REGULARIZE}"`, ESPERA_BLOCO_REGULARIZE_MS);
    } catch (e) {
      if (!e.tempoEsgotado) throw e;
      // painel aberto e carregado, mas sem a opção: este CNPJ não tem acesso à PGFN
      if (painelDividaAberto() && document.readyState === 'complete') { await pularCnpjSemRegularize(); return; }
      opcao = await esperar(() => acharBlocoMenu(TEXTO_REGULARIZE), `a opção "${TEXTO_REGULARIZE}"`);
    }
    await sleep(rand(600, 1200)); // "lê" o painel antes de escolher
    mostrarAviso(`clicando em "${TEXTO_REGULARIZE}"…`);
    aberturaCapturada = null;
    // Antes do clique: avisa o service worker que a próxima página do Regularize continua daqui.
    await clicarEm(opcao, `opção "${TEXTO_REGULARIZE}"`, async () => {
      estado.etapa = ETAPA_AGUARDAR_REGULARIZE;
      estado.linkRegularize = enderecoDoLink(opcao);
      await mensagem({ tipo: 'transferencia-iniciar', cnpj: estado.cnpj, confirmado: estado.confirmado, empresa: estado.empresa,
        concluidos: estado.concluidos || [] });
      await gravarEstado();
    });
  }

  async function aguardarRegularize() {
    mostrarAviso('aguardando a nova janela do Regularize…');
    const inicio = Date.now();
    let tentouAbrir = false;
    for (;;) {
      const t = await mensagem({ tipo: 'transferencia-status' });
      if (t && t.concluida) {
        estado.fim = `Perfil conferido no topo.\n${estado.confirmado}\nA automação continuou na janela do Regularize.`;
        return;
      }
      const bloqueada = aberturaCapturada && aberturaCapturada.bloqueada;
      if (!tentouAbrir && !(t && t.abriu) && (bloqueada || Date.now() - inicio >= ESPERA_ABRIR_JANELA_MS)) {
        // A janela não abriu: um clique simulado pode ser bloqueado como pop-up. Abre o mesmo endereço pela extensão.
        tentouAbrir = true;
        const url = (aberturaCapturada && aberturaCapturada.url) || estado.linkRegularize;
        if (!url) {
          throw new Error('a nova janela não abriu e não encontrei o endereço do link. O Chrome pode ter bloqueado o pop-up: ' +
            `permita pop-ups em ${location.hostname} (ícone à direita da barra de endereço)`);
        }
        log(`a janela não abriu; abrindo pela extensão: ${url}`);
        mostrarAviso('a janela não abriu sozinha; abrindo o mesmo endereço pela extensão…');
        if (!await mensagem({ tipo: 'abrir-url', url })) {
          throw new Error(`a nova janela não abriu e não pude abrir o endereço ${url}`);
        }
      }
      if (Date.now() - inicio >= TIMEOUT_NOVA_JANELA_MS) {
        throw new Error(`a automação não conseguiu continuar na janela nova em ${Math.round(TIMEOUT_NOVA_JANELA_MS / 1000)} s. ` +
          'Confira se abriu o Regularize, outra tela ou um pedido de login');
      }
      await sleep(500);
    }
  }

  // ------------------------------- janela do Regularize -------------------------------
  async function aguardarPaginaRegularize() {
    mostrarAviso('aguardando a página do Regularize carregar…');
    try {
      await esperar(() => document.readyState === 'complete' &&
        (acharBlocoMenu(TEXTO_CIENTE) || acharTexto(TEXTO_BLOCO_ACESSO) || naTelaDoSispar() || telaSemCadastro() ||
          OPCOES_REGULARIZE.some((o) => acharTexto(o))),
      'a página inicial do Regularize', TIMEOUT_REGULARIZE_MS);
    } catch (e) {
      if (!e.tempoEsgotado) throw e;
      throw new Error(`a página inicial do Regularize não apareceu em ${Math.round(TIMEOUT_REGULARIZE_MS / 1000)} s. ` +
        'Confira se ela abriu outra tela ou pediu login');
    }
    if (await tratarSemCadastro()) return;
    await sleep(rand(1000, 1800)); // "olha" a tela antes de agir
  }

  // Aviso "Atenção! Fique atento: você tem novas notificações na caixa de mensagens da PGFN!" (botões "VER AGORA" e
  // "FECHAR"). Só clica em "FECHAR" do próprio aviso, e só se ele estiver visível; nunca em "VER AGORA".
  function acharFecharNotificacoes() {
    const frase = acharTexto(TEXTO_AVISO_NOTIFICACOES);
    if (!frase) return null;
    for (let caixa = frase.parentElement, i = 0; caixa && i < 10; caixa = caixa.parentElement, i++) {
      const botao = [...caixa.querySelectorAll('button, a, input[type="button"], [role="button"]')]
        .find((b) => chave(b.tagName === 'INPUT' ? b.value : b.textContent) === chave(TEXTO_FECHAR_NOTIFICACOES) && visivel(b));
      if (botao) return botao;
    }
    return null;
  }
  // `esperaMs`: tempo dando chance ao aviso aparecer (ele surge um pouco depois do carregamento). Sem aviso, segue.
  async function fecharAvisoNotificacoes(esperaMs = 0) {
    await esperar(() => document.readyState === 'complete', 'o fim do carregamento da página');
    const limite = Date.now() + esperaMs;
    let botao = acharFecharNotificacoes();
    while (!botao && Date.now() < limite) { await sleep(250); botao = acharFecharNotificacoes(); }
    if (!botao) return false;
    for (let tent = 1; tent <= TENTATIVAS_CIENTE; tent++) {
      mostrarAviso(tent === 1 ? 'aviso de notificações da PGFN na tela; clicando em "FECHAR"…'
        : `o aviso de notificações não fechou; tentando de novo (${tent} de ${TENTATIVAS_CIENTE})…`);
      await sleep(rand(900, 1500)); // "lê" o aviso
      await clicarEm(botao, `botão "${TEXTO_FECHAR_NOTIFICACOES}" do aviso de notificações`);
      try {
        await esperar(() => !acharFecharNotificacoes(), 'o fechamento do aviso de notificações', TIMEOUT_JANELA_MS);
        await sleep(rand(500, 900));
        return true;
      } catch (e) {
        if (!e.tempoEsgotado) throw e;
      }
      botao = acharFecharNotificacoes();
      if (!botao) return true;
    }
    throw new Error(`cliquei ${TENTATIVAS_CIENTE} vezes em "${TEXTO_FECHAR_NOTIFICACOES}" e o aviso de notificações da PGFN não fechou`);
  }

  // O aviso "Atenção!" é opcional: se não aparecer no tempo, segue sem ele.
  async function confirmarCiente() {
    await confirmarCienteSemNotificacoes();
    // depois do "CIENTE" (ou sem ele), dá alguns segundos para o aviso de notificações aparecer
    await fecharAvisoNotificacoes(ESPERA_AVISO_NOTIFICACOES_MS);
  }

  async function confirmarCienteSemNotificacoes() {
    mostrarAviso('verificando se apareceu o aviso "Atenção!"…');
    let ciente = null;
    const inicio = Date.now();
    while (!ciente && Date.now() - inicio < ESPERA_AVISO_CIENTE_MS) {
      if (await fecharAvisoNotificacoes()) continue; // o de notificações pode vir antes, por cima do "CIENTE"
      ciente = acharBlocoMenu(TEXTO_CIENTE);
      if (!ciente) await sleep(200);
    }
    if (!ciente) {
      log('o aviso "Atenção!" não apareceu; seguindo');
      return;
    }
    await sleep(rand(800, 1400)); // deixa a janela de aviso terminar de abrir
    for (let tent = 1; tent <= TENTATIVAS_CIENTE; tent++) {
      const botao = acharBlocoMenu(TEXTO_CIENTE);
      if (!botao) break;
      mostrarAviso(tent === 1 ? 'clicando em "CIENTE"…' : `o aviso não fechou; tentando de novo (${tent} de ${TENTATIVAS_CIENTE})…`);
      await clicarEm(botao, 'botão "CIENTE"');
      try {
        await esperar(() => !acharBlocoMenu(TEXTO_CIENTE), 'o fechamento do aviso', TIMEOUT_JANELA_MS);
        return;
      } catch (e) {
        if (!e.tempoEsgotado) throw e;
      }
    }
    throw new Error(`cliquei ${TENTATIVAS_CIENTE} vezes em "CIENTE" e o aviso não fechou`);
  }

  // A tela é reconhecida pelo título OU pela estrutura: pelo menos 3 das opções dela visíveis.
  function noSistemaNegociacoes() {
    const titulo = acharTexto(TEXTO_BOAS_VINDAS) || acharTextoDividido(TEXTO_BOAS_VINDAS);
    if (titulo) return titulo;
    const opcoes = OPCOES_SISTEMA.map((o) => acharBlocoMenu(o)).filter(Boolean);
    return opcoes.length >= 3 ? opcoes[0] : null;
  }
  // Já na tela do SISPAR (o quadro dele ou o conteúdo direto na página): as etapas anteriores não têm o que fazer.
  const naTelaDoSispar = () => document.getElementById('sisparFrame') || noSistemaNegociacoes();
  const acharAvisoSispar = () => acharTexto(TEXTO_AVISO_SISPAR) ||
    (acharBlocoMenu('DESISTIR') && acharBlocoMenu('CONTINUAR'));

  // "Você ainda não está cadastrado no REGULARIZE. Para acessar os serviços, efetue seu cadastro.": este CNPJ não tem
  // cadastro. Não segue o fluxo (nem preenche o cadastro): tira o print, salva em PDF na pasta do CNPJ como
  // sem_cadastro_regularize.pdf e vai direto para a última etapa (próximo CNPJ). Devolve true quando tratou o caso.
  const telaSemCadastro = () => acharTexto(TEXTO_SEM_CADASTRO_REGULARIZE) || acharTextoDividido(TEXTO_SEM_CADASTRO_REGULARIZE);
  async function tratarSemCadastro() {
    if (estado.semCadastroRegularize || !telaSemCadastro()) return !!estado.semCadastroRegularize;
    mostrarAviso(`o Regularize diz que o CNPJ ${formatarCnpj(estado.cnpj || '')} não tem cadastro; salvando o print em PDF…`, 'erro');
    await esperar(() => document.readyState === 'complete', 'o fim do carregamento da página');
    await sleep(rand(1200, 2000)); // a tela assentar (mensagem e campos visíveis)
    window.scrollTo({ top: 0, behavior: 'instant' }); // a mensagem fica no alto da página
    await sleep(500);
    const caminho = await salvarPrintEmPdf(await pastaDoCliente(), 'sem_cadastro_regularize.pdf');
    estado.semCadastroRegularize = caminho;
    const perfil = estado.confirmado ? `Perfil no e-CAC: ${estado.confirmado}\n` : '';
    estado.fim = `${perfil}O CNPJ não tem cadastro no REGULARIZE ("${TEXTO_SEM_CADASTRO_REGULARIZE}").\n` +
      `Não segui com a emissão. Print salvo em PDF:\n${caminho}`;
    log(`sem cadastro no Regularize; print: ${caminho}`);
    estado.etapa = ETAPAS.length - 1; // pula as outras etapas: só falta seguir para o próximo CNPJ
    await gravarEstado();
    return true;
  }

  async function abrirNegociarDivida() {
    if (await tratarSemCadastro()) return;
    if (naTelaDoSispar()) return; // iniciada pelo ícone já na tela seguinte
    await fecharAvisoNotificacoes(); // aviso que ficou aberto não pode bloquear o clique
    for (let tent = 1; tent <= TENTATIVAS_NEGOCIAR; tent++) {
      if (acharTexto(TEXTO_BLOCO_ACESSO)) {
        log('a tela "Negociar Dívida" já está aberta; pulando o clique');
        await fecharAvisoNotificacoes(ESPERA_AVISO_NOTIFICACOES_MS);
        return;
      }
      mostrarAviso(tent === 1
        ? `analisando as opções e procurando "${TEXTO_NEGOCIAR}"…`
        : `a tela não abriu; tentando de novo (${tent} de ${TENTATIVAS_NEGOCIAR})…`);
      const opcao = await esperar(() => acharBlocoMenu(TEXTO_NEGOCIAR), `a opção "${TEXTO_NEGOCIAR}"`);
      await sleep(rand(1000, 1800)); // "lê" as opções antes de escolher
      mostrarAviso(`clicando em "${TEXTO_NEGOCIAR}"…`);
      await clicarEm(opcao, `opção "${TEXTO_NEGOCIAR}"`);
      mostrarAviso('aguardando a tela "Negociar Dívida" carregar…');
      try {
        await esperar(() => acharTexto(TEXTO_BLOCO_ACESSO), 'a tela', TIMEOUT_ELEMENTO_MS);
        // segunda página do Regularize: o aviso de notificações também pode aparecer aqui
        await fecharAvisoNotificacoes(ESPERA_AVISO_NOTIFICACOES_MS);
        return;
      } catch (e) {
        if (!e.tempoEsgotado) throw e;
      }
    }
    throw new Error(`cliquei ${TENTATIVAS_NEGOCIAR} vezes em "${TEXTO_NEGOCIAR}" e o bloco "${TEXTO_BLOCO_ACESSO}" não apareceu`);
  }

  async function clicarAcessar() {
    if (naTelaDoSispar()) return; // iniciada pelo ícone já na tela seguinte
    await fecharAvisoNotificacoes();
    mostrarAviso(`procurando o botão "${TEXTO_ACESSAR}" do bloco "${TEXTO_BLOCO_ACESSO}"…`);
    const botao = await esperar(acharBotaoAcessar, `o botão "${TEXTO_ACESSAR}" do bloco "${TEXTO_BLOCO_ACESSO}"`);
    await sleep(rand(1000, 1800)); // "lê" o bloco antes de clicar
    mostrarAviso(`clicando em "${TEXTO_ACESSAR}"…`);
    aberturaCapturada = null;
    await clicarEm(botao, `botão "${TEXTO_ACESSAR}"`, async () => {
      // A página pode recarregar: ao voltar, a etapa é só conferir o que aconteceu, sem clicar de novo.
      estado.etapa = ETAPA_REACAO_ACESSAR;
      estado.tAcessar = Date.now();
      const a = botao.closest('a');
      estado.linkAcessar = a && a.target === '_blank' ? enderecoDoLink(a) : null;
      await gravarEstado();
    });
  }

  // NUNCA reabrir aqui o endereço que a página tentou abrir: no Regularize/SISPAR ele leva uma chave (token) de uso
  // único. Abrir o mesmo endereço numa aba extra gasta a chave duas vezes e o site encerra a sessão ("Acesso Expirado!",
  // "Você não tem permissão de acesso ou ele expirou"). Foi o que aconteceu no teste de 05/11/2026.
  // Aqui só se espera a tela seguinte; se ela não vier e a página tiver tentado uma janela bloqueada, a mensagem diz isso.
  async function conferirReacaoAcessar() {
    await sleep(ESPERA_REACAO_ACESSAR_MS);
    if (aberturaCapturada && aberturaCapturada.bloqueada) estado.popupBloqueado = aberturaCapturada.url;
  }

  // ------------------------------- quadro do SISPAR -------------------------------
  // A tela do SISPAR fica num <iframe id="sisparFrame"> de outro endereço: a página de fora não enxerga o conteúdo.
  // Quem age lá dentro é o "agente" (este mesmo script, rodando no quadro). A seta continua desenhada na página de
  // fora, e as coordenadas são convertidas com a posição do iframe.
  // Na aba própria do SISPAR não há quadro: o "agente" responde aqui mesmo, sem mensagens.
  const pedirAoQuadro = (op, alvo, extra = {}) => (NO_SISPARNET
    ? Promise.resolve(responderOp({ tipo: 'quadro-op', op, alvo, ...extra })).then((r) => r || null)
    : mensagem({ tipo: 'ao-quadro', dados: { tipo: 'quadro-op', op, alvo, ...extra } }));
  const acharIframeSispar = () => document.getElementById('sisparFrame');

  function hostDoIframe() {
    if (NO_SISPARNET) return location.hostname;
    const f = acharIframeSispar();
    if (!f) return 'nenhum quadro do SISPAR na página';
    try { return new URL(f.src).hostname || 'quadro sem endereço'; } catch (_) { return 'quadro sem endereço'; }
  }

  const avisoSisparPresente = async () => acharAvisoSispar() || await pedirAoQuadro('achar', 'aviso');

  // op 'clicar' clica; op 'passar' só passa a seta por cima (abre menus de "hover").
  // opcoes.descer: em vez do trajeto sorteado, desce em linha até a altura do alvo e só então vai para o lado
  // (submenu: quem desce do menu para a opção não sai de cima do menu, senão ele fecha).
  async function clicarNoQuadro(alvo, descricao, op = 'clicar', opcoes = {}) {
    // Posição do conteúdo na janela: a do quadro, ou zero na aba própria do SISPAR.
    const f = NO_SISPARNET ? null : acharIframeSispar();
    const base = () => {
      if (!f) return { x: 0, y: 0 };
      const ref = f.getBoundingClientRect();
      return { x: ref.left + f.clientLeft, y: ref.top + f.clientTop };
    };
    const extra = opcoes.extra || {}; // ex.: { conta } para achar a linha certa
    let r = await esperar(() => pedirAoQuadro('achar', alvo, extra), descricao);
    const yNaJanela = base().y + r.top + r.height / 2;
    if (yNaJanela < 80 || yNaJanela > innerHeight - 80) {
      window.scrollBy({ top: yNaJanela - innerHeight / 2, behavior: 'smooth' });
      await sleep(700);
      r = await esperar(() => pedirAoQuadro('achar', alvo, extra), descricao);
    }
    const x = r.left + r.width * rand(0.3, 0.7);
    const y = r.top + r.height * rand(0.3, 0.7);
    log(`movendo a seta até: ${descricao}${f ? ' (dentro do quadro)' : ''}`);
    if (opcoes.descer) {
      const destX = base().x + x, destY = base().y + y;
      // fica dentro da largura da opção ao descer
      const coluna = clamp(cursor.x + rand(-3, 3), base().x + r.left + 6, base().x + r.left + r.width - 6);
      const ritmo = RITMO * rand(0.9, 1.15) * LENTIDAO_MOUSE;
      await trecho(coluna, destY + rand(-1.5, 1.5), clamp(Math.abs(destY - cursor.y) * rand(5, 8), 280, 900) * ritmo, 0.05);
      await sleep(rand(80, 220));
      await trecho(destX, destY, clamp(Math.abs(destX - cursor.x) * rand(3, 5), 180, 700) * ritmo, 0.08);
      if (estado) { estado.cursor = { x: cursor.x, y: cursor.y }; gravarEstado(); }
      await sleep(rand(250, 600) * RITMO);
    } else {
      await moverPara(base().x + x, base().y + y);
    }
    if (op === 'passar') {
      log(`passando a seta sobre: ${descricao}`);
      if (!await pedirAoQuadro('passar', alvo, { x, y })) log(`o quadro não respondeu à seta sobre ${descricao}`);
      return;
    }
    // Antes do clique que recarrega a página: grava de onde continuar, para a página nova não repetir o clique.
    if (opcoes.antesDoClique) await opcoes.antesDoClique();
    log(`clicando em: ${descricao}`);
    pulso();
    // Sem resposta não é erro: o quadro pode ter mudado de tela com o clique. Quem decide é a conferência seguinte.
    if (!await pedirAoQuadro('clicar', alvo, { x, y, ...extra })) log(`o quadro não respondeu ao clique em ${descricao}`);
  }

  async function abrirConsultar() {
    mostrarAviso('aguardando o Sistema de Negociações carregar…');
    let tela;
    try {
      tela = await esperar(async () => await pedirAoQuadro('achar', 'sistema') || await avisoSisparPresente() || noSistemaNegociacoes(),
        'o Sistema de Negociações', TIMEOUT_REGULARIZE_MS);
    } catch (e) {
      if (!e.tempoEsgotado) throw e;
      throw new Error(`o Sistema de Negociações não respondeu em ${Math.round(TIMEOUT_REGULARIZE_MS / 1000)} s. ` +
        `Endereço do quadro: ${hostDoIframe()}`);
    }
    if (tela.host) estado.hostSispar = tela.host;
    log(`Sistema de Negociações reconhecido ${tela.host ? `dentro do quadro de ${tela.host}` : 'na própria página'}`);
    const noQuadro = !!tela.host;

    for (let tent = 1; tent <= TENTATIVAS_CONSULTAR; tent++) {
      if (await avisoSisparPresente()) break;
      mostrarAviso(tent === 1
        ? `analisando as opções e procurando "${TEXTO_CONSULTAR}"…`
        : `o aviso não apareceu; tentando de novo (${tent} de ${TENTATIVAS_CONSULTAR})…`);
      await sleep(rand(1000, 1800)); // "lê" as opções antes de escolher
      mostrarAviso(`clicando em "${TEXTO_CONSULTAR}"…`);
      if (noQuadro) {
        await clicarNoQuadro('consultar', `opção "${TEXTO_CONSULTAR}"`);
      } else {
        const opcao = await esperar(() => acharBlocoMenu(TEXTO_CONSULTAR), `a opção "${TEXTO_CONSULTAR}"`);
        await clicarEm(opcao, `opção "${TEXTO_CONSULTAR}"`);
      }
      mostrarAviso('aguardando o aviso do SISPAR aparecer…');
      try {
        await esperar(avisoSisparPresente, 'o aviso', TIMEOUT_JANELA_MS);
      } catch (e) {
        if (!e.tempoEsgotado) throw e;
      }
    }
    if (!await avisoSisparPresente()) {
      throw new Error(`cliquei ${TENTATIVAS_CONSULTAR} vezes em "${TEXTO_CONSULTAR}" e o aviso "${TEXTO_AVISO_SISPAR}" não apareceu`);
    }
  }

  // Depois de "CONTINUAR": a tela da PGFN abre no próprio quadro (é o que acontece no site). A extensão NÃO abre o
  // endereço em outra aba, nem se a página tentar uma janela que o Chrome bloqueou: o endereço tem uma chave de uso
  // único e abri-lo de novo derruba a sessão (ver conferirReacaoAcessar).
  // `inicio` = antes do clique (para reconhecer uma aba aberta pela própria página); a espera conta a partir de agora.
  async function aguardarReacaoContinuar(inicio) {
    const limite = Date.now() + ESPERA_REACAO_CONTINUAR_MS;
    let avisoFechouEm = 0;
    while (Date.now() < limite) {
      if ((await mensagem({ tipo: 'ultima-aba-criada' }) || 0) >= inicio) return 'Abriu uma janela nova.';
      if (await pedirAoQuadro('achar', 'pgfn')) return 'A tela da PGFN abriu no quadro.';
      // O aviso fecha antes de a aba nova aparecer: espera mais um pouco por ela antes de concluir.
      if (!await avisoSisparPresente()) {
        avisoFechouEm = avisoFechouEm || Date.now();
        if (Date.now() - avisoFechouEm > 4000) return 'O aviso fechou.'; // a tela da PGFN está carregando no quadro
      }
      await sleep(400);
    }
    if (aberturaCapturada && aberturaCapturada.bloqueada) estado.popupBloqueado = aberturaCapturada.url;
    return null; // o aviso continua aberto: o clique não pegou
  }

  async function abrirDocumentoArrecadacao() {
    if (estado.continuouEmAba) return; // no Regularize: o trabalho seguiu na aba nova do SISPAR
    mostrarAviso('aguardando a tela da PGFN carregar…');
    // A tela de emissão já está aberta (ex.: a página recarregou depois do clique): nada a fazer no menu.
    if (await pedirAoQuadro('achar', 'telaEmissao')) {
      log('a tela de emissão já está aberta; pulando o menu');
      return;
    }
    try {
      const tela = await esperar(async () => (await pedirAoQuadro('achar', 'semPermissao') && 'sem permissão') ||
        await pedirAoQuadro('achar', 'menuEmissao'), `o menu "${TEXTO_MENU_EMISSAO}"`, TIMEOUT_REGULARIZE_MS);
      if (tela === 'sem permissão') throw await erroSemPermissao();
    } catch (e) {
      if (!e.tempoEsgotado) throw e;
      throw new Error(`o menu "${TEXTO_MENU_EMISSAO}" não apareceu em ${Math.round(TIMEOUT_REGULARIZE_MS / 1000)} s. ` +
        `Endereço do quadro: ${hostDoIframe()}` +
        (estado.popupBloqueado ? '. A página tentou abrir uma janela que o Chrome bloqueou: permita pop-ups no Regularize ' +
          '(ícone à direita da barra de endereço) e comece de novo' : ''));
    }
    if (CLIQUE_MANUAL_NO_DOCUMENTO) {
      estado.cliqueManual = true;
      mostrarAviso(`TESTE DE DIAGNÓSTICO: agora é com você.\nPasse o mouse em "${TEXTO_MENU_EMISSAO}" e clique em ` +
        `"${TEXTO_DOC_ARRECADACAO}". Depois a automação continua sozinha.`, 'ok');
      return;
    }
    // Este clique recarrega a página: a página nova continua na conferência do resultado (sem clicar de novo aqui).
    await usarMenuDocumento(async () => { estado.etapa = ETAPA_VERIFICAR_RESULTADO; await gravarEstado(); });
  }

  // Menu "Emissão de Documento" > "Documento de arrecadação": passa a seta no menu (sem clicar), desce até a opção e
  // clica nela. `antesDoClique` grava de onde continuar, porque o clique recarrega a página.
  async function usarMenuDocumento(antesDoClique) {
    mostrarAviso('analisando as opções do menu…');
    await sleep(rand(1200, 2000)); // "lê" o menu antes de escolher
    let abriu = false;
    for (let tent = 1; tent <= TENTATIVAS_MENU && !abriu; tent++) {
      mostrarAviso(tent === 1
        ? `passando a seta sobre "${TEXTO_MENU_EMISSAO}"…`
        : `as opções não apareceram; passando a seta de novo (${tent} de ${TENTATIVAS_MENU})…`);
      // Só passa a seta por cima (não clica): o menu abre com a seta em cima.
      await clicarNoQuadro('menuEmissao', `menu "${TEXTO_MENU_EMISSAO}"`, 'passar');
      try {
        await esperar(() => pedirAoQuadro('achar', 'docArrecadacao'), `a opção "${TEXTO_DOC_ARRECADACAO}"`, TIMEOUT_JANELA_MS);
        abriu = true;
      } catch (e) {
        if (!e.tempoEsgotado) throw e;
      }
    }
    if (!abriu) {
      throw new Error(`passei a seta sobre "${TEXTO_MENU_EMISSAO}" ${TENTATIVAS_MENU} vezes e a opção "${TEXTO_DOC_ARRECADACAO}" não apareceu`);
    }
    await sleep(rand(500, 900)); // "lê" as duas opções
    mostrarAviso(`clicando em "${TEXTO_DOC_ARRECADACAO}"…`);
    const info = await pedirAoQuadro('achar', 'docArrecadacao');
    estado.infoDoc = info && info.info; // para o diagnóstico, se o site recusar o acesso
    log(`link de "${TEXTO_DOC_ARRECADACAO}": ${estado.infoDoc}`);
    await clicarNoQuadro('docArrecadacao', `opção "${TEXTO_DOC_ARRECADACAO}" do menu`, 'clicar', { descer: true, antesDoClique });
    await sleep(rand(1500, 2500));
  }

  // ------------------------------- negociações "DEFERIDA E CONSOLIDADA", uma por vez -------------------------------
  // Cada uma é identificada pelo Número da Conta (a posição na tabela muda quando a página recarrega). O andamento
  // (contas a fazer e já feitas) fica no estado, então a etapa continua certa depois de cada recarga da página.
  const semZeros = (s) => soDigitos(s).replace(/^0+/, '');
  const pendentesDeferidas = () => (estado.deferidas || []).filter((c) => !(estado.feitas || []).includes(c));

  async function processarDeferidas() {
    if (estado.continuouEmAba || !estado.temNegociacoes) return; // sem tabela (ou fora da aba do SISPAR): nada a fazer
    try {
      await percorrerDeferidas();
    } catch (e) {
      // parou no meio: salva o que já foi conferido, para não perder o registro das pendências
      if (!e.cancelado) {
        const caminho = await salvarRelatorio(true).catch((x) => { log('relatório parcial não salvo:', x.message); return null; });
        if (caminho) e.message += `.\nRelatório parcial salvo em:\n${caminho}`;
      }
      throw e;
    }
    const perfil = estado.confirmado ? `Perfil no e-CAC: ${estado.confirmado}\n` : '';
    if (!estado.deferidas || !estado.deferidas.length) {
      const caminho = await salvarSemDeferido();
      estado.fim = `${perfil}Nenhuma negociação "${TEXTO_DEFERIDA}" na tabela.\nPrint salvo em PDF:\n${caminho}`;
      return;
    }
    const caminho = await salvarRelatorio(false).catch((x) => `NÃO SALVO (${x.message})`);
    const linhas = estado.feitas.map((c) => {
      const s = resumoDaConta(c);
      return `• conta ${c}: ${s.conferidas} conferidas até ${competenciaAtual()}, ${s.pendencias} pendência(s)` +
        `${s.pendencias ? ` (${s.baixadas} documento(s) baixado(s))` : ''}${s.jaEmitidas ? `, ${s.jaEmitidas} já emitida(s) (ícone laranja)` : ''}` +
        `${s.desconhecidas ? `, ${s.desconhecidas} ícone(s) desconhecido(s)` : ''}` +
        (() => {
          const an = (estado.analises || {})[c] || {};
          const f = an.final;
          return (f ? `; tela final: ${f.pendentes.length ? `${f.pendentes.length} AINDA PENDENTE(S) (${f.pendentes.join(', ')})` : 'sem pendência'}` : '') +
            (an.printConfirmacao ? `\n  print: ${an.printConfirmacao}` : '');
        })();
    });
    estado.fim = `${perfil}Negociações "${TEXTO_DEFERIDA}": ${estado.feitas.length} de ${estado.deferidas.length} analisadas.\n` +
      `${linhas.join('\n')}\nRelatório: ${caminho}`;
  }

  async function percorrerDeferidas() {
    estado.feitas = estado.feitas || [];
    // O ajudante do Windows (janela "Salvar como") responde? Avisa já no começo, e não só quando a janela aparecer.
    if (!estado.ajudanteConferido) {
      estado.ajudanteConferido = true;
      const aj = await mensagem({ tipo: 'ajudante-status' });
      if (aj && aj.ok) log(`ajudante "Salvar como" pronto (versão ${aj.versao})`);
      else {
        log('ajudante "Salvar como" indisponível:', aj && aj.erro);
        mostrarAviso(`Atenção: o ajudante da janela "Salvar como" não respondeu (${(aj && aj.erro) || 'sem resposta'}).\n` +
          (aj && aj.semAjudante ? 'Rode uma vez Instalar.bat (pasta ATM_PGFN) e recarregue a extensão.\n' : '') +
          'Se a janela "Salvar como" aparecer, será preciso clicar em "Salvar".', 'erro');
        await sleep(5000);
      }
      await gravarEstado();
    }
    for (let volta = 0; volta < 1000; volta++) {
      // espera a página terminar de carregar: ou a página da negociação, ou a lista
      let onde;
      try {
        // a página do PDF tem o mesmo título da página da negociação: é reconhecida primeiro
        // 0.36.0: "Você não tem permissão de acesso ou ele expirou" também aqui (em 10/11/2026 14:52 apareceu ao abrir
        // "Documento de arrecadação" para a 3ª negociação e foi tratado como lentidão: repetiu na mesma página, à toa)
        onde = await esperar(async () => (await pedirAoQuadro('achar', 'semPermissao') && 'sem permissão') ||
          (await pedirAoQuadro('achar', 'paginaPdf') && 'pdf') ||
          (await pedirAoQuadro('achar', 'telaDetalhe') && 'detalhe') ||
          (await pedirAoQuadro('achar', 'situacoes') && 'lista'), 'a lista ou a página da negociação', TIMEOUT_REGULARIZE_MS);
      } catch (e) {
        if (!e.tempoEsgotado) throw e;
        if (await pedirAoQuadro('achar', 'semPermissao')) throw await erroSemPermissao();
        throw new Error('não encontrei a tabela de negociações nem a página da negociação');
      }
      if (onde === 'sem permissão') throw await erroSemPermissao();
      // ---- página do PDF (depois de "Emitir"; a página recarregou): baixa, confere e volta
      if (onde === 'pdf') {
        await tratarPaginaPdf((estado.analises || {})[estado.contaAtual], estado.contaAtual);
        continue;
      }
      // ---- página da negociação aberta ("EMISSÃO DE DOCUMENTO DE ARRECADAÇÃO - INTERNET")
      if (onde === 'detalhe') {
        const ref = semZeros(((await pedirAoQuadro('ler', 'refConta')) || {}).conta || '');
        if (!estado.contaAtual) throw new Error('a página de uma negociação abriu, mas não sei qual conta foi selecionada');
        if (ref && ref !== semZeros(estado.contaAtual)) {
          throw new Error(`abriu a negociação da conta ${ref}, mas a selecionada era ${estado.contaAtual}`);
        }
        const total = estado.deferidas.length;
        if (!estado.feitas.includes(estado.contaAtual)) {
          mostrarAviso(`negociação ${estado.feitas.length + 1} de ${total} aberta (conta ${estado.contaAtual}).`);
          log(`negociação aberta: conta ${estado.contaAtual} (${estado.feitas.length + 1} de ${total})`);
          await sleep(rand(1200, 2000)); // "olha" a página aberta
          // coluna "Emissão" de todas as prestações; baixa o documento das pendentes
          try {
            await analisarPrestacoes(estado.contaAtual);
            // de volta à tela "Prestação" com tudo emitido: confere de novo na tela e guarda o print de confirmação
            await confirmarSituacaoFinal(estado.contaAtual);
          } catch (e) {
            if (e.reiniciar) continue; // saiu da página do PDF sem recarregar: confere de novo onde está
            throw e;
          }
          estado.feitas.push(estado.contaAtual);
          estado.retomadas = 0; // progresso: zera o contador de recargas
          await gravarEstado();
        }
        if (!pendentesDeferidas().length) break;
        await rolarAteOTopo(); // o menu fica no alto da página
        // volta à lista pelo menu (o mesmo caminho que já funciona); a página recarrega e esta etapa continua
        mostrarAviso(`voltando à lista para a próxima negociação (faltam ${pendentesDeferidas().length})…`);
        await usarMenuDocumento(() => gravarEstado());
        await esperar(async () => !await pedirAoQuadro('achar', 'telaDetalhe') && await pedirAoQuadro('achar', 'situacoes'),
          'a lista de negociações', TIMEOUT_REGULARIZE_MS);
        continue;
      }

      // ---- lista de negociações
      await sleep(rand(500, 900)); // deixa a tabela terminar de montar
      if (!estado.deferidas) {
        const linhas = ((await pedirAoQuadro('ler', 'linhas')) || {}).linhas || [];
        estado.deferidas = linhas.filter((l) => chave(l.situacao) === chave(TEXTO_DEFERIDA) && l.conta).map((l) => l.conta);
        estado.deferidas = [...new Set(estado.deferidas)];
        log(`contas "${TEXTO_DEFERIDA}": ${estado.deferidas.join(', ') || 'nenhuma'}`);
        await gravarEstado();
        if (!estado.deferidas.length) break;
      }
      const pend = pendentesDeferidas();
      if (!pend.length) break;
      // de volta à lista depois de uma negociação: ordena de novo por "Situação da conta" (como na primeira vez)
      if (estado.feitas.length && estado.ordenadaApos !== estado.feitas.length) {
        await ordenarPorSituacao();
        estado.ordenadaApos = estado.feitas.length;
        await gravarEstado();
      }
      const conta = pend[0];
      const n = estado.feitas.length + 1;
      estado.contaAtual = conta;
      await gravarEstado();

      // seleciona a linha (um clique na linha) e confere que ficou selecionada e o botão de baixo habilitou
      let selecionada = false;
      for (let tent = 1; tent <= TENTATIVAS_SELECIONAR && !selecionada; tent++) {
        mostrarAviso(`negociação ${n} de ${estado.deferidas.length}: selecionando a linha da conta ${conta}…`);
        await sleep(rand(600, 1100));
        await clicarNoQuadro('linhaConta', `linha da conta ${conta}`, 'clicar', { extra: { conta } });
        try {
          await esperar(async () => {
            const l = await pedirAoQuadro('ler', 'linhaConta', { conta });
            const b = await pedirAoQuadro('ler', 'botaoDocArrec');
            return l && l.selecionada && b && b.habilitado;
          }, 'a linha selecionada', TIMEOUT_JANELA_MS);
          selecionada = true;
        } catch (e) {
          if (!e.tempoEsgotado) throw e;
        }
      }
      if (!selecionada) {
        throw new Error(`cliquei ${TENTATIVAS_SELECIONAR} vezes na linha da conta ${conta} e ela não ficou selecionada ` +
          `(ou o botão "${TEXTO_BOTAO_DOC}" abaixo da tabela não habilitou)`);
      }
      // botão "Documento de Arrecadação" ABAIXO da tabela (não a opção do menu); o clique abre a página da negociação
      await sleep(rand(500, 1000));
      mostrarAviso(`negociação ${n} de ${estado.deferidas.length}: clicando em "${TEXTO_BOTAO_DOC}" abaixo da tabela…`);
      await clicarNoQuadro('botaoDocArrec', `botão "${TEXTO_BOTAO_DOC}" abaixo da tabela`, 'clicar', { antesDoClique: () => gravarEstado() });
      mostrarAviso('aguardando a página da negociação abrir…');
      try {
        await esperar(() => pedirAoQuadro('achar', 'telaDetalhe'), 'a página da negociação', TIMEOUT_REGULARIZE_MS);
      } catch (e) {
        if (!e.tempoEsgotado) throw e;
        throw new Error(`cliquei em "${TEXTO_BOTAO_DOC}" (conta ${conta}) e a página "${TEXTO_TELA_DETALHE}" não abriu`);
      }
    }
  }

  // ------------------------------- página da negociação: coluna "Emissão" -------------------------------
  // Competência = mês/ano da "Data Vencimento Prestação". Conferidas: todas até o mês atual (do relógio do computador);
  // meses futuros são só anotados, nunca tratados como pendência.
  const indiceMes = (mes, ano) => ano * 12 + mes;
  const agoraIndice = () => { const d = new Date(); return indiceMes(d.getMonth() + 1, d.getFullYear()); };
  const competenciaAtual = () => { const d = new Date(); return `${String(d.getMonth() + 1).padStart(2, '0')}/${d.getFullYear()}`; };
  function competenciaDe(data) {
    const m = /(\d{2})\/(\d{2})\/(\d{4})/.exec(data || '');
    return m ? { mes: Number(m[2]), ano: Number(m[3]), texto: `${m[2]}/${m[3]}`, arquivo: `${m[2]}-${m[3]}` } : null;
  }
  const valorDe = (s) => Number(String(s || '').replace(/[^\d,]/g, '').replace(',', '.')) || 0;

  // Resultado de cada prestação conferida (fica em estado.analises[conta].linhas[prestação]):
  // regular | pendente-baixado | pendente-sem-documento | sem-acao | desconhecido | futura
  function classificar(l) {
    const comp = competenciaDe(l.venc);
    if (!comp) return { r: 'desconhecido', obs: `data de vencimento ilegível ("${l.venc}")` };
    if (indiceMes(comp.mes, comp.ano) > agoraIndice()) return { r: 'futura' };
    if (l.icone === 'verificado') return { r: 'regular' };
    // ícone laranja: documento já emitido; não emite de novo (a data dele é conferida na tela final)
    if (l.icone === 'emitido') {
      return { r: 'ja-emitido', obs: `documento ${l.docCob || '(sem número na tela)'}${l.vencDoc ? `, vence ${l.vencDoc}` : ''}` };
    }
    // impressora (ou outro ícone clicável com saldo devedor): pendência confirmada -> baixar o documento
    if (l.icone === 'impressora' && l.clicavel) return { r: 'pendente', baixar: true };
    if (l.icone === 'outro' && l.clicavel && valorDe(l.saldo) > 0) return { r: 'pendente', baixar: true };
    if (l.icone === 'vazio') return { r: 'sem-acao', obs: 'sem ícone na coluna Emissão' };
    return { r: 'desconhecido', obs: `ícone não reconhecido: ${l.desc}` };
  }

  function resumoDaConta(conta) {
    const linhas = Object.values(((estado.analises || {})[conta] || {}).linhas || {});
    const conta_ = (f) => linhas.filter(f).length;
    return {
      conferidas: conta_((l) => l.r !== 'futura'),
      pendencias: conta_((l) => /^pendente/.test(l.r)),
      baixadas: conta_((l) => l.r === 'pendente-baixado'),
      desconhecidas: conta_((l) => l.r === 'desconhecido'),
      futuras: conta_((l) => l.r === 'futura'),
      jaEmitidas: conta_((l) => l.r === 'ja-emitido'),
    };
  }

  // Rolagem com a "roda do mouse": a seta fica sobre a tabela e a página desce em dentes, com pausas para os registros
  // renderizarem. Devolve false quando já está no fim.
  async function rolarDentes(sentido = 1) {
    const dentes = Math.round(rand(2, 4));
    let mexeu = false;
    for (let i = 0; i < dentes; i++) {
      const r = await pedirAoQuadro('rolar', 'prestacoes', { delta: sentido * rand(...ROLAGEM_DENTE_PX), x: cursor.x, y: cursor.y });
      if (r && r.mexeu) mexeu = true; else break;
      await sleep(rand(60, 160));
    }
    atualizarHover(); // o conteúdo passou por baixo da seta
    await sleep(rand(350, 800)); // espera renderizar e "lê"
    return mexeu;
  }

  async function rolarAteOTopo() {
    for (let i = 0; i < 400; i++) {
      const r = await pedirAoQuadro('rolar', 'pagina', { delta: -rand(140, 220), x: cursor.x, y: cursor.y });
      if (!r || !r.mexeu) break;
      await sleep(rand(30, 90));
    }
    atualizarHover();
    await sleep(rand(300, 600));
  }

  async function analisarPrestacoes(conta) {
    estado.analises = estado.analises || {};
    const a = estado.analises[conta] = estado.analises[conta] || { linhas: {}, paginas: 0 };
    estado.baixados = estado.baixados || {};
    estado.nomesUsados = estado.nomesUsados || [];
    const pref = `conta ${conta}`;

    // de volta à página da negociação com uma emissão pela metade
    const b = a.baixando;
    if (b && b.fase === 'icone') {
      // só tinha aberto a janela (nada foi emitido): a prestação é conferida de novo
      delete a.linhas[b.prest];
      estado.nomesUsados = estado.nomesUsados.filter((n) => n !== b.nome);
      a.baixando = null;
      await gravarEstado();
    } else if (b && b.fase === 'voltar') {
      a.baixando = null; // PDF já salvo; só faltava o "Voltar"
      await gravarEstado();
    } else if (b) {
      throw new Error(`conta ${conta}, prestação ${b.prest}: cliquei em "${TEXTO_EMITIR}", mas voltei à negociação sem ver ` +
        'o PDF salvo. Confira a pasta do cliente; não emiti de novo, para não gerar documento repetido');
    }

    mostrarAviso(`${pref}: aguardando a tabela "Prestação" carregar…`);
    let leitura;
    try {
      leitura = await esperar(async () => {
        const t = await pedirAoQuadro('ler', 'prestacoes');
        return t && t.linhas && t.linhas.length ? t : null;
      }, 'a tabela "Prestação" com a coluna "Emissão"', TIMEOUT_REGULARIZE_MS);
    } catch (e) {
      if (!e.tempoEsgotado) throw e;
      throw new Error(`a página da negociação (conta ${conta}) abriu, mas não encontrei a tabela "Prestação" com a coluna "${TEXTO_COL_EMISSAO}"`);
    }
    // o cliente da página tem que ser o CNPJ ativo: assim nenhum documento vai para a pasta de outro cliente
    const contrib = await pedirAoQuadro('ler', 'contribuinte');
    if (contrib && contrib.cnpj) {
      if (estado.cnpj && contrib.cnpj !== estado.cnpj) {
        throw new Error(`a negociação da conta ${conta} é do CNPJ ${formatarCnpj(contrib.cnpj)}, mas o CNPJ ativo é ` +
          `${formatarCnpj(estado.cnpj)}. Parei para não associar documentos ao cliente errado`);
      }
      if (!estado.cnpj) { estado.cnpj = contrib.cnpj; estado.empresa = estado.empresa || contrib.nome; await gravarEstado(); }
    }
    // a seta vai para cima da tabela (para a roda do mouse rolar a tabela)
    const area = leitura.area;
    const alvoY = clamp(leitura.tabela.top + rand(60, 160), area.topo + 40, area.base - 40);
    await moverPara(clamp(leitura.tabela.left + leitura.tabela.width * rand(0.25, 0.6), 20, innerWidth - 20), alvoY);
    mostrarAviso(`${pref}: conferindo a coluna "${TEXTO_COL_EMISSAO}" até ${competenciaAtual()}…`);

    for (let volta = 0; volta < 2000; volta++) {
      leitura = await pedirAoQuadro('ler', 'prestacoes');
      if (!leitura || !leitura.linhas) throw new Error(`a tabela "Prestação" da conta ${conta} sumiu durante a análise`);
      const { topo, base } = leitura.area;
      // confere as linhas que estão inteiras na tela agora (como quem lê enquanto rola)
      let baixou = false;
      for (const l of leitura.linhas) {
        if (a.linhas[l.prest]) continue;
        if (l.top < topo + 2 || l.bottom > base - 2) continue;
        if (await registrarLinha(a, conta, l)) { baixou = true; break; }
      }
      if (baixou) continue; // relê a tabela antes de seguir rolando
      const faltam = leitura.linhas.filter((l) => !a.linhas[l.prest]).length;
      const s = resumoDaConta(conta);
      mostrarAviso(`${pref}: conferindo a coluna "${TEXTO_COL_EMISSAO}" até ${competenciaAtual()}…\n` +
        `${Object.keys(a.linhas).length} de ${leitura.linhas.length} prestações vistas, ${s.pendencias} pendência(s)`);
      if (await rolarDentes(1)) { estado.cursor = { x: cursor.x, y: cursor.y }; await gravarEstado(); continue; }
      // chegou ao fim da rolagem: linhas que ficaram escondidas (ex.: atrás do aviso de cookies) são conferidas pela
      // leitura da tabela; uma pendência escondida é trazida para a tela antes do clique (registrarLinha)
      if (faltam) {
        let baixouEscondida = false;
        for (const l of leitura.linhas) {
          if (!a.linhas[l.prest] && await registrarLinha(a, conta, l)) { baixouEscondida = true; break; }
        }
        if (baixouEscondida) continue;
      }
      // tabela com páginas: passa para a próxima
      if (leitura.proxima && a.paginas < 50) {
        a.paginas++;
        await gravarEstado();
        const antes = leitura.linhas.map((l) => l.prest).join('|');
        mostrarAviso(`${pref}: fim desta página da tabela; indo para a próxima…`);
        await clicarNoQuadro('proximaPagina', 'botão de próxima página da tabela "Prestação"');
        await esperar(async () => {
          const t = await pedirAoQuadro('ler', 'prestacoes');
          return t && t.linhas && t.linhas.length && t.linhas.map((l) => l.prest).join('|') !== antes;
        }, 'a próxima página da tabela', TIMEOUT_JANELA_MS * 2);
        continue;
      }
      break;
    }
    const s = resumoDaConta(conta);
    log(`conta ${conta}: ${s.conferidas} conferidas, ${s.pendencias} pendências, ${s.baixadas} baixadas, ${s.futuras} futuras`);
    mostrarAviso(`${pref}: análise concluída. ${s.conferidas} prestações até ${competenciaAtual()}, ` +
      `${s.pendencias} pendência(s), ${s.baixadas} documento(s) baixado(s).`);
    await sleep(rand(900, 1600));
  }

  async function registrarLinha(a, conta, l) {
    const c = classificar(l);
    const comp = competenciaDe(l.venc);
    const reg = { prest: l.prest, venc: l.venc, comp: comp ? comp.texto : '', valor: l.valor, saldo: l.saldo,
      icone: l.icone, r: c.r, obs: c.obs || '' };
    a.linhas[l.prest] = reg;
    if (!c.baixar) {
      if (c.r === 'desconhecido') log(`prestação ${l.prest}: ${c.obs}`);
      return false;
    }
    reg.r = 'pendente-sem-documento'; // vira "baixado" quando o documento chegar
    await gravarEstado();
    await baixarDocumento(a, conta, l, reg);
    return true; // a tela pode ter rolado: quem chamou relê as posições
  }

  // Nome do documento: "CNPJ;NOME;MM-AAAA" (+ conta/prestação só se a mesma competência já tiver sido salva).
  async function nomeDoDocumento(conta, l) {
    const base = `${await baseDoNome()};${competenciaDe(l.venc).arquivo}`;
    const nome = estado.nomesUsados.includes(base) ? `${base};conta ${conta};prest ${l.prest}` : base;
    estado.nomesUsados.push(nome);
    return nome;
  }

  // Pasta do cliente: Documentos_arrecadacao/<CNPJ só dígitos> (o CNPJ ativo, conferido na página da negociação).
  // Regra para todo arquivo salvo: o destino é a pasta do CNPJ em processamento. Confere antes: CNPJ de 14 dígitos e,
  // se a tela mostrar "Usuário: <CNPJ>", que é o mesmo; senão, não salva (nada vai para pasta errada ou solta).
  async function pastaDoCliente() {
    const cnpj = (await baseDoNome()).split(';')[0];
    if (!/^\d{14}$/.test(cnpj)) throw new Error('não sei qual CNPJ está sendo consultado; não salvei o arquivo para não errar a pasta');
    if (estado.cnpj && estado.cnpj !== cnpj) {
      throw new Error(`o arquivo seria do CNPJ ${formatarCnpj(cnpj)}, mas o CNPJ em processamento é ${formatarCnpj(estado.cnpj)}; não salvei`);
    }
    const usuario = await pedirAoQuadro('achar', 'usuario');
    const naTela = usuario && soDigitos((/([\d./-]{18})/.exec(usuario.texto || '') || [])[1] || '');
    if (naTela && naTela.length === 14 && naTela !== cnpj) {
      throw new Error(`a tela é do CNPJ ${formatarCnpj(naTela)}, mas o CNPJ em processamento é ${formatarCnpj(cnpj)}; não salvei`);
    }
    return `${pastaDocumentos()}/${cnpj}`;
  }
  const sinalReiniciar = () => Object.assign(new Error('a página mudou; recomeçando a leitura da tela'), { reiniciar: true });

  // Pendência: ícone -> janela "Cálculo e demonstrativo..." (confere a parcela) -> "Emitir" -> página do PDF -> link do
  // PDF (download conferido) -> "Voltar". Cada passo grava a fase em a.baixando, para a página nova continuar do ponto
  // certo sem repetir o que já foi feito (nunca clica em "Emitir" duas vezes para a mesma prestação).
  async function baixarDocumento(a, conta, l, reg) {
    const chaveDl = `${conta}|${l.prest}`;
    if (estado.baixados[chaveDl]) { // nunca baixa duas vezes a mesma prestação
      reg.r = 'pendente-baixado'; reg.arquivo = estado.baixados[chaveDl];
      return;
    }
    // registro permanente: o PDF desta prestação já foi salvo neste mês (numa execução anterior)? Não emite de novo.
    const pasta = await pastaDoCliente();
    const d = new Date();
    const chaveReg = `${pasta.split('/').pop()}|${semZeros(conta)}|${semZeros(l.prest)}|${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
    const anterior = await mensagem({ tipo: 'registro-ver', chave: chaveReg });
    if (anterior) {
      reg.r = 'pendente-baixado'; reg.arquivo = anterior.arquivo; reg.obs = 'PDF já salvo antes, neste mês: não emiti de novo';
      estado.baixados[chaveDl] = anterior.arquivo;
      await gravarEstado();
      log(`prestação ${l.prest}: já salva antes (${anterior.arquivo})`);
      return;
    }
    const nome = await nomeDoDocumento(conta, l);
    await aceitarCookiesPgfn(); // o aviso de cookies cobre a parte de baixo da tabela
    mostrarAviso(`conta ${conta}: prestação ${l.prest} (${reg.comp}) pendente; abrindo a emissão do documento…`);
    await sleep(rand(600, 1200)); // "confere" a linha antes de clicar
    // traz a linha para a área livre da tela, rolando com a roda, se precisar
    for (let i = 0; i < 40; i++) {
      const p = await pedirAoQuadro('achar', 'iconeEmissao', { prest: l.prest });
      const t = await pedirAoQuadro('ler', 'prestacoes');
      if (!p || !t) break;
      if (p.top >= t.area.topo + 90 && p.top + p.height <= t.area.base - 90) break;
      const sentido = p.top < t.area.topo + 90 ? -1 : 1;
      await pedirAoQuadro('rolar', 'prestacoes', { delta: sentido * rand(...ROLAGEM_DENTE_PX), x: cursor.x, y: cursor.y });
      await sleep(rand(120, 260));
    }
    a.baixando = { prest: l.prest, comp: reg.comp, chave: chaveDl, chaveReg, nome, pasta, fase: 'icone', t: Date.now() };
    await gravarEstado();
    await clicarNoQuadro('iconeEmissao', `ícone da coluna "${TEXTO_COL_EMISSAO}" da prestação ${l.prest}`, 'clicar',
      { extra: { prest: l.prest } });

    // janela "Cálculo e demonstrativo de emissão de Documento de Arrecadação"
    mostrarAviso(`conta ${conta}: aguardando a janela "${TEXTO_JANELA_EMISSAO}"…`);
    let janela;
    try {
      janela = await esperar(() => pedirAoQuadro('ler', 'janelaEmissao'), `a janela "${TEXTO_JANELA_EMISSAO}"`, TIMEOUT_ELEMENTO_MS);
    } catch (e) {
      if (!e.tempoEsgotado) throw e;
      const info = await pedirAoQuadro('achar', 'iconeEmissao', { prest: l.prest });
      throw new Error(`conta ${conta}: cliquei no ícone da prestação ${l.prest} e a janela "${TEXTO_JANELA_EMISSAO}" não abriu` +
        `${info ? `.\nDIAGNÓSTICO do ícone: ${info.info}` : ''}`);
    }
    // a janela tem que ser da prestação clicada ("Parcela para emissão: 55" = Nr. Prestação 0055)
    if (janela.parcela && semZeros(janela.parcela) !== semZeros(l.prest)) {
      await clicarNoQuadro('voltarJanela', `botão "${TEXTO_VOLTAR}" da janela`);
      throw new Error(`cliquei na prestação ${l.prest}, mas a janela mostrou "Parcela para emissão: ${janela.parcela}". ` +
        `Voltei sem emitir`);
    }
    // janela com "Calcular" (parcela que depende da receita bruta): o cálculo do sistema vem antes do "Emitir"
    if (janela.exigeCalculo) {
      janela = await calcularNaJanela(a, conta, l, reg, janela);
      if (!janela) return; // você fechou a janela sem calcular: a prestação fica registrada como não emitida
    }
    mostrarAviso(`conta ${conta}: parcela ${janela.parcela || l.prest}` +
      `${janela.valor ? `, valor ${janela.valor}` : ''}; clicando em "${TEXTO_EMITIR}"…`);
    await sleep(rand(1200, 2200)); // "lê" o demonstrativo
    await clicarNoQuadro('emitir', `botão "${TEXTO_EMITIR}"`, 'clicar', {
      antesDoClique: async () => { a.baixando.fase = 'emitir'; a.baixando.tEmitir = Date.now(); await gravarEstado(); },
    });
    // "Emitir" abre a página do PDF (a página muda; se mudar sem recarregar, segue aqui mesmo)
    mostrarAviso(`conta ${conta}: aguardando a página do PDF…`);
    try {
      await esperar(() => pedirAoQuadro('achar', 'paginaPdf'), 'a página do PDF', TIMEOUT_REGULARIZE_MS);
    } catch (e) {
      if (!e.tempoEsgotado) throw e;
      throw new Error(`conta ${conta}, prestação ${l.prest}: cliquei em "${TEXTO_EMITIR}" e a página com o PDF não abriu. ` +
        'Não cliquei de novo, para não emitir documento repetido');
    }
    await tratarPaginaPdf(a, conta);
    throw sinalReiniciar(); // depois do "Voltar": quem chamou descobre em que tela está
  }

  // ---- janela de emissão com cálculo prévio ("Calcular" + "Receita bruta apurada no mês anterior") ----
  // O "Emitir" só é liberado depois do "Calcular". A automação clica em "Calcular" com o valor que o sistema já mostra
  // no campo (não digita nem altera valores financeiros) e confere o resultado do SISTEMA (mesma parcela, valor da
  // prestação calculado, "Emitir" liberado); aí segue para o "Emitir" de sempre. Só se o sistema NÃO liberar o "Emitir"
  // (exige algum dado), PAUSA: você informa e clica em "Calcular" (se só digitar e sair do campo, ela clica).
  // "Voltar" na janela = esta parcela não é emitida (fica registrada no relatório).
  // Devolve a janela já calculada, ou null se a janela foi fechada sem calcular.
  async function calcularNaJanela(a, conta, l, reg, janela) {
    const parcela = semZeros(janela.parcela || l.prest);
    const calculada = (j) => j && j.emitirHabilitado && j.valorNumero > 0;
    const receitaUsada = janela.receita; // o valor que o sistema mostrava (usado no 1º "Calcular")
    // 1º) "Calcular" com o valor que o sistema JÁ mostra no campo (nada é digitado nem alterado). Se o sistema calcular
    // e liberar o "Emitir", segue sozinho; só pausa se ele não liberar (aí exige algum dado: é com você).
    mostrarAviso(`conta ${conta}, parcela ${parcela}: janela com "${TEXTO_CALCULAR}"; calculando com o valor já apresentado ` +
      `no campo (${janela.receita || 'vazio'}), sem alterar…`);
    log(`conta ${conta}, prestação ${l.prest}: janela com cálculo prévio; "${TEXTO_CALCULAR}" com o valor do campo ("${janela.receita}")`);
    await sleep(rand(1000, 1800)); // "lê" a janela
    await clicarNoQuadro('calcular', `botão "${TEXTO_CALCULAR}"`);
    let pronta = null;
    const limite = Date.now() + TIMEOUT_ELEMENTO_MS;
    while (Date.now() < limite) {
      await sleep(500);
      const j = await pedirAoQuadro('ler', 'janelaEmissao');
      if (!j) break; // a janela fechou: tratado abaixo
      if (j.parcela && semZeros(j.parcela) !== semZeros(l.prest)) {
        throw new Error(`a janela de cálculo mudou para a parcela ${j.parcela}, mas a prestação é ${l.prest}. Não emiti`);
      }
      if (calculada(j)) { pronta = j; break; }
    }
    if (pronta) {
      reg.obs = `calculada pelo sistema (receita no campo: ${pronta.receita || 'vazio'}): prestação ${pronta.valor}`;
      log(`conta ${conta}, prestação ${l.prest}: ${reg.obs}`);
      mostrarAviso(`conta ${conta}, parcela ${parcela}: cálculo do sistema conferido (prestação ${pronta.valor}); emitindo…`);
      await gravarEstado();
      return pronta;
    }
    janela = (await pedirAoQuadro('ler', 'janelaEmissao')) || janela;
    // 2º) o sistema não liberou o "Emitir" com o valor apresentado: exige algum dado. PAUSA (nunca inventa valor).
    const texto = `conta ${conta}, parcela ${parcela} (${reg.comp}): cliquei em "${TEXTO_CALCULAR}" com o valor já ` +
      `apresentado (${janela.receita || 'vazio'}), mas o sistema não liberou o "${TEXTO_EMITIR}" (valor da prestação: ` +
      `${janela.valor || '0,00'}). Confira a mensagem da janela e informe o dado pedido; depois clique em "${TEXTO_CALCULAR}". ` +
      `NÃO clique em "${TEXTO_EMITIR}": a automação confere o cálculo e emite. Para não emitir esta parcela, clique em "${TEXTO_VOLTAR}"`;
    log(`conta ${conta}, prestação ${l.prest}: o cálculo não liberou o "${TEXTO_EMITIR}"; aguardando você`);
    mostrarAviso(`PAUSA: ${texto}`, 'erro');
    await informarOrq('aguardando_humano', texto);
    let tocado = receitaUsada; // valor do campo com o qual a automação já clicou em "Calcular"
    let visto = receitaUsada, mudouEm = 0, ultimoAviso = Date.now();
    for (;;) {
      await sleep(700);
      const j = await pedirAoQuadro('ler', 'janelaEmissao');
      if (!j) { // janela fechada ("Voltar" ou X) sem emitir
        reg.obs = `não emitida: a janela de cálculo foi fechada sem "${TEXTO_CALCULAR}" (receita bruta não informada)`;
        estado.nomesUsados = (estado.nomesUsados || []).filter((n) => n !== a.baixando.nome);
        a.baixando = null;
        await gravarEstado();
        log(`conta ${conta}, prestação ${l.prest}: ${reg.obs}`);
        mostrarAviso(`conta ${conta}, parcela ${parcela}: janela fechada sem calcular; não emitida. Seguindo com as demais…`, 'erro');
        await informarOrq('em_andamento', `parcela ${parcela} não emitida (janela de cálculo fechada)`);
        return null;
      }
      if (j.parcela && semZeros(j.parcela) !== semZeros(l.prest)) {
        throw new Error(`a janela de cálculo mudou para a parcela ${j.parcela}, mas a prestação é ${l.prest}. Não emiti`);
      }
      // cálculo feito pelo sistema: valor da prestação preenchido e "Emitir" liberado
      if (j.emitirHabilitado && j.valorNumero > 0) {
        reg.obs = `calculada pelo sistema com receita bruta ${j.receita || '(campo vazio)'}: prestação ${j.valor}`;
        log(`conta ${conta}, prestação ${l.prest}: ${reg.obs}`);
        mostrarAviso(`conta ${conta}, parcela ${parcela}: cálculo do sistema conferido (prestação ${j.valor}).`);
        await informarOrq('em_andamento', `parcela ${parcela}: cálculo conferido; emitindo`);
        await gravarEstado();
        return j;
      }
      // você digitou a receita e saiu do campo, mas não clicou em "Calcular": a automação clica
      if (j.receita !== visto) { visto = j.receita; mudouEm = Date.now(); }
      if (mudouEm && j.receita !== tocado && !j.receitaEmFoco && Date.now() - mudouEm > 2500) {
        tocado = j.receita; mudouEm = 0;
        mostrarAviso(`conta ${conta}, parcela ${parcela}: receita bruta informada (${j.receita}); clicando em "${TEXTO_CALCULAR}"…`);
        await clicarNoQuadro('calcular', `botão "${TEXTO_CALCULAR}"`);
        continue;
      }
      if (Date.now() - ultimoAviso >= 60000) { // espera por você: sem prazo (o orquestrador sabe)
        ultimoAviso = Date.now();
        await informarOrq('aguardando_humano', texto);
        await gravarEstado();
      }
    }
  }

  // Aviso de cookies das páginas da PGFN (embaixo, "Permitir" / "Rejeitar"): clica em "Permitir" e espera o aviso sumir.
  // Sem aviso, não faz nada. Nunca interrompe o fluxo por causa dele.
  async function aceitarCookiesPgfn() {
    if (!NO_SISPARNET) return false;
    if (!(await pedirAoQuadro('achar', 'cookiesPermitir'))) return false;
    mostrarAviso(`aviso de cookies da PGFN; clicando em "${TEXTO_PERMITIR_COOKIES}"…`);
    await sleep(rand(600, 1100));
    try {
      await clicarNoQuadro('cookiesPermitir', `botão "${TEXTO_PERMITIR_COOKIES}" do aviso de cookies`);
      await esperar(async () => !(await pedirAoQuadro('achar', 'cookiesPermitir')), 'o aviso de cookies fechar', TIMEOUT_JANELA_MS * 2);
      await sleep(rand(400, 800));
      return true;
    } catch (e) {
      if (e.cancelado) throw e;
      log(`aviso de cookies: ${e.message}; seguindo`);
      return false;
    }
  }

  // Página do PDF ("resultadoDarfInternet"): clica no link do PDF, confere o download e clica em "Voltar".
  async function tratarPaginaPdf(a, conta) {
    const b = a && a.baixando;
    if (!b || (b.fase !== 'emitir' && b.fase !== 'link' && b.fase !== 'voltar')) {
      throw new Error('a página do PDF abriu, mas não sei de qual prestação ela é. Não baixei, para não associar o documento ao cliente errado');
    }
    for (let tent = 1; b.fase === 'emitir' || b.fase === 'link'; tent++) {
      if (b.fase === 'emitir') {
        const link = await esperar(() => pedirAoQuadro('achar', 'linkPdf'), 'o link do PDF', TIMEOUT_ELEMENTO_MS);
        log(`link do PDF: ${link.texto} (${link.info})`);
        mostrarAviso(`conta ${conta}: prestação ${b.prest}: clicando no PDF ${link.texto}${tent > 1 ? ` (tentativa ${tent} de ${TENTATIVAS_LINK_PDF})` : ''}…`);
        await sleep(rand(800, 1500));
        await mensagem({ tipo: 'download-limpar', chave: b.chave }); // resultado de uma tentativa anterior não vale
        const numero = numeroDoDocumento(link.texto);
        if (!await mensagem({ tipo: 'download-preparar', chave: b.chave, pasta: b.pasta, nome: b.nome, numero, validadeMs: ESPERA_DOCUMENTO_MS + 15000 })) {
          throw new Error(`a extensão recusou preparar o download "${b.pasta}/${b.nome}"`);
        }
        aberturaCapturada = null;
        log(`${rotuloSalvamento(conta, b)}: clicando no link do PDF ${link.texto} (tentativa ${tent} de ${TENTATIVAS_LINK_PDF})`);
        await clicarNoQuadro('linkPdf', `link do PDF ${link.texto}`, 'clicar', {
          antesDoClique: async () => { b.fase = 'link'; b.tLink = Date.now(); b.href = link.href || ''; b.numero = numero || link.texto; b.tentLink = tent; await gravarEstado(); },
        });
      }
      try {
        await concluirDownload(a, conta);
      } catch (e) {
        if (!e.motivo) throw e; // não é problema de salvamento (ex.: cancelado): segue como antes
        // o PDF pode ter sido salvo mesmo assim (aviso de fim atrasado): confere antes de clicar de novo (sem duplicar)
        if (await conferirSalvoAtrasado(a, conta)) break;
        if (!e.repetivel || tent >= TENTATIVAS_LINK_PDF || !await pedirAoQuadro('achar', 'linkPdf')) {
          // 0.35.0: com o orquestrador, NÃO pausa sem prazo: registra a evidência, deixa o CNPJ pendente (erro) e
          // encerra este CNPJ ("Sair com Segurança" e próximo). Sem orquestrador (modo manual), pausa como antes.
          if (ORQ) await desistirDoSalvamento(a, conta, e.motivo, tent); // lança o erro que encerra o CNPJ (ou volta se achou o PDF)
          else await aguardarSalvamentoManual(a, conta, e.motivo, tent); // volta só com o PDF salvo e conferido
          break;
        }
        log(`${rotuloSalvamento(conta, b)}: ${e.motivo}; clicando no link do PDF de novo (tentativa ${tent + 1} de ${TENTATIVAS_LINK_PDF})`);
        mostrarAviso(`conta ${conta}, prestação ${b.prest}: ${e.motivo}.\nTentando o link do PDF de novo (${tent + 1} de ${TENTATIVAS_LINK_PDF})…`);
        await informarOrq('em_andamento', `salvamento: conta ${conta}, prestação ${b.prest}: ${e.motivo}; tentativa ${tent + 1} de ${TENTATIVAS_LINK_PDF}`);
        b.fase = 'emitir'; // só o clique no link (o documento já está emitido)
        await gravarEstado();
        await sleep(rand(2000, 3000));
      }
    }
    // de volta à página da negociação, para continuar a coluna "Emissão"
    await sleep(rand(700, 1300));
    mostrarAviso(`conta ${conta}: documento salvo; clicando em "${TEXTO_VOLTAR}" para continuar a análise…`);
    await clicarNoQuadro('voltarPdf', `botão "${TEXTO_VOLTAR}" da página do PDF`, 'clicar', {
      antesDoClique: async () => { a.baixando = null; await gravarEstado(); },
    });
    await esperar(async () => !await pedirAoQuadro('achar', 'paginaPdf'), 'a saída da página do PDF', TIMEOUT_REGULARIZE_MS);
  }

  // Endereço que pode ser baixado direto: https, sem "#" no fim, e que não seja a página aberta agora (nem outra página
  // .jsf/.xhtml do sistema, que devolvem HTML).
  function enderecoDeArquivo(href) {
    let u;
    try { u = new URL(href || '', location.href); } catch (_) { return false; }
    if (u.protocol !== 'https:' || /#$/.test(href || '') || /^javascript:/i.test(href || '')) return false;
    if (u.origin === location.origin && u.pathname === location.pathname) return false;
    return !/\.(jsf|xhtml|html?|faces)$/i.test(u.pathname);
  }

  // ------------------------------- salvamento do PDF (rotina única) -------------------------------
  // Todo PDF de prestação passa por aqui: espera o download, cuida da janela "Salvar como" (ajudante do Windows, com
  // tentativas e fechamento controlado), confere no disco e só então registra. Cada passo vai para o log com CNPJ, conta,
  // prestação e arquivo. Nunca recarrega a página com a janela "Salvar como" aberta (na página do PDF nem recarrega: o
  // recarregamento reenviaria a emissão).
  const numeroDoDocumento = (t) => { const d = String(t || '').replace(/\D/g, ''); return d.length >= 6 && d.length <= 30 ? d : ''; };
  const rotuloSalvamento = (conta, b) => `[salvamento] CNPJ ${estado.cnpj || '?'}, conta ${conta}, prestação ${b.prest}, arquivo "${b.nome}.pdf"`;

  // O resultado do download é mesmo o PDF desta prestação, na pasta do CNPJ, íntegro no disco? Devolve o problema ou null.
  async function validarSalvo(r, b) {
    let problema = !r.ok ? r.erro
      : !/\.pdf$/i.test(r.caminho || '') ? `o arquivo baixado não é PDF (${r.caminho})`
      : r.bytes === 0 ? `o PDF baixado está vazio (${r.caminho})`
      // a pasta final tem que ser a do CNPJ (na janela "Salvar como" alguém poderia ter trocado)
      : !`\\${String(r.caminho).replace(/\//g, '\\')}`.toLowerCase().includes(`\\${b.pasta.replace(/\//g, '\\')}\\`.toLowerCase())
        ? `o PDF foi salvo fora da pasta do CNPJ (${r.caminho})` : null;
    // o arquivo tem que ser DESTE documento: nome pedido (ou com "(1)") ou o número do documento. Em 09/11/2026 o
    // "documento" registrado era o print de outra conta (mesmo número de download em dois perfis do Chrome).
    let outroArquivo = false;
    if (!problema) {
      const arq = String(r.caminho).split(/[\\/]/).pop().toLowerCase();
      if (!arq.startsWith(b.nome.toLowerCase()) && !(b.numero && arq.includes(String(b.numero).toLowerCase()))) {
        // 0.35.0: arquivo de OUTRA coisa (print de confirmação, relatório, outra prestação) tomado pelo download: o
        // documento pode nem ter sido baixado ainda. Nunca vale como documento; pode tentar de novo (depois de procurar
        // o documento no disco, para não duplicar).
        outroArquivo = true;
        const tipo = /^(print_confirmacao|sem_|caixa_postal|erro_500|problema_receita|falha_salvamento)/.test(arq) ? 'é um print de conferência, '
          : /relatorio/.test(arq) ? 'é um relatório, ' : '';
        problema = `o arquivo salvo (${arq}) não é o documento desta prestação${tipo ? ` (${tipo.replace(/, $/, '')})` : ''}`;
      }
    }
    // existência e integridade no disco (o ajudante do Windows lê o arquivo: existe e começa com "%PDF")
    let disco = null;
    if (!problema) {
      disco = await mensagem({ tipo: 'conferir-arquivo', caminho: r.caminho });
      if (disco && disco.ok && !disco.existe) problema = `o Chrome disse que salvou, mas o arquivo não está no disco (${r.caminho})`;
      else if (disco && disco.ok && !disco.pdf) problema = `o arquivo salvo não é um PDF válido (${r.caminho})`;
      else if (disco && disco.ok && !disco.bytes) problema = `o PDF salvo está vazio (${r.caminho})`;
    }
    return { problema, disco, outroArquivo };
  }

  // 0.35.0 — O PDF desta prestação já está na pasta do CNPJ (salvo com o nome pedido ou com o número do documento), mesmo
  // que o Chrome não tenha avisado? Só arquivos gravados depois do início desta prestação e que ainda não foram usados
  // por outra prestação. Devolve um resultado no formato do download ({ ok, caminho, bytes }) ou null.
  async function acharDocumentoNoDisco(b) {
    const p = await mensagem({ tipo: 'procurar-documento', pasta: b.pasta, nome: b.nome, numero: b.numero || '', desde: b.t || 0 });
    if (!p || !p.ok || !p.achou || !p.caminho) return null;
    const usados = Object.values(estado.baixados || {}).map((x) => String(x).toLowerCase());
    if (usados.includes(String(p.caminho).toLowerCase())) return null;
    return { ok: true, caminho: p.caminho, bytes: p.bytes, doDisco: true };
  }

  // PDF conferido: registra (estado, registro permanente, relatório) e libera o "Voltar".
  async function registrarSalvo(a, conta, r, disco, obsExtra) {
    const b = a.baixando;
    const reg = a.linhas[b.prest];
    estado.baixados[b.chave] = r.caminho;
    if (b.chaveReg) await mensagem({ tipo: 'registro-gravar', chave: b.chaveReg, arquivo: r.caminho });
    if (reg) {
      reg.r = 'pendente-baixado'; reg.arquivo = r.caminho;
      reg.obs = [b.numero ? `documento ${b.numero}` : reg.obs, obsExtra].filter(Boolean).join('; ');
    }
    b.fase = 'voltar';
    estado.retomadas = 0;
    await gravarEstado();
    log(`${rotuloSalvamento(conta, b)}: PDF salvo: ${r.caminho}` + (disco && disco.ok ? ` (conferido no disco: ${disco.bytes} bytes, PDF válido)`
      : ' (sem o ajudante do Windows: conferido só pelo Chrome)') + (obsExtra ? ` — ${obsExtra}` : ''));
    mostrarAviso(`conta ${conta}: PDF da prestação ${b.prest} salvo:\n${r.caminho}`);
    await sleep(rand(700, 1300));
  }

  // Antes de clicar de novo no link: o PDF da tentativa anterior chegou mesmo assim? (evita documento repetido)
  async function conferirSalvoAtrasado(a, conta) {
    const b = a.baixando;
    const st = await mensagem({ tipo: 'download-status', chave: b.chave });
    if (st && st.ok) {
      const { problema, disco } = await validarSalvo(st, b);
      if (!problema) {
        await registrarSalvo(a, conta, st, disco, 'salvo na tentativa anterior (aviso de fim atrasado)');
        return true;
      }
    }
    // 0.35.0: o Chrome não associou (ou associou o arquivo errado), mas o documento pode estar no disco
    const noDisco = await acharDocumentoNoDisco(b);
    if (!noDisco) return false;
    const { problema, disco } = await validarSalvo(noDisco, b);
    if (problema) return false;
    await registrarSalvo(a, conta, noDisco, disco, 'encontrado na pasta do CNPJ (o Chrome não confirmou o download)');
    return true;
  }

  // Espera o PDF clicado chegar e confere que foi salvo (download do site, aba nova ou janela bloqueada).
  async function concluirDownload(a, conta) {
    const b = a.baixando;
    const reg = a.linhas[b.prest];
    const rot = rotuloSalvamento(conta, b);
    let r = null;
    let pediuUrl = false;
    let procurouEm = 0;
    const inicio = b.tLink || b.t;
    let avisouSalvarComo = false;
    let avisoSalvarComo = '';
    let limite = ESPERA_DOCUMENTO_MS;
    let fecharJanela = ''; // motivo para fechar a janela "Salvar como" de forma controlada
    let corrigido = '';
    try {
      r = await esperar(async () => {
        const st = await mensagem({ tipo: 'download-status', chave: b.chave });
        if (st && (st.ok || st.ok === false)) return st;
        if (Date.now() - inicio > limite) throw Object.assign(new Error('tempo esgotado'), { tempoEsgotado: true });
        // Janela "Salvar como" aberta (opção "Perguntar onde salvar cada arquivo" ligada): o ajudante do Windows confere
        // a pasta do CNPJ, coloca o nome certo se precisar e clica em "Salvar" (até 3 vezes). Se não conseguir, a janela
        // é fechada de forma controlada e o link do PDF é clicado de novo (tratarPaginaPdf).
        if (st && (st.aguardandoSalvar || ['chamando', 'falhou', 'esgotado'].includes(st.ajudante))) {
          if (!avisouSalvarComo) {
            avisouSalvarComo = true;
            limite = Date.now() - inicio + ESPERA_SALVAR_COMO_MS;
            log(`${rot}: o Chrome abriu a janela "Salvar como"; chamando o ajudante do Windows`);
          }
          const resp = st.ajudanteResposta || {};
          if (resp.corrigido) corrigido = resp.corrigido;
          const situacao = `${st.ajudante || ''}|${st.ajudanteTentativas || 0}|${resp.erro || ''}`;
          if (situacao !== avisoSalvarComo) {
            avisoSalvarComo = situacao;
            if (st.ajudante === 'falhou') {
              log(`${rot}: ajudante, tentativa ${st.ajudanteTentativas}: ${resp.erro || 'sem resposta'}; tentando de novo`);
              await informarOrq('em_andamento', `salvamento: conta ${conta}, prestação ${b.prest}: janela "Salvar como" não confirmada (${resp.erro || 'sem resposta'}); tentativa ${st.ajudanteTentativas + 1}`);
            }
            mostrarAviso(`conta ${conta}, prestação ${b.prest}: o Chrome abriu a janela "Salvar como".\n` +
              (st.ajudante === 'falhou' ? `O ajudante não confirmou (${resp.erro || 'sem resposta'}); tentando de novo…`
                : `Conferindo a pasta do CNPJ e o nome e clicando em "Salvar"${st.ajudanteTentativas > 1 ? ` (tentativa ${st.ajudanteTentativas})` : ''}…`));
          }
          if (st.ajudante === 'esgotado') {
            fecharJanela = resp.semAjudante
              ? 'o ajudante do Windows não está instalado (rode Instalar.bat na pasta ATM_PGFN) e a janela "Salvar como" ficou aberta'
              : `o ajudante não conseguiu confirmar a janela "Salvar como" (${resp.erro || 'sem resposta'})`;
            return { fechar: true };
          }
          return null;
        }
        if (pediuUrl || (st && st.iniciado)) return null;
        // nenhum download associado a esta prestação: procura o download do site que começou depois do clique
        if (Date.now() - inicio > PROCURAR_DOWNLOAD_APOS_MS && Date.now() - procurouEm > 5000) {
          procurouEm = Date.now();
          const p = await mensagem({ tipo: 'download-procurar', chave: b.chave, desde: inicio, numero: b.numero || '' });
          if (p && p.achou && !p.jaAssociado) log(`${rot}: download do site achado sem o nome sugerido; seguindo com ele`);
          if (p && p.achou) return null;
        }
        // o site tentou abrir o PDF numa janela que o Chrome bloqueou: baixa o mesmo endereço
        let url = aberturaCapturada && aberturaCapturada.bloqueada && aberturaCapturada.url;
        // o link é o endereço de OUTRO arquivo e nada chegou em 8 s: baixa esse endereço. Nunca a própria página: o link
        // do PDF é "#" (o endereço vira ".../resultadoDarfInternet.jsf#"), e baixar isso salvou a página em HTML
        // (".htm") no lugar do PDF em 06/11/2026.
        if (!url && Date.now() - inicio > 8000 && enderecoDeArquivo(b.href)) url = b.href;
        if (url) {
          pediuUrl = true;
          log(`baixando o endereço do PDF: ${url.split('?')[0]}`);
          await mensagem({ tipo: 'download-url', chave: b.chave, url, pasta: b.pasta, nome: b.nome });
        }
        return null;
      }, `o PDF da prestação ${b.prest}`, ESPERA_SALVAR_COMO_MS + ESPERA_DOCUMENTO_MS);
    } catch (e) {
      if (!e.tempoEsgotado) throw e;
    }
    if (r && r.fechar) r = null;
    if (!r && avisouSalvarComo && !fecharJanela) fecharJanela = `a janela "Salvar como" ficou aberta sem resposta por ${Math.round(ESPERA_SALVAR_COMO_MS / 1000)} s`;
    if (fecharJanela) {
      // fecha só a janela deste documento (botão "Cancelar"), nunca recarrega com ela aberta
      log(`${rot}: ${fecharJanela}; fechando a janela "Salvar como" de forma controlada`);
      mostrarAviso(`conta ${conta}, prestação ${b.prest}: ${fecharJanela}.\nFechando a janela "Salvar como" para tentar de novo…`, 'erro');
      const f = await mensagem({ tipo: 'download-fechar-janela', chave: b.chave });
      log(`${rot}: fechar a janela: ${JSON.stringify(f)}`);
      await sleep(1500);
      // ao fechar, o download pode ter terminado (ex.: alguém clicou em "Salvar" no último instante)
      const st = await mensagem({ tipo: 'download-status', chave: b.chave });
      if (st && st.ok) r = st;
    }
    // confirmação: download completo, arquivo .pdf deste documento, na pasta do CNPJ, íntegro no disco
    let problema = null, disco = null, outroArquivo = false;
    if (!r) {
      problema = fecharJanela ? `${fecharJanela}; fechei a janela`
        : `cliquei no link do PDF e nenhum download chegou em ${Math.round(ESPERA_DOCUMENTO_MS / 1000)} s`;
    } else {
      ({ problema, disco, outroArquivo } = await validarSalvo(r, b));
    }
    if (problema) {
      await mensagem({ tipo: 'download-cancelar' });
      if (reg) { reg.r = 'pendente-sem-documento'; reg.obs = problema; }
      await gravarEstado();
      log(`${rot}: NÃO salvo: ${problema}`);
      const erro = new Error(`conta ${conta}, prestação ${b.prest}: ${problema}. Não cliquei de novo, para não baixar documento repetido`);
      // pode tentar o link de novo (o documento já foi emitido; o link só baixa o mesmo PDF), menos quando um arquivo
      // foi salvo em outro lugar ou com outro nome (repetir criaria duplicata): aí é pausa para você conferir
      // 0.35.0: arquivo de outra coisa tomado pelo download (ex.: o print da conta anterior) também pode repetir: o
      // documento não foi salvo por causa disso (antes de repetir, o disco é conferido para não duplicar)
      erro.repetivel = !(r && r.ok) || outroArquivo || !!(disco && disco.ok && (!disco.pdf || !disco.bytes));
      erro.motivo = problema;
      throw erro;
    }
    await registrarSalvo(a, conta, r, disco, corrigido ? `nome/pasta corrigidos na janela "Salvar como"` : '');
  }

  // 0.35.0 — Tentativas esgotadas COM o orquestrador: não fica pausado. Fecha só a janela "Salvar como" deste documento
  // (se houver), desarma a espera do download, salva um print de evidência, registra conta/prestação/motivo e lança um
  // erro DEFINITIVO: o CNPJ fica como "erro" (pendente; refeito na próxima execução, sem repetir os PDFs já salvos, que
  // estão no registro), o relatório parcial é salvo, a sessão do e-CAC é encerrada ("Sair com Segurança") e o
  // orquestrador fecha o Chrome e segue para o próximo CNPJ.
  async function desistirDoSalvamento(a, conta, motivo, tentativas) {
    const b = a.baixando;
    const cnpj = estado.cnpj || (ORQ && ORQ.cnpj) || '';
    const rot = rotuloSalvamento(conta, b);
    log(`${rot}: FALHA DE SALVAMENTO depois de ${tentativas} tentativa(s): ${motivo}; encerrando este CNPJ`);
    mostrarAviso(`conta ${conta}, prestação ${b.prest}: o PDF não foi salvo depois de ${tentativas} tentativa(s) (${motivo}).\n` +
      'Salvando a evidência e encerrando este CNPJ; a automação segue para o próximo. Ele fica pendente para a próxima execução.', 'erro');
    // a última chance: o documento chegou ao disco enquanto isso? (nunca descarta um PDF salvo)
    if (await conferirSalvoAtrasado(a, conta)) return;
    try { await mensagem({ tipo: 'download-fechar-janela', chave: b.chave }); } catch (_) { /* sem janela */ }
    try { await mensagem({ tipo: 'download-cancelar' }); } catch (_) { /* nada armado */ }
    let evidencia = '';
    try {
      evidencia = await salvarPrintEmPdf(await pastaDoCliente(), `Falha_Salvamento_${cnpj}_conta_${semZeros(conta)}_prest_${b.prest}.pdf`);
    } catch (x) {
      evidencia = `NÃO SALVA (${x.message})`;
    }
    const reg = a.linhas && a.linhas[b.prest];
    if (reg) { reg.r = 'pendente-sem-documento'; reg.obs = `falha de salvamento depois de ${tentativas} tentativa(s): ${motivo}`; }
    estado.falhasSalvamento = estado.falhasSalvamento || [];
    estado.falhasSalvamento.push({ conta, prest: b.prest, motivo, tentativas, evidencia, t: Date.now() });
    a.baixando = null; // não retomar esta página do PDF: o CNPJ será refeito do início na próxima execução
    await gravarEstado();
    log(`${rot}: evidência: ${evidencia}`);
    throw Object.assign(new Error(`[falha_salvamento] conta ${conta}, prestação ${b.prest}: o PDF não foi salvo depois de ` +
      `${tentativas} tentativa(s) (${motivo}). Evidência: ${evidencia}. O CNPJ fica pendente para a próxima execução; ` +
      'os documentos já salvos foram mantidos e não serão emitidos de novo'), { definitivo: true });
  }

  // Tentativas esgotadas: PAUSA (sem prazo; o orquestrador sabe). Você clica no link do PDF e salva; a automação
  // continua cuidando da janela "Salvar como" e só segue com o PDF conferido no disco.
  async function aguardarSalvamentoManual(a, conta, motivo, tentativas) {
    const b = a.baixando;
    const pasta = b.pasta.split('/').pop();
    const texto = `conta ${conta}, prestação ${b.prest}: o PDF não foi salvo depois de ${tentativas} tentativa(s) (${motivo}). ` +
      `Clique no link do PDF ${b.numero || ''} e salve na pasta ${pasta} com o nome "${b.nome}". ` +
      'A automação confere o arquivo no disco e continua sozinha. Não clique em "Voltar" nem em "Emitir" de novo.';
    log(`${rotuloSalvamento(conta, b)}: PAUSA para salvar à mão: ${motivo}`);
    mostrarAviso(`PAUSA: ${texto}`, 'erro');
    await informarOrq('aguardando_humano', texto);
    let preparadoEm = 0, ultimoAviso = Date.now(), procurouEm = 0, inicio = Date.now();
    for (;;) {
      conferirCancelado();
      if (!preparadoEm) { // espera armada para o seu clique (o nome e a pasta certos vêm sugeridos)
        await mensagem({ tipo: 'download-limpar', chave: b.chave });
        await mensagem({ tipo: 'download-preparar', chave: b.chave, pasta: b.pasta, nome: b.nome, numero: b.numero || '', validadeMs: 24 * 3600000 });
        preparadoEm = inicio = Date.now();
      }
      await sleep(1500);
      const st = await mensagem({ tipo: 'download-status', chave: b.chave });
      if (st && st.ok) {
        const { problema, disco } = await validarSalvo(st, b);
        if (!problema) {
          await registrarSalvo(a, conta, st, disco, 'salvo durante a pausa para intervenção');
          await informarOrq('em_andamento', `salvamento: conta ${conta}, prestação ${b.prest}: PDF salvo e conferido; continuando`);
          return;
        }
        log(`${rotuloSalvamento(conta, b)}: na pausa: ${problema}`);
        mostrarAviso(`PAUSA: ${texto}\nÚltima tentativa: ${problema}`, 'erro');
        preparadoEm = 0;
      } else if (st && st.ok === false) {
        preparadoEm = 0; // cancelado ou interrompido: prepara de novo para o próximo clique
      } else if (!(st && st.iniciado) && Date.now() - inicio > PROCURAR_DOWNLOAD_APOS_MS && Date.now() - procurouEm > 5000) {
        procurouEm = Date.now();
        await mensagem({ tipo: 'download-procurar', chave: b.chave, desde: inicio, numero: b.numero || '' });
      }
      if (Date.now() - ultimoAviso >= 60000) {
        ultimoAviso = Date.now();
        await informarOrq('aguardando_humano', texto);
        await gravarEstado();
      }
    }
  }

  // Relatório da execução (.csv, abre no Excel): uma linha por prestação conferida, com o resultado.
  async function salvarRelatorio(parcial) {
    const analises = estado.analises || {};
    if (!Object.keys(analises).length) return null;
    const ROTULO = { regular: 'regular (verificado)', 'pendente-baixado': 'PENDENTE - documento baixado',
      'pendente-sem-documento': 'PENDENTE - documento NÃO baixado', 'sem-acao': 'sem ícone', desconhecido: 'VERIFICAR - ícone desconhecido',
      futura: 'futura (não conferida)', 'ja-emitido': 'já emitido (ícone laranja) - não emitido de novo' };
    const cel = (v) => `"${String(v == null ? '' : v).replace(/"/g, '""')}"`;
    const base = await baseDoNome();
    const [cnpj, ...resto] = base.split(';');
    const linhas = [['CNPJ', 'Cliente', 'Conta', 'Nr. Prestação', 'Competência', 'Vencimento', 'Valor originário',
      'Saldo devedor', 'Ícone Emissão', 'Resultado', 'Arquivo', 'Observação', 'Situação na tela final'].map(cel).join(';')];
    for (const [conta, an] of Object.entries(analises)) {
      for (const l of Object.values(an.linhas || {})) {
        linhas.push([cnpj, resto.join(';'), conta, l.prest, l.comp, l.venc, l.valor, l.saldo, l.icone,
          ROTULO[l.r] || l.r, l.arquivo || '', l.obs, l.final || ''].map(cel).join(';'));
      }
    }
    const d = new Date();
    const p2 = (n) => String(n).padStart(2, '0');
    const quando = `${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())} ${p2(d.getHours())}h${p2(d.getMinutes())}`;
    const nome = `${base};relatorio ${quando}${parcial ? ' (parcial)' : ''}.csv`;
    const r = await mensagem({ tipo: 'salvar-texto', pasta: await pastaDoCliente(), nome, texto: linhas.join('\r\n') });
    if (!r || !r.ok) throw new Error((r && r.erro) || 'sem resposta da extensão');
    return r.caminho;
  }

  // Nome do arquivo: "CNPJ;NOME DA EMPRESA.pdf". O nome vem do topo do e-CAC (guardado na troca de perfil) ou, se a
  // automação começou já no Regularize, da linha "Usuário: CNPJ - NOME" da tela da PGFN.
  async function nomeDoArquivo() {
    return `${await baseDoNome()}.pdf`;
  }

  // "CNPJ;NOME DA EMPRESA", sem extensão (base de todos os arquivos do cliente).
  async function baseDoNome() {
    const separar = (texto) => {
      const m = /([\d./-]{14,18})\s*-\s*(.+)$/.exec((texto || '').replace(/\s+/g, ' ').trim());
      return m ? { cnpj: soDigitos(m[1]), nome: m[2].trim() } : {};
    };
    let cnpj = estado.cnpj;
    let empresa = estado.empresa || separar(estado.confirmado).nome;
    if (!cnpj || !empresa) {
      const usuario = await pedirAoQuadro('achar', 'usuario');
      const lido = separar(usuario && usuario.texto && usuario.texto.replace(/^.*?usu[aá]rio:\s*/i, ''));
      cnpj = cnpj || lido.cnpj;
      empresa = empresa || lido.nome;
    }
    const limpo = (empresa || 'EMPRESA NAO IDENTIFICADA')
      .replace(/[\\/:*?"<>|\x00-\x1f]/g, ' ').replace(/\s+/g, ' ').trim()
      .slice(0, 150).replace(/[.\s]+$/, ''); // sem ponto no fim: "S.A." viraria "S.A..pdf"
    return `${cnpj || 'cnpj-desconhecido'};${limpo}`;
  }

  // Print da parte visível da aba (sem o aviso e sem a seta, que não são da página), salvo em PDF.
  // ---- conferência final e print de confirmação (tela "Prestação" de cada negociação) ----
  const dataDe = (s) => { const m = /(\d{2})\/(\d{2})\/(\d{4})/.exec(s || ''); return m ? new Date(Number(m[3]), Number(m[2]) - 1, Number(m[1])) : null; };
  const hojeSemHora = () => { const d = new Date(); d.setHours(0, 0, 0, 0); return d; };

  // Lê de novo a tabela, já com a página recarregada pelo site depois das emissões, e decide pelo que o SISTEMA mostra
  // (não pelo clique): até o mês atual, cada prestação está "verificada", tem documento válido (vencimento do documento
  // de hoje em diante) ou continua PENDENTE. Depois tira o print da página inteira.
  async function confirmarSituacaoFinal(conta) {
    const a = estado.analises[conta];
    if (a.printConfirmacao) return; // já feito (a página recarregou depois do print)
    mostrarAviso(`conta ${conta}: conferência final da tela "Prestação"…`);
    await esperar(() => document.readyState === 'complete', 'o fim do carregamento da página');
    const leitura = await esperar(async () => {
      const t = await pedirAoQuadro('ler', 'prestacoes');
      return t && t.linhas && t.linhas.length ? t : null;
    }, 'a tabela "Prestação"', TIMEOUT_REGULARIZE_MS);
    await sleep(rand(800, 1300)); // dados na tela assentados
    const atual = agoraIndice();
    const hoje = hojeSemHora();
    const final = { verificadas: 0, comDocumento: 0, pendentes: [], futuras: 0 };
    for (const l of leitura.linhas) {
      const comp = competenciaDe(l.venc);
      const reg = a.linhas[l.prest];
      let situacao;
      if (!comp || indiceMes(comp.mes, comp.ano) > atual) { final.futuras++; situacao = 'futura'; }
      else if (l.icone === 'verificado') { final.verificadas++; situacao = 'verificado'; }
      else if (dataDe(l.vencDoc) && dataDe(l.vencDoc) >= hoje && (l.docCob || l.icone === 'emitido' || reg && reg.r === 'pendente-baixado')) {
        final.comDocumento++;
        situacao = `${l.icone === 'emitido' ? 'já emitido (ícone laranja): ' : ''}documento ${l.docCob || 'emitido'} válido até ${l.vencDoc}`;
      } else {
        final.pendentes.push(l.prest);
        situacao = l.icone === 'emitido' && dataDe(l.vencDoc)
          ? `PENDENTE na tela final: documento ${l.docCob || ''} emitido, mas venceu em ${l.vencDoc}` : 'PENDENTE na tela final';
      }
      if (reg) reg.final = situacao;
    }
    a.final = { ...final, data: new Date().toLocaleString('pt-BR') };
    log(`conta ${conta}: conferência final: ${final.verificadas} verificadas, ${final.comDocumento} com documento válido, ` +
      `${final.pendentes.length} pendentes (${final.pendentes.join(', ') || '-'}), ${final.futuras} futuras`);
    await gravarEstado();

    // print da página inteira (em partes, de cima para baixo), sem a seta, o aviso e a faixa de cookies
    const pasta = await pastaDoCliente();
    const nome = (estado.deferidas || []).length > 1 ? `print_confirmacao_conta_${semZeros(conta)}.pdf` : 'print_confirmacao.pdf';
    // retomada (Chrome reaberto depois de um travamento): o mesmo print, do mesmo dia e com a mesma situação na tela, não
    // é salvo de novo (antes ficava "print_confirmacao (1).pdf"). Situação diferente = print novo.
    const chavePrint = `print|${pasta}/${nome}|${hojeIso()}|${final.verificadas}|${final.comDocumento}|${final.pendentes.join(',')}`;
    const jaPrint = await printJaSalvo(chavePrint);
    if (jaPrint) {
      a.printConfirmacao = jaPrint;
      await gravarEstado();
      log(`conta ${conta}: print de confirmação já salvo hoje com a mesma situação (${jaPrint}); não salvei de novo`);
      mostrarAviso(`conta ${conta}: print de confirmação já salvo hoje (mesma situação):\n${jaPrint}`, final.pendentes.length ? 'erro' : 'ok');
      await sleep(rand(800, 1300));
      return;
    }
    mostrarAviso(`conta ${conta}: tirando o print de confirmação (${nome})…`);
    await rolarAteOTopo();
    const caixa = document.getElementById(ID_AVISO);
    let r;
    try {
      if (caixa) caixa.style.visibility = 'hidden';
      if (cursor.el) cursor.el.style.visibility = 'hidden';
      await pedirAoQuadro('rodape', 'pagina', { esconder: true });
      await mensagem({ tipo: 'print-inicio' });
      for (let parte = 0; parte < 60; parte++) {
        await sleep(650); // redesenho da tela (e o limite do Chrome: 2 prints por segundo)
        const p = await pedirAoQuadro('ler', 'pagina');
        const ok = await mensagem({ tipo: 'print-parte', y: p.topo, util: p.util, janela: p.janela });
        if (!ok || !ok.ok) throw new Error(`não consegui fotografar a tela: ${(ok && ok.erro) || 'sem resposta da extensão'}`);
        if (p.topo + p.util >= p.altura - 1) break;
        await pedirAoQuadro('irPara', 'pagina', { y: p.topo + p.util });
      }
      r = await mensagem({ tipo: 'print-salvar', pasta, nome });
    } finally {
      await pedirAoQuadro('rodape', 'pagina', { esconder: false });
      if (caixa) caixa.style.visibility = '';
      if (cursor.el) cursor.el.style.visibility = '';
    }
    if (!r || !r.ok) throw new Error(`não consegui salvar o ${nome}: ${(r && r.erro) || 'sem resposta da extensão'}`);
    a.printConfirmacao = r.caminho;
    await mensagem({ tipo: 'registro-gravar', chave: chavePrint, arquivo: r.caminho });
    await gravarEstado();
    mostrarAviso(`conta ${conta}: ${final.pendentes.length ? `ATENÇÃO: ${final.pendentes.length} prestação(ões) ainda pendente(s) na tela` : 'nenhuma pendência na tela'} ` +
      `até ${competenciaAtual()}.\nPrint de confirmação: ${r.caminho}`, final.pendentes.length ? 'erro' : 'ok');
    await sleep(rand(1500, 2500));
  }

  // CNPJ terminado (sem parcelamento, sem deferida ou com as negociações analisadas): passa ao próximo da lista na aba do
  // e-CAC. Sem próximo (ou sem a aba do e-CAC), só encerra.
  async function seguirParaProximoCnpj() {
    if (estado.continuouEmAba) return;
    estado.cnpjFinalizado = true; // este CNPJ terminou (o orquestrador é avisado no fim da execução)
    const concluidos = [...new Set([...(estado.concluidos || []), estado.cnpj].filter(Boolean))];
    const proximo = LISTA_CNPJS.find((c) => !concluidos.includes(c));
    if (!proximo) {
      if (LISTA_CNPJS.length > 1) estado.fim += `\nTodos os ${LISTA_CNPJS.length} CNPJs da lista terminados.`;
      return;
    }
    if (!estado.abaEcac) {
      estado.fim += `\nPróximo da lista: ${formatarCnpj(proximo)}, mas não sei qual é a aba do e-CAC: comece por ela.`;
      return;
    }
    mostrarAviso(`${estado.fim}\n\nSeguindo com o próximo CNPJ (${formatarCnpj(proximo)}) na aba do e-CAC…`, 'ok');
    await sleep(rand(3000, 4500)); // dá tempo de ler o resultado deste CNPJ
    const ok = await mensagem({ tipo: 'proximo-cnpj', cnpj: proximo, concluidos, abaEcac: estado.abaEcac, abaRegularize: estado.abaRegularize });
    estado.fim += ok ? `\nSeguindo com ${formatarCnpj(proximo)} na aba do e-CAC.`
      : `\nNão consegui voltar à aba do e-CAC para o próximo (${formatarCnpj(proximo)}).`;
  }

  // Nenhuma "DEFERIDA E CONSOLIDADA": print da lista (página carregada, tabela no alto da tela) em
  // Documentos_arrecadacao/<CNPJ>/Sem_Deferido_<CNPJ>.pdf. Confere antes que a página é do CNPJ em processamento.
  async function salvarSemDeferido() {
    mostrarAviso(`nenhuma negociação "${TEXTO_DEFERIDA}": conferindo a tela antes do print…`);
    await esperar(() => document.readyState === 'complete', 'o fim do carregamento da página');
    await esperar(async () => { const t = await pedirAoQuadro('ler', 'situacoes'); return t && t.valores && t.valores.length; },
      'a tabela de negociações', TIMEOUT_ELEMENTO_MS);
    const cnpj = (await baseDoNome()).split(';')[0];
    const usuario = await pedirAoQuadro('achar', 'usuario');
    const naTela = usuario && soDigitos((/([\d./-]{18})/.exec(usuario.texto || '') || [])[1] || '');
    if (naTela && naTela !== cnpj) {
      throw new Error(`a tela é do CNPJ ${formatarCnpj(naTela)}, mas o CNPJ em processamento é ${formatarCnpj(cnpj)}. Não salvei o print`);
    }
    await rolarAteOTopo(); // a tabela inteira visível, acima do aviso de cookies
    await sleep(rand(800, 1300)); // deixa a tela assentar antes do print
    mostrarAviso('salvando o print da tela em PDF…');
    return salvarPrintEmPdf(await pastaDoCliente(), `Sem_Deferido_${cnpj}.pdf`);
  }

  // Data de hoje "AAAA-MM-DD" (chave dos prints já salvos no dia).
  function hojeIso() { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; }
  // Print já salvo (registro) E ainda no disco? Devolve o caminho; senão null (salva de novo).
  async function printJaSalvo(chave) {
    const ja = await mensagem({ tipo: 'registro-ver', chave });
    if (!ja || !ja.arquivo) return null;
    const disco = await mensagem({ tipo: 'conferir-arquivo', caminho: ja.arquivo });
    return disco && disco.ok && disco.existe && disco.pdf ? ja.arquivo : null;
  }

  async function salvarPrintEmPdf(pasta, nomeFixo) {
    const nome = nomeFixo || await nomeDoArquivo();
    // retomada no mesmo dia: o mesmo print (mesmo nome, mesma pasta) não é salvo de novo (evita "Sem_Deferido_... (1).pdf")
    const chavePrint = `print|${pasta}/${nome}|${hojeIso()}`;
    const jaPrint = await printJaSalvo(chavePrint);
    if (jaPrint) { log(`print ${nome} já salvo hoje (${jaPrint}); não salvei de novo`); return jaPrint; }
    const caixa = document.getElementById(ID_AVISO);
    if (caixa) caixa.style.visibility = 'hidden';
    if (cursor.el) cursor.el.style.visibility = 'hidden';
    let r;
    try {
      await sleep(400); // deixa a tela redesenhar sem a seta e o aviso
      r = await mensagem({ tipo: 'capturar', pasta, nome });
    } finally {
      if (caixa) caixa.style.visibility = '';
      if (cursor.el) cursor.el.style.visibility = '';
    }
    if (!r || !r.ok) throw new Error(`não consegui salvar o PDF: ${(r && r.erro) || 'sem resposta da extensão'}`);
    await mensagem({ tipo: 'registro-gravar', chave: chavePrint, arquivo: r.caminho });
    return r.nomeAjustado ? `${r.caminho}\n(o Chrome não aceitou ";" no nome; salvei com "_")` : r.caminho;
  }

  // "Você não tem permissão de acesso ou ele expirou": a sessão do quadro da PGFN se perdeu. A causa mais provável é a
  // janela anônima, que bloqueia os cookies de terceiros (o quadro é de outro domínio, pgfn.fazenda.gov.br).
  // 0.36.0 — com o orquestrador: o acesso ao SISPAR expirou/foi perdido. Recarregar ou repetir na mesma página não
  // resolve (o próprio site diz: feche o navegador e volte ao Regularize). O erro sai com a marca "[sessao_pgfn]": o
  // orquestrador encerra a sessão do e-CAC ("Sair com Segurança"), fecha o Chrome da automação e refaz o MESMO CNPJ
  // (até 3 vezes; PDFs já salvos não são emitidos de novo). Persistindo, o CNPJ fica pendente e a fila segue.
  async function erroSemPermissao() {
    if (ORQ) {
      const b = estado && estado.contaAtual && (estado.analises || {})[estado.contaAtual] && estado.analises[estado.contaAtual].baixando;
      const onde = [`certificado ${ORQ.certificado || '?'}`, `CNPJ ${formatarCnpj(ORQ.cnpj || estado.cnpj || '')}`,
        estado && estado.contaAtual ? `conta ${estado.contaAtual}` : '', b && b.prest ? `prestação ${b.prest}` : '',
        `etapa "${ETAPAS[estado.etapa] ? ETAPAS[estado.etapa].nome : '?'}"`, `página ${location.pathname.split('/').pop()}`].filter(Boolean).join(', ');
      log(`[sessao_pgfn] o site da PGFN respondeu "${TEXTO_SEM_PERMISSAO}" (${onde})`);
      // o aviso vai ao orquestrador como progresso: é o checkpoint (conta/parcela) antes da recuperação
      mostrarAviso(`O SISPAR respondeu "${TEXTO_SEM_PERMISSAO}" (${onde}).\n` +
        'Encerrando a sessão e reabrindo o Chrome para refazer este mesmo CNPJ (os PDFs já salvos não são emitidos de novo)…', 'erro');
      await gravarEstado();
      return Object.assign(new Error(`[sessao_pgfn] o site da PGFN respondeu "${TEXTO_SEM_PERMISSAO}" (${onde}); ` +
        'o acesso ao SISPAR expirou ou foi perdido: refazendo o mesmo CNPJ com o Chrome reaberto'), { definitivo: true, sessaoPgfn: true });
    }
    const aba = await mensagem({ tipo: 'aba-info' });
    const dica = aba && aba.anonima
      ? 'Esta é uma janela ANÔNIMA: ela bloqueia os cookies de terceiros que o quadro da PGFN usa. ' +
        'Rode numa janela normal, ou permita cookies de terceiros neste site (ícone do olho riscado na barra de endereço)'
      : 'Confira se o Chrome está bloqueando cookies de terceiros neste site (ícone do olho riscado na barra de endereço)';
    const quem = estado.cliqueManual
      ? '\nDIAGNÓSTICO: o clique foi SEU (manual), então o acesso já estava inválido antes dele'
      : (estado.infoDoc ? `\nDIAGNÓSTICO: o clique foi da automação, no link: ${estado.infoDoc}` : '');
    return new Error(`o site da PGFN respondeu "${TEXTO_SEM_PERMISSAO}". ${dica}. Depois feche esta janela do Regularize e comece de novo${quem}`);
  }

  async function verificarResultado() {
    if (estado.continuouEmAba) return; // no Regularize: o trabalho seguiu na aba nova do SISPAR
    if (!estado.cliqueManual) mostrarAviso('aguardando a tela de emissão carregar…');
    const tela = await esperar(async () => (await pedirAoQuadro('achar', 'semPermissao') && 'sem permissão') ||
      await pedirAoQuadro('achar', 'telaEmissao') || await pedirAoQuadro('achar', 'semNegociacao'),
    `a tela "${TEXTO_TELA_EMISSAO}"`, estado.cliqueManual ? ESPERA_CLIQUE_MANUAL_MS : TIMEOUT_REGULARIZE_MS);
    if (tela === 'sem permissão') throw await erroSemPermissao();
    mostrarAviso('analisando o resultado…');
    // Segue assim que a página terminar de mostrar o resultado: a mensagem de "sem negociação" OU a tabela com linhas.
    let resultado = null;
    try {
      resultado = await esperar(async () => {
        if (await pedirAoQuadro('achar', 'semNegociacao')) return 'sem';
        const t = await pedirAoQuadro('ler', 'situacoes');
        return t && t.valores && t.valores.length ? 'tabela' : null;
      }, 'o resultado', ESPERA_RESULTADO_MS);
    } catch (e) {
      if (!e.tempoEsgotado) throw e;
    }
    const perfil = estado.confirmado ? `Perfil no e-CAC: ${estado.confirmado}\n` : '';
    if (resultado === 'tabela') {
      await ordenarPorSituacao();
      estado.temNegociacoes = true; // a etapa seguinte processa as "DEFERIDA E CONSOLIDADA"
      estado.fim = `${perfil}Há negociações: ordenei a tabela por "${TEXTO_COL_SITUACAO}".`;
      return;
    }
    if (resultado !== 'sem') {
      throw new Error(`a tela de emissão abriu, mas não apareceu nem a mensagem "${TEXTO_SEM_NEGOCIACAO}" nem a tabela de negociações. ` +
        'Mande o print para eu ensinar este caso');
    }
    await sleep(rand(800, 1400)); // "lê" a mensagem
    mostrarAviso('sem parcelamento: salvando o print em PDF…');
    const caminho = await salvarPrintEmPdf(await pastaDoCliente());
    estado.fim = `${perfil}Sem parcelamento ("${TEXTO_SEM_NEGOCIACAO}").\nPrint salvo em PDF:\n${caminho}\nParei aqui.`;
  }

  // Ordem alfabética das situações (a ordem que o site mostra depois de clicar no título: "DEFERIDA..." antes de "ENCERRADA...").
  const emOrdem = (valores) => valores.every((v, i) => i === 0 ||
    norm(valores[i - 1]).localeCompare(norm(v), 'pt-BR') <= 0);

  // Clica no título "Situação da conta" para ordenar a tabela (só se ela ainda não estiver nessa ordem).
  async function ordenarPorSituacao() {
    mostrarAviso(`analisando a tabela de negociações (coluna "${TEXTO_COL_SITUACAO}")…`);
    let antes = ((await pedirAoQuadro('ler', 'situacoes')) || {}).valores || [];
    log(`situações antes: ${antes.join(' | ')}`);
    await sleep(rand(700, 1300)); // "lê" a tabela
    if (emOrdem(antes)) {
      log('a tabela já está em ordem de situação; não precisa clicar');
      return;
    }
    for (let tent = 1; tent <= TENTATIVAS_ORDENAR; tent++) {
      mostrarAviso(tent === 1
        ? `clicando no título "${TEXTO_COL_SITUACAO}" para ordenar…`
        : `a tabela não ficou na ordem; clicando de novo no título (${tent} de ${TENTATIVAS_ORDENAR})…`);
      await clicarNoQuadro('colSituacao', `título da coluna "${TEXTO_COL_SITUACAO}"`);
      mostrarAviso('aguardando a tabela reordenar…');
      // espera a tabela mudar (o site reordena sem recarregar a página)
      let depois = antes;
      try {
        depois = await esperar(async () => {
          const v = ((await pedirAoQuadro('ler', 'situacoes')) || {}).valores || [];
          return v.length && v.join('|') !== antes.join('|') ? v : null;
        }, 'a tabela reordenada', TIMEOUT_JANELA_MS);
      } catch (e) {
        if (!e.tempoEsgotado) throw e;
      }
      log(`situações depois: ${depois.join(' | ')}`);
      if (emOrdem(depois)) return;
      antes = depois;
      await sleep(rand(500, 900));
    }
    throw new Error(`cliquei ${TENTATIVAS_ORDENAR} vezes no título "${TEXTO_COL_SITUACAO}" e a tabela não ficou em ordem de situação`);
  }

  async function clicarContinuar() {
    const perfil = estado.confirmado ? `Perfil no e-CAC: ${estado.confirmado}\n` : '';
    const concluir = (reacao) => {
      estado.fim = `${perfil}Cliquei em "${TEXTO_CONTINUAR}" no aviso do SISPAR.\n${reacao}\nParei aqui.`;
    };
    if (estado.continuarClicado && !await avisoSisparPresente()) { // a página recarregou depois do clique
      concluir('O aviso fechou.');
      return;
    }
    mostrarAviso('analisando o aviso do SISPAR e as opções…');
    await esperar(avisoSisparPresente, 'o aviso do SISPAR');
    await sleep(rand(1200, 2000)); // "lê" o aviso antes de escolher
    for (let tent = 1; tent <= TENTATIVAS_CONTINUAR; tent++) {
      mostrarAviso(tent === 1
        ? `clicando em "${TEXTO_CONTINUAR}"…`
        : `o aviso não fechou; tentando de novo (${tent} de ${TENTATIVAS_CONTINUAR})…`);
      aberturaCapturada = null;
      const inicio = Date.now();
      estado.continuarClicado = true;
      await gravarEstado();
      // A aba nova do SISPAR (aberta pela extensão, ver pagina.js) continua o trabalho a partir daqui.
      await mensagem({ tipo: 'transferencia-iniciar', destino: 'sisparnet', cnpj: estado.cnpj, abaEcac: estado.abaEcac, concluidos: estado.concluidos || [],
        confirmado: estado.confirmado, empresa: estado.empresa });
      if (estado.hostSispar) {
        await clicarNoQuadro('continuar', `botão "${TEXTO_CONTINUAR}"`);
      } else {
        const botao = await esperar(() => acharBlocoMenu(TEXTO_CONTINUAR), `o botão "${TEXTO_CONTINUAR}"`);
        await clicarEm(botao, `botão "${TEXTO_CONTINUAR}"`);
      }
      mostrarAviso('aguardando a reação da página…');
      const reacao = await aguardarReacaoContinuar(inicio);
      if (reacao === 'Abriu uma janela nova.') {
        // Como no uso manual: o SISPAR abriu na sua própria aba. As próximas etapas rodam lá.
        estado.continuouEmAba = true;
        mostrarAviso('o SISPAR abriu numa aba nova; a automação continua lá…');
        try {
          await esperar(async () => { const t = await mensagem({ tipo: 'transferencia-status' }); return t && t.concluida; },
            'a aba nova do SISPAR', TIMEOUT_NOVA_JANELA_MS);
        } catch (e) {
          if (!e.tempoEsgotado) throw e;
          throw new Error(`a aba nova do SISPAR abriu, mas a automação não conseguiu continuar nela em ${Math.round(TIMEOUT_NOVA_JANELA_MS / 1000)} s`);
        }
        concluir('A automação continuou na aba nova do SISPAR.');
        return;
      }
      if (reacao) {
        concluir(reacao);
        return;
      }
    }
    throw new Error(`cliquei ${TENTATIVAS_CONTINUAR} vezes em "${TEXTO_CONTINUAR}" e nada aconteceu: o aviso continua aberto` +
      (estado.popupBloqueado ? '. A página tentou abrir uma janela que o Chrome bloqueou: permita pop-ups no Regularize ' +
        '(ícone à direita da barra de endereço) e comece de novo' : ''));
  }

  // O "agente": responde onde estão os alvos e clica neles. Dentro do quadro do Regularize, é tudo o que este script
  // faz (via mensagens); na aba própria do SISPAR, é chamado direto (pedirAoQuadro).
  // Só os alvos desta lista podem ser clicados (nunca "DESISTIR"). "CONTINUAR" só vale com o aviso do SISPAR aberto.
  const responderOp = (() => {
    const ALVOS = {
      sistema: noSistemaNegociacoes,
      consultar: () => acharBlocoMenu(TEXTO_CONSULTAR),
      aviso: acharAvisoSispar,
      continuar: () => acharAvisoSispar() && acharBlocoMenu(TEXTO_CONTINUAR),
      pgfn: () => acharBlocoMenu(TEXTO_MENU_EMISSAO) || acharTexto(TEXTO_TELA_PGFN),
      menuEmissao: () => acharBlocoMenu(TEXTO_MENU_EMISSAO),
      // opção do MENU (dentro do menu "Emissão de Documento"): o botão abaixo da tabela tem o mesmo texto
      docArrecadacao: () => opcaoDoMenu(TEXTO_DOC_ARRECADACAO),
      botaoDocArrec: () => botaoAbaixoDaTabela(TEXTO_BOTAO_DOC),
      linhas: () => acharBlocoMenu(TEXTO_COL_SITUACAO),
      linhaConta: (msg) => celulaDaConta(msg.conta),
      telaDetalhe: () => acharTexto(TEXTO_TELA_DETALHE),
      refConta: () => acharTexto('Nr. Referência Conta'),
      telaEmissao: () => acharTexto(TEXTO_TELA_EMISSAO),
      semNegociacao: () => acharTexto(TEXTO_SEM_NEGOCIACAO),
      semPermissao: () => acharTexto(TEXTO_SEM_PERMISSAO),
      usuario: () => acharCabecalho(/usu[aá]rio:/i), // linha "Usuário: CNPJ - NOME" (só leitura)
      colSituacao: () => acharBlocoMenu(TEXTO_COL_SITUACAO), // título da coluna (clicável: ordena)
      situacoes: () => acharBlocoMenu(TEXTO_COL_SITUACAO),   // o mesmo título, para ler a coluna (op 'ler')
      // página da negociação: tabela "Prestação"
      pagina: () => document.documentElement,                       // só para rolar (op 'rolar')
      prestacoes: () => (cabecalhoPrestacao() || {}).th || null,    // título "Emissão" (ops 'ler' e 'rolar')
      iconeEmissao: (msg) => iconeDaPrestacao(msg.prest),
      proximaPagina: () => botaoProximaPagina(),
      contribuinte: () => acharTexto('Contribuinte:'),
      // janela "Cálculo e demonstrativo de emissão..." (aberta pelo ícone da impressora)
      janelaEmissao: () => janelaEmissao(),
      emitir: () => botaoNaJanela(TEXTO_EMITIR),
      voltarJanela: () => botaoNaJanela(TEXTO_VOLTAR),
      // janela com cálculo prévio (parcelas que dependem da receita bruta): botão "Calcular"
      calcular: () => botaoNaJanela(TEXTO_CALCULAR),
      // aviso de cookies da PGFN (embaixo da página): botão "Permitir"
      cookiesPermitir: () => botaoPermitirCookies(),
      // página do PDF (depois de "Emitir"): link do PDF e "Voltar"
      paginaPdf: () => linkDoPdf(),
      linkPdf: () => linkDoPdf(),
      voltarPdf: () => (linkDoPdf() ? exatos(TEXTO_VOLTAR).map((e) => e.closest('button, input, a, [role="button"]') || e)
        .find((e) => !janelaEmissao()) || null : null),
    };
    const CLICAVEIS = ['consultar', 'continuar', 'docArrecadacao', 'colSituacao', 'linhaConta', 'botaoDocArrec',
      'iconeEmissao', 'proximaPagina', 'emitir', 'voltarJanela', 'linkPdf', 'voltarPdf', 'calcular', 'cookiesPermitir'];

    // Campo da janela de emissão pelo rótulo ("Valor da Prestação:", "RECEITA BRUTA APURADA NO MES ANTERIOR:"): o
    // primeiro campo de texto no menor bloco em volta do rótulo (a linha dele).
    function campoDaJanela(rotulo) {
      const j = janelaEmissao();
      if (!j) return null;
      const alvo = chave(rotulo);
      for (const e of j.querySelectorAll('label, th, td, span, div, p, b, legend')) {
        if (e.querySelector('input') || !chave(e.textContent).startsWith(alvo)) continue;
        for (let p = e; p && j.contains(p); p = p.parentElement) {
          const campo = p.querySelector('input:not([type="hidden"]):not([type="button"]):not([type="submit"]):not([type="image"])');
          if (campo) return campo;
        }
      }
      return null;
    }
    const numeroBr = (s) => { const n = parseFloat(String(s || '').replace(/[^\d,.-]/g, '').replace(/\./g, '').replace(',', '.')); return Number.isFinite(n) ? n : 0; };
    // Aviso de cookies da PGFN ("...Declaração de Cookies", botões "Permitir" e "Rejeitar"): o "Permitir" do próprio aviso.
    function botaoPermitirCookies() {
      const frase = acharTexto('Declaração de Cookies') || acharTexto("Se clicar em 'Rejeitar Cookies'");
      if (!frase) return null;
      for (let e = frase.parentElement, i = 0; e && i < 8; e = e.parentElement, i++) {
        const b = exatos(TEXTO_PERMITIR_COOKIES).find((x) => e.contains(x));
        if (b) return b.closest('button, input, a, [role="button"]') || b;
      }
      return null;
    }

    // A janela de emissão: o bloco em volta de "Parcela para emissão" que também tem o botão "Emitir".
    function janelaEmissao() {
      const parcela = acharTexto(TEXTO_PARCELA_EMISSAO);
      if (!parcela) return null;
      const dialogo = parcela.closest('[role="dialog"], .ui-dialog, .modal, .rf-pp-cntr, .rich-mpnl-body');
      if (dialogo) return dialogo;
      for (let e = parcela.parentElement, i = 0; e && i < 12; e = e.parentElement, i++) {
        if (exatos(TEXTO_EMITIR).some((b) => e.contains(b))) return e;
      }
      return null;
    }
    function botaoNaJanela(texto) {
      const j = janelaEmissao();
      if (!j) return null;
      const el = exatos(texto).find((e) => j.contains(e));
      return el ? (el.closest('button, input, a, [role="button"]') || el) : null;
    }
    // Link do PDF: tem ícone de PDF (ou endereço .pdf) e fica numa página SEM a tabela "Prestação".
    function linkDoPdf() {
      if (cabecalhoPrestacao() || janelaEmissao()) return null;
      const ehPdf = (e) => e && /pdf/i.test([e.getAttribute('src'), e.getAttribute('alt'), e.getAttribute('title'),
        String(e.className || '')].join(' '));
      return [...document.querySelectorAll('a')].find((a) => {
        if (!visivel(a) || a.closest(`#${ID_AVISO}`)) return false;
        const vizinhos = [...a.querySelectorAll('img, span, i'), a.previousElementSibling, ...(a.parentElement ? a.parentElement.querySelectorAll('img') : [])];
        return /\.pdf(\?|$)/i.test(a.getAttribute('href') || '') || ehPdf(a) || vizinhos.some(ehPdf) ||
          (/^\d{10,}$/.test(a.textContent.trim()) && vizinhos.some((v) => v && v.tagName === 'IMG'));
      }) || null;
    }

    // ---- tabela "Prestação" (página da negociação) ----
    // Cabeçalho: a linha que tem "Nr. Prestação" e "Emissão"; índices das colunas usadas.
    function cabecalhoPrestacao() {
      for (const th of document.querySelectorAll('th, td')) {
        if (chave(th.textContent) !== chave(TEXTO_COL_EMISSAO) || !visivel(th)) continue;
        const tr = th.parentElement;
        if (!tr || !tr.cells) continue;
        const idx = (t) => { const c = [...tr.cells].find((x) => chave(x.textContent) === chave(t)); return c ? c.cellIndex : -1; };
        const iPrest = idx(TEXTO_COL_PRESTACAO);
        if (iPrest < 0) continue;
        return { th, tr, iEmissao: th.cellIndex, iPrest, iValor: idx('Valor Originário'), iSaldo: idx('Valor Sd. Devedor'),
          iVenc: idx('Data Vencimento Prestação'), iVencDoc: idx('Data Vencimento Doc. Arrec.'), iDocCob: idx('Nr. Documento Cobrança') };
      }
      return null;
    }
    // Linhas de dados (na mesma tabela do cabeçalho ou na seguinte).
    function linhasPrestacao(cab) {
      const tabelas = [...document.querySelectorAll('table')];
      const daTitulo = cab.th.closest('table');
      for (const t of [daTitulo, ...tabelas.slice(tabelas.indexOf(daTitulo) + 1)]) {
        if (!t) continue;
        const rows = [...t.tBodies].flatMap((b) => [...b.rows])
          .filter((r) => r !== cab.tr && r.cells.length > Math.max(cab.iEmissao, cab.iPrest));
        const ls = rows.map((tr) => ({ tr, prest: soDigitos(tr.cells[cab.iPrest].textContent) })).filter((l) => l.prest);
        if (ls.length) return ls;
      }
      return [];
    }
    const SELETOR_CLICAVEL = 'a[href], a[onclick], button, input[type="image"], input[type="button"], input[type="submit"], [onclick], [role="button"]';
    // O que há na célula "Emissão": verificado (azul), impressora, vazio ou outro; e se dá para clicar.
    function lerEmissao(td) {
      const partes = [td, ...td.querySelectorAll('*')].map((e) => [
        e.getAttribute('src'), e.getAttribute('alt'), e.getAttribute('title'), e.getAttribute('aria-label'),
        typeof e.className === 'string' ? e.className : (e.getAttribute('class') || ''),
        e.getAttribute('href'), e.getAttribute('xlink:href'),
        getComputedStyle(e).backgroundImage !== 'none' ? getComputedStyle(e).backgroundImage : '',
      ].filter(Boolean).join(' '));
      const descricao = norm(partes.join(' ') + ' ' + td.textContent);
      const clicavel = !!td.querySelector(SELETOR_CLICAVEL) || td.matches('[onclick]');
      const temIcone = !!td.querySelector('img, svg, i, input, a, button, span[class]') || !!td.textContent.trim();
      let icone;
      if (/impress|imprim|print|printer/.test(descricao)) icone = 'impressora';
      // ícone laranja de exclamação (aviso): o documento já foi emitido
      else if (/alert|warn|atenc|aviso|exclam|emitid|laranja|orange|⚠/.test(descricao)) icone = 'emitido';
      else if (/check|verific|sucesso|tick|confirm|quitad|\bok\b|✓|✔/.test(descricao)) icone = 'verificado';
      else if (!temIcone) icone = 'vazio';
      else icone = 'outro';
      const html = td.innerHTML.replace(/\s+/g, ' ').trim().slice(0, 220);
      return { icone, clicavel, desc: html };
    }
    function iconeDaPrestacao(prest) {
      const cab = cabecalhoPrestacao();
      if (!cab) return null;
      const l = linhasPrestacao(cab).find((x) => x.prest === soDigitos(prest || ''));
      if (!l) return null;
      const td = l.tr.cells[cab.iEmissao];
      return td.querySelector(SELETOR_CLICAVEL) || td.querySelector('img, svg, i, span') || td;
    }
    function botaoProximaPagina() {
      const cab = cabecalhoPrestacao();
      if (!cab) return null;
      const caixa = cab.th.closest('fieldset') || cab.th.closest('.ui-datatable') || cab.th.closest('table').parentElement;
      return [...caixa.querySelectorAll('.ui-paginator-next, .rf-ds-btn-next, [aria-label*="próxima" i], [title*="próxima" i], ' +
        '[aria-label*="next" i], [title*="next" i]')]
        .find((e) => visivel(e) && habilitado(e)) || null;
    }
    // Quem rola a tabela: o primeiro ancestral com rolagem própria, ou a página.
    function rolavelDe(el) {
      for (let e = el && el.parentElement; e && e !== document.body && e !== document.documentElement; e = e.parentElement) {
        const oy = getComputedStyle(e).overflowY;
        if ((oy === 'auto' || oy === 'scroll') && e.scrollHeight > e.clientHeight + 2) return e;
      }
      return document.scrollingElement || document.documentElement;
    }
    // Área da tela onde a tabela aparece de verdade: tira faixas fixas embaixo (ex.: aviso de cookies).
    function areaLivre(sc) {
      const altura = document.documentElement.clientHeight;
      let topo = 0, base = altura;
      if (sc !== document.scrollingElement && sc !== document.documentElement) {
        const r = sc.getBoundingClientRect();
        topo = Math.max(0, r.top); base = Math.min(base, r.bottom);
      }
      for (const fx of [0.25, 0.5, 0.75]) {
        for (let e = document.elementFromPoint(innerWidth * fx, altura - 3); e && e !== document.body && e !== document.documentElement; e = e.parentElement) {
          const pos = getComputedStyle(e).position;
          if (pos === 'fixed' || pos === 'sticky') {
            const r = e.getBoundingClientRect();
            if (r.top > altura * 0.4) base = Math.min(base, r.top);
            break;
          }
        }
      }
      return { topo, base };
    }
    // Uma "puxada" da roda do mouse: evento wheel no ponto da seta e rolagem suave do trecho.
    async function rolar(el, msg) {
      const sc = msg.alvo === 'pagina' ? (document.scrollingElement || document.documentElement) : rolavelDe(el);
      const antes = sc.scrollTop;
      const sob = (Number.isFinite(msg.x) && document.elementFromPoint(msg.x, msg.y)) || el;
      sob.dispatchEvent(new WheelEvent('wheel', { deltaY: msg.delta, deltaMode: 0, clientX: msg.x, clientY: msg.y,
        bubbles: true, cancelable: true, composed: true, view: window }));
      const max = sc.scrollHeight - sc.clientHeight;
      const destino = clamp(antes + msg.delta, 0, Math.max(0, max));
      const dur = rand(110, 200), inicio = performance.now();
      for (;;) {
        const t = clamp((performance.now() - inicio) / dur, 0, 1);
        const e = 1 - Math.pow(1 - t, 3); // desacelera no fim do dente
        sc.scrollTo({ top: antes + (destino - antes) * e, behavior: 'instant' });
        if (t >= 1) break;
        await new Promise((r) => setTimeout(r, 16));
      }
      return { mexeu: Math.abs(sc.scrollTop - antes) >= 1, topo: sc.scrollTop, max };
    }
    function lerPrestacoes(th) {
      const cab = cabecalhoPrestacao();
      const texto = (tr, i) => (i >= 0 && tr.cells[i] ? tr.cells[i].textContent.replace(/\s+/g, ' ').trim() : '');
      const linhas = linhasPrestacao(cab).map(({ tr, prest }) => {
        const r = tr.getBoundingClientRect();
        const linha = { prest, venc: texto(tr, cab.iVenc), valor: texto(tr, cab.iValor), saldo: texto(tr, cab.iSaldo),
          vencDoc: texto(tr, cab.iVencDoc), docCob: texto(tr, cab.iDocCob),
          ...lerEmissao(tr.cells[cab.iEmissao]), top: r.top, bottom: r.bottom };
        // Ícone laranja de exclamação = documento já emitido. Além do nome do ícone, vale o que a linha mostra: um
        // "Nr. Documento Cobrança" preenchido com saldo devedor (prestação ainda não paga, mas com documento) não é
        // "verificado" (pago); foi assim que a prestação 0012 de um cliente foi lida errado em 06/11/2026.
        if (linha.icone !== 'impressora' && /\d{6,}/.test(linha.docCob) &&
          Number(String(linha.saldo).replace(/[^\d,]/g, '').replace(',', '.')) > 0) linha.icone = 'emitido';
        return linha;
      });
      const t = th.closest('table').getBoundingClientRect();
      return { linhas, tabela: { top: t.top, left: t.left, width: t.width, height: t.height },
        area: areaLivre(rolavelDe(th)), proxima: !!botaoProximaPagina() };
    }

    const DENTRO_DE_MENU = 'ul, [role="menu"], [role="menubar"], .ui-menu, .ui-menubar, nav';
    // Elementos visíveis cujo texto (ou value) é exatamente `texto`, os mais internos.
    function exatos(texto) {
      const alvo = chave(texto);
      const lista = [...document.querySelectorAll('a, button, input[type="button"], input[type="submit"], span, div, td, li')]
        .filter((e) => chave(e.tagName === 'INPUT' ? e.value : e.textContent) === alvo && visivel(e));
      return lista.filter((e) => !lista.some((o) => o !== e && e.contains(o)));
    }
    // A opção dentro do menu "Emissão de Documento" (no mesmo item do menu, ou em qualquer lista de menu).
    function opcaoDoMenu(texto) {
      const titulo = acharBlocoMenu(TEXTO_MENU_EMISSAO);
      const item = titulo && titulo.closest('li');
      const lista = exatos(texto);
      // se o site não usar listas de menu: a opção que fica ANTES da tabela (o botão de mesmo nome fica depois dela)
      const cabTabela = acharBlocoMenu(TEXTO_COL_SITUACAO);
      const tabela = cabTabela && cabTabela.closest('table');
      const el = (item && lista.find((e) => item.contains(e))) || lista.find((e) => e.closest(DENTRO_DE_MENU)) ||
        lista.find((e) => !tabela || (e.compareDocumentPosition(tabela) & Node.DOCUMENT_POSITION_FOLLOWING));
      return el ? (el.closest('a, button, [role="menuitem"], li') || el) : null;
    }
    // O botão com esse texto que fica FORA do menu e depois da tabela de negociações.
    function botaoAbaixoDaTabela(texto) {
      const titulo = acharBlocoMenu(TEXTO_COL_SITUACAO);
      const tabela = titulo && titulo.closest('table');
      const el = exatos(texto).find((e) => !e.closest(DENTRO_DE_MENU) &&
        (!tabela || (tabela.compareDocumentPosition(e) & Node.DOCUMENT_POSITION_FOLLOWING)));
      return el ? (el.closest('button, input, a, [role="button"]') || el) : null;
    }
    const habilitado = (b) => !(b.disabled || b.getAttribute('aria-disabled') === 'true' ||
      /disabled|desabilit/i.test(String(b.className || '')) || getComputedStyle(b).pointerEvents === 'none');

    // Linhas da tabela: Número da Conta e Situação da conta de cada uma (as linhas podem estar na mesma tabela do título
    // ou na seguinte).
    function linhasDaTabela() {
      const thSit = (acharBlocoMenu(TEXTO_COL_SITUACAO) || {}).closest?.('th, td');
      const thConta = (acharBlocoMenu(TEXTO_COL_CONTA) || {}).closest?.('th, td');
      if (!thSit || !thConta) return [];
      const tabelas = [...document.querySelectorAll('table')];
      const daTitulo = thSit.closest('table');
      for (const t of [daTitulo, ...tabelas.slice(tabelas.indexOf(daTitulo) + 1)]) {
        if (!t) continue;
        const rows = [...t.tBodies].flatMap((b) => [...b.rows])
          .filter((r) => r.cells.length > Math.max(thSit.cellIndex, thConta.cellIndex) && !r.contains(thSit));
        const linhas = rows.map((r) => ({
          tr: r,
          conta: soDigitos(r.cells[thConta.cellIndex].textContent),
          situacao: (r.cells[thSit.cellIndex].textContent || '').replace(/\s+/g, ' ').trim(),
        })).filter((l) => l.conta);
        if (linhas.length) return linhas;
      }
      return [];
    }
    // Célula para clicar na linha da conta (a da coluna "Negociações", que é só texto; senão a primeira).
    function celulaDaConta(conta) {
      const l = linhasDaTabela().find((x) => semZeros(x.conta) === semZeros(conta || ''));
      if (!l) return null;
      return l.tr.cells[1] || l.tr.cells[0];
    }
    const linhaSelecionada = (tr) => /selec|highlight|active/i.test(String(tr.className || '')) ||
      tr.getAttribute('aria-selected') === 'true';

    // Valores da coluna do título, na ordem em que aparecem na tabela (procura a tabela das linhas, que pode ser
    // a mesma do título ou a seguinte).
    function lerColuna(titulo) {
      const th = titulo.closest('th, td');
      if (!th) return [];
      const idx = th.cellIndex;
      const tabelaDoTitulo = th.closest('table');
      const tabelas = [...document.querySelectorAll('table')];
      const candidatas = [tabelaDoTitulo, ...tabelas.slice(tabelas.indexOf(tabelaDoTitulo) + 1)];
      for (const t of candidatas) {
        if (!t) continue;
        const linhas = [...t.tBodies].flatMap((b) => [...b.rows]).filter((r) => r.cells.length > idx && !r.contains(th));
        const valores = linhas.map((r) => (r.cells[idx].textContent || '').replace(/\s+/g, ' ').trim()).filter(Boolean);
        if (valores.length) return valores;
      }
      return [];
    }
    const PASSAVEIS = ['menuEmissao']; // só passa a seta por cima, sem clicar
    let rodapesEscondidos = [];

    // Seta chegando ao ponto: o elemento e todos os ancestores recebem "entrada" (como o navegador faz com o mouse).
    function passarNoPonto(el, x, y) {
      const noPonto = document.elementFromPoint(x, y);
      const alvo = noPonto && (el === noPonto || el.contains(noPonto) || noPonto.contains(el)) ? noPonto : el;
      const cadeia = [];
      for (let e = alvo; e && e.nodeType === 1; e = e.parentElement) cadeia.unshift(e);
      eventoMouse(alvo, 'pointerover', x, y);
      eventoMouse(alvo, 'mouseover', x, y);
      cadeia.forEach((e) => { eventoMouse(e, 'pointerenter', x, y); eventoMouse(e, 'mouseenter', x, y); });
      eventoMouse(alvo, 'pointermove', x, y);
      eventoMouse(alvo, 'mousemove', x, y);
    }

    const eventoMouse = (el, tipo, x, y) => {
      const ponteiro = tipo.startsWith('pointer');
      const Ctor = ponteiro && typeof PointerEvent === 'function' ? PointerEvent : MouseEvent;
      el.dispatchEvent(new Ctor(tipo, {
        bubbles: tipo !== 'mouseenter' && tipo !== 'pointerenter', cancelable: true, composed: true, view: window, clientX: x, clientY: y,
        screenX: x, screenY: y, button: 0, buttons: tipo === 'mousedown' || tipo === 'pointerdown' ? 1 : 0,
        pointerId: 1, pointerType: 'mouse', isPrimary: true,
      }));
    };

    async function clicarNoPonto(el, x, y) {
      const noPonto = document.elementFromPoint(x, y);
      const alvo = noPonto && (el === noPonto || el.contains(noPonto) || noPonto.contains(el)) ? noPonto : el;
      ['pointerover', 'mouseover', 'mouseenter', 'pointermove', 'mousemove'].forEach((t) => eventoMouse(alvo, t, x, y));
      await new Promise((r) => setTimeout(r, rand(120, 260)));
      eventoMouse(alvo, 'pointerdown', x, y);
      eventoMouse(alvo, 'mousedown', x, y);
      await new Promise((r) => setTimeout(r, rand(90, 190)));
      eventoMouse(alvo, 'pointerup', x, y);
      eventoMouse(alvo, 'mouseup', x, y);
      eventoMouse(alvo, 'click', x, y);
    }

    // Devolve uma promessa com a resposta, ou null quando este documento não tem o alvo (outro quadro pode ter).
    return (msg) => {
      if (msg.tipo !== 'quadro-op' || !ALVOS[msg.alvo]) return null;
      const el = ALVOS[msg.alvo](msg);
      if (!el) return null;
      if (msg.op === 'achar') {
        const r = el.getBoundingClientRect();
        // info: como o elemento clicável é feito (para diagnóstico)
        const c = el.closest('a, button, input, [onclick]') || el;
        const attr = (n) => (c.getAttribute(n) || '').replace(/\s+/g, ' ').slice(0, 140);
        const info = `<${c.tagName.toLowerCase()}> href="${attr('href')}" target="${attr('target')}" onclick="${attr('onclick')}" id="${attr('id')}"`;
        return Promise.resolve({ top: r.top, left: r.left, width: r.width, height: r.height, host: location.hostname, info, href: c.href || '',
          texto: (el.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 300) });
      }
      if (msg.op === 'ler' && msg.alvo === 'situacoes') {
        return Promise.resolve({ valores: lerColuna(el), host: location.hostname });
      }
      if (msg.op === 'ler' && msg.alvo === 'linhas') {
        return Promise.resolve({ linhas: linhasDaTabela().map(({ conta, situacao }) => ({ conta, situacao })) });
      }
      if (msg.op === 'ler' && msg.alvo === 'linhaConta') {
        // selecionada: classe/aria da linha; se o site não marcar assim, vale a cor de fundo diferente das outras
        const tr = el.closest('tr');
        const outra = [...tr.parentElement.rows].find((r) => r !== tr);
        const cor = (r) => getComputedStyle(r).backgroundColor;
        return Promise.resolve({ selecionada: linhaSelecionada(tr) || (!!outra && cor(tr) !== cor(outra)) });
      }
      if (msg.op === 'ler' && msg.alvo === 'botaoDocArrec') {
        return Promise.resolve({ habilitado: habilitado(el) });
      }
      if (msg.op === 'ler' && msg.alvo === 'refConta') {
        const bloco = el.closest('tr, li, p, div') || el;
        const m = /refer[eê]ncia\s+conta:?\s*(\d+)/i.exec((bloco.textContent || '').replace(/\s+/g, ' '));
        return Promise.resolve({ conta: m ? m[1] : '' });
      }
      if (msg.op === 'ler' && msg.alvo === 'janelaEmissao') {
        const t = (el.textContent || '').replace(/\s+/g, ' ');
        const parcela = (/parcela para emiss[aã]o:?\s*(\d+)/i.exec(t) || [])[1] || '';
        const campoValor = campoDaJanela('Valor da Prestação');
        const valor = (campoValor && campoValor.value) || (/valor da presta[cç][aã]o:?\s*([\d.,]+)/i.exec(t) || [])[1] ||
          ([...el.querySelectorAll('input')].map((i) => i.value).find(Boolean) || '');
        const emitir = botaoNaJanela(TEXTO_EMITIR);
        const receita = campoDaJanela(TEXTO_RECEITA_BRUTA);
        return Promise.resolve({ parcela, valor, valorNumero: numeroBr(valor), temEmitir: !!emitir,
          emitirHabilitado: !!emitir && habilitado(emitir),
          // cálculo prévio: a janela tem "Calcular" (e, em geral, o campo da receita bruta)
          exigeCalculo: !!botaoNaJanela(TEXTO_CALCULAR),
          temReceita: !!receita, receita: receita ? receita.value : '', receitaEmFoco: !!receita && receita.ownerDocument.activeElement === receita });
      }
      if (msg.op === 'ler' && msg.alvo === 'contribuinte') {
        const bloco = el.closest('tr') || el.parentElement || el;
        const m = /contribuinte:?\s*([\d./-]{14,18})\s*-\s*([^\n]+?)(?:\s{2,}|$)/i.exec((bloco.textContent || '').replace(/[ \t]+/g, ' ').trim());
        return Promise.resolve(m ? { cnpj: soDigitos(m[1]), nome: m[2].split(/\s+(?:valor|total|saldo|data|nr\.|modalidade)\b/i)[0].trim() } : {});
      }
      // página inteira (print de confirmação): posição da rolagem, tamanhos e faixas fixas embaixo
      if (msg.op === 'ler' && msg.alvo === 'pagina') {
        const se = document.scrollingElement || document.documentElement;
        return Promise.resolve({ topo: se.scrollTop, altura: se.scrollHeight, janela: innerHeight, util: document.documentElement.clientHeight });
      }
      if (msg.op === 'irPara' && msg.alvo === 'pagina') { // rolagem direta, só para o print em partes
        const se = document.scrollingElement || document.documentElement;
        se.scrollTo({ top: msg.y, behavior: 'instant' });
        return Promise.resolve({ topo: se.scrollTop });
      }
      // esconde (e depois mostra) faixas fixas no rodapé, como o aviso de cookies, só durante o print (não clica nelas)
      if (msg.op === 'rodape' && msg.alvo === 'pagina') {
        if (msg.esconder) {
          rodapesEscondidos = [];
          const altura = document.documentElement.clientHeight;
          for (const fx of [0.25, 0.5, 0.75]) {
            for (let e = document.elementFromPoint(innerWidth * fx, altura - 3); e && e !== document.body && e !== document.documentElement; e = e.parentElement) {
              const pos = getComputedStyle(e).position;
              if ((pos === 'fixed' || pos === 'sticky') && !rodapesEscondidos.includes(e)) {
                if (e.getBoundingClientRect().top > altura * 0.4) { rodapesEscondidos.push(e); e.dataset.pgfnVis = e.style.visibility; e.style.visibility = 'hidden'; }
                break;
              }
            }
          }
        } else {
          rodapesEscondidos.forEach((e) => { e.style.visibility = e.dataset.pgfnVis || ''; delete e.dataset.pgfnVis; });
          rodapesEscondidos = [];
        }
        return Promise.resolve({ ok: true });
      }
      if (msg.op === 'ler' && msg.alvo === 'prestacoes') {
        return Promise.resolve(lerPrestacoes(el));
      }
      if (msg.op === 'rolar' && (msg.alvo === 'prestacoes' || msg.alvo === 'pagina')) {
        return rolar(el, msg);
      }
      // ícone da coluna "Emissão": nunca clica num "verificado" (prestação regular)
      if (msg.op === 'clicar' && msg.alvo === 'iconeEmissao') {
        const td = el.closest('td');
        const ic = td && lerEmissao(td).icone;
        if (ic === 'verificado' || ic === 'emitido') return Promise.resolve({ ok: false, recusado: ic });
      }
      if (msg.op === 'passar' && PASSAVEIS.includes(msg.alvo)) {
        passarNoPonto(el, msg.x, msg.y);
        return Promise.resolve({ ok: true });
      }
      if (msg.op === 'clicar' && CLICAVEIS.includes(msg.alvo)) {
        // "CONTINUAR": avisa o pagina.js que a abertura que vem a seguir é da automação (ele a entrega à extensão)
        if (msg.alvo === 'continuar') document.documentElement.setAttribute('data-pgfn-auto', String(Date.now()));
        return clicarNoPonto(el, msg.x, msg.y).then(() => ({ ok: true }));
      }
      return null;
    };
  })();

  if (QUADRO_DO_REGULARIZE) {
    chrome.runtime.onMessage.addListener((msg, _remetente, responder) => {
      const p = responderOp(msg);
      if (!p) return false; // sem resposta: outro quadro pode ter o elemento
      p.then(responder);
      return true;
    });
    // pagina.js entregou a abertura do "CONTINUAR": a extensão abre a aba nova (uma vez só).
    document.addEventListener('pgfn-abrir-aba', () => {
      const url = document.documentElement.getAttribute('data-pgfn-abrir');
      document.documentElement.removeAttribute('data-pgfn-abrir');
      if (!url) return;
      log(`abrindo o SISPAR numa aba nova (como no uso manual): ${url.split('?')[0]}`);
      mensagem({ tipo: 'abrir-url', url });
    });
    log(`agente pronto no quadro de ${location.hostname}`);
    return;
  }

  const ETAPAS = NO_SISPARNET ? [
    { nome: `abrir "${TEXTO_DOC_ARRECADACAO}"`, rodar: abrirDocumentoArrecadacao },
    { nome: 'verificar o resultado e salvar', rodar: verificarResultado },
    { nome: `analisar as negociações "${TEXTO_DEFERIDA}"`, rodar: processarDeferidas },
    { nome: 'seguir para o próximo CNPJ', rodar: seguirParaProximoCnpj },
  ] : NO_REGULARIZE ? [
    { nome: 'aguardar a página do Regularize', rodar: aguardarPaginaRegularize },
    { nome: 'confirmar o aviso "CIENTE"', rodar: confirmarCiente },
    { nome: `abrir "${TEXTO_NEGOCIAR}"`, rodar: abrirNegociarDivida },
    { nome: `clicar em "${TEXTO_ACESSAR}"`, rodar: clicarAcessar },
    { nome: `conferir a reação do "${TEXTO_ACESSAR}"`, rodar: conferirReacaoAcessar },
    { nome: `abrir "${TEXTO_CONSULTAR}"`, rodar: abrirConsultar },
    { nome: `clicar em "${TEXTO_CONTINUAR}"`, rodar: clicarContinuar },
    { nome: `abrir "${TEXTO_DOC_ARRECADACAO}"`, rodar: abrirDocumentoArrecadacao },
    { nome: 'verificar o resultado e salvar', rodar: verificarResultado },
    { nome: `analisar as negociações "${TEXTO_DEFERIDA}"`, rodar: processarDeferidas },
    { nome: 'seguir para o próximo CNPJ', rodar: seguirParaProximoCnpj }, // usado no caso "sem cadastro no Regularize"
  ] : [
    { nome: 'analisar a página', rodar: analisarPagina },
    { nome: 'abrir "Alterar perfil de acesso"', rodar: abrirJanela },
    { nome: 'conferir a janela', rodar: conferirJanela },
    { nome: 'digitar o CNPJ', rodar: digitarCnpj },
    { nome: 'clicar em "Alterar"', rodar: clicarAlterar },
    { nome: 'conferir o CNPJ no topo', rodar: conferirTopo },
    { nome: `abrir "${TEXTO_DIVIDA}"`, rodar: abrirDividaAtiva },
    { nome: 'clicar na opção do Regularize', rodar: clicarRegularize },
    { nome: 'aguardar a nova janela', rodar: aguardarRegularize },
  ];
  const ETAPA_CONFERIR_TOPO = ETAPAS.findIndex((e) => e.rodar === conferirTopo);
  const ETAPA_AGUARDAR_REGULARIZE = ETAPAS.findIndex((e) => e.rodar === aguardarRegularize);
  const ETAPA_REACAO_ACESSAR = ETAPAS.findIndex((e) => e.rodar === conferirReacaoAcessar);
  const ETAPA_VERIFICAR_RESULTADO = ETAPAS.findIndex((e) => e.rodar === verificarResultado);

  // ------------------------------- orquestrador (vários CNPJs e certificados) -------------------------------
  // O CNPJ da vez vem do orquestrador (via ajudante do Windows); sem ele, vale CNPJS_TESTE (modo manual, como antes).
  async function carregarOrquestrador() {
    const r = await mensagem({ tipo: 'orq-atual' });
    ORQ = r && r.ok && r.ativo && /^\d{14}$/.test(r.cnpj || '') ? r : null;
    LISTA_CNPJS = ORQ ? [ORQ.cnpj] : CNPJS_TESTE;
    return ORQ;
  }
  // Andamento para o orquestrador: em_andamento | aguardando_humano | concluido | erro.
  function informarOrq(situacao, texto) {
    if (!ORQ) return Promise.resolve(null);
    return mensagem({ tipo: 'orq-informar', sessao: ORQ.sessao, cnpj: ORQ.cnpj, situacao, mensagem: String(texto || '') });
  }
  // Fim do CNPJ (concluido | erro): ANTES de avisar o orquestrador, que logo depois fecha o Chrome, a sessão do e-CAC é
  // encerrada com "Sair com Segurança". Sem isso, cada CNPJ deixava uma sessão aberta no servidor e o e-CAC passava a
  // recusar o login (erro 93003: número máximo de dispositivos conectados). Quem faz as duas coisas, nessa ordem, é o
  // service worker (a página pode mudar com o "Sair" e cortaria o aviso). Só nas abas da janela anônima da automação.
  function finalizarOrq(situacao, texto) {
    if (!ORQ) return Promise.resolve(null);
    return mensagem({ tipo: 'orq-finalizar', sessao: ORQ.sessao, cnpj: ORQ.cnpj, situacao, mensagem: String(texto || '') });
  }

  // ------------------------------- lentidão e falhas temporárias -------------------------------
  // Erro de regra (CNPJ diferente, sem procuração, parcela errada, sem permissão...) nunca é repetido: segue como antes.
  const ERRO_DEFINITIVO = /procura[cç][aã]o|n[aã]o [eé] o definido|[eé] do CNPJ|o arquivo seria do CNPJ|selecionada era|n[aã]o sei (qual|de qual)|parcela para emiss|permiss[aã]o|recusou|o campo (ficou|est[aá]) com|n[aã]o sobrou|voltei [aà] negocia|pop-up/i;
  const ERRO_DE_LENTIDAO = /n[aã]o (encontrei|abriu|apareceu|apareceram|fechou|mudou|respondeu|carregou|chegou|conseguiu continuar|ficou selecionada|ficou em ordem)|nada aconteceu|sumiu|sem resposta/i;
  function erroTransitorio(e) {
    if (!e || e.cancelado || e.definitivo) return false; // 0.35.0: falha de salvamento esgotada não é lentidão
    const m = String(e.message || '');
    if (ERRO_DEFINITIVO.test(m)) return false;
    return !!e.tempoEsgotado || ERRO_DE_LENTIDAO.test(m);
  }

  // Etapas que NÃO são repetidas na mesma página: abririam uma 2ª janela/aba (Regularize, SISPAR), já têm recarga
  // própria (troca de perfil) ou só encerram o CNPJ.
  const naoRepetir = (rodar) => [aguardarRegularize, clicarContinuar, conferirTopo, seguirParaProximoCnpj].includes(rodar);

  // Etapa de onde retomar depois de um F5 por lentidão; null = esta página não pode ser recarregada.
  // SISPAR: o endereço é de uso único e a página pode vir de um formulário (F5 pediria para reenviar). Regularize: só
  // antes do "CONTINUAR" (depois dele o SISPAR já foi aberto), recomeçando pela espera da página. e-CAC: a própria
  // retomada já ajusta as etapas da troca de perfil.
  function etapaAposRecarga(etapa) {
    const rodar = ETAPAS[etapa].rodar;
    if (NO_SISPARNET || EM_QUADRO) return null;
    if (NO_REGULARIZE) {
      const continuar = ETAPAS.findIndex((x) => x.rodar === clicarContinuar);
      return estado.continuouEmAba || etapa >= continuar ? null : 0;
    }
    if (rodar === aguardarRegularize || rodar === conferirTopo) return null;
    return etapa;
  }

  // true = repetir a mesma etapa agora; false = o erro segue (como antes). Pode recarregar a página (não volta).
  async function tratarLentidao(e, etapa) {
    if (!erroTransitorio(e)) return false;
    e.lentidao = true; // o orquestrador refaz o MESMO CNPJ (Chrome reaberto) em vez de passar ao próximo
    const nome = ETAPAS[etapa].nome;
    estado.repeticoes = estado.repeticoes || {};
    const feitas = estado.repeticoes[etapa] || 0;
    if (!naoRepetir(ETAPAS[etapa].rodar) && feitas < REPETICOES_POR_ETAPA) {
      estado.repeticoes[etapa] = feitas + 1;
      mostrarAviso(`Lentidão ou falha ao carregar: ${e.message}.\n` +
        `Aguardando alguns segundos e repetindo "${nome}" (${feitas + 1} de ${REPETICOES_POR_ETAPA})…`, 'erro');
      log(`lentidão na etapa "${nome}" (${e.message}); repetindo (${feitas + 1} de ${REPETICOES_POR_ETAPA})`);
      informarOrq('em_andamento', `lentidão; repetindo: ${nome}`);
      await gravarEstado();
      await sleep(rand(ESPERA_ANTES_DE_REPETIR_MS[0], ESPERA_ANTES_DE_REPETIR_MS[1]));
      return true;
    }
    const voltarPara = etapaAposRecarga(etapa);
    const recargas = estado.recargasLentidao || 0;
    if (voltarPara !== null && recargas < RECARGAS_POR_LENTIDAO) {
      estado.recargasLentidao = recargas + 1;
      estado.repeticoes = {};
      estado.etapa = voltarPara;
      mostrarAviso(`A etapa "${nome}" continua sem resposta (${e.message}).\n` +
        `Recarregando a página (F5) e retomando do mesmo ponto (${estado.recargasLentidao} de ${RECARGAS_POR_LENTIDAO})…`, 'erro');
      log(`lentidão persistente em "${nome}"; recarregando a página (${estado.recargasLentidao} de ${RECARGAS_POR_LENTIDAO})`);
      informarOrq('em_andamento', `lentidão; recarregando a página (${nome})`);
      await gravarEstado();
      await sleep(rand(2500, 4000));
      location.reload();
      await new Promise(() => {}); // a página vai recarregar: o script novo retoma de onde parou
    }
    return false;
  }

  async function executar() {
    executando = true;
    cancelado = false;
    criarSeta(estado.cursor);
    let etapa = estado.etapa;
    await carregarOrquestrador();
    try {
      // modo orquestrador: só o CNPJ definido em cnpjs.json (nunca outro cliente)
      if (ORQ && estado.cnpj && estado.cnpj !== ORQ.cnpj) {
        throw new Error(`o CNPJ desta execução (${formatarCnpj(estado.cnpj)}) não é o definido pelo orquestrador (${formatarCnpj(ORQ.cnpj)})`);
      }
      // Caixa Postal do e-CAC em andamento (print ou espera pela leitura): termina isso antes de voltar às etapas
      if (estado.caixaPostalAtual || estado.aguardandoCaixaPostal) etapa = await retomarCaixaPostal();
      for (; etapa < ETAPAS.length; etapa++) {
        estado.etapa = etapa;
        await gravarEstado();
        log(`ETAPA ${etapa + 1} de ${ETAPAS.length}: ${ETAPAS[etapa].nome}`);
        informarOrq('em_andamento', ETAPAS[etapa].nome);
        try {
          await aceitarCookiesPgfn(); // aba do SISPAR: o aviso de cookies cobre a parte de baixo da página
          await ETAPAS[etapa].rodar();
        } catch (e) {
          if (!await tratarLentidao(e, etapa)) throw e;
          etapa = Math.max(etapa, estado.etapa) - 1; // repete a mesma etapa (ou a gravada por ela, se avançou)
          continue;
        }
        if (estado.repeticoes) delete estado.repeticoes[etapa];
        // Etapa concluída = houve progresso: zera o contador de recargas (ele só existe para pegar repetição sem fim).
        estado.retomadas = 0;
        // A etapa pode ter gravado de onde continuar (antes de um clique que recarrega): não volta para trás.
        if (estado.etapa > etapa) etapa = estado.etapa - 1;
      }
      mostrarAviso(estado.fim, 'ok');
      // fim do CNPJ (todos os arquivos já salvos e conferidos): o orquestrador fecha o Chrome e passa ao próximo
      if (ORQ && estado.cnpjFinalizado) await finalizarOrq('concluido', estado.fim);
    } catch (e) {
      if (e.cancelado) {
        mostrarAviso(e.message);
        cursor.el && cursor.el.remove();
        cursor.el = null;
        await finalizarOrq('erro', e.message);
      } else {
        console.error(PREFIXO, e);
        const nomeEtapa = ETAPAS[etapa] ? ETAPAS[etapa].nome : 'Caixa Postal';
        mostrarAviso(`Parei na etapa ${etapa + 1} de ${ETAPAS.length} (${nomeEtapa}): ${e.message}.\n` +
          'Confira a tela e clique no ícone da extensão para tentar de novo.', 'erro');
        // "[lentidao]": o orquestrador refaz este MESMO CNPJ (Chrome reaberto) em vez de passar ao próximo
        const marca = e.lentidao || erroTransitorio(e) ? '[lentidao] ' : '';
        await finalizarOrq('erro', `${marca}etapa ${etapa + 1} (${nomeEtapa}): ${e.message}`);
      }
    } finally {
      // Encerrada nesta aba: a partir daqui só recomeça pelo ícone. Sem isso, cada nova carga da tela inicial
      // trocaria o perfil de novo (e poderia ficar alternando entre os dois CNPJs sem parar).
      estado = null;
      executando = false;
      await mensagem({ tipo: 'estado-gravar', estado: { encerrado: true, t: Date.now() } });
    }
  }

  // Clique no ícone: inicia; se já estiver rodando, para.
  // "Sair com Segurança" do e-CAC (pedido pelo service worker no fim do CNPJ, só com o orquestrador)
  async function sairComSeguranca() {
    if (NO_REGULARIZE || NO_SISPARNET || NA_LOGIN_ECAC || NO_SSO) return { ok: true, clicou: false, motivo: 'não é uma página do e-CAC com login' };
    const achar = () => {
      const el = acharBlocoMenu(TEXTO_SAIR_SEGURANCA) ||
        [...document.querySelectorAll('a, button, input[type="button"], input[type="image"]')]
          .find((e) => chave(e.title || e.getAttribute('alt') || e.value || '') === chave(TEXTO_SAIR_SEGURANCA) && visivel(e));
      return el ? (el.closest('a, button, input, [role="button"]') || el) : null;
    };
    // 0.34.0: janela "Alterar perfil de acesso" aberta (ex.: sem procuração) fica POR CIMA e o clique no "Sair" não
    // encerrava a sessão (10/11 09:52). Primeiro fecha a janela pelo X; depois clica; se a página não sair, tenta de novo.
    const janelaFechada = await fecharJanelaPerfil();
    let botao = achar();
    if (!botao) return { ok: true, clicou: false, janelaFechada, motivo: `não achei "${TEXTO_SAIR_SEGURANCA}" nesta página (sem sessão ativa?)` };
    if (!cursor.el) criarSeta(null);
    const urlAntes = location.href;
    for (let tent = 1; tent <= 2; tent++) {
      mostrarAviso(`fim do CNPJ: encerrando a sessão do e-CAC ("${TEXTO_SAIR_SEGURANCA}") antes de fechar o Chrome…` +
        (tent > 1 ? `\n(a página não saiu; tentando de novo, ${tent} de 2)` : ''));
      await sleep(rand(600, 1100));
      await clicarEm(botao, `botão "${TEXTO_SAIR_SEGURANCA}"`);
      // saiu = a página muda (este script deixa de existir); continua aqui só se nada aconteceu
      await sleep(7000);
      if (location.href !== urlAntes) return { ok: true, clicou: true, janelaFechada, tentativas: tent };
      await fecharJanelaPerfil();
      botao = achar();
      if (!botao) return { ok: true, clicou: true, janelaFechada, tentativas: tent };
    }
    // último recurso: o próprio endereço do "Sair com Segurança" (o mesmo que o clique abriria)
    const href = botao.getAttribute && botao.getAttribute('href');
    if (href && /^(https?:|\/)/i.test(href) && !/^javascript:/i.test(href)) {
      log(`"${TEXTO_SAIR_SEGURANCA}" não respondeu ao clique; abrindo o endereço dele: ${href}`);
      location.assign(new URL(href, location.href).href);
      return { ok: true, clicou: true, janelaFechada, viaEndereco: true };
    }
    return { ok: true, clicou: false, janelaFechada, motivo: `cliquei 2 vezes em "${TEXTO_SAIR_SEGURANCA}" e a página não saiu` };
  }

  chrome.runtime.onMessage.addListener((msg, _remetente, responder) => {
    if (msg.tipo === 'sair-ecac') {
      sairComSeguranca().then(responder, (e) => responder({ ok: false, erro: e.message }));
      return true;
    }
    if (msg.tipo !== 'icone') return false;
    responder({ ok: true });
    if (executando) cancelado = true;
    else iniciar();
    return false;
  });

  function iniciar() {
    estado = { etapa: 0, cnpj: null, cursor: cursor.el ? { x: cursor.x, y: cursor.y } : null, retomadas: 0 };
    executar();
  }

  // Começa sozinha só na tela inicial; nas outras telas do e-CAC, só pelo ícone.
  async function iniciarSeTelaInicial() {
    if (!INICIAR_NA_TELA_INICIAL || NO_REGULARIZE || NO_SISPARNET) return;
    const inicio = Date.now();
    while (Date.now() - inicio < ESPERA_TELA_INICIAL_MS) {
      if (executando) return;
      if ((acharTexto(TEXTO_TELA_INICIAL) && acharBotaoPerfil()) || acharIrCaixaPostal()) { // o aviso da Caixa Postal pode cobrir a tela inicial
        log('tela inicial do e-CAC reconhecida; iniciando');
        iniciar();
        return;
      }
      await new Promise((r) => setTimeout(r, 200));
    }
  }

  // ------------------------------- login (só com o orquestrador) -------------------------------
  // e-CAC (cav.receita.fazenda.gov.br/autenticacao): clica em "Entrar com gov.br".
  // gov.br (sso.acesso.gov.br): clica em "Seu certificado digital"; o ajudante do Windows escolhe na janela do Chrome
  // o certificado configurado em cnpjs.json (com o mouse, conferindo o nome) e clica em OK.
  // Captcha, PIN, senha, autorização ou tela desconhecida: a automação PAUSA, avisa e espera você; quando a página
  // muda (você resolveu), o fluxo continua sozinho — na tela inicial do e-CAC a automação começa como sempre.
  const NA_LOGIN_ECAC = !EM_QUADRO && /(^|\.)cav\.receita\.fazenda\.gov\.br$/.test(location.hostname) && /^\/autenticacao/i.test(location.pathname);
  const NO_SSO = !EM_QUADRO && /(^|\.)sso\.acesso\.gov\.br$/.test(location.hostname);
  const ESPERA_LOGIN_MS = 30000;

  // Desafio de captcha visível (o captcha invisível não aparece; só o desafio, que é para você resolver).
  function captchaVisivel() {
    for (const f of document.querySelectorAll('iframe')) {
      const src = f.src || '';
      if (!/hcaptcha|recaptcha|captcha/i.test(src)) continue;
      const r = f.getBoundingClientRect();
      if (r.width > 120 && r.height > 120 && visivel(f)) return true;
    }
    return !!acharTexto('Não sou um robô') || !!acharTexto('Selecione todas as imagens');
  }

  async function pausarParaHumano(texto) {
    mostrarAviso(`PAUSA: ${texto}\nResolva na tela; a automação continua sozinha depois.`, 'erro');
    await informarOrq('aguardando_humano', texto);
    // fica avisando o orquestrador enquanto espera (a página nova, quando vier, continua o fluxo)
    for (;;) {
      await new Promise((r) => setTimeout(r, 60000));
      await informarOrq('aguardando_humano', texto);
    }
  }

  async function loginEcac() {
    mostrarAviso('login: aguardando a página de acesso do e-CAC carregar…');
    await esperar(() => document.readyState === 'complete', 'o fim do carregamento da página', ESPERA_LOGIN_MS);
    const acharBotao = () => {
      const img = [...document.querySelectorAll('input[type="image"], img, button, a')]
        .find((e) => /gov\s*\.?\s*br/i.test(`${e.alt || ''} ${e.title || ''} ${e.getAttribute('src') || ''} ${e.textContent || ''}`) &&
          /acesso|entrar|gov-br\.png/i.test(`${e.alt || ''} ${e.textContent || ''} ${e.getAttribute('src') || ''}`) && visivel(e));
      return img ? (img.closest('a, button') || img) : null;
    };
    let botao;
    try {
      botao = await esperar(acharBotao, 'o botão "Entrar com gov.br"', ESPERA_LOGIN_MS);
    } catch (e) {
      if (!e.tempoEsgotado) throw e;
      if (captchaVisivel()) return pausarParaHumano('apareceu um captcha na página de acesso do e-CAC');
      // 0.36.0: página de acesso sem o botão não é tarefa para você (em 10/11/2026 14:55 a automação ficou parada aqui,
      // "aguardando você", sem prazo). Recarrega 1 vez; se continuar sem o botão, avisa o orquestrador com "[lentidao]":
      // ele fecha o Chrome e refaz o MESMO CNPJ (até 3 vezes; depois pausa como travamento).
      const CHAVE = 'pgfn_login_sem_botao';
      let feitas = 0;
      try { feitas = Number(sessionStorage.getItem(CHAVE) || 0); } catch (_) { /* sem sessionStorage */ }
      if (feitas < 1) {
        try { sessionStorage.setItem(CHAVE, String(feitas + 1)); } catch (_) { /* segue */ }
        mostrarAviso('login: não encontrei o botão "Entrar com gov.br"; recarregando a página de acesso (1 de 1)…', 'erro');
        await informarOrq('em_andamento', 'login: página de acesso sem o botão "Entrar com gov.br"; recarregando');
        await sleep(rand(2000, 3000));
        location.reload();
        return new Promise(() => {});
      }
      try { sessionStorage.removeItem(CHAVE); } catch (_) { /* nada */ }
      const texto = '[lentidao] login: não encontrei o botão "Entrar com gov.br" na página de acesso do e-CAC (já recarreguei 1 vez); ' +
        'reabrindo o Chrome para refazer este CNPJ';
      mostrarAviso(texto.replace('[lentidao] ', ''), 'erro');
      await finalizarOrq('erro', texto);
      return null;
    }
    try { sessionStorage.removeItem('pgfn_login_sem_botao'); } catch (_) { /* nada */ }
    await sleep(rand(1200, 2200)); // "lê" a página
    await informarOrq('em_andamento', 'login: entrando com gov.br');
    mostrarAviso('login: clicando em "Entrar com gov.br"…');
    await clicarEm(botao, 'botão "Entrar com gov.br"');
    // a página deve ir para o gov.br; se aparecer um desafio de captcha, é com você
    const fim = Date.now() + ESPERA_LOGIN_MS;
    while (Date.now() < fim) {
      await sleep(1000);
      if (captchaVisivel()) return pausarParaHumano('apareceu um captcha no login do e-CAC');
    }
    return pausarParaHumano('cliquei em "Entrar com gov.br" e a página não mudou');
  }

  async function loginGovBr() {
    mostrarAviso('login: aguardando a página do gov.br carregar…');
    await esperar(() => document.readyState === 'complete', 'o fim do carregamento da página', ESPERA_LOGIN_MS);
    // texto exato "Seu certificado digital" (não "Seu certificado digital em nuvem")
    const acharCertificado = () => {
      const t = acharBlocoMenu('Seu certificado digital');
      return t ? (t.closest('a, button, [role="button"], li') || t) : null;
    };
    let opcao = null;
    const fim = Date.now() + ESPERA_LOGIN_MS;
    while (!opcao && Date.now() < fim) {
      if (captchaVisivel()) return pausarParaHumano('apareceu um captcha no gov.br');
      opcao = acharCertificado();
      if (!opcao) await sleep(500);
    }
    if (!opcao) return pausarParaHumano('o gov.br mostrou uma tela que a automação não conhece (ex.: autorização, código, senha)');
    await sleep(rand(1200, 2200)); // "lê" as opções
    await informarOrq('em_andamento', `login: certificado digital (${ORQ.certificado})`);
    mostrarAviso(`login: clicando em "Seu certificado digital"…\nCertificado configurado: ${ORQ.certificado}`);
    // o ajudante começa a esperar a janela "Selecione um certificado" antes do clique (a página muda com ele)
    // exato (configurado na interface): só o certificado com exatamente esse nome; nunca por aproximação
    const escolha = mensagem({ tipo: 'certificado-selecionar', nome: ORQ.certificado, exato: !!ORQ.certificadoExato });
    await clicarEm(opcao, 'opção "Seu certificado digital"');
    mostrarAviso(`login: escolhendo o certificado "${ORQ.certificado}" na janela do Chrome…`);
    const r = await escolha;
    if (!r || !r.ok) {
      const lista = r && r.disponiveis && r.disponiveis.length ? `\nCertificados na janela: ${r.disponiveis.join(' | ')}` : '';
      return pausarParaHumano(`não escolhi o certificado: ${(r && r.erro) || 'sem resposta do ajudante'}${lista}`);
    }
    mostrarAviso(`login: certificado "${r.certificado}" escolhido; entrando…`);
    // se o login não sair desta página (PIN, senha, autorização…), é com você
    await sleep(ESPERA_LOGIN_MS);
    if (captchaVisivel()) return pausarParaHumano('apareceu um captcha no gov.br');
    return pausarParaHumano('o certificado foi escolhido, mas o login não terminou (PIN, senha ou confirmação?)');
  }

  // ---- erro 93003: "Você atingiu o número máximo de dispositivos conectados simultaneamente com esta conta" ----
  // A página do erro também fica em /autenticacao: sem esta checagem, o fluxo de login procurava "Entrar com gov.br" nela.
  // A automação não tem sessão própria para encerrar aqui (as suas são encerradas no fim de cada CNPJ); as que sobram
  // são de outros navegadores/computadores ou antigas, ainda não expiradas. Espera e tenta entrar de novo, até 3 vezes
  // (a contagem fica na aba e zera quando o e-CAC abre); depois PAUSA para você. Nunca passa ao próximo CNPJ por isso.
  const telaMaximoDispositivos = () => /\/erro\/93003/i.test(location.pathname) || !!acharTexto(TEXTO_MAXIMO_DISPOSITIVOS);
  const CHAVE_93003 = 'pgfn_tentativas_93003';
  async function tratarMaximoDispositivos() {
    let n = 1;
    try { n = Number(sessionStorage.getItem(CHAVE_93003) || 0) + 1; sessionStorage.setItem(CHAVE_93003, String(n)); } catch (_) { /* sem contagem */ }
    const texto = 'o e-CAC recusou o login (código 93003): "Você atingiu o número máximo de dispositivos conectados ' +
      'simultaneamente com esta conta"';
    log(`erro 93003 (tentativa ${n} de ${ESPERAS_93003_S.length})`);
    if (n > ESPERAS_93003_S.length) {
      return pausarParaHumano(`${texto}, ${ESPERAS_93003_S.length} vezes seguidas. Há sessões do e-CAC desta conta abertas ` +
        'em outro navegador ou computador (ou ainda não expiradas). Encerre-as com "Sair com Segurança" e depois clique em ' +
        '"Retornar para a página inicial do e-CAC": a automação continua o MESMO CNPJ');
    }
    const s = ESPERAS_93003_S[n - 1];
    await informarOrq('em_andamento', `${texto}; aguardando ${s} s para tentar de novo (${n} de ${ESPERAS_93003_S.length})`);
    const fim = Date.now() + s * 1000;
    while (Date.now() < fim) {
      mostrarAviso(`${texto}.\nAs sessões antigas ainda contam no servidor. Tentando entrar de novo em ` +
        `${Math.ceil((fim - Date.now()) / 1000)} s (${n} de ${ESPERAS_93003_S.length}). Este CNPJ não será pulado.`, 'erro');
      await sleep(1000);
    }
    location.assign(`${location.origin}/autenticacao`);
    await new Promise(() => {}); // a página vai mudar: o login recomeça
  }

  // ---- erro 10000 da Receita Federal (09/11/2026 15:18): "Prezado Usuário, não foi possível validar os seus dados nas
  // bases cadastrais da Receita Federal. Por favor, tente mais tarde." (endereço /autenticacao/Error/Erro/10000) ----
  // É indisponibilidade da Receita, não lentidão: não há botão "Entrar com gov.br" para procurar. Salva o print da
  // página em <CNPJ>\Problema_receita_federal_<CNPJ>.pdf (CNPJ da vez no orquestrador), confere no disco e encerra este
  // CNPJ como "erro" (não concluído; o orquestrador segue para o próximo e o tenta de novo na próxima execução).
  // Uma vez só: nada de recarregar ou tentar o login de novo.
  // Print da página de erro (inteira) em <CNPJ>\<nome>, conferido no disco e na pasta. Nunca substitui ("(1)").
  async function salvarPrintDeErro(cnpj, nome) {
    await sleep(rand(1200, 2000)); // a página termina de desenhar
    let caminho = null, problema = null;
    try {
      caminho = await printPaginaInteiraAqui(`${pastaDocumentos()}/${cnpj}`, nome);
      const disco = await mensagem({ tipo: 'conferir-arquivo', caminho });
      if (disco && disco.ok && (!disco.existe || !disco.pdf || !disco.bytes)) problema = `o print não ficou salvo corretamente (${caminho})`;
      else if (!new RegExp(`[\\\\/]${cnpj}[\\\\/]`).test(caminho || '')) problema = `o print foi salvo fora da pasta do CNPJ (${caminho})`;
    } catch (e) {
      if (e.cancelado) throw e;
      problema = `não consegui salvar o print: ${e.message}`;
    }
    return { caminho, problema };
  }

  // ---- erro 500 do e-CAC: "Atenção. (Código: 500 - …) Ocorreu um erro interno na aplicação." (endereço
  // /autenticacao/Error/ErrorHttp?500) ----
  // Pode ser falha passageira do servidor: até 5 tentativas POR CNPJ, com espera crescente. As 2 primeiras recarregam a
  // página; as seguintes voltam à página de acesso do e-CAC (/autenticacao) e refazem o login de forma controlada (uma
  // entrada por tentativa, sem abrir outra aba). A contagem fica na aba (sessionStorage, por CNPJ): sobrevive aos
  // recarregamentos e não zera quando o acesso volta (o limite é do CNPJ). Voltando o acesso, o fluxo continua o MESMO
  // CNPJ pelo andamento gravado (registro de PDFs já salvos impede emitir de novo). Esgotadas: print em
  // <CNPJ>\Erro_500_<CNPJ>.pdf e o CNPJ fica não concluído ("erro"; o orquestrador segue e o tenta na próxima execução).
  const TEXTO_ERRO_500 = 'Ocorreu um erro interno na aplicação';
  const ESPERAS_500_S = [15, 30, 60, 90, 120]; // espera antes de cada tentativa (crescente)
  const RECARGAS_500 = 2; // tentativas que só recarregam; as demais voltam ao acesso do e-CAC
  const telaErro500 = () => !!acharTexto(TEXTO_ERRO_500) &&
    (/\/errorhttp/i.test(location.pathname) && /^\?500\b/.test(location.search) || /c[oó]digo:\s*500\b/i.test(document.body ? document.body.innerText : ''));
  async function tratarErro500() {
    const cnpj = ORQ && ORQ.cnpj;
    if (!/^\d{14}$/.test(cnpj || '') || !cnpjValido(cnpj)) {
      return pausarParaHumano('o e-CAC mostrou "Ocorreu um erro interno na aplicação" (código 500) e não sei com segurança ' +
        'qual é o CNPJ da vez; não tentei de novo nem salvei o print');
    }
    const chave = `pgfn_tentativas_500_${cnpj}`;
    let feitas = 0;
    try { feitas = Number(sessionStorage.getItem(chave) || 0); } catch (_) { /* sem contagem: vale 0 */ }
    const texto = `o e-CAC mostrou um erro interno (código 500: "Ocorreu um erro interno na aplicação") no CNPJ ${formatarCnpj(cnpj)}`;
    log(`erro 500 do e-CAC, CNPJ ${cnpj}: ${feitas} tentativa(s) feita(s) de ${ESPERAS_500_S.length}`);
    if (feitas >= ESPERAS_500_S.length) {
      mostrarAviso(`${texto}, ${feitas} tentativas sem sucesso.\nSalvando o print da página…`, 'erro');
      await informarOrq('em_andamento', `erro 500 do e-CAC depois de ${feitas} tentativas; salvando o print`);
      const { caminho, problema } = await salvarPrintDeErro(cnpj, `Erro_500_${cnpj}.pdf`);
      if (problema) {
        log(`erro 500, CNPJ ${cnpj}: ${problema}`);
        return pausarParaHumano(`${texto}, ${feitas} tentativas. ${problema}. Salve o print desta página na pasta ${cnpj} e feche o Chrome para seguir`);
      }
      log(`erro 500, CNPJ ${cnpj}: ${feitas} tentativas sem sucesso; print salvo em ${caminho}`);
      const final = `${texto}.\nNão concluído (pendente por erro interno da Receita Federal): ${feitas} tentativas de ` +
        `recuperação sem sucesso; tentar de novo na próxima execução.\nPrint salvo em PDF:\n${caminho}`;
      mostrarAviso(`${final}\nSeguindo para o próximo CNPJ…`, 'erro');
      await finalizarOrq('erro', final);
      return;
    }
    const n = feitas + 1;
    try { sessionStorage.setItem(chave, String(n)); } catch (_) { /* sem contagem */ }
    const recarregar = n <= RECARGAS_500;
    const acao = recarregar ? 'recarregar a página' : 'voltar à página de acesso do e-CAC e entrar de novo';
    const s = ESPERAS_500_S[n - 1];
    await informarOrq('em_andamento', `${texto}; tentativa ${n} de ${ESPERAS_500_S.length} em ${s} s (${acao})`);
    const fim = Date.now() + s * 1000;
    while (Date.now() < fim) {
      mostrarAviso(`${texto}.\nPode ser falha passageira do servidor. Tentativa ${n} de ${ESPERAS_500_S.length} em ` +
        `${Math.ceil((fim - Date.now()) / 1000)} s (${acao}). Este CNPJ não será pulado antes disso.`, 'erro');
      await sleep(1000);
    }
    log(`erro 500, CNPJ ${cnpj}: tentativa ${n} de ${ESPERAS_500_S.length}: ${acao}`);
    if (recarregar) location.reload();
    else location.assign(`${location.origin}/autenticacao`);
    await new Promise(() => {}); // a página vai mudar
  }

  const TEXTO_ERRO_10000 = 'não foi possível validar os seus dados nas bases cadastrais da Receita Federal';
  const telaErro10000 = () => !!acharTexto(TEXTO_ERRO_10000) &&
    (/\/erro\/10000(\/|\?|$)/i.test(location.pathname + location.search) || /c[oó]digo:\s*10000\b/i.test(document.body ? document.body.innerText : ''));
  async function tratarErro10000() {
    const cnpj = ORQ && ORQ.cnpj;
    log(`erro 10000 da Receita Federal na página ${location.pathname} (CNPJ da vez: ${cnpj || 'desconhecido'})`);
    if (!/^\d{14}$/.test(cnpj || '') || !cnpjValido(cnpj)) {
      return pausarParaHumano('a Receita Federal recusou o acesso (código 10000: "não foi possível validar os seus dados nas ' +
        'bases cadastrais"), e não sei com segurança qual é o CNPJ da vez; não salvei o print para não errar a pasta');
    }
    const texto = `Receita Federal indisponível para o CNPJ ${formatarCnpj(cnpj)} (código 10000: "Prezado Usuário, não foi ` +
      'possível validar os seus dados nas bases cadastrais da Receita Federal. Por favor, tente mais tarde.")';
    mostrarAviso(`${texto}.\nSalvando o print da página…`, 'erro');
    await informarOrq('em_andamento', `erro 10000 da Receita Federal; salvando o print`);
    const { caminho, problema } = await salvarPrintDeErro(cnpj, `Problema_receita_federal_${cnpj}.pdf`);
    if (problema) {
      log(`erro 10000, CNPJ ${cnpj}: ${problema}`);
      return pausarParaHumano(`${texto}. ${problema}. Salve o print desta página na pasta ${cnpj} e feche o Chrome para seguir`);
    }
    log(`erro 10000, CNPJ ${cnpj}: print salvo em ${caminho}`);
    const final = `${texto}.\nNão concluído: a Receita Federal não validou o acesso; tentar de novo mais tarde.\n` +
      `Print salvo em PDF:\n${caminho}`;
    mostrarAviso(`${final}\nSeguindo para o próximo CNPJ…`, 'erro');
    await finalizarOrq('erro', final);
  }

  async function fluxoLogin() {
    const r = await mensagem({ tipo: 'orq-atual' });
    if (!await carregarOrquestrador()) {
      // 0.33.1: a lista terminou (ou a execução foi parada): diz isso claramente, sem pedir login (não está travado)
      if (r && r.ok && r.fim && r.motivo) { mostrarAviso(r.motivo + '.', r.encerramento === 'erro' ? 'erro' : 'ok'); return; }
      // sem orquestrador, o login é com você (como antes); o aviso diz por quê, para não ficar parado sem explicação
      mostrarAviso('login automático desligado: ' + (r && r.ok ? (r.motivo || 'o orquestrador não está rodando')
        : `o ajudante do Windows não respondeu (${(r && r.erro) || 'sem resposta da extensão'})`) + '.\nFaça o login você mesmo.');
      return;
    }
    if (NA_LOGIN_ECAC && telaMaximoDispositivos()) {
      try { await tratarMaximoDispositivos(); } catch (e) { if (!e.cancelado) await pausarParaHumano(`erro 93003: ${e.message}`); }
      return;
    }
    if (NA_LOGIN_ECAC && telaErro10000()) {
      try { await tratarErro10000(); } catch (e) { if (!e.cancelado) await pausarParaHumano(`erro 10000 da Receita Federal: ${e.message}`); }
      return;
    }
    if (NA_LOGIN_ECAC && telaErro500()) {
      try { await tratarErro500(); } catch (e) { if (!e.cancelado) await pausarParaHumano(`erro 500 do e-CAC: ${e.message}`); }
      return;
    }
    criarSeta(null);
    try {
      if (NA_LOGIN_ECAC) await loginEcac();
      else await loginGovBr();
    } catch (e) {
      console.error(PREFIXO, e);
      await pausarParaHumano(`login: ${e.message}`);
    }
  }

  // Se a página mudar no meio, guarda onde a seta estava.
  addEventListener('pagehide', () => { if (executando && estado) gravarEstado(); });

  // Página nova com andamento gravado: continua de onde parou.
  (async () => {
    if (NA_LOGIN_ECAC || NO_SSO) { fluxoLogin(); return; } // páginas de login: só o fluxo de login
    // o e-CAC abriu (login feito): zera a contagem de tentativas do erro 93003 nesta aba
    if (!NO_REGULARIZE && !NO_SISPARNET) { try { sessionStorage.removeItem(CHAVE_93003); } catch (_) { /* nada a zerar */ } }
    const salvo = await mensagem({ tipo: 'estado-ler' });
    if (executando || (salvo && salvo.encerrado)) return;
    if (salvo && Date.now() - salvo.t > VALIDADE_ANDAMENTO_MS) {
      await mensagem({ tipo: 'estado-gravar', estado: null });
      iniciarSeTelaInicial();
      return;
    }
    if (!salvo) { iniciarSeTelaInicial(); return; }
    // esperando você ler a Caixa Postal: as páginas que você abre não contam como "a página mudou"
    if (salvo.aguardandoCaixaPostal) salvo.retomadas = Math.max(0, (salvo.retomadas || 0) - 1);
    if (salvo.retomadas >= LIMITE_RETOMADAS) {
      await mensagem({ tipo: 'estado-gravar', estado: { encerrado: true, t: Date.now() } });
      mostrarAviso(`A página mudou ${LIMITE_RETOMADAS} vezes seguidas durante a automação, então parei.\n` +
        'Confira a tela e clique no ícone da extensão para tentar de novo.', 'erro');
      return;
    }
    estado = { ...salvo, retomadas: salvo.retomadas + 1 };
    // Já clicou em "Alterar": continua da etapa gravada. Antes disso, a janela não sobrevive à troca de página:
    // volta à etapa que a abre (ela pula o clique se a janela estiver aberta).
    if (!NO_REGULARIZE && !NO_SISPARNET && estado.etapa < ETAPA_CONFERIR_TOPO) estado.etapa = estado.cnpj ? Math.min(estado.etapa, 1) : 0;
    log(`a página mudou; retomando (${estado.retomadas}ª vez) em: ${ETAPAS[estado.etapa].nome}`);
    executar();
  })();
})();
