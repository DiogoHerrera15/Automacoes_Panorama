# CONTEXTO PARA UM NOVO CHAT — Automação PGFN

> Resumo técnico completo para outro chat do Claude entender o projeto e **continuar exatamente do estado atual**.
> Atualizado em 10/11/2026: **v0.36.0 + ajudante 1.8** (antes: 0.35.0; 0.34.0 + 1.7).
> - 0.39.0: aviso de Caixa Postal → print do AVISO (sem clicar em "Ir para a Caixa Postal") + situação final `caixa_postal` + próximo CNPJ: ver 6.16 (substitui o que 6.3/6.4 dizem da Caixa Postal).
> - 0.38.0 + ajudante 1.9: janela "Selecione um certificado" percorrida INTEIRA pelo teclado (lista com rolagem): ver 6.15.
> - 0.37.0: aviso "foi cancelada em" (procuração cancelada) → situação própria `procuracao_cancelada` + print em `<CNPJ>\Procuracao_Cancelada\`: ver 6.14.
> - 0.36.1: print `Sem_Procuracao_<CNPJ>.pdf` só com a mensagem visível + conferência no disco + print também no modo manual: ver 6.13.
> - 0.36.0: "Você não tem permissão de acesso ou ele expirou" no SISPAR → mesmo CNPJ refeito com o Chrome reaberto (até 3x): ver 6.12.
> - 0.35.0: salvamento do PDF com número de download repetido e "encerrar e avançar" depois de 3 tentativas: ver 6.11.
> - Sem procuração definitivo, "Sair" com a janela de perfil aberta e contador de progresso: ver 6.8 e 6.9.
> - A 0.33.1 explicou o fim da lista na tela.
>
> **Leia junto:**
> - `ESTADO_ATUAL.md`: o que funciona, o que está pendente e onde paramos;
> - `HISTORICO_PROJETO.md`: a ordem cronológica dos pedidos e das soluções;
> - as conversas completas em `Historico_conversas\`.

---

## 1. Objetivo e funcionamento geral

Extensão do Google Chrome (Manifest V3, **sem Playwright nem Selenium**) que faz, como uma pessoa faria, o caminho:
**e-CAC (Receita) → Regularize (PGFN) → SISPAR → emissão dos documentos de arrecadação das negociações "DEFERIDA E CONSOLIDADA"**.
Ela salva os PDFs, os prints de conferência e um relatório numa pasta por certificado e por CNPJ.

Para muitos CNPJs, quem controla é um **orquestrador** (PowerShell). Para cada CNPJ, ele:
1. fecha todo o Chrome;
2. abre uma janela **anônima** no login do e-CAC;
3. deixa a extensão entrar com o **certificado digital** configurado e fazer o fluxo;
4. registra o resultado e passa ao próximo.

A **interface** `Interface\Automacao_PGFN.exe` cadastra certificado e lista de CNPJs, inicia, pausa, retoma, para e mostra o andamento.
Um **ajudante do Windows** faz o que a extensão não consegue fazer dentro do Chrome:
- escolher o certificado na janela do Chrome;
- confirmar a janela "Salvar como";
- conferir o PDF no disco;
- ser o canal entre a extensão e o orquestrador.

**Tudo roda localmente no Windows, sem depender do Claude.**

---

## 2. Duas pastas: qual é qual (importante)

| Pasta | Papel hoje |
|---|---|
| `C:\Users\PANORAMA-PC\Downloads\Auto_PGFN\` | **Instalação ATIVA neste computador.** A extensão carregada no Chrome (ID `hljabalaigcloapogemdonfjdpenfiff`) e o ajudante registrado no Windows são desta pasta. As configurações e os andamentos em uso estão em `Auto_PGFN\configuracoes\`. Os documentos vão para `Auto_PGFN\Documentos_arrecadacao\<CERT>\<CNPJ>`. |
| `C:\Users\PANORAMA-PC\Downloads\ATM_PGFN\` | **Versão de distribuição** (mesmo código, com caminhos portáteis), para outros computadores. Ainda **não** está ativa neste PC. Os documentos dela vão para `<Downloads do Chrome>\ATM_PGFN\Documentos_arrecadacao\<CERT>\<CNPJ>`. O `ATM_PGFN.zip` (em `Downloads\`) é gerado a partir dela. |

**Regra de manutenção:** toda mudança no código tem de ir **para as duas pastas**.
- O caminho usado até agora: editar na `Auto_PGFN`, testar e levar para a ATM com `Desenvolvimento\ferramentas\sincronizar_atm.js`. Ele copia os arquivos e reaplica as trocas de caminho da ATM (`regras_atm.json` e `regras_atm2.json`).
- A interface (`.cs`) é editada nas duas pastas e compilada com `compilar.bat` em cada uma.
- Depois de mudar a ATM, gere o zip de novo: `Instalador\gerar_pacote.ps1`.
- Se o usuário passar a usar a ATM neste PC (remover a extensão antiga, carregar `ATM_PGFN\Extensao_Chrome`, rodar `ATM_PGFN\Instalar.bat`), a ATM vira a principal.

Diferenças de caminho entre as duas pastas:

| Componente | Auto_PGFN | ATM_PGFN |
|---|---|---|
| Extensão | `Automação_PGFN\` | `Extensao_Chrome\` |
| Ajudante | `ajudante_salvar_como\` | `Ajudante_Windows\` |
| Orquestrador | `orquestrador\` | `Automacao\` |
| Interface | `interface\` + exe na raiz | `Interface\` (exe dentro) |
| Configurações | `configuracoes\` | `Configuracoes\` |
| Instalador | `instalacao\` | `Instalador\` |
| Subpasta dos downloads (no content.js) | `Auto_PGFN/Documentos_arrecadacao` | `ATM_PGFN/Documentos_arrecadacao` |

---

## 3. Estrutura da pasta ATM_PGFN

```
ATM_PGFN\
├── Iniciar.bat                 abre a interface (se o .exe faltar, compila)
├── Instalar.bat                instalação guiada (Instalador\instalar.ps1); -SoVerificar só confere
├── README.md                   manual do usuário (instalação, uso, pastas, solução de problemas)
├── HISTORICO_PROJETO.md / CONTEXTO_NOVO_CHAT.md / ESTADO_ATUAL.md   continuidade (estes arquivos)
├── Interface\
│   ├── Automacao_PGFN.exe      interface (C# WinForms, .NET Framework 4)
│   ├── AutomacaoPGFN.cs        código da interface
│   └── compilar.bat            compila com o csc.exe do Windows (sem instalar nada)
├── Automacao\
│   ├── orquestrador.ps1        um CNPJ por vez; vigia de travamentos; pausa e parada
│   └── (gerados) orquestrador.log, atual.json, sinal.json, progresso.json, execucao.json,
│                 pausar.flag, parar.flag, registro_salvos.json, ultima_execucao.json (0.33.1)
├── Extensao_Chrome\            extensão (carregar sem compactação em chrome://extensions)
│   ├── manifest.json           v0.34.0
│   ├── content.js              fluxo inteiro nas páginas (≈3.700 linhas)
│   ├── background.js           service worker (≈700 linhas)
│   ├── pagina.js               mundo MAIN: intercepta window.open do SISPAR
│   └── offscreen.html / .js    junta as partes do print da página inteira num PDF
├── Ajudante_Windows\
│   ├── salvar_como.bat         o Chrome chama este .bat (NADA pode escrever na saída padrão nele)
│   ├── salvar_como.ps1         ajudante 1.7 (todas as ações)
│   ├── instalar_ajudante.bat/.ps1   registra o host no HKCU para o ID da extensão
│   ├── desinstalar_ajudante.bat
│   └── (gerados) com_auto_pgfn_salvar_como.json (manifesto do host), ajudante.log
├── Configuracoes\              <nome>.json (configuração) + <nome>.andamento.json (situação de cada CNPJ)
├── Instalador\
│   ├── instalar.ps1            confere pastas, Chrome, extensão, ajudante (testa o protocolo), interface, atalho
│   └── gerar_pacote.ps1        gera ..\ATM_PGFN.zip só com uma lista fechada de arquivos (sem dados)
├── Historico_conversas\        as 2 conversas completas exportadas (texto; sem saída de ferramentas)
└── Desenvolvimento\
    ├── CONTINUIDADE_AUTOMACAO_PGFN_ate_v0.33.md   documento técnico detalhado, versão a versão
    ├── testes\                 simulador local (server.js + páginas falsas) e testes automáticos
    └── ferramentas\            substituir.js, sincronizar_atm.js, regras_atm*.json, exportar_conversa.js, print_janela.ps1, clicar_gui.ps1
```

`Historico_conversas\`, `Desenvolvimento\` e `Configuracoes\*.json` têm **dados de clientes** (CNPJs e nomes). Eles **não entram** no `ATM_PGFN.zip`, porque o `gerar_pacote.ps1` usa uma lista fechada de arquivos.

---

## 4. Tecnologias e dependências

| Componente | Tecnologia |
|---|---|
| Extensão | JavaScript, Chrome Manifest V3 (content scripts em todos os quadros e um no mundo MAIN, service worker, documento offscreen). Permissões: `storage`, `downloads`, `offscreen`, `nativeMessaging`, `contentSettings`, `scripting`; `host_permissions: <all_urls>`; `"incognito": "spanning"`. |
| Ajudante | **Windows PowerShell 5.1**, UI Automation (`UIAutomationClient`), Win32 (`SendMessage`, `mouse_event`), native messaging do Chrome (4 bytes de tamanho + JSON). |
| Orquestrador | PowerShell 5.1. |
| Interface | C# 5 / WinForms / .NET Framework 4 (`csc.exe` de `C:\Windows\Microsoft.NET\Framework64\v4.0.30319`), `System.Web.Extensions` (JSON) e `X509Store` (certificados). |
| Testes | Node.js (simulador e testes do service worker); não é necessário para o uso. |

**Para usar:** Windows 10/11, Google Chrome e o certificado digital instalado no Windows. Não precisa de administrador.

**Cuidados técnicos obrigatórios:**
- **`.ps1`:** precisam de **UTF-8 com BOM**; sem BOM, os acentos quebram no PowerShell 5.1.
- **`.bat`:** precisam de **CRLF** e ASCII.
- **`.Count` no PS 5.1:** num objeto único é nulo; use `@(...)`.
- **Nomes de variável no PowerShell:** não diferenciam maiúsculas (`$Andamento` = `$andamento`; já causou um bug). Parâmetro tipado `[string]` converte o que recebe.
- **Chrome 157:** não aceita `--load-extension`; a extensão é carregada à mão ("Carregar sem compactação").
- **ID da extensão:** depende da pasta; mudou a pasta, roda o `Instalar.bat` de novo.

---

## 5. Comunicação entre os componentes

```
Interface (.exe) ──(inicia: powershell orquestrador.ps1 -Config <cfg> -Andamento <and>)──► Orquestrador
     ▲  lê: execucao.json, atual.json, sinal.json, progresso.json, <cfg>.andamento.json, orquestrador.log
     └─ escreve: pausar.flag / parar.flag (Pausar/Retomar/Parar)

Orquestrador ──escreve atual.json {cnpj, certificado, pastaCertificado, certificadoExato, sessao, pid}──►
             ──abre chrome --incognito https://cav.receita.fazenda.gov.br/autenticacao
             ◄─lê sinal.json (situação) e progresso.json (última ação + checkpoint)
             ──chama o ajudante direto (mesmo protocolo) para "janelas" / "cancelar-todas"

Extensão (content.js) ◄──chrome.runtime.sendMessage──► background.js ◄──sendNativeMessage──► salvar_como.bat → salvar_como.ps1
   ajudante: lê atual.json (orq-atual), grava sinal.json (orq-informar), progresso.json (orq-progresso),
             registro_salvos.json (registro-ver/gravar); escolhe certificado; confirma/cancela "Salvar como"; confere PDF
```

**Ações do ajudante (1.7):**

| Ação | Para que serve |
|---|---|
| `versao` | confere se o ajudante responde (devolve `1.7`) |
| `orq-atual` | devolve o CNPJ da vez, só se o processo do orquestrador estiver vivo. Desde a 1.6, quando não há CNPJ da vez: lê o `ultima_execucao.json` (válido 12 h) e devolve `fim:true`, `encerramento` e `motivo` ("AUTOMAÇÃO TERMINADA…", "PARADA…" etc.); com `atual.json` e o processo morto, devolve `parado:true` e um motivo |
| `orq-informar` | grava o andamento no `sinal.json`; só aceita a sessão e o CNPJ do `atual.json` |
| `orq-progresso` | grava a última ação e o checkpoint no `progresso.json` |
| `certificado` | escolhe na janela "Selecione um certificado"; `exato` = nome inteiro; precisa de exatamente 1 |
| `confirmar` | confirma a janela "Salvar como": pasta do CNPJ, nome pedido ou o número do documento; corrige o caminho no campo "Nome" e nunca sobrescreve |
| `cancelar` | fecha a janela "Salvar como" deste documento |
| `janelas` | lista as janelas "Salvar como" abertas |
| `cancelar-todas` | fecha todas; só o vigia usa |
| `conferir` | o arquivo existe e começa com `%PDF`? (só dentro da pasta ATM_PGFN/Auto_PGFN) |
| `registro-ver` / `registro-gravar` | registro em disco dos PDFs já salvos |

**Mensagens principais da extensão** (content → background):
- `estado-ler/gravar` (estado da aba em `storage.session`);
- `download-preparar/status/limpar/cancelar/procurar/fechar-janela/url`;
- `capturar`, `print-inicio/parte/salvar`, `salvar-texto`, `conferir-arquivo`, `registro-ver/gravar`;
- `orq-atual/informar/finalizar/progresso`, `certificado-selecionar`, `sair-ecac`, `proximo-cnpj`, `transferencia-*`.

---

## 6. Fluxo completo de execução

### 6.1 Interface
0. **Contador (0.34.0):** lê o andamento da configuração e mostra:
   - "Total de CNPJs · Analisados · Progresso %";
   - "Concluídos · Com erro · Sem procuração · Restantes";
   - uma barra de progresso, o CNPJ em processamento (n de N) e a etapa atual.
   - Restantes = pendente ou em andamento. Analisados = o resto. Cada CNPJ conta uma vez.
   - **Botão "Refazer sem procuração":** os `sem_procuracao` voltam a `pendente`, com cópia `.antes_refazer_<data>`.
1. Configuração = nome + certificado (escolhido da lista do Windows: Pessoal, com chave privada e uso "Autenticação de Cliente"; o nome é o CN, igual ao do Chrome) + CNPJs (um por linha; dígitos conferidos; repetidos removidos).
2. Ao clicar em **Iniciar**, a interface confere o certificado:
   - não existe ou está vencido → não começa;
   - há 2 com o mesmo nome → pede confirmação, e no login a automação pausa para a pessoa escolher.
3. Então chama o orquestrador com a configuração e o andamento dela.

### 6.2 Orquestrador (para cada CNPJ não concluído e não `sem_procuracao`, na ordem)

**Situações** no `<cfg>.andamento.json`:
- `pendente`, `em_andamento`, `concluido`, `erro`;
- **`sem_procuracao`** (0.34.0): final como `concluido`, nunca tentado de novo sozinho.
- **Refeitos no próximo Iniciar:** o `erro` (500, 10000, lentidão etc.) e o `em_andamento`.
- **Linha `PROGRESSO: X de N analisados (P%) | concluídos | com erro | sem procuração | restantes`:** no início e depois de cada CNPJ terminado, ou seja, depois da recuperação.

1. Confere o pedido de **Parar** ou **Pausar** (só entre um CNPJ e outro).
2. CNPJ com dígito inválido → "erro", sem abrir o Chrome.
3. Antes de fechar o Chrome, fecha uma janela "Salvar como" que esteja aberta. Depois espera os `.crdownload` terminarem e **fecha todo o Chrome**.
4. Grava o `atual.json` e abre o Chrome anônimo. Se a extensão não der sinal em 40 s, reabre o endereço (até 2 vezes).
5. Acompanha o `sinal.json` e o `progresso.json` a cada 3 s:
   - **concluido / erro** → registra;
   - **Chrome fechado** pelo usuário → o CNPJ volta a "pendente" e o orquestrador **para**;
   - **vigia de travamento:** 8 min sem progresso (sem contar a espera por você) → fecha a janela "Salvar como", se houver, e espera 90 s; senão `[travamento]`.
6. `[travamento]` ou `[lentidao]` → reabre o Chrome **no mesmo CNPJ**, até 3 vezes. Depois **PAUSA**: o `pausar.flag` guarda o motivo; Retomar refaz o mesmo CNPJ e Parar encerra, com o CNPJ pendente.
7. Registra o checkpoint no andamento.
8. **Ao sair** (0.33.1), no `finally` e antes de apagar o `atual.json`, grava `ultima_execucao.json`:
   - `encerramento`: `terminou`, `parada`, `chrome_fechado` ou `erro`;
   - `nome`, `config`, `fim`, `total`, `concluidos`, `erros`, `pendentes`.
   - No fim da lista **não fecha o Chrome**: a última tela fica à vista, com o aviso de "terminada" (ver 6.8).

### 6.3 Extensão: login (páginas `cav…/autenticacao*` e `sso.acesso.gov.br`)
- **Antes do login,** reconhece as páginas de erro, nesta ordem:
  1. **93003:** espera 60, 180 e 300 s e tenta de novo; depois pausa;
  2. **10000:** print `Problema_receita_federal_<CNPJ>.pdf` e encerra como "erro";
  3. **500:** até 5 tentativas por CNPJ; depois print `Erro_500_<CNPJ>.pdf` e encerra como "erro".
- **Login:** "Entrar com gov.br" → "Seu certificado digital" → o ajudante escolhe o certificado com o mouse real e clica em OK.
  - **Captcha, PIN ou senha:** pausa ("aguardando_humano"), sem prazo. A automação **nunca digita** senha ou PIN.
- **Sem orquestrador** (modo manual): mostra "login automático desligado". A `CNPJS_TESTE` está **vazia**, para nunca processar um CNPJ fora da lista.

### 6.4 Extensão: e-CAC → Regularize
1. **Tela inicial do e-CAC:**
   - aviso "Prepare-se…" → "Continuar no e-CAC por enquanto";
   - **aviso da Caixa Postal** ("Você possui mensagens importantes"): print da Caixa Postal em `Caixa_Postal_<CNPJ>.pdf`, salvo uma vez só (há registro), **sem abrir mensagens**; se o e-CAC exigir a leitura, **pausa** até a página inicial voltar.
2. **"Alterar perfil de acesso":** digita o CNPJ tecla a tecla e clica no "Alterar" da mesma linha; confere o topo.
   - Sem procuração → erro de regra.
3. **"Dívida Ativa da União"** → "PGFN - Todos os serviços do Regularize".
   - Se não houver → o CNPJ é pulado e marcado como concluído, com o motivo.
4. **Regularize, numa janela nova:**
   - sem cadastro → `sem_cadastro_regularize.pdf`;
   - "CIENTE";
   - aviso de notificações → FECHAR.
5. **Entrada no SISPAR:** NEGOCIAR DÍVIDA → ACESSAR → no quadro do SISPAR (agente no iframe), CONSULTAR → CONTINUAR. Nunca clica em DESISTIR.
6. **Aba própria do SISPAR:** o `pagina.js` intercepta o `window.open` e a aba abre **uma vez**, porque o token é de uso único.

### 6.5 Extensão: SISPAR
1. **Cookies:** o aviso da PGFN é aceito ("Permitir") antes de cada etapa e de cada emissão.
2. **Menu:** hover em "Emissão de Documento" → clique em "Documento de arrecadação".
3. **Sem negociação** → print `CNPJ;NOME.pdf`.
4. **Lista de negociações:** ordena por "Situação da conta".
   - Nenhuma "DEFERIDA E CONSOLIDADA" → `Sem_Deferido_<CNPJ>.pdf`.
5. **Cada conta "DEFERIDA E CONSOLIDADA",** uma por vez:
   1. seleciona a linha e clica no botão "Documento de Arrecadação" abaixo da tabela;
   2. confere o "Contribuinte": tem de ser o CNPJ ativo;
   3. rola a tabela "Prestação" com a roda do mouse até a competência do **mês atual** (meses futuros não contam).

   Ícones da coluna "Emissão":

   | Ícone | O que a automação faz |
   |---|---|
   | verificado azul | nada (regular) |
   | **laranja** | já emitido: não emite de novo |
   | impressora | pendência: emite |
   | desconhecido | marca "VERIFICAR" no relatório |

6. **Emissão de uma pendência:**
   1. **Já salva neste mês?** O registro, no Chrome e em disco, impede emitir de novo.
   2. **Janela "Cálculo e demonstrativo":** confere a "Parcela para emissão". Se houver "Receita bruta" e "Calcular", clica em **Calcular com o valor apresentado** (não digita nada) e espera o "Emitir" ser liberado com "Valor da Prestação" maior que 0. Se não for liberado, **pausa** pedindo o dado.
   3. **Emitir** → página do PDF → link do PDF → salvamento (6.6) → **Voltar**.
7. **Fim da conta:** conferência final pela tela e print da página inteira `print_confirmacao[_conta_X].pdf`. O mesmo print, no mesmo dia e com a mesma situação, não é salvo de novo.
8. **Relatório** `.csv` e aviso final ao orquestrador. Antes do aviso, o background faz **"Sair com Segurança"** no e-CAC, para evitar o 93003.

### 6.6 Salvamento de PDFs
1. **Antes do clique:** a espera é "armada" (`download-preparar`). O primeiro download do site depois disso é renomeado em `onDeterminingFilename` para `<pasta>/<nome>.pdf`.
   - Cada download é identificado por **número + perfil** (normal ou anônimo), porque os dois perfis numeram por conta própria.
2. **Janela "Salvar como" aberta** (o download ainda não tem caminho):
   1. o ajudante `confirmar` faz até 3 tentativas. Aceita a janela com o nome pedido ou com o número do documento; se a pasta ou o nome estiverem errados, escreve o caminho completo e livre no campo "Nome" e clica em Salvar;
   2. esgotado → `cancelar` (fechamento controlado) → clica no link do PDF de novo, até 3 vezes;
   3. ainda sem sucesso → **PAUSA**, até a pessoa salvar e o PDF certo estar no disco.
3. **Sem download associado:** `download-procurar` acha o download do site que começou depois do clique (só com 1 candidato).
4. **Validação final:**
   - o download está completo e o arquivo é `.pdf`;
   - fica na pasta do CNPJ;
   - o nome é o pedido, ou contém o número do documento;
   - o arquivo existe no disco, começa com `%PDF` e não está vazio.

   Só então grava o registro e avança. Antes de clicar de novo, confere se o PDF chegou atrasado.
5. **Nunca sobrescreve:** usa "(1)" e assim por diante. Na página do PDF a automação **nunca** recarrega, porque isso reenviaria a emissão.

### 6.7 Outras proteções
- **Lentidão:** repete a etapa até 2 vezes, depois F5 até 2 vezes (o SISPAR nunca recarrega), depois `[lentidao]`.
- **Retomada por aba:** o estado fica em `storage.session` (válido por 10 min; até 12 mudanças de página).
- **Uma execução por vez:** o `execucao.json` guarda o pid do orquestrador.
- **Log do orquestrador:** nunca derruba a execução (tenta de novo por até ~5 s). Erro inesperado fica registrado.

### 6.8 Detecção de travamento × fim da lista (como a recuperação funciona hoje)
O "congelamento" de 10/11 09:19 **não era travamento**: o último CNPJ terminou, a lista acabou e a tela ficou no "Logout realizado" com um aviso errado. Use esta tabela para saber onde fica cada coisa:

| Situação | Quem detecta | O que acontece | Onde no código |
|---|---|---|---|
| Sem progresso por 8 min durante um CNPJ | vigia do orquestrador (`progresso.json` e `sinal.json`) | 1) fecha a "Salvar como" pelo ajudante (`janelas`, `cancelar-todas`) e espera 90 s; 2) `[travamento]` → reabre o Chrome **no mesmo CNPJ** (até 3 vezes; os PDFs já salvos não são emitidos de novo, pelo registro no Chrome e em disco); 3) PAUSA (`pausar.flag` com o motivo) | `orquestrador.ps1`, laço `while (-not $resultado)` e `do … while ($repetir)` |
| Esperando você (captcha, PIN, Caixa Postal, salvar à mão) | `sinal.json` `aguardando_humano` | não conta como travamento; sem prazo | `$esperandoVoce` no orquestrador |
| Lentidão do site | extensão | repete a etapa, F5, depois `[lentidao]` → mesmo tratamento de recuperação | `content.js` (lentidão) |
| Fim do CNPJ | extensão | "Sair com Segurança" (`orq-finalizar`) e marca `CHAVE_SAIU_ECAC`; dali em diante o login automático fica desligado nessa sessão | `background.js` `orq-finalizar` / `orq-atual` |
| **Fim da lista / parada / erro do orquestrador** (0.33.1) | orquestrador grava `ultima_execucao.json`; ajudante `Orq-Ultima` | a extensão mostra "AUTOMAÇÃO TERMINADA às HH:MM: … (X de Y concluídos…). Nada está travado" (verde), ou "PARADA…"/"encerrou com erro…", e não pede login; a interface mostra "TERMINADA em …" | `orquestrador.ps1` `finally`; `salvar_como.ps1` `Orq-Ultima`; `background.js` `orq-atual`; `content.js` `fluxoLogin`; `AutomacaoPGFN.cs` `UltimaExecucao()` |
| Orquestrador morreu no meio (processo encerrado) | ajudante (`pid` do `atual.json` sem processo) | aviso "o orquestrador parou antes de terminar… Iniciar continua de onde parou"; o andamento mantém o CNPJ `em_andamento` e ele é refeito no próximo Iniciar | `salvar_como.ps1` `Orq-Atual` |
| **Sem procuração** (0.34.0): e-CAC diz "Não existe procuração eletrônica…" depois do "Alterar" | extensão (`conferirTopo` → `tratarSemProcuracao`) | print `Sem_Procuracao_<CNPJ>.pdf` com a mensagem; fecha a janela pelo X; erro `[sem_procuracao]` → orquestrador grava `sem_procuracao` (sem F5, sem recuperação, sem nova tentativa) | `content.js`; `orquestrador.ps1` (`$FINAIS`, `$situacao`) |
| **"Sair" com a janela "Alterar perfil" aberta** (0.34.0) | extensão (`sairComSeguranca`) | fecha a janela pelo X → clica no "Sair" → 7 s sem sair: fecha e clica de novo (2x) → `href` do "Sair" → senão devolve o motivo (sem loop). O log recebe "Sessão do e-CAC: encerrada / não confirmada (…)" | `content.js` `fecharJanelaPerfil`/`sairComSeguranca`; `background.js` `orq-finalizar` |

### 6.9 Arquivos e funções alterados na 0.34.0
- **`content.js`:** `tratarSemProcuracao`, `fecharJanelaPerfil`, `acharJanelaPerfilAberta`, `acharXDaJanela` (novas); `conferirTopo` (chama a nova com o orquestrador); `sairComSeguranca` (fecha a janela, confirma, repete 2x, `href`).
- **`background.js`:** `sairDoEcac` (45 s por aba); `orq-finalizar` (75 s e a linha "Sessão do e-CAC").
- **`orquestrador.ps1`:** `$FINAIS`, migração do `erro` de procuração, `Contagem`, `Log-Progresso` (depois de cada CNPJ terminado) e `$situacao` com `sem_procuracao`; o resumo ganhou `semProcuracao`/`percentual`.
- **`salvar_como.ps1`:** `Orq-Ultima` (contagem com sem procuração) e versão 1.7.
- **`AutomacaoPGFN.cs`:** `Execucao.RefazerSemProcuracao`, `RefazerSemProc()`, botão e barra, contador em `Atualizar()`, `UltimaExecucao()` e um teste novo no `--autoteste`.

### 6.10 Pasta do certificado sempre definida (orquestrador 0.34.1, 10/11)
- **`orquestrador.ps1`, montagem da fila:**
  - grupo com `pasta`: usa essa pasta (formato da interface, inalterado);
  - grupo sem `pasta` (cnpjs.json antigo): usa `Pasta-Certificado(nome)`. Se o nome for trecho e houver **uma** pasta em `Downloads\Auto_PGFN\Documentos_arrecadacao` que começa com ele, usa essa.
- Antes, sem `pasta` e sem `exato`, a pasta ficava vazia e os documentos iam para `Documentos_arrecadacao\<CNPJ>`. Foi assim que surgiram as 25 pastas avulsas da CERT_A.
- Essas pastas foram consolidadas em 10/11, com comparação por SHA-256: 48 arquivos copiados, 68 duplicados e 3 renomeados com ` (avulsa 1)`. As originais estão em `Auto_PGFN\_recuperacao\pastas_avulsas_CERT_A_2026-11-10_1242\`, com `relatorio_consolidacao.csv`.
- Teste: `Desenvolvimento\testes\teste_pasta_certificado.ps1`.
- **`README.md`** é o manual de quem instala e vai dentro do `ATM_PGFN.zip`. Foi atualizado em 10/11 com tudo até a 0.34.1. **A cada mudança visível ao usuário, atualizar também o README e gerar o zip de novo.**

### 6.11 Salvamento do PDF: identificação certa e "encerrar e avançar" (0.35.0 + ajudante 1.8, 10/11)
- **Defeito real (CERT_B, 90000002000173, conta 14652591, prestação 0011):** o print da conta anterior (perfil normal, da extensão) e o PDF do site (janela anônima) tinham o mesmo número de download, e o background leu o print como resultado do documento. A conferência barrou, mas marcou como não repetível e a automação **pausou sem prazo** (pausa "aguardando você" não é travamento para o vigia).
- **Política de recuperação:**
  1. até **3 tentativas** do link do PDF, cada uma com até 3 chamadas do ajudante na janela "Salvar como";
  2. antes de cada nova tentativa, `procurar-documento` (ajudante) procura o PDF na pasta do CNPJ, pelo nome pedido ou pelo número do documento, só depois do início da prestação, com `%PDF`;
  3. persistindo a falha, **com o orquestrador**: evidência `Falha_Salvamento_<CNPJ>_conta_<conta>_prest_<prest>.pdf`, prestação "PENDENTE - documento NÃO baixado" com o motivo, só a janela "Salvar como" deste documento fechada, erro definitivo `[falha_salvamento]` (não é `[lentidao]`), relatório parcial, "Sair com Segurança" e **próximo CNPJ**;
  4. o CNPJ fica `erro` (pendente, "com erro" no contador) e é refeito no próximo Iniciar, sem repetir os PDFs já salvos.
  - Sem orquestrador (modo manual), a pausa para salvar à mão continua.
- **Funções:**
  - `background.js`: `itemConfere`, `acharItemAssociado` (novas); `associarDownload(id, chave, anonimo, origem)`; `registrarFimDownload` (recusa item de outro perfil/origem); `onChanged` (procura o item de cada prestação associada ao número); `statusDownload` e `fecharSalvarComo` (usam `acharItemAssociado`); `onDeterminingFilename` (sem perfil no item: o da aba); a espera guarda `anonimo`; nova mensagem `procurar-documento`.
  - `content.js`: `validarSalvo` (devolve `outroArquivo`); `acharDocumentoNoDisco` e `desistirDoSalvamento` (novas); `conferirSalvoAtrasado` (também procura no disco); `concluirDownload` (`repetivel` inclui `outroArquivo`); `tratarPaginaPdf` (com o orquestrador chama `desistirDoSalvamento`); `erroTransitorio` (erro `definitivo` não é lentidão).
  - `salvar_como.ps1` 1.8: `Procurar-Documento` (usa `Janela-Do-Documento`, a mesma regra de nome da janela "Salvar como").
  - `orquestrador.ps1`: linha "resultado: erro - falha de salvamento …".
  - Sincronização: a regra de caminho do ajudante em `regras_atm.json` passou a `"vezes": 2`.
- **Testes:** `teste_colisao_bg.js`, `teste_procurar_documento.js` (com `ATM_PGFN` como 2º argumento para a ATM), `teste_falha_salvamento.ps1` (`-Orig/-PastaOrq/-PastaAj`), simulador `sisparnet?docres=com&sc=errado&cert=X[&disco=1]`. `chrome_simulado.ps1` ganhou `PGFN_SIM_FALHA_SALV=<cnpj>`.

### 6.12 SISPAR "sem permissão / expirou" e página de acesso sem botão (0.36.0, 10/11)
- **Erro:** "Erro: Você não tem permissão de acesso ou ele expirou. Feche o navegador, retorne ao Regularize e tente novamente." (`resumoParcelamentoDarfInternet.jsf`, ao abrir "Documento de arrecadação" de novo). É a sessão do SISPAR perdida ou expirada: na mesma janela nada resolve.
- **Onde é reconhecido (`TEXTO_SEM_PERMISSAO`):**
  - na abertura de "Documento de arrecadação" e na espera do resultado (já existia);
  - na análise das negociações (`percorrerDeferidas`, novo).
- **Com o orquestrador:** `erroSemPermissao` registra certificado, CNPJ, conta, prestação, etapa e página; o aviso vira checkpoint; erro definitivo `[sessao_pgfn]`. Em seguida: relatório parcial, "Sair com Segurança", e o orquestrador refaz o **mesmo CNPJ** com o Chrome reaberto (`$RecuperacoesMax`, 3). Persistindo, fica `erro` e a fila segue, sem pausa.
- **Sem orquestrador:** a mensagem antiga (feche a janela do Regularize e comece de novo).
- **Página de acesso do e-CAC sem "Entrar com gov.br"** (`loginEcac`): recarrega 1 vez (`sessionStorage.pgfn_login_sem_botao`); depois, `finalizarOrq('erro', '[lentidao] login: …')`. Captcha continua pausando.
- **Orquestrador:** `$sessaoPgfn` (marca `[sessao_pgfn]`) entra em `$lento`; depois das recuperações, registra `erro` e segue. As linhas de log são "erro - acesso ao SISPAR expirado (…)" e "fica pendente (com erro) e a fila segue para o próximo CNPJ".
- **Testes:**
  - `teste_sessao_pgfn.ps1` (`-Orig/-PastaOrq/-PastaAj`), com `chrome_simulado.ps1` e `PGFN_SIM_SESSAO=<cnpj>:<vezes>`;
  - simulador `sisparnet?…&cert=X&semperm=N`;
  - `login.html` `/autenticacao?sembotao=1`.
- **Cuidado:** não recarregar a extensão no meio de uma execução: as abas abertas perdem o script (provável origem da página de acesso de 14:54 em 10/11).

**Limitações conhecidas (6.8 e 6.9):**
- O X da janela real do e-CAC é procurado por rótulo/texto ou pelo canto de cima à direita. Só foi testado no simulador; se o e-CAC mudar, a janela fica aberta, o "Sair" é tentado 2 vezes e o orquestrador fecha o Chrome mesmo assim, com "não confirmada" no log.
- O vigia vive **no orquestrador**. Se o orquestrador morrer, ninguém reinicia sozinho. A tela avisa e a interface mostra "Parada", e o usuário clica em Iniciar.
- O aviso da extensão é só texto (`pointer-events:none`); não bloqueia nada. Diálogos nativos tratados hoje: "Salvar como" e "Selecione um certificado".

### 6.13 Print da falta de procuração (0.36.1, 10/11)
- **`content.js` → `printSemProcuracao(cnpj)`** (usada por `tratarSemProcuracao` e pelo modo manual em `conferirTopo`):
  1. espera 0,8 a 1,4 s;
  2. exige `acharTexto(TEXTO_SEM_PROCURACAO)` visível; se a frase estiver fora da tela, usa `scrollIntoView`; sem a frase, não captura;
  3. `salvarPrintEmPdf(<pastaDocumentos()>/<CNPJ>, Sem_Procuracao_<CNPJ>.pdf)`;
  4. `conferir-arquivo` no disco (sem resposta também conta como problema);
  5. devolve `{caminho, problema}`.
- A ordem continua: **print → X da janela → erro `[sem_procuracao]` → "Sair com Segurança" → próximo CNPJ** (orquestrador).
- Destino: `Downloads\Auto_PGFN\Documentos_arrecadacao\<pasta do certificado>\<CNPJ>\Sem_Procuracao_<CNPJ>.pdf`.
- O print do mesmo dia não é repetido (registro `print|<pasta>/<nome>|<data>`).
- Simulador (`index.html`): `semproc=<CNPJs>`, `some=<ms>` (a mensagem some), `iframe=1`; `sessionStorage.orq` / `orqPasta` imitam o orquestrador.

### 6.14 Procuração cancelada (0.37.0, 10/11)
- **Aviso do e-CAC na janela "Alterar perfil de acesso":** "A procuração eletrônica cadastrada para o detentor <CPF> do certificado digital apresentado foi cancelada em <DD/MM/AAAA>". Reconhecido pelo trecho fixo `TEXTO_PROC_CANCELADA = 'foi cancelada em'`.
- **Fluxo:**
  1. `conferirTopo` interrompe a espera;
  2. `tratarProcuracaoCancelada`: o campo PJ tem que ter o CNPJ da vez (senão, erro comum, sem print nem classificação);
  3. `printDoAviso(TEXTO_PROC_CANCELADA, <pastaDocumentos()>/<CNPJ>/Procuracao_Cancelada, Procuracao_Cancelada_<CNPJ>.pdf, cnpj)`;
  4. X da janela;
  5. erro `[procuracao_cancelada] Pendente por procuração cancelada: …` (`definitivo`);
  6. "Sair com Segurança";
  7. orquestrador: situação `procuracao_cancelada` (final; contador `procCancelada`) e próximo CNPJ.
- **Refazer:** botão "Refazer sem procuração" (`Execucao.RefazerSemProcuracao`) volta `sem_procuracao` **e** `procuracao_cancelada` a pendente.
- **Simulador:** `index.html?cancelada=<CNPJs>` (`&outrocampo=1` troca o valor do campo); `chrome_simulado.ps1` com `PGFN_SIM_CANCELADA=<cnpj>`; teste `teste_proc_cancelada.ps1` (orquestrador real).
- **Arquivo de saída novo:** `<CNPJ>\Procuracao_Cancelada\Procuracao_Cancelada_<CNPJ>.pdf`.

### 6.15 Seleção do certificado com lista rolável (0.38.0 + ajudante 1.9, 11/11)
- **Janela do Chrome (views::TableView):**
  - a acessibilidade só expõe as linhas **visíveis**;
  - o foco é a célula "Tema" (DataItem com Name = nome completo) da linha selecionada;
  - a "linha mãe" do foco não é confiável;
  - clicar no cabeçalho "Tema" ordena a lista.
- **`salvar_como.ps1` → `Certificado`:**
  1. acha a janela;
  2. `Percorrer-Lista`: usa o foco atual (ou clica numa linha inteira visível), Home e seta ↓ (`keybd_event` 0x24/0x28; nunca Enter) até o foco parar de mudar;
  3. `Nome-Confere` em cada nome;
  4. exatamente 1 → Home e ↓ até o índice, conferindo cada passo (chave nome|serial);
  5. conferência final nome+serial;
  6. botão OK (ou "Cancelar" com `teste:true`).
- **Antes de cada tecla**, o foco precisa estar numa célula da janela de certificados (`Linha-Em-Foco`): nunca envia tecla para outra janela.
- **Erros** (≠ 1 correspondência, foco fora, lista mudou) → `{ ok:false, erro, disponiveis }` → `content.js` pausa (`pausarParaHumano`) como antes.
- **`background.js`:** `chamarAjudante(pedido, limiteMs = 50000)`; o certificado usa 180000.
- **Teste:** `Desenvolvimento\testes\teste_certificado_real.js` abre um Chrome **de teste** (perfil temporário) em `https://certificado.sso.acesso.gov.br/` e chama o ajudante com `teste:true`:
  - nome inexistente → lista inteira, nada escolhido;
  - último da lista (fora da parte visível) → selecionado e conferido;
  - um do meio → selecionado e conferido.
  - Não imprime nomes. Exige uma máquina com mais certificados do que cabem na janela (mais de 3).

### 6.16 Aviso de Caixa Postal encerra a análise (0.39.0, 11/11)
- **Substitui** o fluxo da 0.29 (clicar em "Ir para a Caixa Postal", print da Caixa Postal, voltar e continuar).
- **Detecção:** a mesma (`acharIrCaixaPostal`: texto "Você possui mensagens importantes" + botão). É verificada em `fecharAvisoEcac`, chamada em `analisarPagina`, `abrirJanela` e `abrirDividaAtiva`.
- **`tratarAvisoCaixaPostal()` (`content.js`):**
  1. CNPJ em processamento = `estado.cnpj` ou `ORQ.cnpj`. Tem que ser igual ao do cabeçalho (`lerPerfilAtual`). Se não for (aviso do titular antes da troca, ou cabeçalho ilegível): não salva e **pausa** (`esperarLeituraCaixaPostal`, como antes);
  2. já registrado (`caixa_postal|<CNPJ>`) e no disco → não salva de novo;
  3. senão, `printDoAviso(TEXTO_AVISO_CAIXA_POSTAL, <pastaDocumentos>/<CNPJ>, Caixa_Postal_<CNPJ>.pdf, cnpj)`: frase visível, captura, conferência no disco e na pasta do CNPJ;
  4. até `TENTATIVAS_PRINT_CAIXA_POSTAL` (3) tentativas. Uma nova tentativa não duplica: o registro do print do dia reaproveita o arquivo que já está no disco;
  5. sucesso → `registro-gravar` e erro `[caixa_postal] Aviso de Caixa Postal: …` com `definitivo` (o "Sair com Segurança" vem no fim do CNPJ);
  6. 3 falhas → `[falha_salvamento] Aviso de Caixa Postal …` (definitivo): o CNPJ fica `erro`, refeito na próxima execução, e a fila segue.
- **`retomarCaixaPostal`/`salvarCaixaPostal`** ficam só para terminar uma visita deixada em andamento pela versão antiga.
- **Orquestrador:** `[caixa_postal]` → situação `caixa_postal` (em `$FINAIS`), contador `caixaPostal` (`Contagem`, PROGRESSO " | aviso de Caixa Postal N" só quando N > 0, `ultima_execucao.json`).
- **Interface:** contador "Aviso de Caixa Postal: N" (entra no total e no %); `RefazerSemProcuracao` também volta `caixa_postal` a pendente; resumo da última execução.
- **Ajudante:** resumo de fim de lista com ", N com aviso de Caixa Postal" (versão continua 1.9).
- **Testes:**
  - simulador: `index.html?caixa=perfil&orq=<CNPJ>[&cxfalha=N]`, `caixa=titular`; a captura anota `comCaixa`;
  - `teste_caixa_postal.ps1` (orquestrador real + `chrome_simulado.ps1` com `PGFN_SIM_CAIXA`).

---

## 7. Arquivos de saída e nomes (não alterar sem pedido)

Pasta: `<Downloads do Chrome>\<ATM_PGFN ou Auto_PGFN>\Documentos_arrecadacao\<PASTA_DO_CERTIFICADO>\<CNPJ>\`.
- **Pasta do certificado:** o nome do certificado sem acento, em maiúsculas, com `[A-Z0-9_-]` e até 80 caracteres. Exemplo: `CERTIFICADO_EXEMPLO_A_LTDA_90000001000129`.
- **Modo antigo ou sem orquestrador:** `Documentos_arrecadacao\<CNPJ>\`.
- **Desde a 0.34.1, com o orquestrador,** sempre há pasta do certificado, mesmo com o `cnpjs.json` antigo (ver 6.10). Só o modo manual da extensão, sem orquestrador, ainda usa `Documentos_arrecadacao\<CNPJ>\`.

| Arquivo | Quando |
|---|---|
| `CNPJ;NOME;MM-AAAA.pdf` | documento da prestação |
| `…;conta X;prest Y.pdf` | mesma competência já salva nesta execução |
| `CNPJ;NOME.pdf` | sem negociação |
| `Sem_Deferido_<CNPJ>.pdf` | nenhuma "Deferida e consolidada" |
| `sem_cadastro_regularize.pdf` | sem cadastro no Regularize |
| `print_confirmacao[_conta_X].pdf` | situação final da conta |
| `Caixa_Postal_<CNPJ>.pdf` | aviso de mensagens importantes (desde a 0.39.0: print do próprio aviso, e a análise do CNPJ é encerrada) |
| `Problema_receita_federal_<CNPJ>.pdf` | erro 10000 |
| `Erro_500_<CNPJ>.pdf` | erro 500 depois de 5 tentativas |
| `Sem_Procuracao_<CNPJ>.pdf` | e-CAC: não existe procuração eletrônica do certificado para o CNPJ (0.34.0) |
| `Procuracao_Cancelada\Procuracao_Cancelada_<CNPJ>.pdf` | e-CAC: a procuração eletrônica "foi cancelada em" uma data (0.37.0); subpasta dentro da pasta do CNPJ |
| `Falha_Salvamento_<CNPJ>_conta_<conta>_prest_<prest>.pdf` | evidência: o PDF da prestação não foi salvo depois de 3 tentativas; o CNPJ fica pendente (0.35.0) |
| `CNPJ;NOME;relatorio AAAA-MM-DD HHhMM.csv` | relatório |

---

## 8. Configurações importantes

- **Configuração** (`Configuracoes\<nome>.json`, gravada pela interface):
  - `{"nome", "certificados":[{"certificado":"<CN exato>", "exato":true, "pasta":"<pasta>", "cnpjs":[...]}]}`;
  - opcional: `"minutosTravamento"`.
- **Orquestrador (parâmetros):**
  - uso normal: `-Config`, `-Andamento`, `-MinutosTravamento 8`, `-SegundosRecuperacao 90`, `-RecuperacoesMax 3`;
  - só para testes: `-SemChrome`, `-ChromeSimulado <script>`, `-PerfilChrome`, `-UrlInicial`, `-SoMostrar`.
- **Constantes do `content.js`:**

  | Constante | Valor |
  |---|---|
  | `TIMEOUT_ELEMENTO_MS` | 20000 |
  | `TIMEOUT_REGULARIZE_MS` | 45000 |
  | `ESPERA_DOCUMENTO_MS` | 45000 |
  | `ESPERA_SALVAR_COMO_MS` | 180000 |
  | `TENTATIVAS_LINK_PDF` | 3 |
  | `ESPERAS_93003_S` | [60, 180, 300] |
  | `ESPERAS_500_S` | [15, 30, 60, 90, 120] |
  | `REPETICOES_POR_ETAPA` | 2 |
  | `RECARGAS_POR_LENTIDAO` | 2 |
  | `LIMITE_RETOMADAS` | 12 |
  | `VALIDADE_ANDAMENTO_MS` | 600000 |
  | `CNPJS_TESTE` | [] |

- **Chrome:** "Permitir no modo anônimo" ligado. `automaticDownloads` liberado só para `https://sisparnet.pgfn.fazenda.gov.br/*`, pela própria extensão. A automação **não** muda nenhuma outra configuração do Chrome.

---

## 9. Regras do usuário (obrigatórias em qualquer mudança)

1. **Idioma:** responder em **português do Brasil**. O usuário testa no site real e manda prints.
2. **Mudanças mínimas:** **preservar tudo o que funciona**. Mudar só o necessário. **Não reescrever** a automação. Explicar a causa antes de mudar quando ele pedir.
3. **Salvamento:** downloads, nomes e pastas são intocáveis, salvo pedido explícito (ele mesmo pediu as pastas por certificado na 0.32). Nunca sobrescrever. Nunca duplicar. Só considerar um PDF salvo depois de conferido no disco.
4. **Mouse e esperas:** seta desenhada e movimento humanizado e aleatório. Esperas com tempo limite e aviso claro no **canto inferior esquerdo**.
5. **Proibições no site:** **nunca** digitar login, senha ou PIN; **nunca** clicar em "DESISTIR"; **não burlar captcha** (pausar, deixar o usuário resolver e retomar).
6. **Valores financeiros:** **não inventar nem preencher valores financeiros.** Na janela com "Calcular", só clicar em Calcular com o valor apresentado.
7. **Certificado:** escolher pelo **nome exato** configurado, nunca outro nem um parecido. O CERT_A é só de desenvolvimento e teste e não pode ficar fixo no código. Não guardar senha, PIN nem chave privada.
8. **CNPJ:** sempre o CNPJ em processamento para pastas e nomes. **Nunca pular um CNPJ** por lentidão, travamento ou 93003. Pausar quando não houver como recuperar. Evitar loops infinitos (sempre com limite).
9. **Configurações do Chrome:** não mudar sozinho. Exceções autorizadas: `automaticDownloads` só no sisparnet; ajudante no HKCU; **fechar todo o Chrome** a cada CNPJ.
10. **Sessões e janelas:** não encerrar sessões de terceiros nem janelas que não são da automação. Não ler o conteúdo de outras janelas do usuário (ex.: WhatsApp).
11. **Referência antiga:** a extensão `Documents\simplificado\parcelamento_simplificado` é só referência; não modificar.
12. **Recarregar a extensão:** depois de mudar a extensão, **lembrar o usuário de clicar em "Recarregar"** em `chrome://extensions` e conferir a versão.
13. **Teste:** validar no simulador e nos testes antes de declarar algo resolvido. Dizer claramente o que foi e o que não foi testado no site real.

---

## 10. Como executar, testar e continuar

- **Usar:** `Iniciar.bat` (a interface). Instalação em outro PC: extrair o zip, rodar `Instalar.bat` e seguir o `README.md`.
- **Conferir a instalação sem mudar nada:** `powershell -ExecutionPolicy Bypass -File Instalador\instalar.ps1 -SoVerificar`.
- **Logs:**
  - `Automacao\orquestrador.log`: cada CNPJ, etapa, TRAVAMENTO, recuperação, pausa e resultado;
  - `Ajudante_Windows\ajudante.log`: cada pedido ao ajudante e a resposta;
  - console da página (F12): mensagens `[Automação_PGFN]`, `[salvamento]`.
- **Simulador** (`Desenvolvimento\testes\`, precisa do Node):
  1. `node server.js` sobe o simulador nas portas 8765 e 8766 e acelera os tempos (`PGFN_CONTENT=<content.js>` escolhe qual content.js usar).
  2. Abrir no navegador: `/sisparnet?docres=com` e as variantes:
     - `&calc=1` / `&calc=exige`: janela com cálculo prévio;
     - `&sc=esgota|sempre|atrasado|errado`: falhas de salvamento;
     - `&cert=PASTA`: orquestrador ativo, com pasta do certificado.
  3. Login e erros: `/autenticacao`, `/autenticacao/Error/Erro/10000`, `/autenticacao/Error/ErrorHttp?500;` (com `localStorage.falhas500`), `/autenticacao/Error/Erro/93003`.
  4. Ao usar o painel de navegador do Claude, rode `resize_window 1280x800` antes.
- **Testes automáticos:**
  - **com Node:** `teste_downloads.js`, `teste_ajudante.js`, `teste_salvamento_bg.js`, `teste_registro_bg.js`, `teste_background.js`, `teste_proximo.js`, `teste_sair_ecac.js`, `teste_ajudante_14.js`, `teste_ajudante_15.js`, `teste_janela_real*.js` (janelas "Salvar como" reais do Windows), `teste_portabilidade.js`;
  - **PowerShell, vigia de travamentos:** `teste_vigia.ps1 -Cenario conclui|trava-uma-vez|pausa|janela|trava [-ControlarPausa]`, com `chrome_simulado.ps1`;
  - **PowerShell, fim da lista (0.33.1):** `teste_fim_lista.ps1` (padrão: Auto_PGFN). Para a ATM: `-Orig <ATM_PGFN> -PastaOrq Automacao -PastaAj Ajudante_Windows`;
  - **PowerShell, sem procuração e contador (0.34.0):** `teste_sem_procuracao.ps1`, com os mesmos parâmetros; `chrome_simulado.ps1` com `PGFN_SIM_SEMPROC=<cnpj>`;
  - **Simulador de páginas, sem procuração (0.34.0):** `/ecac?orq=90000003000118&semproc=90000003000118&limpar=1`, mais `&x=texto` (X com "×") ou `&x=nenhum` (janela sem X). Ver `window.__resultado()`: `prints`, `xFechou`, `cliquesSair`, `sairComJanela`, `saiu`, `sairlog`;
  - **interface:** `Automacao_PGFN.exe --autoteste <arquivo.txt>`.
  - **Atenção aos caminhos:** vários testes apontam para `Downloads\Auto_PGFN` ou para a pasta temporária antiga da conversa. Ajuste antes de usar.
  - **Teste desatualizado:** `teste_pdf.js`, porque a simulação dele não tem `onDeterminingFilename`.
- **Depois de cada mudança:** levar para a outra pasta, compilar a interface se mudou, gerar o zip de novo, atualizar `ESTADO_ATUAL.md` e `HISTORICO_PROJETO.md` e lembrar o usuário de recarregar a extensão.

---

## INSTRUÇÕES PARA CONTINUAR O DESENVOLVIMENTO

Copie e cole o texto abaixo no novo chat, com a pasta `ATM_PGFN` (ou `Auto_PGFN`) aberta como pasta de trabalho:

```
Vamos CONTINUAR o desenvolvimento da automação PGFN (e-CAC → Regularize → SISPAR → emissão e salvamento dos documentos
das negociações "DEFERIDA E CONSOLIDADA"). O projeto JÁ ESTÁ em uso, com muitas funcionalidades implementadas e testadas
(extensão Chrome 0.34.0, ajudante do Windows 1.7, orquestrador PowerShell com vigia de travamentos, interface
Automacao_PGFN.exe com configurações por certificado). Não comece do zero.

Antes de qualquer alteração:
1. Leia, nesta ordem: C:\Users\PANORAMA-PC\Downloads\ATM_PGFN\ESTADO_ATUAL.md, CONTEXTO_NOVO_CHAT.md e
   HISTORICO_PROJETO.md. Se precisar de detalhes de uma decisão, consulte Historico_conversas\ (as conversas completas)
   e Desenvolvimento\CONTINUIDADE_AUTOMACAO_PGFN_ate_v0.33.md.
2. Analise o código existente que for mexer (Extensao_Chrome\content.js e background.js, Ajudante_Windows\salvar_como.ps1,
   Automacao\orquestrador.ps1, Interface\AutomacaoPGFN.cs) antes de propor mudanças.
3. Atenção: neste computador a instalação ATIVA é C:\Users\PANORAMA-PC\Downloads\Auto_PGFN (extensão carregada e ajudante
   registrados a partir dela); a ATM_PGFN é a versão de distribuição com os mesmos recursos. Toda mudança vale para as
   duas pastas (ver CONTEXTO_NOVO_CHAT.md, seção 2) e o ATM_PGFN.zip deve ser gerado de novo.

Regras: responda em português do Brasil; não remova nem reescreva funcionalidades existentes sem necessidade; faça só
mudanças pontuais que respeitem a arquitetura e as regras da seção 9 do CONTEXTO_NOVO_CHAT.md (não digitar senha/PIN,
não burlar captcha, nunca clicar em DESISTIR, não inventar valores financeiros, certificado só pelo nome exato, não pular
CNPJ por travamento, não sobrescrever nem duplicar arquivos, não mudar configurações do Chrome sozinho, preservar
download/salvamento/nomes/pastas). Antes de mexer, explique a causa do problema; depois, teste (simulador e testes em
Desenvolvimento\testes) e diga com clareza o que foi testado e o que não foi testado no site real. Ao terminar cada
mudança, me lembre de clicar em "Recarregar" na extensão em chrome://extensions e atualize ESTADO_ATUAL.md e
HISTORICO_PROJETO.md.

Continue exatamente do estado descrito em ESTADO_ATUAL.md. Primeiro, me diga em poucas linhas o que entendeu do estado
atual e quais são os próximos passos pendentes; depois aguarde meu pedido.
```
