// Automação PGFN — interface de configuração e acompanhamento (Windows Forms, .NET Framework 4, sem dependências).
// Compilar: Interface\compilar.bat  ->  Interface\Automacao_PGFN.exe (pasta ATM_PGFN). Abrir: Iniciar.bat.
//
// O que faz: cadastra configurações (certificado + lista de CNPJs), confere o certificado no Windows, inicia o
// orquestrador de sempre (Automacao\orquestrador.ps1) com a configuração escolhida e mostra o andamento.
// Não guarda senha, PIN nem chave privada: do certificado só lê o NOME (o mesmo que aparece na janela do Chrome).
// Cada configuração fica em Configuracoes\<nome>.json (formato do cnpjs.json) e o andamento dela em
// Configuracoes\<nome>.andamento.json. Os documentos vão para <Downloads do Chrome>\ATM_PGFN\Documentos_arrecadacao\
// <CERTIFICADO>\<CNPJ>. Todos os caminhos são relativos à pasta ATM_PGFN (pode ser copiada para outro computador).
// (C# 5: compila com o csc.exe que vem no Windows.)
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.RegularExpressions;
using System.Web.Script.Serialization;
using System.Windows.Forms;

namespace AutomacaoPGFN
{
    // ---------------------------------------------------------------- regras (sem tela; testadas no --autoteste)
    public static class Regras
    {
        public static string SoDigitos(string s) { return Regex.Replace(s ?? "", @"\D", ""); }

        public static bool CnpjValido(string c)
        {
            if (c == null || !Regex.IsMatch(c, @"^\d{14}$") || Regex.IsMatch(c, @"^(\d)\1{13}$")) return false;
            int d1 = Dv(c.Substring(0, 12));
            int d2 = Dv(c.Substring(0, 12) + d1);
            return c.Substring(12) == d1.ToString() + d2.ToString();
        }
        static int Dv(string b)
        {
            int soma = 0, peso = b.Length - 7;
            foreach (char ch in b) { soma += (ch - '0') * peso; peso--; if (peso < 2) peso = 9; }
            int r = soma % 11;
            return r < 2 ? 0 : 11 - r;
        }
        public static string Formatar(string c)
        {
            return c.Length == 14 ? string.Format("{0}.{1}.{2}/{3}-{4}", c.Substring(0, 2), c.Substring(2, 3), c.Substring(5, 3), c.Substring(8, 4), c.Substring(12)) : c;
        }

        // Linhas digitadas -> CNPJs válidos (sem repetição, na ordem), repetidos e inválidos.
        public class Lista { public List<string> Validos = new List<string>(); public List<string> Repetidos = new List<string>(); public List<string> Invalidos = new List<string>(); }
        public static Lista LerCnpjs(string texto)
        {
            var r = new Lista();
            foreach (string linha0 in (texto ?? "").Split(new[] { '\r', '\n', ';', ',' }, StringSplitOptions.RemoveEmptyEntries))
            {
                string linha = linha0.Trim();
                if (linha.Length == 0) continue;
                string d = SoDigitos(linha);
                if (!CnpjValido(d)) { r.Invalidos.Add(linha); continue; }
                if (r.Validos.Contains(d)) { if (!r.Repetidos.Contains(d)) r.Repetidos.Add(d); continue; }
                r.Validos.Add(d);
            }
            return r;
        }

        // Pasta do certificado: igual ao Pasta-Certificado do orquestrador (letras sem acento, números, "_" e "-").
        public static string PastaCertificado(string nome)
        {
            string s = (nome ?? "").Normalize(NormalizationForm.FormD);
            var sb = new StringBuilder();
            foreach (char ch in s) if (CharUnicodeInfo.GetUnicodeCategory(ch) != UnicodeCategory.NonSpacingMark) sb.Append(ch);
            s = Regex.Replace(sb.ToString().ToUpperInvariant(), @"[^A-Z0-9_-]+", "_").Trim('_', '-');
            if (s.Length > 80) s = s.Substring(0, 80).TrimEnd('_', '-');
            return s;
        }

        // Nome do arquivo da configuração (sem acento/símbolos).
        public static string ArquivoDaConfig(string nome)
        {
            string s = PastaCertificado(nome).ToLowerInvariant();
            return s.Length == 0 ? "configuracao" : s;
        }

        // Certificados do Windows que o Chrome oferece no login (Pessoal, com chave privada, para autenticação de cliente).
        public class Cert { public string Nome; public DateTime Validade; public DateTime Inicio; public string Emissor; public string Impressao; }
        public static List<Cert> CertificadosDoWindows()
        {
            var lista = new List<Cert>();
            var loja = new X509Store(StoreName.My, StoreLocation.CurrentUser);
            loja.Open(OpenFlags.ReadOnly | OpenFlags.OpenExistingOnly);
            try
            {
                foreach (X509Certificate2 c in loja.Certificates)
                {
                    if (!c.HasPrivateKey) continue;
                    bool cliente = true;
                    foreach (X509Extension e in c.Extensions)
                    {
                        var eku = e as X509EnhancedKeyUsageExtension;
                        if (eku == null) continue;
                        cliente = false;
                        foreach (var o in eku.EnhancedKeyUsages) if (o.Value == "1.3.6.1.5.5.7.3.2") cliente = true;
                    }
                    if (!cliente) continue;
                    lista.Add(new Cert { Nome = c.GetNameInfo(X509NameType.SimpleName, false), Validade = c.NotAfter, Inicio = c.NotBefore,
                        Emissor = c.GetNameInfo(X509NameType.SimpleName, true), Impressao = c.Thumbprint });
                }
            }
            finally { loja.Close(); }
            return lista.OrderBy(x => x.Nome).ThenBy(x => x.Validade).ToList();
        }

        // Certificados com EXATAMENTE este nome (o ajudante usa a mesma regra: sem diferença de maiúsculas/acentos/espaços).
        public static string Normalizar(string s)
        {
            string d = (s ?? "").Normalize(NormalizationForm.FormD);
            var sb = new StringBuilder();
            foreach (char ch in d) if (CharUnicodeInfo.GetUnicodeCategory(ch) != UnicodeCategory.NonSpacingMark) sb.Append(ch);
            return Regex.Replace(sb.ToString().ToUpperInvariant(), @"\s+", " ").Trim();
        }
        public static List<Cert> ComONome(List<Cert> todos, string nome)
        {
            string alvo = Normalizar(nome);
            return todos.Where(c => Normalizar(c.Nome) == alvo).ToList();
        }
    }

    // ---------------------------------------------------------------- configuração (arquivo do orquestrador)
    public class Configuracao
    {
        public string Arquivo; // caminho completo do .json
        public string Nome = "";
        public string Certificado = "";
        public string Pasta = "";
        public List<string> Cnpjs = new List<string>();
        public string Andamento { get { return Path.ChangeExtension(Arquivo, null) + ".andamento.json"; } }

        static readonly JavaScriptSerializer Json = new JavaScriptSerializer();

        public static Configuracao Ler(string arq)
        {
            var d = Json.DeserializeObject(File.ReadAllText(arq, Encoding.UTF8)) as Dictionary<string, object>;
            var c = new Configuracao { Arquivo = arq };
            if (d == null) return c;
            object v;
            if (d.TryGetValue("nome", out v) && v != null) c.Nome = v.ToString();
            if (d.TryGetValue("certificados", out v))
            {
                var grupos = v as IEnumerable;
                foreach (var g0 in grupos)
                {
                    var g = g0 as Dictionary<string, object>;
                    if (g == null) continue;
                    if (g.TryGetValue("certificado", out v) && v != null && c.Certificado.Length == 0) c.Certificado = v.ToString();
                    if (g.TryGetValue("pasta", out v) && v != null && c.Pasta.Length == 0) c.Pasta = v.ToString();
                    if (g.TryGetValue("cnpjs", out v) && v is IEnumerable)
                        foreach (var x in (IEnumerable)v) { string s = Regras.SoDigitos(Convert.ToString(x)); if (s.Length > 0 && !c.Cnpjs.Contains(s)) c.Cnpjs.Add(s); }
                    break; // uma configuração = um certificado
                }
            }
            if (c.Nome.Length == 0) c.Nome = Path.GetFileNameWithoutExtension(arq);
            return c;
        }

        public void Gravar()
        {
            if (Pasta.Length == 0) Pasta = Regras.PastaCertificado(Certificado);
            var obj = new Dictionary<string, object>();
            obj["nome"] = Nome;
            obj["_como_usar"] = "Arquivo da interface Automacao_PGFN.exe (edite por ela). certificado = nome exato do certificado; exato = escolhe só esse nome; pasta = pasta do certificado em Documentos_arrecadacao.";
            obj["certificados"] = new object[] { new Dictionary<string, object> {
                { "certificado", Certificado }, { "exato", true }, { "pasta", Pasta }, { "cnpjs", Cnpjs.Select(Regras.Formatar).ToArray() } } };
            string tmp = Arquivo + ".tmp";
            File.WriteAllText(tmp, Json.Serialize(obj), new UTF8Encoding(false));
            if (File.Exists(Arquivo)) File.Delete(Arquivo);
            File.Move(tmp, Arquivo);
        }
    }

    // ---------------------------------------------------------------- arquivos da execução (orquestrador)
    public static class Execucao
    {
        // Raiz ATM_PGFN: o .exe fica em ATM_PGFN\Interface (sobe um nível); se estiver na própria raiz, vale ela.
        public static string Base = AcharBase();
        static string AcharBase()
        {
            string aqui = AppDomain.CurrentDomain.BaseDirectory.TrimEnd('\\');
            string pai = Path.GetDirectoryName(aqui);
            if (!Directory.Exists(Path.Combine(aqui, "Automacao")) && pai != null && Directory.Exists(Path.Combine(pai, "Automacao"))) return pai;
            return aqui;
        }
        public static string PastaOrq { get { return Path.Combine(Base, "Automacao"); } }
        public static string PastaConfigs { get { return Path.Combine(Base, "Configuracoes"); } }
        // Diretório de saída: <pasta de downloads do Chrome>\ATM_PGFN\Documentos_arrecadacao (o Chrome só salva lá dentro).
        public static string PastaSaida { get { return Path.Combine(Path.Combine(PastaDownloadsChrome(), "ATM_PGFN"), "Documentos_arrecadacao"); } }
        public static string PastaDownloadsChrome()
        {
            try
            {
                string pref = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), @"Google\Chrome\User Data\Default\Preferences");
                var d = LerJson(pref);
                object v;
                if (d != null && d.TryGetValue("download", out v) && v is Dictionary<string, object>)
                {
                    string dir = Campo((Dictionary<string, object>)v, "default_directory");
                    if (dir.Length > 0 && Directory.Exists(dir)) return dir;
                }
            }
            catch { }
            try
            {
                using (var k = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders"))
                {
                    var v = k != null ? k.GetValue("{374DE290-123F-4565-9164-39C4925E467B}") as string : null;
                    if (!string.IsNullOrEmpty(v)) return Environment.ExpandEnvironmentVariables(v);
                }
            }
            catch { }
            return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads");
        }
        public static string Orquestrador { get { return Path.Combine(PastaOrq, "orquestrador.ps1"); } }
        public static string Pausar { get { return Path.Combine(PastaOrq, "pausar.flag"); } }
        public static string Parar { get { return Path.Combine(PastaOrq, "parar.flag"); } }
        static readonly JavaScriptSerializer Json = new JavaScriptSerializer();

        // 0.34.0: CNPJs "sem_procuracao" voltam a "pendente" (depois de você criar a procuração no e-CAC). Devolve quantos.
        // O andamento antigo é guardado em cópia antes.
        public static int RefazerSemProcuracao(string arq)
        {
            var and = LerJson(arq);
            if (and == null) return 0;
            int n = 0;
            foreach (var k in and.Keys.ToList())
            {
                var reg = and[k] as Dictionary<string, object>;
                // 0.37.0: também os "procuracao_cancelada" (depois de renovar a procuração no e-CAC)
                string sit = reg == null ? "" : Campo(reg, "situacao");
                if (sit != "sem_procuracao" && sit != "procuracao_cancelada" && sit != "caixa_postal") continue; // 0.39.0: + aviso de Caixa Postal
                reg["situacao"] = "pendente";
                reg["mensagem"] = "refazer pedido na interface em " + DateTime.Now.ToString("dd/MM HH:mm") +
                    (sit == "procuracao_cancelada" ? " (antes: procuração cancelada)" : sit == "caixa_postal" ? " (antes: aviso de Caixa Postal)" : " (antes: sem procuração)");
                n++;
            }
            if (n == 0) return 0;
            File.Copy(arq, arq + ".antes_refazer_" + DateTime.Now.ToString("yyyyMMdd_HHmmss"));
            string tmp = arq + ".tmp";
            File.WriteAllText(tmp, Json.Serialize(and), new UTF8Encoding(false));
            File.Copy(tmp, arq, true); File.Delete(tmp);
            return n;
        }

        public static string LerTexto(string arq)
        {
            try
            {
                using (var f = new FileStream(arq, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete))
                using (var r = new StreamReader(f, Encoding.UTF8)) return r.ReadToEnd();
            }
            catch { return null; }
        }
        public static Dictionary<string, object> LerJson(string arq)
        {
            string t = LerTexto(arq);
            if (string.IsNullOrEmpty(t)) return null;
            try { return Json.DeserializeObject(t) as Dictionary<string, object>; } catch { return null; }
        }
        public static string Campo(Dictionary<string, object> d, string k) { object v; return d != null && d.TryGetValue(k, out v) && v != null ? v.ToString() : ""; }

        // Execução em andamento: execucao.json com o processo do orquestrador vivo.
        public static Dictionary<string, object> EmAndamento()
        {
            var e = LerJson(Path.Combine(PastaOrq, "execucao.json"));
            if (e == null) return null;
            int pid;
            if (!int.TryParse(Campo(e, "pid"), out pid)) return null;
            try { var p = Process.GetProcessById(pid); if (p.HasExited || !p.ProcessName.ToLowerInvariant().Contains("powershell")) return null; }
            catch { return null; }
            return e;
        }

        // Últimas linhas do log (só o fim do arquivo).
        public static string FimDoLog(int maxBytes)
        {
            string arq = Path.Combine(PastaOrq, "orquestrador.log");
            try
            {
                using (var f = new FileStream(arq, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete))
                {
                    long ini = Math.Max(0, f.Length - maxBytes);
                    f.Seek(ini, SeekOrigin.Begin);
                    using (var r = new StreamReader(f, Encoding.UTF8))
                    {
                        string t = r.ReadToEnd();
                        if (ini > 0) { int i = t.IndexOf('\n'); if (i >= 0) t = t.Substring(i + 1); }
                        return t.Replace("\r\n", "\n").Replace("\n", "\r\n");
                    }
                }
            }
            catch { return ""; }
        }

        public static Process Iniciar(Configuracao c)
        {
            var psi = new ProcessStartInfo("powershell.exe",
                string.Format("-NoProfile -ExecutionPolicy Bypass -File \"{0}\" -Config \"{1}\" -Andamento \"{2}\"", Orquestrador, c.Arquivo, c.Andamento));
            psi.UseShellExecute = true;
            psi.WindowStyle = ProcessWindowStyle.Minimized; // a janela do orquestrador fica na barra de tarefas
            psi.WorkingDirectory = PastaOrq;
            return Process.Start(psi);
        }

        public static bool AjudanteInstalado()
        {
            using (var k = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(@"Software\Google\Chrome\NativeMessagingHosts\com.auto_pgfn.salvar_como"))
                return k != null;
        }
    }

    // ---------------------------------------------------------------- tela
    public class Janela : Form
    {
        ListBox lstConfigs = new ListBox();
        TextBox txtNome = new TextBox();
        ComboBox cmbCert = new ComboBox();
        Label lblCert = new Label();
        TextBox txtCnpjs = new TextBox();
        Label lblCnpjs = new Label();
        Label lblPasta = new Label();
        Button btnNova = new Button(), btnExcluir = new Button(), btnSalvar = new Button(), btnValidar = new Button(), btnAtualizarCerts = new Button();
        Button btnIniciar = new Button(), btnPausar = new Button(), btnRetomar = new Button(), btnParar = new Button(), btnZerar = new Button(), btnPasta = new Button(), btnRefazerSemProc = new Button();
        ProgressBar barra = new ProgressBar();
        Label lblExecCert = new Label(), lblTotal = new Label(), lblAtual = new Label(), lblContagem = new Label(), lblEtapa = new Label(), lblEstado = new Label();
        TextBox txtLog = new TextBox();
        Timer relogio = new Timer();
        List<Configuracao> configs = new List<Configuracao>();
        List<Regras.Cert> certs = new List<Regras.Cert>();
        Configuracao atual; // a selecionada (null = nova, ainda não salva)
        bool alterada;
        string ultimoLog = "";

        public Janela()
        {
            Text = "Automação PGFN";
            Font = new Font("Segoe UI", 9F);
            Size = new Size(1100, 760);
            MinimumSize = new Size(980, 680);
            StartPosition = FormStartPosition.CenterScreen;
            try { Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath); } catch { }

            // --- configurações (esquerda)
            var grpLista = new GroupBox { Text = "Configurações salvas", Left = 10, Top = 10, Width = 240, Height = 330, Anchor = AnchorStyles.Top | AnchorStyles.Left };
            lstConfigs.SetBounds(10, 22, 220, 255); grpLista.Controls.Add(lstConfigs);
            Botao(btnNova, "Nova", 10, 285, 105, grpLista); Botao(btnExcluir, "Excluir", 125, 285, 105, grpLista);
            Controls.Add(grpLista);

            // --- edição (direita)
            var grpEd = new GroupBox { Text = "Configuração", Left = 260, Top = 10, Width = 815, Height = 330, Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right };
            grpEd.Controls.Add(new Label { Text = "Nome da configuração:", Left = 12, Top = 26, Width = 150 });
            txtNome.SetBounds(165, 22, 300, 24); grpEd.Controls.Add(txtNome);
            grpEd.Controls.Add(new Label { Text = "Certificado digital:", Left = 12, Top = 58, Width = 150 });
            cmbCert.SetBounds(165, 54, 520, 24); cmbCert.DropDownStyle = ComboBoxStyle.DropDownList; grpEd.Controls.Add(cmbCert);
            Botao(btnAtualizarCerts, "Atualizar lista", 692, 53, 110, grpEd);
            lblCert.SetBounds(165, 82, 637, 20); lblCert.ForeColor = Color.DimGray; grpEd.Controls.Add(lblCert);
            lblPasta.SetBounds(165, 102, 637, 20); lblPasta.ForeColor = Color.DimGray; grpEd.Controls.Add(lblPasta);
            lblPasta.AutoEllipsis = true; lblCert.AutoEllipsis = true; // caminho longo: "…" e o texto inteiro ao passar o mouse
            grpEd.Controls.Add(new Label { Text = "CNPJs (um por linha,\ncom ou sem máscara):", Left = 12, Top = 128, Width = 150, Height = 40 });
            txtCnpjs.SetBounds(165, 126, 300, 192); txtCnpjs.Multiline = true; txtCnpjs.ScrollBars = ScrollBars.Vertical; txtCnpjs.Font = new Font("Consolas", 10F); txtCnpjs.AcceptsReturn = true;
            grpEd.Controls.Add(txtCnpjs);
            Botao(btnValidar, "Validar e organizar", 475, 126, 160, grpEd);
            lblCnpjs.SetBounds(475, 160, 327, 120); grpEd.Controls.Add(lblCnpjs);
            Botao(btnSalvar, "Salvar configuração", 475, 290, 160, grpEd);
            btnSalvar.Font = new Font(Font, FontStyle.Bold);
            Controls.Add(grpEd);

            // --- execução (embaixo)
            var grpEx = new GroupBox { Text = "Execução", Left = 10, Top = 348, Width = 1065, Height = 365, Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right };
            Botao(btnIniciar, "▶ Iniciar", 12, 24, 120, grpEx); btnIniciar.Font = new Font(Font, FontStyle.Bold);
            Botao(btnPausar, "Pausar", 140, 24, 90, grpEx);
            Botao(btnRetomar, "Retomar", 236, 24, 90, grpEx);
            Botao(btnParar, "Parar após o CNPJ atual", 332, 24, 170, grpEx);
            Botao(btnZerar, "Nova rodada (zerar andamento)", 508, 24, 200, grpEx);
            Botao(btnPasta, "Abrir pasta dos documentos", 714, 24, 190, grpEx);
            Botao(btnRefazerSemProc, "Refazer sem procuração", 910, 24, 145, grpEx);
            int y = 60;
            foreach (var l in new[] { lblEstado, lblExecCert, lblTotal, lblAtual, lblContagem, lblEtapa })
            { l.SetBounds(12, y, 1040, 20); l.AutoEllipsis = true; l.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right; grpEx.Controls.Add(l); y += 20; }
            // 0.34.0: barra do progresso (CNPJs já analisados / total)
            barra.SetBounds(12, y + 2, 1040, 14); barra.Minimum = 0; barra.Maximum = 100; barra.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            grpEx.Controls.Add(barra); y += 20;
            lblEstado.Font = new Font(Font, FontStyle.Bold);
            txtLog.SetBounds(12, y + 6, 1040, 365 - y - 18); txtLog.Multiline = true; txtLog.ReadOnly = true; txtLog.ScrollBars = ScrollBars.Both; txtLog.WordWrap = false;
            txtLog.Font = new Font("Consolas", 8.5F); txtLog.BackColor = Color.White;
            txtLog.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            grpEx.Controls.Add(txtLog);
            Controls.Add(grpEx);

            // --- eventos
            lstConfigs.SelectedIndexChanged += delegate { if (lstConfigs.SelectedIndex >= 0 && lstConfigs.SelectedIndex < configs.Count && configs[lstConfigs.SelectedIndex] != atual) Mostrar(configs[lstConfigs.SelectedIndex]); };
            btnNova.Click += delegate { if (Descartar()) { lstConfigs.ClearSelected(); Mostrar(null); } };
            btnExcluir.Click += delegate { Excluir(); };
            btnSalvar.Click += delegate { Salvar(true); };
            btnValidar.Click += delegate { Validar(true); };
            btnAtualizarCerts.Click += delegate { CarregarCertificados(); MostrarCertificado(); };
            cmbCert.SelectedIndexChanged += delegate { alterada = true; MostrarCertificado(); };
            txtNome.TextChanged += delegate { alterada = true; };
            txtCnpjs.TextChanged += delegate { alterada = true; };
            btnIniciar.Click += delegate { Iniciar(); };
            btnPausar.Click += delegate { Flag(Execucao.Pausar, true); };
            btnRetomar.Click += delegate { Flag(Execucao.Pausar, false); };
            btnParar.Click += delegate {
                if (MessageBox.Show("Encerrar a execução depois do CNPJ que está em processamento?\nO CNPJ atual termina normalmente; os demais ficam pendentes.",
                    Text, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes) Flag(Execucao.Parar, true);
            };
            btnZerar.Click += delegate { Zerar(); };
            btnPasta.Click += delegate { AbrirPasta(); };
            btnRefazerSemProc.Click += delegate { RefazerSemProc(); };
            FormClosing += (s, e) => { if (!Descartar()) e.Cancel = true; };
            relogio.Interval = 2000;
            relogio.Tick += delegate { Atualizar(); };

            Directory.CreateDirectory(Execucao.PastaConfigs);
            Importar();
            CarregarCertificados();
            CarregarConfigs(null);
            relogio.Start();
            Atualizar();
        }

        static void Botao(Button b, string texto, int x, int y, int w, Control pai) { b.Text = texto; b.SetBounds(x, y, w, 28); pai.Controls.Add(b); }

        // Primeira vez: a lista antiga (cnpjs.json) vira uma configuração, com o andamento que já existe (nada é refeito).
        void Importar()
        {
            if (Directory.GetFiles(Execucao.PastaConfigs, "*.json").Any(f => !f.EndsWith(".andamento.json"))) return;
            string antigo = Path.Combine(Execucao.Base, "cnpjs.json");
            if (!File.Exists(antigo)) return;
            try
            {
                var c = Configuracao.Ler(antigo);
                var achados = Regras.CertificadosDoWindows().Where(x => Regras.Normalizar(x.Nome).Contains(Regras.Normalizar(c.Certificado))).Select(x => x.Nome).Distinct().ToList();
                if (achados.Count == 1) c.Certificado = achados[0]; // nome exato, como aparece no Chrome
                c.Nome = "Lista do cnpjs.json (importada)";
                c.Arquivo = Path.Combine(Execucao.PastaConfigs, Regras.ArquivoDaConfig(c.Nome) + ".json");
                c.Pasta = "";
                c.Gravar();
                string andAntigo = Path.Combine(Execucao.PastaOrq, "andamento.json");
                if (File.Exists(andAntigo) && !File.Exists(c.Andamento)) File.Copy(andAntigo, c.Andamento);
            }
            catch (Exception e) { MessageBox.Show("Não consegui importar cnpjs.json: " + e.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Warning); }
        }

        void CarregarCertificados()
        {
            string sel = cmbCert.SelectedItem != null ? ((ItemCert)cmbCert.SelectedItem).Nome : (atual != null ? atual.Certificado : "");
            try { certs = Regras.CertificadosDoWindows(); }
            catch (Exception e) { certs = new List<Regras.Cert>(); MessageBox.Show("Não consegui ler os certificados do Windows: " + e.Message, Text); }
            bool antes = alterada;
            cmbCert.Items.Clear();
            foreach (var n in certs.Select(c => c.Nome).Distinct()) cmbCert.Items.Add(new ItemCert(n, certs.Where(c => c.Nome == n).ToList()));
            SelecionarCert(sel);
            alterada = antes;
        }

        class ItemCert
        {
            public string Nome; public List<Regras.Cert> Certs; public bool Ausente;
            public ItemCert(string n, List<Regras.Cert> c) { Nome = n; Certs = c; }
            public override string ToString()
            {
                if (Ausente) return Nome + "   (NÃO ENCONTRADO neste computador)";
                if (Certs.Count > 1) return Nome + "   (" + Certs.Count + " certificados com este nome)";
                return Nome + "   (válido até " + Certs[0].Validade.ToString("dd/MM/yyyy") + ")";
            }
        }

        void SelecionarCert(string nome)
        {
            cmbCert.SelectedIndex = -1;
            if (string.IsNullOrEmpty(nome)) return;
            for (int i = 0; i < cmbCert.Items.Count; i++)
                if (Regras.Normalizar(((ItemCert)cmbCert.Items[i]).Nome) == Regras.Normalizar(nome)) { cmbCert.SelectedIndex = i; return; }
            // o certificado da configuração não está neste computador: aparece marcado (não some, nem é trocado por outro)
            cmbCert.Items.Add(new ItemCert(nome, new List<Regras.Cert>()) { Ausente = true });
            cmbCert.SelectedIndex = cmbCert.Items.Count - 1;
        }

        void MostrarCertificado()
        {
            var it = cmbCert.SelectedItem as ItemCert;
            if (it == null) { lblCert.Text = certs.Count == 0 ? "Nenhum certificado com chave privada encontrado no Windows (Pessoal)." : "Escolha o certificado."; lblPasta.Text = ""; return; }
            if (it.Ausente) { lblCert.ForeColor = Color.Firebrick; lblCert.Text = "Este certificado não está instalado neste computador: a execução não começa."; }
            else if (it.Certs.Count > 1) { lblCert.ForeColor = Color.DarkOrange; lblCert.Text = "Há " + it.Certs.Count + " certificados com este nome (" + string.Join(", ", it.Certs.Select(c => "até " + c.Validade.ToString("dd/MM/yyyy"))) + "): no login você confirma qual usar."; }
            else if (it.Certs[0].Validade < DateTime.Now) { lblCert.ForeColor = Color.Firebrick; lblCert.Text = "Certificado VENCIDO em " + it.Certs[0].Validade.ToString("dd/MM/yyyy") + "."; }
            else { lblCert.ForeColor = Color.DimGray; lblCert.Text = "Emitido por " + it.Certs[0].Emissor + "; válido até " + it.Certs[0].Validade.ToString("dd/MM/yyyy") + "."; }
            string pasta = atual != null && atual.Pasta.Length > 0 && Regras.Normalizar(atual.Certificado) == Regras.Normalizar(it.Nome) ? atual.Pasta : Regras.PastaCertificado(it.Nome);
            lblPasta.Text = "Documentos em: " + Execucao.PastaSaida + "\\" + pasta + "\\<CNPJ>";
        }

        void CarregarConfigs(string selecionar)
        {
            configs = Directory.GetFiles(Execucao.PastaConfigs, "*.json").Where(f => !f.EndsWith(".andamento.json"))
                .Select(f => { try { return Configuracao.Ler(f); } catch { return null; } }).Where(c => c != null).OrderBy(c => c.Nome).ToList();
            lstConfigs.Items.Clear();
            foreach (var c in configs) lstConfigs.Items.Add(c.Nome + "  (" + c.Cnpjs.Count + ")");
            var alvo = configs.FirstOrDefault(c => c.Arquivo == selecionar) ?? (configs.Count > 0 ? configs[0] : null);
            Mostrar(alvo);
        }

        void Mostrar(Configuracao c)
        {
            atual = c;
            if (c != null) lstConfigs.SelectedIndex = configs.IndexOf(c);
            txtNome.Text = c != null ? c.Nome : "";
            txtCnpjs.Text = c != null ? string.Join("\r\n", c.Cnpjs.Select(Regras.Formatar)) : "";
            SelecionarCert(c != null ? c.Certificado : "");
            MostrarCertificado();
            lblCnpjs.ForeColor = Color.DimGray;
            lblCnpjs.Text = c != null ? c.Cnpjs.Count + " CNPJ(s) na lista." : "Nova configuração: dê um nome, escolha o certificado e cole os CNPJs.";
            alterada = false;
            Atualizar();
        }

        bool Descartar()
        {
            if (!alterada) return true;
            var r = MessageBox.Show("Há alterações não salvas nesta configuração. Salvar agora?", Text, MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
            if (r == DialogResult.Cancel) return false;
            if (r == DialogResult.Yes) return Salvar(false);
            alterada = false;
            return true;
        }

        // Organiza a lista: válidos formatados (sem repetição); inválidos ficam no topo para corrigir.
        Regras.Lista Validar(bool reescrever)
        {
            var l = Regras.LerCnpjs(txtCnpjs.Text);
            if (reescrever)
            {
                bool antes = alterada;
                txtCnpjs.Text = string.Join("\r\n", l.Invalidos.Concat(l.Validos.Select(Regras.Formatar)));
                alterada = antes || l.Repetidos.Count > 0;
            }
            var sb = new StringBuilder();
            sb.AppendLine(l.Validos.Count + " CNPJ(s) válido(s).");
            if (l.Repetidos.Count > 0) sb.AppendLine(l.Repetidos.Count + " repetido(s) removido(s): " + string.Join(", ", l.Repetidos.Select(Regras.Formatar)));
            if (l.Invalidos.Count > 0) sb.AppendLine(l.Invalidos.Count + " INVÁLIDO(S) (dígito verificador ou formato), no topo da lista: " + string.Join(", ", l.Invalidos.Take(6)) + (l.Invalidos.Count > 6 ? "…" : ""));
            lblCnpjs.ForeColor = l.Invalidos.Count > 0 ? Color.Firebrick : Color.DarkGreen;
            lblCnpjs.Text = sb.ToString();
            return l;
        }

        bool Salvar(bool avisar)
        {
            string nome = txtNome.Text.Trim();
            var it = cmbCert.SelectedItem as ItemCert;
            if (nome.Length == 0) { MessageBox.Show("Dê um nome à configuração.", Text); txtNome.Focus(); return false; }
            if (it == null) { MessageBox.Show("Escolha o certificado digital.", Text); return false; }
            var l = Validar(true);
            if (l.Invalidos.Count > 0) { MessageBox.Show("Corrija ou apague os CNPJs inválidos (estão no topo da lista) antes de salvar.", Text, MessageBoxButtons.OK, MessageBoxIcon.Warning); return false; }
            if (l.Validos.Count == 0) { MessageBox.Show("Informe pelo menos um CNPJ.", Text); return false; }
            string arq = atual != null ? atual.Arquivo : Path.Combine(Execucao.PastaConfigs, Regras.ArquivoDaConfig(nome) + ".json");
            if (atual == null && File.Exists(arq)) { MessageBox.Show("Já existe uma configuração com esse nome.", Text); return false; }
            var exec = Execucao.EmAndamento();
            if (exec != null && atual != null && string.Equals(Execucao.Campo(exec, "config"), atual.Arquivo, StringComparison.OrdinalIgnoreCase))
                MessageBox.Show("Esta configuração está em execução: as mudanças valem a partir da próxima vez que você clicar em Iniciar.", Text);
            var c = atual ?? new Configuracao { Arquivo = arq };
            if (Regras.Normalizar(c.Certificado) != Regras.Normalizar(it.Nome)) c.Pasta = ""; // outro certificado: outra pasta
            c.Nome = nome; c.Certificado = it.Nome; c.Cnpjs = l.Validos;
            try { c.Gravar(); }
            catch (Exception e) { MessageBox.Show("Não consegui salvar: " + e.Message, Text); return false; }
            alterada = false;
            CarregarConfigs(c.Arquivo);
            if (avisar) { lblCnpjs.ForeColor = Color.DarkGreen; lblCnpjs.Text = "Configuração salva: " + c.Cnpjs.Count + " CNPJ(s)."; }
            return true;
        }

        void Excluir()
        {
            if (atual == null) return;
            var exec = Execucao.EmAndamento();
            if (exec != null && string.Equals(Execucao.Campo(exec, "config"), atual.Arquivo, StringComparison.OrdinalIgnoreCase)) { MessageBox.Show("Esta configuração está em execução.", Text); return; }
            if (MessageBox.Show("Excluir a configuração \"" + atual.Nome + "\"?\nOs documentos já salvos NÃO são apagados.", Text, MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;
            string marca = DateTime.Now.ToString("yyyyMMdd_HHmmss");
            File.Move(atual.Arquivo, atual.Arquivo + ".excluida_" + marca); // guardada, não apagada
            if (File.Exists(atual.Andamento)) File.Move(atual.Andamento, atual.Andamento + ".excluida_" + marca);
            alterada = false;
            CarregarConfigs(null);
        }

        void Iniciar()
        {
            if (Execucao.EmAndamento() != null) { MessageBox.Show("Já há uma execução em andamento. Use Pausar/Retomar ou espere terminar.", Text); return; }
            if (alterada || atual == null) { if (!Salvar(false)) return; }
            var c = atual;
            // o certificado tem que existir neste computador, com exatamente esse nome (nunca outro por aproximação)
            var iguais = Regras.ComONome(Regras.CertificadosDoWindows(), c.Certificado);
            if (iguais.Count == 0) { MessageBox.Show("O certificado \"" + c.Certificado + "\" não foi encontrado no Windows (certificados pessoais com chave privada).\nA execução NÃO foi iniciada.", Text, MessageBoxButtons.OK, MessageBoxIcon.Error); return; }
            if (iguais.All(x => x.Validade < DateTime.Now)) { MessageBox.Show("O certificado \"" + c.Certificado + "\" está vencido. A execução NÃO foi iniciada.", Text, MessageBoxButtons.OK, MessageBoxIcon.Error); return; }
            if (iguais.Count > 1 && MessageBox.Show("Há " + iguais.Count + " certificados com o nome \"" + c.Certificado + "\".\nA automação não escolhe sozinha entre eles: no login ela vai PAUSAR na janela \"Selecione um certificado\" para você confirmar qual usar.\n\nContinuar?",
                Text, MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;
            if (!File.Exists(Execucao.Orquestrador)) { MessageBox.Show("Não encontrei " + Execucao.Orquestrador, Text); return; }
            if (!Execucao.AjudanteInstalado() && MessageBox.Show("O ajudante do Windows não está instalado (rode Instalar.bat na pasta ATM_PGFN). Sem ele o login e a janela \"Salvar como\" não são automáticos.\nContinuar mesmo assim?",
                Text, MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;
            if (MessageBox.Show("Iniciar com:\n\nCertificado: " + c.Certificado + "\nCNPJs: " + c.Cnpjs.Count + "\nPasta: " + Path.Combine(Execucao.PastaSaida, c.Pasta) +
                "\n\nO Chrome será fechado e reaberto a cada CNPJ (salve o que estiver aberto nele). Recarregue a extensão se ela foi atualizada.",
                Text, MessageBoxButtons.OKCancel, MessageBoxIcon.Information) != DialogResult.OK) return;
            try { File.Delete(Execucao.Pausar); File.Delete(Execucao.Parar); } catch { }
            try { Execucao.Iniciar(c); } catch (Exception e) { MessageBox.Show("Não consegui iniciar o orquestrador: " + e.Message, Text); return; }
            lblEstado.Text = "Iniciando…";
        }

        // pausar.flag: criado pelo botão Pausar (data) ou pelo orquestrador quando um CNPJ travou e não se recuperou (motivo)
        static string MotivoDaPausa()
        {
            string t = (Execucao.LerTexto(Execucao.Pausar) ?? "").Trim();
            if (t.StartsWith("PAUSA")) return "  —  " + t;
            return "  —  PAUSA pedida: o próximo CNPJ espera você clicar em Retomar (o atual termina normalmente)";
        }

        void Flag(string arq, bool criar)
        {
            if (Execucao.EmAndamento() == null) { MessageBox.Show("Não há execução em andamento.", Text); return; }
            try { if (criar) File.WriteAllText(arq, DateTime.Now.ToString("o")); else if (File.Exists(arq)) File.Delete(arq); }
            catch (Exception e) { MessageBox.Show(e.Message, Text); }
            Atualizar();
        }

        void Zerar()
        {
            if (atual == null) return;
            var exec = Execucao.EmAndamento();
            if (exec != null && string.Equals(Execucao.Campo(exec, "config"), atual.Arquivo, StringComparison.OrdinalIgnoreCase)) { MessageBox.Show("Esta configuração está em execução.", Text); return; }
            if (!File.Exists(atual.Andamento)) { MessageBox.Show("Esta configuração ainda não tem andamento: todos os CNPJs serão processados.", Text); return; }
            if (MessageBox.Show("Começar uma nova rodada de \"" + atual.Nome + "\"? Todos os CNPJs voltam a pendente e serão processados de novo.\n\nO andamento atual é guardado em cópia. Documentos já salvos NÃO são apagados, e PDFs já emitidos neste mês não são emitidos de novo.",
                Text, MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
            File.Move(atual.Andamento, atual.Andamento + ".rodada_" + DateTime.Now.ToString("yyyyMMdd_HHmmss"));
            Atualizar();
        }

        void RefazerSemProc()
        {
            if (atual == null) return;
            var exec = Execucao.EmAndamento();
            if (exec != null) { MessageBox.Show("Há uma execução em andamento. Use depois que ela terminar.", Text); return; }
            if (MessageBox.Show("Os CNPJs marcados \"sem procuração\" em \"" + atual.Nome + "\" voltam a pendente e serão tentados de novo no próximo Iniciar.\n\nUse só depois de criar a procuração eletrônica no e-CAC. Continuar?",
                Text, MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
            int n = 0;
            try { n = Execucao.RefazerSemProcuracao(atual.Andamento); } catch (Exception ex) { MessageBox.Show("Não consegui alterar o andamento: " + ex.Message, Text); return; }
            MessageBox.Show(n == 0 ? "Nenhum CNPJ sem procuração, com procuração cancelada ou com aviso de Caixa Postal nesta configuração." : n + " CNPJ(s) voltaram a pendente.", Text);
            Atualizar();
        }

        void AbrirPasta()
        {
            string p = Execucao.PastaSaida;
            Directory.CreateDirectory(p);
            if (atual != null && atual.Pasta.Length > 0) { string q = Path.Combine(p, atual.Pasta); Directory.CreateDirectory(q); p = q; }
            Process.Start("explorer.exe", "\"" + p + "\"");
        }

        // 0.33.1: como terminou a última execução (ultima_execucao.json do orquestrador), para não parecer travada no fim.
        static string UltimaExecucao()
        {
            var u = Execucao.LerJson(Path.Combine(Execucao.PastaOrq, "ultima_execucao.json"));
            DateTime fim;
            if (u == null || !DateTime.TryParse(Execucao.Campo(u, "fim"), out fim)) return null;
            string conta = Execucao.Campo(u, "concluidos") + " de " + Execucao.Campo(u, "total") + " concluídos, " +
                Execucao.Campo(u, "erros") + " com erro, " +
                (Execucao.Campo(u, "semProcuracao").Length > 0 ? Execucao.Campo(u, "semProcuracao") + " sem procuração, " : "") +
                (Execucao.Campo(u, "procCancelada").Length > 0 && Execucao.Campo(u, "procCancelada") != "0" ? Execucao.Campo(u, "procCancelada") + " com procuração cancelada, " : "") +
                (Execucao.Campo(u, "caixaPostal").Length > 0 && Execucao.Campo(u, "caixaPostal") != "0" ? Execucao.Campo(u, "caixaPostal") + " com aviso de Caixa Postal, " : "") +
                Execucao.Campo(u, "pendentes") + " restantes";
            string nome = Execucao.Campo(u, "nome"), quando = fim.ToString("dd/MM HH:mm");
            switch (Execucao.Campo(u, "encerramento"))
            {
                case "terminou": return "TERMINADA em " + quando + (nome.Length > 0 ? " (" + nome + ")" : "") + ": " + conta + ". Pode fechar o Chrome.";
                case "parada": return "Parada pela interface em " + quando + ": " + conta + ". Iniciar continua de onde parou.";
                case "chrome_fechado": return "Encerrada em " + quando + " (Chrome fechado): " + conta + ". Iniciar continua de onde parou.";
                default: return "Encerrada com ERRO em " + quando + " (veja o log): " + conta + ". Iniciar continua de onde parou.";
            }
        }

        // Acompanhamento: lê os arquivos do orquestrador a cada 2 s.
        void Atualizar()
        {
            var exec = Execucao.EmAndamento();
            Configuracao mostrada = atual;
            if (exec != null)
            {
                string arq = Execucao.Campo(exec, "config");
                mostrada = configs.FirstOrDefault(c => string.Equals(c.Arquivo, arq, StringComparison.OrdinalIgnoreCase));
                if (mostrada == null) try { mostrada = Configuracao.Ler(arq); } catch { }
            }
            bool pausa = File.Exists(Execucao.Pausar), parar = File.Exists(Execucao.Parar);
            if (exec == null) lblEstado.Text = UltimaExecucao() ?? "Parada. Escolha a configuração e clique em Iniciar.";
            else lblEstado.Text = "EM EXECUÇÃO: " + (mostrada != null ? mostrada.Nome : Execucao.Campo(exec, "config")) +
                (parar ? "  —  vai encerrar depois do CNPJ atual" : pausa ? MotivoDaPausa() : "");
            lblEstado.ForeColor = exec == null ? Color.DimGray : pausa || parar ? Color.DarkOrange : Color.DarkGreen;
            btnIniciar.Enabled = exec == null;
            btnPausar.Enabled = exec != null && !pausa; btnRetomar.Enabled = exec != null && pausa; btnParar.Enabled = exec != null && !parar;
            btnZerar.Enabled = exec == null && atual != null; btnExcluir.Enabled = atual != null;

            if (mostrada == null) { lblExecCert.Text = lblTotal.Text = lblAtual.Text = lblContagem.Text = lblEtapa.Text = ""; barra.Value = 0; btnRefazerSemProc.Enabled = false; }
            else
            {
                lblExecCert.Text = "Certificado: " + mostrada.Certificado;
                var and = Execucao.LerJson(exec != null ? Execucao.Campo(exec, "andamento") : mostrada.Andamento);
                // 0.34.0: contador vindo do andamento (o checkpoint em disco): cada CNPJ conta uma vez; sobrevive a reinícios
                int conc = 0, pend = 0, erro = 0, semProc = 0, cancel = 0, caixa = 0;
                foreach (var cnpj in mostrada.Cnpjs.Distinct())
                {
                    object v = null;
                    var reg = and != null && and.TryGetValue(cnpj, out v) ? v as Dictionary<string, object> : null;
                    string s = Execucao.Campo(reg, "situacao");
                    if (s == "concluido") conc++; else if (s == "erro") erro++; else if (s == "sem_procuracao") semProc++;
                    else if (s == "procuracao_cancelada") cancel++; else if (s == "caixa_postal") caixa++; else pend++;
                }
                int total = conc + erro + semProc + cancel + caixa + pend;
                int pct = total == 0 ? 0 : (int)Math.Floor(100.0 * (total - pend) / total);
                lblTotal.Text = "Total de CNPJs: " + total + "    Analisados: " + (total - pend) + "    Progresso: " + pct + "%";
                lblContagem.Text = "Concluídos: " + conc + "    Com erro: " + erro + "    Sem procuração: " + semProc +
                    (cancel > 0 ? "    Procuração cancelada: " + cancel : "") + (caixa > 0 ? "    Aviso de Caixa Postal: " + caixa : "") + "    Restantes: " + pend;
                barra.Value = Math.Max(0, Math.Min(100, pct));
                btnRefazerSemProc.Enabled = exec == null && semProc + cancel + caixa > 0;
                var at = exec != null ? Execucao.LerJson(Path.Combine(Execucao.PastaOrq, "atual.json")) : null;
                if (at != null && Execucao.Campo(at, "pid") != Execucao.Campo(exec, "pid")) at = null; // de outra execução (antiga)
                string cnpjAtual = Execucao.Campo(at, "cnpj");
                lblAtual.Text = "CNPJ em processamento: " + (cnpjAtual.Length == 14 ? Regras.Formatar(cnpjAtual) + "  (" + (mostrada.Cnpjs.IndexOf(cnpjAtual) + 1) + " de " + mostrada.Cnpjs.Count + ")" : "—");
                var si = at != null ? Execucao.LerJson(Path.Combine(Execucao.PastaOrq, "sinal.json")) : null;
                string etapa = si != null && Execucao.Campo(si, "sessao") == Execucao.Campo(at, "sessao")
                    ? "[" + Execucao.Campo(si, "situacao") + "] " + Execucao.Campo(si, "mensagem").Split('\n')[0] : (exec != null ? "abrindo o Chrome / login…" : "—");
                // ponto exato (checkpoint enviado pela extensão ao vigia de travamentos): conta e parcela em processamento
                var pg = at != null ? Execucao.LerJson(Path.Combine(Execucao.PastaOrq, "progresso.json")) : null;
                object cpo = null;
                var cp = pg != null && Execucao.Campo(pg, "sessao") == Execucao.Campo(at, "sessao") && pg.TryGetValue("checkpoint", out cpo) ? cpo as Dictionary<string, object> : null;
                string ponto = cp == null ? "" : (Execucao.Campo(cp, "conta").Length > 0 ? "   |   conta " + Execucao.Campo(cp, "conta") : "") +
                    (Execucao.Campo(cp, "parcela").Length > 0 ? ", parcela " + Execucao.Campo(cp, "parcela") : "") +
                    (Execucao.Campo(cp, "salvos").Length > 0 ? ", PDFs salvos: " + Execucao.Campo(cp, "salvos") : "");
                lblEtapa.Text = "Etapa atual: " + etapa + ponto;
                lblEtapa.ForeColor = etapa.StartsWith("[aguardando_humano]") ? Color.Firebrick : SystemColors.ControlText;
            }
            string log = Execucao.FimDoLog(48000);
            if (log != ultimoLog)
            {
                ultimoLog = log;
                txtLog.Clear();
                txtLog.AppendText(log); // AppendText deixa a última linha à vista
            }
        }
    }

    static class Programa
    {
        [STAThread]
        static int Main(string[] args)
        {
            if (args.Length >= 2 && args[0] == "--autoteste") return AutoTeste.Rodar(args[1]);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Janela());
            return 0;
        }
    }

    // Testes das regras sem abrir a tela (resultado num arquivo de texto).
    static class AutoTeste
    {
        public static int Rodar(string saida)
        {
            var sb = new StringBuilder(); int falhas = 0;
            Action<string, bool> ok = (nome, cond) => { sb.AppendLine((cond ? "ok    " : "FALHA ") + nome); if (!cond) falhas++; };
            ok("CNPJ válido", Regras.CnpjValido("11222333000181"));
            ok("CNPJ com DV errado", !Regras.CnpjValido("11444777000100"));
            ok("CNPJ repetido 1111...", !Regras.CnpjValido("11111111111111"));
            var l = Regras.LerCnpjs("11.222.333/0001-81\r\n11222333000181\n 11.444.777/0001-61 \nabc\n11.444.777/0001-00\n\n123");
            ok("lista: 2 válidos", l.Validos.Count == 2 && l.Validos[0] == "11222333000181" && l.Validos[1] == "11444777000161");
            ok("lista: 1 repetido", l.Repetidos.Count == 1);
            ok("lista: 3 inválidos", l.Invalidos.Count == 3);
            ok("formatar", Regras.Formatar("11222333000181") == "11.222.333/0001-81");
            ok("pasta do certificado", Regras.PastaCertificado("EMPRESA EXEMPLO LTDA:11444777000161") == "EMPRESA_EXEMPLO_LTDA_11444777000161");
            ok("pasta com acento", Regras.PastaCertificado("José Ação & Cia. Ltda") == "JOSE_ACAO_CIA_LTDA");
            sb.AppendLine("pasta (para comparar com o orquestrador): " + Regras.PastaCertificado("Ótica São João: Comércio-Ltda/ME 12.345"));
            ok("normalizar", Regras.Normalizar("  empresa  exemplo ") == "EMPRESA EXEMPLO");
            var certs = Regras.CertificadosDoWindows();
            sb.AppendLine("certificados no Windows: " + string.Join(" | ", certs.Select(c => c.Nome + " (até " + c.Validade.ToString("dd/MM/yyyy") + ")")));
            if (certs.Count > 0)
            {
                ok("nome exato acha 1", Regras.ComONome(certs, certs[0].Nome).Count >= 1);
                ok("trecho do nome NÃO acha", Regras.ComONome(certs, certs[0].Nome.Substring(0, certs[0].Nome.Length / 2)).Count == 0);
            }
            var dups = new List<Regras.Cert> { new Regras.Cert { Nome = "EMPRESA X:1" }, new Regras.Cert { Nome = "empresa x:1" }, new Regras.Cert { Nome = "EMPRESA X:12" } };
            ok("duplicados com o mesmo nome: 2 (não confunde :1 com :12)", Regras.ComONome(dups, "EMPRESA X:1").Count == 2);
            string tmp = Path.Combine(Path.GetTempPath(), "pgfn_autoteste_config.json");
            var c1 = new Configuracao { Arquivo = tmp, Nome = "Teste", Certificado = "EMPRESA X:1", Cnpjs = new List<string> { "11222333000181", "11444777000161" } };
            c1.Gravar();
            var c2 = Configuracao.Ler(tmp);
            ok("configuração grava e lê", c2.Nome == "Teste" && c2.Certificado == "EMPRESA X:1" && c2.Pasta == "EMPRESA_X_1" && c2.Cnpjs.Count == 2 && c2.Cnpjs[1] == "11444777000161");
            ok("andamento ao lado", c2.Andamento.EndsWith("pgfn_autoteste_config.andamento.json"));
            sb.AppendLine("arquivo gravado: " + File.ReadAllText(tmp));
            sb.AppendLine("raiz ATM_PGFN: " + Execucao.Base);
            ok("raiz tem Automacao, Extensao_Chrome e Ajudante_Windows", Directory.Exists(Execucao.PastaOrq) && Directory.Exists(Path.Combine(Execucao.Base, "Extensao_Chrome")) && Directory.Exists(Path.Combine(Execucao.Base, "Ajudante_Windows")));
            sb.AppendLine("diretório de saída: " + Execucao.PastaSaida);
            File.Delete(tmp);
            // 0.34.0: "Refazer sem procuração" só mexe nos sem_procuracao
            string andTmp = Path.Combine(Path.GetTempPath(), "pgfn_autoteste_and.json");
            File.WriteAllText(andTmp, "{\"11222333000181\":{\"situacao\":\"sem_procuracao\",\"mensagem\":\"x\",\"tentativas\":3},\"90000006000151\":{\"situacao\":\"concluido\",\"mensagem\":\"ok\"}}", new UTF8Encoding(false));
            int nRef = Execucao.RefazerSemProcuracao(andTmp);
            var andLido = Execucao.LerJson(andTmp);
            ok("refazer sem procuração: 1 volta a pendente, concluído intacto", nRef == 1 &&
                Execucao.Campo(andLido["11222333000181"] as Dictionary<string, object>, "situacao") == "pendente" &&
                Execucao.Campo(andLido["11222333000181"] as Dictionary<string, object>, "tentativas") == "3" &&
                Execucao.Campo(andLido["90000006000151"] as Dictionary<string, object>, "situacao") == "concluido");
            ok("refazer de novo: nada a fazer", Execucao.RefazerSemProcuracao(andTmp) == 0);
            // 0.37.0: "procuracao_cancelada" também volta a pendente; os outros ficam intactos
            // (apaga a cópia do caso anterior: no mesmo segundo o nome da cópia seria o mesmo)
            foreach (var bak in Directory.GetFiles(Path.GetTempPath(), "pgfn_autoteste_and.json.antes_refazer_*")) File.Delete(bak);
            File.WriteAllText(andTmp, "{\"90000023000199\":{\"situacao\":\"procuracao_cancelada\",\"mensagem\":\"x\"},\"90000006000151\":{\"situacao\":\"erro\",\"mensagem\":\"e\"}}", new UTF8Encoding(false));
            int nCan = Execucao.RefazerSemProcuracao(andTmp);
            var andCan = Execucao.LerJson(andTmp);
            ok("refazer: procuração cancelada volta a pendente, erro intacto", nCan == 1 &&
                Execucao.Campo(andCan["90000023000199"] as Dictionary<string, object>, "situacao") == "pendente" &&
                Execucao.Campo(andCan["90000023000199"] as Dictionary<string, object>, "mensagem").Contains("procuração cancelada") &&
                Execucao.Campo(andCan["90000006000151"] as Dictionary<string, object>, "situacao") == "erro");
            // 0.39.0: "caixa_postal" (aviso de Caixa Postal) também volta a pendente; concluído intacto
            foreach (var bak in Directory.GetFiles(Path.GetTempPath(), "pgfn_autoteste_and.json.antes_refazer_*")) File.Delete(bak);
            File.WriteAllText(andTmp, "{\"90000023000199\":{\"situacao\":\"caixa_postal\",\"mensagem\":\"x\"},\"90000006000151\":{\"situacao\":\"concluido\",\"mensagem\":\"ok\"}}", new UTF8Encoding(false));
            int nCx = Execucao.RefazerSemProcuracao(andTmp);
            var andCx = Execucao.LerJson(andTmp);
            ok("refazer: aviso de Caixa Postal volta a pendente, concluído intacto", nCx == 1 &&
                Execucao.Campo(andCx["90000023000199"] as Dictionary<string, object>, "situacao") == "pendente" &&
                Execucao.Campo(andCx["90000023000199"] as Dictionary<string, object>, "mensagem").Contains("Caixa Postal") &&
                Execucao.Campo(andCx["90000006000151"] as Dictionary<string, object>, "situacao") == "concluido");
            File.Delete(andTmp);
            foreach (var bak in Directory.GetFiles(Path.GetTempPath(), "pgfn_autoteste_and.json.antes_refazer_*")) File.Delete(bak);
            sb.AppendLine(falhas == 0 ? "TUDO OK" : falhas + " FALHA(S)");
            File.WriteAllText(saida, sb.ToString(), new UTF8Encoding(false));
            return falhas;
        }
    }
}
