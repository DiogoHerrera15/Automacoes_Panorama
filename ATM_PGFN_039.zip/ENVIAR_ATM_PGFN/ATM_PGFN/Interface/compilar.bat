@echo off
rem Compila a interface (Automacao_PGFN.exe) com o compilador C# que vem no Windows (.NET Framework 4). Sem instalar nada.
setlocal
set CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe
if not exist "%CSC%" set CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe
if not exist "%CSC%" (
  echo Nao encontrei o compilador do .NET Framework 4 ^(csc.exe^).
  exit /b 1
)
"%CSC%" /nologo /target:winexe /optimize+ /codepage:65001 /out:"%~dp0Automacao_PGFN.exe" /r:System.Windows.Forms.dll /r:System.Drawing.dll /r:System.Web.Extensions.dll /r:System.Core.dll "%~dp0AutomacaoPGFN.cs"
if errorlevel 1 (
  echo Falhou a compilacao.
  exit /b 1
)
echo Gerado: %~dp0Automacao_PGFN.exe
