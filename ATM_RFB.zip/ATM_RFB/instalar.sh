#!/bin/bash
# Prepara este Mac (Intel ou Apple Silicon) para rodar a automacao RFB.
# Rode UMA vez, no Terminal, dentro desta pasta:   bash instalar.sh
# Pode rodar de novo quando quiser: so instala o que falta.
cd "$(dirname "$0")" || exit 1
AQUI="$PWD"
export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"   # Homebrew: Apple Silicon e Intel

ok()   { echo "  [OK] $1"; }
erro() { echo "  [ERRO] $1"; exit 1; }

echo "Instalacao - Automacao RFB (certidoes da Receita Federal)"
echo "Pasta: $AQUI"
echo "Mac: $(uname -m) ($( [ "$(uname -m)" = arm64 ] && echo 'Apple Silicon' || echo 'Intel' ))"
echo

[ "$(uname -s)" = Darwin ] || erro "Este instalador e so para macOS."

echo "1/5 Google Chrome"
if [ -d "/Applications/Google Chrome.app" ]; then ok "Google Chrome encontrado"
else erro "Google Chrome nao encontrado em /Applications. Baixe em https://www.google.com/chrome/ , arraste para Aplicativos, abra uma vez e rode este instalador de novo."; fi

echo "2/5 Node.js (versao 18 ou mais nova)"
if ! command -v node >/dev/null 2>&1; then
  if command -v brew >/dev/null 2>&1; then
    echo "  Node.js nao encontrado. Instalando com Homebrew..."
    brew install node || erro "Falha ao instalar o Node.js com o Homebrew."
  else
    erro "Node.js nao encontrado. Instale a versao LTS em https://nodejs.org (instalador .pkg, serve para Intel e Apple Silicon) ou instale o Homebrew (https://brew.sh) e rode: brew install node . Depois rode este instalador de novo."
  fi
fi
VERSAO_NODE=$(node -p 'process.versions.node.split(".")[0]')
[ "$VERSAO_NODE" -ge 18 ] || erro "Node.js $(node -v) e antigo demais. Instale a versao 18 ou mais nova (https://nodejs.org)."
ok "Node.js $(node -v), npm $(npm -v)"

echo "3/5 Dependencias do programa (pdfjs-dist, via npm)"
if [ -f package-lock.json ]; then npm ci --no-fund --no-audit || npm install --no-fund --no-audit || erro "Falha no npm. Confira a internet e rode de novo."
else npm install --no-fund --no-audit || erro "Falha no npm. Confira a internet e rode de novo."; fi
ok "node_modules instalado"

echo "4/5 Python 3 e bibliotecas (Pillow, openpyxl) em ambiente proprio (.venv)"
if ! command -v python3 >/dev/null 2>&1; then
  erro "python3 nao encontrado. No Terminal rode: xcode-select --install (instala as ferramentas da Apple, inclusive o Python 3), espere terminar e rode este instalador de novo."
fi
[ -x .venv/bin/python3 ] || python3 -m venv .venv || erro "Nao consegui criar o ambiente .venv."
.venv/bin/python3 -m pip install --quiet --upgrade pip >/dev/null 2>&1
.venv/bin/python3 -m pip install --quiet -r requirements.txt || erro "Falha ao instalar Pillow/openpyxl (confira a internet)."
ok "Python $(.venv/bin/python3 -V | cut -d' ' -f2) com Pillow e openpyxl"

echo "5/5 Liberando os arquivos baixados de outro computador"
xattr -dr com.apple.quarantine "$AQUI" 2>/dev/null
chmod +x instalar.sh iniciar.sh 2>/dev/null
ok "permissoes ajustadas"

echo
echo "Instalacao concluida."
echo
echo "FALTA UM PASSO MANUAL: carregar a extensao no Chrome (so uma vez):"
echo "  1. No Chrome, abra  chrome://extensions  e ligue 'Modo do desenvolvedor' (canto superior direito)."
echo "  2. Clique em 'Carregar sem compactacao' e escolha a pasta:"
echo "       $AQUI/extensao-chrome"
echo "  3. Em 'Detalhes' da extensao 'Automacao_RFB', ligue 'Permitir na navegacao anonima'."
echo "  (passo a passo com detalhes no README.md)"
echo
if [ -t 0 ]; then
  read -r -p "Abrir agora o chrome://extensions e a pasta da extensao? (s/N) " r
  if [ "$r" = s ] || [ "$r" = S ]; then
    open -a "Google Chrome" "chrome://extensions" 2>/dev/null
    open "$AQUI/extensao-chrome"
  fi
fi
echo "Depois: abra a interface com dois cliques em \"INTERFACE RFB EMISSAO.command\" (ou use lista_cnpjs.txt + bash iniciar.sh --teste)."
