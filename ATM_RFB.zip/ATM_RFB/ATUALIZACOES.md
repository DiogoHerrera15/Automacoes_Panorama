# Histórico de atualizações — Automação RFB (ATM_RFB)

Resumo do que foi implementado em cada atualização. Os detalhes de uso estão no `README.md`.

## Pastas e documentos pelo nome da empresa
- Pasta de cada empresa com o **nome dela**; documento `CNPJ;NOME DA EMPRESA.pdf` (CNPJ com 14 dígitos, sem pontuação).
- Sem certidão: `IRREGULAR - CNPJ;NOME DA EMPRESA.pdf`.
- Nomes iguais de CNPJs diferentes (matriz e filial, por exemplo) viram `NOME - CNPJ` na pasta; a pasta de cada CNPJ fica em `_controle/pastas.json` e nunca muda ao retomar o lote.
- Lista só com CNPJ: usa o nome lido na própria certidão; sem nome, pasta e documento levam só o CNPJ (nada é inventado).
- Só os caracteres proibidos em nomes de arquivo são trocados; nomes reservados do Windows ganham `_`; limite de 90 caracteres no nome (60 no Windows).
- Antes de salvar, confere que o arquivo de origem é da mesma empresa; nunca sobrescreve (o repetido ganha ` (2)`).
- Lotes antigos (pasta por CNPJ) continuam como estão, sem mover nem duplicar.

## Aviso "Estamos analisando seu pedido de emissão de certidão" (extensão v1.8)
- Espera 60 s, atualiza a página **uma vez** e confere de novo. Se a certidão ou outro resultado aparecer, segue o fluxo normal.
- Se o aviso persistir (ou a página não carregar em 45 s): **PENDENTE — EM ANÁLISE PELA RECEITA FEDERAL**, a automação passa para o próximo CNPJ.
- Esses CNPJs não são refeitos no mesmo lote; uma nova execução com o mesmo nome de pasta os tenta de novo.

## Erro 033 e travamentos
- Erro 033 ("Não foi possível emitir a certidão. Tente novamente em alguns minutos"), serviço indisponível e CAPTCHA/bloqueio (sem tentar contornar): a empresa é pulada na hora e tentada de novo uma vez no fim do lote.
- Tempos limite: 5 min por tentativa, 2 tentativas por empresa; site ou extensão sem sinal em 90 s é reaberto uma vez; exceções isoladas só pulam a empresa.
- Depois de 3 puladas seguidas, espera 2 min antes da próxima (a Receita pode estar limitando). Tudo configurável por variáveis (veja o README).
- O programa avisa quando a extensão do Chrome está desatualizada.
- Relatório de pendências: aba `Pendencias` da planilha e `Pendencias.csv`, com o motivo de cada CNPJ.

## Outras mudanças
- Arquivo sem certidão passou de `INVALIDA` para `IRREGULAR` (lotes antigos com `INVALIDA` continuam reconhecidos).
- Extensão renomeada para **Automacao_RFB** (v1.8).
- **INTERFACE RFB EMISSÃO**: painel gráfico (nome da pasta, lista de CNPJs, iniciar/pausar/parar, andamento em tempo real e resumo final), usando a mesma lógica de salvamento da automação.
- `.gitignore` ignora `node_modules`, `.venv`, dados de clientes e arquivos de lote.
