// Parte de fundo da extensão. Só recebe mensagens do baixar.js, que roda apenas no
// servicos.receitafederal.gov.br.
//
// - fechar-aba: fecha a aba que pediu (a da certidão já baixada), depois da espera.
// - cnpj-da-vez: pergunta ao assistente (certidao-rfb.js) o CNPJ da empresa da
//   vez, para a tecla V. Se o assistente não estiver aberto, responde vazio.
// - oi: avisa o assistente que a aba do site abriu com a extensão (check-in).
// - certidao: entrega ao assistente o PDF da certidão pego na página (interceptar.js).
// - analise: avisa o assistente que a Receita está analisando o pedido (espera / persistiu).
// - pular: avisa o assistente que a Receita não conseguiu emitir agora; ele pula a empresa.
// - imprimir: imprime a aba em PDF (como o "Salvar como PDF" do Ctrl+P, sem a janela de
//   impressão) e manda para o assistente salvar. Usa a permissão "debugger": enquanto
//   imprime, o Chrome mostra por um instante a faixa "começou a depurar este navegador".

// Mesma porta do certidao-rfb.js.
const URL_CNPJ_DA_VEZ = 'http://127.0.0.1:47322/cnpj';
const URL_CHECK_IN = 'http://127.0.0.1:47322/oi';
const URL_IMPRESSAO = 'http://127.0.0.1:47322/impressao';
const URL_CERTIDAO = 'http://127.0.0.1:47322/certidao';
const URL_PULAR = 'http://127.0.0.1:47322/pular';
const URL_ANALISE = 'http://127.0.0.1:47322/analise';

async function entregarCertidao(arquivo, pdf) {
  const resposta = await fetch(URL_CERTIDAO, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ arquivo, pdf }),
  });
  if (!resposta.ok) throw new Error(`o assistente respondeu ${resposta.status} (fechado, ou PDF de outra empresa)`);
}

// A Receita não conseguiu emitir ("Tente novamente em alguns minutos", erro 033): avisa o
// assistente para pular esta empresa e seguir para a próxima.
async function pedirPulo(cnpj, motivo) {
  const resposta = await fetch(URL_PULAR, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ cnpj, motivo }),
  });
  if (!resposta.ok) throw new Error(`o assistente respondeu ${resposta.status} (fechado, ou outra empresa da vez)`);
}

// "Estamos analisando seu pedido...": avisa o assistente em duas fases ("espera" e "persistiu").
async function avisarAnalise(carga) {
  const resposta = await fetch(URL_ANALISE, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(carga),
  });
  if (!resposta.ok) throw new Error(`o assistente respondeu ${resposta.status} (fechado, ou outra empresa da vez)`);
}

async function imprimirAba(aba, cnpj, motivo) {
  const alvo = { tabId: aba };
  await chrome.debugger.attach(alvo, '1.3');
  let imagem;
  try {
    // Print da tela (PNG) em vez de PDF: o assistente salva como IRREGULAR-<CNPJ>.png.
    ({ data: imagem } = await chrome.debugger.sendCommand(alvo, 'Page.captureScreenshot', { format: 'png', captureBeyondViewport: true }));
  } finally {
    await chrome.debugger.detach(alvo).catch(() => {});
  }
  const resposta = await fetch(URL_IMPRESSAO, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ cnpj, motivo, imagem }),
  });
  if (!resposta.ok) throw new Error(`o assistente respondeu ${resposta.status} (está aberto, nesta empresa?)`);
}

chrome.runtime.onMessage.addListener((mensagem, remetente, responder) => {
  const aba = remetente.tab?.id;
  if (aba === undefined) return;

  if (mensagem?.tipo === 'fechar-aba') {
    console.log(`[Certidão RFB] Fechando a aba ${aba} em ${mensagem.espera} ms.`);
    setTimeout(() => {
      chrome.tabs.remove(aba).catch((e) => console.warn(`[Certidão RFB] Não fechei a aba ${aba}:`, e.message));
    }, mensagem.espera);
    responder({ ok: true });
    return;
  }

  if (mensagem?.tipo === 'oi') {
    fetch(`${URL_CHECK_IN}?v=${chrome.runtime.getManifest().version}`, { cache: 'no-store' }).catch(() => {});
    responder({ ok: true });
    return;
  }

  if (mensagem?.tipo === 'certidao') {
    entregarCertidao(mensagem.arquivo, mensagem.pdf)
      .then(() => responder({ ok: true }))
      .catch((e) => responder({ ok: false, erro: e.message }));
    return true; // responde depois do envio
  }

  if (mensagem?.tipo === 'analise') {
    const { tipo, ...carga } = mensagem;
    avisarAnalise(carga)
      .then(() => responder({ ok: true }))
      .catch((e) => responder({ ok: false, erro: e.message }));
    return true; // responde depois do envio
  }

  if (mensagem?.tipo === 'pular') {
    pedirPulo(mensagem.cnpj, mensagem.motivo)
      .then(() => responder({ ok: true }))
      .catch((e) => responder({ ok: false, erro: e.message }));
    return true; // responde depois do envio
  }

  if (mensagem?.tipo === 'imprimir') {
    imprimirAba(aba, mensagem.cnpj, mensagem.motivo)
      .then(() => responder({ ok: true }))
      .catch((e) => {
        console.warn('[Certidão RFB] Impressão em PDF falhou:', e.message);
        responder({ ok: false, erro: e.message });
      });
    return true; // responde depois da impressão
  }

  if (mensagem?.tipo === 'cnpj-da-vez') {
    fetch(URL_CNPJ_DA_VEZ, { cache: 'no-store' })
      .then((r) => (r.ok ? r.json() : {}))
      .catch(() => ({}))
      .then(responder);
    return true; // responde depois do fetch
  }
});
