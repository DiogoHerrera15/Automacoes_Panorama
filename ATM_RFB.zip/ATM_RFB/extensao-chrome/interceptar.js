// Roda no mundo da própria página (manifest.json: "world": "MAIN"), antes do site. Quando
// o site baixa a certidão (um link com download="Certidao-<CNPJ>.pdf" e endereço blob:),
// pega o PDF e entrega ao baixar.js, que manda para o assistente salvar. Assim o PDF não
// passa pelo download do Chrome, que na guia anônima abre o "Salvar como" e, ao fechar a
// aba, pergunta se quer sair do modo anônimo.
//
// Se o assistente não confirmar em ESPERA_DO_ASSISTENTE (fechado, ou o PDF é de outra
// empresa), o download normal do site acontece do mesmo jeito.
(() => {
  const ESPERA_DO_ASSISTENTE = 15000;
  const cliqueOriginal = HTMLAnchorElement.prototype.click;

  const ehCertidao = (a) => /\.pdf$/i.test(a.download ?? '') && a.href.startsWith('blob:');

  function paraBase64(blob) {
    return new Promise((resolve, reject) => {
      const leitor = new FileReader();
      leitor.onload = () => resolve(String(leitor.result).split(',')[1]);
      leitor.onerror = () => reject(leitor.error);
      leitor.readAsDataURL(blob);
    });
  }

  function aguardarResposta(id) {
    return new Promise((resolve) => {
      const ouvir = (e) => {
        if (e.source !== window || e.data?.origem !== 'certidao-rfb-extensao' || e.data.id !== id) return;
        removeEventListener('message', ouvir);
        resolve(e.data.ok === true);
      };
      addEventListener('message', ouvir);
      setTimeout(() => {
        removeEventListener('message', ouvir);
        resolve(false);
      }, ESPERA_DO_ASSISTENTE);
    });
  }

  // Links já devolvidos ao download normal (para o clique de reserva não ser pego de novo).
  const liberados = new WeakSet();

  function entregar(link) {
    const arquivo = link.download;
    // O fetch começa aqui mesmo, antes de o site revogar o endereço blob:.
    const baixando = fetch(link.href).then((r) => r.blob());
    (async () => {
      const pdf = await paraBase64(await baixando);
      const id = `${Date.now()}-${Math.random()}`;
      const resposta = aguardarResposta(id);
      window.postMessage({ origem: 'certidao-rfb-pagina', id, arquivo, pdf }, location.origin);
      if (!(await resposta)) throw new Error('assistente não confirmou');
    })().catch(() => {
      liberados.add(link);
      cliqueOriginal.call(link);
    });
  }

  // link.click() feito pelo site.
  HTMLAnchorElement.prototype.click = function () {
    if (!ehCertidao(this) || liberados.has(this)) return cliqueOriginal.call(this);
    entregar(this);
  };

  // Clique de verdade (ou evento de clique disparado) num link que está na página.
  addEventListener('click', (e) => {
    const link = e.target instanceof Element ? e.target.closest('a') : null;
    if (!link || !ehCertidao(link) || liberados.has(link)) return;
    e.preventDefault();
    entregar(link);
  }, true);
})();
