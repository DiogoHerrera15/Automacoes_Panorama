// Só roda em servicos.receitafederal.gov.br/servico/certidoes (ver manifest.json). Na
// página de emissão (#/home/cnpj), deixa o cursor no campo CNPJ; a tecla V cola o CNPJ da
// vez (com o assistente aberto) e o Ctrl+V cola o que o assistente copiou. Depois que o
// CNPJ entra no campo, clica em Emitir Certidão. Se o site avisar "Certidão Válida
// Encontrada", clica em Emitir Nova Certidão. Na página de resultado (#/home/cnpj/resultado)
// o site baixa o PDF sozinho como "Certidao-<CNPJ>.pdf"; o interceptar.js pega esse PDF
// antes do download do Chrome e ele vai direto para o assistente. A aba é fechada logo
// depois (o assistente abre a da próxima empresa). Se a Receita não emitir (por exemplo, "As
// informações disponíveis... são insuficientes para emitir a certidão"), a tela de
// resultado é impressa em PDF, como num Ctrl+P, e vai para o assistente salvar.
//
// Ao abrir a página, a extensão espera ESPERA_ANTES_DO_V e cola sozinha, como se a pessoa
// apertasse V. Emitir uma atrás da outra, rápido demais, faz a Receita recusar com o erro
// 106; se isso acontecer, aumente a espera. A tecla V continua valendo a qualquer hora.
//
// O campo do site tem máscara (AA.AAA.AAA/AAAA-99) que só aceita o valor por digitação ou
// colagem; valor posto direto no campo fica de fora e o site diz "CNPJ inválido". Por isso
// a tecla V simula uma colagem (evento paste), como se fosse o Ctrl+V.

// Espera depois que a página abre, antes de colar sozinho (a "tecla V" automática).
const ESPERA_ANTES_DO_V = 5000;
// Espera depois de colar, para a máscara formatar antes de conferir e clicar em Emitir.
const ESPERA_DEPOIS_DE_COLAR = 500;
// Espera na página de resultado, para o Chrome terminar de gravar o PDF antes de fechar a aba.
const ESPERA_ANTES_DE_FECHAR = 5000;
const TEMPO_INSISTINDO_NO_FOCO = 15000;

const naEmissao = () => /^#\/home\/cnpj\/?$/i.test(location.hash);
const noResultado = () => /^#\/home\/cnpj\/resultado/i.test(location.hash);

// Só letras e números, em maiúsculas (o CNPJ alfanumérico vale desde julho/2026).
function chaveDoc(documento) {
  return documento.replace(/[^0-9A-Za-z]/g, '').toUpperCase();
}

// Dígitos verificadores do CNPJ; letras valem o código ASCII menos 48, como manda a RFB.
function cnpjValido(chave) {
  if (!/^[0-9A-Z]{12}\d{2}$/.test(chave) || /^(.)\1+$/.test(chave)) return false;
  const dv = (base) => {
    let soma = 0;
    let peso = base.length - 7;
    for (const c of base) {
      soma += (c.charCodeAt(0) - 48) * peso--;
      if (peso < 2) peso = 9;
    }
    const resto = soma % 11;
    return resto < 2 ? 0 : 11 - resto;
  };
  const d1 = dv(chave.slice(0, 12));
  return String(d1) === chave[12] && String(dv(chave.slice(0, 12) + d1)) === chave[13];
}

function visivelEHabilitado(el) {
  return el.offsetParent !== null && !el.disabled && el.getAttribute('aria-disabled') !== 'true';
}

function campoCnpj() {
  const campo = document.querySelector('input[name="niContribuinte"]');
  return campo && visivelEHabilitado(campo) && !campo.readOnly ? campo : null;
}

function botao(texto) {
  return [...document.querySelectorAll('button')].find((b) => b.textContent.trim() === texto && visivelEHabilitado(b)) ?? null;
}

// Na página de emissão, deixa o cursor no campo CNPJ, para a pessoa só apertar V.
// A aba nova pode abrir antes de o Chrome estar na frente ou de o site terminar de montar
// o campo, e aí um foco só se perde. Por isso o foco é refeito enquanto o campo estiver
// vazio e nada mais da página tiver o cursor. Se a pessoa clicar em outro lugar, para.
function focarCampoCnpj() {
  if (!naEmissao()) return;
  const campo = campoCnpj();
  if (!campo || chaveDoc(campo.value) || document.activeElement === campo) return;
  if (document.activeElement && document.activeElement !== document.body) return;
  campo.focus();
}

// Cada CNPJ é emitido uma vez por tecla apertada: a tecla V e o Ctrl+V da pessoa liberam
// de novo (por exemplo, depois do erro 106).
let ultimoEmitido = '';
let novaEmitidaPara = '';

function emitirSeValido() {
  setTimeout(() => {
    const campo = campoCnpj();
    if (!campo) return;
    const chave = chaveDoc(campo.value);
    if (!cnpjValido(chave) || chave === ultimoEmitido) return;
    const emitir = botao('Emitir Certidão');
    if (!emitir) return;
    ultimoEmitido = chave;
    console.log(`[Certidão RFB] Emitir Certidão clicado para ${campo.value}.`);
    emitir.click();
  }, ESPERA_DEPOIS_DE_COLAR);
}

// Simula a colagem: a máscara do site trata o evento paste e formata o CNPJ.
function colar(campo, cnpj, origem) {
  campo.focus();
  campo.select();
  const dados = new DataTransfer();
  dados.setData('text/plain', chaveDoc(cnpj));
  campo.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dados, bubbles: true, cancelable: true }));
  console.log(`[Certidão RFB] CNPJ ${cnpj} colado ${origem}.`);
  emitirSeValido();
}

// CNPJ da empresa da vez, que o assistente informa (via fundo.js) enquanto está aberto.
// Com o assistente fechado, resolve com ''.
async function cnpjDaVez() {
  try {
    const { cnpj } = (await chrome.runtime.sendMessage({ tipo: 'cnpj-da-vez' })) ?? {};
    return cnpj ?? '';
  } catch {
    console.warn('[Certidão RFB] Extensão recarregada; feche esta aba e use a aba nova.');
    return '';
  }
}

// Tecla V (sem Ctrl): cola o CNPJ da vez no campo, mesmo que já tenha algo nele. Com o
// cursor em outro campo, ou fora da página de emissão, a tecla V não é alterada.
function colarComV(evento) {
  if (!naEmissao() || evento.key.toLowerCase() !== 'v' || evento.ctrlKey || evento.altKey || evento.metaKey || evento.repeat) return;
  const campo = campoCnpj();
  if (!campo) return;
  const ativo = document.activeElement;
  if (ativo !== campo && ativo && ativo !== document.body) return;

  evento.preventDefault();
  evento.stopPropagation();
  colouSozinho = true;
  cnpjDaVez().then((cnpj) => {
    if (!cnpj) {
      console.log('[Certidão RFB] Assistente fechado: tecla V sem CNPJ para colar.');
      return;
    }
    ultimoEmitido = '';
    colar(campo, cnpj, 'pela tecla V');
  });
}

// "Tecla V" automática: uma vez por aba, depois da espera, se o campo ainda estiver vazio
// e a pessoa não tiver apertado V antes.
let colouSozinho = false;

// Se o site ainda não montou o campo, tenta de novo a cada meio segundo, até o limite.
const LIMITE_ESPERANDO_O_CAMPO = 20000;

function colarSozinhoDepoisDaEspera(espera = ESPERA_ANTES_DO_V, esperado = 0) {
  setTimeout(async () => {
    if (colouSozinho || !naEmissao()) return;
    aceitarCookies();
    const campo = campoCnpj();
    if (!campo) {
      if (esperado < LIMITE_ESPERANDO_O_CAMPO) colarSozinhoDepoisDaEspera(500, esperado + 500);
      return;
    }
    if (chaveDoc(campo.value)) return;
    const cnpj = await cnpjDaVez();
    if (!cnpj || colouSozinho || chaveDoc(campo.value)) return;
    colouSozinho = true;
    ultimoEmitido = '';
    colar(campo, cnpj, `sozinho, ${(ESPERA_ANTES_DO_V + esperado) / 1000} s depois de abrir`);
  }, espera);
}

// Ctrl+V da pessoa no campo: depois que a máscara formatar, clica em Emitir.
function emitirDepoisDeColar(evento) {
  if (!naEmissao() || !evento.isTrusted) return;
  const campo = campoCnpj();
  if (!campo || evento.target !== campo) return;
  ultimoEmitido = '';
  emitirSeValido();
}

// "Certidão Válida Encontrada": já existe certidão no prazo; emite uma nova, uma vez por CNPJ.
function emitirNovaSeAvisar() {
  if (!naEmissao() || !ultimoEmitido || novaEmitidaPara === ultimoEmitido) return;
  const titulo = document.getElementById('titulo-modal');
  if (!titulo || !/Certid[aã]o V[aá]lida Encontrada/i.test(titulo.textContent)) return;
  const nova = botao('Emitir Nova Certidão');
  if (!nova) return;
  novaEmitidaPara = ultimoEmitido;
  console.log('[Certidão RFB] Certidão válida encontrada; Emitir Nova Certidão clicado.');
  nova.click();
}

// Na página de resultado o site já baixou o PDF; fecha a aba uma vez só.
let pediuFechamento = false;

function fecharNoResultado() {
  if (!noResultado() || pediuFechamento) return;
  if (!/certid[aã]o foi emitida com sucesso/i.test(document.body.innerText)) return;
  pediuFechamento = true;
  console.log(`[Certidão RFB] Certidão emitida; fechando a aba em ${ESPERA_ANTES_DE_FECHAR} ms.`);
  pedirFechamento();
}

// Resultado sem certidão (o site mostra "Como Resolver?" no lugar do download): imprime a
// tela em PDF, uma vez só, e manda para o assistente salvar com o nome e o CNPJ da empresa.
// A impressão é feita pelo fundo.js, como o "Salvar como PDF" do Ctrl+P, sem a janela de
// impressão. Só fecha a aba se o assistente recebeu o PDF.
const ESPERA_ANTES_DE_IMPRIMIR = 1500;
let pediuImpressao = false;

function imprimirSemCertidao() {
  if (!noResultado() || pediuImpressao) return;
  const texto = document.body.innerText;
  if (/certid[aã]o foi emitida com sucesso/i.test(texto)) return;
  // Telas de resultado em que a Receita não emite: "Como Resolver?" (informações insuficientes)
  // ou "emissão de certidão não permitida" (ex.: inscrição Inapta, Suspensa, Baixada).
  if (!/Como Resolver|emiss[aã]o de certid[aã]o n[aã]o permitida/i.test(texto)) return;
  const cnpj = texto.match(/[0-9A-Z]{2}\.[0-9A-Z]{3}\.[0-9A-Z]{3}\/[0-9A-Z]{4}-\d{2}/)?.[0];
  if (!cnpj) return;
  pediuImpressao = true;
  const motivo = texto.split('\n').map((l) => l.trim())
    .find((l) => l.length > 40 && /contribuinte|certid[aã]o|pend[eê]ncia/i.test(l)) ?? 'Certidão não emitida';
  console.log(`[Certidão RFB] Sem certidão para ${cnpj}: ${motivo}. Imprimindo a tela em PDF.`);
  setTimeout(async () => {
    try {
      const resposta = await chrome.runtime.sendMessage({ tipo: 'imprimir', cnpj, motivo });
      if (resposta?.ok) {
        console.log('[Certidão RFB] PDF da tela entregue ao assistente; fechando a aba.');
        pedirFechamento();
      } else {
        console.warn('[Certidão RFB] Não consegui salvar o PDF da tela:', resposta?.erro);
      }
    } catch (e) {
      console.warn('[Certidão RFB] Extensão recarregada; use Ctrl+P nesta aba.', e);
    }
  }, ESPERA_ANTES_DE_IMPRIMIR);
}

// Resultado com erro do portal ("Não foi possível emitir a certidão. Tente novamente em alguns
// minutos", erro 033, serviço indisponível...) ou bloqueio (CAPTCHA): não adianta esperar nem
// tentar contornar. Avisa o assistente para registrar a pendência com o motivo e pular esta
// empresa, e fecha a aba; a próxima empresa abre numa aba nova, com o site limpo. A pulada é
// tentada de novo no fim do lote. Falha técnica não é irregularidade: nada é salvo como
// IRREGULAR aqui. Uma vez só por aba.
const ERRO_DO_PORTAL = /N[aã]o foi poss[ií]vel (emitir|concluir)|Tente novamente|temporariamente indispon|servi[cç]o indispon|erro inesperado|erro interno/i;
const BLOQUEIO_DO_PORTAL = /captcha|n[aã]o sou (um )?rob[oô]|verifica[cç][aã]o de seguran[cç]a|acesso negado|access denied/i;
const TENTATIVAS_DE_AVISO = 3;
let pediuPulo = false;

function pedirPulo(cnpj, motivo) {
  if (pediuPulo) return;
  pediuPulo = true;
  console.log(`[Certidão RFB] ${motivo} (${cnpj}). Pulando para a próxima empresa.`);
  let tentativa = 0;
  const falhou = (erro) => {
    console.warn('[Certidão RFB] Assistente não aceitou pular:', erro);
    if (tentativa < TENTATIVAS_DE_AVISO) setTimeout(enviar, 3000);
    // Outra empresa na vez (409): esta aba é de uma empresa já tratada; pode fechar.
    else if (/409/.test(String(erro))) pedirFechamento();
  };
  const enviar = () => {
    tentativa++;
    try {
      chrome.runtime.sendMessage({ tipo: 'pular', cnpj, motivo })
        .then((resposta) => {
          if (resposta?.ok) {
            console.log('[Certidão RFB] Assistente avisado; fechando a aba.');
            pedirFechamento();
          } else {
            falhou(resposta?.erro);
          }
        })
        .catch((e) => falhou(e?.message));
    } catch (e) {
      console.warn('[Certidão RFB] Extensão recarregada; feche esta aba e use a aba nova.', e);
    }
  };
  enviar();
}

function pularSeErroDoPortal() {
  if (!noResultado() || pediuPulo || tratandoAnalise || elementoDoAviso()) return;
  const texto = document.body.innerText;
  // Telas com tratamento próprio (certidão emitida, ou sem certidão com print) ficam como estão.
  if (/certid[aã]o foi emitida com sucesso|Como Resolver|emiss[aã]o de certid[aã]o n[aã]o permitida/i.test(texto)) return;
  const bloqueio = BLOQUEIO_DO_PORTAL.test(texto);
  if (!bloqueio && !ERRO_DO_PORTAL.test(texto)) return;
  const cnpj = texto.match(/[0-9A-Z]{2}\.[0-9A-Z]{3}\.[0-9A-Z]{3}\/[0-9A-Z]{4}-\d{2}/)?.[0];
  if (!cnpj) return;
  const padrao = bloqueio ? BLOQUEIO_DO_PORTAL : ERRO_DO_PORTAL;
  const linha = texto.split('\n').map((l) => l.trim()).find((l) => l && padrao.test(l)) ?? '';
  pedirPulo(cnpj, bloqueio
    ? `Bloqueio ou CAPTCHA do portal (não contornado): ${linha}`.trim()
    : (linha || 'Receita não conseguiu emitir agora'));
}

// "Estamos analisando seu pedido de emissão de certidão. Retorne em alguns minutos para o resultado."
// Não é erro nem irregularidade: a Receita ainda está processando. Sequência, uma vez por aba:
// 1) identifica o aviso pelo texto da própria página (elemento do site, sem coordenadas);
// 2) avisa o assistente ("espera") e aguarda ESPERA_ANALISE;
// 3) se o aviso saiu da tela, os tratamentos normais (certidão, sem certidão, erro) assumem;
// 4) se continua, atualiza a página UMA vez (o estado fica no sessionStorage da aba);
// 5) depois da atualização, se o aviso ainda aparece, ou nada conclusivo veio em CARGA_MAXIMA,
//    avisa o assistente ("persistiu"), que registra "PENDENTE - EM ANÁLISE" e passa para o
//    próximo CNPJ; a aba é fechada. Sem segunda espera, sem segundo reload.
const AVISO_DE_ANALISE = /Estamos analisando seu pedido de emiss[aã]o de certid[aã]o|Retorne em alguns minutos para o resultado/i;
const ESPERA_ANALISE = 60000;
const CARGA_MAXIMA_APOS_RELOAD = 45000;
const CHAVE_ANALISE = 'certidao-rfb-analise';
const CNPJ_NA_PAGINA = /[0-9A-Z]{2}\.[0-9A-Z]{3}\.[0-9A-Z]{3}\/[0-9A-Z]{4}-\d{2}/;
let tratandoAnalise = false;

// Elemento mais interno do site cujo texto traz o aviso.
function elementoDoAviso() {
  const achados = [...document.querySelectorAll('div, p, span, section, article, li')].filter((e) => AVISO_DE_ANALISE.test(e.textContent));
  return achados.at(-1) ?? null;
}

function lerEstadoAnalise() {
  try {
    return JSON.parse(sessionStorage.getItem(CHAVE_ANALISE) ?? 'null');
  } catch {
    return null;
  }
}

function gravarEstadoAnalise(estado) {
  try {
    sessionStorage.setItem(CHAVE_ANALISE, JSON.stringify(estado));
  } catch {
    // sem sessionStorage: a aba segue sem lembrar; o assistente ainda tem o tempo limite dele
  }
}

// Avisa o assistente (via fundo.js). Tenta até 3 vezes; 409 = outra empresa na vez (aba velha).
function avisarAnalise(carga, aoConfirmar) {
  let tentativa = 0;
  const falhou = (erro) => {
    console.warn('[Certidão RFB] Assistente não recebeu o aviso de análise:', erro);
    if (tentativa < TENTATIVAS_DE_AVISO) setTimeout(enviar, 3000);
    else if (/409/.test(String(erro))) aoConfirmar?.();
  };
  const enviar = () => {
    tentativa++;
    try {
      chrome.runtime.sendMessage({ tipo: 'analise', ...carga })
        .then((resposta) => (resposta?.ok ? aoConfirmar?.() : falhou(resposta?.erro)))
        .catch((e) => falhou(e?.message));
    } catch (e) {
      console.warn('[Certidão RFB] Extensão recarregada; feche esta aba e use a aba nova.', e);
    }
  };
  enviar();
}

function concluirAnaliseComoPendente(cnpj, motivo) {
  console.log(`[Certidão RFB] ${motivo} (${cnpj}). Registrando como pendente em análise e seguindo para a próxima empresa.`);
  avisarAnalise({ fase: 'persistiu', cnpj, motivo }, pedirFechamento);
}

function tratarAnalise() {
  if (!noResultado() || tratandoAnalise || !elementoDoAviso()) return;
  const cnpj = document.body.innerText.match(CNPJ_NA_PAGINA)?.[0];
  if (!cnpj) return;
  tratandoAnalise = true;
  const chave = chaveDoc(cnpj);
  const estado = lerEstadoAnalise();
  if (estado?.cnpj === chave) {
    // Já esperou e atualizou nesta aba: o aviso persistiu. Nada de nova espera nem novo reload.
    concluirAnaliseComoPendente(cnpj, 'o aviso de análise persistiu depois da espera e da atualização');
    return;
  }
  gravarEstadoAnalise({ cnpj: chave, fase: 'esperando' });
  console.log(`[Certidão RFB] A Receita está analisando o pedido de ${cnpj}. Aguardando ${ESPERA_ANALISE / 1000} s e atualizando a página uma vez.`);
  avisarAnalise({ fase: 'espera', cnpj, espera: ESPERA_ANALISE / 1000 });
  setTimeout(() => {
    if (!elementoDoAviso()) {
      // O resultado saiu sozinho durante a espera: os tratamentos normais cuidam dele.
      tratandoAnalise = false;
      verificar();
      return;
    }
    gravarEstadoAnalise({ cnpj: chave, fase: 'recarregado' });
    location.reload();
  }, ESPERA_ANALISE);
}

// Depois da atualização: se nada conclusivo (certidão, sem certidão, erro) vier a tempo, a página
// não carregou direito. Não bloqueia a fila: registra a pendência e fecha a aba.
function vigiarCargaDepoisDoReload() {
  const estado = lerEstadoAnalise();
  if (estado?.fase !== 'recarregado') return;
  setTimeout(() => {
    if (tratandoAnalise || pediuFechamento || pediuImpressao || pediuPulo) return;
    tratandoAnalise = true;
    concluirAnaliseComoPendente(estado.cnpj, `a página não trouxe resultado em ${CARGA_MAXIMA_APOS_RELOAD / 1000} s depois da atualização`);
  }, CARGA_MAXIMA_APOS_RELOAD);
}

function pedirFechamento() {
  const fecharPelaPagina = () => setTimeout(() => window.close(), ESPERA_ANTES_DE_FECHAR);
  try {
    chrome.runtime.sendMessage({ tipo: 'fechar-aba', espera: ESPERA_ANTES_DE_FECHAR }).catch((e) => {
      console.warn('[Certidão RFB] fundo.js não respondeu; fechando pela página.', e);
      fecharPelaPagina();
    });
  } catch (e) {
    // Extensão recarregada depois que a aba abriu: este script perdeu o contato com ela.
    console.warn('[Certidão RFB] Extensão recarregada; fechando pela página.', e);
    fecharPelaPagina();
  }
}

// Aviso de cookies do gov.br (aparece em toda guia anônima): clica em Aceitar, uma vez
// por aba, antes de colar o CNPJ. Só o botão de dentro da barra de cookies.
let aceitouCookies = false;

function aceitarCookies() {
  if (aceitouCookies) return;
  const barra = document.querySelector('.br-cookiebar');
  if (!barra) return;
  const aceitar = [...barra.querySelectorAll('button')].find((b) => b.textContent.trim() === 'Aceitar' && visivelEHabilitado(b));
  if (!aceitar) return;
  aceitouCookies = true;
  console.log('[Certidão RFB] Cookies aceitos.');
  aceitar.click();
}

// Certidão pega pelo interceptar.js (mundo da página): repassa ao fundo.js, que entrega ao
// assistente, e devolve à página se deu certo (se não, a página faz o download normal).
window.addEventListener('message', (e) => {
  if (e.source !== window || e.data?.origem !== 'certidao-rfb-pagina') return;
  const { id, arquivo, pdf } = e.data;
  const devolver = (ok) => window.postMessage({ origem: 'certidao-rfb-extensao', id, ok }, location.origin);
  try {
    chrome.runtime.sendMessage({ tipo: 'certidao', arquivo, pdf })
      .then((resposta) => {
        console.log(resposta?.ok ? `[Certidão RFB] ${arquivo} entregue ao assistente.` : `[Certidão RFB] Assistente não aceitou ${arquivo}: ${resposta?.erro}`);
        devolver(resposta?.ok === true);
      })
      .catch(() => devolver(false));
  } catch {
    devolver(false);
  }
});

// Check-in: avisa o assistente (pelo fundo.js) que esta aba do site abriu com a extensão.
function avisarQueAbriu() {
  try {
    chrome.runtime.sendMessage({ tipo: 'oi' }).catch(() => {});
  } catch {
    // Extensão recarregada depois que a aba abriu.
  }
}

// A Receita às vezes recusa com "Não foi possível concluir a ação... tente novamente dentro de
// alguns minutos". Como a própria mensagem pede, espera e recarrega a página (que cola o CNPJ e
// emite de novo), até MAX_RECUSAS vezes por aba; depois disso avisa o assistente, que pula a empresa e segue.
const ESPERA_APOS_RECUSA = 60000;
const MAX_RECUSAS = 3;
let recusaAgendada = false;

function tentarDepoisDaRecusa() {
  if (noResultado() || recusaAgendada) return;
  if (!/N[aã]o foi poss[ií]vel concluir a a[cç][aã]o/i.test(document.body.innerText)) return;
  const recusas = Number(sessionStorage.getItem('certidao-rfb-recusas') ?? 0);
  if (recusas >= MAX_RECUSAS) {
    console.warn(`[Certidão RFB] A Receita recusou ${MAX_RECUSAS} vezes.`);
    // A página recarregou nas tentativas: o CNPJ vem do campo ou, se vazio, do próprio assistente.
    (async () => {
      const cnpj = ultimoEmitido || chaveDoc(campoCnpj()?.value ?? '') || chaveDoc(await cnpjDaVez());
      if (cnpj) pedirPulo(cnpj, `Receita recusou ${MAX_RECUSAS} vezes seguidas ("Não foi possível concluir a ação", erro 106)`);
    })();
    return;
  }
  recusaAgendada = true;
  sessionStorage.setItem('certidao-rfb-recusas', String(recusas + 1));
  console.log(`[Certidão RFB] Recusa da Receita; nova tentativa em ${ESPERA_APOS_RECUSA / 1000} s (${recusas + 1}/${MAX_RECUSAS}).`);
  setTimeout(() => {
    location.hash = '#/home/cnpj'; // o site pode ter voltado para a tela inicial depois do erro
    location.reload();
  }, ESPERA_APOS_RECUSA);
}

// Se o site cair na tela inicial (escolha do tipo de contribuinte), volta para a emissão por
// CNPJ e cola de novo. No máximo 5 vezes por aba, para nunca ficar em laço.
function voltarParaEmissao() {
  if (naEmissao() || noResultado() || !/^(#\/?(home\/?)?)?$/i.test(location.hash)) return;
  const voltas = Number(sessionStorage.getItem('certidao-rfb-voltas') ?? 0);
  if (voltas >= 5) return;
  sessionStorage.setItem('certidao-rfb-voltas', String(voltas + 1));
  console.log('[Certidão RFB] Site na tela inicial; voltando para a emissão por CNPJ.');
  location.hash = '#/home/cnpj';
  colarSozinhoDepoisDaEspera(2000);
}

function verificar() {
  agendado = null;
  voltarParaEmissao();
  tentarDepoisDaRecusa();
  aceitarCookies();
  focarCampoCnpj();
  emitirNovaSeAvisar();
  fecharNoResultado();
  imprimirSemCertidao();
  tratarAnalise();
  pularSeErroDoPortal();
}

let agendado = null;

document.addEventListener('keydown', colarComV, true);
document.addEventListener('paste', emitirDepoisDeColar, true);
window.addEventListener('hashchange', verificar);
window.addEventListener('focus', focarCampoCnpj);
document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'visible') focarCampoCnpj();
});

const insistir = setInterval(focarCampoCnpj, 300);
setTimeout(() => clearInterval(insistir), TEMPO_INSISTINDO_NO_FOCO);

new MutationObserver(() => {
  agendado ??= setTimeout(verificar, 300);
}).observe(document.documentElement, { childList: true, subtree: true });

avisarQueAbriu();
colarSozinhoDepoisDaEspera();
verificar();
vigiarCargaDepoisDoReload();
