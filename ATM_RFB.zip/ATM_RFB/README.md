# Automação RFB – Certidões da Receita Federal (pacote portátil para Mac)

Este pacote leva a automação para **outro Mac** (Intel ou Apple Silicon: M1, M2, M3 e posteriores) sem reconstruir nada. Basta seguir os passos abaixo, na ordem. Não é preciso conhecer o projeto.

---

## INTERFACE RFB EMISSÃO (painel gráfico) — o jeito mais simples de usar

Em vez de digitar comandos, use o painel: **dois cliques em `INTERFACE RFB EMISSAO.command`** (ou, no Terminal, `bash "INTERFACE RFB EMISSAO.command"`). Na primeira vez ele instala o que falta e abre a janela da interface. **Deixe a janela preta do Terminal aberta** enquanto usa o painel (Ctrl+C a encerra). Se a janela não abrir sozinha, abra no navegador: http://127.0.0.1:47330

Uso (3 passos):

1. **Nome da pasta** — digite, por exemplo, `AGM Novembro`. A pasta é criada sozinha dentro da pasta principal (por padrão `~/Downloads`; dá para trocar em "alterar").
2. **Lista de CNPJs** — cole um por linha, com ou sem pontuação. Também aceita `Nome;CNPJ`. Sem nome, o arquivo recebe o nome que está escrito na certidão. CPFs são ignorados.
3. Clique em **Iniciar Automação**.

| Botão | O que faz |
|---|---|
| **Iniciar Automação** | Cria a pasta, lê a lista e emite as certidões. Se a pasta já existir, **continua** o lote de onde parou (nunca repete o que já está feito) |
| **Pausar / Continuar** | A empresa em andamento termina e a automação espera antes da próxima; nada se perde. **Continuar** retoma |
| **Parar** | Encerra com segurança: o andamento fica salvo e os arquivos são organizados. Para continuar, use o mesmo nome de pasta |

O painel mostra, em tempo real: CNPJs inseridos, processados, certidões emitidas, sem certidão (print salvo), pendentes/com erro, barra de progresso, a empresa em andamento, se a extensão do Chrome está conectada e o registro de ações. Ao terminar, aparece o **resumo** com o botão "Abrir pasta".

O que fica na pasta do lote (usa exatamente a mesma lógica de salvamento da automação):

```
<pasta principal>/<nome da pasta>/
├── <14 dígitos do CNPJ>/          certidão "NOME - CNPJ - Certidao Regularidade Fiscal RFB - AAAA-MM-DD.pdf"
│                                   (ou "IRREGULAR - ….pdf" com o print, quando a Receita não emite)
├── Controle_Certidoes.xlsx         situação de cada CNPJ (aba "Pendencias" com o motivo de cada falha)
├── Pendencias.csv                  só aparece se sobrar CNPJ para tentar de novo, com o motivo
└── _controle/                      dados internos da automação (certidoes/, Controle.json, Relatorio.csv): não mexer
```

Pré-requisitos são os mesmos do restante deste guia: Chrome com a extensão carregada (seção 6) e `bash instalar.sh` já executado (o painel avisa se faltar algo). Os comandos do `iniciar.sh` continuam funcionando normalmente.

Observações: a pausa vale entre uma empresa e outra (leva até ~1 minuto para aparecer "Pausado"); só pode haver uma automação por vez (porta 47322); o painel só atende neste computador.

---

## 1. Finalidade

Emitir **em lote** a *Certidão de Débitos Relativos a Créditos Tributários Federais e à Dívida Ativa da União* (a "Certidão de Regularidade Fiscal" da Receita Federal) de uma lista de CNPJs, no portal público da Receita (sem login e sem senha):

`https://servicos.receitafederal.gov.br/servico/certidoes/#/home/cnpj`

Para cada empresa o resultado é:

- **Certidão emitida** → o PDF `NOME - CNPJ - Certidao Regularidade Fiscal RFB - AAAA-MM-DD.pdf`.
- **A Receita não emite** (informações insuficientes, CNPJ inapto etc.) → um PDF `IRREGULAR - NOME - CNPJ - ….pdf` com o print da tela da Receita (a prova de que foi tentado).
- Tudo organizado em uma pasta por CNPJ e uma planilha de controle.

## 2. Como funciona

```
 certidao-rfb.js (Node.js, janela do Terminal)         Extensão do Chrome (extensao-chrome/)
 ─────────────────────────────────────────            ──────────────────────────────────────
 lê a lista de CNPJs                                   só age em servicos.receitafederal.gov.br
 abre o portal em uma aba anônima    ──────────►       aceita os cookies
 diz qual é o CNPJ da vez  (GET /cnpj)                 5 s depois cola o CNPJ e clica "Emitir"
 confere o PDF e salva     (POST /certidao) ◄───────   pega o PDF da própria página
 salva o print "sem certidão" (POST /impressao) ◄──    ou tira o print da tela e fecha a aba
 grava Controle.json e Relatorio.csv
 organiza em resultado/<CNPJ>/ (lote.py)
```

- O programa e a extensão conversam **só dentro do seu computador**, em `http://127.0.0.1:47322`. Nenhuma configuração é necessária: se a extensão estiver instalada e permitida em anônimo, ela se conecta sozinha. Só pode haver **um** programa aberto por vez.
- **Por que Node.js + extensão e não Playwright/Selenium?** O portal bloqueia navegador automatizado (erros 023/106). A extensão roda no **Chrome de verdade** e o portal aceita. **Não há Playwright neste projeto** e não deve ser trocado por ele.
- O certificado da Receita é emitido **só para a matriz** e vale para as filiais. Se a lista tem a matriz e filiais, é emitida uma vez e a cópia vai para a pasta de cada filial. Se a lista tem só a filial, o programa pede a matriz no lugar.
- Intervalo de ~15 s entre empresas (para a Receita não recusar). **Nenhuma empresa trava o lote:** erro 033 / serviço indisponível / CAPTCHA na tela de resultado → a extensão avisa e a empresa é **pulada na hora**; site que não abre ou extensão muda por 90 s → reabre uma vez e, sem sinal, pula; portal sem resposta por 5 min → reabre uma vez e, sem resposta, pula; qualquer exceção isolada também só pula aquela empresa. As puladas ficam como pendência com o motivo e são **tentadas de novo uma vez no fim do lote** (a interface faz sozinha). Falha técnica nunca vira `IRREGULAR`: esse nome é só para quando a Receita diz que não emite.

## 3. O que tem na pasta

| Item | Para que serve |
|---|---|
| `README.md` | Este guia |
| `instalar.sh` | Instala tudo que falta no Mac (rodar uma vez) |
| `INTERFACE RFB EMISSAO.command` | **Abre o painel gráfico** (dois cliques) |
| `interface/` | O painel: `servidor.js` (liga o painel à automação) e `index.html` (a tela) |
| `iniciar.sh` | Roda a automação pelo Terminal (comando único) |
| `certidao-rfb.js` | O programa principal (Node.js): lista, controle, conferência do PDF, servidor local |
| `package.json`, `package-lock.json` | Dependência do Node (`pdfjs-dist`, usada para ler o CNPJ dentro do PDF) |
| `requirements.txt` | Dependências do Python (`pillow`, `openpyxl`) |
| `extensao-chrome/` | **A extensão do Chrome**: `manifest.json`, `baixar.js`, `interceptar.js`, `fundo.js` |
| `ferramentas/lote.py` | Lê a lista, cria as pastas por CNPJ, organiza os PDFs e gera a planilha |
| `ferramentas/entrega_nomeada.py` | Opcional: monta uma pasta de entrega ao cliente (PDFs nomeados + planilha + .zip) |
| `lista_cnpjs.exemplo.txt` | Modelo da lista de entrada |

Criados durante o uso (não vêm no pacote): `node_modules/`, `.venv/`, `lista_cnpjs.txt`, `empresas.csv`, `certidoes/`, `Controle.json`, `Relatorio.csv`, `resultado/`.

## 4. O que precisa estar instalado no Mac

| Programa | Observação |
|---|---|
| **macOS** com acesso à internet | Intel ou Apple Silicon |
| **Google Chrome** | Em `/Applications/Google Chrome.app`. Abra-o uma vez antes de começar |
| **Node.js 18 ou mais novo** | `instalar.sh` instala via Homebrew se houver; senão baixe em https://nodejs.org (versão LTS, instalador `.pkg`) |
| **Python 3** | Já vem com as "Ferramentas de Linha de Comando" da Apple. Se faltar: `xcode-select --install` |

Homebrew é opcional. Nenhuma senha, token ou certificado é usado pela automação.

## 5. Preparar o ambiente do zero

1. Copie o `.zip` para o novo Mac (AirDrop, pendrive, nuvem) e dê dois cliques para abrir.
2. Mova a pasta `ATM_RFB` para um lugar **fixo**, por exemplo `Documentos`. **Não mude a pasta de lugar depois de instalar a extensão** (veja a seção 6).
3. Abra o **Terminal** (Spotlight → "Terminal") e entre na pasta:
   ```
   cd ~/Documents/ATM_RFB
   ```
4. Rode o instalador:
   ```
   bash instalar.sh
   ```
   Ele confere o Chrome, confere/instala o Node.js, instala as dependências do Node (`npm ci`), cria o ambiente Python `.venv` com Pillow e openpyxl e libera os arquivos baixados de outro computador. Não use `sudo`. Se algo faltar, ele diz exatamente o que fazer; depois de resolver, rode `bash instalar.sh` de novo.
5. Se o Mac perguntar se o Terminal pode acessar a pasta Documentos/Downloads, clique em **Permitir**.

## 6. Instalar e configurar a extensão do Chrome

A extensão se chama **"Automacao_RFB"** (**versão 1.8**) e está na pasta `extensao-chrome`. É a **única** extensão necessária. Ela fica "sem compactação" (modo desenvolvedor), não vem da Chrome Web Store.

1. No Chrome, digite na barra de endereços `chrome://extensions` e aperte Enter.
2. Ligue o **Modo do desenvolvedor** (interruptor no canto superior direito).
3. Clique em **Carregar sem compactação** e escolha a pasta `ATM_RFB/extensao-chrome` (a pasta inteira, não um arquivo). A extensão "Automacao_RFB" aparece na lista.
4. Clique em **Detalhes** nela e ligue **Permitir na navegação anônima**. **Sem isso nada acontece**, porque o portal é aberto em aba anônima.
5. Deixe a extensão **ligada**. Não é preciso fixar na barra nem clicar nela.

Pontos importantes:

- **Não há outra configuração.** A conexão com o programa é automática (porta local 47322). Para conferir: ao rodar a automação, o Terminal mostra **"OK: extensão conectada na aba do site"**.
- O Chrome guarda o **caminho** da pasta da extensão. Se você mover ou renomear a pasta do projeto, a extensão para de funcionar: em `chrome://extensions` remova-a e carregue de novo (passos 3–4).
- Se algum arquivo de `extensao-chrome` for alterado, clique no botão **Recarregar** (seta circular) da extensão e feche as abas antigas do portal.
- **Depois de uma atualização da automação**, sempre recarregue a extensão (botão **Recarregar**) e confira que aparece a **versão 1.8**. Ao iniciar, o log da interface mostra "Extensão v1.8 (atualizada)"; se mostrar "extensão desatualizada", a extensão ainda é a antiga.
- Se o Chrome mostrar um aviso sobre "extensões no modo desenvolvedor" ao abrir, pode dispensá-lo (não desative a extensão).

## 6.1 Atualizar uma instalação que já funciona

Quando a pasta `ATM_RFB` for atualizada (arquivos novos por cima dos antigos):

1. **Pare** qualquer automação em andamento (botão **Parar** da interface) e feche a janela da interface e o Terminal.
2. Em `chrome://extensions`, clique em **Recarregar** na "Automacao_RFB" e confira a **versão 1.8**. Se a extensão estiver carregada de outra pasta, remova-a e carregue `ATM_RFB/extensao-chrome` (e ligue "Permitir na navegação anônima").
3. Abra a interface de novo (`INTERFACE RFB EMISSAO.command`). Não precisa reinstalar nada, a menos que o instalador peça.
4. Para continuar um lote que ficou pela metade, inicie com o **mesmo nome de pasta**: o que já foi emitido não é refeito.

## 7. Instalar as dependências

Já feito pelo `instalar.sh` (seção 5). Resumo do que ele faz, caso queira fazer à mão dentro da pasta:

```
npm ci                                  # instala o pdfjs-dist em node_modules/
python3 -m venv .venv                   # ambiente Python próprio deste Mac
.venv/bin/python3 -m pip install -r requirements.txt
```

`node_modules/` e `.venv/` **nunca devem ser copiados entre Macs**: são recriados pelo `instalar.sh`.

## 8. Iniciar e usar

Sempre no Terminal, dentro da pasta do projeto:

| Comando | O que faz |
|---|---|
| `bash iniciar.sh --teste` | **Faça primeiro.** Emite só 2 empresas, para conferir que tudo funciona |
| `bash iniciar.sh` | Lote completo |
| `bash iniciar.sh --verificar` | Só confere a lista (não abre o site) |
| `bash iniciar.sh --organizar` | Só reorganiza o que já foi emitido (não abre o site) |
| `bash iniciar.sh --novo-lote` | Guarda o lote atual em `lotes_anteriores/` para começar uma lista nova |

Passo a passo de um lote:

1. Coloque a lista em `lista_cnpjs.txt` (seção 9).
2. Confira se o Chrome está com a extensão ativa e **não há outra janela da automação aberta**.
3. Rode `bash iniciar.sh --teste`. O Chrome abre uma aba anônima do portal, o CNPJ é colado sozinho em ~5 s e o PDF é salvo. O Terminal deve mostrar "OK: extensão conectada na aba do site".
4. Se o teste foi bem, rode `bash iniciar.sh` (continua de onde parou, sem refazer as 2 do teste).
5. Deixe o Mac ligado e sem hibernar (ex.: `caffeinate -i bash iniciar.sh`). A Receita aceita ~uma empresa a cada 15 s; 400 empresas levam cerca de 2 horas.
6. No fim, o programa refaz uma vez as empresas que deram erro e organiza tudo. Veja o resumo no Terminal e a planilha.

Opções avançadas (antes do comando): `LIMITE=50` (máximo de empresas), `PAUSA_SEGUNDOS=30` (pausa maior se a Receita recusar muito), `TEMPO_MAX_EMPRESA_MIN=5` (minutos por tentativa), `TENTATIVAS_POR_EMPRESA=2` (quantas vezes abre o site por empresa), `ESPERA_SEM_SINAL_SEG=90` (site/extensão sem sinal), `FALHAS_SEGUIDAS=3` e `ESFRIAR_SEGUNDOS=120` (depois de 3 pulos técnicos seguidos, espera 2 min antes da próxima, para não insistir com a Receita limitando), `PASTA_SAIDA=/outra/pasta`. Ex.: `LIMITE=50 PAUSA_SEGUNDOS=30 bash iniciar.sh`.

Comandos na janela do programa (digite e Enter):

| Tecla | Ação |
|---|---|
| `c` | Copia o CNPJ da vez de novo |
| `a` | Reabre o portal para a **mesma** empresa (aba travada ou fechada) |
| `p` | Pula a empresa (fica com erro; é refeita no fim) |
| `s` | Sai com segurança; o andamento fica salvo |

## 9. Como informar os CNPJs

Crie o arquivo **`lista_cnpjs.txt`** na pasta do projeto (modelo: `lista_cnpjs.exemplo.txt`). Texto simples, UTF-8, **uma empresa por linha, separada por `;`**, em qualquer um dos formatos:

```
Nome;CNPJ        EMPRESA EXEMPLO UM LTDA;11.222.333/0001-81
CNPJ;Nome        11.222.333/0001-81;EMPRESA EXEMPLO UM LTDA
```

- Com ou sem pontuação no CNPJ; cabeçalho opcional.
- **CPFs** (11 dígitos) são ignorados — pessoa física não tem esta certidão — e ficam listados na aba "Ignorados (CPF)" da planilha.
- CNPJs inválidos ou repetidos são avisados no Terminal e ignorados.
- Filial com matriz na lista: sai uma certidão só (a da matriz), copiada para a filial. Filial sem matriz na lista: o programa pede a matriz.
- A lista só é lida quando o programa **começa**. Mudou a lista? Pare (`s`) e rode de novo.
- **Lista nova de outro cliente ou lote?** Rode `bash iniciar.sh --novo-lote` antes (guarda o lote antigo em `lotes_anteriores/`, nada é apagado) e depois coloque a nova lista.

## 10. Onde ficam os arquivos gerados

Tudo dentro da pasta do projeto (ou em `PASTA_SAIDA`, se definida):

```
resultado/                              ← o que você entrega/usa
├── 11222333000181/                     uma pasta por CNPJ (14 dígitos)
│     NOME - 11222333000181 - Certidao Regularidade Fiscal RFB - 2026-01-31.pdf
│     IRREGULAR - NOME - … .pdf          (somente quando a Receita não emitiu)
└── Controle_Certidoes.xlsx             situação de cada CNPJ (concluído, sem certidão, erro, pendente)
certidoes/                              PDFs e prints originais ("dados brutos")
Controle.json                           andamento por CNPJ (é o que permite continuar de onde parou)
Relatorio.csv                           uma linha por empresa
```

- Nada é sobrescrito nem apagado; rodar de novo não duplica arquivos. Se uma empresa que estava "sem certidão" passar a ter certidão, o print antigo vai para `_substituidos/` na pasta dela.
- Se um PDF cair em `~/Downloads` (extensão fora do ar, por exemplo), o programa o encontra e move na próxima execução (ou `node certidao-rfb.js --organizar`).
- Entrega ao cliente (opcional): `.venv/bin/python3 ferramentas/entrega_nomeada.py . ~/Documents/RFB-Entrega` (o destino não pode existir). Gera `01 - Certidoes emitidas/`, `02 - Sem certidao/`, uma planilha e um `.zip`.
- Dados de clientes ficam só neste computador; o `.gitignore` os mantém fora do GitHub. Não compartilhe a pasta com os resultados.

## 11. Erros comuns

| Sintoma | Causa / solução |
|---|---|
| `instalar.sh`: "Google Chrome não encontrado" | Instale o Chrome em Aplicativos e abra-o uma vez |
| `command not found: node` / "Node.js não encontrado" | Rode `bash instalar.sh`; se pedir, instale o Node em https://nodejs.org e **abra um Terminal novo** |
| "Falta Pillow/openpyxl" | Rode `bash instalar.sh` (recria o `.venv`) |
| "Permission denied" ao rodar o script | Use `bash instalar.sh` / `bash iniciar.sh` (com `bash` na frente) |
| "não pode ser aberto porque é de um desenvolvedor não identificado" | Use `bash …` no Terminal; o `instalar.sh` já remove a quarentena da pasta |
| "a extensão não respondeu" / nada acontece na aba | Extensão não carregada, desligada ou **sem "Permitir na navegação anônima"**. Corrija e digite `a` + Enter |
| Extensão parou depois de mover a pasta | Remova e carregue de novo a extensão (seção 6) |
| Aparece "Salvar como" / "Sair do modo anônimo?" | O programa não recebeu o PDF (duas janelas abertas ou programa fechado). Rode `bash iniciar.sh --organizar` depois |
| "Estamos analisando seu pedido de emissão de certidão. Retorne em alguns minutos" (tela de resultado) | A extensão (**v1.8**) espera **60 s**, atualiza a página **uma vez** e confere de novo. Saiu a certidão ou outro resultado: segue o fluxo normal. A mensagem continuou (ou a página não carregou em 45 s): o CNPJ fica como **PENDENTE — EM ANÁLISE PELA RECEITA FEDERAL** (Relatorio.csv, aba/arquivo Pendencias, resumo da interface) e a automação passa para o próximo. Esses CNPJs **não são repetidos no mesmo lote**; ficam para a próxima execução com o mesmo nome de pasta |
| Erro 033 "Não foi possível emitir a certidão. Tente novamente em alguns minutos" (tela de resultado) | A extensão (**v1.7 ou mais nova**) avisa o programa, fecha a aba, **pula a empresa e segue para a próxima**; fica pendente com o motivo e é tentada de novo no fim do lote. Se o programa avisar "extensão desatualizada", recarregue a extensão em `chrome://extensions` |
| Erro 106 "Não foi possível concluir a ação" | Muitas emissões seguidas. A extensão espera 1 min e tenta de novo (até 6×). Se persistir, use `PAUSA_SEGUNDOS=30` |
| Tela "serviço temporariamente indisponível" | Digite `a` + Enter; em 8 min o programa reabre sozinho e depois registra erro e segue. Dá para parar (`s`) e rodar mais tarde |
| "O assistente já está aberto" | Há outro programa rodando (porta 47322). Feche a outra janela do Terminal |
| "CNPJ inválido" no site com CNPJ certo | Recarregue a extensão e feche as abas antigas do portal |
| "o PDF é de outro CNPJ" | O programa rejeita o arquivo. Use `a` para emitir de novo ou `p` para pular |
| Captcha / verificação de robô do portal | **Não contorne.** Pare (`s`), resolva à mão no navegador e rode de novo |
| Chrome instalado em outro local | Em `certidao-rfb.js`, função `abrirSite()`, ajuste o caminho do Chrome |

## 12. Interromper e reiniciar com segurança

- **Parar:** digite `s` e Enter na janela do Terminal (ou `Ctrl+C`). O que já foi emitido está salvo em `certidoes/` e `Controle.json`, e o `iniciar.sh` ainda organiza `resultado/` antes de fechar.
- **Reiniciar:** `bash iniciar.sh`. Continua apenas das pendentes e das que deram erro; nunca baixa de novo uma empresa já concluída.
- Se fechou o Terminal à força ou faltou luz: rode `bash iniciar.sh --organizar` e depois `bash iniciar.sh`.
- Não edite `Controle.json` à mão e não rode duas cópias ao mesmo tempo.
- **Dica:** antes de fechar o Mac ou trocar de lista, rode `bash iniciar.sh --organizar` para deixar `resultado/` atualizado.

---

*Uso apenas para empresas pelas quais o escritório responde. A automação não usa senha nem contorna proteções do portal.*
