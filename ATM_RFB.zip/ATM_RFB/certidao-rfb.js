// Assistente para emitir a Certidão de Débitos Relativos a Créditos Tributários Federais e
// à Dívida Ativa da União (Receita Federal), no site
// https://servicos.receitafederal.gov.br/servico/certidoes/#/home/cnpj, para cada empresa
// de empresas.csv, com a pessoa operando o próprio Chrome. Detalhes no README.md.
//
// O script não mexe no site. Para cada empresa ele copia o CNPJ para a área de
// transferência e abre o site numa aba nova; 5 segundos depois a extensão (extensao-chrome)
// cola o CNPJ da vez, como se a pessoa apertasse V, e clica em Emitir Certidão. Quando o PDF chega
// em Downloads, o script confere se o CNPJ dentro dele é o da empresa, salva em
// certidoes\<NOME DA EMPRESA> - <CNPJ>.pdf (sem nunca sobrescrever um anterior), registra
// no relatório e passa para a próxima.
//
// A espera existe porque emitir uma atrás da outra, rápido demais, faz a Receita recusar
// ("Não foi possível concluir a ação... 106").
//
// O andamento fica em Controle.json, gravado depois de cada empresa: se a janela for
// fechada, rodar de novo continua das pendentes. Relatorio.csv (abre no Excel) tem uma
// linha por empresa da lista, com a situação de cada uma.
//
// Uso:
//   node certidao-rfb.js                     todas as pendentes
//   node certidao-rfb.js --verificar         só confere a lista, sem copiar nada
//   node certidao-rfb.js --organizar         só move para a pasta as certidões que já
//                                            estão em Downloads
//   node certidao-rfb.js --refazer-puladas   volta as puladas para pendente
//
// Toda execução começa movendo as certidões que já estão em Downloads (o site baixa como
// "Certidao-<CNPJ>.pdf"): o CNPJ é lido dentro do PDF, então dá para emitir sem o
// assistente.
//
// Enquanto roda, o script responde em http://127.0.0.1:47322/cnpj (só neste computador)
// com o CNPJ da empresa da vez. A extensão do Chrome (extensao-chrome) usa isso na tecla V;
// com o script fechado, ela não preenche nada.

import { execFileSync, spawn } from 'node:child_process';
import fs from 'node:fs';
import http from 'node:http';
import os from 'node:os';
import path from 'node:path';
import readline from 'node:readline';
import { fileURLToPath } from 'node:url';
import { getDocument } from 'pdfjs-dist/legacy/build/pdf.mjs';

const URL_CERTIDAO = 'https://servicos.receitafederal.gov.br/servico/certidoes/#/home/cnpj';

const PASTA_PROGRAMA = path.dirname(fileURLToPath(import.meta.url));
// PASTA_LOTE: onde ficam empresas.csv, Controle.json, Relatorio.csv e certidoes/ (a interface cria uma por lote). Sem ela, a pasta do programa.
const PASTA = process.env.PASTA_LOTE ? path.resolve(process.env.PASTA_LOTE) : PASTA_PROGRAMA;
const ARQUIVO_EMPRESAS = path.join(PASTA, 'empresas.csv');
const PASTA_SAIDA = path.join(PASTA, 'certidoes');
const ARQUIVO_CONTROLE = path.join(PASTA, 'Controle.json');
const ARQUIVO_RELATORIO = path.join(PASTA, 'Relatorio.csv');
const PASTA_DOWNLOADS = process.env.PASTA_DOWNLOADS || path.join(os.homedir(), 'Downloads');

const INTERVALO_DOWNLOADS = 1000;
// Mesma porta do fundo.js da extensão (a do MTE usa 47321, então os dois rodam juntos).
const PORTA_CNPJ = 47322;

const OPCOES = ['--verificar', '--organizar', '--refazer-puladas'];

const SITUACAO = {
  pendente: 'pendente',
  salvo: 'PDF salvo',
  pulada: 'pulada',
  semCertidao: 'sem certidão',
};

class ErroDeUso extends Error {}

function agora() {
  return new Date().toLocaleString('pt-BR');
}

// Só letras e números, em maiúsculas (o CNPJ alfanumérico vale desde julho/2026).
function chaveDoc(documento) {
  return documento.replace(/[^0-9A-Za-z]/g, '').toUpperCase();
}

// Dígitos verificadores do CNPJ; letras valem o código ASCII menos 48, como manda a RFB.
function cnpjValido(chave) {
  if (!/^[0-9A-Z]{12}\d{2}$/.test(chave) || /^(.)\1+$/.test(chave)) return false;
  const dv = (base) => {
    let soma = 0;
    let peso = base.length - 7;
    for (const c of base) {
      soma += (c.charCodeAt(0) - 48) * peso--;
      if (peso < 2) peso = 9;
    }
    const resto = soma % 11;
    return resto < 2 ? 0 : 11 - resto;
  };
  const d1 = dv(chave.slice(0, 12));
  return String(d1) === chave[12] && String(dv(chave.slice(0, 12) + d1)) === chave[13];
}

// CSV "CNPJ;Empresa" com cabeçalho. Toda linha não vazia vira um registro, mesmo as que
// não deu para interpretar.
function lerLista() {
  if (!fs.existsSync(ARQUIVO_EMPRESAS)) {
    throw new ErroDeUso(`Lista de empresas não encontrada: ${ARQUIVO_EMPRESAS}\nCopie empresas.exemplo.csv para empresas.csv e coloque as suas empresas (CNPJ;Empresa).`);
  }
  const registros = [];
  const linhas = fs.readFileSync(ARQUIVO_EMPRESAS, 'utf8').replace(/^﻿/, '').split(/\r?\n/);
  for (const [i, linha] of linhas.entries()) {
    if (i === 0 || !linha.trim()) continue;
    const [documento = '', ...resto] = linha.split(';');
    const nome = resto.join(';').trim();
    const chave = chaveDoc(documento);
    const registro = { linha: i + 1, nome, documento: documento.trim(), chave, problema: '' };
    if (!nome) registro.problema = 'Linha sem nome da empresa';
    else if (!cnpjValido(chave)) registro.problema = `CNPJ com formato ou dígito verificador inválido: ${documento}`;
    registros.push(registro);
  }
  return registros;
}

function conferirLista(registros) {
  const validos = registros.filter((r) => !r.problema);
  const unicos = new Set(validos.map((r) => r.chave));
  console.log(`Lista: ${registros.length} empresa(s), ${unicos.size} CNPJ(s) único(s), ${validos.length - unicos.size} repetido(s)`);
  for (const r of registros.filter((r) => r.problema)) console.log(`  linha ${r.linha}: ${r.nome || '(sem nome)'} - ${r.problema}`);
  const repetidas = registros.filter((r) => r.repetidaDe);
  if (repetidas.length) console.log(`Repetidas (mesma empresa, emitidas uma vez só): ${repetidas.length}`);
  for (const r of repetidas) console.log(`  linha ${r.linha}: ${r.nome} ${r.documento} -> fica com ${r.repetidaDe.documento}`);
}

// Raiz do CNPJ (8 primeiros caracteres): a mesma para a matriz e as filiais.
function raiz(chave) {
  return chave.slice(0, 8);
}

// A certidão da Receita vale para a empresa toda (matriz e filiais), então cada raiz de
// CNPJ é emitida uma vez só: fica a matriz (0001) se estiver na lista, senão a primeira.
// As outras linhas da mesma raiz (CNPJ repetido ou filial) ganham repetidaDe.
function marcarRepetidas(registros) {
  const ehMatriz = (r) => r.chave.slice(8, 12) === '0001';
  const escolhida = new Map();
  for (const r of registros.filter((r) => !r.problema)) {
    const atual = escolhida.get(raiz(r.chave));
    if (!atual || (ehMatriz(r) && !ehMatriz(atual))) escolhida.set(raiz(r.chave), r);
  }
  for (const r of registros.filter((r) => !r.problema)) {
    const e = escolhida.get(raiz(r.chave));
    if (e !== r) r.repetidaDe = e;
  }
}

function lerOpcoes(args) {
  const desconhecida = args.find((a) => !OPCOES.includes(a));
  if (desconhecida) throw new ErroDeUso(`Opção desconhecida: ${desconhecida}. Opções válidas: ${OPCOES.join(' ')}`);
  return { verificar: args.includes('--verificar'), organizar: args.includes('--organizar'), refazerPuladas: args.includes('--refazer-puladas') };
}

function carregarControle() {
  try {
    return JSON.parse(fs.readFileSync(ARQUIVO_CONTROLE, 'utf8'));
  } catch (e) {
    if (e.code === 'ENOENT') return { loteIniciadoEm: agora(), documentos: {} };
    throw new Error(`Não consegui ler ${ARQUIVO_CONTROLE}: ${e.message}`);
  }
}

// Grava num temporário e renomeia, para não deixar o controle pela metade se cair.
function gravarControle(controle) {
  const temporario = `${ARQUIVO_CONTROLE}.tmp`;
  fs.writeFileSync(temporario, JSON.stringify(controle, null, 2), 'utf8');
  fs.renameSync(temporario, ARQUIVO_CONTROLE);
}

function celulaCsv(valor) {
  const texto = String(valor ?? '');
  return /[;"\r\n]/.test(texto) ? `"${texto.replace(/"/g, '""')}"` : texto;
}

let avisouRelatorioAberto = false;

function gravarRelatorio(registros, controle) {
  const cabecalho = ['Linha', 'Empresa', 'CNPJ', 'Situação', 'Mensagem', 'PDF', 'Processado em'];
  const linhas = registros.map((r) => {
    if (r.problema) return [r.linha, r.nome, r.documento, 'CNPJ inválido', r.problema, '', ''];
    if (r.repetidaDe) {
      const e = controle.documentos[r.repetidaDe.chave];
      return [r.linha, r.nome, r.documento, 'repetida', `Mesma empresa de ${r.repetidaDe.documento}: certidão emitida uma vez só`, e?.pdf ?? '', ''];
    }
    const c = controle.documentos[r.chave];
    return [r.linha, r.nome, r.documento, c.situacao, c.mensagem, c.pdf, c.processadoEm];
  });
  // BOM e ";" para o Excel em português abrir com acentos e colunas certas.
  const csv = `﻿${[cabecalho, ...linhas].map((l) => l.map(celulaCsv).join(';')).join('\r\n')}\r\n`;
  try {
    fs.writeFileSync(ARQUIVO_RELATORIO, csv, 'utf8');
    avisouRelatorioAberto = false;
  } catch (e) {
    if (e.code !== 'EBUSY' && e.code !== 'EPERM') throw e;
    // Planilha aberta no Excel: o controle continua sendo gravado e o relatório sai depois.
    if (!avisouRelatorioAberto) console.warn(`  AVISO: feche ${path.basename(ARQUIVO_RELATORIO)} no Excel para o relatório ser atualizado.`);
    avisouRelatorioAberto = true;
  }
}

// Sem acentos e sem caracteres proibidos em nome de arquivo.
function nomeLimpo(nome) {
  return nome
    .normalize('NFD').replace(/[̀-ͯ]/g, '')
    .replace(/[\\/:*?"<>|]/g, ' ').replace(/\s+/g, ' ').trim().replace(/[. ]+$/, '').slice(0, 150);
}

// Nome de MEI vem com a raiz do CNPJ na frente ("17.100.354 MARIA ..."); o CNPJ já vai
// no fim do nome do arquivo, então sai do começo.
function nomeSemCnpj(nome) {
  return nome.replace(/^\d{2}\.?\d{3}\.?\d{3}\s+/, '');
}

// <NOME DA EMPRESA> - <CNPJ>.pdf; se o arquivo já existir, o novo ganha " (2)", " (3)"...
// ("wx" falha se o arquivo existir, então um PDF anterior nunca é sobrescrito.)
function salvarPdf(empresa, pdf) {
  const base = `${nomeLimpo(nomeSemCnpj(empresa.nome))} - ${empresa.chave}`;
  for (let n = 1; ; n++) {
    const arquivo = path.join(PASTA_SAIDA, n === 1 ? `${base}.pdf` : `${base} (${n}).pdf`);
    try {
      fs.writeFileSync(arquivo, pdf, { flag: 'wx' });
      return arquivo;
    } catch (e) {
      if (e.code !== 'EEXIST') throw e;
    }
  }
}

// Print da tela "sem certidão": INVALIDA-<CNPJ>.png (nunca sobrescreve; o novo ganha " (2)", ...).
function salvarPrint(empresa, png) {
  const base = `INVALIDA-${empresa.chave}`;
  for (let n = 1; ; n++) {
    const arquivo = path.join(PASTA_SAIDA, n === 1 ? `${base}.png` : `${base} (${n}).png`);
    try {
      fs.writeFileSync(arquivo, png, { flag: 'wx' });
      return arquivo;
    } catch (e) {
      if (e.code !== 'EEXIST') throw e;
    }
  }
}

// PDF da empresa que já está na pasta de saída (com o CNPJ no nome), ou ''.
function pdfNaPasta(empresa) {
  const arquivo = fs.readdirSync(PASTA_SAIDA).find((a) => /\.pdf$/i.test(a) && chaveDoc(a).includes(empresa.chave));
  return arquivo ? path.join(PASTA_SAIDA, arquivo) : '';
}

// PDF que já está na pasta de saída com o CNPJ no nome marca a empresa como PDF salvo.
function marcarJaSalvas(controle) {
  let marcadas = 0;
  for (const empresa of Object.values(controle.documentos)) {
    if (empresa.situacao === SITUACAO.salvo || empresa.situacao === SITUACAO.semCertidao) continue;
    const pdf = pdfNaPasta(empresa);
    if (!pdf) continue;
    Object.assign(empresa, { situacao: SITUACAO.salvo, pdf, mensagem: 'PDF já estava na pasta' });
    marcadas++;
  }
  return marcadas;
}

// Texto do PDF sem espaços, para o CNPJ e o título não dependerem da quebra das linhas.
async function textoDoPdf(pdf) {
  const doc = await getDocument({ data: new Uint8Array(pdf), verbosity: 0 }).promise;
  let texto = '';
  for (let i = 1; i <= doc.numPages; i++) {
    texto += (await (await doc.getPage(i)).getTextContent()).items.map((item) => item.str).join('');
  }
  await doc.destroy();
  return texto.replace(/\s+/g, '');
}

// Negativa ou positiva com efeitos de negativa: as duas falam de tributos federais e da
// Dívida Ativa da União.
function ehCertidaoRfb(texto) {
  const t = texto.normalize('NFD').replace(/[̀-ͯ]/g, '').toUpperCase();
  return t.includes('DIVIDAATIVADAUNIAO') || t.includes('TRIBUTOSFEDERAIS');
}

// CNPJs (formatados ou só dígitos) que aparecem no texto do PDF.
function cnpjsNoTexto(texto) {
  const achados = texto.match(/[0-9A-Z]{2}\.?[0-9A-Z]{3}\.?[0-9A-Z]{3}\/?[0-9A-Z]{4}-?\d{2}/g) ?? [];
  return new Set(achados.map(chaveDoc).filter(cnpjValido));
}

// Certidões já em Downloads (emitidas sem o assistente, ou com ele fechado): cada uma
// vai para a pasta com o nome da empresa cujo CNPJ está dentro do PDF. Fica em Downloads
// o que não for certidão da Receita, não for da lista ou for de empresa que já tem PDF.
async function organizarDownloads(controle) {
  const movidas = [];
  const deixadas = [];
  for (const nome of pdfsEmDownloads().keys()) {
    const origem = path.join(PASTA_DOWNLOADS, nome);
    const pdf = fs.readFileSync(origem);
    let texto;
    try {
      texto = await textoDoPdf(pdf);
    } catch {
      continue;
    }
    if (!ehCertidaoRfb(texto)) continue;
    const cnpjs = cnpjsNoTexto(texto);
    let empresas = [...cnpjs].map((k) => controle.documentos[k]).filter(Boolean);
    // Certidão pedida pela filial traz o CNPJ da matriz: vale a empresa de mesma raiz.
    if (!empresas.length) {
      const raizes = new Set([...cnpjs].map(raiz));
      empresas = Object.values(controle.documentos).filter((e) => raizes.has(raiz(e.chave)));
    }
    if (!empresas.length) {
      deixadas.push(`${nome}: CNPJ não está na lista`);
      continue;
    }
    const empresa = empresas[0];
    if (empresa.situacao === SITUACAO.salvo) {
      deixadas.push(`${nome}: ${empresa.nome} já tem PDF (${path.basename(empresa.pdf)})`);
      continue;
    }
    const destino = salvarPdf(empresa, pdf);
    fs.unlinkSync(origem);
    Object.assign(empresa, { situacao: SITUACAO.salvo, pdf: destino, mensagem: 'Emitida sem o assistente; CNPJ conferido no PDF', processadoEm: agora() });
    movidas.push(`${nome} -> ${path.basename(destino)}`);
  }
  if (movidas.length) console.log(`\nCertidões movidas de Downloads: ${movidas.length}`);
  for (const linha of movidas) console.log(`  ${linha}`);
  if (deixadas.length) console.log(`Certidões deixadas em Downloads: ${deixadas.length}`);
  for (const linha of deixadas) console.log(`  ${linha}`);
}

function pdfsEmDownloads() {
  const arquivos = new Map();
  for (const nome of fs.readdirSync(PASTA_DOWNLOADS)) {
    if (!/\.pdf$/i.test(nome)) continue;
    try {
      const { size, mtimeMs } = fs.statSync(path.join(PASTA_DOWNLOADS, nome));
      arquivos.set(nome, `${size}:${mtimeMs}`);
    } catch {
      // Apagado ou renomeado entre a listagem e o stat.
    }
  }
  return arquivos;
}

// Comandos digitados na janela enquanto o script espera o PDF.
const comandos = [];
let avisarComando = null;
readline.createInterface({ input: process.stdin }).on('line', (linha) => {
  comandos.push(linha.trim().toLowerCase());
  avisarComando?.();
});

// Pausa pedida pela interface (arquivo PAUSAR na pasta do lote): espera entre uma empresa e outra,
// sem perder o andamento. Devolve false se o usuário mandou sair (s) durante a pausa.
const ARQUIVO_PAUSA = path.join(PASTA, 'PAUSAR');
async function aguardarSePausado() {
  let avisou = false;
  while (fs.existsSync(ARQUIVO_PAUSA)) {
    if (comandos.includes('s')) return false;
    if (!avisou) console.log('\n  PAUSADO. Aguardando para continuar...');
    avisou = true;
    await new Promise((r) => setTimeout(r, 1000));
  }
  if (avisou) console.log('  Retomando...');
  return true;
}

function proximoComando() {
  return comandos.length ? Promise.resolve(comandos.shift()) : new Promise((resolve) => {
    avisarComando = () => {
      avisarComando = null;
      resolve(comandos.shift());
    };
  });
}

// Espera um PDF novo em Downloads (ou com tamanho/data diferentes do que havia antes) e
// que tenha parado de crescer, ou um comando digitado. Devolve { arquivo } ou { comando }.
async function aguardarPdfOuComando(antes, limiteMs = 0) {
  let candidatos = new Map();
  const inicio = Date.now();
  while (true) {
    const comando = await Promise.race([proximoComando(), new Promise((r) => setTimeout(r, INTERVALO_DOWNLOADS))]);
    if (comando !== undefined) {
      avisarComando = null;
      return { comando };
    }
    if (limiteMs && Date.now() - inicio > limiteMs) {
      avisarComando = null;
      return { comando: 'tempo' };
    }
    const atuais = pdfsEmDownloads();
    for (const [nome, assinatura] of atuais) {
      if (antes.get(nome) === assinatura) continue;
      // O mesmo tamanho em duas leituras seguidas: o Chrome terminou de gravar.
      if (candidatos.get(nome) === assinatura) return { arquivo: path.join(PASTA_DOWNLOADS, nome), assinatura, nome };
    }
    candidatos = atuais;
  }
}

// ASSISTENTE_TESTE=1: não mexe na área de transferência nem abre o Chrome (para testes).
const MODO_TESTE = process.env.ASSISTENTE_TESTE === '1';

// Segundos de pausa entre uma empresa e a próxima (aumente se o erro "tente novamente" voltar).
const PAUSA_ENTRE_EMPRESAS = Number(process.env.PAUSA_SEGUNDOS ?? 15);

// Quantas empresas emitir por execução (LIMITE=1 para testar só uma). Sem LIMITE, vai até o fim.
const LIMITE_POR_EXECUCAO = Number(process.env.LIMITE ?? Infinity);

// Lote sem ninguém olhando: TEMPO_MAX_EMPRESA_MIN=8 dá até 8 min por tentativa. Estourou, reabre o site
// uma vez (como o comando a); estourou de novo, a empresa fica "pulada" com o motivo e o lote segue.
// 0 (padrão) mantém o comportamento de sempre: espera sem limite.
const TEMPO_MAXIMO_EMPRESA = Number(process.env.TEMPO_MAX_EMPRESA_MIN ?? 0) * 60000;

function copiar(texto) {
  if (MODO_TESTE) return;
  execFileSync(process.platform === 'darwin' ? 'pbcopy' : 'clip', { input: texto });
}

// CNPJ da empresa da vez para a extensão (tecla V). Só atende este computador
// (127.0.0.1) e só enquanto o script está esperando um PDF.
let empresaDaVez = null;
let servidorCnpj = null;

// Check-in da extensão: cada aba do site avisa em /oi quando abre. Se a aba aberta pelo
// assistente não avisar, a extensão não está instalada, está desativada ou o site não abriu.
const ESPERA_CHECK_IN = 20000;
let extensaoAvisou = false;
let avisoCheckIn = null;

function aguardarCheckIn() {
  extensaoAvisou = false;
  clearTimeout(avisoCheckIn);
  avisoCheckIn = setTimeout(() => {
    if (extensaoAvisou) return;
    console.log('  ATENÇÃO: a extensão não respondeu. Confira:');
    console.log('    1. O Chrome abriu o site da Receita numa aba nova?');
    console.log('    2. Em chrome://extensions, "Baixar Certidão Receita Federal" está instalada e ativada?');
    if (ABRIR_EM_ANONIMO) console.log('       Em "Detalhes" dela, "Permitir no modo anônimo" está ligado?');
    console.log(`       (Carregar sem compactação -> pasta ${path.join(PASTA_PROGRAMA, 'extensao-chrome')})`);
    console.log('    Depois de instalar, digite a e Enter para abrir o site de novo.');
  }, ESPERA_CHECK_IN);
}

// Tela "sem certidão" impressa em PDF pela extensão (POST /impressao, JSON com cnpj,
// motivo e o PDF em base64). Só vale para a empresa da vez; entra na fila de comandos
// para o emitir() salvar.
const LIMITE_JSON = 20 * 1024 * 1024;

// Corpo JSON de um POST da extensão; null se não der para ler.
function lerJson(req) {
  return new Promise((resolve) => {
    let corpo = '';
    req.setEncoding('utf8');
    req.on('data', (parte) => {
      corpo += parte;
      if (corpo.length > LIMITE_JSON) req.destroy();
    });
    req.on('error', () => resolve(null));
    req.on('end', () => {
      try {
        resolve(JSON.parse(corpo));
      } catch {
        resolve(null);
      }
    });
  });
}

async function receberImpressao(req, res) {
  const dados = await lerJson(req);
  const chave = chaveDoc(String(dados?.cnpj ?? ''));
  if (!dados?.imagem || !empresaDaVez || raiz(chave) !== raiz(empresaDaVez.chave)) {
    res.writeHead(409).end();
    return;
  }
  comandos.push({ impressao: Buffer.from(dados.imagem, 'base64'), motivo: String(dados.motivo ?? 'Certidão não emitida') });
  avisarComando?.();
  res.writeHead(204).end();
}

// Certidão pega pela extensão na página, sem passar pelo download do Chrome (POST
// /certidao, JSON com arquivo e o PDF em base64). É conferida antes de responder: se não
// for da empresa da vez, a extensão deixa o site baixar do jeito normal.
async function receberCertidao(req, res) {
  const dados = await lerJson(req);
  const empresa = empresaDaVez;
  if (!dados?.pdf || !empresa) {
    res.writeHead(409).end();
    return;
  }
  const pdf = Buffer.from(dados.pdf, 'base64');
  const conferencia = await conferirPdf(empresa, pdf);
  if (!conferencia.ok || empresa !== empresaDaVez) {
    console.log(`  ATENÇÃO: ${dados.arquivo ?? 'PDF'} recusado: ${conferencia.mensagem}.`);
    res.writeHead(409).end();
    return;
  }
  comandos.push({ certidao: pdf, mensagem: conferencia.mensagem });
  avisarComando?.();
  res.writeHead(204).end();
}

function iniciarServidorCnpj() {
  servidorCnpj = http.createServer((req, res) => {
    if (req.method === 'POST' && req.url === '/impressao') {
      receberImpressao(req, res);
      return;
    }
    if (req.method === 'POST' && req.url === '/certidao') {
      receberCertidao(req, res);
      return;
    }
    if (req.method === 'GET' && req.url === '/oi') {
      if (!extensaoAvisou) console.log('  OK: extensão conectada na aba do site. O CNPJ entra em 5 s.');
      extensaoAvisou = true;
      clearTimeout(avisoCheckIn);
      res.writeHead(204).end();
      return;
    }
    if (req.method !== 'GET' || req.url !== '/cnpj' || !empresaDaVez) {
      res.writeHead(404).end();
      return;
    }
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
    res.end(JSON.stringify({ cnpj: empresaDaVez.documento, nome: empresaDaVez.nome }));
  });
  // Sem a porta a extensão não acha o CNPJ nem entrega a certidão. Porta ocupada quase
  // sempre é o assistente aberto em outra janela: duas janelas disputariam os mesmos
  // PDFs e o mesmo controle, então esta não continua.
  return new Promise((resolve, reject) => {
    servidorCnpj.once('error', (e) => {
      reject(new ErroDeUso(e.code === 'EADDRINUSE'
        ? `O assistente já está aberto em outra janela preta (porta ${PORTA_CNPJ} ocupada).\nFeche as outras janelas do INICIAR.cmd e abra só uma.`
        : `Não consegui usar a porta ${PORTA_CNPJ}: ${e.message}`));
    });
    servidorCnpj.listen(PORTA_CNPJ, '127.0.0.1', resolve);
  });
}

// Abre o site numa guia anônima (sem os cookies da sessão normal do Chrome). A extensão só
// roda lá se estiver com "Permitir na navegação anônima" ligado em chrome://extensions.
// A certidão chega pela extensão (/certidao), sem o download do Chrome, que na guia
// anônima abriria o "Salvar como".
// Para voltar à janela normal, troque para false.
const ABRIR_EM_ANONIMO = true;

function abrirSite() {
  if (MODO_TESTE) return;
  const argumentos = ABRIR_EM_ANONIMO ? ['--incognito', URL_CERTIDAO] : [URL_CERTIDAO];
  if (process.platform === 'darwin') {
    // No macOS chama o executável do Chrome direto: com o Chrome já aberto, a janela anônima abre nele.
    spawn('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', argumentos, { detached: true, stdio: 'ignore' }).unref();
    return;
  }
  spawn('cmd', ['/c', 'start', '', 'chrome', ...argumentos], { detached: true, stdio: 'ignore' }).unref();
}

function mostrarEmpresa(empresa, faltam) {
  console.log('\n==============================================================');
  console.log(`  EMPRESA: ${empresa.nome}`);
  console.log(`  CNPJ ${empresa.documento} copiado.`);
  console.log('  Na aba nova do Chrome o CNPJ entra sozinho em 5 s e o Emitir é clicado (ou aperte V antes).');
  console.log('  Se aparecer "Não foi possível concluir a ação", espere uns minutos e aperte V de novo.');
  console.log(`  Faltam ${faltam} empresa(s). Comandos: c = copiar de novo, a = abrir o site de novo, p = pular, s = sair`);
  console.log('==============================================================');
  console.log('  Aguardando o PDF em Downloads...');
}

async function aceitar(empresa, pdf, mensagem) {
  await completarNome(empresa, pdf);
  return { ok: true, mensagem };
}

// Linha da lista sem nome (a interface usa o próprio CNPJ no lugar): o nome do arquivo passa a ser
// o "Nome:" que está escrito na certidão.
async function completarNome(empresa, pdf) {
  if (empresa.nome.replace(/[^0-9A-Za-z]/g, '').toUpperCase() !== empresa.chave) return;
  try {
    const doc = await getDocument({ data: new Uint8Array(pdf), verbosity: 0 }).promise;
    let texto = '';
    for (let i = 1; i <= doc.numPages; i++) texto += (await (await doc.getPage(i)).getTextContent()).items.map((item) => item.str).join(' ');
    await doc.destroy();
    const nome = texto.replace(/\s+/g, ' ').match(/Nome:\s*(.+?)\s*CNPJ:/)?.[1]?.trim();
    if (nome) empresa.nome = nome;
  } catch {
    // fica com o CNPJ no lugar do nome
  }
}

// Confere o PDF baixado. Devolve { ok, mensagem }; ok false deixa o arquivo em Downloads.
async function conferirPdf(empresa, pdf) {
  if (pdf.subarray(0, 4).toString() !== '%PDF') return { ok: false, mensagem: 'não é um PDF válido' };
  let texto;
  try {
    texto = await textoDoPdf(pdf);
  } catch (e) {
    return { ok: true, mensagem: `Salvo sem conferir o CNPJ (não consegui ler o PDF: ${e.message})` };
  }
  if (!ehCertidaoRfb(texto)) return { ok: false, mensagem: 'não é a certidão de tributos federais da Receita' };
  const cnpjs = cnpjsNoTexto(texto);
  if (cnpjs.has(empresa.chave)) return aceitar(empresa, pdf, 'CNPJ conferido no PDF');
  // A certidão pode trazer só a raiz do CNPJ (os 8 primeiros dígitos), que vale para
  // todos os estabelecimentos.
  const raiz = empresa.chave.slice(0, 8);
  if (chaveDoc(texto).includes(raiz)) return aceitar(empresa, pdf, 'Raiz do CNPJ conferida no PDF');
  if (!cnpjs.size) return aceitar(empresa, pdf, 'Salvo sem conferir o CNPJ (não achei CNPJ no texto do PDF)');
  return { ok: false, mensagem: `o PDF é de outro CNPJ (${[...cnpjs].join(', ')})` };
}

// Cada empresa ganha uma aba nova do site, com o formulário limpo e o CNPJ já copiado.
// A aba anterior é fechada pela extensão (extensao-chrome) depois do download.
async function emitir(empresa, faltam) {
  copiar(empresa.documento);
  abrirSite();
  mostrarEmpresa(empresa, faltam);
  if (!MODO_TESTE) aguardarCheckIn();
  let antes = pdfsEmDownloads();
  let reaberturas = 0;
  while (true) {
    const resultado = await aguardarPdfOuComando(antes, TEMPO_MAXIMO_EMPRESA);
    if (resultado.comando?.certidao) {
      const destino = salvarPdf(empresa, resultado.comando.certidao);
      console.log(`  Salvo: ${path.basename(destino)} (${resultado.comando.mensagem})`);
      return { situacao: SITUACAO.salvo, pdf: destino, mensagem: resultado.comando.mensagem };
    }
    if (resultado.comando?.impressao) {
      const destino = salvarPrint(empresa, resultado.comando.impressao);
      console.log(`  SEM CERTIDÃO: ${resultado.comando.motivo}`);
      console.log(`  Print da tela salvo: ${path.basename(destino)}`);
      return { situacao: SITUACAO.semCertidao, pdf: destino, mensagem: resultado.comando.motivo };
    }
    if (resultado.comando !== undefined) {
      if (resultado.comando === 'tempo') {
        const minutos = TEMPO_MAXIMO_EMPRESA / 60000;
        if (reaberturas++ < 1) {
          console.log(`  ATENÇÃO: sem resposta do portal em ${minutos} min. Abrindo o site de novo (última tentativa).`);
          abrirSite();
          aguardarCheckIn();
        } else {
          console.log('  ERRO: sem resposta do portal depois de 2 tentativas. Registrada como pulada; o lote segue.');
          return { situacao: SITUACAO.pulada, mensagem: `ERRO: sem resposta do portal (${minutos} min por tentativa, 2 tentativas)` };
        }
      } else if (resultado.comando === 'c') {
        copiar(empresa.documento);
        console.log(`  CNPJ ${empresa.documento} copiado de novo.`);
      } else if (resultado.comando === 'a') {
        abrirSite();
        console.log('  Site aberto de novo numa aba nova.');
        aguardarCheckIn();
      } else if (resultado.comando === 'p') {
        return { situacao: SITUACAO.pulada, mensagem: 'Pulada na janela do assistente' };
      } else if (resultado.comando === 's') {
        return null;
      } else if (resultado.comando) {
        console.log('  Comando não reconhecido. Use c = copiar de novo, a = abrir o site de novo, p = pular, s = sair.');
      }
      continue;
    }

    const pdf = fs.readFileSync(resultado.arquivo);
    const conferencia = await conferirPdf(empresa, pdf);
    if (!conferencia.ok) {
      console.log(`  ATENÇÃO: ${resultado.nome} ficou em Downloads: ${conferencia.mensagem}.`);
      console.log(`  Emita de novo para ${empresa.nome} ou digite p para pular.`);
      antes = pdfsEmDownloads();
      continue;
    }
    const destino = salvarPdf(empresa, pdf);
    fs.unlinkSync(resultado.arquivo);
    console.log(`  Salvo: ${path.basename(destino)} (${conferencia.mensagem})`);
    return { situacao: SITUACAO.salvo, pdf: destino, mensagem: conferencia.mensagem };
  }
}

function mostrarResumo(registros, controle) {
  const empresas = Object.values(controle.documentos);
  const contar = (situacao) => empresas.filter((e) => e.situacao === situacao).length;
  console.log('\nResumo:');
  console.log(`  PDF salvo: ${contar(SITUACAO.salvo)}`);
  console.log(`  Sem certidão (print INVALIDA-CNPJ salvo):${contar(SITUACAO.semCertidao)}`);
  console.log(`  Puladas: ${contar(SITUACAO.pulada)}`);
  console.log(`  Pendentes: ${contar(SITUACAO.pendente)}`);
  const invalidos = registros.filter((r) => r.problema).length;
  if (invalidos) console.log(`  CNPJ inválido (fora do processo): ${invalidos}`);
  const repetidas = registros.filter((r) => r.repetidaDe).length;
  if (repetidas) console.log(`  Repetidas (mesma empresa de outra linha): ${repetidas}`);
  console.log(`  Relatório: ${ARQUIVO_RELATORIO}`);
}

async function main() {
  const opcoes = lerOpcoes(process.argv.slice(2));
  const registros = lerLista();
  marcarRepetidas(registros);
  conferirLista(registros);
  if (opcoes.verificar) return;
  // Antes de mexer em Downloads ou no controle: se já houver outra janela aberta, para aqui.
  await iniciarServidorCnpj();

  fs.mkdirSync(PASTA_SAIDA, { recursive: true });
  const controle = carregarControle();
  // Uma empresa por raiz de CNPJ (ver marcarRepetidas).
  const chaves = [];
  for (const r of registros.filter((r) => !r.problema && !r.repetidaDe)) {
    chaves.push(r.chave);
    controle.documentos[r.chave] ??= { nome: r.nome, documento: r.documento, chave: r.chave, situacao: SITUACAO.pendente, mensagem: '', pdf: '', processadoEm: '' };
  }
  // Pendentes que saíram da lista (ou viraram repetidas) não contam mais.
  for (const [k, e] of Object.entries(controle.documentos)) {
    if (!chaves.includes(k) && e.situacao === SITUACAO.pendente) delete controle.documentos[k];
  }
  if (opcoes.refazerPuladas) {
    for (const k of chaves) {
      const empresa = controle.documentos[k];
      if (empresa.situacao === SITUACAO.pulada) Object.assign(empresa, { situacao: SITUACAO.pendente, mensagem: '' });
    }
  }
  const jaSalvas = marcarJaSalvas(controle);
  if (jaSalvas) console.log(`PDFs que já estavam na pasta: ${jaSalvas}`);
  await organizarDownloads(controle);
  gravarControle(controle);
  gravarRelatorio(registros, controle);
  if (opcoes.organizar) {
    mostrarResumo(registros, controle);
    return;
  }

  const pendentes = chaves.filter((k) => controle.documentos[k].situacao === SITUACAO.pendente);
  const feitas = chaves.filter((k) => controle.documentos[k].situacao === SITUACAO.salvo).length;
  console.log(`\nJá emitidas (não serão repetidas): ${feitas} de ${chaves.length}. Pendentes: ${pendentes.length}.`);
  if (!pendentes.length) {
    console.log('\nNenhuma empresa pendente.');
  } else {
    for (const [i, chave] of pendentes.entries()) {
      if (i >= LIMITE_POR_EXECUCAO) {
        console.log(`\nLimite de ${LIMITE_POR_EXECUCAO} empresa(s) nesta execução. Rode de novo para continuar.`);
        break;
      }
      if (!(await aguardarSePausado())) {
        console.log('\nParado. Rode de novo para continuar desta empresa.');
        process.exitCode = 3;
        break;
      }
      const empresa = controle.documentos[chave];
      // Confere de novo antes de abrir o site: o PDF pode ter entrado na pasta depois.
      const jaTem = pdfNaPasta(empresa);
      if (jaTem) {
        console.log(`
  ${empresa.nome}: já tem PDF na pasta (${path.basename(jaTem)}), não emite de novo.`);
        Object.assign(empresa, { situacao: SITUACAO.salvo, pdf: jaTem, mensagem: 'PDF já estava na pasta', processadoEm: agora() });
        gravarControle(controle);
        gravarRelatorio(registros, controle);
        continue;
      }
      empresaDaVez = empresa;
      const resultado = await emitir(empresa, pendentes.length - i);
      empresaDaVez = null;
      if (!resultado) {
        console.log('\nParado. Rode de novo para continuar desta empresa.');
        process.exitCode = 3; // avisa o iniciar.sh que foi o usuário quem parou
        break;
      }
      Object.assign(empresa, { pdf: '', ...resultado, processadoEm: agora() });
      gravarControle(controle);
      gravarRelatorio(registros, controle);
      // Pausa entre empresas: emitir uma atrás da outra, rápido demais, faz a Receita recusar.
      if (i < Math.min(pendentes.length, LIMITE_POR_EXECUCAO) - 1 && PAUSA_ENTRE_EMPRESAS > 0) {
        console.log(`\n  Pausa de ${PAUSA_ENTRE_EMPRESAS} s antes da próxima empresa (para a Receita não recusar)...`);
        await new Promise((r) => setTimeout(r, PAUSA_ENTRE_EMPRESAS * 1000));
      }
    }
  }
  mostrarResumo(registros, controle);
}

main()
  .catch((e) => {
    console.error(e instanceof ErroDeUso ? e.message : e);
    process.exitCode = 1;
  })
  .finally(() => {
    process.stdin.destroy();
    clearTimeout(avisoCheckIn);
    servidorCnpj?.close();
  });
