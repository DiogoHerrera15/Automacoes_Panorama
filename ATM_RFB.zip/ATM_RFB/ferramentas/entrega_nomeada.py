"""Entrega nomeada de um lote da automacao RFB (so copia, nunca apaga nem move).

Uso:  python3 entrega_nomeada.py <pasta-do-lote> <pasta-de-destino>
Ex.:  python3 entrega_nomeada.py ~/Documents/MeuLote ~/Documents/RFB-MeuLote-Entrega
Gera no destino: 01 - Certidoes emitidas/ (NOME - CNPJ.pdf), 02 - Sem certidao/ (IRREGULAR - NOME - CNPJ.pdf,
prints convertidos para PDF), Relatorio-Certidoes.xlsx, e o .zip ao lado. Precisa de Pillow e openpyxl.
"""
import json, os, re, shutil, sys, zipfile, csv
from PIL import Image
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
base = os.path.expanduser(sys.argv[1])
dest = os.path.expanduser(sys.argv[2])
assert not os.path.exists(dest), 'destino ja existe'
d = json.load(open(f'{base}/Controle.json'))['documentos']
a = f'{dest}/01 - Certidoes emitidas'; b = f'{dest}/02 - Sem certidao'
os.makedirs(a); os.makedirs(b)
def limpa(n): return re.sub(r'\s+', ' ', n.replace('/', '-').replace('\\', '-').replace(':', '-')).strip()
def motivo(m):
    m = m or ''
    if 'Receita Federal e na Procuradoria' in m: return 'Informações insuficientes (Receita Federal e PGFN)'
    if 'Procuradoria' in m: return 'Informações insuficientes (PGFN)'
    if 'Receita Federal' in m: return 'Informações insuficientes (Receita Federal)'
    if 'Inapta' in m: return 'CNPJ inapto - omissão de declaração'
    return m
linhas = []
for v in sorted(d.values(), key=lambda v: v['nome']):
    nome = limpa(v['nome']); ch = v['chave']
    if v['situacao'] == 'PDF salvo':
        arq = f'{nome} - {ch}.pdf'; pasta = a; sit = 'Certidão emitida'; mot = ''
    else:
        arq = f'IRREGULAR - {nome} - {ch}.pdf'; pasta = b; sit = 'Sem certidão'; mot = motivo(v['mensagem'])
    if v['situacao'] == 'PDF salvo':
        shutil.copy2(v['pdf'], f'{pasta}/{arq}')
    else:
        Image.open(v['pdf']).convert('RGB').save(f'{pasta}/{arq}', 'PDF', resolution=100.0)
    linhas.append((v['nome'], v['documento'], sit, mot, arq, v['processadoEm']))
# filiais cobertas
for r in csv.reader(open(f'{base}/empresas.csv', encoding='utf-8-sig'), delimiter=';'):
    if r and 'FILIAL' in r[1].upper():
        linhas.append((r[1], r[0], 'Filial - coberta pela certidão da matriz', '', '(sem arquivo próprio)', ''))
wb = Workbook(); ws = wb.active; ws.title = 'Relatório'
cab = ['Empresa', 'CNPJ', 'Situação', 'Motivo', 'Arquivo', 'Processado em']
ws.append(cab)
for c in ws[1]:
    c.font = Font(bold=True, color='FFFFFF'); c.fill = PatternFill('solid', fgColor='1F4E78'); c.alignment = Alignment(horizontal='center')
for l in linhas: ws.append(l)
for col, w in zip('ABCDEF', [48, 22, 34, 46, 80, 22]): ws.column_dimensions[col].width = w
ws.freeze_panes = 'A2'; ws.auto_filter.ref = ws.dimensions
wb.save(f'{dest}/Relatorio-Certidoes.xlsx')
zp = dest + '.zip'
with zipfile.ZipFile(zp, 'w', zipfile.ZIP_DEFLATED) as z:
    for root, _, fs in os.walk(dest):
        for f in sorted(fs):
            p = os.path.join(root, f); z.write(p, os.path.relpath(p, os.path.dirname(dest)))
print(len(os.listdir(a)), len(os.listdir(b)), len(linhas), round(os.path.getsize(zp)/1e6, 1))
