"""Lote da automacao RFB: prepara a lista e organiza os PDFs em resultado/<CNPJ>/ (ou na pasta indicada em PASTA_SAIDA).

A lista (lista_cnpjs.txt) pode vir como "CNPJ;Nome" ou "Nome;CNPJ"; CPFs (pessoa fisica) sao ignorados: a certidao e so de CNPJ.

Uso (o iniciar.sh chama estes passos; da pra rodar a mao):
    python3 ferramentas/lote.py preparar         le lista_cnpjs.txt, gera empresas.csv e cria resultado/<14 digitos>/ para cada CNPJ
    python3 ferramentas/lote.py organizar        copia os PDFs/prints de certidoes/ para a pasta de cada CNPJ e atualiza resultado/Controle_Certidoes.xlsx
    python3 ferramentas/lote.py contar-puladas   imprime quantas empresas estao com erro (puladas)

So copia: certidoes/, Controle.json e Relatorio.csv nunca sao alterados. Rodar de novo nao duplica nada.
Precisa de Pillow e openpyxl (pip install -r requirements.txt).
"""
import csv
import json
import os
import re
import shutil
import sys
from collections import Counter
from datetime import datetime
from pathlib import Path

BASE = Path(os.environ['PASTA_LOTE']).expanduser() if os.environ.get('PASTA_LOTE') else Path(__file__).resolve().parent.parent
LISTA = BASE / 'lista_cnpjs.txt'
EMPRESAS = BASE / 'empresas.csv'
CONTROLE = BASE / 'Controle.json'
RFB = Path(os.environ['PASTA_SAIDA']).expanduser() if os.environ.get('PASTA_SAIDA') else BASE / 'resultado'
DOCUMENTO = 'Certidao Regularidade Fiscal RFB'
SUFIXOS_SOZINHOS = {'LTDA', 'ME', 'EPP', 'SA', 'S/A', 'EIRELI', 'MEI'}


def chave(doc):
    return re.sub(r'[^0-9A-Za-z]', '', doc).upper()


def dv(base):
    soma, peso = 0, len(base) - 7
    for c in base:
        soma += (ord(c) - 48) * peso
        peso -= 1
        if peso < 2:
            peso = 9
    resto = soma % 11
    return 0 if resto < 2 else 11 - resto


def cnpj_valido(c):
    if not re.fullmatch(r'[0-9A-Z]{12}\d{2}', c) or len(set(c)) == 1:
        return False
    d1 = dv(c[:12])
    return c[12] == str(d1) and c[13] == str(dv(c[:12] + str(d1)))


def formatar(c):
    return f'{c[:2]}.{c[2:5]}.{c[5:8]}/{c[8:12]}-{c[12:]}'


def eh_documento(campo):
    c = chave(campo)
    return len(c) in (11, 14) and bool(re.fullmatch(r'[0-9A-Z]+', c)) and bool(re.fullmatch(r'[0-9./\-A-Za-z]+', campo.strip()))


def ler_lista():
    """([(cnpj14, nome)], avisos, [(cpf, nome)]): CNPJs na ordem do documento, sem repetir; CPFs a parte (nao entram)."""
    if not LISTA.exists():
        sys.exit(f'Lista nao encontrada: {LISTA}')
    itens, vistos, avisos, cpfs = [], set(), [], []
    for n, linha in enumerate(LISTA.read_text(encoding='utf-8-sig').splitlines(), 1):
        if not linha.strip():
            continue
        campos = linha.split(';')
        # "Nome;CNPJ" (documento no ultimo campo) ou "CNPJ;Nome" (no primeiro)
        if len(campos) > 1 and eh_documento(campos[-1]):
            doc, nome = campos[-1], ';'.join(campos[:-1])
        elif eh_documento(campos[0]):
            doc, nome = campos[0], ';'.join(campos[1:])
        elif n == 1 and not re.search(r'\d', linha):
            continue  # cabecalho
        else:
            avisos.append(f'linha {n}: sem CNPJ valido ({linha.strip()[:60]})')
            continue
        c = chave(doc)
        if len(c) == 11:
            cpfs.append((c, nome.strip()))
            continue
        if not cnpj_valido(c):
            avisos.append(f'linha {n}: CNPJ invalido ({doc.strip()})')
            continue
        if c in vistos:
            avisos.append(f'linha {n}: CNPJ repetido ({doc.strip()}), ignorado')
            continue
        vistos.add(c)
        itens.append((c, nome.strip()))
    return itens, avisos, cpfs


def nome_cliente(nome):
    """Nome para o arquivo: sem caracteres proibidos; tira a raiz do CNPJ do comeco (MEI), se sobrar nome."""
    limpo = re.sub(r'\s+', ' ', re.sub(r'[\\/:*?"<>|]', ' ', nome)).strip()
    sem_raiz = re.sub(r'^\d{2}\.?\d{3}\.?\d{3}\s+', '', limpo)
    if sem_raiz != limpo and sem_raiz.upper().replace('.', '') not in SUFIXOS_SOZINHOS:
        limpo = sem_raiz
    return limpo.rstrip('. ')[:90]


def matriz_de(c):
    base = c[:8] + '0001'
    return base + str(dv(base)) + str(dv(base + str(dv(base))))


def preparar():
    itens, avisos, cpfs = ler_lista()
    raizes = {}
    for c, _ in itens:
        raizes.setdefault(c[:8], []).append(c)
    linhas, adicionadas, ja_feita = [], 0, set()
    for c, nome in itens:
        r = c[:8]
        if any(x[8:12] == '0001' for x in raizes[r]):
            linhas.append((c, nome or formatar(c)))  # a matriz esta na lista; o programa emite so ela e as filiais ficam "repetidas"
        elif r not in ja_feita:
            # So filiais na lista: o portal emite apenas para a matriz, entao pede-se a matriz (valida para a empresa toda).
            ja_feita.add(r)
            linhas.append((matriz_de(c), nome or formatar(matriz_de(c))))
            adicionadas += 1
    with open(EMPRESAS, 'w', encoding='utf-8-sig', newline='') as f:
        f.write('CNPJ;Empresa\r\n')
        for c, nome in linhas:
            f.write(f'{formatar(c)};{nome}\r\n')
    (BASE / 'lista_processada.json').write_text(json.dumps({'cnpjs': [{'cnpj': c, 'nome': n} for c, n in itens], 'cpfs': len(cpfs), 'avisos': avisos}, ensure_ascii=False), encoding='utf-8')
    RFB.mkdir(parents=True, exist_ok=True)
    for c, _ in itens:
        (RFB / c).mkdir(exist_ok=True)
    print(f'Lista: {len(itens)} CNPJs unicos, na ordem do documento')
    print(f'  {len(raizes)} emissoes (uma por empresa/raiz de CNPJ); {len(itens) - len(raizes) + adicionadas} CNPJs de filial cobertos pela certidao da matriz')
    if adicionadas:
        print(f'  {adicionadas} empresa(s) so tinham filial na lista: a matriz foi pedida no lugar')
    if cpfs:
        print(f'  {len(cpfs)} CPF(s) ignorados (pessoa fisica nao tem certidao de CNPJ); ficam na aba "Ignorados (CPF)" da planilha')
    for a in avisos:
        print('  AVISO', a)
    print(f'  Pastas: {RFB}/<CNPJ> ({len(itens)} criadas/conferidas)')
    print(f'  Lista do programa: {EMPRESAS}')


def carregar_controle():
    if not CONTROLE.exists():
        return {}
    return json.loads(CONTROLE.read_text(encoding='utf-8')).get('documentos', {})


def data_da(entrada):
    m = re.match(r'(\d{2})/(\d{2})/(\d{4})', entrada.get('processadoEm', '') or '')
    return f'{m[3]}-{m[2]}-{m[1]}' if m else datetime.now().strftime('%Y-%m-%d')


EM_ANALISE = 'PENDENTE - EM ANALISE PELA RECEITA FEDERAL'


def existentes(pasta, cnpj):
    return [p for p in pasta.iterdir() if p.is_file() and f' - {cnpj} - {DOCUMENTO}' in p.name]


def organizar():
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    from PIL import Image

    itens, avisos, cpfs = ler_lista()
    docs = carregar_controle()
    por_raiz = {k[:8]: v for k, v in docs.items()}
    linhas, contagem = [], Counter()
    for ordem, (c, nome) in enumerate(itens, 1):
        pasta = RFB / c
        pasta.mkdir(parents=True, exist_ok=True)
        e = por_raiz.get(c[:8])
        nome = nome or (e['nome'] if e and e.get('nome') else formatar(c))  # lista so com CNPJ: usa o nome que o programa leu na certidao
        tipo = 'Matriz' if c[8:12] == '0001' else 'Filial'
        emitida_por = formatar(e['chave']) if e else ''
        arquivo, motivo = '', ''
        if e and e['situacao'] == 'PDF salvo' and Path(e['pdf']).exists():
            sit, kind = 'Concluido - certidao baixada', 'valida'
        elif e and e['situacao'] == 'sem certidão' and Path(e['pdf']).exists():
            sit, kind = 'Concluido - sem certidao (print salvo)', 'invalida'
            motivo = e.get('mensagem', '')
        elif e and e['situacao'] == 'em análise':
            sit, kind, motivo = EM_ANALISE, None, e.get('mensagem', '')
        elif e and e['situacao'] == 'pulada':
            sit, kind, motivo = 'ERRO - sera refeita', None, e.get('mensagem', '')
        else:
            sit, kind = 'Pendente', None
        if kind:
            # sem nome na lista e sem nome lido da certidao: o nome do arquivo comeca pelo CNPJ
            cliente = '' if re.sub(r'[^0-9A-Za-z]', '', nome).upper() == c else nome_cliente(nome)
            base = ' - '.join(x for x in (cliente, c, DOCUMENTO, data_da(e)) if x) + '.pdf'
            achados = existentes(pasta, c)
            do_tipo = [p for p in achados if p.name.startswith(('IRREGULAR - ', 'INVALIDA - ')) == (kind == 'invalida')]
            if do_tipo:
                arquivo = do_tipo[0].name  # ja organizado: nao duplica
            else:
                if kind == 'valida':
                    for velho in achados:  # chegou a certidao valida: o print antigo sai da frente (nao e apagado)
                        (pasta / '_substituidos').mkdir(exist_ok=True)
                        shutil.move(str(velho), str(pasta / '_substituidos' / velho.name))
                    destino = pasta / base
                    shutil.copy2(e['pdf'], destino)
                else:
                    destino = pasta / f'IRREGULAR - {base}'
                    Image.open(e['pdf']).convert('RGB').save(destino, 'PDF', resolution=100.0)
                arquivo = destino.name
        contagem[sit] += 1
        linhas.append((ordem, formatar(c), nome, tipo, sit, arquivo, motivo, emitida_por if kind else '', e.get('processadoEm', '') if e else ''))

    wb = Workbook()
    ws = wb.active
    ws.title = 'Controle'
    ws.append(['Ordem', 'CNPJ', 'Empresa', 'Tipo', 'Situacao', 'Arquivo', 'Motivo / erro', 'Certidao emitida pelo CNPJ', 'Processado em'])
    cores = {'Concluido - certidao baixada': 'C6EFCE', 'Concluido - sem certidao (print salvo)': 'FFEB9C', 'ERRO - sera refeita': 'FFC7CE', EM_ANALISE: 'FCE4D6', 'Pendente': 'D9D9D9'}
    for cel in ws[1]:
        cel.font = Font(bold=True, color='FFFFFF')
        cel.fill = PatternFill('solid', fgColor='1F4E78')
        cel.alignment = Alignment(horizontal='center')
    for l in linhas:
        ws.append(l)
        ws.cell(ws.max_row, 5).fill = PatternFill('solid', fgColor=cores[l[4]])
    for col, w in zip('ABCDEFGHI', [8, 22, 52, 9, 38, 90, 50, 26, 22]):
        ws.column_dimensions[col].width = w
    ws.freeze_panes = 'A2'
    ws.auto_filter.ref = ws.dimensions
    res = wb.create_sheet('Resumo')
    res.append(['Situacao', 'CNPJs'])
    for k in cores:
        res.append([k, contagem.get(k, 0)])
    res.append(['Total', len(itens)])
    res.column_dimensions['A'].width = 42
    if cpfs:
        ign = wb.create_sheet('Ignorados (CPF)')
        ign.append(['CPF', 'Nome', 'Motivo'])
        for cpf, nome in cpfs:
            ign.append([f'{cpf[:3]}.{cpf[3:6]}.{cpf[6:9]}-{cpf[9:]}', nome, 'CPF: pessoa fisica, sem certidao de CNPJ'])
        ign.column_dimensions['A'].width = 18
        ign.column_dimensions['B'].width = 52
        ign.column_dimensions['C'].width = 42
    pend = [l for l in linhas if l[4] in ('ERRO - sera refeita', EM_ANALISE, 'Pendente')]
    arq_pend = RFB / 'Pendencias.csv'
    if pend:
        # Falha tecnica (erro 033 da Receita, site fora do ar...) NAO e irregularidade: so precisa de nova tentativa.
        pws = wb.create_sheet('Pendencias')
        pws.append(['CNPJ', 'Empresa', 'Situacao', 'Motivo'])
        for l in pend:
            pws.append([l[1], l[2], l[4], l[6] or 'Ainda nao processado'])
        for col, w in zip('ABCD', [22, 52, 24, 90]):
            pws.column_dimensions[col].width = w
        with open(arq_pend, 'w', encoding='utf-8-sig', newline='') as f:
            f.write('CNPJ;Empresa;Situacao;Motivo\r\n')
            for l in pend:
                f.write(';'.join(str(x).replace(';', ',') for x in (l[1], l[2], l[4], l[6] or 'Ainda nao processado')) + '\r\n')
    elif arq_pend.exists():
        arq_pend.unlink()
    wb.save(RFB / 'Controle_Certidoes.xlsx')

    print(f'Pasta de resultado organizada: {len(itens)} CNPJs ({len(cpfs)} CPFs ignorados)')
    for k in cores:
        print(f'  {k}: {contagem.get(k, 0)}')
    for a in avisos:
        print('  AVISO', a)
    erros = [l for l in linhas if l[4].startswith('ERRO')]
    for l in erros[:30]:
        print(f'  ERRO {l[1]} {l[2]}: {l[6]}')
    for l in [l for l in linhas if l[4] == EM_ANALISE][:30]:
        print(f'  EM ANALISE {l[1]} {l[2]}: ficou para a proxima execucao')
    if pend:
        print(f'  PENDENCIAS ({len(pend)}): {arq_pend}')
    print(f'  Controle: {RFB / "Controle_Certidoes.xlsx"}')


def contar_puladas():
    print(sum(1 for e in carregar_controle().values() if e['situacao'] == 'pulada'))


if __name__ == '__main__':
    comandos = {'preparar': preparar, 'organizar': organizar, 'contar-puladas': contar_puladas}
    if len(sys.argv) != 2 or sys.argv[1] not in comandos:
        sys.exit(__doc__)
    comandos[sys.argv[1]]()
