"""Lote da automacao RFB: prepara a lista e organiza os PDFs em resultado/<NOME DA EMPRESA>/ (ou na pasta indicada em PASTA_SAIDA).

Cada empresa tem uma pasta com o nome dela e o documento se chama "CNPJ;NOME DA EMPRESA.pdf" (sem certidao: "IRREGULAR - CNPJ;NOME DA EMPRESA.pdf").
Nomes iguais de empresas diferentes viram "NOME - CNPJ" para nunca misturar documentos; sem nome conhecido, a pasta e o documento usam so o CNPJ.

A lista (lista_cnpjs.txt) pode vir como "CNPJ;Nome" ou "Nome;CNPJ"; CPFs (pessoa fisica) sao ignorados: a certidao e so de CNPJ.

Uso (o iniciar.sh chama estes passos; da pra rodar a mao):
    python3 ferramentas/lote.py preparar         le lista_cnpjs.txt, gera empresas.csv e cria a pasta de cada empresa (pelo nome da lista)
    python3 ferramentas/lote.py organizar        copia os PDFs/prints de certidoes/ para a pasta de cada CNPJ e atualiza resultado/Controle_Certidoes.xlsx
    python3 ferramentas/lote.py contar-puladas   imprime quantas empresas estao com erro (puladas)

So copia: certidoes/, Controle.json e Relatorio.csv nunca sao alterados. Rodar de novo nao duplica nada.
Precisa de Pillow e openpyxl (pip install -r requirements.txt).
"""
import csv
import json
import os
import re
import shutil
import sys
import unicodedata
from collections import Counter
from datetime import datetime
from pathlib import Path

BASE = Path(os.environ['PASTA_LOTE']).expanduser() if os.environ.get('PASTA_LOTE') else Path(__file__).resolve().parent.parent
LISTA = BASE / 'lista_cnpjs.txt'
EMPRESAS = BASE / 'empresas.csv'
CONTROLE = BASE / 'Controle.json'
RFB = Path(os.environ['PASTA_SAIDA']).expanduser() if os.environ.get('PASTA_SAIDA') else BASE / 'resultado'
DOCUMENTO = 'Certidao Regularidade Fiscal RFB'
PASTAS = BASE / 'pastas.json'  # CNPJ -> pasta e nome usados; fixo depois de definido (retomar um lote nunca muda uma pasta)
# O nome da empresa entra duas vezes no caminho (pasta e arquivo): no Windows o caminho tem limite de 260 caracteres.
LIMITE_NOME = 60 if sys.platform == 'win32' else 90
RESERVADOS = {'CON', 'PRN', 'AUX', 'NUL', *(f'COM{i}' for i in range(1, 10)), *(f'LPT{i}' for i in range(1, 10))}


def chave(doc):
    return re.sub(r'[^0-9A-Za-z]', '', doc).upper()


def dv(base):
    soma, peso = 0, len(base) - 7
    for c in base:
        soma += (ord(c) - 48) * peso
        peso -= 1
        if peso < 2:
            peso = 9
    resto = soma % 11
    return 0 if resto < 2 else 11 - resto


def cnpj_valido(c):
    if not re.fullmatch(r'[0-9A-Z]{12}\d{2}', c) or len(set(c)) == 1:
        return False
    d1 = dv(c[:12])
    return c[12] == str(d1) and c[13] == str(dv(c[:12] + str(d1)))


def formatar(c):
    return f'{c[:2]}.{c[2:5]}.{c[5:8]}/{c[8:12]}-{c[12:]}'


def eh_documento(campo):
    c = chave(campo)
    return len(c) in (11, 14) and bool(re.fullmatch(r'[0-9A-Z]+', c)) and bool(re.fullmatch(r'[0-9./\-A-Za-z]+', campo.strip()))


def ler_lista():
    """([(cnpj14, nome)], avisos, [(cpf, nome)]): CNPJs na ordem do documento, sem repetir; CPFs a parte (nao entram)."""
    if not LISTA.exists():
        sys.exit(f'Lista nao encontrada: {LISTA}')
    itens, vistos, avisos, cpfs = [], set(), [], []
    for n, linha in enumerate(LISTA.read_text(encoding='utf-8-sig').splitlines(), 1):
        if not linha.strip():
            continue
        campos = linha.split(';')
        # "Nome;CNPJ" (documento no ultimo campo) ou "CNPJ;Nome" (no primeiro)
        if len(campos) > 1 and eh_documento(campos[-1]):
            doc, nome = campos[-1], ';'.join(campos[:-1])
        elif eh_documento(campos[0]):
            doc, nome = campos[0], ';'.join(campos[1:])
        elif n == 1 and not re.search(r'\d', linha):
            continue  # cabecalho
        else:
            avisos.append(f'linha {n}: sem CNPJ valido ({linha.strip()[:60]})')
            continue
        c = chave(doc)
        if len(c) == 11:
            cpfs.append((c, nome.strip()))
            continue
        if not cnpj_valido(c):
            avisos.append(f'linha {n}: CNPJ invalido ({doc.strip()})')
            continue
        if c in vistos:
            avisos.append(f'linha {n}: CNPJ repetido ({doc.strip()}), ignorado')
            continue
        vistos.add(c)
        itens.append((c, nome.strip()))
    return itens, avisos, cpfs


def nome_limpo(nome):
    """Nome da empresa para pasta e arquivo: so troca o que o sistema nao aceita (\\ / : * ? " < > | e controles, por espaco;
    ';' por ',' porque o ';' separa CNPJ e nome no arquivo); o resto do nome fica como esta. Sem ponto/espaco no fim."""
    limpo = re.sub(r'[\\/:*?"<>|\x00-\x1f]', ' ', nome or '').replace(';', ',')
    limpo = re.sub(r'\s+', ' ', limpo).strip().rstrip('. ')
    limpo = limpo[:LIMITE_NOME].rstrip('. ')
    return limpo + '_' if limpo.upper() in RESERVADOS else limpo


def nome_conhecido(nome, c):
    """False para nome vazio ou que e so o proprio CNPJ (o programa usa o CNPJ no lugar de um nome que a lista nao trouxe)."""
    n = (nome or '').strip()
    return bool(nome_limpo(n)) and re.sub(r'[^0-9A-Za-z]', '', n).upper() != c


def chave_pasta(nome):
    """Compara nomes de pasta como o disco compara (sem diferenciar maiusculas, acentos compostos ou nao)."""
    return unicodedata.normalize('NFC', nome).casefold()


def matriz_de(c):
    base = c[:8] + '0001'
    return base + str(dv(base)) + str(dv(base + str(dv(base))))


def preparar():
    itens, avisos, cpfs = ler_lista()
    raizes = {}
    for c, _ in itens:
        raizes.setdefault(c[:8], []).append(c)
    linhas, adicionadas, ja_feita = [], 0, set()
    for c, nome in itens:
        r = c[:8]
        if any(x[8:12] == '0001' for x in raizes[r]):
            linhas.append((c, nome or formatar(c)))  # a matriz esta na lista; o programa emite so ela e as filiais ficam "repetidas"
        elif r not in ja_feita:
            # So filiais na lista: o portal emite apenas para a matriz, entao pede-se a matriz (valida para a empresa toda).
            ja_feita.add(r)
            linhas.append((matriz_de(c), nome or formatar(matriz_de(c))))
            adicionadas += 1
    with open(EMPRESAS, 'w', encoding='utf-8-sig', newline='') as f:
        f.write('CNPJ;Empresa\r\n')
        for c, nome in linhas:
            f.write(f'{formatar(c)};{nome}\r\n')
    (BASE / 'lista_processada.json').write_text(json.dumps({'cnpjs': [{'cnpj': c, 'nome': n} for c, n in itens], 'cpfs': len(cpfs), 'avisos': avisos}, ensure_ascii=False), encoding='utf-8')
    RFB.mkdir(parents=True, exist_ok=True)
    mapa = atribuir_pastas(itens, carregar_controle())
    sem_nome = 0
    for c, _ in itens:
        if mapa[c].get('provisoria'):
            sem_nome += 1
        else:
            (RFB / mapa[c]['pasta']).mkdir(exist_ok=True)
    print(f'Lista: {len(itens)} CNPJs unicos, na ordem do documento')
    print(f'  {len(raizes)} emissoes (uma por empresa/raiz de CNPJ); {len(itens) - len(raizes) + adicionadas} CNPJs de filial cobertos pela certidao da matriz')
    if adicionadas:
        print(f'  {adicionadas} empresa(s) so tinham filial na lista: a matriz foi pedida no lugar')
    if cpfs:
        print(f'  {len(cpfs)} CPF(s) ignorados (pessoa fisica nao tem certidao de CNPJ); ficam na aba "Ignorados (CPF)" da planilha')
    for a in avisos:
        print('  AVISO', a)
    print(f'  Pastas: {RFB}/<NOME DA EMPRESA> ({len(itens) - sem_nome} criadas/conferidas)')
    if sem_nome:
        print(f'  {sem_nome} CNPJ(s) sem nome na lista: a pasta leva o nome lido da certidao; sem certidao, fica o proprio CNPJ (nenhum nome e inventado)')
    print(f'  Lista do programa: {EMPRESAS}')


def carregar_controle():
    if not CONTROLE.exists():
        return {}
    return json.loads(CONTROLE.read_text(encoding='utf-8')).get('documentos', {})


EM_ANALISE = 'PENDENTE - EM ANALISE PELA RECEITA FEDERAL'


def eh_irregular(nome_arquivo):
    return nome_arquivo.startswith(('IRREGULAR - ', 'INVALIDA - '))


def existentes(pasta, cnpj):
    """Documentos deste CNPJ na pasta: no formato novo (CNPJ;NOME.pdf, com ou sem IRREGULAR) e no antigo (NOME - CNPJ - Certidao...)."""
    novo = re.compile(rf'^(IRREGULAR - |INVALIDA - )?{cnpj}(;.*)?\.pdf$')
    return [p for p in pasta.iterdir() if p.is_file() and (novo.match(p.name) or f' - {cnpj} - {DOCUMENTO}' in p.name)]


def destino_livre(destino):
    """Nunca sobrescreve um arquivo que ja esta la: o novo ganha " (2)", " (3)"..."""
    candidato, n = destino, 2
    while candidato.exists():
        candidato = destino.with_name(f'{destino.stem} ({n}){destino.suffix}')
        n += 1
    return candidato


def carregar_pastas():
    try:
        return json.loads(PASTAS.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return {}


def nome_da_empresa(c, nome_lista, e):
    """Nome da lista; sem ele, o nome que o programa leu na certidao DESTA empresa (mesma raiz de CNPJ). Nunca outro nome."""
    if nome_conhecido(nome_lista, c):
        return nome_lista.strip()
    if e and nome_conhecido(e.get('nome'), e.get('chave', c)):
        return e['nome'].strip()
    return ''


def atribuir_pastas(itens, docs):
    """Define (uma vez so) a pasta de cada CNPJ e grava em pastas.json. Regras:
    - pasta = nome da empresa; nomes iguais (ou que so mudam em maiusculas/acentos) de CNPJs diferentes viram "NOME - CNPJ";
    - lote retomado: pasta ja definida nunca muda; um nome novo que repete uma pasta existente ganha o CNPJ;
    - sem nome conhecido: pasta provisoria = o CNPJ (passa para o nome quando a certidao trouxer o nome);
    - lote antigo com pasta <CNPJ> ja com documentos: continua nela (nada e movido nem duplicado)."""
    mapa = carregar_pastas()
    por_raiz = {k[:8]: v for k, v in docs.items()}
    no_disco = {chave_pasta(p.name) for p in RFB.iterdir() if p.is_dir()} if RFB.exists() else set()
    usados = {chave_pasta(m['pasta']): c for c, m in mapa.items()}
    novos = []
    for c, nome_lista in itens:
        nome = nome_da_empresa(c, nome_lista, por_raiz.get(c[:8]))
        m = mapa.get(c)
        if m and not (m.get('provisoria') and nome):
            continue
        novos.append((c, nome))
    repetidos = Counter(chave_pasta(nome_limpo(n)) for _, n in novos if n)
    for c, nome in novos:
        antigo = mapa.get(c)
        legado = RFB / c
        if not nome:
            mapa[c] = {'pasta': c, 'nome': '', 'provisoria': True}
            usados[chave_pasta(c)] = c
            continue
        base = nome_limpo(nome)
        if antigo is None and legado.is_dir() and any(legado.iterdir()):
            mapa[c] = {'pasta': c, 'nome': base, 'legado': True}
            usados[chave_pasta(c)] = c
            print(f'  Pasta antiga mantida: {c} (ja tinha documentos); os novos entram nela')
            continue
        k = chave_pasta(base)
        ocupada = (k in usados and usados[k] != c) or (k in no_disco and k not in usados) or repetidos[k] > 1
        pasta = f'{base} - {c}' if ocupada else base
        n = 2
        while chave_pasta(pasta) in usados and usados[chave_pasta(pasta)] != c:
            pasta = f'{base} - {c} ({n})'
            n += 1
        if antigo and antigo.get('provisoria') and (RFB / antigo['pasta']).is_dir() and not (RFB / pasta).exists():
            (RFB / antigo['pasta']).rename(RFB / pasta)  # o nome chegou depois: a pasta provisoria (so CNPJ) passa a ter o nome
        mapa[c] = {'pasta': pasta, 'nome': base}
        usados[chave_pasta(pasta)] = c
    for c, m in mapa.items():  # pasta antiga vazia, so com o CNPJ, que ficou para tras
        if m['pasta'] != c and (RFB / c).is_dir():
            try:
                (RFB / c).rmdir()
            except OSError:
                pass
    PASTAS.write_text(json.dumps(mapa, ensure_ascii=False, indent=1), encoding='utf-8')
    return mapa


def organizar():
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    from PIL import Image

    itens, avisos, cpfs = ler_lista()
    docs = carregar_controle()
    por_raiz = {k[:8]: v for k, v in docs.items()}
    mapa = atribuir_pastas(itens, docs)
    linhas, contagem = [], Counter()
    for ordem, (c, _) in enumerate(itens, 1):
        e = por_raiz.get(c[:8])
        nome = mapa[c]['nome']  # '' = sem nome conhecido: nada e inventado, o documento leva so o CNPJ
        pasta = RFB / mapa[c]['pasta']
        tipo = 'Matriz' if c[8:12] == '0001' else 'Filial'
        emitida_por = formatar(e['chave']) if e else ''
        arquivo, motivo = '', ''
        if e and e['situacao'] == 'PDF salvo' and Path(e['pdf']).exists():
            sit, kind = 'Concluido - certidao baixada', 'valida'
        elif e and e['situacao'] == 'sem certidão' and Path(e['pdf']).exists():
            sit, kind = 'Concluido - sem certidao (print salvo)', 'invalida'
            motivo = e.get('mensagem', '')
        elif e and e['situacao'] == 'em análise':
            sit, kind, motivo = EM_ANALISE, None, e.get('mensagem', '')
        elif e and e['situacao'] == 'pulada':
            sit, kind, motivo = 'ERRO - sera refeita', None, e.get('mensagem', '')
        else:
            sit, kind = 'Pendente', None
        if kind and e['chave'] not in Path(e['pdf']).name:
            # O arquivo de origem tem que ser da mesma empresa (mesma raiz de CNPJ): senao nao e salvo.
            sit, kind, motivo = 'ERRO - sera refeita', None, f'arquivo de origem nao confere com o CNPJ {e["chave"]}: {Path(e["pdf"]).name}'
        if kind or not mapa[c].get('provisoria'):
            pasta.mkdir(parents=True, exist_ok=True)
        if kind:
            base = f'{c};{nome}.pdf' if nome else f'{c}.pdf'
            achados = existentes(pasta, c)
            do_tipo = [p for p in achados if eh_irregular(p.name) == (kind == 'invalida')]
            if do_tipo:
                arquivo = do_tipo[0].name  # ja organizado: nao duplica
            else:
                if kind == 'valida':
                    for velho in achados:  # chegou a certidao valida: o print antigo sai da frente (nao e apagado)
                        (pasta / '_substituidos').mkdir(exist_ok=True)
                        shutil.move(str(velho), str(destino_livre(pasta / '_substituidos' / velho.name)))
                    destino = destino_livre(pasta / base)
                    shutil.copy2(e['pdf'], destino)
                else:
                    destino = destino_livre(pasta / f'IRREGULAR - {base}')
                    Image.open(e['pdf']).convert('RGB').save(destino, 'PDF', resolution=100.0)
                arquivo = destino.name
        contagem[sit] += 1
        linhas.append((ordem, formatar(c), nome or formatar(c), tipo, sit, arquivo, motivo, emitida_por if kind else '', e.get('processadoEm', '') if e else '', mapa[c]['pasta']))

    wb = Workbook()
    ws = wb.active
    ws.title = 'Controle'
    ws.append(['Ordem', 'CNPJ', 'Empresa', 'Tipo', 'Situacao', 'Arquivo', 'Motivo / erro', 'Certidao emitida pelo CNPJ', 'Processado em', 'Pasta'])
    cores = {'Concluido - certidao baixada': 'C6EFCE', 'Concluido - sem certidao (print salvo)': 'FFEB9C', 'ERRO - sera refeita': 'FFC7CE', EM_ANALISE: 'FCE4D6', 'Pendente': 'D9D9D9'}
    for cel in ws[1]:
        cel.font = Font(bold=True, color='FFFFFF')
        cel.fill = PatternFill('solid', fgColor='1F4E78')
        cel.alignment = Alignment(horizontal='center')
    for l in linhas:
        ws.append(l)
        ws.cell(ws.max_row, 5).fill = PatternFill('solid', fgColor=cores[l[4]])
    for col, w in zip('ABCDEFGHIJ', [8, 22, 52, 9, 38, 90, 50, 26, 22, 52]):
        ws.column_dimensions[col].width = w
    ws.freeze_panes = 'A2'
    ws.auto_filter.ref = ws.dimensions
    res = wb.create_sheet('Resumo')
    res.append(['Situacao', 'CNPJs'])
    for k in cores:
        res.append([k, contagem.get(k, 0)])
    res.append(['Total', len(itens)])
    res.column_dimensions['A'].width = 42
    if cpfs:
        ign = wb.create_sheet('Ignorados (CPF)')
        ign.append(['CPF', 'Nome', 'Motivo'])
        for cpf, nome in cpfs:
            ign.append([f'{cpf[:3]}.{cpf[3:6]}.{cpf[6:9]}-{cpf[9:]}', nome, 'CPF: pessoa fisica, sem certidao de CNPJ'])
        ign.column_dimensions['A'].width = 18
        ign.column_dimensions['B'].width = 52
        ign.column_dimensions['C'].width = 42
    pend = [l for l in linhas if l[4] in ('ERRO - sera refeita', EM_ANALISE, 'Pendente')]
    arq_pend = RFB / 'Pendencias.csv'
    if pend:
        # Falha tecnica (erro 033 da Receita, site fora do ar...) NAO e irregularidade: so precisa de nova tentativa.
        pws = wb.create_sheet('Pendencias')
        pws.append(['CNPJ', 'Empresa', 'Situacao', 'Motivo'])
        for l in pend:
            pws.append([l[1], l[2], l[4], l[6] or 'Ainda nao processado'])
        for col, w in zip('ABCD', [22, 52, 24, 90]):
            pws.column_dimensions[col].width = w
        with open(arq_pend, 'w', encoding='utf-8-sig', newline='') as f:
            f.write('CNPJ;Empresa;Situacao;Motivo\r\n')
            for l in pend:
                f.write(';'.join(str(x).replace(';', ',') for x in (l[1], l[2], l[4], l[6] or 'Ainda nao processado')) + '\r\n')
    elif arq_pend.exists():
        arq_pend.unlink()
    wb.save(RFB / 'Controle_Certidoes.xlsx')

    print(f'Pasta de resultado organizada: {len(itens)} CNPJs ({len(cpfs)} CPFs ignorados)')
    for k in cores:
        print(f'  {k}: {contagem.get(k, 0)}')
    for a in avisos:
        print('  AVISO', a)
    erros = [l for l in linhas if l[4].startswith('ERRO')]
    for l in erros[:30]:
        print(f'  ERRO {l[1]} {l[2]}: {l[6]}')
    for l in [l for l in linhas if l[4] == EM_ANALISE][:30]:
        print(f'  EM ANALISE {l[1]} {l[2]}: ficou para a proxima execucao')
    if pend:
        print(f'  PENDENCIAS ({len(pend)}): {arq_pend}')
    print(f'  Controle: {RFB / "Controle_Certidoes.xlsx"}')


def contar_puladas():
    print(sum(1 for e in carregar_controle().values() if e['situacao'] == 'pulada'))


if __name__ == '__main__':
    comandos = {'preparar': preparar, 'organizar': organizar, 'contar-puladas': contar_puladas}
    if len(sys.argv) != 2 or sys.argv[1] not in comandos:
        sys.exit(__doc__)
    comandos[sys.argv[1]]()
