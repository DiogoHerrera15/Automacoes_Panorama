#!/bin/bash
# Executa a automacao RFB: le lista_cnpjs.txt, emite as certidoes da Receita, refaz uma vez as que
# deram erro e organiza tudo em resultado/<CNPJ>/. Rode no Terminal, dentro desta pasta:
#   bash iniciar.sh              lote completo (continua de onde parou, sem baixar nada em duplicidade)
#   bash iniciar.sh --teste      so 2 empresas, para conferir que esta tudo funcionando
#   bash iniciar.sh --verificar  so confere a lista (nao abre o site)
#   bash iniciar.sh --organizar  so reorganiza o que ja foi emitido (nao abre o site)
#   bash iniciar.sh --novo-lote  guarda o lote atual em lotes_anteriores/ para comecar uma lista nova
# Parar: digite s e Enter (o que ja foi emitido fica salvo).
# Variaveis opcionais: LIMITE=n  PAUSA_SEGUNDOS=n (padrao 15)  TEMPO_MAX_EMPRESA_MIN=n (padrao 8)  PASTA_SAIDA=/outra/pasta
cd "$(dirname "$0")" || exit 1
export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"
export TEMPO_MAX_EMPRESA_MIN="${TEMPO_MAX_EMPRESA_MIN:-8}"   # minutos por tentativa; estourou 2 vezes = erro e segue

fim() { echo; if [ -t 0 ]; then read -n 1 -s -r -p "Aperte qualquer tecla para fechar..."; echo; fi; exit "${1:-0}"; }

PY=.venv/bin/python3
[ -x "$PY" ] || PY=python3

case "$1" in
  -h|--ajuda|--help) sed -n '2,10p' iniciar.sh | sed 's/^# \{0,1\}//'; exit 0 ;;
  --novo-lote)
    destino="lotes_anteriores/$(date +%Y-%m-%d_%H%M)"
    echo "Isto guarda o lote atual em $destino/ (nada e apagado) e deixa a pasta pronta para uma lista nova."
    read -r -p "Continuar? (s/N) " r; [ "$r" = s ] || [ "$r" = S ] || { echo "Cancelado."; exit 0; }
    mkdir -p "$destino"
    for item in Controle.json Relatorio.csv empresas.csv certidoes resultado lista_cnpjs.txt; do
      [ -e "$item" ] && mv "$item" "$destino/"
    done
    echo "Pronto. Coloque a nova lista em lista_cnpjs.txt e rode: bash iniciar.sh"
    exit 0 ;;
esac

echo "Automacao RFB - certidoes da Receita Federal"
command -v node >/dev/null 2>&1 || { echo "Node.js nao encontrado. Rode primeiro: bash instalar.sh"; fim 1; }
[ -d node_modules ] || { echo "Dependencias nao instaladas. Rode primeiro: bash instalar.sh"; fim 1; }
"$PY" -c "import PIL, openpyxl" 2>/dev/null || { echo "Falta Pillow/openpyxl. Rode primeiro: bash instalar.sh"; fim 1; }
[ -f lista_cnpjs.txt ] || { echo "Nao achei lista_cnpjs.txt nesta pasta. Veja lista_cnpjs.exemplo.txt e o README."; fim 1; }

echo; echo "1/4 Lendo a lista e criando as pastas..."
"$PY" ferramentas/lote.py preparar || fim 1

case "$1" in
  --verificar) node certidao-rfb.js --verificar; fim $? ;;
  --organizar) "$PY" ferramentas/lote.py organizar; fim $? ;;
  --teste) export LIMITE="${LIMITE:-2}"; echo; echo "MODO TESTE: so $LIMITE empresas." ;;
  "") ;;
  *) echo "Opcao desconhecida: $1 (veja: bash iniciar.sh --ajuda)"; fim 1 ;;
esac

echo; echo "2/4 Emitindo as certidoes (em cada aba o CNPJ entra sozinho; para parar: s e Enter)..."
node certidao-rfb.js
codigo=$?
if [ $codigo -ne 0 ]; then
  echo; echo "Execucao interrompida (codigo $codigo). Organizando o que ja foi feito..."
  "$PY" ferramentas/lote.py organizar
  echo "Rode  bash iniciar.sh  de novo para continuar."
  fim $codigo
fi

erros=$("$PY" ferramentas/lote.py contar-puladas)
if [ "${erros:-0}" -gt 0 ]; then
  echo; echo "3/4 $erros empresa(s) com erro: tentando de novo uma vez..."
  node certidao-rfb.js --refazer-puladas || true
else
  echo; echo "3/4 Nenhum erro para refazer."
fi

echo; echo "4/4 Organizando os arquivos..."
"$PY" ferramentas/lote.py organizar
echo; echo "Pronto. Resultado em: ${PASTA_SAIDA:-$PWD/resultado}  (planilha Controle_Certidoes.xlsx dentro)"
fim 0
