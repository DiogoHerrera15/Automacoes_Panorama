#!/bin/bash
# Abre a INTERFACE RFB EMISSAO (painel de controle da automacao). Dois cliques neste arquivo,
# ou no Terminal:  bash "INTERFACE RFB EMISSAO.command"
# Deixe esta janela aberta enquanto usa a interface. Para encerrar: Ctrl+C.
cd "$(dirname "$0")" || exit 1
export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"

if [ ! -d node_modules ] || [ ! -x .venv/bin/python3 ]; then
  echo "Primeira vez neste Mac: instalando o que falta (precisa de internet)..."
  bash instalar.sh < /dev/null || { echo; read -n 1 -s -r -p "Algo faltou. Veja a mensagem acima. Aperte uma tecla para fechar..."; exit 1; }
  echo
fi
command -v node >/dev/null 2>&1 || { echo "Node.js nao encontrado. Rode: bash instalar.sh"; read -n 1 -s -r -p "Aperte uma tecla..."; exit 1; }

node interface/servidor.js
