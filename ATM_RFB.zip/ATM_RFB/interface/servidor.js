// INTERFACE RFB EMISSÃO: painel de controle (no navegador) da automação certidao-rfb.js.
// Não reimplementa nada: grava a lista, chama os mesmos passos do iniciar.sh (lote.py preparar ->
// certidao-rfb.js -> refazer erros -> lote.py organizar) e mostra o andamento lendo a saída do
// programa e o Controle.json do lote. Só atende neste computador (127.0.0.1).
import { spawn, spawnSync } from 'node:child_process';
import fs from 'node:fs';
import http from 'node:http';
import os from 'node:os';
import path from 'node:path';
import readline from 'node:readline';
import { fileURLToPath } from 'node:url';

const RAIZ = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const PORTA = Number(process.env.PORTA_INTERFACE ?? 47330);
const ARQ_CONFIG = path.join(RAIZ, 'interface', 'config.json');
const PY = fs.existsSync(path.join(RAIZ, '.venv', 'bin', 'python3')) ? path.join(RAIZ, '.venv', 'bin', 'python3') : 'python3';

// ---------- configuração (pasta principal dos lotes) ----------
const PADRAO = { pastaPrincipal: path.join(os.homedir(), 'Downloads'), pausaSegundos: 15 };
function lerConfig() {
  let c = {};
  try { c = JSON.parse(fs.readFileSync(ARQ_CONFIG, 'utf8')); } catch { /* sem config ainda */ }
  const cfg = { ...PADRAO, ...c };
  if (process.env.PASTA_PRINCIPAL) cfg.pastaPrincipal = process.env.PASTA_PRINCIPAL;
  return cfg;
}
function gravarConfig(c) {
  fs.writeFileSync(ARQ_CONFIG, JSON.stringify({ pastaPrincipal: c.pastaPrincipal, pausaSegundos: c.pausaSegundos }, null, 2));
}

// ---------- estado da execução ----------
const run = novo();
function novo() {
  return { fase: 'ocioso', etapa: '', nome: '', dir: '', ctrl: '', inicio: 0, fim: 0, atual: null, extensao: false, pausado: false, pedidoPausa: false, parando: false, resumo: null, erro: '', filho: null, lista: null };
}
const logs = [];
let seq = 0;
function log(texto, nivel = 'info') {
  logs.push({ n: ++seq, h: new Date().toLocaleTimeString('pt-BR'), nivel, texto });
  if (logs.length > 5000) logs.splice(0, 1000);
}

// ---------- validação ----------
const chaveDoc = (d) => d.replace(/[^0-9A-Za-z]/g, '').toUpperCase();
function nomeDePastaValido(nome) {
  return /^[\p{L}\p{N}][\p{L}\p{N} ._()\-]{0,79}$/u.test(nome) && !nome.includes('..') && !/[ .]$/.test(nome);
}

// ---------- processos ----------
function semAnsi(s) { return s.replace(/\x1b\[[0-9;]*[A-Za-z]/g, ''); }

function rodar(cmd, args, env, aoLinha, { stdin = false } = {}) {
  return new Promise((resolve) => {
    const f = spawn(cmd, args, { cwd: RAIZ, env: { ...process.env, ...env }, stdio: ['pipe', 'pipe', 'pipe'] });
    if (stdin) run.filho = f; else f.stdin.end();
    f.stdin.on('error', () => {});
    for (const fluxo of [f.stdout, f.stderr]) {
      readline.createInterface({ input: fluxo }).on('line', (l) => aoLinha(semAnsi(l).replace(/\s+$/, '')));
    }
    f.on('error', (e) => { log(`Não consegui executar ${cmd}: ${e.message}`, 'erro'); resolve(-1); });
    f.on('close', (codigo) => { if (run.filho === f) run.filho = null; resolve(codigo ?? -1); });
  });
}

const RUIDO = [/^=+$/, /Na aba nova do Chrome o CNPJ entra sozinho/, /Se aparecer "Não foi possível/, /Comandos: c = copiar/, /^\s*CNPJ \S+ copiado\.$/];
function linhaDoPrograma(l) {
  const m = l.match(/^\s*EMPRESA:\s*(.+)$/);
  if (m) { run.atual = { nome: m[1].trim(), cnpj: '' }; return; }
  const c = l.match(/^\s*CNPJ (\S+) copiado\.$/);
  if (c && run.atual) run.atual.cnpj = c[1];
  if (/extensão conectada/.test(l)) run.extensao = true;
  if (/^\s*PAUSADO\./.test(l)) { run.pausado = true; log('Pausado. A automação aguarda para continuar.', 'aviso'); return; }
  if (/^\s*Retomando/.test(l)) { run.pausado = false; run.pedidoPausa = false; log('Retomando.', 'ok'); return; }
  if (!l.trim() || RUIDO.some((r) => r.test(l))) {
    if (c && run.atual) log(`Processando ${run.atual.nome} (${c[1]})`, 'info');
    return;
  }
  const nivel = /ERRO|não foi possível|inválid/i.test(l) ? 'erro' : /ATENÇÃO|AVISO/.test(l) ? 'aviso' : /^\s*(Salvo|Print da tela salvo):/.test(l) ? 'ok' : 'info';
  log(l.trim(), nivel);
}
function linhaGenerica(l) {
  if (l.trim()) log(l.trim(), /ERRO/.test(l) ? 'erro' : /AVISO/.test(l) ? 'aviso' : 'info');
}

// ---------- leitura do andamento ----------
function lerJson(arq) {
  try { return JSON.parse(fs.readFileSync(arq, 'utf8')); } catch { return null; }
}
function contagem() {
  const lista = run.lista ?? (run.ctrl ? lerJson(path.join(run.ctrl, 'lista_processada.json')) : null);
  const total = lista?.cnpjs?.length ?? 0;
  const c = { total, processados: 0, emitidas: 0, semCertidao: 0, pendentes: 0, emAnalise: 0, erros: 0, cpfs: lista?.cpfs ?? 0, emissoes: 0 };
  if (!lista) return c;
  const docs = lerJson(path.join(run.ctrl, 'Controle.json'))?.documentos ?? {};
  const porRaiz = {};
  for (const [k, v] of Object.entries(docs)) porRaiz[k.slice(0, 8)] = v;
  c.emissoes = new Set(lista.cnpjs.map((x) => x.cnpj.slice(0, 8))).size;
  for (const x of lista.cnpjs) {
    const sit = porRaiz[x.cnpj.slice(0, 8)]?.situacao;
    if (sit === 'PDF salvo') c.emitidas++;
    else if (sit === 'sem certidão') c.semCertidao++;
    else if (sit === 'pulada') c.erros++;
    else if (sit === 'em análise') { c.pendentes++; c.emAnalise++; }
    else c.pendentes++;
  }
  c.processados = c.emitidas + c.semCertidao;
  return c;
}
function listaDeProblemas() {
  const docs = lerJson(path.join(run.ctrl, 'Controle.json'))?.documentos ?? {};
  return Object.values(docs).filter((e) => e.situacao === 'pulada' || e.situacao === 'em análise')
    .map((e) => ({ cnpj: e.documento, nome: e.nome, motivo: e.situacao === 'em análise' ? `EM ANÁLISE PELA RECEITA: ${e.mensagem}` : e.mensagem }));
}
// Só as puladas por erro têm repetição automática no fim do lote; "em análise" fica para a próxima execução.
function contarPuladas() {
  const docs = lerJson(path.join(run.ctrl, 'Controle.json'))?.documentos ?? {};
  return Object.values(docs).filter((e) => e.situacao === 'pulada').length;
}

// ---------- orquestração (os mesmos passos do iniciar.sh) ----------
function ambiente() {
  return { PASTA_LOTE: run.ctrl, PASTA_SAIDA: run.dir, PAUSA_SEGUNDOS: String(lerConfig().pausaSegundos), TEMPO_MAX_EMPRESA_MIN: process.env.TEMPO_MAX_EMPRESA_MIN ?? '5' };
}
async function executar(nome, cnpjsTexto) {
  const cfg = lerConfig();
  Object.assign(run, novo(), { fase: 'preparando', etapa: 'Preparando a pasta e a lista', nome, dir: path.join(cfg.pastaPrincipal, nome), inicio: Date.now() });
  run.ctrl = path.join(run.dir, '_controle');
  try {
    fs.mkdirSync(run.ctrl, { recursive: true });
    fs.rmSync(path.join(run.ctrl, 'PAUSAR'), { force: true });
    fs.writeFileSync(path.join(run.ctrl, 'lista_cnpjs.txt'), `﻿CNPJ;Nome\r\n${cnpjsTexto.replace(/\r?\n/g, '\r\n')}\r\n`);
    log(`Pasta do lote: ${run.dir}`, 'info');
    if ((await rodar(PY, ['ferramentas/lote.py', 'preparar'], ambiente(), linhaGenerica)) !== 0) throw new Error('Não consegui ler a lista de CNPJs.');
    run.lista = lerJson(path.join(run.ctrl, 'lista_processada.json'));
    if (!run.lista?.cnpjs?.length) throw new Error('Nenhum CNPJ válido na lista.');

    let codigo = 3;
    if (!run.parando) {
      run.fase = 'rodando';
      run.etapa = 'Emitindo as certidões';
      codigo = await rodar('node', ['certidao-rfb.js'], ambiente(), linhaDoPrograma, { stdin: true });
      run.atual = null;
    }
    if (codigo === 0 && !run.parando) {
      const puladas = contarPuladas();
      if (puladas > 0) {
        run.etapa = `Tentando de novo ${puladas} com erro`;
        log(`${puladas} CNPJ(s) com erro: tentando de novo uma vez.`, 'aviso');
        codigo = await rodar('node', ['certidao-rfb.js', '--refazer-puladas'], ambiente(), linhaDoPrograma, { stdin: true });
        run.atual = null;
      }
    }
    run.fase = 'organizando';
    run.etapa = 'Organizando os arquivos';
    await rodar(PY, ['ferramentas/lote.py', 'organizar'], ambiente(), linhaGenerica);
    run.fase = run.parando || codigo === 3 ? 'parado' : codigo === 0 ? 'finalizado' : 'erro';
    if (run.fase === 'erro') run.erro = 'A automação terminou com erro. Veja o painel de logs.';
  } catch (e) {
    run.fase = 'erro';
    run.erro = e.message;
    log(e.message, 'erro');
  }
  run.fim = Date.now();
  run.etapa = '';
  run.pausado = false;
  run.pedidoPausa = false;
  run.atual = null;
  const c = contagem();
  run.resumo = { ...c, problemas: listaDeProblemas(), duracaoSeg: Math.round((run.fim - run.inicio) / 1000), pasta: run.dir, planilha: path.join(run.dir, 'Controle_Certidoes.xlsx') };
  log(run.fase === 'finalizado' ? 'Execução concluída.' : run.fase === 'parado' ? 'Execução parada. Rode de novo com o mesmo nome de pasta para continuar.' : 'Execução encerrada com erro.', run.fase === 'finalizado' ? 'ok' : 'aviso');
}

const ocupado = () => ['preparando', 'rodando', 'organizando'].includes(run.fase);

function pausar() {
  if (run.fase !== 'rodando' || run.pedidoPausa) return false;
  fs.writeFileSync(path.join(run.ctrl, 'PAUSAR'), 'pausar\n');
  run.pedidoPausa = true;
  log('Pausa pedida: a empresa em andamento termina e a automação para antes da próxima.', 'aviso');
  return true;
}
function continuar() {
  if (!run.pedidoPausa) return false;
  fs.rmSync(path.join(run.ctrl, 'PAUSAR'), { force: true });
  if (!run.pausado) { run.pedidoPausa = false; log('Pausa cancelada.', 'ok'); }
  return true;
}
function parar() {
  if (!ocupado() || run.parando) return false;
  run.parando = true;
  log('Parando com segurança: o andamento fica salvo.', 'aviso');
  fs.rmSync(path.join(run.ctrl, 'PAUSAR'), { force: true });
  if (run.filho) {
    run.filho.stdin.write('s\n');
    const f = run.filho;
    setTimeout(() => { if (run.filho === f) { log('Encerrando o processo (o andamento já está salvo).', 'aviso'); f.kill('SIGTERM'); } }, 90000);
  }
  return true;
}

// ---------- API ----------
function verificarAmbiente() {
  const falta = [];
  if (!fs.existsSync(path.join(RAIZ, 'node_modules', 'pdfjs-dist'))) falta.push('dependências do Node');
  if (spawnSync(PY, ['-c', 'import PIL, openpyxl']).status !== 0) falta.push('Pillow/openpyxl (Python)');
  if (!fs.existsSync('/Applications/Google Chrome.app')) falta.push('Google Chrome');
  return falta;
}
function estado(desde) {
  const cfg = lerConfig();
  return {
    fase: run.fase, etapa: run.etapa, nome: run.nome, pasta: run.dir, atual: run.atual, extensao: run.extensao,
    pausado: run.pausado, pedidoPausa: run.pedidoPausa, parando: run.parando, erro: run.erro,
    inicio: run.inicio, fim: run.fim, contagem: contagem(), resumo: run.resumo,
    config: cfg, logs: logs.filter((x) => x.n > desde), seq,
  };
}
function loteExistente(nome) {
  const dir = path.join(lerConfig().pastaPrincipal, nome);
  if (!fs.existsSync(dir)) return { existe: false };
  const docs = lerJson(path.join(dir, '_controle', 'Controle.json'))?.documentos ?? {};
  const feitas = Object.values(docs).filter((e) => e.situacao === 'PDF salvo' || e.situacao === 'sem certidão').length;
  return { existe: true, retoma: Object.keys(docs).length > 0, feitas, total: Object.keys(docs).length };
}

function corpo(req) {
  return new Promise((resolve, reject) => {
    let d = '';
    req.on('data', (c) => { d += c; if (d.length > 2e6) { reject(new Error('Lista grande demais')); req.destroy(); } });
    req.on('end', () => { try { resolve(d ? JSON.parse(d) : {}); } catch (e) { reject(e); } });
  });
}
function responder(res, codigo, obj) {
  const texto = JSON.stringify(obj);
  res.writeHead(codigo, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(texto);
}

const servidor = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  // Só aceita a própria página (evita que um site qualquer mande comandos para esta porta).
  if (!/^(127\.0\.0\.1|localhost):\d+$/.test(req.headers.host ?? '')) { res.writeHead(403); return res.end(); }
  try {
    if (req.method === 'GET' && (url.pathname === '/' || url.pathname === '/index.html')) {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
      return res.end(fs.readFileSync(path.join(RAIZ, 'interface', 'index.html')));
    }
    if (req.method === 'GET' && url.pathname === '/api/estado') return responder(res, 200, estado(Number(url.searchParams.get('desde') ?? 0)));
    if (req.method === 'GET' && url.pathname === '/api/ambiente') return responder(res, 200, { falta: verificarAmbiente() });
    if (req.method === 'GET' && url.pathname === '/api/lote') {
      const nome = (url.searchParams.get('nome') ?? '').trim();
      return responder(res, 200, nomeDePastaValido(nome) ? loteExistente(nome) : { existe: false });
    }
    if (req.method === 'POST') {
      if (req.headers['x-interface'] !== 'rfb') return responder(res, 403, { erro: 'Pedido não autorizado.' });
      const b = await corpo(req);
      if (url.pathname === '/api/iniciar') {
        if (ocupado()) return responder(res, 409, { erro: 'Já há uma execução em andamento.' });
        const nome = String(b.nome ?? '').trim();
        if (!nomeDePastaValido(nome)) return responder(res, 400, { erro: 'Nome de pasta inválido. Use letras, números, espaço, ponto, hífen, sublinhado ou parênteses.' });
        const texto = String(b.cnpjs ?? '').split(/\r?\n/).map((l) => l.trim()).filter(Boolean).join('\n');
        if (!texto) return responder(res, 400, { erro: 'Cole pelo menos um CNPJ.' });
        const falta = verificarAmbiente();
        if (falta.length) return responder(res, 400, { erro: `Falta instalar: ${falta.join(', ')}. Rode "bash instalar.sh" na pasta do projeto.` });
        executar(nome, texto);
        return responder(res, 200, { ok: true });
      }
      if (url.pathname === '/api/pausar') return responder(res, 200, { ok: pausar() });
      if (url.pathname === '/api/continuar') return responder(res, 200, { ok: continuar() });
      if (url.pathname === '/api/parar') return responder(res, 200, { ok: parar() });
      if (url.pathname === '/api/nova') {
        if (ocupado()) return responder(res, 409, { erro: 'Aguarde terminar.' });
        Object.assign(run, novo());
        return responder(res, 200, { ok: true });
      }
      if (url.pathname === '/api/abrir') {
        if (run.dir && fs.existsSync(run.dir)) spawn('open', [run.dir], { detached: true, stdio: 'ignore' }).unref();
        return responder(res, 200, { ok: true });
      }
      if (url.pathname === '/api/config') {
        if (ocupado()) return responder(res, 409, { erro: 'Aguarde terminar a execução.' });
        const cfg = lerConfig();
        if (b.pastaPrincipal !== undefined) {
          const p = path.resolve(String(b.pastaPrincipal).replace(/^~(?=\/|$)/, os.homedir()));
          if (!fs.existsSync(p) || !fs.statSync(p).isDirectory()) return responder(res, 400, { erro: 'Essa pasta não existe.' });
          cfg.pastaPrincipal = p;
        }
        if (b.pausaSegundos !== undefined) cfg.pausaSegundos = Math.max(0, Math.min(300, Number(b.pausaSegundos) || 0));
        gravarConfig(cfg);
        return responder(res, 200, { ok: true });
      }
    }
    res.writeHead(404);
    res.end();
  } catch (e) {
    responder(res, 500, { erro: e.message });
  }
});

servidor.on('error', (e) => {
  if (e.code === 'EADDRINUSE') {
    console.log(`A INTERFACE RFB EMISSÃO já está aberta (porta ${PORTA}). Abrindo a janela...`);
    abrirJanela();
    process.exit(0);
  }
  throw e;
});

function abrirJanela() {
  if (process.env.NAO_ABRIR === '1') return;
  const url = `http://127.0.0.1:${PORTA}`;
  const chrome = '/Applications/Google Chrome.app';
  // Janela própria, sem barra de endereço, no Chrome (-n: abre mesmo com o Chrome já aberto).
  const args = fs.existsSync(chrome) ? ['-na', 'Google Chrome', '--args', `--app=${url}`, '--window-size=1240,860'] : [url];
  spawn('open', args, { detached: true, stdio: 'ignore' }).unref();
}

servidor.listen(PORTA, '127.0.0.1', () => {
  console.log(`INTERFACE RFB EMISSÃO aberta em http://127.0.0.1:${PORTA}`);
  console.log('Deixe esta janela do Terminal aberta enquanto usa a interface. Para encerrar: Ctrl+C.');
  abrirJanela();
});

// Ctrl+C / fechar o Terminal: para a automação com segurança (o andamento já está salvo a cada empresa).
function encerrar() {
  if (ocupado() && run.filho) { try { run.filho.stdin.write('s\n'); } catch { /* sem stdin */ } }
  setTimeout(() => process.exit(0), 1500);
}
process.on('SIGINT', encerrar);
process.on('SIGTERM', encerrar);
