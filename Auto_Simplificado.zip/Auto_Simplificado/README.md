# Auto_Simplificado: automação do Parcelamento Simplificado (e-CAC)

Extensão do Google Chrome que, para cada empresa de uma lista, troca o perfil de acesso do e-CAC para o CNPJ da empresa
(perfil "Procurador de pessoa jurídica"), consulta o **Parcelamento Simplificado** e guarda em PDF o resultado da
consulta ou o DARF emitido.

Versão: **1.7.8**. Esta pasta tem **só a automação**, pronta para ser usada com qualquer lista de CNPJs. Não há dados de
nenhuma empresa aqui: a lista é um modelo com CNPJs fictícios.

---

## 1. O que tem nesta pasta

```
Auto_Simplificado/
├── README.md                      Este documento
└── parcelamento_simplificado/     A extensão. É esta pasta que o Chrome carrega
    ├── manifest.json              Versão, permissões e onde a extensão roda
    ├── lista_cnpjs.js             A lista de empresas e as configurações. É o arquivo que você edita
    ├── content.js                 Todo o fluxo da automação (roda dentro das páginas do e-CAC)
    └── background.js              Salva os PDFs e faz a ponte entre as partes da página
```

Não precisa instalar nada além do Chrome (sem Python, Node ou bibliotecas).

---

## 2. Como usar com uma lista nova (passo a passo)

1. Abra `parcelamento_simplificado\lista_cnpjs.js` num editor de texto (Bloco de Notas serve).
2. Troque `LISTA_CNPJS` pelas suas empresas, uma por linha, no formato
   `{ nome: 'NOME DA EMPRESA', cnpj: '12345678000190' },` (CNPJ só com os 14 dígitos, sem pontos, barra ou traço).
3. Troque o `ID_LOTE` por um nome novo (por exemplo `cliente-x-2026-12`). **Isso zera o andamento** do lote anterior.
4. Troque `PASTA_SEM_NEGOCIACAO` e `PASTA_COM_NEGOCIACAO` por pastas novas, para não misturar PDFs de lotes diferentes.
5. Deixe `JA_CONCLUIDAS`, `PULAR_CNPJS` e `COM_ERRO_INICIAL` vazias (`[]`), a não ser que precise delas (seção 5).
6. Salve o arquivo e instale/recarregue a extensão (seção 3).
7. Entre no e-CAC e comece (seção 4).

---

## 3. Como instalar a extensão no Chrome

1. Abra o Chrome e digite `chrome://extensions` na barra de endereço.
2. Ligue o **Modo do desenvolvedor** (canto superior direito).
3. Clique em **Carregar sem compactação** e escolha a pasta **`parcelamento_simplificado`** (a que contém o
   `manifest.json`, não a `Auto_Simplificado`).
4. Confira no cartão: nome `parcelamento_simplificado` e a versão (1.7.8).
5. Se for usar **janela anônima**: no cartão, **Detalhes > Permitir no modo anônimo**. Cada instalação nova começa com
   essa opção desligada.
6. Em **Detalhes > Origem**, confira que aponta para a pasta certa.

Cuidados:
- **Deixe só UMA cópia da extensão ligada.** Duas cópias juntas clicam em duplicidade na mesma tela.
- **O andamento fica guardado dentro do Chrome, por instalação.** Remover a extensão, ou carregá-la de outra pasta, apaga o
  andamento. Para aplicar mudanças nos arquivos, use só a **setinha de recarregar** no cartão da extensão.
- Depois de **qualquer mudança nos arquivos**: recarregue a extensão, aperte **F5** na aba do e-CAC (a página aberta
  continua com a versão antiga) e clique no ícone.

---

## 4. Como rodar

1. Entre no e-CAC como de costume (certificado digital ou gov.br). A extensão **nunca digita login nem senha**.
2. Deixe aberta a **tela inicial do Parcelamento** (Pagamento e Parcelamento > Parcelamento - Solicitar e acompanhar),
   com a aba em primeiro plano.
3. Inicie de um destes jeitos:
   - aperte **F5** nessa tela (começa sozinha), ou
   - clique no **ícone da extensão** (retoma de onde parou e também tenta de novo as empresas com erro do sistema).
4. Acompanhe pelo **aviso no canto superior direito**, que mostra a empresa e quantas faltam
   (ex.: `CNPJ 3 de 33 · faltam 30 · negociação 2 de 4`). Se parar, o aviso diz o motivo e a empresa continua pendente.
5. Não mexa na aba do e-CAC enquanto ela trabalha e não a deixe em segundo plano (o print da tela exige a aba à frente).

Antes de rodar de verdade, confira o aviso: ele mostra o **total de empresas**. Se mostrar "2 CNPJs" e CNPJs `0000...`,
o Chrome está carregando o modelo sem a sua lista.

---

## 5. Configurações (`lista_cnpjs.js`)

| Constante | Para que serve |
|---|---|
| `ID_LOTE` | Nome do lote. **Mudar o texto zera o andamento** e recomeça a lista. |
| `LISTA_CNPJS` | As empresas (`nome` e `cnpj`), na ordem de processamento. |
| `PASTA_SEM_NEGOCIACAO`, `PASTA_COM_NEGOCIACAO` | Subpastas de **Downloads** onde cada tipo de PDF é salvo. |
| `SITUACOES_PROCESSAR` | Situações da negociação em que emite o DARF (padrão: `Ativo` e `Requerimento em análise`). As outras, como rescindida e liquidada, são puladas e anotadas. |
| `DEVEDORAS_QUALQUER_MES` | `true`: marca todas as parcelas "Devedora". `false`: só as do mês atual/anterior. (As "A vencer" são sempre só do mês atual e do mês anterior.) |
| `JA_CONCLUIDAS` | CNPJs que contam como feitos mesmo que o Chrome tenha perdido o andamento (extensão removida ou carregada de outra pasta). Para refazer uma empresa, apague o CNPJ daqui. |
| `PULAR_CNPJS` | CNPJs ignorados. |
| `COM_ERRO_INICIAL` | CNPJs que já deram "erro do sistema" e devem entrar marcados para tentar depois. |
| `CONTINUAR_SOZINHO` | `true`: segue sozinha para a próxima empresa. `false`: espera um clique no ícone a cada empresa. |

Ajustes finos no topo do `content.js`: `LENTIDAO_MOUSE` (1.1) e `LENTIDAO_DIGITACAO` (1.8). Quanto maior o número, mais
devagar. `CNPJ_TESTE` só vale com a lista vazia.

### Se o Chrome perder o andamento no meio de um lote

Os PDFs já salvos continuam na pasta de destino. Para não refazer as empresas prontas, coloque os CNPJs delas em
`JA_CONCLUIDAS` (dá para conferir pelos nomes dos arquivos na pasta). Recarregue a extensão e comece de novo.

---

## 6. Onde ficam os PDFs

Sempre dentro da pasta **Downloads** do Chrome (a extensão não consegue salvar fora dela). Na janela anônima também vão
para a mesma pasta Downloads.

| O quê | Pasta (padrão do modelo) | Nome do arquivo |
|---|---|---|
| DARF emitido (empresa com negociação) | `Downloads\Parcelamento\Com_Negociacao` | `CNPJ.pdf`, ou `CNPJ_1.pdf`, `CNPJ_2.pdf`... se a empresa tem várias negociações |
| Print da consulta "sem negociação" | `Downloads\Parcelamento\Sem_Negociacao` | `CNPJ_data-hora.pdf` |

Se o Chrome estiver configurado para perguntar onde salvar cada arquivo, desligue em `chrome://settings/downloads`.

---

## 7. O que a automação faz, passo a passo

Para cada empresa, uma por vez:

1. **Troca o perfil**: "Alterar perfil de acesso" > campo "Procurador de pessoa jurídica - CNPJ" (digita tecla a tecla)
   > "Alterar". A página recarrega.
2. Abre **Consultar informações de seus parcelamentos** e clica em **Consultar**.
3. Conforme o resultado:
   - **"Não existem negociações com os critérios informados"**: tira um print da tela e salva como PDF em
     `PASTA_SEM_NEGOCIACAO`. Empresa concluída.
   - **Tabela de negociações**: lê a coluna **Situação** e, para cada negociação aceita, na ordem da tabela:
     1. menu **Ações > Emitir Documento de Arrecadação**;
     2. escolhe **Parcela** (ou **Primeira parcela**, quando for a única opção) e **Confirmar**;
     3. na tabela de parcelas, marca as **"A vencer" do mês atual e do mês anterior** e as **"Devedora"**;
        se não houver nenhuma dessas (negociação em dia), anota "em dia" e segue para a próxima;
     4. **Emitir DARF de parcela** e, na tela "Emissão de DARF", **Imprimir DARF**;
     5. guarda o PDF gerado pelo e-CAC em `PASTA_COM_NEGOCIACAO`.
     Se nenhuma negociação estiver numa situação aceita, guarda o print da consulta e conclui a empresa.
4. Registra o andamento e passa para a próxima.

**A automação nunca clica em "Pagar DARF online" e nunca digita login ou senha.**

### Quando algo dá errado

| Situação | O que ela faz |
|---|---|
| "Não foi possível prosseguir. Tente mais tarde (Erro N)" | Pula a empresa, marca "erro do sistema" e segue. No fim da rodada lista as que deram erro; clicar no ícone tenta de novo. |
| "Não foi possível concluir a ação..." ao emitir o DARF | Tenta mais uma vez após uma pausa. Se repetir, pula só essa negociação e marca a empresa para voltar depois. |
| Tela "carregando" sem fim ou página de erro do servidor | Atualiza a página (F5) sozinha e continua de onde parou. Até 4 recargas por empresa; depois marca "erro do sistema". |
| "Alterar perfil de acesso" cinza ou janela que não abre | Só clica quando o botão está utilizável e mostra o motivo no aviso. Espera 45 s (90, 135, 180 s nas recargas seguintes) e atualiza a página. |
| Tabela com muitas negociações | Rola a tabela linha a linha, com pausas, deixando espaço para o menu "Ações" abrir. |
| Empresa com várias negociações | Processa uma a uma; guarda quais já saíram e, ao voltar, refaz só as que faltaram. |
| Qualquer outra coisa nova | **Para** e mostra o motivo na tela. A empresa continua pendente. Nada é adivinhado. |

---

## 8. Como funciona por dentro (resumo)

- **Manifest V3**, JavaScript puro, sem dependências. Roda só em `cav.receita.fazenda.gov.br` e subdomínios.
- O conteúdo do Parcelamento fica num **iframe de outro subdomínio**. Por isso o `content.js` roda em todos os quadros:
  na janela principal ele orquestra; dentro do iframe ele é um agente que responde a pedidos ("ache este texto",
  "clique aqui"), com as mensagens passando pelo `background.js`.
- O **andamento** fica em `chrome.storage.local` (chave `parcelamento_simplificado_fila`), ligado ao `ID_LOTE`.
- O `background.js` captura a tela da aba (tela para PDF) e renomeia/salva o PDF do DARF na pasta de destino.
- A seta desenhada, as pausas, a rolagem suave e a digitação tecla a tecla servem para a página reagir como no uso normal
  e para você acompanhar. Não são um meio de contornar controles do e-CAC.
- Permissões: `downloads` (guardar o PDF em subpasta), `storage` (andamento), acesso ao e-CAC e `<all_urls>` (exigido
  pelo Chrome para capturar a imagem da aba). Nenhum dado é enviado para fora do computador.
- Janela anônima: o manifest declara `"incognito": "spanning"` (um só serviço, andamento compartilhado).

---

## 9. Limitações e cuidados

- Depende dos textos e da estrutura das telas do e-CAC. Se a Receita mudar as telas, a busca por texto precisa de ajuste.
- A aba do e-CAC precisa estar em primeiro plano durante a captura de tela.
- O PDF "sem negociação" é uma imagem da tela (sem texto selecionável). O PDF do DARF é o do próprio e-CAC.
- Erros do próprio sistema da Receita são tratados como descrito acima, mas não dá para contorná-los.
- Uso apenas para as empresas em que você tem procuração/autorização de acesso no e-CAC.
- Ainda não confirmados em uso real: o salvamento de PDF em janela anônima e a espera do botão "Alterar perfil de acesso".

---

## 10. Manutenção

- Verificação rápida de sintaxe (precisa do Node): `node --check content.js`, e o mesmo para `background.js` e
  `lista_cnpjs.js`.
- Ao mudar o código, suba a versão no `manifest.json` para conferir em `chrome://extensions` que recarregou.
