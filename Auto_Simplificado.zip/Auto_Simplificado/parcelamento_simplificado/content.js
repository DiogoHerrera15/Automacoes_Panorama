// ===================== CONFIGURAÇÃO (fácil de trocar) =====================
const CNPJ_TESTE = '00000000000000';       // CNPJ do procurador de pessoa jurídica
const TIMEOUT_ELEMENTO_MS = 20000;         // tempo máximo esperando cada elemento aparecer
const INICIAR_AO_CARREGAR = true;          // true = roda sozinha ao abrir/recarregar a tela de Parcelamento
const LENTIDAO_MOUSE = 1.1;              // multiplica o tempo dos movimentos da seta (1 = rápido; 1.5 = bem calmo; maior = mais devagar)
const LENTIDAO_DIGITACAO = 1.8;            // multiplica o tempo entre as teclas (1 = versão anterior; maior = mais devagar)
// (as pastas de destino dos PDFs, PASTA_SEM_NEGOCIACAO e PASTA_COM_NEGOCIACAO, ficam em lista_cnpjs.js, junto com a lista)
const DATA_REFERENCIA = '';                // '' = usa a data de hoje; para testar outra data: 'AAAA-MM-DD'
const MODO_PREENCHIMENTO = 'digitar';      // 'digitar' = tecla a tecla | 'colar' = Ctrl+V simulado (evento paste)
// ==========================================================================

(() => {
  'use strict';

  const PREFIXO = '[parcelamento_simplificado]';
  const TEXTO_BOTAO = 'Alterar perfil de acesso';
  const TEXTO_MODAL = 'Escolha uma das opções e altere o perfil de acesso';
  const TEXTO_LABEL_CNPJ = 'Procurador de pessoa jurídica - CNPJ';
  const TEXTO_CONSULTAR = 'Consultar informações de seus parcelamentos';
  const TEXTO_TELA_INICIAL = 'Parcelamento - Solicitar e acompanhar';
  const TEXTO_TELA_NEGOCIACOES = 'Consultar negociações';
  const TEXTO_BOTAO_CONSULTAR = 'Consultar';
  const TEXTO_SEM_NEGOCIACAO = 'Não existem negociações com os critérios informados';
  const TEXTO_COL_REQUERIMENTO = 'Data do requerimento';           // cabeçalho da tabela de negociações
  const TEXTO_COL_ACOES = 'Ações';                                  // cabeçalho da coluna com o ícone de menu
  const TEXTO_OPCAO_DARF = 'Emitir Documento de Arrecadação';       // opção do menu de Ações
  const RESERVA_MENU_PX = 240;  // espaço livre exigido ABAIXO do ícone "Ações" (o menu abre para baixo)
  const TEXTO_TELA_DARF = 'Esta funcionalidade permite emitir documento de arrecadação';
  const TEXTO_DARF_BLOCO = 'Deseja emitir DARF para pagamento de';
  const TEXTO_RADIO_PARCELA = 'Parcela';                            // opção do bloco DARF a escolher
  // Opções do bloco DARF aceitas, em ordem de preferência: "Parcela" (negociações Ativo, que também têm "Saldo") ou,
  // quando é a única, "Primeira parcela" (negociações em "Requerimento em análise").
  const OPCOES_DARF_PREFERIDAS = ['Parcela', 'Primeira parcela'];
  const TEXTO_BOTAO_CONFIRMAR = 'Confirmar';
  const TEXTO_TELA_EXTRATO = 'Demonstrativo de parcelas';           // título da tela depois de Confirmar
  const TEXTO_BLOCO_PARCELAS = 'Parcelas da negociação';            // bloco com a tabela de parcelas
  const TEXTO_BOTAO_EMITIR = 'Emitir DARF de parcela';              // botão que leva à tela "Emissão de DARF"
  const TEXTO_TELA_EMISSAO = 'Emissão de DARF';                     // título dessa tela
  const TEXTO_BOTAO_IMPRIMIR = 'Imprimir DARF';                     // botão que gera o PDF do DARF

  let executando = false;
  let cnpjAtual = CNPJ_TESTE;  // CNPJ em processamento (o da lista, ou CNPJ_TESTE se a lista estiver vazia)
  let rotuloLote = '';         // "CNPJ 3 de 13 · faltam 10 / nome (cnpj)": aparece em todos os avisos
  let etiquetaNeg = '';        // "negociação 2 de 2": acrescentada ao rótulo quando a empresa tem mais de uma

  // ------------------------------- utilitários -------------------------------
  const log = (...a) => console.log(PREFIXO, ...a);
  const aviso = (...a) => console.warn(PREFIXO, ...a);
  const erro = (...a) => console.error(PREFIXO, ...a);
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const rand = (a, b) => a + Math.random() * (b - a);
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  const norm = (s) =>
    (s || '').replace(/\s+/g, ' ').trim().toLowerCase()
      .normalize('NFD').replace(/[̀-ͯ]/g, '');
  const soDigitos = (s) => (s || '').replace(/\D/g, '');
  // requestAnimationFrame não dispara em aba oculta; o timeout evita travar.
  const quadro = () => new Promise((r) => {
    let feito = false;
    const f = () => { if (!feito) { feito = true; r(); } };
    requestAnimationFrame(f);
    setTimeout(f, 50);
  });

  function cnpjValido(c) {
    if (!/^\d{14}$/.test(c) || /^(\d)\1+$/.test(c)) return false;
    const dv = (base) => {
      let soma = 0, peso = base.length - 7;
      for (let i = 0; i < base.length; i++) {
        soma += Number(base[i]) * peso--;
        if (peso < 2) peso = 9;
      }
      const r = soma % 11;
      return r < 2 ? 0 : 11 - r;
    };
    const d1 = dv(c.slice(0, 12));
    const d2 = dv(c.slice(0, 12) + d1);
    return d1 === Number(c[12]) && d2 === Number(c[13]);
  }

  function visivel(el) {
    if (!el || !el.isConnected) return false;
    const r = el.getBoundingClientRect();
    // vazio ou escondido fora da PÁGINA (ex.: menu em left:-9999px). Algo só rolado para fora da tela conta como visível.
    const se = el.ownerDocument.scrollingElement;
    const sx = se ? se.scrollLeft : 0, sy = se ? se.scrollTop : 0;
    if (r.width < 1 || r.height < 1 || r.right + sx <= 0 || r.bottom + sy <= 0) return false;
    const cs = getComputedStyle(el);
    return cs.visibility !== 'hidden' && cs.display !== 'none' && Number(cs.opacity) > 0;
  }

  // A janela "Alterar perfil de acesso" pode estar dentro de um iframe: busca no documento
  // principal e em todos os iframes do mesmo domínio (os de outro domínio o navegador bloqueia).
  function todosDocs() {
    const docs = [document];
    for (let i = 0; i < docs.length; i++) {
      for (const f of docs[i].querySelectorAll('iframe, frame')) {
        try {
          const d = f.contentDocument;
          if (d && d.body && !docs.includes(d)) docs.push(d);
        } catch (_) { /* iframe de outro domínio */ }
      }
    }
    return docs;
  }

  function descreverFrames() {
    const docs = todosDocs();
    let total = 0;
    const bloqueados = {};
    for (const d of docs) {
      for (const f of d.querySelectorAll('iframe, frame')) {
        total++;
        let ok = false;
        try { ok = !!f.contentDocument; } catch (_) { /* bloqueado */ }
        if (!ok) {
          let host = 'sem src';
          try { host = new URL(f.src, location.href).host || host; } catch (_) { /* ignora */ }
          bloqueados[host] = (bloqueados[host] || 0) + 1;
        }
      }
    }
    const lista = Object.entries(bloqueados).map(([h, n]) => `${h} x${n}`).join(', ');
    return `iframes: ${total}; bloqueados: ${lista || 'nenhum'}`;
  }

  // Documentos + shadow roots abertos (a janela pode estar dentro de um componente).
  function todasRaizes() {
    const raizes = todosDocs();
    for (let i = 0; i < raizes.length; i++) {
      for (const el of raizes[i].querySelectorAll('*')) {
        if (el.shadowRoot) raizes.push(el.shadowRoot);
      }
    }
    return raizes;
  }

  // Comparação tolerante: ignora acentos, maiúsculas, pontuação, espaços e caracteres invisíveis.
  const chave = (s) => norm(s).replace(/[^a-z0-9]/g, '');

  // Visível mesmo quando o pai direto é um <span> inline sem tamanho: olha até 4 ancestrais.
  function visivelFrouxo(el) {
    // qualquer ancestral com display:none (janela escondida) torna o elemento invisível
    for (let e = el; e; e = e.parentElement || (e.getRootNode && e.getRootNode().host)) {
      if (getComputedStyle(e).display === 'none') return false;
    }
    if (getComputedStyle(el).visibility === 'hidden') return false;
    for (let e = el, i = 0; e && i < 4; e = e.parentElement, i++) {
      const r = e.getBoundingClientRect();
      if (r.width >= 1 && r.height >= 1) {
        const se = e.ownerDocument.scrollingElement; // menu escondido fora da página (não só rolado para fora da tela)
        if (r.right + (se ? se.scrollLeft : 0) <= 0 || r.bottom + (se ? se.scrollTop : 0) <= 0) return false;
        const cs = getComputedStyle(e);
        return cs.visibility !== 'hidden' && cs.display !== 'none' && Number(cs.opacity) > 0.05;
      }
    }
    return false;
  }

  // Diagnóstico: onde (e como) um texto aparece na página, mesmo invisível.
  function ondeEstaTexto(texto) {
    const alvo = chave(texto);
    for (const raiz of todasRaizes()) {
      const w = (raiz.ownerDocument || raiz).createTreeWalker(raiz, NodeFilter.SHOW_TEXT);
      for (let n = w.nextNode(); n; n = w.nextNode()) {
        if (!chave(n.nodeValue).includes(alvo)) continue;
        const pai = n.parentElement || (n.parentNode && n.parentNode.host);
        if (!pai) continue;
        const r = pai.getBoundingClientRect();
        const cs = getComputedStyle(pai);
        const lugar = raiz === document ? 'página' : (raiz.host ? 'shadow' : 'iframe');
        const desc = `<${pai.tagName.toLowerCase()}${pai.id ? '#' + pai.id : ''}> em ${lugar}, ` +
          `${Math.round(r.width)}x${Math.round(r.height)}, display=${cs.display}, vis=${cs.visibility}, opac=${cs.opacity}`;
        log('diagnóstico do texto', JSON.stringify(texto), '->', desc, pai);
        return desc;
      }
    }
    log('diagnóstico do texto', JSON.stringify(texto), '-> não encontrado em nenhum lugar acessível');
    return 'não encontrado em nenhum lugar acessível';
  }

  // Deslocamento do documento (viewport do iframe) em relação à janela principal.
  function offsetDoc(doc) {
    let x = 0, y = 0;
    let w = doc.defaultView;
    while (w && w.frameElement) {
      const f = w.frameElement;
      const r = f.getBoundingClientRect();
      const cs = getComputedStyle(f);
      x += r.left + f.clientLeft + (parseFloat(cs.paddingLeft) || 0);
      y += r.top + f.clientTop + (parseFloat(cs.paddingTop) || 0);
      w = w.parent;
    }
    return { x, y };
  }

  // Retângulo do elemento em coordenadas da janela principal.
  function rectAbs(el) {
    const r = el.getBoundingClientRect();
    const o = offsetDoc(el.ownerDocument);
    return { left: r.left + o.x, top: r.top + o.y, width: r.width, height: r.height,
             right: r.right + o.x, bottom: r.bottom + o.y };
  }

  // ------------------------------- erro do sistema da Receita -------------------------------
  // O e-CAC às vezes responde com uma faixa laranja: "Não foi possível prosseguir. Tente mais tarde (Erro 6)."
  // É falha do lado da Receita: a empresa é pulada e marcada para voltar depois.
  // Faixas de erro conhecidas. `tipo`:
  //  - 'sistema': "Não foi possível prosseguir. Tente mais tarde (Erro N)" - falha passageira da Receita: a EMPRESA é
  //    pulada e marcada para voltar depois.
  //  - 'negociacao': "[undefined -] Não foi possível concluir a ação, utilize os canais de atendimento…" - o e-CAC
  //    não conseguiu fazer aquela ação (ex.: emitir o DARF de uma negociação): só ESSA negociação é pulada, as outras
  //    da empresa continuam, e a empresa fica marcada para voltar depois.
  //  - 'servidor': página de erro do servidor (ASP.NET), ex.: "Server Error in '/autenticacao' Application." -
  //    o servidor da Receita falhou por dentro; a página é ATUALIZADA (F5) e o trabalho continua de onde parou.
  const PADROES_ERRO = [
    { chave: chave('Tente mais tarde'), tipo: 'sistema' },
    { chave: chave('Não foi possível concluir a ação'), tipo: 'negociacao' },
    { chave: chave('Server Error in'), tipo: 'servidor' },
  ];
  const padraoDoTexto = (t) => PADROES_ERRO.find((p) => chave(t).includes(p.chave));

  // `faixa` = { texto, tipo } (como devolve lerErroSistema)
  function erroSistema(faixa, etapa) {
    const e = new Error(`Erro do e-CAC ao aguardar ${etapa}: "${faixa.texto}"`);
    e.erroSistema = true;
    e.faixa = faixa.texto;
    e.tipo = faixa.tipo;
    return e;
  }

  // Faixa de erro visível (na página ou nos iframes acessíveis). `soNovas`: ignora as que já estavam na tela
  // quando foram marcadas com marcarFaixasVistas() (por exemplo, uma faixa antiga que ficou aberta).
  function acharFaixaErro(soNovas) {
    for (const raiz of todasRaizes()) {
      const w = (raiz.ownerDocument || raiz).createTreeWalker(raiz, NodeFilter.SHOW_TEXT);
      for (let n = w.nextNode(); n; n = w.nextNode()) {
        const padrao = padraoDoTexto(n.nodeValue);
        if (!padrao) continue;
        const pai = n.parentElement || (n.parentNode && n.parentNode.host);
        if (!pai || pai.closest('#ps-aviso') || !visivelFrouxo(pai)) continue;
        if (soNovas && pai.dataset && pai.dataset.psVisto) continue;
        return { pai, tipo: padrao.tipo, texto: n.nodeValue.replace(/\s+/g, ' ').trim().slice(0, 160) };
      }
    }
    return null;
  }

  function marcarFaixasVistas() {
    for (const raiz of todasRaizes()) {
      const w = (raiz.ownerDocument || raiz).createTreeWalker(raiz, NodeFilter.SHOW_TEXT);
      for (let n = w.nextNode(); n; n = w.nextNode()) {
        const pai = n.parentElement;
        if (pai && pai.dataset && padraoDoTexto(n.nodeValue)) pai.dataset.psVisto = '1';
      }
    }
  }

  // Versões que também olham os iframes de outro domínio (pelo agente de cada frame). Devolve { texto, tipo } ou null.
  async function lerErroSistema(soNovas) {
    const l = acharFaixaErro(soNovas);
    if (l) return { texto: l.texto, tipo: l.tipo };
    const r = await perguntarFrames({ op: 'erro-sistema', soNovas });
    return r && r.ok ? { texto: r.texto, tipo: r.tipo } : null;
  }
  const vigiarErroSistema = (final) => lerErroSistema(!final);

  async function marcarErrosVistos() {
    marcarFaixasVistas();
    await perguntarFrames({ op: 'erro-sistema', marcar: true });
  }

  // Espera `buscar()` devolver algo "truthy"; se estourar o tempo, lança erro com a mensagem.
  // `buscar` pode ser síncrona ou async. `textosDiag`: textos a procurar para explicar uma falha.
  // `vigiar`: confere de tempos em tempos se o e-CAC mostrou uma faixa de erro do sistema ("Tente mais tarde");
  // se mostrou, a espera termina na hora com um erro marcado como `erroSistema`. null = não vigia.
  // `recarregarSeDemorar`: se estourar o tempo (tela que ficou "carregando" sem terminar), o erro lançado leva
  // `recarregar = true`: quem trata decide atualizar a página (F5) e continuar de onde parou.
  async function esperar(buscar, descricao, timeout = TIMEOUT_ELEMENTO_MS, textosDiag = [], vigiar = vigiarErroSistema,
    recarregarSeDemorar = false) {
    const limite = Date.now() + timeout;
    let ultimaVigia = Date.now();
    log(`aguardando: ${descricao} (limite ${Math.round(timeout / 1000)}s)`);
    for (;;) {
      let achado = null;
      try { achado = await buscar(); } catch (_) { /* tenta de novo */ }
      if (achado) {
        log(`encontrado: ${descricao}`);
        return achado;
      }
      if (vigiar && Date.now() - ultimaVigia > 2500) {
        ultimaVigia = Date.now();
        const faixa = await vigiar(false);
        if (faixa) throw erroSistema(faixa, descricao);
      }
      if (Date.now() > limite) {
        const faixa = vigiar ? await vigiar(true) : null; // no fim, conta até a faixa que já estava na tela
        if (faixa) throw erroSistema(faixa, descricao);
        if (recarregarSeDemorar) {
          const e = new Error(`Demorou mais de ${Math.round(timeout / 1000)}s (tela carregando sem concluir): ${descricao}`);
          e.recarregar = true;
          throw e;
        }
        const diag = descreverFrames();
        aviso('diagnóstico:', diag);
        const textos = await Promise.all(textosDiag.map(async (t) => `"${t}" -> ${await ondeEstaTextoGeral(t)}`));
        throw new Error(`Não apareceu em ${Math.round(timeout / 1000)}s: ${descricao}. (${diag}) ${textos.join(' ; ')}`);
      }
      await sleep(120);
    }
  }

  // Elementos visíveis mais internos cujo texto (normalizado) casa com `texto`.
  function acharPorTexto(texto, { exato = true } = {}) {
    const alvo = norm(texto);
    const casa = (el) => {
      const t = norm(el.textContent);
      return exato ? t === alvo : t.startsWith(alvo) && t.length <= alvo.length + 6;
    };
    const lista = todosDocs().flatMap((d) => [...d.body.querySelectorAll('*')]).filter((el) =>
      !el.closest('#ps-cursor, #ps-aviso') &&
      !['SCRIPT', 'STYLE', 'NOSCRIPT'].includes(el.tagName) &&
      casa(el) && visivel(el));
    // fica só com os mais internos
    return lista.filter((el) => !lista.some((o) => o !== el && el.contains(o)));
  }

  function acharBotaoPerfil() {
    const alvo = norm(TEXTO_BOTAO);
    let el = acharPorTexto(TEXTO_BOTAO)[0];
    if (!el) {
      // botão que leva o texto em title/alt/value
      el = todosDocs().flatMap((d) => [...d.querySelectorAll('[title],[alt],input[value]')]).find((e) =>
        [e.title, e.alt, e.value].some((v) => norm(v) === alvo) && visivel(e));
    }
    if (!el) return null;
    return el.closest('a, button, input, [role="button"], [onclick]') || el;
  }

  // Elemento visível que tem, como texto próprio, um trecho com `texto` (mesmo que misturado a outros filhos).
  // `exato`: o texto do nó tem de ser só `texto` (evita pegar uma frase que apenas o contém).
  // `semVisibilidade`: acha o texto mesmo escondido (para saber se o menu existe na página sem estar à vista).
  function acharTextoProprio(texto, exato = false, semVisibilidade = false) {
    const alvo = chave(texto);
    for (const raiz of todasRaizes()) {
      const walker = (raiz.ownerDocument || raiz).createTreeWalker(raiz, NodeFilter.SHOW_TEXT);
      for (let n = walker.nextNode(); n; n = walker.nextNode()) {
        const pai = n.parentElement || (n.parentNode && n.parentNode.host);
        if (!pai || pai.closest('#ps-cursor, #ps-aviso') || ['SCRIPT', 'STYLE', 'NOSCRIPT'].includes(pai.tagName)) continue;
        const t = chave(n.nodeValue);
        if ((exato ? t === alvo : t.includes(alvo)) && (semVisibilidade || visivelFrouxo(pai))) return pai;
      }
    }
    return null;
  }

  function acharModal() {
    return acharTextoProprio(TEXTO_MODAL);
  }

  function acharLabelCnpj() {
    return acharTextoProprio(TEXTO_LABEL_CNPJ);
  }

  function acharCampoCnpj(label) {
    const doc = label.getRootNode(); // o campo está na mesma raiz (documento, iframe ou shadow) do rótulo
    if (label.htmlFor) {
      const porId = doc.getElementById(label.htmlFor);
      if (porId && visivel(porId)) return porId;
    }
    const tiposIgnorados = ['hidden', 'button', 'submit', 'reset', 'image', 'checkbox', 'radio', 'file'];
    const rl = label.getBoundingClientRect();
    return [...doc.querySelectorAll('input, textarea')].find((i) => {
      if (tiposIgnorados.includes(i.type) || !visivel(i)) return false;
      if (!(label.compareDocumentPosition(i) & Node.DOCUMENT_POSITION_FOLLOWING)) return false;
      const ri = i.getBoundingClientRect();
      return ri.top >= rl.top - 8 && ri.top - rl.top < 200; // o campo fica logo abaixo do rótulo
    }) || null;
  }

  // ------------------------------- avisos na tela -------------------------------
  function mostrarAviso(texto, tipo = 'info') {
    let box = document.getElementById('ps-aviso');
    if (!box) {
      box = document.createElement('div');
      box.id = 'ps-aviso';
      document.documentElement.appendChild(box);
    }
    const cor = { info: '#1f4e79', ok: '#1e7b3a', erro: '#b03a2e' }[tipo] || '#1f4e79';
    box.style.cssText =
      'position:fixed!important;right:10px!important;top:10px!important;bottom:auto!important;max-width:340px!important;' +
      'z-index:2147483646!important;padding:10px 14px!important;border-radius:6px!important;' +
      `background:${cor}!important;color:#fff!important;font:13px/1.4 Arial,sans-serif!important;` +
      'box-shadow:0 2px 10px rgba(0,0,0,.3)!important;pointer-events:none!important;' +
      'word-break:break-word!important;max-height:60vh!important;overflow:hidden!important;white-space:pre-line!important;';
    // com a lista ativa, o aviso sempre diz em qual empresa está e quantas faltam
    const rotulo = rotuloLote && etiquetaNeg ? rotuloLote.replace('\n', ` · ${etiquetaNeg}\n`) : rotuloLote;
    box.textContent = (rotulo ? `${rotulo}\n` : 'parcelamento_simplificado: ') + texto;
  }

  // ------------------------------- cursor (seta) -------------------------------
  const cursor = { el: null, x: 0, y: 0, hover: null };
  const PONTA = { x: 3, y: 2 }; // posição da ponta da seta dentro do SVG

  function criarCursor() {
    if (cursor.el) cursor.el.remove();
    const el = document.createElement('div');
    el.id = 'ps-cursor';
    el.style.cssText =
      'position:fixed!important;left:0!important;top:0!important;width:24px!important;height:28px!important;' +
      'z-index:2147483647!important;pointer-events:none!important;margin:0!important;padding:0!important;' +
      'transition:opacity .25s!important;opacity:0;will-change:transform;';
    el.innerHTML =
      '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="28" viewBox="0 0 24 28" style="display:block;overflow:visible">' +
      '<path d="M3 2 L3 20 L7.6 15.8 L10.8 22.8 L13.6 21.6 L10.5 14.8 L16.8 14.4 Z" ' +
      'fill="#111" stroke="#fff" stroke-width="1.4" stroke-linejoin="round"/></svg>';
    document.documentElement.appendChild(el);
    cursor.el = el;
    cursor.x = rand(innerWidth * 0.35, innerWidth * 0.65);
    cursor.y = rand(innerHeight * 0.45, innerHeight * 0.75);
    posicionar();
    requestAnimationFrame(() => { el.style.opacity = '1'; });
  }

  function posicionar() {
    cursor.el.style.transform = `translate(${cursor.x - PONTA.x}px, ${cursor.y - PONTA.y}px)`;
  }

  function removerCursor() {
    if (!cursor.el) return;
    const el = cursor.el;
    el.style.opacity = '0';
    setTimeout(() => el.remove(), 400);
    cursor.el = null;
  }

  function pulso() {
    const anel = document.createElement('div');
    anel.style.cssText =
      `position:fixed!important;left:${cursor.x - 14}px!important;top:${cursor.y - 14}px!important;` +
      'width:28px!important;height:28px!important;border-radius:50%!important;' +
      'border:2px solid rgba(31,78,121,.8)!important;z-index:2147483647!important;pointer-events:none!important;';
    document.documentElement.appendChild(anel);
    anel.animate(
      [{ transform: 'scale(.3)', opacity: 1 }, { transform: 'scale(1.5)', opacity: 0 }],
      { duration: 450, easing: 'ease-out' }
    ).onfinish = () => anel.remove();
    cursor.el.animate(
      [{ transform: `translate(${cursor.x - PONTA.x}px, ${cursor.y - PONTA.y}px) scale(1)` },
       { transform: `translate(${cursor.x - PONTA.x}px, ${cursor.y - PONTA.y}px) scale(.82)` },
       { transform: `translate(${cursor.x - PONTA.x}px, ${cursor.y - PONTA.y}px) scale(1)` }],
      { duration: 180 }
    );
  }

  // Eventos de mouse "sintéticos" no ponto onde a seta está.
  function disparar(el, tipo, extra = {}) {
    if (!el) return;
    const ponteiro = tipo.startsWith('pointer');
    const Ctor = ponteiro && typeof PointerEvent === 'function' ? PointerEvent : MouseEvent;
    const semBolha = tipo === 'mouseenter' || tipo === 'mouseleave' || tipo === 'pointerenter' || tipo === 'pointerleave';
    const o = offsetDoc(el.ownerDocument); // se o elemento está num iframe, a coordenada é relativa a ele
    el.dispatchEvent(new Ctor(tipo, {
      bubbles: !semBolha, cancelable: true, composed: true, view: window,
      clientX: cursor.x - o.x, clientY: cursor.y - o.y, screenX: cursor.x, screenY: cursor.y,
      button: 0, buttons: tipo === 'mousedown' || tipo === 'pointerdown' ? 1 : 0,
      pointerId: 1, pointerType: 'mouse', isPrimary: true, ...extra,
    }));
  }

  function sobCursor() {
    // a seta tem pointer-events:none; se o ponto cair num iframe, entra nele
    let x = cursor.x, y = cursor.y;
    let el = document.elementFromPoint(x, y);
    while (el && /^i?frame$/i.test(el.tagName)) {
      let d = null;
      try { d = el.contentDocument; } catch (_) { /* outro domínio */ }
      if (!d) break;
      const r = el.getBoundingClientRect();
      const cs = getComputedStyle(el);
      x -= r.left + el.clientLeft + (parseFloat(cs.paddingLeft) || 0);
      y -= r.top + el.clientTop + (parseFloat(cs.paddingTop) || 0);
      const dentro = d.elementFromPoint(x, y);
      if (!dentro) break;
      el = dentro;
    }
    return el;
  }

  function atualizarHover() {
    const novo = sobCursor();
    if (novo !== cursor.hover) {
      if (cursor.hover) {
        disparar(cursor.hover, 'pointerout'); disparar(cursor.hover, 'mouseout');
        disparar(cursor.hover, 'mouseleave');
      }
      if (novo) {
        disparar(novo, 'pointerover'); disparar(novo, 'mouseover');
        disparar(novo, 'mouseenter');
      }
      cursor.hover = novo;
    }
    if (novo) { disparar(novo, 'pointermove'); disparar(novo, 'mousemove'); }
  }

  // Um trecho de movimento: curva de Bézier cúbica, aceleração/desaceleração e leve tremor.
  async function trecho(destX, destY, duracao, curvatura = 1) {
    const x0 = cursor.x, y0 = cursor.y;
    const dx = destX - x0, dy = destY - y0;
    const dist = Math.hypot(dx, dy) || 1;
    const nx = -dy / dist, ny = dx / dist;
    const arco = rand(-0.2, 0.2) * dist * curvatura;
    const c1 = { x: x0 + dx * rand(0.2, 0.35) + nx * arco * rand(0.6, 1.3), y: y0 + dy * rand(0.2, 0.35) + ny * arco * rand(0.6, 1.3) };
    const c2 = { x: x0 + dx * rand(0.65, 0.85) + nx * arco * rand(0.1, 0.9), y: y0 + dy * rand(0.65, 0.85) + ny * arco * rand(0.1, 0.9) };
    const fase = rand(0, 6.28);
    const inicio = performance.now();
    for (;;) {
      const t = clamp((performance.now() - inicio) / duracao, 0, 1);
      const e = t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2; // easeInOutCubic
      const u = 1 - e;
      const bx = u * u * u * x0 + 3 * u * u * e * c1.x + 3 * u * e * e * c2.x + e * e * e * destX;
      const by = u * u * u * y0 + 3 * u * u * e * c1.y + 3 * u * e * e * c2.y + e * e * e * destY;
      const tremor = (1 - t) * 0.9;
      cursor.x = bx + Math.sin(t * 41 + fase) * tremor;
      cursor.y = by + Math.cos(t * 37 + fase) * tremor;
      posicionar();
      atualizarHover();
      if (t >= 1) break;
      await quadro();
    }
    cursor.x = destX; cursor.y = destY;
    posicionar();
    atualizarHover();
  }

  async function moverPara(x, y) {
    const dist = Math.hypot(x - cursor.x, y - cursor.y);
    if (dist < 3) return;
    // movimento calmo: ~1,2 a 3,8 s conforme a distância
    const duracao = clamp((900 + dist * rand(1.3, 2.0) + rand(0, 300)) * LENTIDAO_MOUSE,
      1200 * LENTIDAO_MOUSE, 3800 * LENTIDAO_MOUSE);
    if (dist > 200 && Math.random() < 0.6) {
      // passa um pouco do alvo e corrige, como a mão humana faz
      const ux = (x - cursor.x) / dist, uy = (y - cursor.y) / dist;
      const exc = rand(7, 20);
      await trecho(x + ux * exc, y + uy * exc, duracao);
      await sleep(rand(80, 200));
      await trecho(x, y, rand(300, 520) * LENTIDAO_MOUSE, 0.3);
    } else {
      await trecho(x, y, duracao);
    }
    await sleep(rand(350, 800)); // pausa antes de agir
  }

  // Ponto aleatório na parte central do elemento (não o centro exato), em coordenadas da janela.
  function pontoEm(el) {
    const r = rectAbs(el);
    return {
      x: r.left + r.width * rand(0.3, 0.7),
      y: r.top + r.height * rand(0.3, 0.7),
    };
  }

  async function garantirNaTela(el) {
    const r = rectAbs(el);
    if (r.top < 40 || r.bottom > innerHeight - 40 || r.left < 0 || r.right > innerWidth) {
      log('rolando a página até o elemento');
      el.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'nearest' });
      await sleep(700);
    }
  }

  async function clicarEm(el, descricao) {
    // a página rola (em gomos suaves) para o alvo ficar numa zona confortável antes de a seta ir até ele
    await manterNaZonaConfortavel(async () => { const r = rectAbs(el); return { top: r.top, bottom: r.bottom, iframe: null }; });
    await garantirNaTela(el);
    const p = pontoEm(el);
    log(`movendo a seta até: ${descricao}`);
    await moverPara(p.x, p.y);

    let alvo = sobCursor();
    if (!alvo || !(alvo === el || el.contains(alvo) || alvo.contains(el))) {
      aviso(`outro elemento está sobre ${descricao}; clicando no próprio elemento`);
      alvo = el;
    }
    log(`clicando em: ${descricao}`);
    pulso();
    disparar(alvo, 'pointerdown'); disparar(alvo, 'mousedown');
    if (typeof el.focus === 'function' && /^(INPUT|TEXTAREA)$/.test(el.tagName)) el.focus();
    await sleep(rand(90, 190));
    disparar(alvo, 'pointerup'); disparar(alvo, 'mouseup');
    disparar(alvo, 'click', { detail: 1 });
  }

  // ------------------------------- digitação e colagem -------------------------------
  // Dispara um evento de teclado; devolve false se a página cancelou (preventDefault).
  function tecla(campo, tipo, t, extra = {}) {
    return campo.dispatchEvent(new KeyboardEvent(tipo, {
      key: t.key, code: t.code, keyCode: t.keyCode, which: t.keyCode,
      charCode: tipo === 'keypress' ? t.keyCode : 0,
      bubbles: true, cancelable: true, composed: true, view: window, ...extra,
    }));
  }

  async function digitar(campo, texto) {
    campo.focus();
    if (campo.value) {
      // apaga o que já houver, como faria quem seleciona tudo e aperta Backspace
      if (typeof campo.select === 'function') campo.select();
      const bs = { key: 'Backspace', code: 'Backspace', keyCode: 8 };
      if (tecla(campo, 'keydown', bs)) campo.ownerDocument.execCommand('delete');
      tecla(campo, 'keyup', bs);
      await sleep(rand(250, 450));
    }
    for (let i = 0; i < texto.length; i++) {
      const ch = texto[i];
      const t = { key: ch, code: /\d/.test(ch) ? `Digit${ch}` : '', keyCode: ch.charCodeAt(0) };
      let tratada = !tecla(campo, 'keydown', t);
      if (!tratada) tratada = !tecla(campo, 'keypress', t);
      // se uma máscara cancelou o keypress, ela mesma insere o caractere
      if (!tratada) campo.ownerDocument.execCommand('insertText', false, ch);
      tecla(campo, 'keyup', t);
      // ritmo de quem digita (base 45-130 ms por tecla, com hesitação curta de vez em quando) x LENTIDAO_DIGITACAO
      await sleep((rand(45, 130) + (Math.random() < 0.12 ? rand(90, 220) : 0)) * LENTIDAO_DIGITACAO);
    }
    await sleep(120);
    return 'digitação tecla a tecla';
  }

  async function preencher(campo, texto) {
    if (MODO_PREENCHIMENTO === 'colar') return colar(campo, texto);
    const metodo = await digitar(campo, texto);
    if (soDigitos(campo.value) === texto) return metodo;
    aviso(`a digitação deixou "${campo.value}"; tentando colar`);
    return colar(campo, texto);
  }

  async function colar(campo, texto) {
    campo.focus();
    if (typeof campo.select === 'function') campo.select();

    // Ctrl+V: pressiona Ctrl, pressiona V, dispara o paste e solta as teclas
    const ctrl = { key: 'Control', code: 'ControlLeft', keyCode: 17 };
    const v = { key: 'v', code: 'KeyV', keyCode: 86 };
    tecla(campo, 'keydown', ctrl, { ctrlKey: true });
    await sleep(rand(60, 140));
    tecla(campo, 'keydown', v, { ctrlKey: true });
    const dt = new DataTransfer();
    dt.setData('text/plain', texto);
    const evt = new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true, composed: true });
    campo.dispatchEvent(evt);
    log('evento paste disparado' + (evt.defaultPrevented ? ' (tratado/cancelado pela página)' : ''));
    await sleep(rand(50, 120));
    tecla(campo, 'keyup', v, { ctrlKey: true });
    tecla(campo, 'keyup', ctrl);
    await sleep(120);
    if (soDigitos(campo.value) === texto) return 'evento paste';

    // O paste sintético não insere texto sozinho: insere como se fosse digitado/colado.
    campo.focus();
    if (typeof campo.select === 'function') campo.select();
    campo.ownerDocument.execCommand('insertText', false, texto);
    await sleep(120);
    if (soDigitos(campo.value) === texto) return 'insertText após paste';

    // Último recurso: setter nativo + eventos de input/change.
    const proto = campo.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, 'value').set.call(campo, texto);
    campo.dispatchEvent(new Event('input', { bubbles: true }));
    campo.dispatchEvent(new Event('change', { bubbles: true }));
    await sleep(120);
    return 'valor direto + input/change';
  }

  // ------------------------------- estado entre recarregamentos -------------------------------
  // Ao clicar em "Alterar" o e-CAC recarrega a página e o script recomeça do zero;
  // este marcador (válido por 3 min, só nesta aba) diz de onde continuar.
  const CHAVE_FASE = 'parcelamento_simplificado_fase';
  const TIMEOUT_TROCA_PERFIL_MS = 45000;

  function lerFase() {
    try {
      const o = JSON.parse(sessionStorage.getItem(CHAVE_FASE) || 'null');
      if (o && Date.now() - o.t < 180000) return o.fase;
    } catch (_) { /* sem storage */ }
    return null;
  }

  function gravarFase(fase) {
    try {
      if (fase) sessionStorage.setItem(CHAVE_FASE, JSON.stringify({ fase, t: Date.now() }));
      else sessionStorage.removeItem(CHAVE_FASE);
    } catch (_) { /* sem storage */ }
  }

  // ------------------------------- outros frames (iframe de outro domínio) -------------------------------
  // O conteúdo do Parcelamento fica num iframe de outro subdomínio, que o navegador não deixa o script
  // principal tocar. Por isso a extensão também roda dentro dele (agente) e o script principal
  // conversa com o agente pelo service worker (background.js).
  function perguntarFrames(dados) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage({ ps: 'repassar', dados }, (resp) => {
          void chrome.runtime.lastError;
          resolve(resp || null);
        });
      } catch (_) { resolve(null); }
    });
  }

  function offsetFrameEl(f) {
    const r = f.getBoundingClientRect();
    const cs = getComputedStyle(f);
    const base = offsetDoc(f.ownerDocument);
    return {
      x: base.x + r.left + f.clientLeft + (parseFloat(cs.paddingLeft) || 0),
      y: base.y + r.top + f.clientTop + (parseFloat(cs.paddingTop) || 0),
    };
  }

  function iframeDeOrigem(origem) {
    const candidatos = todosDocs().flatMap((d) => [...d.querySelectorAll('iframe, frame')]).filter(visivel);
    const porOrigem = candidatos.filter((f) => {
      try { return new URL(f.src, location.href).origin === origem; } catch (_) { return false; }
    });
    const lista = porOrigem.length ? porOrigem : candidatos;
    const area = (f) => { const r = f.getBoundingClientRect(); return r.width * r.height; };
    return lista.sort((a, b) => area(b) - area(a))[0] || null;
  }

  // Elemento clicável cujo texto (ou value/title/alt, no caso de <input>) é exatamente `texto`.
  function acharClicavel(texto) {
    const alvo = norm(texto);
    let el = acharPorTexto(texto, { exato: true })[0];
    if (!el) {
      el = todosDocs().flatMap((d) =>
        [...d.querySelectorAll('input[type="button"], input[type="submit"], input[type="image"], [title], [alt]')])
        .find((e) => [e.value, e.title, e.alt].some((v) => norm(v) === alvo) && visivel(e));
    }
    return el ? (el.closest('a, button, input, [role="button"], [onclick]') || el) : null;
  }

  // Ícone de menu (três linhas) da coluna "Ações": o pequeno elemento logo abaixo do cabeçalho "Ações".
  // `indice` = qual linha da tabela (0 = a primeira negociação, 1 = a segunda…).
  function acharIconeAcoes(indice = 0) {
    const cab = acharPorTexto(TEXTO_COL_ACOES, { exato: true })[0];
    if (!cab) return null;
    const rc = cab.getBoundingClientRect();
    const cx = rc.left + rc.width / 2;
    const cands = [...cab.ownerDocument.querySelectorAll('a, button, img, i, span, div, input[type="image"], [onclick]')]
      .filter((e) => {
        if (e === cab || e.contains(cab) || cab.contains(e) || !visivel(e)) return false;
        const r = e.getBoundingClientRect();
        if (r.width < 6 || r.height < 6 || r.width > 80 || r.height > 60) return false;
        return r.top >= rc.bottom - 2 && r.top - rc.bottom < 800 &&
          Math.abs(r.left + r.width / 2 - cx) < Math.max(40, rc.width / 2);
      });
    const topo = (e) => e.getBoundingClientRect().top;
    const dist = (e) => { const r = e.getBoundingClientRect(); return Math.abs(r.left + r.width / 2 - cx); };
    // um ícone por linha: ordena de cima para baixo e, entre os que estão na mesma linha (o ícone e seus
    // invólucros), fica o mais centralizado na coluna
    const linhas = [];
    for (const e of cands.sort((a, b) => topo(a) - topo(b))) {
      const r = e.getBoundingClientRect();
      const cy = r.top + r.height / 2;
      const ult = linhas[linhas.length - 1];
      if (ult && Math.abs(ult.cy - cy) < 14) { if (dist(e) < dist(ult.e)) ult.e = e; }
      else linhas.push({ e, cy });
    }
    const alvo = linhas[indice];
    return alvo ? (alvo.e.closest('a, button, [onclick], [role="button"]') || alvo.e) : null;
  }

  // Bloco "Deseja emitir DARF para pagamento de": devolve a legenda e as opções (rádios) com seus rótulos.
  function lerBlocoDarf() {
    const leg = acharTextoProprio(TEXTO_DARF_BLOCO);
    if (!leg) return null;
    const caixa = leg.closest('fieldset') || leg.parentElement || leg;
    const campos = [...caixa.querySelectorAll('input[type="radio"], input[type="checkbox"]')];
    const opcoes = campos.map((r) => ({
      texto: rotuloDoCampo(r, caixa), marcado: r.checked, visivel: visivel(r), id: r.id || '', nome: r.name || '',
    }));
    return { leg, caixa, campos, opcoes };
  }

  // Rótulo de um rádio/checkbox: o <label> dele ou, se não houver, o texto logo à direita na mesma linha.
  function rotuloDoCampo(campo, caixa) {
    const viaLabel = (campo.labels && campo.labels[0])
      ? campo.labels[0].textContent.replace(/\s+/g, ' ').trim() : '';
    if (viaLabel) return viaLabel;
    const doc = caixa.ownerDocument;
    const rc = campo.getBoundingClientRect();
    const cy = rc.top + rc.height / 2;
    const w = doc.createTreeWalker(caixa, NodeFilter.SHOW_TEXT);
    let melhor = null;
    for (let n = w.nextNode(); n; n = w.nextNode()) {
      const t = n.nodeValue.replace(/\s+/g, ' ').trim();
      if (!t || !n.parentElement || n.parentElement.closest('legend')) continue;
      const rg = doc.createRange();
      rg.selectNodeContents(n);
      const r = rg.getBoundingClientRect();
      if (r.width < 1) continue;
      if (r.left >= rc.right - 2 && Math.abs(r.top + r.height / 2 - cy) < 14 && (!melhor || r.left < melhor.left)) {
        melhor = { left: r.left, t };
      }
    }
    if (melhor) return melhor.t;
    const attr = (campo.getAttribute('aria-label') || campo.getAttribute('title') || '').trim();
    if (attr) return attr;
    // último recurso: o texto do menor ancestral que tenha só este campo (linha da tabela, item, div…)
    for (let e = campo.parentElement, i = 0; e && i < 3 && e !== caixa; e = e.parentElement, i++) {
      const t = e.textContent.replace(/\s+/g, ' ').trim();
      if (t && e.querySelectorAll('input[type="radio"], input[type="checkbox"]').length === 1) return t;
    }
    return '';
  }

  // O que clicar para escolher a opção `texto` do bloco DARF (ex.: "Parcela"): o rádio, se estiver
  // visível; senão (rádio com visual próprio, escondido) o texto do rótulo.
  function acharRadioDarf(texto) {
    const b = lerBlocoDarf();
    if (!b) return null;
    const i = b.opcoes.findIndex((o) => norm(o.texto) === norm(texto));
    if (i < 0) return null;
    const r = b.campos[i];
    if (visivel(r)) return r;
    return acharPorTexto(texto, { exato: true }).find((e) => b.caixa.contains(e)) || null;
  }

  // Último recurso: marca a opção direto no rádio (clique programático), mesmo escondido.
  function forcarRadioDarf(texto) {
    const b = lerBlocoDarf();
    if (!b) return false;
    const i = b.opcoes.findIndex((o) => norm(o.texto) === norm(texto));
    if (i < 0) return false;
    const r = b.campos[i];
    r.focus();
    r.click();
    if (!r.checked) {
      r.checked = true;
      r.dispatchEvent(new Event('input', { bubbles: true }));
      r.dispatchEvent(new Event('change', { bubbles: true }));
    }
    return r.checked;
  }

  // Escolhe o localizador conforme o modo: 'texto' (padrão), 'acoes' (ícone de menu) ou 'radio' (rádio do DARF).
  function localizar(modo, texto) {
    if (modo === 'acoes') return acharIconeAcoes(Number(texto) || 0); // `texto` = índice da linha
    if (modo === 'radio') return acharRadioDarf(texto);
    return acharClicavel(texto);
  }

  // Elemento rolável mais próximo acima de `el` (ou a própria página).
  function rolavelAcima(el) {
    for (let e = el.parentElement; e && e !== el.ownerDocument.body; e = e.parentElement) {
      if (/(auto|scroll|overlay)/.test(getComputedStyle(e).overflowY) && e.scrollHeight > e.clientHeight + 2) return e;
    }
    return el.ownerDocument.scrollingElement || el.ownerDocument.documentElement;
  }

  // Todos os elementos que podem estar rolando a PÁGINA de um documento, do mais provável ao menos: ancestrais
  // roláveis de `ancora` (ex.: o iframe), o rolador padrão, body, html e contêineres grandes com rolagem própria
  // (o e-CAC às vezes rola um <div> e não o documento). Tabelas pequenas com rolagem interna ficam de fora.
  function rolaveisDoc(doc, ancora) {
    const lista = [];
    const add = (e) => { if (e && !lista.includes(e)) lista.push(e); };
    const w = doc.defaultView;
    const rolavel = (e) => /(auto|scroll|overlay)/.test(w.getComputedStyle(e).overflowY) && e.scrollHeight > e.clientHeight + 40;
    if (ancora) for (let e = ancora.parentElement; e; e = e.parentElement) if (rolavel(e)) add(e);
    add(doc.scrollingElement); add(doc.body); add(doc.documentElement);
    for (const e of doc.querySelectorAll('div, section, main, form, article')) {
      if (e.clientHeight >= w.innerHeight * 0.5 && e.clientWidth >= w.innerWidth * 0.5 && rolavel(e)) add(e);
    }
    return lista;
  }

  // As negociações que a consulta listou: uma por linha da tabela (cabeçalho "Data do requerimento") que
  // tenha uma data. Devolve a lista de números ("0211.00012.0025684030.24-92"; "#1", "#2"… se não houver
  // número legível), na ordem da tabela. null = não achei a tabela.
  // As linhas (<tr>) da tabela de negociações, TODAS e na ordem da tabela, mesmo as que a rolagem interna da
  // tabela escondeu. Assim "a linha 8" é sempre a 8ª, esteja a tabela rolada ou não.
  const RE_NEGOCIACAO = /\d{4}\.\d{5}\.\d{10}\.\d{2}-\d{2}/;

  function trsNegociacoes() {
    const cab = acharTextoProprio(TEXTO_COL_REQUERIMENTO, true);
    if (!cab) return null;
    const limpa = (e) => e.textContent.replace(/\s+/g, ' ').trim();
    let raiz = cab;
    for (let i = 0; i < 6 && raiz.parentElement; i++) {
      raiz = raiz.parentElement;
      const linhas = [...raiz.querySelectorAll('tr')].filter((tr) =>
        !tr.querySelector('th') && [...tr.querySelectorAll(':scope > td')].some((td) => /^\d{2}\/\d{2}\/\d{4}$/.test(limpa(td))));
      if (linhas.length) return linhas;
    }
    return null;
  }

  const idDaLinha = (tr, k) => (RE_NEGOCIACAO.exec(tr.textContent.replace(/\s+/g, ' ')) || [`#${k + 1}`])[0];

  // Situação da negociação nesta linha (ex.: "Ativo", "Requerimento em análise"): o texto da célula que fica sob o
  // cabeçalho "Situação" da tabela (cabeçalho e linhas podem estar em tabelas separadas, então alinha pela posição).
  function situacaoDaLinha(tr) {
    const txt = (e) => e.textContent.replace(/\s+/g, ' ').trim();
    const tds = [...tr.querySelectorAll(':scope > td')];
    if (!tds.length) return '';
    const cabReq = acharTextoProprio(TEXTO_COL_REQUERIMENTO, true);
    const linhaCab = cabReq && cabReq.closest('tr');
    const cabSit = linhaCab && [...linhaCab.children].find((c) => norm(txt(c)).startsWith('situacao'));
    if (cabSit) {
      const rc = cabSit.getBoundingClientRect();
      const cx = rc.left + rc.width / 2;
      const dist = (c) => { const r = c.getBoundingClientRect(); return Math.abs(r.left + r.width / 2 - cx); };
      return txt(tds.reduce((a, b) => (dist(b) < dist(a) ? b : a)));
    }
    const ativo = tds.find((td) => norm(txt(td)) === 'ativo'); // sem cabeçalho legível: só reconhece "Ativo"
    return ativo ? txt(ativo) : '';
  }

  // Lista de { id, situacao } das negociações da tabela, na ordem. null = não achei a tabela.
  function listarNegociacoesLocal() {
    const trs = trsNegociacoes();
    return trs ? trs.map((tr, k) => ({ id: idDaLinha(tr, k), situacao: situacaoDaLinha(tr) })) : null;
  }

  // O ícone de menu (três linhas) DESTA linha: na célula da linha que fica sob o cabeçalho "Ações".
  function iconeAcoesDaLinha(tr) {
    const cab = acharPorTexto(TEXTO_COL_ACOES, { exato: true })[0];
    const tds = [...tr.querySelectorAll(':scope > td')];
    if (!tds.length) return null;
    let td = tds[tds.length - 1];
    if (cab) {
      const rc = cab.getBoundingClientRect();
      const cx = rc.left + rc.width / 2;
      const dist = (c) => { const r = c.getBoundingClientRect(); return Math.abs(r.left + r.width / 2 - cx); };
      td = tds.reduce((a, b) => (dist(b) < dist(a) ? b : a));
    }
    const el = [...td.querySelectorAll('a, button, img, i, span, div, input[type="image"], [onclick]')].find((e) => {
      const r = e.getBoundingClientRect();
      return r.width >= 6 && r.height >= 6 && r.width <= 80 && r.height <= 60;
    }) || td;
    return el.closest('a, button, [onclick], [role="button"]') || el;
  }

  // Estado da tabela de negociações (posições no sistema de coordenadas deste documento): o retângulo
  // visível do "rolador" da tabela e, por linha, o número da negociação, a posição da linha e a do ícone.
  function serializarNegociacoes() {
    const trs = trsNegociacoes();
    if (!trs) return null;
    const sc = rolavelAcima(trs[0]);
    const doc = sc.ownerDocument;
    const R = (el) => { const r = rectAbs(el); return { left: r.left, top: r.top, right: r.right, bottom: r.bottom }; };
    const ehPagina = sc === doc.scrollingElement || sc === doc.documentElement || sc === doc.body;
    const o = offsetDoc(doc);
    const scRect = ehPagina
      ? { left: o.x, top: o.y, right: o.x + doc.documentElement.clientWidth, bottom: o.y + doc.documentElement.clientHeight }
      : R(sc);
    return {
      sc: scRect,
      paginaInteira: ehPagina, // true = a tabela não tem rolagem própria: quem rola é a página/quadro inteiro
      linhas: trs.map((tr, i) => {
        const ic = iconeAcoesDaLinha(tr);
        return { i, id: idDaLinha(tr, i), situacao: situacaoDaLinha(tr), rect: R(tr), rectIcone: ic ? R(ic) : null };
      }),
    };
  }

  async function rolarGradeNeg(dy, ms) { // um "gomo" de rolagem suave da tabela de negociações
    const trs = trsNegociacoes();
    return trs ? rolarSuave(rolavelAcima(trs[0]), dy, ms) : false;
  }

  // Número da negociação mostrado na tela "Emitir documento de arrecadação" (campo "Negociação" da Identificação).
  function idNegociacaoTelaLocal() {
    const rotulo = acharTextoProprio('Negociação', true);
    if (!rotulo) return null;
    const cont = rotulo.closest('fieldset') || (rotulo.parentElement && rotulo.parentElement.parentElement);
    const m = cont ? RE_NEGOCIACAO.exec(cont.textContent.replace(/\s+/g, ' ')) : null;
    return m ? m[0] : null;
  }

  // Linhas da tabela de parcelas: número, vencimento, situação e a caixa de seleção (se houver).
  function lerLinhasParcelas(t) {
    const limpa = (e) => e.textContent.replace(/\s+/g, ' ').trim();
    const ths = [...t.caixa.querySelectorAll('th')];
    const idxSit = ths.findIndex((th) => norm(limpa(th)).startsWith('situacao'));
    const linhas = [];
    for (const tr of t.caixa.querySelectorAll('tr')) {
      const tds = [...tr.querySelectorAll(':scope > td')];
      if (tds.length < 5) continue;
      const textos = tds.map(limpa);
      const alinhado = ths.length === tds.length && idxSit >= 0;
      linhas.push({
        tr,
        parcela: textos.find((x) => /^\d{1,3}$/.test(x)) || '',
        venc: textos.find((x) => /^\d{2}\/\d{2}\/\d{4}$/.test(x)) || '',
        situacao: (alinhado ? textos[idxSit]
          : textos.find((x) => /^(paga|a vencer|devedora|parcialmente|em analise|dispensa)/.test(norm(x)))) || '',
        check: tr.querySelector('input[type="checkbox"]'),
      });
    }
    return linhas;
  }

  // Estado da tabela de parcelas (posições no sistema de coordenadas deste documento):
  // retângulo visível do "rolador" da tabela e, por linha, posição da linha e da caixa de seleção.
  function serializarParcelas() {
    const t = lerTabelaParcelas();
    if (!t) return null;
    const linhas = lerLinhasParcelas(t);
    if (!linhas.length) return null;
    const sc = rolavelAcima(linhas[0].tr);
    const doc = sc.ownerDocument;
    const R = (el) => { const r = rectAbs(el); return { left: r.left, top: r.top, right: r.right, bottom: r.bottom }; };
    const ehPagina = sc === doc.scrollingElement || sc === doc.documentElement || sc === doc.body;
    const o = offsetDoc(doc);
    const scRect = ehPagina
      ? { left: o.x, top: o.y, right: o.x + doc.documentElement.clientWidth, bottom: o.y + doc.documentElement.clientHeight }
      : R(sc);
    return {
      sc: scRect,
      linhas: linhas.map((l, i) => ({
        i, parcela: l.parcela, venc: l.venc, situacao: l.situacao,
        temCheck: !!l.check, marcado: !!(l.check && l.check.checked),
        rect: R(l.tr), rectCheck: l.check ? R(l.check) : null,
      })),
    };
  }

  async function rolarGrade(dy, ms) { // um "gomo" de rolagem suave da tabela de parcelas
    const t = lerTabelaParcelas();
    const l = t && lerLinhasParcelas(t)[0];
    return l ? rolarSuave(rolavelAcima(l.tr), dy, ms) : false;
  }

  function forcarCheckParcela(i) { // último recurso: clique programático na caixa da linha i
    const t = lerTabelaParcelas();
    const l = t && lerLinhasParcelas(t)[i];
    if (!l || !l.check) return false;
    if (!l.check.checked) l.check.click();
    return l.check.checked;
  }

  // Rolagem suave: anda `dy` px em `ms` ms com aceleração/desaceleração, como um "gomo" da roda do mouse.
  // Devolve true se a posição realmente mudou (false = já está no fim/início).
  async function rolarSuave(sc, dy, ms) {
    const inicio0 = sc.scrollTop;
    const t0 = performance.now();
    for (;;) {
      const t = clamp((performance.now() - t0) / ms, 0, 1);
      const e = t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2; // easeInOutQuad
      sc.scrollTop = inicio0 + dy * e;
      if (t >= 1) break;
      await quadro();
    }
    return Math.abs(sc.scrollTop - inicio0) >= 1;
  }

  // Tabela do bloco "Parcelas da negociação": cabeçalhos e linhas (texto das células).
  function lerTabelaParcelas() {
    const leg = acharTextoProprio(TEXTO_BLOCO_PARCELAS, true);
    if (!leg) return null;
    const caixa = leg.closest('fieldset') || leg.parentElement || leg;
    const limpa = (e) => e.textContent.replace(/\s+/g, ' ').trim();
    const colunas = [...caixa.querySelectorAll('th')].map(limpa).filter(Boolean);
    const linhas = [...caixa.querySelectorAll('tr')]
      .map((tr) => [...tr.querySelectorAll(':scope > td')].map(limpa))
      .filter((c) => c.length >= 5);
    return { leg, caixa, colunas, linhas };
  }

  // Botão/link desabilitado (atributo, aria ou classe)?
  function desabilitadoEl(e) {
    return !!(e.disabled || e.getAttribute('aria-disabled') === 'true' ||
      /(^|\s)(disabled|desabilitado)(\s|$)/i.test(typeof e.className === 'string' ? e.className : ''));
  }

  // Procura um elemento pelo texto exato (modo 'texto') ou o ícone de Ações (modo 'acoes'):
  // primeiro na página/iframes acessíveis, depois nos outros frames.
  async function acharAlvoTexto(texto, modo = 'texto', semRolar = false) {
    const q = { texto, modo }; // como achar este alvo de novo (a posição muda quando a tela rola)
    const local = localizar(modo, texto);
    if (local) return { el: local, desabilitado: desabilitadoEl(local), q };
    const r = await perguntarFrames({ op: 'achar', texto, modo, exato: true, semRolar });
    if (!r || !r.ok) return null;
    const iframe = iframeDeOrigem(r.origem);
    if (!iframe) return null;
    return { remoto: true, iframe, idFrame: r.idFrame, rect: r.rect, desabilitado: !!r.desabilitado, q };
  }

  async function existeTexto(texto, semVisibilidade = false) {
    if (acharTextoProprio(texto, false, semVisibilidade)) return true;
    const r = await perguntarFrames({ op: 'existe', texto, semVisibilidade });
    return !!(r && r.ok);
  }

  // Onde o texto está (na página e nos iframes), com tamanho e estilo: para explicar uma falha.
  async function ondeEstaTextoGeral(texto) {
    const local = ondeEstaTexto(texto);
    const r = await perguntarFrames({ op: 'onde-texto', texto });
    const remoto = r && r.ok ? r.desc : 'não encontrado no quadro do Parcelamento';
    return `página: ${local}; quadro: ${remoto}`;
  }

  async function clicarAlvo(alvo, descricao) {
    await marcarErrosVistos(); // uma faixa de erro que já está na tela não conta como resposta a ESTE clique
    if (alvo.el) return clicarEm(alvo.el, descricao);
    // alvo dentro de um iframe de outro domínio: antes de mover a seta, a página/quadro rola para acompanhá-la
    const posAbs = async () => {
      const a = alvo.q ? await acharAlvoTexto(alvo.q.texto, alvo.q.modo, true) : null;
      const b = a && a.remoto ? a : alvo;
      const o = offsetFrameEl(alvo.iframe);
      return { top: o.y + b.rect.top, bottom: o.y + b.rect.top + b.rect.height, iframe: alvo.iframe };
    };
    await manterNaZonaConfortavel(posAbs);
    if (alvo.q) { // posição atualizada depois da rolagem
      const a = await acharAlvoTexto(alvo.q.texto, alvo.q.modo, true);
      if (a && a.remoto) alvo = a;
    }
    const o = offsetFrameEl(alvo.iframe);
    const px = o.x + alvo.rect.left + alvo.rect.width * rand(0.3, 0.7);
    const py = o.y + alvo.rect.top + alvo.rect.height * rand(0.3, 0.7);
    log(`movendo a seta até: ${descricao} (dentro de outro frame)`);
    await moverPara(px, py);
    const o2 = offsetFrameEl(alvo.iframe);
    const lx = cursor.x - o2.x, ly = cursor.y - o2.y;
    await perguntarFrames({ op: 'mover', idFrame: alvo.idFrame, x: lx, y: ly });
    log(`clicando em: ${descricao}`);
    pulso();
    const r = await perguntarFrames({ op: 'clicar', idFrame: alvo.idFrame, x: lx, y: ly });
    if (!r || !r.ok) aviso('o frame não confirmou o clique (a página pode ter navegado); seguindo');
  }

  // Agente que roda dentro dos iframes: acha texto, move e clica a pedido do script principal.
  function iniciarAgente() {
    const idFrame = Math.random().toString(36).slice(2);
    log('agente do frame pronto em', location.href.slice(0, 90));
    chrome.runtime.onMessage.addListener((msg, remetente, responder) => {
      if (!msg || msg.ps !== 'frame') return false;
      const m = msg.dados || {};
      if (m.op === 'achar') {
        const alvo = localizar(m.modo, m.texto);
        if (!alvo) return false;
        let r = rectAbs(alvo);
        if (!m.semRolar && (r.top < 20 || r.bottom > innerHeight - 20)) {
          alvo.scrollIntoView({ block: 'center', inline: 'nearest' });
          r = rectAbs(alvo);
        }
        responder({ ok: true, idFrame, origem: location.origin, desabilitado: desabilitadoEl(alvo),
                    rect: { left: r.left, top: r.top, width: r.width, height: r.height } });
        return false;
      }
      if (m.op === 'existe') {
        if (acharTextoProprio(m.texto, false, !!m.semVisibilidade)) responder({ ok: true, idFrame });
        return false;
      }
      if (m.op === 'onde-texto') { // descreve onde (e como) o texto aparece neste frame, mesmo escondido
        const d = ondeEstaTexto(m.texto);
        if (d.startsWith('<')) responder({ ok: true, desc: d });
        return false;
      }
      if (m.op === 'darf') { // lê o bloco "Deseja emitir DARF…" deste frame
        const b = lerBlocoDarf();
        if (!b) return false;
        const r0 = b.caixa.getBoundingClientRect();
        if (r0.bottom > innerHeight - 20 || r0.top < 20) b.caixa.scrollIntoView({ block: 'center', inline: 'nearest' });
        const r = rectAbs(b.leg);
        responder({ ok: true, idFrame, origem: location.origin, opcoes: b.opcoes,
                    rect: { left: r.left, top: r.top, width: r.width, height: r.height } });
        return false;
      }
      if (m.op === 'rolar-el') { // um gomo de rolagem suave na direção de um botão/link deste frame
        const alvo = localizar(m.modo, m.texto);
        if (!alvo) return false;
        rolarSuave(rolavelAcima(alvo), m.dy, m.ms).then((moveu) => responder({ ok: true, moveu }));
        return true;
      }
      if (m.op === 'erro-sistema') { // faixa de erro do e-CAC neste frame / marcar as que já estão na tela
        if (m.marcar) { marcarFaixasVistas(); responder({ ok: true }); return false; }
        const f = acharFaixaErro(!!m.soNovas);
        if (f) responder({ ok: true, texto: f.texto, tipo: f.tipo });
        return false;
      }
      if (m.op === 'neg-estado') { // estado da tabela de negociações deste frame
        const s = serializarNegociacoes();
        if (s) responder({ ok: true, idFrame, origem: location.origin, ...s });
        return false;
      }
      if (m.op === 'neg-rolar') { // um gomo de rolagem suave da tabela de negociações
        if (!trsNegociacoes()) return false;
        rolarGradeNeg(m.dy, m.ms).then((moveu) => responder({ ok: true, moveu }));
        return true;
      }
      if (m.op === 'rolar-doc') { // um gomo de rolagem suave de um dos roladores da página deste frame (m.n = qual)
        const lista = rolaveisDoc(document, null);
        const sc = lista[m.n || 0];
        if (!sc) { responder({ ok: true, moveu: false, real: 0, total: lista.length }); return false; }
        const antes = sc.scrollTop;
        rolarSuave(sc, m.dy, m.ms)
          .then((moveu) => responder({ ok: true, moveu, real: sc.scrollTop - antes, total: lista.length }));
        return true;
      }
      if (m.op === 'neg-tela') { // número da negociação da tela "Emitir documento de arrecadação" deste frame
        const id = idNegociacaoTelaLocal();
        if (id) responder({ ok: true, id });
        return false;
      }
      if (m.op === 'negociacoes') { // as negociações que a tabela deste frame lista
        const lista = listarNegociacoesLocal();
        if (lista) responder({ ok: true, lista });
        return false;
      }
      if (m.op === 'parcelas') { // estado da tabela de parcelas deste frame
        const s = serializarParcelas();
        if (s) responder({ ok: true, idFrame, origem: location.origin, ...s });
        return false;
      }
      if (m.op === 'parcelas-rolar') { // um gomo de rolagem suave da tabela de parcelas
        if (!lerTabelaParcelas()) return false;
        rolarGrade(m.dy, m.ms).then((moveu) => responder({ ok: true, moveu }));
        return true;
      }
      if (m.op === 'parcela-forcar') { // marca a linha direto na caixa de seleção
        if (!lerTabelaParcelas()) return false;
        responder({ ok: true, marcado: forcarCheckParcela(m.indice) });
        return false;
      }
      if (m.op === 'forcar-radio') { // marca a opção direto no rádio deste frame
        const bloco = lerBlocoDarf();
        if (!bloco) return false;
        responder({ ok: true, marcado: forcarRadioDarf(m.texto) });
        return false;
      }
      if (m.op === 'texto-rect') { // posição de um texto neste frame (sem rolar)
        const el = acharTextoProprio(m.texto, m.exato);
        if (!el) return false;
        const r = rectAbs(el);
        responder({ ok: true, idFrame, origem: location.origin,
                    rect: { left: r.left, top: r.top, width: r.width, height: r.height } });
        return false;
      }
      if (m.op === 'rolar') { // um passo SUAVE de rolagem do frame rumo a um texto
        const el = acharTextoProprio(m.texto, m.exato);
        if (!el) return false;
        if (m.forcar) {
          el.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'nearest' });
          responder({ ok: true, moveu: true });
          return false;
        }
        rolarSuave(rolavelAcima(el), m.dy, m.ms).then((moveu) => responder({ ok: true, moveu }));
        return true; // responde quando a animação termina
      }
      if (m.op === 'tabela') { // cabeçalhos e linhas do bloco "Parcelas da negociação"
        const t = lerTabelaParcelas();
        if (t) responder({ ok: true, idFrame, colunas: t.colunas, linhas: t.linhas.slice(0, 200) });
        return false;
      }
      if (m.op === 'topo') { // rola o frame até o topo (antes da captura de tela)
        window.scrollTo(0, 0);
        return false;
      }
      if (m.idFrame !== idFrame) return false;
      if (m.op === 'mover') {
        cursor.x = m.x; cursor.y = m.y;
        atualizarHover();
        responder({ ok: true });
        return false;
      }
      if (m.op === 'clicar') {
        agenteClicar(m.x, m.y).then(responder);
        return true;
      }
      return false;
    });
  }

  async function agenteClicar(x, y) {
    cursor.x = x; cursor.y = y;
    const alvo = sobCursor();
    if (!alvo) return { ok: false };
    disparar(alvo, 'pointerdown'); disparar(alvo, 'mousedown');
    await sleep(rand(90, 190));
    disparar(alvo, 'pointerup'); disparar(alvo, 'mouseup');
    disparar(alvo, 'click', { detail: 1 });
    return { ok: true, alvo: alvo.tagName };
  }

  // ------------------------------- botão "Alterar" e cabeçalho do perfil -------------------------------
  // O botão "Alterar" na mesma linha do campo (à direita dele).
  function acharBotaoAlterarDoCampo(campo) {
    const raiz = campo.getRootNode();
    const rc = campo.getBoundingClientRect();
    const centro = rc.top + rc.height / 2;
    const textoDe = (e) => norm(e.tagName === 'INPUT' ? e.value : e.textContent);
    const todos = [...raiz.querySelectorAll('button, input[type="button"], input[type="submit"], a, [role="button"], span, div, td')]
      .filter((e) => {
        if (textoDe(e) !== 'alterar' || !visivel(e)) return false;
        if (!(campo.compareDocumentPosition(e) & Node.DOCUMENT_POSITION_FOLLOWING)) return false;
        const r = e.getBoundingClientRect();
        return Math.abs(r.top + r.height / 2 - centro) < 30;
      });
    const el = todos.filter((e) => !todos.some((o) => o !== e && e.contains(o)))[0];
    return el ? (el.closest('button, input, a, [role="button"]') || el) : null;
  }

  // Linha "Procurador de: 00.000.000/0000-00 - NOME" do cabeçalho do e-CAC.
  function perfilProcuradorAtual() {
    for (const raiz of todasRaizes()) {
      const w = (raiz.ownerDocument || raiz).createTreeWalker(raiz, NodeFilter.SHOW_TEXT);
      for (let n = w.nextNode(); n; n = w.nextNode()) {
        if (!/procurador de:/i.test(n.nodeValue)) continue;
        const pai = n.parentElement || (n.parentNode && n.parentNode.host);
        if (!pai || pai.closest('#ps-aviso') || !visivelFrouxo(pai)) continue;
        const t = (pai.textContent || '').replace(/\s+/g, ' ');
        const m = /procurador de:/i.exec(t);
        return m ? t.slice(m.index, m.index + 160) : null;
      }
    }
    return null;
  }

  function perfilTrocado() {
    const s = perfilProcuradorAtual();
    return s && soDigitos(s).includes(cnpjAtual) ? s : null;
  }

  // ------------------------------- fluxo -------------------------------
  function analisarPagina() {
    log('ETAPA 1: analisando a página do e-CAC');
    log('URL:', location.href);
    log('título:', document.title);
    const titular = [...document.querySelectorAll('div,span,td,p')].find((e) =>
      /^Titular \(Acesso/i.test((e.textContent || '').trim()) && e.children.length < 3);
    if (titular) log('perfil atual:', titular.textContent.replace(/\s+/g, ' ').trim());
    else aviso('não encontrei a linha "Titular (Acesso ...)" no topo; seguindo mesmo assim');
    if (/parcelamento/i.test(document.body.innerText || '')) log('página de Parcelamento detectada');
    if (document.readyState !== 'complete') aviso('a página ainda está carregando (readyState=' + document.readyState + ')');
    if (!cnpjValido(cnpjAtual)) aviso(`o CNPJ ${cnpjAtual} não tem dígitos verificadores válidos`);
  }

  // Etapas 2 a 5: abre "Alterar perfil de acesso", digita o CNPJ e clica em "Alterar".
  async function etapasPerfil() {
    // Se a janela já estiver aberta, não clica de novo.
    if (acharModal()) {
      log('a janela "Alterar perfil de acesso" já está aberta; pulando o clique');
    } else {
      // O botão "Alterar perfil de acesso" às vezes fica inacessível por um tempo (cinza, sem reagir ao clique; visto
      // nas empresas 23 e 25), e a janela não abre. Regra: tenta abrir durante ESPERA_PERFIL_MS (45 s) clicando de
      // tempos em tempos (a cada ~10 s; a cada 3ª vez também com o clique nativo .click()); se nesse tempo a janela
      // não abrir (ou o botão nem aparecer), atualiza a página (F5) e recomeça de onde parou (conta nas recargas por empresa).
      // A espera cresce a cada recarga já feita nesta empresa (45 s, 90 s, 135 s...): se o e-CAC está lento, dá mais tempo.
      let recargasFeitas = 0;
      try { recargasFeitas = ((await lerFila()).recargas || {})[cnpjAtual] || 0; } catch (_) { /* sem storage */ }
      const ESPERA_PERFIL_MS = 45000 * (1 + Math.min(recargasFeitas, 3));
      // O botão está realmente utilizável? (visível, habilitado, sem nada por cima). Devolve o motivo se não estiver.
      const estadoBotaoPerfil = (el) => {
        const r = el.getBoundingClientRect();
        if (r.width < 2 || r.height < 2) return { pronto: false, motivo: 'botão escondido (sem tamanho)' };
        const cs = (el.ownerDocument.defaultView || window).getComputedStyle(el);
        if (el.disabled || el.getAttribute('aria-disabled') === 'true' || /disabled|desabilit|inativ/i.test(String(el.className || ''))) {
          return { pronto: false, motivo: 'botão desabilitado' };
        }
        if (cs.pointerEvents === 'none') return { pronto: false, motivo: 'botão sem resposta a cliques (pointer-events)' };
        const topo = el.ownerDocument.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2);
        if (topo && !(topo === el || el.contains(topo) || topo.contains(el))) {
          const nome = `<${topo.tagName.toLowerCase()}${topo.id ? '#' + topo.id : ''}${topo.className && typeof topo.className === 'string' ? '.' + topo.className.trim().split(/\s+/).slice(0, 2).join('.') : ''}>`;
          const tx = (topo.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 40);
          return { pronto: false, motivo: `algo está por cima do botão: ${nome}${tx ? ' "' + tx + '"' : ''}` };
        }
        return { pronto: true };
      };
      const inicioPerfil = Date.now();
      const restantePerfil = () => Math.max(0, ESPERA_PERFIL_MS - (Date.now() - inicioPerfil));
      const desistirPerfil = (motivo) => {
        const e2 = new Error(`o botão/janela "Alterar perfil de acesso" ficou inacessível por ${Math.round(ESPERA_PERFIL_MS / 1000)} s: ${motivo}`);
        e2.recarregar = true; // atualiza a página e continua de onde parou
        return e2;
      };
      for (let tent = 1; ; tent++) {
        log(`ETAPA 2: localizar e clicar em "Alterar perfil de acesso" (tentativa ${tent}; faltam ${Math.round(restantePerfil() / 1000)} s para atualizar a página)`);
        mostrarAviso(tent > 1
          ? `"Alterar perfil de acesso" não respondeu; tentando de novo (tentativa ${tent}). Se continuar assim, atualizo a página em ${Math.round(restantePerfil() / 1000)} s…`
          : 'procurando "Alterar perfil de acesso"…');
        let botao = null;
        try {
          botao = await esperar(acharBotaoPerfil, 'botão "Alterar perfil de acesso"', Math.max(1500, Math.min(10000, restantePerfil())));
        } catch (e) {
          if (e.erroSistema) throw e;
          aviso(`botão "Alterar perfil de acesso" não apareceu: ${e.message}`);
        }
        if (botao) {
          // só clica quando o botão está de fato utilizável; enquanto não estiver, espera ele voltar (diz o motivo na tela).
          // Nos últimos 15 s clica mesmo assim (a checagem pode errar).
          const est = estadoBotaoPerfil(botao);
          if (!est.pronto && restantePerfil() > 15000) {
            if (tent === 1 || tent % 10 === 0) aviso(`"Alterar perfil de acesso" indisponível: ${est.motivo}`);
            mostrarAviso(`"Alterar perfil de acesso" indisponível (${est.motivo}).\nEsperando voltar; se não voltar, atualizo a página em ${Math.round(restantePerfil() / 1000)} s…`, 'info');
            await sleep(1000);
            continue;
          }
          if (tent > 1) { window.scrollTo(0, 0); await sleep(rand(500, 900)); }
          const rb = botao.getBoundingClientRect();
          log(`botão achado: <${botao.tagName.toLowerCase()}> ${Math.round(rb.width)}x${Math.round(rb.height)} em (${Math.round(rb.left)}, ${Math.round(rb.top)}); ` +
            `desabilitado=${!!botao.disabled}; texto "${(botao.textContent || botao.value || botao.title || '').replace(/\s+/g, ' ').trim().slice(0, 60)}"`);
          mostrarAviso('clicando em "Alterar perfil de acesso"…');
          await clicarEm(botao, 'botão "Alterar perfil de acesso"');
          if (tent % 3 === 0 && typeof botao.click === 'function') { await sleep(rand(600, 1000)); botao.click(); }

          log('ETAPA 3: aguardar a janela "Alterar perfil de acesso"');
          mostrarAviso('aguardando a janela abrir…');
          try {
            await esperar(() => acharModal() || acharLabelCnpj(),
              'janela "Alterar perfil de acesso" (texto "Escolha uma das opções…")',
              Math.max(2000, Math.min(10000, restantePerfil())), [TEXTO_MODAL, TEXTO_LABEL_CNPJ]);
            break; // a janela abriu
          } catch (e) {
            if (e.erroSistema) throw e;
            aviso(`a janela "Alterar perfil de acesso" não abriu (tentativa ${tent}): ${e.message}`);
          }
        }
        if (restantePerfil() <= 0) throw desistirPerfil(botao ? 'a janela não abriu depois dos cliques' : 'o botão não apareceu');
        await sleep(rand(800, 1500));
      }
    }
    await sleep(rand(900, 1500)); // deixa a janela terminar de animar

    // "Lê" a janela: leva a seta ao texto de cima antes de descer até o CNPJ.
    const topoJanela = acharModal();
    if (topoJanela) {
      log('lendo a janela (seta no topo das opções)');
      const p = pontoEm(topoJanela);
      await moverPara(p.x, p.y);
    }

    log('ETAPA 4: preencher o CNPJ do procurador de pessoa jurídica');
    mostrarAviso('procurando o campo de CNPJ…');
    const campo = await esperar(() => {
      const label = acharLabelCnpj();
      return label && acharCampoCnpj(label);
    }, 'campo "Procurador de pessoa jurídica - CNPJ"', TIMEOUT_ELEMENTO_MS, [TEXTO_LABEL_CNPJ]);

    await clicarEm(campo, 'campo CNPJ do procurador de pessoa jurídica');
    await sleep(rand(250, 500));
    mostrarAviso(MODO_PREENCHIMENTO === 'colar' ? 'colando o CNPJ…' : 'digitando o CNPJ…');
    log(`${MODO_PREENCHIMENTO === 'colar' ? 'colando' : 'digitando'} CNPJ ${cnpjAtual}`);
    const metodo = await preencher(campo, cnpjAtual);
    const valorFinal = campo.value;
    if (soDigitos(valorFinal) !== cnpjAtual) {
      throw new Error(`O campo ficou com "${valorFinal}" em vez de ${cnpjAtual} (método: ${metodo})`);
    }
    log(`CNPJ preenchido via ${metodo}; valor no campo: "${valorFinal}"`);

    // ETAPA 5: botão "Alterar" ao lado do campo
    log('ETAPA 5: clicar no botão "Alterar" ao lado do CNPJ');
    mostrarAviso('procurando o botão "Alterar"…');
    await sleep(rand(500, 1000));
    const botaoAlterar = await esperar(() => acharBotaoAlterarDoCampo(campo),
      'botão "Alterar" ao lado do campo CNPJ');
    gravarFase('trocou_perfil'); // a página vai recarregar: o script recomeça e retoma daqui
    mostrarAviso('clicando em "Alterar"…');
    await clicarEm(botaoAlterar, 'botão "Alterar" do CNPJ');
    log('clique feito; aguardando o e-CAC trocar o perfil (a página pode recarregar)');
  }

  // Etapas 6 a 8: confere o perfil novo, abre "Consultar informações de seus parcelamentos".
  async function etapasConsulta() {
    log('ETAPA 6: conferir se o e-CAC trocou para o perfil do CNPJ', cnpjAtual);
    mostrarAviso('aguardando o e-CAC trocar de perfil…');
    const perfil = await esperar(perfilTrocado, `cabeçalho "Procurador de: ${cnpjAtual}"`,
      TIMEOUT_TROCA_PERFIL_MS, ['Procurador de:']);
    gravarFase(null);
    log('perfil trocado:', perfil);
    mostrarAviso('perfil trocado. Seguindo…');
    await sleep(rand(1200, 2000)); // "olha" o cabeçalho antes de continuar

    log('ETAPA 7: localizar e clicar em "Consultar informações de seus parcelamentos"');
    mostrarAviso('procurando "Consultar informações de seus parcelamentos"…');
    let alvo;
    try {
      alvo = await esperar(() => acharAlvoTexto(TEXTO_CONSULTAR),
        'link "Consultar informações de seus parcelamentos"', 8000);
    } catch (e0) {
      if (e0.erroSistema) throw e0; // erro do sistema da Receita: quem chamou decide (pula a empresa)
      // não está na tela inicial do Parcelamento (ex.: o perfil foi trocado a partir de uma tela mais funda):
      // volta pelo caminho de navegação do topo
      aviso('não achei o link; voltando à tela inicial pelo caminho de navegação "Parcelamento - Solicitar e acompanhar"');
      mostrarAviso('voltando à tela inicial do Parcelamento…');
      const migalha = await esperar(() => acharAlvoTexto(TEXTO_TELA_INICIAL), 'caminho de navegação "Parcelamento - Solicitar e acompanhar"',
        10000, [TEXTO_TELA_INICIAL]);
      await clicarAlvo(migalha, 'caminho de navegação "Parcelamento - Solicitar e acompanhar"');
      alvo = await esperar(() => acharAlvoTexto(TEXTO_CONSULTAR),
        'link "Consultar informações de seus parcelamentos"', TIMEOUT_ELEMENTO_MS, [TEXTO_CONSULTAR]);
    }
    mostrarAviso('clicando em "Consultar informações de seus parcelamentos"…');
    await clicarAlvo(alvo, 'link "Consultar informações de seus parcelamentos"');

    log('ETAPA 8: aguardar a tela "Consultar negociações"');
    mostrarAviso('aguardando a tela carregar…');
    await esperar(() => existeTexto(TEXTO_TELA_NEGOCIACOES), 'tela "Consultar negociações"',
      30000, [TEXTO_TELA_NEGOCIACOES], undefined, true);
  }

  function pedirAoBackground(msg) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(msg, (resp) => {
          void chrome.runtime.lastError;
          resolve(resp || null);
        });
      } catch (_) { resolve(null); }
    });
  }

  // Captura a tela (sem o aviso e sem a seta, que não fazem parte da página) e salva em PDF.
  async function salvarPdf(pasta) {
    const d = new Date();
    const p2 = (n) => String(n).padStart(2, '0');
    const carimbo = `${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())}_${p2(d.getHours())}-${p2(d.getMinutes())}-${p2(d.getSeconds())}`;
    const nome = `${cnpjAtual}_${carimbo}.pdf`;
    const caixa = document.getElementById('ps-aviso');
    if (caixa) caixa.style.visibility = 'hidden';
    if (cursor.el) cursor.el.style.visibility = 'hidden';
    try {
      await sleep(350); // deixa a tela redesenhar sem a seta e o aviso
      return await pedirAoBackground({ ps: 'capturar', dados: { pasta, nome } });
    } finally {
      if (caixa) caixa.style.visibility = '';
      if (cursor.el) cursor.el.style.visibility = '';
    }
  }

  // Etapas 9 a 11: clica em "Consultar", espera o resultado e, se não houver negociações, salva o PDF.
  async function etapasResultado() {
    log('ETAPA 9: clicar no botão "Consultar"');
    mostrarAviso('tela carregada; procurando o botão "Consultar"…');
    await sleep(rand(1500, 2500)); // deixa a tela assentar
    const botao = await esperar(() => acharAlvoTexto(TEXTO_BOTAO_CONSULTAR), 'botão "Consultar"',
      TIMEOUT_ELEMENTO_MS, [TEXTO_BOTAO_CONSULTAR]);
    await sleep(rand(500, 1000));
    mostrarAviso('clicando em "Consultar"…');
    await clicarAlvo(botao, 'botão "Consultar"');

    log('ETAPA 10: aguardar o resultado da consulta');
    mostrarAviso('aguardando o resultado da consulta…');
    let tipo;
    try {
      // dois resultados conhecidos: a mensagem "Não existem negociações…" ou a tabela de negociações
      tipo = await esperar(async () => {
        if (await existeTexto(TEXTO_SEM_NEGOCIACAO)) return 'sem';
        if (await existeTexto(TEXTO_COL_REQUERIMENTO)) return 'com';
        return null;
      }, 'resultado da consulta (mensagem "Não existem negociações…" ou tabela de negociações)',
      30000, [TEXTO_SEM_NEGOCIACAO, TEXTO_COL_REQUERIMENTO], undefined, true);
    } catch (e) {
      if (e.erroSistema || e.recarregar) throw e; // erro do e-CAC / tela travada: quem chamou decide
      // Resultado desconhecido: para aqui, sem salvar nada e sem clicar em mais nada.
      aviso('o resultado da consulta não é nenhum dos conhecidos:', e.message);
      return { tipo: 'outro' };
    }
    if (tipo === 'com') return { tipo: 'com' };

    log(`ETAPA 11: "Não existem negociações"; salvando a tela em PDF (Downloads/${PASTA_SEM_NEGOCIACAO})`);
    mostrarAviso('sem negociações; salvando o PDF…');
    await sleep(rand(1200, 1800));
    window.scrollTo(0, 0);
    await perguntarFrames({ op: 'topo' });
    await sleep(500);
    const r = await salvarPdf(PASTA_SEM_NEGOCIACAO);
    if (!r || !r.ok) throw new Error(`Não consegui salvar o PDF: ${r ? r.erro : 'sem resposta do service worker'}`);
    log('PDF salvo:', r.caminho);
    return { tipo: 'sem', caminho: r.caminho };
  }

  // Estado da tabela de parcelas (na página ou num iframe), com posições na janela principal.
  async function lerParcelas() {
    const local = serializarParcelas();
    if (local) return { ...local, iframe: null };
    const r = await perguntarFrames({ op: 'parcelas' });
    if (!r || !r.ok) return null;
    const iframe = iframeDeOrigem(r.origem);
    if (!iframe) return null;
    const o = offsetFrameEl(iframe);
    const mv = (b) => b && { left: b.left + o.x, top: b.top + o.y, right: b.right + o.x, bottom: b.bottom + o.y };
    return {
      iframe, idFrame: r.idFrame, sc: mv(r.sc),
      linhas: r.linhas.map((l) => ({ ...l, rect: mv(l.rect), rectCheck: mv(l.rectCheck) })),
    };
  }

  // Regra: entram (1) parcelas "A vencer" com vencimento no mês atual ou no mês anterior (à data de referência) e
  // (2) parcelas "Devedora" (vencidas e não pagas): de qualquer mês, ou só do mês atual/anterior se
  // DEVEDORAS_QUALQUER_MES = false em lista_cnpjs.js.
  function decidirParcelas(linhas, ref) {
    const refMes = ref.getFullYear() * 12 + ref.getMonth();
    const devedorasQualquerMes = typeof DEVEDORAS_QUALQUER_MES === 'undefined' ? true : !!DEVEDORAS_QUALQUER_MES;
    return linhas.map((l) => {
      const m = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec(l.venc);
      const mes = m ? Number(m[3]) * 12 + (Number(m[2]) - 1) : null;
      let escolher = false, motivo;
      if (/^devedora/.test(norm(l.situacao))) {
        if (devedorasQualquerMes || mes === null || mes >= refMes - 1) { escolher = true; motivo = 'Devedora'; }
        else motivo = 'Devedora de mais de um mês atrás (DEVEDORAS_QUALQUER_MES = false)';
        return { ...l, escolher, motivo };
      }
      if (norm(l.situacao) !== 'a vencer') motivo = `situação "${l.situacao}"`;
      else if (mes === null) motivo = 'vencimento ilegível';
      else if (mes === refMes) { escolher = true; motivo = 'A vencer no mês atual'; }
      else if (mes === refMes - 1) { escolher = true; motivo = 'A vencer do mês anterior'; }
      else if (mes > refMes) motivo = 'A vencer de mês futuro';
      else motivo = 'A vencer de mais de um mês atrás';
      return { ...l, escolher, motivo };
    });
  }

  // Mantém o que a seta vai tocar numa zona confortável da tela (nem colado embaixo, nem escondido em cima):
  // rola o quadro (iframe) e/ou a página em gomos suaves, para a PÁGINA ACOMPANHAR a seta e as tabelas, e não
  // só as opções de dentro. `obterRect`: async () => ({ top, bottom, iframe }) em coordenadas da janela principal
  // (iframe = o quadro onde o alvo está, ou null); null = perdi o alvo.
  // `reserva` = px livres que precisam sobrar ABAIXO do alvo (ex.: o menu "Ações" abre para baixo do ícone e some
  // se o ícone estiver colado na borda inferior da tela).
  async function manterNaZonaConfortavel(obterRect, reserva = 0) {
    for (let n = 0; n < 30; n++) {
      const r = await obterRect();
      if (!r) return;
      const H = innerHeight;
      const limiteBase = reserva ? H - 20 : H * 0.72;
      if (r.bottom + reserva <= limiteBase && r.top >= 70) return; // já está numa zona boa
      const centro = (r.top + r.bottom + reserva) / 2; // com reserva, o "alvo" inclui o espaço de baixo
      let dy = clamp(centro - H * 0.5, -220, 220); // leva o centro do alvo para ~metade da tela
      if (Math.abs(dy) < 40) return;
      dy *= rand(0.85, 1);
      const ms = rand(400, 700) * LENTIDAO_MOUSE / 1.5;
      if (!(await rolarParaMover(r, obterRect, dy, ms))) return; // nenhum rolador mexeu o alvo: não rola mais
      await sleep(rand(150, 350));
    }
  }

  // Rola UM gomo e confere que o alvo se mexeu de verdade. Tenta, um a um, os roladores possíveis (primeiro os do
  // quadro, depois os da página principal): se um rolou mas o alvo não saiu do lugar (era o rolador errado, ou
  // uma janela fixa), desfaz e tenta o próximo. true = o alvo andou.
  async function rolarParaMover(r, obterRect, dy, ms) {
    const alvoAndou = async () => {
      await sleep(80);
      const r2 = await obterRect();
      return !!r2 && Math.abs(r2.top - r.top) >= 2;
    };
    if (r.iframe) {
      for (let n = 0; n < 8; n++) {
        const resp = await perguntarFrames({ op: 'rolar-doc', dy, ms, n });
        if (!resp || !resp.ok) break;
        if (resp.moveu) {
          if (await alvoAndou()) return true;
          await perguntarFrames({ op: 'rolar-doc', dy: -resp.real, ms: 250, n });
        }
        if (n + 1 >= resp.total) break;
      }
    }
    for (const sc of rolaveisDoc(document, r.iframe)) {
      const antes = sc.scrollTop;
      if (!(await rolarSuave(sc, dy, ms))) continue;
      const real = sc.scrollTop - antes;
      if (await alvoAndou()) return true;
      await rolarSuave(sc, -real, 250);
    }
    return false;
  }

  // Um gomo de rolagem da página (sem conferir nenhum alvo): o primeiro rolador que andar vale. true = rolou.
  async function rolarPaginaGomo(dy, ms, iframe) {
    if (iframe) {
      for (let n = 0; n < 8; n++) {
        const resp = await perguntarFrames({ op: 'rolar-doc', dy, ms, n });
        if (!resp || !resp.ok) break;
        if (resp.moveu) return true;
        if (n + 1 >= resp.total) break;
      }
    }
    for (const sc of rolaveisDoc(document, iframe)) if (await rolarSuave(sc, dy, ms)) return true;
    return false;
  }

  // Como clicarPonto, mas o ponto é re-lido (`obterPonto`: async () => ({ x, y, ctx })) depois de a tela rolar
  // para o alvo ficar numa zona confortável.
  async function clicarPontoSeguindo(obterPonto, reserva = 0) {
    await manterNaZonaConfortavel(async () => {
      const p = await obterPonto();
      return p && { top: p.y - 12, bottom: p.y + 12, iframe: p.ctx && p.ctx.iframe };
    }, reserva);
    const p = await obterPonto();
    if (!p) throw new Error('Perdi o alvo do clique ao rolar a tela');
    return clicarPonto(p.x, p.y, p.ctx);
  }

  // Move a seta até (px, py) e clica ali; `ctx` = {iframe, idFrame} quando o ponto está num iframe.
  async function clicarPonto(px, py, ctx) {
    await moverPara(px, py);
    pulso();
    if (ctx && ctx.iframe) {
      const o = offsetFrameEl(ctx.iframe);
      const lx = cursor.x - o.x, ly = cursor.y - o.y;
      await perguntarFrames({ op: 'mover', idFrame: ctx.idFrame, x: lx, y: ly });
      const r = await perguntarFrames({ op: 'clicar', idFrame: ctx.idFrame, x: lx, y: ly });
      return !!(r && r.ok);
    }
    const alvo = sobCursor();
    if (!alvo) return false;
    disparar(alvo, 'pointerdown'); disparar(alvo, 'mousedown');
    await sleep(rand(90, 190));
    disparar(alvo, 'pointerup'); disparar(alvo, 'mouseup');
    disparar(alvo, 'click', { detail: 1 });
    return true;
  }

  // Etapas 21 a 25: rola a tabela de parcelas até as "A vencer" do mês anterior e do mês atual, analisa
  // com calma e marca as caixas dessas parcelas. Para aí, sem clicar em "Emitir DARF de parcela".
  async function etapasSelecao() {
    const ref = DATA_REFERENCIA ? new Date(`${DATA_REFERENCIA}T12:00:00`) : new Date();
    const mesAno = (d) => `${String(d.getMonth() + 1).padStart(2, '0')}/${d.getFullYear()}`;
    const anterior = new Date(ref.getFullYear(), ref.getMonth() - 1, 1);
    log(`ETAPA 21: ler as parcelas. Hoje = ${ref.toLocaleDateString('pt-BR')}; valem as "A vencer" de ${mesAno(anterior)} (mês anterior) e ${mesAno(ref)} (mês atual) e as "Devedora"`);
    mostrarAviso('lendo as parcelas da tabela…');
    let info = await esperar(lerParcelas, 'linhas da tabela "Parcelas da negociação"',
      TIMEOUT_ELEMENTO_MS, [TEXTO_BLOCO_PARCELAS]);

    const decisoes = decidirParcelas(info.linhas, ref);
    const alvos = decisoes.filter((d) => d.escolher);
    const aVencer = decisoes.filter((d) => norm(d.situacao) === 'a vencer');
    const devedoras = decisoes.filter((d) => /^devedora/.test(norm(d.situacao)));
    log(`${decisoes.length} parcelas lidas; ${aVencer.length} "A vencer"; ${devedoras.length} "Devedora". Decisão (devedoras e as "A vencer" mais próximas):`);
    devedoras.concat(aVencer.slice(0, 6)).forEach((d) =>
      log(`  parcela ${d.parcela} | venc. ${d.venc} | ${d.situacao} | ${d.escolher ? 'ESCOLHER' : 'ignorar'} (${d.motivo})`));
    if (!alvos.length) {
      return { texto: 'Nenhuma parcela "A vencer" do mês atual ou do mês anterior, nem "Devedora"; não marquei nada', marcadas: 0 };
    }
    const idx = alvos.map((a) => a.i);
    const nomes = alvos.map((a) => `${a.parcela} (${a.venc})`).join(', ');

    log(`ETAPA 22: rolar a tabela até as parcelas escolhidas: ${nomes}`);
    mostrarAviso('rolando a tabela até as parcelas escolhidas ("A vencer" e "Devedora")…');
    // a PÁGINA acompanha a tabela: leva a tabela de parcelas para uma zona confortável da tela antes de rolá-la por dentro
    await manterNaZonaConfortavel(async () => {
      const i = await lerParcelas();
      return i && { top: i.sc.top, bottom: i.sc.bottom, iframe: i.iframe };
    });
    info = (await lerParcelas()) || info;
    const sc0 = info.sc; // seta sobre a tabela, como quem usa a roda do mouse sobre ela
    await moverPara(sc0.left + (sc0.right - sc0.left) * rand(0.3, 0.6), sc0.top + (sc0.bottom - sc0.top) * rand(0.4, 0.65));
    // Leva as linhas `lista` (índices na tabela inteira) à vista, rolando POR DENTRO da tabela de parcelas aos poucos.
    // `noAlto`: exige a 1ª linha na metade de cima da tabela (ao chegar); sem isso basta estarem à vista.
    const levarAVista = async (lista, noAlto) => {
      let parado = 0;
      for (let k = 0; k < 120; k++) {
        const cur = await lerParcelas();
        if (!cur) { await sleep(500); continue; }
        const sc = cur.sc, altura = sc.bottom - sc.top;
        const prim = cur.linhas[lista[0]], ult = cur.linhas[lista[lista.length - 1]];
        const dentro = prim.rect.top >= sc.top - 1 && ult.rect.bottom <= sc.bottom + 1;
        if (dentro && (!noAlto || prim.rect.top <= sc.top + altura * 0.5)) return; // já estão à vista
        const dy = (prim.rect.top < sc.top ? -1 : 1) * rand(70, 150);
        const ms = rand(380, 650) * LENTIDAO_MOUSE / 1.5;
        let moveu;
        if (cur.iframe) {
          const r = await perguntarFrames({ op: 'parcelas-rolar', dy, ms });
          moveu = !!(r && r.ok && r.moveu);
        } else {
          moveu = await rolarGrade(dy, ms);
        }
        parado = moveu ? 0 : parado + 1;
        if (parado >= 3) {
          if (dentro) return; // não rola mais, mas as parcelas estão à vista
          throw new Error('A tabela não rolou até as parcelas escolhidas');
        }
        await sleep(rand(200, 500) + (Math.random() < 0.25 ? rand(400, 900) : 0));
      }
    };
    // Se todas as escolhidas cabem de uma vez na tabela, leva o grupo; senão (ex.: devedoras antigas e "A vencer"
    // recentes, muito afastadas) vai até a 1ª e, mais adiante, cada parcela é levada à vista na hora de analisar/marcar.
    const linhasIdx = info.linhas;
    const cabemJuntas = (linhasIdx[idx[idx.length - 1]].rect.bottom - linhasIdx[idx[0]].rect.top) <= (info.sc.bottom - info.sc.top) - 4;
    await levarAVista(cabemJuntas ? idx : [idx[0]], true);

    log('ETAPA 23: analisar com calma as parcelas escolhidas');
    mostrarAviso('analisando as parcelas escolhidas ("A vencer" e "Devedora")…');
    await sleep(rand(3000, 4500));
    for (const a of alvos) {
      await levarAVista([a.i]);
      info = await lerParcelas();
      const l = info.linhas[a.i];
      await moverPara(l.rect.left + (l.rect.right - l.rect.left) * rand(0.25, 0.5), (l.rect.top + l.rect.bottom) / 2);
      await sleep(rand(1500, 2500));
    }

    log('ETAPA 24: marcar as caixas de seleção das parcelas escolhidas');
    for (const a of alvos) {
      await levarAVista([a.i]); // com parcelas afastadas, leva cada uma à vista antes de clicar
      info = await lerParcelas();
      if (!info.linhas[a.i].temCheck) throw new Error(`A parcela ${a.parcela} não tem caixa de seleção`);
      if (info.linhas[a.i].marcado) { log(`parcela ${a.parcela} já estava marcada`); continue; }
      mostrarAviso(`marcando a parcela ${a.parcela} (${a.venc})…`);
      let ok = false;
      for (let tent = 0; tent < 2 && !ok; tent++) {
        log(`clicando na caixa da parcela ${a.parcela}${tent ? ' (2ª tentativa)' : ''}`);
        await clicarPontoSeguindo(async () => { // posição re-lida depois de cada rolagem da página
          const cur = (await lerParcelas()) || info;
          const c = cur.linhas[a.i].rectCheck;
          return {
            x: c.left + (c.right - c.left) * rand(0.35, 0.65),
            y: c.top + (c.bottom - c.top) * rand(0.35, 0.65),
            ctx: cur,
          };
        });
        await sleep(rand(600, 1000));
        info = (await lerParcelas()) || info;
        ok = info.linhas[a.i].marcado;
      }
      if (!ok) {
        aviso(`o clique não marcou a parcela ${a.parcela}; marcando direto na caixa`);
        if (info.iframe) await perguntarFrames({ op: 'parcela-forcar', indice: a.i });
        else forcarCheckParcela(a.i);
        await sleep(rand(600, 1000));
        info = (await lerParcelas()) || info;
        ok = info.linhas[a.i].marcado;
      }
      if (!ok) throw new Error(`A parcela ${a.parcela} (${a.venc}) não ficou marcada`);
      await sleep(rand(1200, 2200));
    }

    log('ETAPA 25: conferir as marcações');
    info = await lerParcelas();
    const marcadas = info.linhas.filter((l) => l.marcado).map((l) => l.i);
    if (marcadas.length !== idx.length || !idx.every((i) => marcadas.includes(i))) {
      throw new Error(`As parcelas marcadas (${marcadas.map((i) => info.linhas[i].parcela).join(', ') || 'nenhuma'}) ` +
        `não batem com as esperadas (${alvos.map((a) => a.parcela).join(', ')})`);
    }
    return { texto: `Parcelas marcadas: ${nomes}`, marcadas: idx.length };
  }

  // Etapas 26 a 29: clica em "Emitir DARF de parcela", espera a tela "Emissão de DARF", rola até
  // "Imprimir DARF", clica e acompanha o PDF que a página gera; o service worker guarda esse PDF em
  // Downloads/<PASTA_COM_NEGOCIACAO>/<CNPJ>.pdf. Devolve o caminho do arquivo.
  // `k`/`total`: com mais de uma negociação o PDF leva o número da negociação (<CNPJ>_1.pdf, <CNPJ>_2.pdf…).
  // `jaNaTelaDeEmissao`: o "Confirmar" levou direto à tela "Emissão de DARF" (sem tabela de parcelas), então
  // não há "Emitir DARF de parcela" para clicar: começa já no "Imprimir DARF".
  async function etapasEmissao(k = 0, total = 1, jaNaTelaDeEmissao = false) {
    if (!jaNaTelaDeEmissao) {
      log('ETAPA 26: clicar em "Emitir DARF de parcela"');
      mostrarAviso('procurando o botão "Emitir DARF de parcela"…');
      await sleep(rand(1500, 2500));
      const botao = await esperar(async () => {
        const a = await acharAlvoTexto(TEXTO_BOTAO_EMITIR);
        return a && !a.desabilitado ? a : null;
      }, 'botão "Emitir DARF de parcela" habilitado', 20000, [TEXTO_BOTAO_EMITIR]);

      mostrarAviso('clicando em "Emitir DARF de parcela"…');
      await sleep(rand(800, 1500));
      await clicarAlvo(botao, 'botão "Emitir DARF de parcela"');

      log('ETAPA 27: aguardar a tela "Emissão de DARF"');
      mostrarAviso('aguardando a tela de emissão do DARF…');
      await esperar(() => acharAlvoTexto(TEXTO_BOTAO_IMPRIMIR), 'botão "Imprimir DARF" na tela "Emissão de DARF"',
        30000, [TEXTO_TELA_EMISSAO], undefined, true);
    }
    await sleep(rand(2500, 4000)); // olha a tela (parcelas e total) antes de agir

    log('ETAPA 28: rolar até "Imprimir DARF" e clicar');
    mostrarAviso('rolando até o botão "Imprimir DARF"…');
    let imprimir = await rolarAteAlvoVisivel(TEXTO_BOTAO_IMPRIMIR);
    if (!imprimir) throw new Error('Perdi o botão "Imprimir DARF" ao rolar a tela');
    await sleep(rand(1000, 1800)); // olha o botão antes de ir até ele

    // só agora o salvamento é armado: o PDF sai quando se clica em "Imprimir DARF" (nunca em "Pagar DARF online")
    const nome = total > 1 ? `${cnpjAtual}_${k + 1}.pdf` : `${cnpjAtual}.pdf`;
    for (let tentativa = 1; ; tentativa++) {
      const armou = await pedirAoBackground({ ps: 'armar-darf', dados: { pasta: PASTA_COM_NEGOCIACAO, nome } });
      if (!armou || !armou.ok) {
        throw new Error(`Não consegui preparar o salvamento do PDF: ${armou ? armou.erro : 'sem resposta do service worker'}`);
      }
      mostrarAviso(tentativa > 1 ? 'clicando de novo em "Imprimir DARF"…' : 'clicando em "Imprimir DARF"…');
      await clicarAlvo(imprimir, 'botão "Imprimir DARF"');

      log(`ETAPA 29: aguardar o PDF (será salvo em Downloads/${PASTA_COM_NEGOCIACAO}/${nome})`);
      mostrarAviso('aguardando o PDF do DARF…');
      try {
        return await aguardarPdfDoDarf();
      } catch (e) {
        // faixa "Não foi possível concluir a ação...": tenta mais uma vez, depois de uma pausa; se repetir, desiste
        // só desta negociação (as outras da empresa continuam)
        if (!(e.erroSistema && e.tipo === 'negociacao') || tentativa >= 2) throw e;
        aviso(`o e-CAC recusou a emissão ("${e.faixa}"); esperando e tentando de novo`);
        mostrarAviso(`o e-CAC recusou a emissão ("${e.faixa}"). Esperando alguns segundos para tentar de novo…`);
        await sleep(rand(8000, 12000));
        imprimir = (await rolarAteAlvoVisivel(TEXTO_BOTAO_IMPRIMIR)) || imprimir;
        await sleep(rand(1000, 1800));
      }
    }
  }

  // Espera o PDF do DARF ser salvo (até 60 s). Se o e-CAC responder com uma faixa de erro em vez do PDF, para na hora.
  async function aguardarPdfDoDarf() {
    const t0 = Date.now();
    let st = null;
    for (;;) {
      st = await pedirAoBackground({ ps: 'status-darf' });
      if (st && (st.estado === 'ok' || st.estado === 'erro')) break;
      // nos primeiros 20 s só conta faixa NOVA (uma antiga que ficou na tela não é resposta a este clique)
      const faixa = await lerErroSistema(Date.now() - t0 < 20000);
      if (faixa) throw erroSistema(faixa, 'o PDF do DARF');
      if (Date.now() - t0 > 45000) {
        // a tela ficou "carregando" e o PDF não saiu: atualiza a página e refaz esta negociação
        const e = new Error('O PDF do DARF não saiu em 45 s (a tela ficou carregando sem concluir)');
        e.recarregar = true;
        throw e;
      }
      await sleep(1000);
    }
    log('situação do PDF:', st);
    if (!st || st.estado !== 'ok') {
      const aba = st && st.novaAba ? ` Nova aba aberta pela página: ${st.novaAba.url || '(sem endereço)'}.` : '';
      throw new Error(`O PDF do DARF não foi salvo (${st ? st.estado : 'sem resposta'}${st && st.detalhe ? ': ' + st.detalhe : ''}).` +
        `${aba} Veja na tela se apareceu alguma mensagem ou janela depois do clique.`);
    }
    if (st.detalhe) aviso(st.detalhe);
    return st.caminho;
  }

  // Estado da tabela de negociações (na página ou num iframe), com posições na janela principal.
  async function lerGradeNegociacoes() {
    const local = serializarNegociacoes();
    if (local) return { ...local, iframe: null };
    const r = await perguntarFrames({ op: 'neg-estado' });
    if (!r || !r.ok) return null;
    const iframe = iframeDeOrigem(r.origem);
    if (!iframe) return null;
    const o = offsetFrameEl(iframe);
    const mv = (b) => b && { left: b.left + o.x, top: b.top + o.y, right: b.right + o.x, bottom: b.bottom + o.y };
    return {
      iframe, idFrame: r.idFrame, sc: mv(r.sc), paginaInteira: !!r.paginaInteira,
      linhas: r.linhas.map((l) => ({ ...l, rect: mv(l.rect), rectIcone: mv(l.rectIcone) })),
    };
  }

  async function lerIdNegociacaoTela() {
    const local = idNegociacaoTelaLocal();
    if (local) return local;
    const r = await perguntarFrames({ op: 'neg-tela' });
    return r && r.ok ? r.id : null;
  }

  // Confere o espaço da tela para a tabela de negociações e o menu "Ações" (que abre para baixo): a tabela precisa
  // ficar com RESERVA_MENU_PX livres abaixo dela e o topo não pode ser empurrado para fora da tela. Se falta espaço
  // embaixo, desce a tela em gomos pequenos, com pausa entre eles. O movimento é sempre numa direção só (só sobe se o
  // topo da tabela estiver cortado), então não há vai-e-vem. Se a tabela não tem rolagem própria (a página inteira é
  // a tabela), não faz nada: o clique no ícone já reserva o espaço.
  async function ajustarPaginaParaTabela(id, k, total) {
    mostrarAviso(`negociação ${id} (linha ${k + 1} de ${total}): conferindo o espaço da tela…`);
    await sleep(rand(1200, 2000));
    for (let n = 0; n < 12; n++) {
      const g = await lerGradeNegociacoes();
      if (!g || g.paginaInteira) return;
      const H = innerHeight, sc = g.sc;
      const faltaBaixo = sc.bottom + RESERVA_MENU_PX - (H - 20); // > 0: tabela + menu não cabem embaixo
      const cortadoEmCima = 70 - sc.top;                          // > 0: topo da tabela colado/cortado
      let dy = 0;
      if (faltaBaixo > 0) dy = Math.min(faltaBaixo, Math.max(0, sc.top - 70)); // desce sem empurrar o topo para fora
      else if (cortadoEmCima > 0) dy = -cortadoEmCima;
      if (Math.abs(dy) < 8) {
        log(`espaço conferido: tabela de ${Math.round(sc.top)} a ${Math.round(sc.bottom)} px, tela de ${H} px: está no lugar certo`);
        return;
      }
      dy = clamp(dy, -120, 120); // um gomo pequeno por vez
      log(`espaço: tabela de ${Math.round(sc.top)} a ${Math.round(sc.bottom)} px, tela de ${H} px; ` +
        `${dy > 0 ? 'descendo' : 'subindo'} a tela ${Math.round(Math.abs(dy))} px`);
      mostrarAviso(`negociação ${id}: ${dy > 0 ? 'descendo' : 'subindo'} a tela para a tabela e o menu caberem…`);
      const obter = async () => { const g2 = await lerGradeNegociacoes(); return g2 && { top: g2.sc.top, bottom: g2.sc.bottom, iframe: g2.iframe }; };
      const andou = await rolarParaMover({ top: sc.top, bottom: sc.bottom, iframe: g.iframe }, obter, dy, rand(500, 800) * LENTIDAO_MOUSE / 1.5);
      if (!andou) { log('a tela não rola mais; seguindo com o espaço que há'); return; }
      await sleep(rand(900, 1500));
    }
  }

  // Abre o menu "Ações" da negociação da linha `k` (0 = primeira). A linha é achada pela POSIÇÃO NA TABELA (e
  // conferida pelo número da negociação), não pela posição na tela: com a tabela rolada por dentro, as primeiras
  // linhas somem por cima do cabeçalho, e contar só o que aparece faria acertar a linha errada.
  async function abrirMenuDaNegociacao(k, idEsperado) {
    let info = await esperar(lerGradeNegociacoes, 'tabela de negociações', TIMEOUT_ELEMENTO_MS, [TEXTO_COL_ACOES]);
    if (!info.linhas[k]) {
      throw new Error(`A tabela tem ${info.linhas.length} linha(s); não achei a linha ${k + 1} (negociação ${idEsperado || '?'})`);
    }
    if (idEsperado && !idEsperado.startsWith('#') && info.linhas[k].id !== idEsperado) {
      throw new Error(`A linha ${k + 1} da tabela é a negociação ${info.linhas[k].id}, mas eu esperava ${idEsperado}; a tabela mudou. Parei por segurança.`);
    }
    const id = info.linhas[k].id;
    log(`negociação ${id}: linha ${k + 1} de ${info.linhas.length} da tabela`);

    // 0) a PÁGINA acompanha a tabela, UMA vez e com calma: confere o espaço e, se a tabela estiver colada embaixo
    //    (sem sobrar lugar para o menu abrir), desce a tela aos poucos. Nunca vai e volta.
    await ajustarPaginaParaTabela(id, k, info.linhas.length);

    // 1) rola a tabela (por dentro dela) LINHA A LINHA até a linha inteira ficar à vista, sem cortes pelo cabeçalho
    //    ou pela borda. Cada gomo anda no máximo a altura de UMA linha (e só o que falta, sem passar do ponto), e
    //    depois de cada um a automação para um pouco para "olhar" a tabela.
    let parado = 0, dirAnterior = 0;
    for (let n = 0; n < 120; n++) {
      info = (await lerGradeNegociacoes()) || info;
      const l = info.linhas[k], sc = info.sc;
      // Tolerância de ~2 px nos DOIS lados: com a tabela no topo (ou no fim) a linha fica exatamente encostada na
      // borda e isso já é "à vista". (Exigir folga fazia a primeira linha ser empurrada para fora e a tabela
      // rolar para cima e para baixo sem parar.)
      const TOL = 2;
      const linhaInteira = l.rect.top >= sc.top - TOL && l.rect.bottom <= sc.bottom + TOL;
      const iconeVisivel = !!l.rectIcone && l.rectIcone.top >= sc.top - TOL && l.rectIcone.bottom <= sc.bottom + TOL;
      if (linhaInteira) break;
      if (parado >= 2 && iconeVisivel) break; // no fim da tabela a linha pode ficar cortada por 1-2 px: o ícone basta
      const dir = l.rect.top < sc.top - TOL ? -1 : 1;
      if (dirAnterior && dir !== dirAnterior) { // virou de direção: está oscilando; o ícone à vista basta
        if (iconeVisivel) break;
        throw new Error(`A tabela oscilou ao rolar até a negociação ${id} (linha ${k + 1}) e o ícone de "Ações" não ficou à vista`);
      }
      dirAnterior = dir;
      const alturaLinha = Math.max(30, l.rect.bottom - l.rect.top);
      const falta = dir > 0 ? l.rect.bottom - sc.bottom + 4 : l.rect.top - sc.top - 4; // já com o sinal certo
      const dy = clamp(falta, -alturaLinha, alturaLinha); // de 1 em 1 linha, sem passar do ponto
      const ms = rand(450, 700) * LENTIDAO_MOUSE / 1.5;
      const restam = Math.max(1, Math.ceil(Math.abs(falta) / alturaLinha));
      mostrarAviso(`rolando a tabela, linha a linha: indo para a negociação ${id} (linha ${k + 1} de ${info.linhas.length}); ` +
        `${dir > 0 ? 'descendo' : 'subindo'}, faltam ~${restam} linha(s)…`);
      if (n === 0) log(`rolando a tabela linha a linha (${Math.round(alturaLinha)} px por gomo) até a linha ${k + 1} de ${info.linhas.length}`);
      let moveu;
      if (info.iframe) {
        const r = await perguntarFrames({ op: 'neg-rolar', dy, ms });
        moveu = !!(r && r.ok && r.moveu);
      } else {
        moveu = await rolarGradeNeg(dy, ms);
      }
      parado = moveu ? 0 : parado + 1;
      if (parado >= 3 && !iconeVisivel) throw new Error(`A tabela não rolou até a negociação ${id} (linha ${k + 1})`);
      if (parado >= 3) break;
      await sleep(rand(800, 1500) * LENTIDAO_MOUSE / 1.5); // para e "olha" a tabela antes do próximo gomo
    }

    // 2) vai até o ícone da linha certa (a página rola, se precisar, para ele ficar numa zona confortável) e clica
    mostrarAviso(`abrindo o menu de "Ações" da negociação ${id}…`);
    await sleep(rand(800, 1500));
    await marcarErrosVistos();
    log(`clicando no ícone de "Ações" da linha ${k + 1} (negociação ${id})`);
    // O menu abre PARA BAIXO do ícone: a página rola até sobrar RESERVA_MENU_PX livres abaixo dele (ícone colado
    // na borda de baixo da tela = menu cortado / clique que não acerta nada).
    const clicou = await clicarPontoSeguindo(async () => {
      const g = (await lerGradeNegociacoes()) || info;
      const ic = g.linhas[k] && g.linhas[k].rectIcone;
      if (!ic) throw new Error(`Perdi o ícone de "Ações" da linha ${k + 1} (negociação ${id})`);
      return {
        x: ic.left + (ic.right - ic.left) * rand(0.35, 0.65),
        y: ic.top + (ic.bottom - ic.top) * rand(0.35, 0.65),
        ctx: g,
      };
    }, RESERVA_MENU_PX);
    if (!clicou) aviso(`o clique no ícone de "Ações" da linha ${k + 1} não acertou nenhum elemento (ícone fora da tela?)`);
  }

  // As negociações listadas pela consulta (na página ou num iframe): lista de { id, situacao }; null = sem tabela.
  async function listarNegociacoes() {
    const local = listarNegociacoesLocal();
    if (local) return local;
    const r = await perguntarFrames({ op: 'negociacoes' });
    return r && r.ok ? r.lista : null;
  }

  // Depois de emitir o DARF de uma negociação, volta para a tela "Consultar negociações" (pelo caminho de
  // navegação do topo), consulta de novo e espera a tabela, para abrir a próxima negociação.
  async function voltarParaConsulta() {
    log('voltando para "Consultar negociações" para fazer a próxima negociação');
    mostrarAviso('voltando para consultar a próxima negociação…');
    await sleep(rand(2000, 3500));
    const migalha = await esperar(() => acharAlvoTexto(TEXTO_CONSULTAR),
      'caminho de navegação "Consultar informações de seus parcelamentos"', 15000, [TEXTO_CONSULTAR]);
    await clicarAlvo(migalha, 'caminho de navegação "Consultar informações de seus parcelamentos"');
    await esperar(() => existeTexto(TEXTO_TELA_NEGOCIACOES), 'tela "Consultar negociações"',
      30000, [TEXTO_TELA_NEGOCIACOES], undefined, true);
    const r = await etapasResultado();
    if (r.tipo !== 'com') {
      throw new Error('Ao consultar de novo, o resultado não foi a tabela de negociações (resultado: ' + r.tipo + ')');
    }
  }

  // Lê o bloco "Deseja emitir DARF…" (na página ou num iframe): opções com rótulo e estado, e onde está.
  async function lerDarf() {
    const local = lerBlocoDarf();
    if (local) return { opcoes: local.opcoes, el: local.leg };
    const r = await perguntarFrames({ op: 'darf' });
    if (!r || !r.ok) return null;
    const iframe = iframeDeOrigem(r.origem);
    return iframe ? { opcoes: r.opcoes, iframe, rect: r.rect } : null;
  }

  // Rola (em gomos suaves, como a roda do mouse) até o botão/link `texto` ficar bem à vista, longe das
  // bordas da tela (e de barras que o cobrem, como o rodapé "Voltar"). Devolve o alvo já atualizado.
  async function rolarAteAlvoVisivel(texto, modo = 'texto') {
    const MARGEM_TOPO = 100, MARGEM_BASE = 100; // px livres acima e abaixo do botão
    let parado = 0, alvo = null;
    for (let i = 0; i < 40; i++) {
      alvo = await acharAlvoTexto(texto, modo, true);
      if (!alvo) { await sleep(400); continue; }
      let r;
      if (alvo.el) { r = rectAbs(alvo.el); }
      else {
        const o = offsetFrameEl(alvo.iframe);
        r = { top: o.y + alvo.rect.top, bottom: o.y + alvo.rect.top + alvo.rect.height };
      }
      if (r.top >= MARGEM_TOPO && r.bottom <= innerHeight - MARGEM_BASE) return alvo; // já está bem à vista
      const dy = (r.top < MARGEM_TOPO ? -1 : 1) * rand(80, 160);
      const ms = rand(400, 700) * LENTIDAO_MOUSE / 1.5;
      let moveu = false;
      if (alvo.el) moveu = await rolarSuave(rolavelAcima(alvo.el), dy, ms);
      else {
        const resp = await perguntarFrames({ op: 'rolar-el', texto, modo, dy, ms });
        moveu = !!(resp && resp.ok && resp.moveu);
      }
      if (!moveu) moveu = await rolarPaginaGomo(dy, ms, alvo.el ? null : alvo.iframe); // rola a página (todos os roladores)
      parado = moveu ? 0 : parado + 1;
      if (parado >= 3) break; // não rola mais: segue com o que dá
      await sleep(rand(200, 450));
    }
    return alvo;
  }

  // Posição (na janela principal) de um texto, na página ou num iframe, sem rolar nada.
  async function rectDoTexto(texto, exato = false) {
    const el = acharTextoProprio(texto, exato);
    if (el) {
      const r = rectAbs(el);
      return { el, left: r.left, top: r.top, width: r.width, height: r.height };
    }
    const r = await perguntarFrames({ op: 'texto-rect', texto, exato });
    if (!r || !r.ok) return null;
    const iframe = iframeDeOrigem(r.origem);
    if (!iframe) return null;
    const o = offsetFrameEl(iframe);
    return { iframe, left: o.x + r.rect.left, top: o.y + r.rect.top, width: r.rect.width, height: r.rect.height };
  }

  // Desce como quem gira a roda do mouse: "gomos" suaves de 110-230 px (0,45-0,8 s cada, com
  // aceleração e desaceleração) e pausas entre eles, até o título ficar na parte de cima da tela.
  // O texto tem de ser exato (o título do bloco, não uma frase que o cita). Devolve a posição final.
  async function rolarAteTexto(texto) {
    await moverPara(innerWidth * rand(0.45, 0.6), innerHeight * rand(0.5, 0.65)); // seta sobre o conteúdo
    let ultimoTop = null, parado = 0;
    for (let i = 0; i < 80; i++) {
      const p = await rectDoTexto(texto, true);
      if (!p) { await sleep(500); continue; } // ainda não carregou
      if (p.top >= 90 && p.top <= innerHeight * 0.6) return p;
      parado = ultimoTop !== null && Math.abs(p.top - ultimoTop) < 1 ? parado + 1 : 0;
      ultimoTop = p.top;
      // sem como rolar mais: se o texto já está inteiro na tela, serve
      if (parado >= 3 && p.top >= 60 && p.top <= innerHeight - 120) return p;
      const dy = (p.top < 90 ? -1 : 1) * rand(110, 230);
      const ms = rand(450, 800) * LENTIDAO_MOUSE / 1.5;
      let moveu = false;
      if (p.iframe) { // primeiro rola o conteúdo do frame; se ele já não rola, rola a página
        const r = await perguntarFrames({ op: 'rolar', texto, exato: true, dy, ms, forcar: parado >= 2 });
        moveu = !!(r && r.ok && r.moveu);
      } else if (parado >= 2) {
        p.el.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'nearest' });
        moveu = true;
      }
      if (!moveu) await rolarSuave(document.scrollingElement || document.documentElement, dy, ms);
      // pausa entre os gomos; de vez em quando uma maior, como quem "olha" o que passou
      await sleep(rand(150, 400) + (Math.random() < 0.2 ? rand(500, 1100) : 0));
    }
    throw new Error(`Não consegui rolar até o bloco "${texto}"`);
  }

  async function lerTabela() {
    const t = lerTabelaParcelas();
    if (t) return { colunas: t.colunas, linhas: t.linhas };
    const r = await perguntarFrames({ op: 'tabela' });
    return r && r.ok ? { colunas: r.colunas, linhas: r.linhas } : null;
  }

  // Etapas 16 a 20: escolhe "Parcela", clica em "Confirmar", espera a tela de parcelas, desce até o
  // bloco "Parcelas da negociação" e o analisa. Para aí, sem clicar em mais nada.
  async function etapasParcelas() {
    log('ETAPA 16: escolher a opção do bloco DARF');
    await sleep(rand(2500, 4000)); // pensa antes de escolher
    // resumo das opções lidas, para explicar uma falha na tela
    const descreverOpcoes = (l) => l
      ? l.opcoes.map((o) => `[${o.texto || 'sem rótulo'}|${o.marcado ? 'marcada' : 'desmarcada'}|${o.visivel ? 'visível' : 'escondida'}${o.id ? '|id=' + o.id : ''}]`).join(' ')
      : 'bloco não lido';
    // qual opção escolher: a primeira da lista de preferência que existir no bloco ("Parcela" ou "Primeira parcela")
    const lidoInicial = await esperar(lerDarf, 'bloco "Deseja emitir DARF para pagamento de"',
      TIMEOUT_ELEMENTO_MS, [TEXTO_DARF_BLOCO]);
    const rotulosDoBloco = lidoInicial.opcoes.map((o) => norm(o.texto));
    const escolha = OPCOES_DARF_PREFERIDAS.find((t) => rotulosDoBloco.includes(norm(t)));
    log(`opções do bloco: ${lidoInicial.opcoes.map((o) => o.texto || '(sem rótulo)').join(' | ')}; escolho: ${escolha ? `"${escolha}"` : '(nenhuma conhecida)'}`);
    if (!escolha) {
      throw new Error(`Nenhuma das opções esperadas (${OPCOES_DARF_PREFERIDAS.map((t) => `"${t}"`).join(' ou ')}) está no bloco DARF | rádios lidos: ${descreverOpcoes(lidoInicial)}`);
    }
    mostrarAviso(`escolhendo "${escolha}"…`);
    const opcaoMarcada = async () => {
      const l = await lerDarf();
      const o = l && l.opcoes.find((x) => norm(x.texto) === norm(escolha));
      return !!(o && o.marcado);
    };
    let radio;
    try {
      radio = await esperar(() => acharAlvoTexto(escolha, 'radio'),
        `opção "${escolha}" do bloco DARF`, TIMEOUT_ELEMENTO_MS, [escolha, TEXTO_DARF_BLOCO]);
    } catch (e) {
      if (e.erroSistema) throw e;
      throw new Error(`${e.message} | rádios lidos: ${descreverOpcoes(await lerDarf())}`);
    }
    await clicarAlvo(radio, `opção "${escolha}"`);
    await sleep(rand(600, 1000));
    if (!(await opcaoMarcada())) {
      // o clique não marcou (rádio com visual próprio): tenta de novo e, por fim, marca direto no rádio
      aviso(`o clique não marcou "${escolha}"; tentando de novo`);
      const outra = await acharAlvoTexto(escolha, 'radio');
      if (outra) await clicarAlvo(outra, `opção "${escolha}" (2ª tentativa)`);
      await sleep(rand(600, 1000));
    }
    if (!(await opcaoMarcada())) {
      aviso('ainda não marcou; marcando direto no rádio');
      if (!lerBlocoDarf()) await perguntarFrames({ op: 'forcar-radio', texto: escolha });
      else forcarRadioDarf(escolha);
      await sleep(rand(600, 1000));
    }
    if (!(await opcaoMarcada())) {
      throw new Error(`A opção "${escolha}" não ficou marcada | rádios lidos: ${descreverOpcoes(await lerDarf())}`);
    }
    log(`opção "${escolha}" marcada`);

    log('ETAPA 17: clicar no botão "Confirmar"');
    mostrarAviso('procurando o botão "Confirmar"…');
    await sleep(rand(1500, 2500));
    await esperar(() => acharAlvoTexto(TEXTO_BOTAO_CONFIRMAR), 'botão "Confirmar"',
      TIMEOUT_ELEMENTO_MS, [TEXTO_BOTAO_CONFIRMAR]);
    mostrarAviso('rolando até o botão "Confirmar" aparecer bem…');
    const confirmar = await rolarAteAlvoVisivel(TEXTO_BOTAO_CONFIRMAR);
    if (!confirmar) throw new Error('Perdi o botão "Confirmar" ao rolar a tela');
    await sleep(rand(1000, 1800)); // olha o botão antes de ir até ele
    mostrarAviso('clicando em "Confirmar"…');
    await clicarAlvo(confirmar, 'botão "Confirmar"');

    log('ETAPA 18: aguardar a tela seguinte ao "Confirmar"');
    mostrarAviso('aguardando a tela carregar…');
    // Duas telas possíveis: "Demonstrativo de parcelas" (com a tabela de parcelas, caso normal) ou direto a
    // "Emissão de DARF" (botão "Imprimir DARF"), sem tabela. No caminho "Primeira parcela" ainda não sabemos qual vem:
    // se demorar sem aparecer nenhuma das duas, PARA com o motivo em vez de recarregar a página.
    const telaSeguinte = await esperar(async () => {
      if (await existeTexto(TEXTO_TELA_EXTRATO)) return 'parcelas';
      if (await acharAlvoTexto(TEXTO_BOTAO_IMPRIMIR)) return 'emissao';
      return null;
    }, 'tela seguinte ao "Confirmar" ("Demonstrativo de parcelas" ou "Emissão de DARF")',
    30000, [TEXTO_TELA_EXTRATO, TEXTO_TELA_EMISSAO], undefined, norm(escolha) === norm(TEXTO_RADIO_PARCELA));
    if (telaSeguinte === 'emissao') {
      log('a tela seguinte já é a "Emissão de DARF" (sem tabela de parcelas): sigo direto para o "Imprimir DARF"');
      await sleep(rand(2500, 4000));
      return { texto: `Opção "${escolha}": foi direto para a emissão, sem tabela de parcelas`, direto: true };
    }
    await sleep(rand(2500, 4000)); // olha a tela antes de descer

    log('ETAPA 19: descer até o bloco "Parcelas da negociação"');
    mostrarAviso('descendo até "Parcelas da negociação"…');
    await rolarAteTexto(TEXTO_BLOCO_PARCELAS);
    await sleep(rand(1500, 2500));

    log('ETAPA 20: analisar o bloco "Parcelas da negociação"');
    mostrarAviso('analisando "Parcelas da negociação"…');
    const alvo = await rectDoTexto(TEXTO_BLOCO_PARCELAS, true);
    if (alvo) {
      // passa a seta pelo título do bloco e depois pela tabela logo abaixo, sem clicar
      await moverPara(alvo.left + alvo.width * rand(0.3, 0.8), alvo.top + alvo.height / 2);
      await sleep(rand(1500, 2500));
      await moverPara(alvo.left + rand(150, 500), alvo.top + rand(60, 110));
      await sleep(rand(1500, 2500));
    }
    const tabela = await esperar(lerTabela, 'tabela do bloco "Parcelas da negociação"',
      TIMEOUT_ELEMENTO_MS, [TEXTO_BLOCO_PARCELAS]);
    log(`bloco "Parcelas da negociação": colunas = ${tabela.colunas.join(' | ') || '(nenhuma lida)'}`);
    log(`${tabela.linhas.length} linha(s) de parcela lida(s). Primeiras:`, tabela.linhas.slice(0, 3),
      'Últimas:', tabela.linhas.slice(-2));
    return { texto: `Bloco "Parcelas da negociação" analisado (${tabela.linhas.length} parcelas lidas)`, direto: false };
  }

  // Etapas 11 a 15 (consulta COM negociações): menu "Ações" > "Emitir Documento de Arrecadação"
  // e leitura do bloco "Deseja emitir DARF para pagamento de". Para sem escolher nenhuma opção.
  // `k` = índice da negociação na tabela (0 = primeira linha); `total` = quantas negociações há.
  // `idEsperado` = número da negociação desta linha (lido da tabela); é conferido de novo na tela do DARF.
  async function etapasNegociacao(k = 0, total = 1, idEsperado = null) {
    log(`ETAPA 11: a consulta mostrou negociações; olhando a tabela (negociação ${k + 1} de ${total})`);
    mostrarAviso(total > 1 ? `olhando a tabela; vou abrir a negociação ${k + 1} de ${total}…` : 'há negociações. Olhando a tabela…');
    await sleep(rand(3000, 4500)); // demora antes de agir

    log(`ETAPA 12: localizar o ícone de menu (três linhas) da coluna "Ações" da linha ${k + 1} e clicar`);
    await abrirMenuDaNegociacao(k, idEsperado);

    log('ETAPA 13: aguardar o menu abrir e escolher "Emitir Documento de Arrecadação"');
    mostrarAviso('menu aberto? aguardando as opções…');
    // O clique pode não abrir o menu (ex.: o primeiro clique só fecha um menu que ficou aberto de outra linha).
    // Menu fechado fica escondido na página (o texto existe, mas invisível); se depois de 6 s a opção continua
    // invisível, o menu está fechado: clica de novo no ícone da MESMA linha (até 3 tentativas).
    for (let tent = 1; ; tent++) {
      try {
        await esperar(() => existeTexto(TEXTO_OPCAO_DARF), `opção "Emitir Documento de Arrecadação" no menu (tentativa ${tent}/3)`,
          6000, [TEXTO_OPCAO_DARF, 'Solicitar Desistência']);
        break;
      } catch (e) {
        if (e.erroSistema || tent >= 3) throw e;
        aviso(`o menu não abriu (tentativa ${tent}/3); clicando de novo no ícone de "Ações" da linha ${k + 1}`);
        mostrarAviso(`o menu não abriu; rolando a página para baixo e clicando de novo no ícone da linha ${k + 1} (tentativa ${tent + 1}/3)…`);
        await sleep(rand(1500, 2500));
        // pode ser falta de espaço embaixo do ícone: desce a página um gomo antes de tentar de novo
        const g0 = await lerGradeNegociacoes();
        await rolarPaginaGomo(rand(140, 200), rand(450, 700) * LENTIDAO_MOUSE / 1.5, g0 && g0.iframe);
        await sleep(rand(400, 800));
        await abrirMenuDaNegociacao(k, idEsperado);
      }
    }
    mostrarAviso('lendo as opções do menu…');
    await sleep(rand(2000, 3500)); // poucos segundos "lendo" o menu antes de escolher
    const opcao = await esperar(() => acharAlvoTexto(TEXTO_OPCAO_DARF),
      'opção "Emitir Documento de Arrecadação"', 10000, [TEXTO_OPCAO_DARF]);
    mostrarAviso('escolhendo "Emitir Documento de Arrecadação"…');
    await clicarAlvo(opcao, 'opção "Emitir Documento de Arrecadação"');

    log('ETAPA 14: aguardar a tela "Emitir documento de arrecadação"');
    mostrarAviso('aguardando a tela carregar…');
    await esperar(() => existeTexto(TEXTO_TELA_DARF), 'tela "Emitir documento de arrecadação"',
      30000, [TEXTO_TELA_DARF], undefined, true);
    await sleep(rand(1500, 2500));

    // Confere que a tela aberta é mesmo da negociação desta linha, antes de marcar ou emitir qualquer coisa.
    if (idEsperado && !idEsperado.startsWith('#')) {
      const idTela = await esperar(lerIdNegociacaoTela, 'número da negociação na tela "Emitir documento de arrecadação"',
        10000, ['Negociação']);
      if (idTela !== idEsperado) {
        throw new Error(`A tela aberta é da negociação ${idTela}, mas a da linha ${k + 1} é ${idEsperado}. Parei antes de marcar qualquer coisa.`);
      }
      log(`conferido: a tela é da negociação ${idTela}`);
    }

    log('ETAPA 15: analisar o bloco "Deseja emitir DARF para pagamento de"');
    mostrarAviso('analisando "Deseja emitir DARF para pagamento de"…');
    const bloco = await esperar(lerDarf, 'bloco "Deseja emitir DARF para pagamento de"',
      TIMEOUT_ELEMENTO_MS, [TEXTO_DARF_BLOCO]);

    // "lê" o bloco: leva a seta até o título dele, sem clicar em nada
    let px, py;
    if (bloco.el) {
      await garantirNaTela(bloco.el);
      const p = pontoEm(bloco.el);
      px = p.x; py = p.y;
    } else {
      const o = offsetFrameEl(bloco.iframe);
      px = o.x + bloco.rect.left + bloco.rect.width * rand(0.2, 0.6);
      py = o.y + bloco.rect.top + bloco.rect.height * rand(0.3, 0.7);
    }
    await moverPara(px, py);
    const lista = bloco.opcoes.map((o) => o.texto || '(sem rótulo)');
    log(`opções do bloco "Deseja emitir DARF para pagamento de": ${lista.join(' | ') || '(nenhuma encontrada)'}`,
      bloco.opcoes);
    return lista;
  }

  // ------------------------------- fila de empresas (lista_cnpjs.js) -------------------------------
  // O andamento fica em chrome.storage.local (sobrevive às recargas do e-CAC). Empresa "concluída" =
  // sem negociação (PDF salvo) ou DARF salvo; qualquer outro desfecho deixa a empresa pendente.
  const CHAVE_FILA = 'parcelamento_simplificado_fila';
  const ESTADOS_FEITOS = ['sem negociação', 'sem negociação ativa', 'DARF salvo'];

  async function lerFila() {
    try {
      const o = await chrome.storage.local.get(CHAVE_FILA);
      const f = o[CHAVE_FILA];
      if (f && f.lote === ID_LOTE) return f;
    } catch (_) { /* sem storage */ }
    return { lote: ID_LOTE, feitos: {} };
  }

  async function gravarFila(f) {
    try { await chrome.storage.local.set({ [CHAVE_FILA]: f }); } catch (_) { /* sem storage */ }
  }

  // Empresa com "erro do sistema" (faixa "Tente mais tarde" do e-CAC): é pulada e fica marcada para voltar depois.
  const ESTADO_ERRO = 'erro do sistema';
  // JA_CONCLUIDAS (lista_cnpjs.js): empresas que o usuário já fez antes e que contam como concluídas mesmo sem andamento
  // guardado (ex.: o Chrome perdeu o andamento porque a extensão foi removida e carregada de novo).
  const jaConcluidas = typeof JA_CONCLUIDAS !== 'undefined' ? JA_CONCLUIDAS : [];
  const concluida = (fila, c) => ESTADOS_FEITOS.includes((fila.feitos[c.cnpj] || {}).estado) || jaConcluidas.includes(c.cnpj);
  const pendentes = (fila) => LISTA_CNPJS.filter((c) => !concluida(fila, c) && !PULAR_CNPJS.includes(c.cnpj));
  const comErro = (fila) => pendentes(fila).filter((c) => (fila.feitos[c.cnpj] || {}).estado === ESTADO_ERRO);
  const pendentesNormais = (fila) => pendentes(fila).filter((c) => (fila.feitos[c.cnpj] || {}).estado !== ESTADO_ERRO);
  const formatarCnpj = (c) => c.replace(/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})$/, '$1.$2.$3/$4-$5');
  const nomesComErro = (fila) => comErro(fila).map((c) => `${c.nome} (${formatarCnpj(c.cnpj)})`);

  // Próxima empresa: a que estava em andamento (a página pode ter recarregado no meio da troca de perfil);
  // senão a primeira pendente sem erro. Só no clique do ícone (`incluirErros`) entram também as com erro do sistema.
  function proximoItem(fila, incluirErros) {
    const emAndamento = fila.atual && LISTA_CNPJS.find((c) => c.cnpj === fila.atual);
    if (emAndamento && pendentes(fila).includes(emAndamento)) return emAndamento;
    return pendentesNormais(fila)[0] || (incluirErros ? comErro(fila)[0] : null) || null;
  }

  function rotuloDoItem(fila, item) {
    const pos = LISTA_CNPJS.indexOf(item) + 1;
    const faltam = pendentesNormais(fila).filter((c) => c !== item).length;
    const erros = comErro(fila).filter((c) => c !== item).length;
    return `CNPJ ${pos} de ${LISTA_CNPJS.length} · faltam ${faltam}${erros ? ` · com erro: ${erros}` : ''}\n` +
      `${item.nome} (${formatarCnpj(item.cnpj)})`;
  }

  // Empresas que você já viu dar erro do sistema (COM_ERRO_INICIAL em lista_cnpjs.js) entram como "erro do
  // sistema" uma única vez, para ficarem na lista de "voltar depois" em vez de serem tentadas de novo agora.
  async function semearErros(fila) {
    fila.semeados = fila.semeados || {};
    let mudou = false;
    for (const cnpj of (typeof COM_ERRO_INICIAL !== 'undefined' ? COM_ERRO_INICIAL : [])) {
      const c = LISTA_CNPJS.find((x) => x.cnpj === cnpj);
      if (!c || fila.semeados[cnpj] || concluida(fila, c)) continue;
      fila.semeados[cnpj] = true;
      const antes = fila.feitos[cnpj] || {};
      fila.feitos[cnpj] = {
        nome: c.nome, neg: antes.neg, estado: ESTADO_ERRO,
        detalhe: 'marcada por você: "Não foi possível prosseguir. Tente mais tarde (Erro 6)"',
        quando: new Date().toLocaleString('pt-BR'),
      };
      mudou = true;
    }
    if (mudou) await gravarFila(fila);
  }

  function linhasDoResumo(fila) {
    return LISTA_CNPJS.map((c, i) => {
      const f = fila.feitos[c.cnpj];
      const estado = PULAR_CNPJS.includes(c.cnpj) ? 'pulada'
        : (jaConcluidas.includes(c.cnpj) && !(f && ESTADOS_FEITOS.includes(f.estado)) ? 'já concluída (JA_CONCLUIDAS)' : (f ? f.estado : 'pendente'));
      return `${String(i + 1).padStart(2, '0')}. ${c.nome} (${formatarCnpj(c.cnpj)}): ${estado}` +
        `${f && f.arquivo ? ` -> ${f.arquivo}` : ''}${f && f.detalhe && !ESTADOS_FEITOS.includes(f.estado) ? ` [${f.detalhe}]` : ''}`;
    });
  }

  // Tela travada ("carregando" sem concluir) ou página de erro do servidor: atualiza a página (F5) e continua de
  // onde parou. O andamento (empresa, negociações já feitas) já está guardado, e `fila.atual` faz o script,
  // depois da recarga, retomar nesta mesma empresa. Limite de recargas por empresa, para não girar em círculo.
  const LIMITE_RECARGAS = 4;

  async function recarregarEContinuar(fila, item, e) {
    fila.recargas = fila.recargas || {};
    const n = (fila.recargas[item.cnpj] || 0) + 1;
    if (n > LIMITE_RECARGAS) return false;
    fila.recargas[item.cnpj] = n;
    fila.atual = item.cnpj;
    fila.retomar = { cnpj: item.cnpj, t: Date.now() };
    await gravarFila(fila);
    aviso(`${e.message} -> atualizando a página (recarga ${n}/${LIMITE_RECARGAS}) e continuando de onde parou`);
    mostrarAviso(`Demorou demais ou o e-CAC deu erro de servidor.\nAtualizando a página (${n}/${LIMITE_RECARGAS}) e continuando de onde parou…`, 'info');
    await sleep(rand(1500, 2500));
    location.reload();
    await sleep(15000); // a página recarrega e este script termina
    return true;
  }

  async function registrarDesfecho(fila, item, desfecho) {
    const antes = fila.feitos[item.cnpj] || {};
    if (ESTADOS_FEITOS.includes(desfecho.estado) && fila.recargas) delete fila.recargas[item.cnpj]; // concluída: zera
    fila.feitos[item.cnpj] = { nome: item.nome, neg: antes.neg, emDia: antes.emDia, ...desfecho, quando: new Date().toLocaleString('pt-BR') };
    await gravarFila(fila);
  }

  // `manual` = clique no ícone (também refaz as empresas com erro do sistema); false = início automático
  // (F5 na tela inicial, retomada depois da troca de perfil, ou seguir sozinha para a próxima empresa).
  async function executar(manual = false) {
    if (executando) { aviso('já existe uma execução em andamento'); return; }
    executando = true;
    let fila = null, item = null, concluiu = false, seguirErro = false, recarregando = false;
    etiquetaNeg = '';
    try {
      if (LISTA_CNPJS.length) {
        fila = await lerFila();
        await semearErros(fila);
        if (fila.retomar) { delete fila.retomar; await gravarFila(fila); } // já estamos retomando depois da recarga
        item = proximoItem(fila, manual);
        if (!item) {
          rotuloLote = '';
          const erros = nomesComErro(fila);
          log(erros.length ? '=== FIM DA RODADA: há empresas com erro do sistema para voltar ===' : '=== LISTA CONCLUÍDA ===');
          linhasDoResumo(fila).forEach((l) => log(l));
          mostrarAviso(erros.length
            ? `Fim da rodada. COM ERRO DO SISTEMA (${erros.length}), para voltar depois:\n- ${erros.join('\n- ')}\nClique no ícone da extensão para tentar essas de novo.`
            : `Lista concluída: as ${LISTA_CNPJS.length} empresas já foram processadas (resumo no console).`,
          erros.length ? 'info' : 'ok');
          return;
        }
        fila.atual = item.cnpj; // se a página recarregar no meio (troca de perfil), retoma nesta mesma empresa
        await gravarFila(fila);
        cnpjAtual = item.cnpj;
        rotuloLote = rotuloDoItem(fila, item);
        log(`=== ${rotuloLote.replace('\n', ' | ')} ===`);
      }
      await marcarErrosVistos(); // faixas de erro que já estavam na tela não contam

      // O perfil do CNPJ já está ativo? Vale o cabeçalho da própria página ("Procurador de: CNPJ"),
      // que sobrevive à recarga; o marcador de fase é só um reforço.
      let perfilPronto = lerFase() === 'trocou_perfil';
      if (!perfilPronto) {
        const fim = Date.now() + 4000; // dá tempo do cabeçalho aparecer
        while (!perfilProcuradorAtual() && Date.now() < fim) await sleep(200);
        perfilPronto = !!perfilTrocado();
      }
      log(perfilPronto ? '=== perfil do CNPJ já ativo: seguindo direto para a consulta ===' : '=== início da automação ===');
      mostrarAviso(perfilPronto ? 'perfil já ativo; seguindo…' : 'iniciando…');
      if (!perfilPronto) analisarPagina();
      criarCursor();
      await sleep(rand(500, 900));

      if (!perfilPronto) await etapasPerfil();
      await etapasConsulta();
      const resultado = await etapasResultado();
      let desfecho; // { estado, arquivo?, detalhe? }

      if (resultado.tipo === 'com') {
        // Uma empresa pode ter várias negociações: faz o processo completo em cada uma, na ordem da tabela.
        // O andamento por negociação fica guardado, para não refazer as que já terminaram.
        // SÓ as negociações com situação "Ativo" são processadas; as outras (ex.: "Requerimento em análise",
        // rescindida, liquidada) são lidas, anotadas e puladas, sem erro.
        const lista = (await listarNegociacoes()) || [{ id: '#1', situacao: '' }];
        const ids = lista.map((x) => x.id);
        const total = ids.length;
        const neg = { ...((item && fila.feitos[item.cnpj] && fila.feitos[item.cnpj].neg) || {}) }; // número -> PDF
        // negociações "em dia" (sem parcela "A vencer" do mês atual/anterior para pagar): puladas sem erro; número -> texto
        const emDia = { ...((item && fila.feitos[item.cnpj] && fila.feitos[item.cnpj].emDia) || {}) };
        // Situações aceitas: SITUACOES_PROCESSAR em lista_cnpjs.js (padrão: "Ativo" e "Requerimento em análise").
        const situacoesAceitas = typeof SITUACOES_PROCESSAR !== 'undefined' && SITUACOES_PROCESSAR.length
          ? SITUACOES_PROCESSAR : ['Ativo'];
        const aceitas = situacoesAceitas.map(norm);
        const textoAceitas = situacoesAceitas.map((s) => `"${s}"`).join(' ou ');
        const ehAtivo = (x) => !x.situacao || aceitas.includes(norm(x.situacao)); // situação ilegível: processa (como antes)
        log(`negociações desta empresa: ${total}; aceitas (${textoAceitas}): ${lista.filter(ehAtivo).length}; já feitas: ${Object.keys(neg).length}`);
        lista.forEach((x) => log(`  ${x.id} | situação: ${x.situacao || '(não consegui ler)'} | ${ehAtivo(x) ? 'PROCESSAR' : 'ignorar'}${neg[x.id] ? ' (já feita)' : ''}`));
        if (lista.some((x) => !x.situacao)) aviso('não consegui ler a situação de alguma negociação; essas serão processadas');
        let parouEm = null;
        const negErro = {}; // negociações recusadas pelo e-CAC nesta rodada: número -> texto da faixa
        const ignoradas = {}; // negociações puladas por não estarem "Ativo": número -> situação
        let naTabela = true; // acabamos de ver a tabela de negociações
        for (let k = 0; k < total && !parouEm; k++) {
          const id = ids[k];
          if (neg[id]) { log(`negociação ${id} já feita (${neg[id]}); pulando`); continue; }
          if (emDia[id]) { log(`negociação ${id} já vista como em dia; pulando`); continue; }
          if (!ehAtivo(lista[k])) {
            ignoradas[id] = lista[k].situacao;
            log(`negociação ${id} ignorada: situação "${lista[k].situacao}" (só processo: ${textoAceitas})`);
            continue;
          }
          etiquetaNeg = total > 1 ? `negociação ${k + 1} de ${total}` : '';
          log(`=== ${etiquetaNeg ? etiquetaNeg + ' - ' : ''}negociação ${id} ===`);
          try {
            if (!naTabela) await voltarParaConsulta();
            naTabela = false;
            const opcoes = await etapasNegociacao(k, total, id);
            log(`tela de DARF analisada; opções: ${opcoes.join(' | ')}`);
            const parcelas = await etapasParcelas();
            log(parcelas.texto);
            let arquivo;
            if (parcelas.direto) {
              // sem tabela de parcelas: o "Confirmar" levou direto à emissão
              arquivo = await etapasEmissao(k, total, true);
            } else {
              const selecao = await etapasSelecao();
              log(selecao.texto);
              if (!selecao.marcadas) {
                // sem parcela "A vencer" do mês atual/anterior = negociação em dia (tudo pago): anota e segue
                emDia[id] = 'em dia, sem parcela a vencer neste mês nem no anterior e sem parcela devedora';
                log(`negociação ${id} em dia (sem "A vencer" do mês atual/anterior e sem "Devedora"); sigo para o próximo processo`);
                mostrarAviso(`negociação ${id} em dia (nada a pagar neste mês nem no anterior).\nSeguindo para o próximo processo…`, 'info');
                if (item) {
                  fila.feitos[item.cnpj] = { ...(fila.feitos[item.cnpj] || {}), nome: item.nome, estado: 'parou', detalhe: 'em andamento', neg, emDia };
                  await gravarFila(fila);
                }
                await sleep(rand(1200, 2000));
                naTabela = false; // a tela está no demonstrativo de parcelas: a próxima etapa volta à consulta
                continue;
              }
              arquivo = await etapasEmissao(k, total);
            }
            neg[id] = arquivo;
            if (item) { // guarda o andamento já, caso a empresa pare numa negociação seguinte
              fila.feitos[item.cnpj] = { ...(fila.feitos[item.cnpj] || {}), nome: item.nome, estado: 'parou', detalhe: 'em andamento', neg };
              await gravarFila(fila);
            }
          } catch (e) {
            // O e-CAC recusou a ação nesta negociação ("Não foi possível concluir a ação…"): anota, pula SÓ esta
            // negociação e continua com as outras da empresa. Qualquer outro erro continua parando a empresa.
            if (!(e.erroSistema && e.tipo === 'negociacao')) throw e;
            negErro[id] = e.faixa;
            erro(`NEGOCIAÇÃO ${id} RECUSADA PELO E-CAC: "${e.faixa}"; sigo com as outras`);
            mostrarAviso(`⚠ o e-CAC recusou a negociação ${id}: "${e.faixa}".\nPulei só esta e sigo para a próxima negociação.`, 'erro');
            await sleep(rand(3000, 5000));
            naTabela = false; // a página ficou na tela do erro: a próxima negociação começa voltando à consulta
          }
        }
        etiquetaNeg = '';
        const idsComErro = Object.keys(negErro);
        if (idsComErro.length && !parouEm) {
          // as negociações que deram certo ficaram guardadas; a empresa vai para "voltar depois", e ao voltar só
          // as que faltaram são refeitas
          const e = new Error('negociações recusadas pelo e-CAC');
          e.erroSistema = true;
          e.tipo = 'empresa';
          e.faixa = `DARF não emitido em ${idsComErro.length} negociação(ões): ` +
            idsComErro.map((i) => `${i} ("${negErro[i]}")`).join('; ');
          throw e;
        }
        const nIgn = Object.keys(ignoradas).length;
        const nDia = Object.keys(emDia).length;
        const obsIgn = [
          nIgn ? `${nIgn} negociação(ões) ignorada(s) por não estarem em ${textoAceitas}: ` +
            Object.entries(ignoradas).map(([i, s]) => `${i} (${s})`).join('; ') : '',
          nDia ? `${nDia} negociação(ões) em dia, sem DARF a emitir: ${Object.keys(emDia).join('; ')}` : '',
        ].filter(Boolean).join(' | ');
        if (parouEm) {
          desfecho = { estado: 'parou', detalhe: parouEm, neg };
        } else if (!Object.keys(neg).length) {
          // nenhuma negociação aceita para emitir: guarda o print da tabela como comprovante e dá a empresa por concluída
          log(`nenhuma negociação aceita (${textoAceitas}) para emitir; guardando o print da tela de consulta`);
          mostrarAviso(`nenhuma negociação para emitir (só ${textoAceitas}). Guardando o print da consulta…`);
          if (!naTabela) await voltarParaConsulta(); // se a última tela foi o demonstrativo de parcelas, volta à consulta antes do print
          window.scrollTo(0, 0);
          await perguntarFrames({ op: 'topo' });
          await sleep(rand(1000, 1800));
          const r = await salvarPdf(PASTA_SEM_NEGOCIACAO);
          if (!r || !r.ok) throw new Error(`Não consegui salvar o PDF: ${r ? r.erro : 'sem resposta do service worker'}`);
          desfecho = { estado: 'sem negociação ativa', arquivo: r.caminho, detalhe: obsIgn };
        } else {
          desfecho = { estado: 'DARF salvo', arquivo: Object.values(neg).join(' | '), neg, detalhe: obsIgn };
        }
      } else if (resultado.tipo === 'sem') {
        desfecho = { estado: 'sem negociação', arquivo: resultado.caminho };
      } else {
        desfecho = { estado: 'parou', detalhe: 'o resultado da consulta não é "sem negociações" nem a tabela de negociações conhecida' };
      }

      // registra e mostra o andamento
      const feito = ESTADOS_FEITOS.includes(desfecho.estado);
      if (item) await registrarDesfecho(fila, item, desfecho);
      const textoFim = feito
        ? (desfecho.estado === 'DARF salvo' ? `DARF salvo em ${desfecho.arquivo}`
          : desfecho.estado === 'sem negociação ativa' ? `Sem negociação para emitir. PDF salvo em ${desfecho.arquivo}`
          : `Sem negociações. PDF salvo em ${desfecho.arquivo}`) + (desfecho.detalhe ? `\n(${desfecho.detalhe})` : '')
        : `PAROU: ${desfecho.detalhe}`;
      if (item && feito) {
        concluiu = true;
        const faltam = pendentesNormais(fila);
        const erros = nomesComErro(fila);
        log(`=== CONCLUÍDA: ${item.nome} (${formatarCnpj(item.cnpj)}) -> ${textoFim} ===`);
        const proxima = faltam[0];
        mostrarAviso(`✔ ${textoFim}\n` + (proxima
          ? `Faltam ${faltam.length}. Próxima: ${proxima.nome} (${formatarCnpj(proxima.cnpj)}).` +
            (CONTINUAR_SOZINHO ? ' Seguindo sozinha…' : ' Clique no ícone da extensão para seguir.') +
            (erros.length ? `\nCom erro do sistema (${erros.length}): ${erros.join('; ')}` : '')
          : (erros.length
            ? `Fim da rodada. COM ERRO DO SISTEMA (${erros.length}), para voltar depois:\n- ${erros.join('\n- ')}\nClique no ícone da extensão para tentar essas de novo.`
            : 'LISTA CONCLUÍDA.')), 'ok');
        if (!proxima) linhasDoResumo(fila).forEach((l) => log(l));
      } else {
        log(`=== ${feito ? 'fim' : 'PAROU'}: ${textoFim} ===`);
        mostrarAviso(feito ? textoFim : `${textoFim}. Esta empresa continua pendente; me mostre o que apareceu.`, feito ? 'ok' : 'info');
      }
      setTimeout(removerCursor, 4000);
    } catch (e) {
      gravarFase(null);
      // Tela travada ou erro de servidor: atualiza a página e continua de onde parou (até LIMITE_RECARGAS vezes)
      if (item && (e.recarregar || (e.erroSistema && e.tipo === 'servidor'))) {
        if (await recarregarEContinuar(fila, item, e)) { recarregando = true; return; }
        // passou do limite: trata como erro do sistema (pula a empresa e marca para voltar depois)
        e.erroSistema = true;
        e.tipo = 'sistema';
        e.faixa = `o e-CAC travou ou deu erro de servidor ${LIMITE_RECARGAS} vezes seguidas (${e.message.slice(0, 120)})`;
      }
      if (e.erroSistema && item) {
        // Erro do sistema da Receita: pula esta empresa, marca para voltar depois e segue para a próxima
        erro('ERRO DO SISTEMA:', e.message);
        await registrarDesfecho(fila, item, { estado: ESTADO_ERRO, detalhe: e.faixa || e.message.slice(0, 200) });
        seguirErro = true;
        const erros = nomesComErro(fila);
        const proxima = pendentesNormais(fila)[0];
        log(`=== ERRO DO SISTEMA em ${item.nome} (${formatarCnpj(item.cnpj)}): marcada para voltar depois ===`);
        mostrarAviso(`⚠ ERRO DO SISTEMA da Receita ("${e.faixa}").\nPulei esta empresa e marquei para voltar depois.\n` +
          (proxima
            ? `Próxima: ${proxima.nome} (${formatarCnpj(proxima.cnpj)}).` + (CONTINUAR_SOZINHO ? ' Seguindo sozinha…' : ' Clique no ícone da extensão para seguir.')
            : 'Fim da rodada. Clique no ícone da extensão para tentar de novo as que deram erro.') +
          `\nCom erro até agora (${erros.length}):\n- ${erros.join('\n- ')}`, 'erro');
        if (!proxima) linhasDoResumo(fila).forEach((l) => log(l));
      } else {
        erro('FALHA:', e.message);
        if (item) await registrarDesfecho(fila, item, { estado: 'parou', detalhe: e.message.slice(0, 300) });
        mostrarAviso(`parou. ${e.message}`, 'erro');
      }
      removerCursor();
    } finally {
      executando = false;
      // terminou (bem ou mal); se está só recarregando a página, mantém a empresa em andamento
      if (!recarregando && fila && item && fila.atual === item.cnpj) { fila.atual = null; await gravarFila(fila); }
      if (!recarregando && CONTINUAR_SOZINHO && (concluiu || seguirErro) && fila && pendentesNormais(fila).length) {
        setTimeout(() => executar(false), rand(5000, 8000)); // segue para a próxima empresa
      }
    }
  }

  // Dentro de um iframe: só o agente. O fluxo principal roda apenas na janela principal.
  if (window !== window.top) {
    iniciarAgente();
    return;
  }

  // Clique no ícone da extensão = iniciar à força, em qualquer tela do e-CAC.
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg && msg.tipo === 'iniciar') executar(true); // clique no ícone: também refaz as empresas com erro do sistema
  });

  // Início automático: na tela "Parcelamento - Solicitar e acompanhar" (sem subtela depois do ">>").
  async function iniciarAutomatico() {
    log('carregada em', location.href);
    if (!INICIAR_AO_CARREGAR) {
      log('início automático desligado; clique no ícone da extensão para iniciar');
      return;
    }
    try {
      await esperar(
        () => /parcelamento\s*-\s*solicitar e acompanhar(?!\s*>>)/i.test(document.body.innerText || ''),
        'tela "Parcelamento - Solicitar e acompanhar"',
        10000, [], null // sem vigiar faixa de erro: aqui só se decide se é a tela inicial
      );
    } catch (_) {
      // Depois de uma recarga feita pela própria automação (tela travada / erro de servidor), retoma mesmo que o
      // e-CAC não tenha voltado para a tela inicial do Parcelamento.
      let retomar = null;
      try { retomar = LISTA_CNPJS.length ? (await lerFila()).retomar : null; } catch (_e) { /* sem storage */ }
      if (retomar && Date.now() - retomar.t < 180000) {
        log('retomando depois da recarga, mesmo fora da tela inicial do Parcelamento');
        await sleep(rand(1500, 2500));
        executar(false);
        return;
      }
      log('esta não parece a tela inicial de Parcelamento; não iniciei sozinha (clique no ícone para forçar)');
      return;
    }
    await sleep(rand(700, 1300));
    executar(false);
  }
  iniciarAutomatico();
})();
