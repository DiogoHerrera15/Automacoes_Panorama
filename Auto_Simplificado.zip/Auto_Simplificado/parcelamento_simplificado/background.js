// Service worker:
//  1) ao clicar no ícone da extensão, manda o content script da janela principal iniciar;
//  2) repassa mensagens entre a janela principal e os iframes de outro domínio do e-CAC
//     (o conteúdo do Parcelamento fica num iframe que a janela principal não consegue acessar);
//  3) captura a tela da aba do e-CAC, monta um PDF e salva numa subpasta de Downloads.
// O content script só existe nas páginas do e-CAC (ver "matches" no manifest).

const PREFIXO = '[parcelamento_simplificado]';

// Pasta de destino: subpastas de Downloads separadas por "/", só com letras, números, "_", "-" e ".",
// e nunca "." ou ".." (não deixa sair de Downloads).
const pastaValida = (p) => typeof p === 'string' && /^[\w.-]+(\/[\w.-]+)*$/.test(p) &&
  !p.split('/').some((s) => /^\.+$/.test(s));

chrome.action.onClicked.addListener(async (tab) => {
  try {
    await chrome.tabs.sendMessage(tab.id, { tipo: 'iniciar' }, { frameId: 0 });
    await chrome.action.setBadgeText({ tabId: tab.id, text: '' });
    console.log(PREFIXO, 'comando de início enviado à aba', tab.id);
  } catch (e) {
    console.warn(PREFIXO, 'esta aba não é do e-CAC (ou precisa ser recarregada):', e.message);
    await chrome.action.setBadgeBackgroundColor({ tabId: tab.id, color: '#c0392b' });
    await chrome.action.setBadgeText({ tabId: tab.id, text: '!' });
  }
});

// ------------------------------- PDF a partir de uma imagem JPEG -------------------------------
// PDF mínimo de 1 página, do tamanho da imagem (96 dpi -> pontos), com o JPEG embutido.
function montarPdf(jpg, w, h) {
  const enc = new TextEncoder();
  const W = +(w * 0.75).toFixed(2);
  const H = +(h * 0.75).toFixed(2);
  const conteudo = `q ${W} 0 0 ${H} 0 0 cm /Im0 Do Q`;
  const partes = [];
  const offs = [];
  let pos = 0;
  const add = (x) => {
    const b = typeof x === 'string' ? enc.encode(x) : x;
    partes.push(b);
    pos += b.length;
  };
  const obj = (n, corpo) => {
    offs[n] = pos;
    add(`${n} 0 obj\n${corpo}\nendobj\n`);
  };

  add('%PDF-1.4\n');
  obj(1, '<< /Type /Catalog /Pages 2 0 R >>');
  obj(2, '<< /Type /Pages /Kids [3 0 R] /Count 1 >>');
  obj(3, `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${W} ${H}] /Resources << /XObject << /Im0 4 0 R >> >> /Contents 5 0 R >>`);
  offs[4] = pos;
  add(`4 0 obj\n<< /Type /XObject /Subtype /Image /Width ${w} /Height ${h} /ColorSpace /DeviceRGB ` +
      `/BitsPerComponent 8 /Filter /DCTDecode /Length ${jpg.length} >>\nstream\n`);
  add(jpg);
  add('\nendstream\nendobj\n');
  obj(5, `<< /Length ${conteudo.length} >>\nstream\n${conteudo}\nendstream`);

  const xref = pos;
  let t = 'xref\n0 6\n0000000000 65535 f \n';
  for (let n = 1; n <= 5; n++) t += `${String(offs[n]).padStart(10, '0')} 00000 n \n`;
  t += `trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF\n`;
  add(t);

  const saida = new Uint8Array(pos);
  let p = 0;
  for (const b of partes) { saida.set(b, p); p += b.length; }
  return saida;
}

function bytesParaBase64(bytes) {
  let s = '';
  for (let i = 0; i < bytes.length; i += 0x8000) {
    s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
  }
  return btoa(s);
}

function dataUrlParaBytes(dataUrl) {
  const bin = atob(dataUrl.slice(dataUrl.indexOf(',') + 1));
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return bytes;
}

function esperarDownload(id, limiteMs = 15000) {
  return new Promise((resolve) => {
    const fim = (caminho) => {
      chrome.downloads.onChanged.removeListener(ouvir);
      clearTimeout(timer);
      resolve(caminho);
    };
    const buscar = async () => {
      const [item] = await chrome.downloads.search({ id });
      return item && item.filename;
    };
    const ouvir = async (d) => {
      if (d.id !== id || !d.state) return;
      if (d.state.current === 'complete' || d.state.current === 'interrupted') fim(await buscar());
    };
    const timer = setTimeout(async () => fim(await buscar()), limiteMs);
    chrome.downloads.onChanged.addListener(ouvir);
  });
}

// Captura a parte visível da aba, gera o PDF e salva em Downloads/<pasta>/<nome>.
async function capturarEmPdf({ pasta, nome }, tabId) {
  if (!pastaValida(pasta) || !/^[\w.-]+\.pdf$/.test(nome)) throw new Error('nome de pasta/arquivo inválido');
  const tab = await chrome.tabs.get(tabId);
  if (!tab.active) throw new Error('a aba do e-CAC não está em primeiro plano; deixe-a visível durante a captura');
  const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'jpeg', quality: 92 });
  const jpg = dataUrlParaBytes(dataUrl);
  const bmp = await createImageBitmap(new Blob([jpg], { type: 'image/jpeg' }));
  const pdf = montarPdf(jpg, bmp.width, bmp.height);
  const id = await chrome.downloads.download({
    url: 'data:application/pdf;base64,' + bytesParaBase64(pdf),
    filename: `${pasta}/${nome}`,
    conflictAction: 'uniquify',
    saveAs: false,
  });
  const caminho = await esperarDownload(id);
  // Aba anônima: o salvamento é igual (mesma pasta Downloads do Chrome); só registramos para conferência.
  console.log(PREFIXO, `PDF da tela salvo em ${caminho || `Downloads/${pasta}/${nome}`}${tab.incognito ? ' (aba anônima)' : ''}`);
  return { ok: true, caminho: caminho || `Downloads/${pasta}/${nome}`, anonima: !!tab.incognito };
}

// ------------------------------- PDF do DARF (gerado pela própria página do e-CAC) -------------------------------
// Antes de clicar em "Emitir DARF de parcela", o content script "arma" este estado. Daí em diante:
//  - se a página iniciar um download, ele é renomeado e guardado em Downloads/<pasta>/<nome>;
//  - se a página abrir uma nova aba (PDF aberto em vez de baixado) e nenhum download começar em 8 s,
//    tenta baixar o endereço dessa aba.
// O content script consulta o andamento com 'status-darf'.
let darf = null; // { tabId, pasta, nome, expira, estado, caminho, detalhe, novaAba, downloadId }
const DARF_VALIDADE_MS = 120000;
const darfAtivo = () => !!darf && Date.now() < darf.expira;

chrome.downloads.onDeterminingFilename.addListener((item, sugerir) => {
  if (item.byExtensionId === chrome.runtime.id) return; // downloads desta extensão (PDF da tela) seguem como estão
  if (!darfAtivo() || darf.downloadId) return;          // só o primeiro download depois do clique
  const origem = `${item.url} ${item.finalUrl || ''} ${item.referrer || ''}`;
  if (!origem.includes('receita.fazenda.gov.br')) return;
  darf.downloadId = item.id;
  darf.estado = 'baixando';
  darf.detalhe = `download iniciado pela página (${item.mime || 'tipo desconhecido'}; nome original: ${item.filename})` +
    (item.incognito ? ' [aba anônima: guardado na mesma pasta Downloads]' : '');
  console.log(PREFIXO, darf.detalhe);
  sugerir({ filename: `${darf.pasta}/${darf.nome}`, conflictAction: 'uniquify' });
});

chrome.downloads.onChanged.addListener(async (d) => {
  if (!darf || d.id !== darf.downloadId || !d.state) return;
  if (d.state.current === 'complete') {
    const [it] = await chrome.downloads.search({ id: d.id });
    darf.estado = 'ok';
    darf.caminho = it && it.filename;
    if (it && it.mime && !/pdf/i.test(it.mime)) darf.detalhe = `atenção: o arquivo baixado é do tipo ${it.mime}, não PDF`;
    console.log(PREFIXO, 'DARF salvo em', darf.caminho, darf.detalhe || '');
  } else if (d.state.current === 'interrupted') {
    darf.estado = 'erro';
    darf.detalhe = `o download foi interrompido (${(d.error && d.error.current) || 'motivo desconhecido'})`;
  }
});

chrome.tabs.onCreated.addListener((tab) => {
  if (!darfAtivo() || tab.openerTabId !== darf.tabId) return;
  darf.novaAba = { id: tab.id, url: tab.pendingUrl || tab.url || '' };
  console.log(PREFIXO, 'a página abriu uma nova aba:', darf.novaAba.url);
  setTimeout(() => baixarDaNovaAba(tab.id), 8000);
});

async function baixarDaNovaAba(tabId) {
  if (!darfAtivo() || darf.downloadId) return; // já houve download: nada a fazer
  let url = '';
  try { url = (await chrome.tabs.get(tabId)).url || ''; } catch (_) { /* aba fechada */ }
  darf.novaAba = { id: tabId, url };
  if (!/^(https?|blob):/.test(url)) {
    darf.estado = 'erro';
    darf.detalhe = `a nova aba abriu em "${url || 'endereço desconhecido'}" e não consegui baixar o PDF dela`;
    return;
  }
  try {
    darf.downloadId = await chrome.downloads.download({
      url, filename: `${darf.pasta}/${darf.nome}`, conflictAction: 'uniquify', saveAs: false,
    });
    darf.estado = 'baixando';
    darf.detalhe = `baixando o endereço da nova aba: ${url.slice(0, 120)}`;
  } catch (e) {
    darf.estado = 'erro';
    darf.detalhe = `não consegui baixar o endereço da nova aba (${e.message}): ${url.slice(0, 120)}`;
  }
}

// ------------------------------- mensagens do content script -------------------------------
chrome.runtime.onMessage.addListener((msg, remetente, responder) => {
  if (!msg || !remetente.tab || remetente.id !== chrome.runtime.id) return false;

  // Janela principal -> todos os frames da aba. Quem tiver resposta (o frame certo) responde;
  // os demais ficam em silêncio. Sem resposta, devolve null.
  if (msg.ps === 'repassar') {
    chrome.tabs.sendMessage(remetente.tab.id, { ps: 'frame', dados: msg.dados })
      .then((resp) => responder(resp || null))
      .catch(() => responder(null));
    return true; // resposta assíncrona
  }

  let doEcac = false;
  try { doEcac = new URL(remetente.url).hostname.endsWith('cav.receita.fazenda.gov.br'); } catch (_) { /* url inválida */ }

  // Prepara o salvamento do PDF que a página vai gerar (ver bloco do DARF acima).
  if (msg.ps === 'armar-darf') {
    const { pasta, nome } = msg.dados || {};
    if (!doEcac || !pastaValida(pasta) || !/^[\w.-]+\.pdf$/.test(nome || '')) {
      responder({ ok: false, erro: 'pedido inválido' });
      return false;
    }
    darf = { tabId: remetente.tab.id, pasta, nome, expira: Date.now() + DARF_VALIDADE_MS, estado: 'aguardando' };
    responder({ ok: true });
    return false;
  }
  if (msg.ps === 'status-darf') {
    responder(darf ? { estado: darf.estado, caminho: darf.caminho, detalhe: darf.detalhe, novaAba: darf.novaAba || null } : null);
    return false;
  }

  // Captura de tela: só aceita pedidos vindos de páginas do e-CAC.
  if (msg.ps === 'capturar') {
    if (!doEcac) { responder({ ok: false, erro: 'captura permitida só no e-CAC' }); return false; }
    capturarEmPdf(msg.dados, remetente.tab.id)
      .then(responder)
      .catch((e) => { console.error(PREFIXO, 'falha ao salvar PDF:', e); responder({ ok: false, erro: e.message }); });
    return true;
  }
  return false;
});
