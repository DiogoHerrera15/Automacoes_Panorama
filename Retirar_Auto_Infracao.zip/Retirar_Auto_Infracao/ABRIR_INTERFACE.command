#!/bin/bash
# Abre a interface gráfica do Retirar_Auto_Infracao (duplo clique ou ./ABRIR_INTERFACE.command).
cd "$(dirname "$0")" || exit 1
echo "Retirar_Auto_Infracao - interface grafica"
if ! command -v node >/dev/null 2>&1; then
  echo
  echo "O Node.js nao esta instalado. Instale a versao LTS em https://nodejs.org e rode de novo."
  read -r -p "Enter para fechar..."
  exit 1
fi
# Instala as dependencias na primeira vez, ou se a pasta veio de outro tipo de Mac
# (o leitor de PDF usa um componente nativo que depende do processador).
if ! node --input-type=module -e "await import('pdfjs-dist/legacy/build/pdf.mjs'); await import('@napi-rs/canvas')" >/dev/null 2>&1; then
  echo "Instalando dependencias (so na primeira vez)..."
  npm install --no-audit --no-fund || { read -r -p "Falhou. Enter para fechar..."; exit 1; }
fi
node src/interface/iniciar.js "$@"
echo
echo "Interface encerrada."
read -r -p "Enter para fechar..."
