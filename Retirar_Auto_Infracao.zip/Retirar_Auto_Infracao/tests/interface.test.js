// Interface: API, segurança local, eventos em tempo real e uma execução completa feita
// pela API (como a página faz).

import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { test } from 'node:test';
import { iniciarInterface } from '../src/interface/servidor.js';
import { certidaoFicticia, cnpjDaVez, criarAmbiente, esperarAte } from './ajuda.js';

const A = '00.897.321/0001-30';

async function comInterface(corpo, extra = {}) {
  const amb = await criarAmbiente();
  const pastasAbertas = [];
  const ui = await iniciarInterface({ cfg: amb.cfg, porta: 0, abrirPasta: (p) => pastasAbertas.push(p), ...extra });
  const base = ui.url.replace(/\/$/, '');
  const api = async (rota, corpoJson, { token = ui.token, headers = {} } = {}) => {
    const resposta = await fetch(base + rota, {
      method: corpoJson === undefined ? 'GET' : 'POST',
      headers: { 'Content-Type': 'application/json', ...(token ? { 'X-Token': token } : {}), ...headers },
      body: corpoJson === undefined ? undefined : JSON.stringify(corpoJson),
    });
    return { status: resposta.status, dados: await resposta.json().catch(() => null) };
  };
  try {
    await corpo({ ...amb, ui, base, api, pastasAbertas });
  } finally {
    await ui.fechar();
    amb.limpar();
  }
}

test('página, arquivos estáticos e token da sessão', () => comInterface(async ({ base, ui }) => {
  const html = await (await fetch(`${base}/`)).text();
  assert.ok(html.includes(`content="${ui.token}"`), 'o token vai embutido na página');
  assert.ok(!html.includes('{{TOKEN}}'));
  assert.equal((await fetch(`${base}/app.js`)).status, 200);
  assert.equal((await fetch(`${base}/estilo.css`)).status, 200);
  assert.equal((await fetch(`${base}/api/ping`)).status, 200);
  assert.equal((await fetch(`${base}/../package.json`)).status, 404);
}));

test('segurança: sem token, com token errado, Host estranho, Origin de outro site e tipo errado', () => comInterface(async ({ api, base, ui }) => {
  assert.equal((await api('/api/estado')).status, 200);
  assert.equal((await api('/api/estado', undefined, { token: 'errado' })).status, 403);
  assert.equal((await api('/api/validar', { texto: A }, { token: '' })).status, 403);
  assert.equal((await api('/api/validar', { texto: A }, { token: 'errado' })).status, 403);
  assert.equal((await api('/api/validar', { texto: A }, { headers: { Origin: 'https://site-malicioso.example' } })).status, 403);
  const semJson = await fetch(`${base}/api/validar`, { method: 'POST', headers: { 'Content-Type': 'text/plain', 'X-Token': ui.token }, body: '{}' });
  assert.equal(semJson.status, 415);
  // Host diferente (DNS rebinding): feito direto no socket, porque o fetch não deixa trocar o Host.
  const { request } = await import('node:http');
  const status = await new Promise((resolve, reject) => {
    const r = request({ host: '127.0.0.1', port: ui.porta, path: '/', headers: { Host: 'atacante.example' } }, (res) => { res.resume(); resolve(res.statusCode); });
    r.on('error', reject);
    r.end();
  });
  assert.equal(status, 403);
}));

test('validar: classifica válidos, inválidos e repetidos sem salvar nada', () => comInterface(async ({ api, cfg }) => {
  const { dados } = await api('/api/validar', { texto: `${A};A\n${A};B\n00.897.321/0001-99;X\n123.456.789-09;PF` });
  assert.deepEqual(dados.itens.map((i) => i.situacao), ['pendente', 'repetido', 'inválido', 'pendente']);
  assert.deepEqual(dados.itens.map((i) => i.tipo), ['CNPJ', 'CNPJ', 'CNPJ', 'CPF']);
  assert.equal(dados.contagem.total, 2);
  assert.equal(dados.contagem.invalidos, 1);
  assert.equal(dados.contagem.repetidos, 1);
  assert.ok(!fs.existsSync(cfg.arquivoLista) || !fs.readFileSync(cfg.arquivoLista, 'utf8').includes(A));
}));

test('lista: salva no mesmo arquivo do terminal e reaparece no estado', () => comInterface(async ({ api, cfg }) => {
  assert.equal((await api('/api/lista', { texto: `${A};ANTONIO\n\n123.456.789-09` })).status, 200);
  const arquivo = fs.readFileSync(cfg.arquivoLista, 'utf8');
  assert.ok(arquivo.startsWith('# Cole aqui os CNPJs'));
  assert.ok(arquivo.includes(`${A};ANTONIO\n123.456.789-09\n`));
  const { dados } = await api('/api/estado');
  assert.equal(dados.listaTexto, `${A};ANTONIO\n123.456.789-09`);
  assert.equal(dados.contagem.total, 2);
}));

test('iniciar sem lista ou sem documento válido é recusado com mensagem clara', () => comInterface(async ({ api }) => {
  const vazio = await api('/api/iniciar', { texto: '' });
  assert.equal(vazio.status, 400);
  assert.match(vazio.dados.erro, /lista está vazia/);
  const invalido = await api('/api/iniciar', { texto: '00.897.321/0001-99' });
  assert.equal(invalido.status, 400);
  assert.match(invalido.dados.erro, /nenhum CPF\/CNPJ válido/);
  assert.equal((await api('/api/comando', { comando: 's' })).status, 409);
  assert.equal((await api('/api/comando', { comando: 'x' })).status, 400);
}));

test('execução completa pela API, com eventos SSE, bloqueios durante a execução e abrir pasta', () => comInterface(async ({ api, base, ui, cfg, downloads, pastasAbertas }) => {
  // Cliente de eventos (SSE), como a página.
  const controle = new AbortController();
  const resposta = await fetch(`${base}/api/eventos?t=${ui.token}`, { signal: controle.signal });
  assert.equal(resposta.headers.get('content-type').split(';')[0], 'text/event-stream');
  const eventos = [];
  (async () => {
    const leitor = resposta.body.getReader();
    const decodificador = new TextDecoder();
    let sobra = '';
    try {
      while (true) {
        const { value, done } = await leitor.read();
        if (done) break;
        sobra += decodificador.decode(value, { stream: true });
        const blocos = sobra.split('\n\n');
        sobra = blocos.pop();
        for (const bloco of blocos) {
          const nome = bloco.match(/^event: (.+)$/m)?.[1];
          const dados = bloco.match(/^data: (.+)$/m)?.[1];
          if (nome && dados) eventos.push({ nome, dados: JSON.parse(dados) });
        }
      }
    } catch {
      // Cancelado no fim do teste.
    }
  })();
  await esperarAte(() => eventos.some((e) => e.nome === 'estado'), { mensagem: 'estado inicial por SSE' });

  assert.equal((await api('/api/iniciar', { texto: `${A};ANTONIO CARLOS DE BRITO` })).status, 200);
  await esperarAte(async () => (await cnpjDaVez(cfg))?.cnpj === A, { mensagem: 'extensão recebe o CNPJ' });

  // Durante a execução: lista travada, segunda execução e encerrar lote recusados.
  assert.equal((await api('/api/lista', { texto: 'x' })).status, 409);
  assert.equal((await api('/api/iniciar', { texto: A })).status, 409);
  assert.equal((await api('/api/novo-lote', {})).status, 409);
  assert.equal((await api('/api/encerrar', {})).status, 409);
  const durante = (await api('/api/estado')).dados;
  assert.equal(durante.fase, 'executando');
  assert.equal(durante.empresaAtual.nome, 'ANTONIO CARLOS DE BRITO');
  assert.equal(durante.itens[0].situacao, 'em andamento');
  assert.ok(durante.extensao.consultas >= 1, 'a consulta da extensão é contada');
  assert.equal((await api('/api/abrir-pasta', { alvo: 'lote' })).status, 200);
  assert.equal(pastasAbertas.at(-1), durante.pastaLote);

  fs.writeFileSync(path.join(downloads, 'Document.pdf'), certidaoFicticia(A));
  await esperarAte(async () => (await api('/api/estado')).dados.fase === 'ocioso', { mensagem: 'fim da execução' });

  const fim = (await api('/api/estado')).dados;
  assert.equal(fim.mostrandoUltimoLote, true);
  assert.equal(fim.itens[0].situacao, 'PDF salvo');
  assert.equal(fim.contagem.feitas, 1);
  assert.ok(fs.existsSync(path.join(fim.pastaLote, '00897321000130;ANTONIO CARLOS DE BRITO.pdf')));

  await esperarAte(() => eventos.some((e) => e.nome === 'log' && /Salvo: 00897321000130/.test(e.dados.texto)), { mensagem: 'log do salvamento por SSE' });
  assert.ok(eventos.some((e) => e.nome === 'estado' && e.dados.fase === 'executando'));
  assert.ok(eventos.some((e) => e.nome === 'estado' && e.dados.fase === 'ocioso' && e.dados.mostrandoUltimoLote));
  controle.abort();
}));

test('parar e pular pela API', () => comInterface(async ({ api, cfg }) => {
  await api('/api/iniciar', { texto: `${A};A` });
  await esperarAte(async () => (await cnpjDaVez(cfg))?.cnpj === A, { mensagem: 'vez de A' });
  assert.equal((await api('/api/comando', { comando: 'c' })).status, 200);
  assert.equal((await api('/api/comando', { comando: 's' })).status, 200);
  await esperarAte(async () => (await api('/api/estado')).dados.fase === 'ocioso', { mensagem: 'parou' });
  const estado = (await api('/api/estado')).dados;
  assert.equal(estado.itens[0].situacao, 'pendente', 'parar não marca a empresa como pulada');

  await api('/api/iniciar', { texto: `${A};A` });
  await esperarAte(async () => (await cnpjDaVez(cfg))?.cnpj === A, { mensagem: 'vez de A de novo' });
  await api('/api/comando', { comando: 'p' });
  await esperarAte(async () => (await api('/api/estado')).dados.fase === 'ocioso', { mensagem: 'pulou' });
  assert.equal((await api('/api/estado')).dados.itens[0].situacao, 'pulada');

  // Encerrar o lote pela interface limpa tudo.
  assert.equal((await api('/api/novo-lote', {})).status, 200);
  assert.equal((await api('/api/estado')).dados.itens.length, 0);
}));

test('encerrar chama o callback e só com a execução parada', () => {
  let encerrou = false;
  return comInterface(async ({ api }) => {
    assert.equal((await api('/api/encerrar', {})).status, 200);
    await esperarAte(() => encerrou, { mensagem: 'callback de encerramento' });
  }, { aoEncerrar: () => { encerrou = true; } });
});
