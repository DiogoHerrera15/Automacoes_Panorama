// Fluxo completo do assistente, com um "Downloads" falso e a extensão simulada por
// chamadas a GET /cnpj. Não abre o Chrome nem acessa o site do MTE.

import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { test } from 'node:test';
import { Assistente } from '../src/assistente.js';
import { MODELO_LISTA } from '../src/config.js';
import { salvarListaArquivo } from '../src/persistencia.js';
import { certidaoFicticia, cnpjDaVez, criarAmbiente, esperarAte, lotesEm } from './ajuda.js';

const A = '00.897.321/0001-30';
const B = '40.842.851/0001-04';

async function comAmbiente(corpo) {
  const amb = await criarAmbiente();
  try {
    await corpo(amb);
  } finally {
    amb.limpar();
  }
}

// Espera a empresa da vez aparecer na porta que a extensão consulta.
const esperarVez = (cfg, documento) => esperarAte(async () => (await cnpjDaVez(cfg))?.cnpj === documento, { mensagem: `vez de ${documento}` });

test('uma empresa: extensão recebe o CNPJ, PDF é conferido, salvo no lote e o lote é encerrado', () => comAmbiente(async ({ cfg, downloads }) => {
  salvarListaArquivo(cfg, `${A};ANTONIO CARLOS DE BRITO`);
  const assistente = new Assistente(cfg);
  const logs = [];
  assistente.on('log', (l) => logs.push(l.texto));

  const execucao = assistente.executar();
  await esperarVez(cfg, A);
  const resposta = await cnpjDaVez(cfg);
  assert.deepEqual(resposta, { cnpj: A, nome: 'ANTONIO CARLOS DE BRITO' });
  assert.equal(assistente.snapshot().empresaAtual.documento, A);
  assert.equal(assistente.snapshot().servidorCnpjAtivo, true);

  fs.writeFileSync(path.join(downloads, 'Document.pdf'), certidaoFicticia(A));
  const { resultado, placar } = await execucao;

  assert.equal(resultado, 'concluido');
  assert.deepEqual(placar, { total: 1, feitas: 1, puladas: 0, faltam: 0 });
  const [lote] = lotesEm(cfg.raiz);
  assert.ok(fs.existsSync(path.join(cfg.raiz, lote, '00897321000130;ANTONIO CARLOS DE BRITO.pdf')));
  assert.equal(fs.existsSync(path.join(downloads, 'Document.pdf')), false, 'o PDF sai de Downloads');
  // Lote encerrado: lista esvaziada, controle e relatório do lote apagados, relatório guardado.
  assert.equal(fs.readFileSync(cfg.arquivoLista, 'utf8'), MODELO_LISTA);
  assert.equal(fs.existsSync(cfg.arquivoControle), false);
  assert.equal(fs.readdirSync(cfg.pastaRelatorios).length, 1);
  assert.ok(fs.existsSync(path.join(cfg.raiz, lote, 'Relatorio.csv')));
  assert.ok(logs.some((t) => t.includes('Lote concluído')));
  // A porta da extensão é liberada ao terminar.
  assert.equal(await cnpjDaVez(cfg), null);
  // Interface continua mostrando o que foi feito, mesmo com a lista vazia.
  const depois = assistente.snapshot();
  assert.equal(depois.mostrandoUltimoLote, true);
  assert.equal(depois.itens[0].situacao, 'PDF salvo');
}));

test('várias empresas (CNPJ e CPF), com repetido e inválido na lista', () => comAmbiente(async ({ cfg, downloads }) => {
  salvarListaArquivo(cfg, [`${A};EMPRESA A`, `${B};EMPRESA B`, '123.456.789-09;PESSOA FISICA', `${A};REPETIDA`, '00.897.321/0001-99;INVALIDO'].join('\n'));
  const assistente = new Assistente(cfg);
  const execucao = assistente.executar();

  const itensIniciais = assistente.snapshot().itens.map((i) => i.situacao);
  assert.deepEqual(itensIniciais.slice(3), ['repetido', 'inválido']);

  for (const doc of [A, B, '123.456.789-09']) {
    await esperarVez(cfg, doc);
    fs.writeFileSync(path.join(downloads, 'Document.pdf'), certidaoFicticia(doc));
    await esperarAte(() => !fs.existsSync(path.join(downloads, 'Document.pdf')), { mensagem: `PDF de ${doc} movido` });
  }
  const { resultado, placar } = await execucao;
  assert.equal(resultado, 'concluido');
  assert.equal(placar.feitas, 3);
  const [lote] = lotesEm(cfg.raiz);
  const arquivos = fs.readdirSync(path.join(cfg.raiz, lote)).sort();
  assert.deepEqual(arquivos, [
    '00897321000130;EMPRESA A.pdf',
    '12345678909;PESSOA FISICA.pdf',
    '40842851000104;EMPRESA B.pdf',
    'Relatorio.csv',
  ]);
  // O relatório mantém uma linha por linha da lista, inclusive o inválido.
  const relatorio = fs.readFileSync(path.join(cfg.raiz, lote, 'Relatorio.csv'), 'utf8');
  assert.match(relatorio, /CPF\/CNPJ inválido/);
  assert.equal(relatorio.trim().split(/\r?\n/).length, 6);
}));

test('PDF de outro CNPJ fica em Downloads e a empresa continua esperando', () => comAmbiente(async ({ cfg, downloads }) => {
  salvarListaArquivo(cfg, `${A};EMPRESA A`);
  const assistente = new Assistente(cfg);
  const logs = [];
  assistente.on('log', (l) => logs.push(l.texto));
  const execucao = assistente.executar();
  await esperarVez(cfg, A);

  fs.writeFileSync(path.join(downloads, 'errado.pdf'), certidaoFicticia(B));
  await esperarAte(() => logs.some((t) => t.includes('ATENÇÃO')), { mensagem: 'aviso de PDF errado' });
  assert.ok(fs.existsSync(path.join(downloads, 'errado.pdf')), 'o PDF errado não é movido');
  assert.equal(assistente.snapshot().itens[0].situacao, 'em andamento');

  fs.writeFileSync(path.join(downloads, 'Document.pdf'), certidaoFicticia(A));
  assert.equal((await execucao).resultado, 'concluido');
  assert.ok(fs.existsSync(path.join(downloads, 'errado.pdf')));
}));

test('p (pular) mantém o lote; --refazer-puladas volta a empresa para pendente', () => comAmbiente(async ({ cfg, downloads }) => {
  salvarListaArquivo(cfg, `${A};EMPRESA A`);
  const assistente = new Assistente(cfg);
  const primeira = assistente.executar();
  await esperarVez(cfg, A);
  assistente.enviarComando('p');
  assert.equal((await primeira).resultado, 'puladas');
  assert.ok(fs.readFileSync(cfg.arquivoLista, 'utf8').includes(A), 'a lista é mantida');
  assert.equal(assistente.snapshot().itens[0].situacao, 'pulada');

  const segunda = assistente.executar({ refazerPuladas: true });
  await esperarVez(cfg, A);
  fs.writeFileSync(path.join(downloads, 'Document.pdf'), certidaoFicticia(A));
  assert.equal((await segunda).resultado, 'concluido');
}));

test('s (parar) é seguro: o andamento fica salvo e rodar de novo continua de onde parou', () => comAmbiente(async ({ cfg, downloads }) => {
  salvarListaArquivo(cfg, `${A};EMPRESA A\n${B};EMPRESA B`);
  const assistente = new Assistente(cfg);
  const primeira = assistente.executar();
  await esperarVez(cfg, A);
  fs.writeFileSync(path.join(downloads, 'Document.pdf'), certidaoFicticia(A));
  await esperarVez(cfg, B);
  assistente.enviarComando('s');
  assert.equal(assistente.snapshot().parando, true);
  const { resultado, placar } = await primeira;
  assert.equal(resultado, 'parado');
  assert.deepEqual([placar.feitas, placar.faltam], [1, 1]);
  assert.equal(assistente.snapshot().fase, 'ocioso');
  assert.equal(assistente.snapshot().parando, false);
  assert.ok(fs.existsSync(cfg.arquivoControle), 'o controle fica para retomar');

  // Nova instância (como fechar e abrir o programa): continua só a B.
  const outra = new Assistente(cfg);
  const retomada = outra.executar();
  await esperarVez(cfg, B);
  fs.writeFileSync(path.join(downloads, 'Document.pdf'), certidaoFicticia(B));
  const fim = await retomada;
  assert.equal(fim.resultado, 'concluido');
  assert.equal(fim.placar.feitas, 2);
  assert.equal(lotesEm(cfg.raiz).length, 1, 'continua no mesmo lote');
}));

test('certidões já em Downloads são organizadas sem abrir o site (--organizar e início normal)', () => comAmbiente(async ({ cfg, downloads }) => {
  salvarListaArquivo(cfg, `${A};EMPRESA A\n${B};EMPRESA B`);
  fs.writeFileSync(path.join(downloads, 'Document.pdf'), certidaoFicticia(A));
  fs.writeFileSync(path.join(downloads, 'outra-pessoa.pdf'), certidaoFicticia('01.016.121/0001-94'));
  const assistente = new Assistente(cfg);
  const { resultado, placar } = await assistente.executar({ organizar: true });
  assert.equal(resultado, 'organizado');
  assert.deepEqual([placar.feitas, placar.faltam], [1, 1]);
  assert.ok(fs.existsSync(path.join(downloads, 'outra-pessoa.pdf')), 'fora da lista: fica em Downloads');
  assert.equal(fs.existsSync(path.join(downloads, 'Document.pdf')), false);
}));

test('parar durante a pausa entre empresas funciona', () => comAmbiente(async ({ cfg, downloads }) => {
  salvarListaArquivo(cfg, `${A};EMPRESA A\n${B};EMPRESA B`);
  const assistente = new Assistente(cfg);
  const execucao = assistente.executar({ pausaMin: 30, pausaMax: 30 });
  await esperarVez(cfg, A);
  fs.writeFileSync(path.join(downloads, 'Document.pdf'), certidaoFicticia(A));
  await esperarAte(() => assistente.etapa === 'pausa', { mensagem: 'pausa' });
  assistente.enviarComando('s');
  assert.equal((await execucao).resultado, 'parado');
}));

test('lista sem nenhum documento válido não é apagada', () => comAmbiente(async ({ cfg }) => {
  salvarListaArquivo(cfg, '00.897.321/0001-99;INVALIDO');
  const { resultado } = await new Assistente(cfg).executar();
  assert.equal(resultado, 'sem-validos');
  assert.ok(fs.readFileSync(cfg.arquivoLista, 'utf8').includes('INVALIDO'));
}));

test('duas execuções ao mesmo tempo são recusadas; novoLote só quando ocioso', () => comAmbiente(async ({ cfg }) => {
  salvarListaArquivo(cfg, `${A};EMPRESA A`);
  const assistente = new Assistente(cfg);
  const execucao = assistente.executar();
  await esperarVez(cfg, A);
  await assert.rejects(() => assistente.executar(), /já existe uma execução/i);
  assert.throws(() => assistente.novoLote(), /Pare a execução/);
  assistente.enviarComando('s');
  await execucao;
  assistente.novoLote();
  assert.equal(fs.readFileSync(cfg.arquivoLista, 'utf8'), MODELO_LISTA);
  assert.equal(fs.existsSync(cfg.arquivoControle), false);
}));

test('pasta Downloads inexistente dá erro claro', () => comAmbiente(async ({ cfg, downloads }) => {
  salvarListaArquivo(cfg, `${A};EMPRESA A`);
  fs.rmSync(downloads, { recursive: true });
  await assert.rejects(() => new Assistente(cfg).executar(), /pasta de Downloads/);
}));

test('porta da extensão ocupada: avisa e segue (V / Cmd+V continuam valendo)', () => comAmbiente(async ({ cfg, downloads }) => {
  const { createServer } = await import('node:http');
  const ocupante = createServer((_, r) => r.end()).listen(cfg.portaCnpj, '127.0.0.1');
  await esperarAte(() => ocupante.listening);
  try {
    salvarListaArquivo(cfg, `${A};EMPRESA A`);
    const assistente = new Assistente(cfg);
    const logs = [];
    assistente.on('log', (l) => logs.push(l));
    const execucao = assistente.executar();
    await esperarAte(() => logs.some((l) => l.nivel === 'aviso' && l.texto.includes('EADDRINUSE')), { mensagem: 'aviso de porta' });
    assert.equal(assistente.snapshot().servidorCnpjAtivo, false);
    fs.writeFileSync(path.join(downloads, 'Document.pdf'), certidaoFicticia(A));
    assert.equal((await execucao).resultado, 'concluido');
  } finally {
    ocupante.close();
  }
}));
