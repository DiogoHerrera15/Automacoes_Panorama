// Extensão do Chrome: nome novo e comunicação com o assistente (sem abrir o Chrome).

import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { test } from 'node:test';
import { fileURLToPath } from 'node:url';
import { PORTA_CNPJ } from '../src/config.js';

const raiz = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const ler = (...p) => fs.readFileSync(path.join(raiz, 'extensao-chrome', ...p), 'utf8');
const manifest = JSON.parse(ler('manifest.json'));

test('manifest: nome Retirar_Auto_Infracao, MV3 e arquivos referenciados existem', () => {
  assert.equal(manifest.name, 'Retirar_Auto_Infracao');
  assert.equal(manifest.manifest_version, 3);
  assert.ok(manifest.name.length <= 45);
  assert.ok(fs.existsSync(path.join(raiz, 'extensao-chrome', manifest.background.service_worker)));
  for (const cs of manifest.content_scripts) {
    assert.deepEqual(cs.matches, ['https://eprocesso.sit.trabalho.gov.br/*']);
    for (const js of cs.js) assert.ok(fs.existsSync(path.join(raiz, 'extensao-chrome', js)), js);
  }
});

test('o nome antigo não aparece mais em nenhum arquivo da extensão', () => {
  for (const arquivo of fs.readdirSync(path.join(raiz, 'extensao-chrome'))) {
    assert.ok(!/Baixar Certid/.test(ler(arquivo)), `${arquivo} ainda cita "Baixar Certidão"`);
  }
});

test('porta: fundo.js, host_permissions e PORTA_CNPJ do assistente são a mesma', () => {
  assert.equal(PORTA_CNPJ, 47321);
  const url = ler('fundo.js').match(/URL_CNPJ_DA_VEZ = '([^']+)'/)[1];
  assert.equal(url, `http://127.0.0.1:${PORTA_CNPJ}/cnpj`);
  assert.deepEqual(manifest.host_permissions, [`http://127.0.0.1:${PORTA_CNPJ}/*`]);
});

test('mensagens entre baixar.js (página) e fundo.js (fundo) continuam as mesmas', () => {
  const baixar = ler('baixar.js');
  const fundo = ler('fundo.js');
  for (const tipo of ['fechar-aba', 'cnpj-da-vez']) {
    assert.ok(baixar.includes(`tipo: '${tipo}'`), `baixar.js envia ${tipo}`);
    assert.ok(fundo.includes(`mensagem?.tipo === '${tipo}'`), `fundo.js trata ${tipo}`);
  }
});

test('o assistente atende exatamente o que o fundo.js pede (GET /cnpj com JSON { cnpj, nome })', () => {
  const assistente = fs.readFileSync(path.join(raiz, 'src', 'assistente.js'), 'utf8');
  assert.ok(assistente.includes("req.url === '/cnpj'"));
  assert.ok(assistente.includes('JSON.stringify({ cnpj: this.empresaDaVez.documento, nome: this.empresaDaVez.nome })'));
  assert.ok(ler('baixar.js').includes('const { cnpj } = (await chrome.runtime.sendMessage'));
});

test('o launcher e o README citam a pasta da extensão que existe', () => {
  assert.ok(fs.existsSync(path.join(raiz, 'extensao-chrome', 'manifest.json')));
  assert.ok(fs.readFileSync(path.join(raiz, 'README.md'), 'utf8').includes('extensao-chrome'));
});
