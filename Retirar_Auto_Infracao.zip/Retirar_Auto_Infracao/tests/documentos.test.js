import assert from 'node:assert/strict';
import { test } from 'node:test';
import { chaveDoc, cnpjValido, cpfValido, formatarDocumento, interpretarLista, nomeLimpo } from '../src/documentos.js';
import { conferirPdf, documentosNoTexto, ehCertidaoTrabalhista, textoDoPdf } from '../src/pdf.js';
import { certidaoFicticia, criarPdf } from './ajuda.js';

test('CNPJ: dígitos verificadores', () => {
  assert.ok(cnpjValido('00897321000130'));
  assert.ok(cnpjValido('40842851000104'));
  assert.ok(!cnpjValido('00897321000131'));
  assert.ok(!cnpjValido('11111111111111'));
  assert.ok(!cnpjValido('123'));
});

test('CNPJ alfanumérico (regra da RFB, letra = ASCII - 48)', () => {
  assert.ok(cnpjValido('12ABC34501DE35'));
  assert.ok(!cnpjValido('12ABC34501DE36'));
});

test('CPF: dígitos verificadores', () => {
  assert.ok(cpfValido('12345678909'));
  assert.ok(!cpfValido('12345678900'));
  assert.ok(!cpfValido('11111111111'));
});

test('formatação e chave', () => {
  assert.equal(chaveDoc('00.897.321/0001-30'), '00897321000130');
  assert.equal(formatarDocumento('00897321000130'), '00.897.321/0001-30');
  assert.equal(formatarDocumento('12345678909'), '123.456.789-09');
});

test('lista: todos os formatos aceitos no LEIA-ME', () => {
  const r = interpretarLista([
    '# comentário',
    '',
    '00.897.321/0001-30',
    '00897321000130;ANTONIO CARLOS DE BRITO',
    '01.016.121/0001-94 - ARRUMEL COMERCIO DE BALAS LTDA',
    '40.842.851/0001-04\t2P CALIFORNIA EXCHANGE LTDA',
    'CPF/CNPJ Empresa',
    '123.456.789-09;FULANO DE TAL',
  ].join('\r\n'));
  assert.equal(r.length, 5);
  assert.deepEqual(r.map((x) => x.problema), ['', '', '', '', '']);
  assert.equal(r[0].nome, '');
  assert.equal(r[1].nome, 'ANTONIO CARLOS DE BRITO');
  assert.equal(r[2].nome, 'ARRUMEL COMERCIO DE BALAS LTDA');
  assert.equal(r[3].nome, '2P CALIFORNIA EXCHANGE LTDA');
  assert.equal(r[4].documento, '123.456.789-09');
  assert.equal(r[4].chave.length, 11);
});

test('lista: documento inválido e número solto viram problema; cabeçalho é ignorado', () => {
  const r = interpretarLista('00.897.321/0001-31;X\n12345678\nCPF/CNPJ Empresa');
  assert.equal(r.length, 2);
  assert.match(r[0].problema, /inválido/);
  assert.match(r[1].problema, /sem CPF\/CNPJ/);
});

test('lista: CPF do dono dentro do nome não vale quando a linha já tem CNPJ', () => {
  const [r] = interpretarLista('00.897.321/0001-30 - JOAO 123.456.789-09');
  assert.equal(r.chave, '00897321000130');
});

test('nome do arquivo sem acentos nem caracteres proibidos', () => {
  assert.equal(nomeLimpo('AÇAÍ & CIA: "LTDA"/ME.'), 'ACAI & CIA LTDA ME');
});

test('PDF: texto, tipo de certidão e documentos', async () => {
  const pdf = certidaoFicticia('00.897.321/0001-30');
  const texto = await textoDoPdf(pdf);
  assert.ok(ehCertidaoTrabalhista(texto));
  assert.ok(documentosNoTexto(texto).has('00897321000130'));
});

test('conferirPdf: CNPJ certo, outro CNPJ, não-certidão, lixo, CPF e raiz', async () => {
  const empresa = { chave: '00897321000130', nome: 'X' };
  assert.equal((await conferirPdf(empresa, certidaoFicticia('00.897.321/0001-30'))).ok, true);

  const outro = await conferirPdf(empresa, certidaoFicticia('40.842.851/0001-04'));
  assert.equal(outro.ok, false);
  assert.match(outro.mensagem, /outro CPF\/CNPJ/);

  const naoCertidao = await conferirPdf(empresa, criarPdf(['Outro documento', '00.897.321/0001-30']));
  assert.equal(naoCertidao.ok, false);

  assert.equal((await conferirPdf(empresa, Buffer.from('nao e pdf'))).ok, false);

  const cpf = await conferirPdf({ chave: '12345678909', nome: 'F' }, certidaoFicticia('123.456.789-09'));
  assert.equal(cpf.ok, true);
  assert.match(cpf.mensagem, /CPF conferido/);

  // A certidão pode trazer só a raiz (8 primeiros dígitos) do CNPJ.
  const raiz = await conferirPdf({ chave: '00897321000221', nome: 'F' }, criarPdf(['CERTIDAO DE DEBITOS TRABALHISTAS', 'Raiz 00.897.321']));
  assert.equal(raiz.ok, true);
  assert.match(raiz.mensagem, /Raiz/);
});
