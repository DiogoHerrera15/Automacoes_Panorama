// Apoio dos testes: PDFs de certidão fictícios, portas livres e pastas temporárias.
// Nada aqui acessa o site do MTE, o Chrome ou a pasta Downloads de verdade.

import fs from 'node:fs';
import net from 'node:net';
import os from 'node:os';
import path from 'node:path';
import { criarConfig } from '../src/config.js';

const escapar = (texto) => texto.replace(/[\\()]/g, '\\$&');

// PDF mínimo e válido, uma linha de texto por elemento (como o site, que quebra o CNPJ).
export function criarPdf(linhas) {
  const fluxo = `BT /F1 12 Tf 50 750 Td 14 TL ${linhas.map((l) => `(${escapar(l)}) Tj T*`).join(' ')} ET`;
  const objetos = [
    '<< /Type /Catalog /Pages 2 0 R >>',
    '<< /Type /Pages /Kids [3 0 R] /Count 1 >>',
    '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>',
    `<< /Length ${Buffer.byteLength(fluxo, 'latin1')} >>\nstream\n${fluxo}\nendstream`,
    '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>',
  ];
  let saida = '%PDF-1.4\n';
  const posicoes = [];
  objetos.forEach((o, i) => {
    posicoes.push(Buffer.byteLength(saida, 'latin1'));
    saida += `${i + 1} 0 obj\n${o}\nendobj\n`;
  });
  const xref = Buffer.byteLength(saida, 'latin1');
  saida += `xref\n0 ${objetos.length + 1}\n0000000000 65535 f \n${posicoes.map((p) => `${String(p).padStart(10, '0')} 00000 n \n`).join('')}`;
  saida += `trailer\n<< /Size ${objetos.length + 1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF\n`;
  return Buffer.from(saida, 'latin1');
}

// Certidão fictícia no formato do site: título + CNPJ/CPF do empregador.
export function certidaoFicticia(documento) {
  return criarPdf(['CERTIDAO DE DEBITOS TRABALHISTAS', 'Certidao no teste', `Inscricao: ${documento}`, 'Validade: 180 dias']);
}

export function portaLivre() {
  return new Promise((resolve, reject) => {
    const s = net.createServer();
    s.once('error', reject);
    s.listen(0, '127.0.0.1', () => {
      const { port } = s.address();
      s.close(() => resolve(port));
    });
  });
}

export const dormir = (ms) => new Promise((r) => setTimeout(r, ms));

export async function esperarAte(condicao, { tempo = 8000, passo = 25, mensagem = 'condição não atingida' } = {}) {
  const limite = Date.now() + tempo;
  while (Date.now() < limite) {
    if (await condicao()) return;
    await dormir(passo);
  }
  throw new Error(`Tempo esgotado: ${mensagem}`);
}

// Ambiente isolado: pasta raiz e Downloads temporários, porta própria, modo de teste.
export async function criarAmbiente(extra = {}) {
  const base = fs.mkdtempSync(path.join(os.tmpdir(), 'retirar-teste-'));
  const downloads = path.join(base, 'Downloads');
  fs.mkdirSync(downloads);
  const cfg = criarConfig({ raiz: path.join(base, 'projeto'), pastaDownloads: downloads, portaCnpj: await portaLivre(), intervaloDownloads: 30, modoTeste: true, pausaMin: 0, pausaMax: 0, ...extra });
  fs.mkdirSync(cfg.raiz, { recursive: true });
  return { base, downloads, cfg, limpar: () => fs.rmSync(base, { recursive: true, force: true }) };
}

// Faz o papel da extensão: pergunta o CNPJ da vez ao assistente (GET /cnpj).
export async function cnpjDaVez(cfg) {
  try {
    const r = await fetch(`http://127.0.0.1:${cfg.portaCnpj}/cnpj`);
    return r.ok ? await r.json() : null;
  } catch {
    return null;
  }
}

export const lotesEm = (raiz) => fs.readdirSync(raiz).filter((n) => n.startsWith('Lote_'));
