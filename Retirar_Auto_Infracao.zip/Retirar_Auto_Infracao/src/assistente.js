// Núcleo do assistente: o mesmo fluxo do certidao-trabalhista.js original, agora como uma
// classe que emite eventos. O terminal (src/cli.js) e a interface (src/interface/) são só
// "telas" sobre ela:
//
//   evento 'log'     { hora, nivel, texto }   mensagens que antes iam para o console
//   evento 'estado'  (sem dados)              algo mudou; chame snapshot() para ler
//   enviarComando()  'c' copiar de novo, 'p' pular a empresa, 's' parar (antes: stdin)
//
// Fluxo (inalterado): para cada empresa pendente, copia o CNPJ para a área de
// transferência, abre o site no Chrome e espera o PDF aparecer em Downloads. Enquanto
// espera, responde em http://127.0.0.1:<portaCnpj>/cnpj (só neste computador) com o CNPJ da
// vez; a extensão do Chrome usa isso para preencher o campo. O PDF é conferido (o CNPJ
// dentro dele tem que bater), salvo no lote e registrado no controle e no relatório.

import { execFileSync, spawn } from 'node:child_process';
import { EventEmitter } from 'node:events';
import fs from 'node:fs';
import http from 'node:http';
import path from 'node:path';
import { documentosNoTexto, ehCertidaoTrabalhista, conferirPdf, textoDoPdf } from './pdf.js';
import { tipoDoDocumento } from './documentos.js';
import {
  SITUACAO, agora, carimbo, carregarControle, encerrarLote, gravarControle, gravarRelatorio,
  lerControleSeExiste, lerListaArquivo, lerTextoDaLista, marcarJaSalvas, salvarPdf,
} from './persistencia.js';
import { contarItens, linhaPlacar, montarItens, placar } from './resumo.js';

export { SITUACAO };

// Erro de uso (opção inválida etc.): mostrado sem rastreio de pilha.
export class ErroDeUso extends Error {}

// Comandos digitados na janela (ou clicados na interface) enquanto o assistente espera.
class FilaComandos {
  #fila = [];
  #acordar = null;

  enviar(comando) {
    this.#fila.push(comando);
    this.#acordar?.();
  }

  limpar() {
    this.#fila.length = 0;
  }

  // Próximo comando; se passar `ms` sem nenhum, devolve undefined.
  proximo(ms) {
    if (this.#fila.length) return Promise.resolve(this.#fila.shift());
    return new Promise((resolve) => {
      const timer = ms === undefined ? null : setTimeout(() => {
        this.#acordar = null;
        resolve(undefined);
      }, ms);
      this.#acordar = () => {
        clearTimeout(timer);
        this.#acordar = null;
        resolve(this.#fila.shift());
      };
    });
  }
}

export class Assistente extends EventEmitter {
  constructor(cfg) {
    super();
    this.cfg = cfg;
    this.fase = 'ocioso'; // 'ocioso' | 'executando'
    this.parando = false;
    this.etapa = ''; // 'aguardando-pdf' | 'pausa' | ''
    this.logs = [];
    this.fila = new FilaComandos();
    this.registros = [];
    this.controle = null;
    this.pastaDoLote = cfg.raiz;
    this.empresaDaVez = null;
    this.servidorCnpj = null;
    this.servidorAtivo = false;
    this.extensao = { consultas: 0, ultimaConsulta: 0 };
    this.ultimoLote = null;
    this.avisouRelatorioAberto = false;
    this.avisouAreaDeTransferencia = false;
  }

  // ---------- mensagens e estado ----------

  log(texto, nivel = 'info') {
    const entrada = { hora: Date.now(), nivel, texto };
    this.logs.push(entrada);
    if (this.logs.length > 2000) this.logs.shift();
    this.emit('log', entrada);
  }

  mudou() {
    this.emit('estado');
  }

  // Tudo o que a interface precisa para se desenhar. Não tem efeitos colaterais.
  snapshot() {
    const executando = this.fase === 'executando';
    const registros = executando ? this.registros : lerListaArquivo(this.cfg);
    const controle = executando ? this.controle : lerControleSeExiste(this.cfg);
    const emAndamento = executando ? (this.empresaDaVez?.chave ?? '') : '';
    let itens = montarItens(registros, controle, emAndamento);
    let mostrandoUltimoLote = false;
    if (!executando && !registros.length && this.ultimoLote) {
      itens = this.ultimoLote.itens;
      mostrandoUltimoLote = true;
    }
    const empresa = this.empresaDaVez;
    return {
      fase: this.fase,
      parando: this.parando,
      etapa: this.etapa,
      itens,
      contagem: contarItens(itens),
      mostrandoUltimoLote,
      listaTexto: lerTextoDaLista(this.cfg),
      empresaAtual: empresa ? { nome: empresa.nome, documento: empresa.documento, tipo: tipoDoDocumento(empresa.chave) } : null,
      pastaLote: controle?.pastaLote ?? (mostrandoUltimoLote ? this.ultimoLote.pastaLote : ''),
      pastaRaiz: this.cfg.raiz,
      pastaDownloads: this.cfg.pastaDownloads,
      servidorCnpjAtivo: this.servidorAtivo,
      portaCnpj: this.cfg.portaCnpj,
      extensao: { ...this.extensao },
      pausa: { min: this.cfg.pausaMin, max: this.cfg.pausaMax },
      modoTeste: this.cfg.modoTeste,
    };
  }

  // ---------- comandos (c, p, s) ----------

  enviarComando(comando) {
    const c = String(comando ?? '').trim().toLowerCase();
    if (c === 's' && this.fase === 'executando') {
      this.parando = true;
      this.mudou();
    }
    this.fila.enviar(c);
  }

  // ---------- operações ----------

  lerLista() {
    return lerListaArquivo(this.cfg);
  }

  conferirLista(registros) {
    const validos = registros.filter((r) => !r.problema);
    const unicos = new Set(validos.map((r) => r.chave));
    this.log(`Lista: ${registros.length} empresa(s), ${unicos.size} CPF/CNPJ único(s), ${validos.length - unicos.size} repetido(s)`);
    for (const r of registros.filter((r) => r.problema)) this.log(`  linha ${r.linha}: ${r.nome || '(sem nome)'} - ${r.problema}`, 'aviso');
  }

  // --verificar: só confere a lista, sem copiar nada.
  verificar() {
    const registros = this.lerLista();
    this.conferirLista(registros);
    if (!registros.length) this.log(`\nA lista está vazia. Cole os CNPJs do dia em ${this.cfg.arquivoLista} e rode de novo.`);
    return registros;
  }

  // --novo-lote: encerra o lote atual (apaga lista e controle; o relatório fica guardado).
  novoLote() {
    if (this.fase !== 'ocioso') throw new ErroDeUso('Pare a execução antes de encerrar o lote.');
    encerrarLote(this.cfg);
    this.ultimoLote = null;
    this.log('Lote encerrado: lista e controle apagados (o relatório ficou em dados/Relatorios).');
    this.mudou();
  }

  // Executa o lote (equivale ao main() do script original). Opções: { organizar,
  // refazerPuladas, pausaMin, pausaMax }. Devolve { resultado, placar }.
  async executar(opcoes = {}) {
    if (this.fase !== 'ocioso') throw new ErroDeUso('Já existe uma execução em andamento.');
    this.fase = 'executando';
    this.parando = false;
    this.fila.limpar();
    this.mudou();
    try {
      return await this.rodar(opcoes);
    } finally {
      this.empresaDaVez = null;
      this.etapa = '';
      this.parando = false;
      this.fecharServidorCnpj();
      this.fase = 'ocioso';
      this.mudou();
    }
  }

  async rodar({ organizar = false, refazerPuladas = false, pausaMin, pausaMax } = {}) {
    const { cfg } = this;
    const registros = this.lerLista();
    this.registros = registros;
    this.conferirLista(registros);
    if (!registros.length) {
      this.log(`\nA lista está vazia. Cole os CNPJs do dia em ${cfg.arquivoLista} e rode de novo.`);
      return { resultado: 'lista-vazia' };
    }

    // CNPJ repetido na lista é emitido uma vez só, com o nome da primeira ocorrência.
    const chaves = [...new Set(registros.filter((r) => !r.problema).map((r) => r.chave))];
    if (!chaves.length) {
      // (o original seguia e apagava a lista; aqui ela é mantida para a pessoa corrigir)
      this.log('\nNenhum CPF/CNPJ válido na lista. Corrija as linhas acima e rode de novo.', 'erro');
      return { resultado: 'sem-validos' };
    }

    const controle = carregarControle(cfg);
    this.controle = controle;
    controle.pastaLote ??= path.join(cfg.raiz, `Lote_${carimbo()}`);
    this.pastaDoLote = controle.pastaLote;
    fs.mkdirSync(this.pastaDoLote, { recursive: true });
    this.log(`Pasta do lote: ${this.pastaDoLote}`);
    for (const r of registros.filter((r) => !r.problema)) {
      controle.documentos[r.chave] ??= { nome: r.nome, documento: r.documento, chave: r.chave, situacao: SITUACAO.pendente, mensagem: '', pdf: '', processadoEm: '' };
    }
    if (refazerPuladas) {
      for (const k of chaves) {
        const empresa = controle.documentos[k];
        if (empresa.situacao === SITUACAO.pulada) Object.assign(empresa, { situacao: SITUACAO.pendente, mensagem: '' });
      }
    }
    const jaSalvas = marcarJaSalvas(this.pastaDoLote, controle);
    if (jaSalvas) this.log(`PDFs que já estavam na pasta: ${jaSalvas}`);
    await this.organizarDownloads(controle);
    this.gravar(registros, controle);
    if (organizar) {
      this.mostrarResumo(registros, controle);
      return { resultado: 'organizado', placar: placar(controle, chaves) };
    }

    const pendentes = chaves.filter((k) => controle.documentos[k].situacao === SITUACAO.pendente);
    const feitas = chaves.filter((k) => controle.documentos[k].situacao === SITUACAO.salvo).length;
    this.log(`\nJá emitidas (não serão repetidas): ${feitas} de ${chaves.length}. Pendentes: ${pendentes.length}.`);
    let parado = false;
    if (!pendentes.length) {
      this.log('\nNenhuma empresa pendente.');
    } else {
      this.iniciarServidorCnpj();
      for (const [i, chave] of pendentes.entries()) {
        if (i > 0 && !(await this.pausarEntreEmpresas(pausaMin, pausaMax))) {
          this.log('\nParado. Rode de novo para continuar desta empresa.');
          parado = true;
          break;
        }
        const empresa = controle.documentos[chave];
        this.empresaDaVez = empresa;
        this.mudou();
        const resultado = await this.emitir(empresa, placar(controle, chaves));
        this.empresaDaVez = null;
        if (!resultado) {
          this.log('\nParado. Rode de novo para continuar desta empresa.');
          parado = true;
          break;
        }
        Object.assign(empresa, { pdf: '', ...resultado, processadoEm: agora() });
        this.gravar(registros, controle);
      }
    }
    this.mostrarResumo(registros, controle);

    const final = placar(controle, chaves);
    if (parado) return { resultado: 'parado', placar: final };
    if (final.faltam) return { resultado: 'incompleto', placar: final };
    if (final.puladas) {
      this.log(`\nLote com ${final.puladas} pulada(s): a lista foi mantida. Rode com --refazer-puladas, ou com --novo-lote para encerrar assim mesmo.`, 'aviso');
      return { resultado: 'puladas', placar: final };
    }
    // Guarda o resultado na memória: depois de encerrar o lote a lista fica vazia e a
    // interface continua mostrando o que foi feito.
    this.ultimoLote = { pastaLote: this.pastaDoLote, itens: montarItens(registros, controle), terminadoEm: agora() };
    encerrarLote(cfg);
    this.log('\nLote concluído: lista e controle apagados (o relatório ficou em dados/Relatorios). Cole os próximos CNPJs em COLE_OS_CNPJS_AQUI.txt.', 'ok');
    this.log(`PDFs deste lote: ${this.pastaDoLote}`, 'ok');
    return { resultado: 'concluido', placar: final };
  }

  gravar(registros, controle) {
    gravarControle(this.cfg, controle);
    const gravou = gravarRelatorio(this.cfg, registros, controle);
    if (!gravou && !this.avisouRelatorioAberto) {
      // Planilha travada por outro programa: o controle continua sendo gravado e o relatório sai depois.
      this.log(`  AVISO: feche ${path.basename(this.cfg.arquivoRelatorio)} no Excel para o relatório ser atualizado.`, 'aviso');
    }
    this.avisouRelatorioAberto = !gravou;
    this.mudou();
  }

  mostrarResumo(registros, controle) {
    const chaves = registros.filter((r) => !r.problema).map((r) => r.chave);
    const contagem = placar(controle, [...new Set(chaves)]);
    this.log('\nResumo:');
    this.log(`  Total na lista: ${contagem.total}`);
    this.log(`  PDF salvo (feitas): ${contagem.feitas}`);
    this.log(`  Puladas: ${contagem.puladas}`);
    this.log(`  Faltam (pendentes): ${contagem.faltam}`);
    const invalidos = registros.filter((r) => r.problema).length;
    if (invalidos) this.log(`  CPF/CNPJ inválido (fora do processo): ${invalidos}`, 'aviso');
    this.log(`  Relatório: ${this.cfg.arquivoRelatorio}`);
  }

  // ---------- Downloads ----------

  pdfsEmDownloads() {
    const arquivos = new Map();
    let nomes;
    try {
      nomes = fs.readdirSync(this.cfg.pastaDownloads);
    } catch (e) {
      throw new ErroDeUso(`Não consegui ler a pasta de Downloads (${this.cfg.pastaDownloads}): ${e.message}. No macOS, libere o acesso a Downloads para o Terminal em Ajustes do Sistema > Privacidade e Segurança > Arquivos e Pastas.`);
    }
    for (const nome of nomes) {
      if (!/\.pdf$/i.test(nome)) continue;
      try {
        const { size, mtimeMs } = fs.statSync(path.join(this.cfg.pastaDownloads, nome));
        arquivos.set(nome, `${size}:${mtimeMs}`);
      } catch {
        // Apagado ou renomeado entre a listagem e o stat.
      }
    }
    return arquivos;
  }

  // Certidões já em Downloads (emitidas sem o assistente, ou com ele fechado): cada uma
  // vai para a pasta com o nome da empresa cujo CNPJ está dentro do PDF. Fica em Downloads
  // o que não for certidão trabalhista, não for da lista ou for de empresa que já tem PDF.
  async organizarDownloads(controle) {
    const movidas = [];
    const deixadas = [];
    for (const nome of this.pdfsEmDownloads().keys()) {
      const origem = path.join(this.cfg.pastaDownloads, nome);
      const pdf = fs.readFileSync(origem);
      let texto;
      try {
        texto = await textoDoPdf(pdf);
      } catch {
        continue;
      }
      if (!ehCertidaoTrabalhista(texto)) continue;
      const empresas = [...documentosNoTexto(texto)].map((k) => controle.documentos[k]).filter(Boolean);
      if (!empresas.length) {
        deixadas.push(`${nome}: CNPJ não está na lista`);
        continue;
      }
      const empresa = empresas[0];
      if (empresa.situacao === SITUACAO.salvo) {
        deixadas.push(`${nome}: ${empresa.nome} já tem PDF (${path.basename(empresa.pdf)})`);
        continue;
      }
      const destino = salvarPdf(this.pastaDoLote, empresa, pdf);
      fs.unlinkSync(origem);
      Object.assign(empresa, { situacao: SITUACAO.salvo, pdf: destino, mensagem: 'Emitida sem o assistente; CNPJ conferido no PDF', processadoEm: agora() });
      movidas.push(`${nome} -> ${path.basename(destino)}`);
    }
    if (movidas.length) this.log(`\nCertidões movidas de Downloads: ${movidas.length}`, 'ok');
    for (const linha of movidas) this.log(`  ${linha}`);
    if (deixadas.length) this.log(`Certidões deixadas em Downloads: ${deixadas.length}`, 'aviso');
    for (const linha of deixadas) this.log(`  ${linha}`);
  }

  // Espera um PDF novo em Downloads (ou com tamanho/data diferentes do que havia antes) e
  // que tenha parado de crescer, ou um comando. Devolve { arquivo, nome } ou { comando }.
  async aguardarPdfOuComando(antes) {
    let candidatos = new Map();
    while (true) {
      const comando = await this.fila.proximo(this.cfg.intervaloDownloads);
      if (comando !== undefined) return { comando };
      const atuais = this.pdfsEmDownloads();
      for (const [nome, assinatura] of atuais) {
        if (antes.get(nome) === assinatura) continue;
        // O mesmo tamanho em duas leituras seguidas: o Chrome terminou de gravar.
        if (candidatos.get(nome) === assinatura) return { arquivo: path.join(this.cfg.pastaDownloads, nome), nome };
      }
      candidatos = atuais;
    }
  }

  // ---------- Chrome, área de transferência e extensão ----------

  copiar(texto) {
    if (this.cfg.modoTeste) return;
    try {
      execFileSync('pbcopy', { input: texto });
    } catch (e) {
      if (!this.avisouAreaDeTransferencia) this.log(`  AVISO: não consegui copiar para a área de transferência (${e.message}). Digite o CNPJ no site.`, 'aviso');
      this.avisouAreaDeTransferencia = true;
    }
  }

  abrirSite() {
    if (this.cfg.modoTeste) return;
    const aviso = (motivo) => this.log(`  AVISO: não consegui abrir o Google Chrome (${motivo}). Abra ${this.cfg.urlCertidao} no Chrome.`, 'aviso');
    const filho = spawn('open', ['-a', 'Google Chrome', this.cfg.urlCertidao], { detached: true, stdio: 'ignore' });
    filho.on('error', (e) => aviso(e.message));
    filho.on('exit', (codigo) => { if (codigo) aviso(`código ${codigo}`); });
    filho.unref();
  }

  // CNPJ da empresa da vez para a extensão (tecla V e preenchimento automático). Só atende
  // este computador (127.0.0.1) e só enquanto o assistente está esperando um PDF.
  iniciarServidorCnpj() {
    const { portaCnpj } = this.cfg;
    this.servidorCnpj = http.createServer((req, res) => {
      if (req.url === '/cnpj') {
        this.extensao.consultas++;
        this.extensao.ultimaConsulta = Date.now();
        this.mudou();
      }
      if (req.method !== 'GET' || req.url !== '/cnpj' || !this.empresaDaVez) {
        res.writeHead(404).end();
        return;
      }
      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
      res.end(JSON.stringify({ cnpj: this.empresaDaVez.documento, nome: this.empresaDaVez.nome }));
    });
    this.servidorCnpj.on('error', (e) => {
      this.servidorAtivo = false;
      const motivo = e.code === 'EADDRINUSE' ? ' (outra janela do assistente já está aberta?)' : '';
      this.log(`  AVISO: não consegui usar a porta ${portaCnpj} (${e.code})${motivo}; a extensão não vai receber o CNPJ, use V ou Cmd+V.`, 'aviso');
      this.mudou();
    });
    this.servidorCnpj.on('listening', () => {
      this.servidorAtivo = true;
      this.mudou();
    });
    this.servidorCnpj.listen(portaCnpj, '127.0.0.1');
  }

  fecharServidorCnpj() {
    try {
      this.servidorCnpj?.close();
    } catch {
      // Já estava fechado (ou nunca chegou a abrir).
    }
    this.servidorCnpj = null;
    this.servidorAtivo = false;
  }

  // ---------- uma empresa ----------

  mostrarEmpresa(empresa, contagem) {
    const tipo = tipoDoDocumento(empresa.chave);
    this.log([
      '\n==============================================================',
      `  ${linhaPlacar(contagem)}`,
      `  EMPRESA: ${empresa.nome || '(sem nome)'}`,
      `  ${tipo} ${empresa.documento} copiado.`,
      `  Na aba nova do Chrome ${tipo === 'CPF' ? 'a extensão escolhe "CPF Empregador" e o CPF entra' : 'o CNPJ entra'} sozinho (se não entrar: V ou Cmd+V).`,
      '  Faça a verificação "Confirme que é humano".',
      '  Comandos: c = copiar de novo, p = pular, s = sair',
      '==============================================================',
      '  Aguardando o PDF em Downloads...',
    ].join('\n'));
  }

  // Cada empresa ganha uma aba nova do site, com o formulário limpo e o CNPJ já copiado.
  // A aba anterior é fechada pela extensão depois do download. Devolve o resultado da
  // empresa ({ situacao, mensagem, pdf }) ou null se a pessoa pediu para parar.
  async emitir(empresa, contagem) {
    this.copiar(empresa.documento);
    this.abrirSite();
    this.mostrarEmpresa(empresa, contagem);
    this.etapa = 'aguardando-pdf';
    this.mudou();
    let antes = this.pdfsEmDownloads();
    while (true) {
      const resultado = await this.aguardarPdfOuComando(antes);
      if (resultado.comando !== undefined) {
        if (resultado.comando === 'c') {
          this.copiar(empresa.documento);
          this.log(`  CNPJ ${empresa.documento} copiado de novo.`);
        } else if (resultado.comando === 'p') {
          return { situacao: SITUACAO.pulada, mensagem: 'Pulada na janela do assistente' };
        } else if (resultado.comando === 's') {
          return null;
        } else if (resultado.comando) {
          this.log('  Comando não reconhecido. Use c = copiar de novo, p = pular, s = sair.', 'aviso');
        }
        continue;
      }

      const pdf = fs.readFileSync(resultado.arquivo);
      const conferencia = await conferirPdf(empresa, pdf);
      if (!conferencia.ok) {
        this.log(`  ATENÇÃO: ${resultado.nome} ficou em Downloads: ${conferencia.mensagem}.`, 'aviso');
        this.log(`  Emita de novo para ${empresa.nome} ou digite p para pular.`, 'aviso');
        antes = this.pdfsEmDownloads();
        continue;
      }
      const destino = salvarPdf(this.pastaDoLote, empresa, pdf);
      fs.unlinkSync(resultado.arquivo);
      this.log(`  Salvo: ${path.basename(destino)} (${conferencia.mensagem})`, 'ok');
      return { situacao: SITUACAO.salvo, pdf: destino, mensagem: conferencia.mensagem };
    }
  }

  // Pausa sorteada entre uma empresa e a próxima. Devolve false se a pessoa pediu para
  // parar durante a pausa.
  async pausarEntreEmpresas(min = this.cfg.pausaMin, max = this.cfg.pausaMax) {
    const piso = Math.max(0, Number(min) || 0);
    const teto = Math.max(piso, Number(max) || 0);
    const segundos = Math.round(piso + Math.random() * (teto - piso));
    if (segundos <= 0) return true;
    this.log(`\n  Pausa de ${segundos}s antes da próxima empresa... (s = parar)`);
    this.etapa = 'pausa';
    this.mudou();
    const fim = Date.now() + segundos * 1000;
    while (Date.now() < fim) {
      const comando = await this.fila.proximo(Math.min(1000, fim - Date.now()));
      if (comando === 's') return false;
    }
    return true;
  }
}
