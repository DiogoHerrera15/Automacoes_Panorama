// Abre a interface gráfica: node src/interface/iniciar.js [--sem-abrir]
// A porta é a 47330 (PORTA_INTERFACE no ambiente muda). Se a interface já estiver aberta
// nessa porta, só abre o navegador nela.

import { spawn } from 'node:child_process';
import { criarConfig, PORTA_INTERFACE } from '../config.js';
import { iniciarInterface, NOME_APP } from './servidor.js';

const porta = Number(process.env.PORTA_INTERFACE ?? PORTA_INTERFACE);
const abrir = !process.argv.includes('--sem-abrir');

function abrirNavegador(url) {
  if (!abrir) return;
  const filho = spawn('open', [url], { detached: true, stdio: 'ignore' });
  filho.on('error', () => console.log(`Abra ${url} no navegador.`));
  filho.unref();
}

async function jaEstaAberta() {
  try {
    const resposta = await fetch(`http://127.0.0.1:${porta}/api/ping`, { signal: AbortSignal.timeout(1500) });
    return (await resposta.json()).app === NOME_APP;
  } catch {
    return false;
  }
}

try {
  const interfaceGrafica = await iniciarInterface({ cfg: criarConfig(), porta, aoEncerrar: () => process.exit(0) });
  console.log(`Retirar_Auto_Infracao - interface aberta em ${interfaceGrafica.url}`);
  console.log('Deixe esta janela aberta enquanto usa a interface. Para fechar: botão "Fechar interface" ou Ctrl+C.');
  abrirNavegador(interfaceGrafica.url);
  const sair = () => interfaceGrafica.fechar().finally(() => process.exit(0));
  process.on('SIGINT', sair);
  process.on('SIGTERM', sair);
} catch (e) {
  if (e.code === 'EADDRINUSE' && (await jaEstaAberta())) {
    console.log(`A interface já está aberta em http://127.0.0.1:${porta}/ - abrindo no navegador.`);
    abrirNavegador(`http://127.0.0.1:${porta}/`);
  } else {
    console.error(e.code === 'EADDRINUSE' ? `A porta ${porta} está em uso por outro programa. Use PORTA_INTERFACE=<outra porta>.` : e);
    process.exitCode = 1;
  }
}
