// Interface do Retirar_Auto_Infracao. Não tem lógica de negócio: valida e executa tudo no
// servidor (src/interface/servidor.js) e só mostra o estado e o registro que chegam por SSE.
'use strict';

const token = document.querySelector('meta[name="token"]').content;
const $ = (id) => document.getElementById(id);

let estado = null;
let faseAnterior = null;
let listaEditada = false;
let temporizadorSalvar = null;
let tarefaDeSalvar = Promise.resolve();

// ---------- chamadas ao servidor ----------

async function chamar(rota, corpo) {
  let resposta;
  try {
    resposta = await fetch(rota, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Token': token },
      body: JSON.stringify(corpo ?? {}),
    });
  } catch {
    throw new Error('Não consegui falar com a interface. Ela foi fechada?');
  }
  const dados = await resposta.json().catch(() => ({}));
  if (!resposta.ok) throw new Error(dados.erro || `Erro ${resposta.status}`);
  return dados;
}

let temporizadorToast = null;
function avisar(texto, tipo = 'erro') {
  const toast = $('aviso-toast');
  toast.textContent = texto;
  toast.className = `toast ${tipo === 'ok' ? 'ok' : ''}`;
  clearTimeout(temporizadorToast);
  temporizadorToast = setTimeout(() => toast.classList.add('oculto'), 6000);
}

// Executa uma ação e mostra o erro (se houver) em vez de falhar em silêncio.
async function agir(rota, corpo) {
  try {
    return await chamar(rota, corpo);
  } catch (e) {
    avisar(e.message);
    return null;
  }
}

// ---------- lista ----------

function salvarLista() {
  clearTimeout(temporizadorSalvar);
  const texto = $('lista').value;
  $('salvo-status').textContent = 'Salvando…';
  // Uma gravação por vez, na ordem em que foram pedidas.
  tarefaDeSalvar = tarefaDeSalvar.then(async () => {
    try {
      await chamar('/api/lista', { texto });
      if ($('lista').value === texto) listaEditada = false;
      $('salvo-status').textContent = 'Lista salva';
    } catch (e) {
      $('salvo-status').textContent = 'Não salvou';
      avisar(e.message);
    }
  });
  return tarefaDeSalvar;
}

$('lista').addEventListener('input', () => {
  listaEditada = true;
  $('salvo-status').textContent = 'Editando…';
  clearTimeout(temporizadorSalvar);
  temporizadorSalvar = setTimeout(salvarLista, 700);
});

// ---------- botões ----------

$('b-iniciar').addEventListener('click', async () => {
  clearTimeout(temporizadorSalvar);
  await tarefaDeSalvar;
  const ok = await agir('/api/iniciar', {
    texto: $('lista').value,
    refazerPuladas: $('o-refazer').checked,
    pausaMin: Number($('o-pausa-min').value) || 0,
    pausaMax: Number($('o-pausa-max').value) || 0,
  });
  if (ok) listaEditada = false;
});
$('b-parar').addEventListener('click', () => agir('/api/comando', { comando: 's' }));
$('b-copiar').addEventListener('click', () => agir('/api/comando', { comando: 'c' }));
$('b-pular').addEventListener('click', () => {
  if (confirm('Pular esta empresa? Ela fica como "pulada" e dá para refazer depois.')) agir('/api/comando', { comando: 'p' });
});
$('b-organizar').addEventListener('click', async () => {
  await tarefaDeSalvar;
  agir('/api/organizar', { texto: $('lista').value });
});
$('b-novo-lote').addEventListener('click', async () => {
  if (!confirm('Encerrar o lote atual?\n\nIsso apaga a lista e o controle do lote (os PDFs e o relatório já gerados são mantidos).')) return;
  if (await agir('/api/novo-lote')) {
    $('lista').value = '';
    listaEditada = false;
    avisar('Lote encerrado.', 'ok');
  }
});
$('b-pasta-lote').addEventListener('click', () => agir('/api/abrir-pasta', { alvo: 'lote' }));
$('b-pasta-raiz').addEventListener('click', () => agir('/api/abrir-pasta', { alvo: 'raiz' }));
$('b-fechar').addEventListener('click', async () => {
  if (!confirm('Fechar a interface?')) return;
  if (await agir('/api/encerrar')) {
    $('pill-fase').className = 'pill';
    $('pill-fase').textContent = 'Interface fechada';
    document.body.style.opacity = '0.6';
  }
});

// ---------- registro (log) ----------

const MAX_LINHAS = 2000;
const logEl = $('log');
const horaDe = (ms) => new Date(ms).toLocaleTimeString('pt-BR');

function acrescentarLog(entrada) {
  const texto = String(entrada.texto).replace(/^\n+|\n+$/g, '');
  if (!texto) return;
  const linha = document.createElement('span');
  linha.className = `l ${entrada.nivel}`;
  const hora = document.createElement('span');
  hora.className = 'hora';
  hora.textContent = horaDe(entrada.hora);
  linha.append(hora, texto);
  logEl.append(linha);
  while (logEl.childElementCount > MAX_LINHAS) logEl.firstElementChild.remove();
  if ($('l-rolar').checked) logEl.scrollTop = logEl.scrollHeight;
}

$('l-limpar').addEventListener('click', () => { logEl.textContent = ''; });
$('l-copiar').addEventListener('click', async () => {
  try {
    await navigator.clipboard.writeText(logEl.innerText);
    avisar('Registro copiado.', 'ok');
  } catch {
    avisar('Não consegui copiar; selecione o texto e use Cmd+C.');
  }
});

// ---------- desenho ----------

const CHIPS = {
  'PDF salvo': 'ok',
  pendente: '',
  pulada: 'aviso',
  'em andamento': 'info',
  inválido: 'erro',
  repetido: 'aviso',
};

function desenharTabela(itens) {
  const corpo = $('corpo-tabela');
  corpo.textContent = '';
  $('tabela-vazia').classList.toggle('oculto', itens.length > 0);
  for (const [posicao, item] of itens.entries()) {
    const tr = document.createElement('tr');
    if (item.situacao === 'em andamento') tr.className = 'atual-linha';
    const celula = (classe, conteudo) => {
      const td = document.createElement('td');
      td.className = classe;
      if (conteudo instanceof Node) td.append(conteudo); else td.textContent = conteudo;
      return td;
    };
    const chip = document.createElement('span');
    chip.className = `chip ${CHIPS[item.situacao] ?? ''}`;
    chip.textContent = item.situacao === 'inválido' ? 'inválido' : item.situacao;
    const detalhe = document.createElement('div');
    detalhe.textContent = item.mensagem;
    if (item.pdf) {
      const arquivo = document.createElement('div');
      arquivo.className = 'arquivo';
      arquivo.textContent = item.pdf;
      detalhe.append(arquivo);
    }
    tr.append(
      celula('num', posicao + 1),
      celula('', item.nome || '(sem nome)'),
      celula('doc', `${item.tipo ? `${item.tipo} ` : ''}${item.documento}`),
      celula('', chip),
      celula('detalhe', detalhe),
    );
    corpo.append(tr);
  }
}

function pill(id, texto, tipo, extra = '') {
  const el = $(id);
  el.textContent = texto;
  el.className = `pill ${tipo} ${extra}`.trim();
}

function desenharExtensao() {
  if (!estado) return;
  const { consultas, ultimaConsulta } = estado.extensao;
  if (!consultas) {
    pill('pill-extensao', estado.fase === 'executando' ? 'Extensão: aguardando contato' : 'Extensão: sem contato', '');
    return;
  }
  const segundos = Math.max(0, Math.round((Date.now() - ultimaConsulta) / 1000));
  pill('pill-extensao', `Extensão: contato há ${segundos < 90 ? `${segundos}s` : `${Math.round(segundos / 60)} min`}`, 'ok');
}
setInterval(desenharExtensao, 1000);

const DICAS = {
  'aguardando-pdf': 'No Chrome, a extensão preenche o documento e clica em Emitir. Faça a verificação "Confirme que é humano"; o PDF é baixado, conferido e salvo sozinho.',
  pausa: 'Pausa entre empresas. A próxima abre sozinha ao fim da contagem (você pode parar).',
};

function desenhar(e) {
  estado = e;
  const executando = e.fase === 'executando';

  // Cabeçalho
  if (e.parando) pill('pill-fase', 'Parando…', 'aviso', 'executando');
  else if (executando) pill('pill-fase', 'Em execução', 'info', 'executando');
  else pill('pill-fase', 'Pronto', 'ok');
  pill('pill-conexao', 'Interface conectada', 'ok');
  desenharExtensao();

  // A caixa de texto é da pessoa: só é preenchida pelo servidor ao abrir a página e quando
  // uma execução termina (o fim do lote esvazia a lista). Nunca enquanto ela digita.
  const terminouAgora = faseAnterior === 'executando' && !executando;
  if (faseAnterior === null || terminouAgora) {
    if ($('lista').value !== e.listaTexto) $('lista').value = e.listaTexto;
    listaEditada = false;
  }
  faseAnterior = e.fase;
  $('lista').readOnly = executando;

  // Contadores e barra
  const c = e.contagem;
  $('c-total').textContent = c.total;
  $('c-feitas').textContent = c.feitas;
  $('c-faltam').textContent = c.faltam;
  $('c-puladas').textContent = c.puladas;
  $('c-invalidos').textContent = c.invalidos;
  const pct = c.total ? Math.round(((c.feitas + c.puladas) / c.total) * 100) : 0;
  $('barra-preenchida').style.width = `${pct}%`;
  $('barra').setAttribute('aria-valuenow', String(pct));
  const partes = [];
  if (c.repetidos) partes.push(`${c.repetidos} repetido(s)`);
  if (c.invalidos) partes.push(`${c.invalidos} inválido(s)`);
  // O resumo é da lista que está na caixa; depois do fim do lote a caixa fica vazia.
  $('lista-resumo').textContent = !e.mostrandoUltimoLote && (c.total || partes.length) ? [`${c.total} para emitir`, ...partes].join(' · ') : '';

  // Empresa da vez
  const atual = $('atual');
  atual.classList.toggle('oculto', !e.empresaAtual);
  if (e.empresaAtual) {
    $('atual-nome').textContent = e.empresaAtual.nome || '(sem nome)';
    $('atual-doc').textContent = `${e.empresaAtual.tipo} ${e.empresaAtual.documento}`;
    $('atual-etapa').textContent = e.etapa === 'aguardando-pdf' ? 'Aguardando o PDF em Downloads…' : '';
    $('atual-dica').textContent = DICAS[e.etapa] ?? '';
  }

  // Faixa de avisos
  const faixa = $('aviso-geral');
  let aviso = '';
  let tipo = '';
  if (executando && !e.servidorCnpjAtivo && e.etapa) {
    aviso = `A porta ${e.portaCnpj} não está disponível (outra janela do assistente aberta?). A extensão não receberá o CNPJ: use V ou Cmd+V no site.`;
  } else if (!executando && c.faltam === 0 && c.feitas > 0 && e.mostrandoUltimoLote) {
    aviso = `Lote concluído: ${c.feitas} certidão(ões) salva(s).`;
    tipo = 'ok';
  } else if (!executando && c.puladas > 0) {
    aviso = `${c.puladas} empresa(s) pulada(s): use "Refazer as empresas puladas" em Opções e inicie de novo, ou encerre o lote.`;
  }
  faixa.textContent = aviso;
  faixa.className = `faixa ${tipo}${aviso ? '' : ' oculto'}`;

  // Tabela e rótulo do último lote
  desenharTabela(e.itens);
  $('rotulo-ultimo').classList.toggle('oculto', !e.mostrandoUltimoLote);

  // Botões
  // Depois do fim do lote a tabela mostra o lote concluído, mas não há nada novo para iniciar.
  const temValidos = c.total > 0 && !e.mostrandoUltimoLote;
  $('b-iniciar').disabled = executando || !temValidos;
  $('b-iniciar').textContent = executando ? '▶ Em execução' : !e.mostrandoUltimoLote && (c.feitas || c.puladas) ? '▶ Continuar' : '▶ Iniciar';
  $('b-parar').disabled = !executando || e.parando;
  $('b-copiar').disabled = !executando || !e.empresaAtual;
  $('b-pular').disabled = !executando || !e.empresaAtual;
  $('b-organizar').disabled = executando || !temValidos;
  $('b-novo-lote').disabled = executando;
  $('b-pasta-lote').disabled = !e.pastaLote;
  $('b-fechar').disabled = executando;
}

// ---------- eventos em tempo real ----------

function conectar() {
  const origem = new EventSource(`/api/eventos?t=${encodeURIComponent(token)}`);
  origem.addEventListener('logs', (ev) => {
    logEl.textContent = '';
    JSON.parse(ev.data).forEach(acrescentarLog);
  });
  origem.addEventListener('log', (ev) => acrescentarLog(JSON.parse(ev.data)));
  origem.addEventListener('estado', (ev) => desenhar(JSON.parse(ev.data)));
  origem.onopen = () => { if (estado) pill('pill-conexao', 'Interface conectada', 'ok'); };
  origem.onerror = () => {
    pill('pill-conexao', 'Interface desconectada', 'erro');
    pill('pill-fase', 'Sem conexão', 'erro');
  };
}

conectar();
