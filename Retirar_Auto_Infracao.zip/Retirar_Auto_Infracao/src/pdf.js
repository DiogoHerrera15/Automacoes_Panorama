// Leitura e conferência do PDF da certidão. Lógica idêntica à do certidao-trabalhista.js
// original.

import { getDocument } from 'pdfjs-dist/legacy/build/pdf.mjs';
import { chaveDoc, cnpjValido, cpfValido } from './documentos.js';

// Texto do PDF sem espaços: o site quebra o CNPJ em pedaços ("36.526.266/0001 - 10").
export async function textoDoPdf(pdf) {
  const doc = await getDocument({ data: new Uint8Array(pdf), verbosity: 0 }).promise;
  try {
    let texto = '';
    for (let i = 1; i <= doc.numPages; i++) {
      texto += (await (await doc.getPage(i)).getTextContent()).items.map((item) => item.str).join('');
    }
    return texto.replace(/\s+/g, '');
  } finally {
    await doc.destroy();
  }
}

export function ehCertidaoTrabalhista(texto) {
  return texto.normalize('NFD').replace(/[̀-ͯ]/g, '').toUpperCase().includes('CERTIDAODEDEBITOSTRABALHISTAS');
}

// CNPJs (formatados ou só dígitos) que aparecem no texto do PDF.
export function cnpjsNoTexto(texto) {
  const achados = texto.match(/[0-9A-Z]{2}\.?[0-9A-Z]{3}\.?[0-9A-Z]{3}\/?[0-9A-Z]{4}-?\d{2}/g) ?? [];
  return new Set(achados.map(chaveDoc).filter(cnpjValido));
}

// CPFs formatados que aparecem no texto do PDF (certidão emitida para pessoa física).
export function cpfsNoTexto(texto) {
  const achados = texto.match(/\d{3}\.\d{3}\.\d{3}-\d{2}/g) ?? [];
  return new Set(achados.map(chaveDoc).filter(cpfValido));
}

export function documentosNoTexto(texto) {
  return new Set([...cnpjsNoTexto(texto), ...cpfsNoTexto(texto)]);
}

// Confere o PDF baixado. Devolve { ok, mensagem }; ok false deixa o arquivo em Downloads.
export async function conferirPdf(empresa, pdf) {
  if (pdf.subarray(0, 4).toString() !== '%PDF') return { ok: false, mensagem: 'não é um PDF válido' };
  let texto;
  try {
    texto = await textoDoPdf(pdf);
  } catch (e) {
    return { ok: true, mensagem: `Salvo sem conferir o CNPJ (não consegui ler o PDF: ${e.message})` };
  }
  if (!ehCertidaoTrabalhista(texto)) return { ok: false, mensagem: 'não é a Certidão de Débitos Trabalhistas' };
  const documentos = documentosNoTexto(texto);
  if (documentos.has(empresa.chave)) return { ok: true, mensagem: `${empresa.chave.length === 11 ? 'CPF' : 'CNPJ'} conferido no PDF` };
  // A certidão pode trazer só a raiz do CNPJ (os 8 primeiros dígitos), que vale para
  // todos os estabelecimentos. CPF não tem raiz.
  if (empresa.chave.length === 14 && chaveDoc(texto).includes(empresa.chave.slice(0, 8))) return { ok: true, mensagem: 'Raiz do CNPJ conferida no PDF' };
  if (!documentos.size) return { ok: true, mensagem: 'Salvo sem conferir o CPF/CNPJ (não achei CPF/CNPJ no texto do PDF)' };
  return { ok: false, mensagem: `o PDF é de outro CPF/CNPJ (${[...documentos].join(', ')})` };
}
