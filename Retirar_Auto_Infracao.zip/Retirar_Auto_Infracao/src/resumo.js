// Contagens e linhas de andamento (para o terminal e para a interface).

import path from 'node:path';
import { tipoDoDocumento } from './documentos.js';
import { SITUACAO } from './persistencia.js';

// Contagem da lista: quantas já têm PDF, quantas foram puladas e quantas ainda faltam.
export function placar(controle, chaves) {
  const situacoes = chaves.map((k) => controle.documentos[k].situacao);
  const contar = (s) => situacoes.filter((x) => x === s).length;
  return { total: chaves.length, feitas: contar(SITUACAO.salvo), puladas: contar(SITUACAO.pulada), faltam: contar(SITUACAO.pendente) };
}

export function linhaPlacar({ total, feitas, puladas, faltam }) {
  return `Feitas: ${feitas} de ${total} | Faltam: ${faltam}${puladas ? ` | Puladas: ${puladas}` : ''}`;
}

// Uma linha por registro da lista, com a situação de cada um, para a interface.
// `emAndamento` é a chave do documento que está sendo emitido agora (ou '').
export function montarItens(registros, controle, emAndamento = '') {
  const vistos = new Set();
  return registros.map((r) => {
    const c = r.problema ? null : controle?.documentos?.[r.chave];
    let situacao;
    if (r.problema) situacao = 'inválido';
    else if (vistos.has(r.chave)) situacao = 'repetido';
    else if (emAndamento && r.chave === emAndamento) situacao = 'em andamento';
    else situacao = c?.situacao ?? SITUACAO.pendente;
    if (!r.problema) vistos.add(r.chave);
    let mensagem = c?.mensagem ?? '';
    if (r.problema) mensagem = r.problema;
    else if (situacao === 'repetido') mensagem = 'Repetido na lista (é emitido uma vez só)';
    return {
      linha: r.linha,
      nome: r.nome,
      documento: r.documento,
      chave: r.chave,
      tipo: tipoDoDocumento(r.chave),
      situacao,
      mensagem,
      pdf: c?.pdf ? path.basename(c.pdf) : '',
      processadoEm: c?.processadoEm ?? '',
    };
  });
}

export function contarItens(itens) {
  const n = (...sit) => itens.filter((i) => sit.includes(i.situacao)).length;
  const invalidos = n('inválido');
  const repetidos = n('repetido');
  return {
    total: itens.length - invalidos - repetidos,
    feitas: n(SITUACAO.salvo),
    puladas: n(SITUACAO.pulada),
    faltam: n(SITUACAO.pendente, 'em andamento'),
    invalidos,
    repetidos,
  };
}
