// Arquivos do assistente: lista do dia, Controle.json, Relatorio.csv e PDFs do lote.
// Mesmos formatos e nomes do certidao-trabalhista.js original (as pastas de dados agora
// ficam em dados/).

import fs from 'node:fs';
import path from 'node:path';
import { MODELO_LISTA } from './config.js';
import { chaveDoc, interpretarLista, nomeLimpo } from './documentos.js';

export const SITUACAO = {
  pendente: 'pendente',
  salvo: 'PDF salvo',
  pulada: 'pulada',
};

export function agora() {
  return new Date().toLocaleString('pt-BR');
}

// 2026-11-05_09h40, na hora do computador.
export function carimbo() {
  const d = new Date();
  const dois = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${dois(d.getMonth() + 1)}-${dois(d.getDate())}_${dois(d.getHours())}h${dois(d.getMinutes())}`;
}

// --- Lista do dia (COLE_OS_CNPJS_AQUI.txt) ---

export function lerListaArquivo(cfg) {
  if (!fs.existsSync(cfg.arquivoLista)) fs.writeFileSync(cfg.arquivoLista, MODELO_LISTA, 'utf8');
  return interpretarLista(fs.readFileSync(cfg.arquivoLista, 'utf8'));
}

// Só as linhas de dados (sem o cabeçalho de comentários), para mostrar na interface.
export function lerTextoDaLista(cfg) {
  if (!fs.existsSync(cfg.arquivoLista)) return '';
  return fs.readFileSync(cfg.arquivoLista, 'utf8').replace(/^﻿/, '').split(/\r?\n/).filter((l) => l.trim() && !l.trim().startsWith('#')).join('\n');
}

// Grava a lista com o cabeçalho de sempre; `texto` são as linhas de dados.
export function salvarListaArquivo(cfg, texto) {
  const linhas = String(texto).replace(/^﻿/, '').split(/\r?\n/).filter((l) => l.trim());
  fs.writeFileSync(cfg.arquivoLista, `${MODELO_LISTA}${linhas.join('\n')}${linhas.length ? '\n' : ''}`, 'utf8');
}

// --- Controle.json ---

export function novoControle() {
  return { loteIniciadoEm: agora(), loteIniciadoMs: Date.now(), documentos: {} };
}

export function carregarControle(cfg) {
  try {
    return JSON.parse(fs.readFileSync(cfg.arquivoControle, 'utf8'));
  } catch (e) {
    if (e.code === 'ENOENT') return novoControle();
    throw new Error(`Não consegui ler ${cfg.arquivoControle}: ${e.message}`);
  }
}

// Para a interface: nunca lança, devolve null se não houver controle legível.
export function lerControleSeExiste(cfg) {
  try {
    return JSON.parse(fs.readFileSync(cfg.arquivoControle, 'utf8'));
  } catch {
    return null;
  }
}

// Grava num temporário e renomeia, para não deixar o controle pela metade se cair.
export function gravarControle(cfg, controle) {
  fs.mkdirSync(cfg.pastaDados, { recursive: true });
  const temporario = `${cfg.arquivoControle}.tmp`;
  fs.writeFileSync(temporario, JSON.stringify(controle, null, 2), 'utf8');
  fs.renameSync(temporario, cfg.arquivoControle);
}

// --- Relatorio.csv ---

function celulaCsv(valor) {
  const texto = String(valor ?? '');
  return /[;"\r\n]/.test(texto) ? `"${texto.replace(/"/g, '""')}"` : texto;
}

// Devolve true se gravou; false se a planilha estava travada por outro programa.
export function gravarRelatorio(cfg, registros, controle) {
  const cabecalho = ['Linha', 'Empresa', 'CNPJ', 'Situação', 'Mensagem', 'PDF', 'Processado em'];
  const linhas = registros.map((r) => {
    const c = r.problema ? null : controle.documentos[r.chave];
    return c
      ? [r.linha, r.nome, r.documento, c.situacao, c.mensagem, c.pdf, c.processadoEm]
      : [r.linha, r.nome, r.documento, 'CPF/CNPJ inválido', r.problema, '', ''];
  });
  // BOM e ";" para o Excel em português abrir com acentos e colunas certas.
  const csv = `﻿${[cabecalho, ...linhas].map((l) => l.map(celulaCsv).join(';')).join('\r\n')}\r\n`;
  fs.mkdirSync(cfg.pastaDados, { recursive: true });
  try {
    fs.writeFileSync(cfg.arquivoRelatorio, csv, 'utf8');
    return true;
  } catch (e) {
    if (e.code !== 'EBUSY' && e.code !== 'EPERM' && e.code !== 'EACCES') throw e;
    return false;
  }
}

// --- Lote ---

// Fecha o lote: guarda o relatório em dados/Relatorios/ e apaga o controle e a lista do
// dia, para o próximo lote começar do zero.
export function encerrarLote(cfg) {
  let pastaLote = '';
  try {
    pastaLote = JSON.parse(fs.readFileSync(cfg.arquivoControle, 'utf8')).pastaLote ?? '';
  } catch {
    // Sem controle: não há pasta de lote para guardar o relatório.
  }
  if (fs.existsSync(cfg.arquivoRelatorio)) {
    fs.mkdirSync(cfg.pastaRelatorios, { recursive: true });
    fs.copyFileSync(cfg.arquivoRelatorio, path.join(cfg.pastaRelatorios, `Relatorio_${carimbo()}.csv`));
    if (pastaLote && fs.existsSync(pastaLote)) fs.copyFileSync(cfg.arquivoRelatorio, path.join(pastaLote, 'Relatorio.csv'));
  }
  fs.rmSync(cfg.arquivoControle, { force: true });
  fs.rmSync(cfg.arquivoRelatorio, { force: true });
  fs.writeFileSync(cfg.arquivoLista, MODELO_LISTA, 'utf8');
}

// <CNPJ>;<NOME DA EMPRESA>.pdf; se o arquivo já existir, o novo ganha " (2)", " (3)"...
// ("wx" falha se o arquivo existir, então um PDF anterior nunca é sobrescrito.)
export function salvarPdf(pastaDoLote, empresa, pdf) {
  const nome = nomeLimpo(empresa.nome);
  const base = nome ? `${empresa.chave};${nome}` : empresa.chave;
  for (let n = 1; ; n++) {
    const arquivo = path.join(pastaDoLote, n === 1 ? `${base}.pdf` : `${base} (${n}).pdf`);
    try {
      fs.writeFileSync(arquivo, pdf, { flag: 'wx' });
      return arquivo;
    } catch (e) {
      if (e.code !== 'EEXIST') throw e;
    }
  }
}

// PDF que já está na pasta do lote com o CNPJ no nome marca a empresa como PDF salvo.
export function marcarJaSalvas(pastaDoLote, controle) {
  const arquivos = fs.readdirSync(pastaDoLote).filter((a) => /\.pdf$/i.test(a));
  let marcadas = 0;
  for (const empresa of Object.values(controle.documentos)) {
    if (empresa.situacao === SITUACAO.salvo) continue;
    // Só vale PDF salvo depois que o lote começou: certidões de lotes antigos na pasta não
    // contam, senão a empresa ficaria sem emitir de novo.
    const arquivo = arquivos.find((a) => chaveDoc(a).includes(empresa.chave) && fs.statSync(path.join(pastaDoLote, a)).mtimeMs >= (controle.loteIniciadoMs ?? 0));
    if (!arquivo) continue;
    Object.assign(empresa, { situacao: SITUACAO.salvo, pdf: path.join(pastaDoLote, arquivo), mensagem: 'PDF já estava na pasta' });
    marcadas++;
  }
  return marcadas;
}
