// Uso pelo terminal (mesmas opções do certidao-trabalhista.js original):
//   node src/cli.js                     todas as pendentes
//   node src/cli.js --verificar         só confere a lista, sem copiar nada
//   node src/cli.js --organizar         só move para a pasta as certidões que já estão em Downloads
//   node src/cli.js --refazer-puladas   volta as puladas para pendente
//   node src/cli.js --novo-lote         encerra o lote atual (apaga lista e controle)
// Pausa entre empresas: PAUSA_MIN=20 PAUSA_MAX=45 ./INICIAR.command
// Enquanto roda: c = copiar o CNPJ de novo, p = pular a empresa, s = sair.

import readline from 'node:readline';
import { Assistente, ErroDeUso } from './assistente.js';
import { criarConfig } from './config.js';

const OPCOES = ['--verificar', '--organizar', '--refazer-puladas', '--novo-lote'];

function lerOpcoes(args) {
  const desconhecida = args.find((a) => !OPCOES.includes(a));
  if (desconhecida) throw new ErroDeUso(`Opção desconhecida: ${desconhecida}. Opções válidas: ${OPCOES.join(' ')}`);
  return {
    verificar: args.includes('--verificar'),
    organizar: args.includes('--organizar'),
    refazerPuladas: args.includes('--refazer-puladas'),
    novoLote: args.includes('--novo-lote'),
  };
}

async function principal() {
  const opcoes = lerOpcoes(process.argv.slice(2));
  const assistente = new Assistente(criarConfig());
  assistente.on('log', ({ nivel, texto }) => (nivel === 'info' || nivel === 'ok' ? console.log(texto) : console.warn(texto)));

  if (opcoes.novoLote) return assistente.novoLote();
  if (opcoes.verificar) return assistente.verificar();

  // Comandos digitados na janela enquanto o assistente espera o PDF.
  readline.createInterface({ input: process.stdin }).on('line', (linha) => assistente.enviarComando(linha));
  try {
    await assistente.executar({ organizar: opcoes.organizar, refazerPuladas: opcoes.refazerPuladas });
  } finally {
    process.stdin.destroy();
  }
}

principal().catch((e) => {
  console.error(e instanceof ErroDeUso ? e.message : e);
  process.exitCode = 1;
});
