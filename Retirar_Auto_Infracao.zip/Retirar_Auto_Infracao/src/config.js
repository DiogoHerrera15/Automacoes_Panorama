// Configuração central: caminhos, portas e constantes usados pelo terminal e pela interface.

import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

export const RAIZ_PADRAO = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

export const URL_CERTIDAO = 'https://eprocesso.sit.trabalho.gov.br/Certidao/Emitir';

// Porta em que o assistente informa à extensão o CNPJ da vez. Tem de ser a mesma do
// extensao-chrome/fundo.js e do host_permissions do manifest.json (há um teste que confere).
export const PORTA_CNPJ = 47321;

// Porta da interface gráfica (só neste computador).
export const PORTA_INTERFACE = 47330;

export const MODELO_LISTA = [
  '# Cole aqui os CNPJs que vai trabalhar, um por linha. Linhas com # são ignoradas.',
  '# Pode ser só o CNPJ ou "CNPJ;NOME DA EMPRESA" (o nome vai no nome do PDF).',
  '# Também dá para copiar as colunas CNPJ e Empresa da planilha e colar aqui.',
  '# Ao terminar o lote, este arquivo é esvaziado sozinho.',
  '',
].join('\n');

const numero = (valor, padrao) => (valor === undefined || valor === '' || !Number.isFinite(Number(valor)) ? padrao : Number(valor));

// `extra` serve para os testes e para a interface; no uso normal vale o padrão + variáveis
// de ambiente (PASTA_DOWNLOADS, PAUSA_MIN, PAUSA_MAX, ASSISTENTE_TESTE), como antes.
export function criarConfig(extra = {}) {
  const raiz = path.resolve(extra.raiz ?? RAIZ_PADRAO);
  const pastaDados = path.join(raiz, 'dados');
  const pausaMin = Math.max(0, numero(extra.pausaMin ?? process.env.PAUSA_MIN, 0));
  return {
    raiz,
    // Lista do dia: a pessoa cola aqui os CNPJs do lote. Ao terminar o lote, é esvaziada.
    arquivoLista: path.join(raiz, 'COLE_OS_CNPJS_AQUI.txt'),
    pastaDados,
    pastaRelatorios: path.join(pastaDados, 'Relatorios'),
    arquivoControle: path.join(pastaDados, 'Controle.json'),
    arquivoRelatorio: path.join(pastaDados, 'Relatorio.csv'),
    pastaDownloads: extra.pastaDownloads ?? process.env.PASTA_DOWNLOADS ?? path.join(os.homedir(), 'Downloads'),
    // Pausa sorteada entre uma empresa e a próxima, em segundos (padrão: sem pausa).
    pausaMin,
    pausaMax: Math.max(pausaMin, numero(extra.pausaMax ?? process.env.PAUSA_MAX, 0)),
    portaCnpj: extra.portaCnpj ?? PORTA_CNPJ,
    intervaloDownloads: extra.intervaloDownloads ?? 1000,
    urlCertidao: URL_CERTIDAO,
    // ASSISTENTE_TESTE=1: não mexe na área de transferência nem abre o Chrome.
    modoTeste: extra.modoTeste ?? process.env.ASSISTENTE_TESTE === '1',
  };
}
