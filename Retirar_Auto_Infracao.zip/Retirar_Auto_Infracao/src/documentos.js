// CPF/CNPJ: validação, formatação e leitura da lista do dia. Lógica idêntica à do
// certidao-trabalhista.js original; só foi separada em módulo e a leitura do texto ficou
// independente do arquivo (interpretarLista), para a interface poder validar antes de salvar.

// Só letras e números, em maiúsculas (o CNPJ alfanumérico vale desde julho/2026).
export function chaveDoc(documento) {
  return documento.replace(/[^0-9A-Za-z]/g, '').toUpperCase();
}

// Dígitos verificadores do CNPJ; letras valem o código ASCII menos 48, como manda a RFB.
export function cnpjValido(chave) {
  if (!/^[0-9A-Z]{12}\d{2}$/.test(chave) || /^(.)\1+$/.test(chave)) return false;
  const dv = (base) => {
    let soma = 0;
    let peso = base.length - 7;
    for (const c of base) {
      soma += (c.charCodeAt(0) - 48) * peso--;
      if (peso < 2) peso = 9;
    }
    const resto = soma % 11;
    return resto < 2 ? 0 : 11 - resto;
  };
  const d1 = dv(chave.slice(0, 12));
  return String(d1) === chave[12] && String(dv(chave.slice(0, 12) + d1)) === chave[13];
}

// CNPJ formatado (00.000.000/0000-00) ou 14 caracteres seguidos.
export const RE_CNPJ = /[0-9A-Z]{2}\.[0-9A-Z]{3}\.[0-9A-Z]{3}\/[0-9A-Z]{4}-\d{2}|\b[0-9A-Z]{12}\d{2}\b/i;
// CPF (pessoa física) formatado (000.000.000-00) ou 11 dígitos seguidos. Só vale quando a
// linha não tem CNPJ, porque o nome da empresa pode trazer o CPF do dono.
export const RE_CPF = /\d{3}\.\d{3}\.\d{3}-\d{2}|\b\d{11}\b/;

// Dígitos verificadores do CPF.
export function cpfValido(chave) {
  if (!/^\d{11}$/.test(chave) || /^(.)\1+$/.test(chave)) return false;
  const dv = (base) => {
    const soma = [...base].reduce((total, c, i) => total + Number(c) * (base.length + 1 - i), 0);
    const resto = (soma * 10) % 11;
    return resto === 10 ? 0 : resto;
  };
  const d1 = dv(chave.slice(0, 9));
  return String(d1) === chave[9] && String(dv(chave.slice(0, 9) + d1)) === chave[10];
}

export function documentoValido(chave) {
  return cnpjValido(chave) || cpfValido(chave);
}

export function formatarDocumento(chave) {
  if (chave.length === 11) return `${chave.slice(0, 3)}.${chave.slice(3, 6)}.${chave.slice(6, 9)}-${chave.slice(9)}`;
  return `${chave.slice(0, 2)}.${chave.slice(2, 5)}.${chave.slice(5, 8)}/${chave.slice(8, 12)}-${chave.slice(12)}`;
}

export function tipoDoDocumento(chave) {
  if (chave.length === 11) return 'CPF';
  if (chave.length === 14) return 'CNPJ';
  return '';
}

// Lista do dia: uma empresa por linha, em qualquer um destes jeitos: "CNPJ", "CNPJ;NOME",
// "CNPJ - NOME" ou colunas coladas da planilha (separadas por tab). O nome é opcional.
// Linhas vazias e com # são ignoradas.
export function interpretarLista(conteudo) {
  const registros = [];
  const linhas = conteudo.replace(/^﻿/, '').split(/\r?\n/);
  for (const [i, linha] of linhas.entries()) {
    const texto = linha.trim();
    if (!texto || texto.startsWith('#')) continue;
    const achado = texto.match(RE_CNPJ) ?? texto.match(RE_CPF);
    if (!achado) {
      // Cabeçalho colado da planilha ("CPF/CNPJ Empresa") não é problema; número solto é.
      if ((texto.match(/\d/g) ?? []).length >= 8) {
        registros.push({ linha: i + 1, nome: '', documento: texto, chave: '', problema: `Linha sem CPF/CNPJ reconhecível: ${texto}` });
      }
      continue;
    }
    const chave = chaveDoc(achado[0]);
    const restante = `${texto.slice(0, achado.index)};${texto.slice(achado.index + achado[0].length)}`;
    const nome = restante.split(/[\t;]+/).map((p) => p.replace(/^[\s,-]+|[\s,-]+$/g, '')).find(Boolean) ?? '';
    const valido = documentoValido(chave);
    registros.push({
      linha: i + 1,
      nome: nome.replace(/\s+/g, ' '),
      documento: valido ? formatarDocumento(chave) : achado[0],
      chave,
      problema: valido ? '' : `CPF/CNPJ com formato ou dígito verificador inválido: ${achado[0]}`,
    });
  }
  return registros;
}

// Sem acentos e sem caracteres proibidos em nome de arquivo.
export function nomeLimpo(nome) {
  return nome
    .normalize('NFD').replace(/[̀-ͯ]/g, '')
    .replace(/[\\/:*?"<>|;]/g, ' ').replace(/\s+/g, ' ').trim().replace(/[. ]+$/, '').slice(0, 150);
}
