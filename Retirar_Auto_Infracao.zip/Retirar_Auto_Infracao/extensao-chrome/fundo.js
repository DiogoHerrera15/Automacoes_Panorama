// Parte de fundo da extensão. Só recebe mensagens do baixar.js, que roda apenas no
// eprocesso.sit.trabalho.gov.br.
//
// - fechar-aba: fecha a aba que pediu (a da certidão já baixada), depois da espera.
// - cnpj-da-vez: pergunta ao assistente (src/assistente.js) o CNPJ da empresa da
//   vez, para a tecla V. Se o assistente não estiver aberto, responde vazio.

// Mesma porta do assistente (PORTA_CNPJ em src/config.js).
const URL_CNPJ_DA_VEZ = 'http://127.0.0.1:47321/cnpj';

chrome.runtime.onMessage.addListener((mensagem, remetente, responder) => {
  const aba = remetente.tab?.id;
  if (aba === undefined) return;

  if (mensagem?.tipo === 'fechar-aba') {
    console.log(`[Retirar_Auto_Infracao] Fechando a aba ${aba} em ${mensagem.espera} ms.`);
    setTimeout(() => {
      chrome.tabs.remove(aba).catch((e) => console.warn(`[Retirar_Auto_Infracao] Não fechei a aba ${aba}:`, e.message));
    }, mensagem.espera);
    responder({ ok: true });
    return;
  }

  if (mensagem?.tipo === 'cnpj-da-vez') {
    fetch(URL_CNPJ_DA_VEZ, { cache: 'no-store' })
      .then((r) => (r.ok ? r.json() : {}))
      .catch(() => ({}))
      .then(responder);
    return true; // responde depois do fetch
  }
});
