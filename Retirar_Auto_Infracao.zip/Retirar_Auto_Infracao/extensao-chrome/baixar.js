// Só roda no eprocesso.sit.trabalho.gov.br (ver manifest.json). Na página de emissão,
// deixa o cursor no campo CNPJ, preenche sozinho o CNPJ da vez (com o assistente aberto;
// a tecla V e o Ctrl+V ficam de reserva) e clica em Emitir depois que o CNPJ entra no
// campo. Quando
// a certidão abre na janela "Visualizar certidão", clica na seta de download e, logo
// depois, fecha a aba (o assistente abre a da próxima empresa). A verificação "Confirme
// que é humano" continua sendo feita pela pessoa.
//
// O visualizador do site baixa o PDF como "Document.pdf", e o assistente
// (src/assistente.js) pega o arquivo em Downloads.

// Espera depois de achar o botão, para o PDF terminar de carregar no visualizador.
const ESPERA_ANTES_DO_CLIQUE = 1500;
// Espera depois do clique, para o Chrome terminar de gravar o PDF antes de fechar a aba.
const ESPERA_ANTES_DE_FECHAR = 4000;

// Cada certidão é baixada uma vez: pela inscrição do título da janela ou, se não houver
// título, pelo próprio botão.
const baixadas = new Set();
const botoesClicados = new WeakSet();
let agendado = null;

function visivelEHabilitado(el) {
  return el.offsetParent !== null && !el.disabled && el.getAttribute('aria-disabled') !== 'true' && !el.classList.contains('e-disabled');
}

function botaoDownload() {
  const candidatos = document.querySelectorAll([
    '[id$="_download"]',
    '.e-pv-download-document-icon',
    'button[title*="download" i]',
    'button[aria-label*="download" i]',
    'button[title*="baixar" i]',
    'button[aria-label*="baixar" i]',
  ].join(','));
  for (const el of candidatos) {
    const botao = el.closest('button') ?? el;
    if (visivelEHabilitado(botao)) return botao;
  }
  return null;
}

// "Visualizar certidão - Inscrição: 60.721.223/0001-70" -> "60.721.223/0001-70"
function inscricaoNaTela() {
  for (const el of document.querySelectorAll('h1, h2, h3, h4, h5, h6, .modal-title, .e-dlg-header')) {
    const m = el.textContent.match(/Visualizar certid[aã]o.*Inscri[cç][aã]o:\s*([\d./-]+)/i);
    if (m) return m[1];
  }
  return '';
}

function verificar() {
  agendado = null;
  const botao = botaoDownload();
  if (!botao) return;
  const inscricao = inscricaoNaTela();
  if (inscricao ? baixadas.has(inscricao) : botoesClicados.has(botao)) return;

  setTimeout(() => {
    const atual = botaoDownload();
    if (!atual) return;
    if (inscricao ? baixadas.has(inscricao) : botoesClicados.has(atual)) return;
    if (inscricao) baixadas.add(inscricao);
    botoesClicados.add(atual);
    console.log(`[Retirar_Auto_Infracao] Download clicado${inscricao ? ` para ${inscricao}` : ''}.`);
    // O pedido sai antes do clique e quem espera é o fundo.js: se o download recarregar
    // ou trocar a página, este script some, mas a aba fecha do mesmo jeito.
    pedirFechamento();
    atual.click();
  }, ESPERA_ANTES_DO_CLIQUE);
}

function pedirFechamento() {
  const fecharPelaPagina = () => setTimeout(() => window.close(), ESPERA_ANTES_DE_FECHAR);
  try {
    chrome.runtime.sendMessage({ tipo: 'fechar-aba', espera: ESPERA_ANTES_DE_FECHAR }).catch((e) => {
      console.warn('[Retirar_Auto_Infracao] fundo.js não respondeu; fechando pela página.', e);
      fecharPelaPagina();
    });
  } catch (e) {
    // Extensão recarregada depois que a aba abriu: este script perdeu o contato com ela.
    console.warn('[Retirar_Auto_Infracao] Extensão recarregada; fechando pela página.', e);
    fecharPelaPagina();
  }
}

// Na página de emissão, deixa o cursor no campo CNPJ, para a pessoa só apertar Ctrl+V.
// O campo do site é o #Consulta_NrInscricao; se mudar de nome, vale o primeiro campo de
// texto visível e editável da página.
//
// A aba nova pode abrir antes de o Chrome estar na frente ou de o site terminar de montar
// o campo, e aí um foco só se perde. Por isso o foco é refeito enquanto o campo estiver
// vazio e nada mais da página tiver o cursor, ao abrir e sempre que a janela/aba voltar
// para a frente. Se a pessoa clicar em outro lugar ou digitar algo, a extensão para.
const ESTA_NA_EMISSAO = window === window.top && /\/Certidao\/Emitir/i.test(location.pathname);
const TEMPO_INSISTINDO_NO_FOCO = 15000;

function campoCnpj() {
  return [document.getElementById('Consulta_NrInscricao'), ...document.querySelectorAll('input:not([type]), input[type="text"], input[type="tel"], input[type="search"]')]
    .find((el) => el && el.offsetParent !== null && !el.readOnly && !el.disabled);
}

function focarCampoCnpj() {
  if (!ESTA_NA_EMISSAO) return;
  const campo = campoCnpj();
  if (!campo || campo.value.replace(/\D/g, '') || document.activeElement === campo) return;
  // Outro campo, botão ou a verificação com o cursor: foi a pessoa, não mexe.
  if (document.activeElement && document.activeElement !== document.body) return;
  campo.focus();
}

// Depois que a pessoa cola o CNPJ (Ctrl+V), clica em Emitir: espera a máscara do campo
// formatar e só clica se o CNPJ estiver completo e com os dígitos verificadores certos.
// Cada CNPJ colado é emitido uma vez. A verificação "Confirme que é humano" que aparece
// depois continua com a pessoa.
const ESPERA_DEPOIS_DE_COLAR = 500;
let ultimoEmitido = '';

// Só letras e números, em maiúsculas (o CNPJ alfanumérico vale desde julho/2026).
function chaveDoc(documento) {
  return documento.replace(/[^0-9A-Za-z]/g, '').toUpperCase();
}

// Dígitos verificadores do CNPJ; letras valem o código ASCII menos 48, como manda a RFB.
function cnpjValido(chave) {
  if (!/^[0-9A-Z]{12}\d{2}$/.test(chave) || /^(.)\1+$/.test(chave)) return false;
  const dv = (base) => {
    let soma = 0;
    let peso = base.length - 7;
    for (const c of base) {
      soma += (c.charCodeAt(0) - 48) * peso--;
      if (peso < 2) peso = 9;
    }
    const resto = soma % 11;
    return resto < 2 ? 0 : 11 - resto;
  };
  const d1 = dv(chave.slice(0, 12));
  return String(d1) === chave[12] && String(dv(chave.slice(0, 12) + d1)) === chave[13];
}

// Dígitos verificadores do CPF (pessoa física).
function cpfValido(chave) {
  if (!/^\d{11}$/.test(chave) || /^(.)\1+$/.test(chave)) return false;
  const dv = (base) => {
    const soma = [...base].reduce((total, c, i) => total + Number(c) * (base.length + 1 - i), 0);
    const resto = (soma * 10) % 11;
    return resto === 10 ? 0 : resto;
  };
  const d1 = dv(chave.slice(0, 9));
  return String(d1) === chave[9] && String(dv(chave.slice(0, 9) + d1)) === chave[10];
}

function botaoEmitir() {
  const botao = document.getElementById('btnConsultarInscricaoCertidao')
    ?? [...document.querySelectorAll('button')].find((b) => b.textContent.trim() === 'Emitir');
  return botao && visivelEHabilitado(botao) ? botao : null;
}

function emitirSeValido(campo) {
  setTimeout(() => {
    const chave = chaveDoc(campo.value);
    if (!(cnpjValido(chave) || cpfValido(chave)) || chave === ultimoEmitido) return;
    const botao = botaoEmitir();
    if (!botao) return;
    ultimoEmitido = chave;
    console.log(`[Retirar_Auto_Infracao] Emitir clicado para ${campo.value}.`);
    botao.click();
  }, ESPERA_DEPOIS_DE_COLAR);
}

function emitirDepoisDeColar(evento) {
  const campo = campoCnpj();
  if (campo && evento.target === campo) emitirSeValido(campo);
}

// CNPJ da empresa da vez, que o assistente informa (via fundo.js) enquanto está aberto.
// Com o assistente fechado, resolve com ''.
async function cnpjDaVez() {
  try {
    const { cnpj } = (await chrome.runtime.sendMessage({ tipo: 'cnpj-da-vez' })) ?? {};
    return cnpj ?? '';
  } catch {
    console.warn('[Retirar_Auto_Infracao] Extensão recarregada; feche esta aba e use a aba nova.');
    return '';
  }
}

// Põe o CNPJ no campo (a máscara do site formata no evento input) e segue como se a
// pessoa tivesse colado: confere e clica em Emitir.
const esperar = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

function clicar(el) {
  for (const tipo of ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click']) {
    el.dispatchEvent(new MouseEvent(tipo, { bubbles: true, cancelable: true, view: window }));
  }
}

// Seletor "CNPJ Empregador" / "CPF Empregador" ao lado do campo de inscrição.
function seletorTipo() {
  return [...document.querySelectorAll('select')].find((s) => {
    const textos = [...s.options].map((o) => o.textContent);
    return textos.some((t) => /CPF/i.test(t)) && textos.some((t) => /CNPJ/i.test(t));
  }) ?? null;
}

// Elemento visível e mais interno cujo texto é exatamente o rótulo (menu feito de div/li).
function elementoComTexto(rotulo, ignorar = null) {
  return [...document.querySelectorAll('body *')]
    .filter((el) => el !== ignorar && el.offsetParent !== null && el.textContent.trim().toLowerCase() === rotulo.toLowerCase())
    .pop() ?? null;
}

// Põe o seletor em "CPF Empregador" (documento de 11 dígitos) ou "CNPJ Empregador" e
// espera o site refazer o campo. Clica no bloco, espera a lista abrir e clica na opção.
// Devolve true se o tipo certo ficou escolhido.
async function escolherTipo(chave) {
  const rotulo = chave.length === 11 ? 'CPF Empregador' : 'CNPJ Empregador';
  const seletor = seletorTipo();
  if (seletor) {
    const opcao = [...seletor.options].find((o) => o.textContent.trim().toLowerCase() === rotulo.toLowerCase());
    if (!opcao) return false;
    if (seletor.value === opcao.value) return true;
    seletor.focus();
    clicar(seletor);
    await esperar(400);
    seletor.value = opcao.value;
    seletor.dispatchEvent(new Event('input', { bubbles: true }));
    seletor.dispatchEvent(new Event('change', { bubbles: true }));
    await esperar(800);
    return seletor.value === opcao.value;
  }
  // Menu personalizado: o bloco mostra o tipo atual; clica nele e depois na opção.
  const atual = elementoComTexto('CNPJ Empregador') ?? elementoComTexto('CPF Empregador');
  if (!atual) return false;
  if (atual.textContent.trim().toLowerCase() === rotulo.toLowerCase()) return true;
  clicar(atual);
  await esperar(600);
  const opcao = elementoComTexto(rotulo, atual);
  if (!opcao) return false;
  clicar(opcao);
  await esperar(800);
  return true;
}

// Escolhe o tipo (CPF ou CNPJ), põe o número no campo (a máscara do site formata no evento
// input) e segue como se a pessoa tivesse colado: confere e clica em Emitir.
async function preencherCampo(campo, cnpj, origem) {
  const chave = chaveDoc(cnpj);
  const tipoCerto = await escolherTipo(chave);
  if (!tipoCerto && chave.length === 11) {
    console.warn('[Retirar_Auto_Infracao] Não consegui escolher "CPF Empregador"; escolha na tela e aperte V.');
    return;
  }
  // Ao trocar o tipo o site pode refazer o campo.
  campo = campoCnpj() ?? campo;
  campo.focus();
  campo.value = chave;
  campo.dispatchEvent(new Event('input', { bubbles: true }));
  campo.dispatchEvent(new Event('change', { bubbles: true }));
  console.log(`[Retirar_Auto_Infracao] ${chave.length === 11 ? 'CPF' : 'CNPJ'} ${cnpj} preenchido ${origem}.`);
  emitirSeValido(campo);
}

// Ao abrir a página: com o assistente aberto, preenche sozinho o CNPJ da vez, uma vez
// por aba e só se o campo estiver vazio. Se não der (assistente fechado ou aberto
// depois da aba), a tecla V e o Ctrl+V continuam valendo.
let tentouPreencherSozinho = false;

async function preencherSozinho() {
  if (!ESTA_NA_EMISSAO || tentouPreencherSozinho) return;
  const campo = campoCnpj();
  if (!campo || !botaoEmitir()) return;
  // Espera o site montar a máscara do campo (o .k-maskedtextbox em volta dele), senão o
  // valor posto antes se perde; se o site mudar, vale a página já carregada.
  if (!campo.closest('.k-maskedtextbox') && document.readyState !== 'complete') return;
  tentouPreencherSozinho = true;
  const cnpj = await cnpjDaVez();
  if (cnpj && !chaveDoc(campo.value)) preencherCampo(campo, cnpj, 'ao abrir a página');
}

// Tecla V (sem Ctrl): preenche o campo vazio com o CNPJ da vez. Com o assistente fechado,
// ou com o cursor em outro campo, a tecla V não é alterada.
function preencherComV(evento) {
  if (evento.key.toLowerCase() !== 'v' || evento.ctrlKey || evento.altKey || evento.metaKey || evento.repeat) return;
  const campo = campoCnpj();
  if (!campo || chaveDoc(campo.value)) return;
  const ativo = document.activeElement;
  if (ativo !== campo && ativo && ativo !== document.body) return;

  evento.preventDefault();
  evento.stopPropagation();
  cnpjDaVez().then((cnpj) => {
    if (cnpj) preencherCampo(campo, cnpj, 'pela tecla V');
    else console.log('[Retirar_Auto_Infracao] Assistente fechado: tecla V sem CNPJ para preencher.');
  });
}

if (ESTA_NA_EMISSAO) {
  document.addEventListener('paste', emitirDepoisDeColar, true);
  document.addEventListener('keydown', preencherComV, true);
  const insistir = setInterval(() => {
    focarCampoCnpj();
    preencherSozinho();
  }, 300);
  setTimeout(() => clearInterval(insistir), TEMPO_INSISTINDO_NO_FOCO);
  window.addEventListener('focus', focarCampoCnpj);
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') focarCampoCnpj();
  });
}

new MutationObserver(() => {
  focarCampoCnpj();
  preencherSozinho();
  agendado ??= setTimeout(verificar, 300);
}).observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ['class', 'disabled', 'style'] });

focarCampoCnpj();
preencherSozinho();
verificar();
