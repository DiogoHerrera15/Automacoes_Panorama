# Retirar_Auto_Infracao

Assistente com **interface gráfica** para emitir a **Certidão de Débitos Trabalhistas (MTE)** de vários CPF/CNPJ em
sequência, no site `eprocesso.sit.trabalho.gov.br`. Você informa os documentos, acompanha o andamento na tela e faz só a
verificação "Confirme que é humano"; o resto (preencher, emitir, baixar, conferir o PDF e organizar) é automático.

> O nome "Auto Infração" é o nome do projeto (Panorama Fiscal). O que a automação emite hoje é a **Certidão de Débitos
> Trabalhistas**. Não existe, neste projeto, código que consulte ou emita Autos de Infração.

Só funciona em **macOS** com **Google Chrome** (usa `pbcopy` e `open -a "Google Chrome"`).

---

## 1. Instalação (uma vez por computador)

1. **Node.js 20 ou mais novo** (versão LTS): <https://nodejs.org>.
2. **Copie esta pasta inteira** para o computador (por exemplo, `~/Documents/Retirar_Auto_Infracao`).
3. Se o macOS bloquear os arquivos `.command` (veio de download/ZIP), rode uma vez no Terminal:

   ```bash
   cd ~/Documents/Retirar_Auto_Infracao
   xattr -dr com.apple.quarantine . && chmod +x ABRIR_INTERFACE.command INICIAR.command
   ```

4. As dependências (só o leitor de PDF, `pdfjs-dist`) são instaladas **sozinhas** na primeira vez que você abrir a
   interface (precisa de internet nesse momento). Para instalar à mão: `npm install` dentro da pasta.

## 2. Instalar a extensão do Chrome (uma vez)

1. No Chrome, abra `chrome://extensions` e ative o **Modo do desenvolvedor** (canto superior direito).
2. **Remova versões antigas**: se existir a extensão **"Baixar Certidão Trabalhista"**, remova-a (ou desligue-a). As duas
   juntas disputam o mesmo site e clicam duas vezes.
3. Clique em **Carregar sem compactação** e escolha a pasta **`extensao-chrome`** deste projeto. Deve aparecer
   **Retirar_Auto_Infracao** (versão 1.12), ligada. Deixe a pasta no lugar: se movê-la, remova e carregue de novo.
4. Em `chrome://settings/downloads`, deixe **"Perguntar onde salvar cada arquivo" desligado**.
5. Deixe o Chrome **logado no gov.br**, sem abas antigas do `eprocesso`.
6. Na primeira vez o macOS pode pedir permissão ao Terminal para acessar **Downloads** e **Documentos**: permita.

## 3. Usar a interface

Dê **duplo clique em `ABRIR_INTERFACE.command`** (ou rode `./ABRIR_INTERFACE.command`). Uma janela do Terminal abre e a
interface aparece no navegador em `http://127.0.0.1:47330/`. **Deixe a janela do Terminal aberta** enquanto usa.

| Área | O que faz |
|---|---|
| **1. CPF / CNPJ** | Cole ou digite um por linha. Aceita CNPJ (inclusive alfanumérico) e CPF, com ou sem pontuação. O nome é opcional: `CNPJ;NOME`, `CNPJ - NOME` ou colunas coladas da planilha (CNPJ e Empresa). Linhas com `#` são ignoradas. A lista é salva sozinha em `COLE_OS_CNPJS_AQUI.txt`. |
| **2. Execução** | **Iniciar/Continuar**, **Parar com segurança**, **Copiar de novo** (comando `c`), **Pular empresa** (comando `p`). Em *Opções*: refazer as puladas, pausa entre empresas, organizar Downloads, encerrar lote. |
| **3. Andamento** | Contadores (na lista, PDF salvo, pendentes, puladas, inválidos), barra de progresso, a empresa da vez e a tabela com a situação de cada documento. |
| **Registro** | As mesmas mensagens que antes apareciam só no Terminal, em tempo real. |

**Fluxo de uma empresa:** o assistente copia o documento, abre o site numa aba nova do Chrome e a extensão preenche o campo
(escolhendo "CPF Empregador" ou "CNPJ Empregador") e clica em **Emitir**. **Você faz a verificação "Confirme que é
humano"**. A extensão baixa o PDF e fecha a aba; o assistente confere se o CPF/CNPJ dentro do PDF bate, salva como
`<DOCUMENTO>;<NOME DA EMPRESA>.pdf` na pasta do lote e passa para a próxima.

**Parar com segurança:** o botão interrompe na hora e **o andamento já está gravado** (`dados/Controle.json`). Ao iniciar de
novo, continua do ponto em que parou, na mesma pasta de lote. Fechar a janela do Terminal também é seguro: o PDF que
tiver ficado em Downloads é organizado na próxima execução.

**Quando o lote termina** (todas com PDF), a lista e o controle são esvaziados sozinhos; o relatório fica na pasta do lote
e em `dados/Relatorios/`. Se houver empresas **puladas**, o lote não é apagado: use *Refazer as empresas puladas* ou
*Encerrar lote*.

## 4. Uso só pelo Terminal (sem interface)

Funciona como antes: cole os CNPJs em `COLE_OS_CNPJS_AQUI.txt` e rode `./INICIAR.command`. Opções:

```bash
./INICIAR.command --verificar         # só confere a lista
./INICIAR.command --organizar         # só move certidões já baixadas em Downloads
./INICIAR.command --refazer-puladas   # volta as puladas para pendente e continua
./INICIAR.command --novo-lote         # encerra o lote atual (apaga lista e controle)
PAUSA_MIN=20 PAUSA_MAX=45 ./INICIAR.command   # pausa sorteada entre empresas
```

Na janela: `c` copia o documento de novo, `p` pula a empresa, `s` sai. **Use a interface ou o terminal, não os dois ao
mesmo tempo** (ambos usam a porta 47321 e a mesma lista).

## 5. Pastas e arquivos

```
Retirar_Auto_Infracao/
├── ABRIR_INTERFACE.command     abre a interface gráfica
├── INICIAR.command             uso só pelo Terminal
├── COLE_OS_CNPJS_AQUI.txt      lista do dia (criada sozinha; a interface também a edita)
├── Lote_AAAA-MM-DD_HHhMM/      PDFs de cada lote (criada sozinha)
├── dados/                      Controle.json, Relatorio.csv e Relatorios/ (criada sozinha)
├── extensao-chrome/            extensão "Retirar_Auto_Infracao" (carregar no Chrome)
├── src/
│   ├── assistente.js           núcleo: fluxo, comandos, servidor do CNPJ da vez
│   ├── documentos.js           validação de CPF/CNPJ e leitura da lista
│   ├── pdf.js                  leitura e conferência do PDF
│   ├── persistencia.js         lista, controle, relatório, lote e PDFs
│   ├── resumo.js               contagens e linhas de andamento
│   ├── config.js               caminhos, portas e constantes
│   ├── cli.js                  entrada do Terminal
│   └── interface/              servidor + página (publico/) da interface
├── tests/                      testes automáticos
└── package.json, package-lock.json
```

## 6. Como as partes se comunicam

```
 Navegador (interface)  ──HTTP/SSE──▶  src/interface/servidor.js ──▶  Assistente (src/assistente.js)
   127.0.0.1:47330                      token + Host checados             │  copia o CNPJ (pbcopy)
                                                                          │  abre o site no Chrome
 Chrome: extensão (baixar.js) ◀─mensagens─▶ fundo.js ──GET /cnpj──────────┤  serve o CNPJ da vez
   preenche, clica em Emitir,           127.0.0.1:47321                   │  vigia ~/Downloads, confere o PDF,
   baixa e fecha a aba                                                    ▼  salva no lote, grava controle/relatório
```

- A **interface** e o **terminal** são duas "telas" do mesmo núcleo (`Assistente`): comandos `c/p/s` e mensagens são os
  mesmos que existiam por `stdin`/`stdout`.
- A **extensão** só fala com o assistente pela porta `47321` (`GET /cnpj`). Se essa porta mudar, mude também
  `extensao-chrome/fundo.js` e `manifest.json` (há um teste que confere).
- Tudo escuta **somente em 127.0.0.1**. A interface exige um token da sessão e confere o `Host`, para que outra página
  aberta no navegador não consiga controlar a automação.

## 7. Se algo travar

- **Fica em "Aguardando o PDF em Downloads…"**: olhe a aba do Chrome. Pode ser sessão do gov.br expirada (entre de novo)
  ou o documento que não entrou (clique no campo e aperte `V`, ou use *Copiar de novo* e `Cmd+V`).
- **"Extensão: sem contato"** durante a execução: a extensão não está ligada, ainda está carregada a versão antiga, ou a
  aba do site ainda não abriu. Confira em `chrome://extensions`.
- **Aviso de porta 47321 ocupada**: há outra janela do assistente aberta (ou o Terminal e a interface ao mesmo tempo).
  Feche a outra.
- **"Não consegui ler a pasta de Downloads"**: libere Downloads para o Terminal em *Ajustes do Sistema › Privacidade e
  Segurança › Arquivos e Pastas* (ou *Acesso total ao disco*).
- **Erro de módulo / outro tipo de Mac (Intel ↔ Apple Silicon)**: `rm -rf node_modules && npm install`.
- A interface fica em `http://127.0.0.1:47330/`; se a porta estiver ocupada: `PORTA_INTERFACE=47340 ./ABRIR_INTERFACE.command`.

## 8. Testes

```bash
npm test
```

Rodam sem Chrome e sem acessar o site: usam uma pasta "Downloads" falsa, PDFs de certidão fictícios e simulam a extensão
consultando `GET /cnpj`. **Não cobrem** o site real do MTE nem a extensão dentro do Chrome (precisam de um teste manual
com um CNPJ, como descrito na seção 3).
