#!/bin/bash
# Uso pelo terminal, sem interface gráfica. Opções: --verificar --organizar --refazer-puladas --novo-lote
cd "$(dirname "$0")" || exit 1
echo "Certidao de Debitos Trabalhistas (MTE) - Retirar_Auto_Infracao"
if ! command -v node >/dev/null 2>&1; then
  echo
  echo "O Node.js nao esta instalado. Instale a versao LTS em https://nodejs.org e rode de novo."
  read -r -p "Enter para fechar..."
  exit 1
fi
if ! node --input-type=module -e "await import('pdfjs-dist/legacy/build/pdf.mjs'); await import('@napi-rs/canvas')" >/dev/null 2>&1; then
  echo "Instalando dependencias (so na primeira vez)..."
  npm install --no-audit --no-fund || { read -r -p "Falhou. Enter para fechar..."; exit 1; }
fi
echo "Use o seu Chrome ja logado no gov.br. Para parar, digite s e Enter."
node src/cli.js "$@"
echo
echo "Execucao encerrada. Confira a pasta do projeto e o relatorio em dados/."
read -r -p "Enter para fechar..."
