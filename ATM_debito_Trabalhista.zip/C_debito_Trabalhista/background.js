// Parte de fundo da extensão (service worker). Responsabilidades:
//  1) abrir a JANELA da automação (interface.html): pelo ícone da extensão ou quando a Central
//     de Automações abre a página do TST com "#cndt_abrir_interface";
//  2) guardar a FILA e o andamento (chrome.storage) e responder ao content.js qual é a empresa
//     da vez; iniciar, pausar, continuar e parar a pedido da janela;
//  3) receber o PDF que a PÁGINA DO TST baixa depois de "Emitir Certidão", renomeá-lo para
//     CNDT_<NOME DA EMPRESA>.pdf e salvá-lo em Downloads/<pasta principal>/<pasta da empresa>/,
//     e só dar a empresa por concluída depois que o Chrome confirma o arquivo salvo por inteiro;
//  4) salvar o relatório (.txt) na pasta principal.
//
// O service worker pode ser desligado pelo Chrome entre um evento e outro: tudo o que precisa
// sobreviver fica em chrome.storage (local = fila e andamento; session = download em espera).

importScripts('config.js', 'cnpj.js', 'lista.js');
const { CONFIG, LISTA } = self.CNDT;
const PREFIXO = CONFIG.PREFIXO_LOG;
const HOST_TST = 'cndt-certidao.tst.jus.br';
const URL_AUTOMACAO = `${CONFIG.URL_EMISSAO}#${CONFIG.MARCADOR}`;
const URL_INTERFACE = chrome.runtime.getURL('interface.html');

// Chaves do chrome.storage.local
const K = {
  config: 'cndt_config', // { pasta, itens, rejeitadas }
  controle: 'cndt_controle', // { estado, atual, tabId, falhasSeguidas, refeitas, refazerErros, ultimoDownloadId, caminhoBase }
  log: 'cndt_log', // [{ t, tipo, texto }]
};
// Andamento por pasta principal: pastas diferentes = andamentos separados (repetir a mesma pasta continua de onde parou).
const chaveAndamento = (pasta) => `cndt_andamento:${pasta}`;

const ler = async (chave, padrao) => (await chrome.storage.local.get(chave))[chave] ?? padrao;
const gravar = (chave, valor) => chrome.storage.local.set({ [chave]: valor });
const agora = () => new Date().toLocaleString('pt-BR');

// Leitura-e-gravação em sequência (dois eventos ao mesmo tempo não apagam a mudança um do outro).
let cadeia = Promise.resolve();
function emSequencia(fn) {
  const p = cadeia.then(fn);
  cadeia = p.catch(() => {});
  return p;
}

function log(texto, tipo = 'info') {
  console.log(PREFIXO, texto);
  return emSequencia(async () => {
    const lista = await ler(K.log, []);
    lista.push({ t: Date.now(), tipo, texto: String(texto).slice(0, 500) });
    await gravar(K.log, lista.slice(-300));
  });
}

async function controle() {
  return ler(K.controle, { estado: 'parada', atual: null, tabId: null, falhasSeguidas: 0, refeitas: [], refazerErros: false });
}
function mudarControle(mudancas) {
  return emSequencia(async () => {
    const c = { ...(await controle()), ...mudancas };
    await gravar(K.controle, c);
    return c;
  });
}

// ------------------------------- janela da automação -------------------------------
async function abrirInterface() {
  const { cndt_janela: id } = await chrome.storage.session.get('cndt_janela');
  if (id) {
    try { await chrome.windows.update(id, { focused: true }); return; } catch (_) { /* foi fechada */ }
  }
  const w = await chrome.windows.create({ url: URL_INTERFACE, type: 'popup', width: 720, height: 920 });
  await chrome.storage.session.set({ cndt_janela: w.id });
}

chrome.action.onClicked.addListener(() => {
  abrirInterface().catch((e) => console.warn(PREFIXO, 'não consegui abrir a janela:', e.message));
});

// Central de Automações: abre a página do TST com "#cndt_abrir_interface" (o que vem depois do "#"
// não é enviado ao TST) = sinal para abrir a janela.
chrome.webNavigation.onBeforeNavigate.addListener((d) => {
  if (d.frameId !== 0 || !String(d.url).includes('cndt_abrir_interface')) return;
  abrirInterface().catch((e) => console.warn(PREFIXO, 'não consegui abrir a janela:', e.message));
}, { url: [{ hostEquals: HOST_TST }] });

// ------------------------------- aba do TST -------------------------------
// Abre (ou reaproveita) a aba da automação na página de emissão, já com o marcador, e a recarrega
// para o content.js começar a próxima empresa.
async function carregarAbaDaAutomacao() {
  const c = await controle();
  let aba = null;
  if (c.tabId) { try { aba = await chrome.tabs.get(c.tabId); } catch (_) { aba = null; } }
  if (aba && String(aba.url || aba.pendingUrl || '').includes(HOST_TST)) {
    if (aba.url === URL_AUTOMACAO) await chrome.tabs.reload(aba.id);
    else await chrome.tabs.update(aba.id, { url: URL_AUTOMACAO });
    await chrome.tabs.update(aba.id, { active: true });
    try { await chrome.windows.update(aba.windowId, { focused: true }); } catch (_) { /* ok */ }
    return aba.id;
  }
  const nova = await chrome.tabs.create({ url: URL_AUTOMACAO, active: true });
  await mudarControle({ tabId: nova.id });
  return nova.id;
}

// ------------------------------- fila -------------------------------
async function estadoDaFila() {
  const cfg = await ler(K.config, null);
  if (!cfg) return { cfg: null, andamento: {} };
  return { cfg, andamento: await ler(chaveAndamento(cfg.pasta), {}) };
}

function publico(item) {
  return { cnpj: item.cnpj, formatado: item.formatado, tipo: item.tipo, nome: item.nome, pasta: item.pasta, arquivo: item.arquivo };
}

// O content.js pergunta qual empresa fazer. A empresa "atual" só sai da fila quando o resultado
// chega: se a página recarregar no meio (recuperação), a mesma empresa é devolvida.
async function proximo(tabId) {
  const c = await controle();
  if (tabId !== c.tabId) return { nada: 'Esta aba não é a da automação. Use a janela da extensão para iniciar.' };
  if (c.estado === 'pausando') { await mudarControle({ estado: 'pausada', atual: null }); await log('Automação pausada.'); return { pausada: true }; }
  if (c.estado === 'pausada') return { pausada: true };
  if (c.estado !== 'processando') return { nada: 'A automação está parada. Use a janela da extensão para iniciar.' };

  const { cfg, andamento } = await estadoDaFila();
  if (!cfg) return { nada: 'Nenhuma lista informada.' };
  const posicao = (it) => cfg.itens.findIndex((x) => x.cnpj === it.cnpj) + 1;

  if (c.atual) {
    const it = cfg.itens.find((x) => x.cnpj === c.atual);
    if (it) return { empresa: publico(it), pastaPrincipal: cfg.pasta, posicao: posicao(it), total: cfg.itens.length };
  }
  const it = LISTA.proximaEmpresa(cfg.itens, andamento, { refazerErros: c.refazerErros, jaRefeitas: c.refeitas || [] });
  if (!it) {
    await mudarControle({ estado: 'concluida', atual: null });
    const r = LISTA.resumo(cfg.itens, andamento);
    await log(`Fim da lista: ${r.concluidas} concluída(s), ${r.erros} com erro, ${r.pendentes} pendente(s).`, r.erros ? 'erro' : 'ok');
    await salvarRelatorio().catch((e) => log(`Não consegui salvar o relatório: ${e.message}`, 'erro'));
    return { fim: true, resumo: r };
  }
  const refazendo = !!(andamento[it.cnpj] && andamento[it.cnpj].estado === 'erro');
  await mudarControle({ atual: it.cnpj, refeitas: refazendo ? [...(c.refeitas || []), it.cnpj] : (c.refeitas || []) });
  await log(`${refazendo ? 'Refazendo' : 'Iniciando'} ${posicao(it)}/${cfg.itens.length}: ${it.formatado} - ${it.nome}`);
  return { empresa: publico(it), pastaPrincipal: cfg.pasta, posicao: posicao(it), total: cfg.itens.length };
}

// Resultado de uma empresa vindo do content.js.
//  estado 'concluida' | 'erro': grava no andamento e segue (ou pausa, se pedido).
//  estado 'pendente': a empresa volta para a fila e a automação pausa (ninguém digitou a
//  verificação a tempo, ou a pessoa apertou Esc).
async function registrarResultado(tabId, { cnpj, estado, detalhe, arquivo }) {
  const c = await controle();
  if (tabId !== c.tabId || cnpj !== c.atual) return { continuar: false };
  const { cfg, andamento } = await estadoDaFila();
  const it = cfg && cfg.itens.find((x) => x.cnpj === cnpj);
  if (!it) return { continuar: false };

  if (estado === 'pendente') {
    await mudarControle({ atual: null, estado: c.estado === 'parada' ? 'parada' : 'pausada' });
    await log(`Pausada em ${it.formatado} - ${it.nome}: ${detalhe}`, 'erro');
    return { continuar: false };
  }
  andamento[cnpj] = { estado, detalhe: detalhe || '', arquivo: arquivo || '', quando: agora() };
  await gravar(chaveAndamento(cfg.pasta), andamento);

  let falhas = estado === 'erro' ? (c.falhasSeguidas || 0) + 1 : 0;
  let novoEstado = c.estado;
  if (estado === 'concluida') await log(`Concluída: ${it.nome} -> ${arquivo}`, 'ok');
  else await log(`Erro em ${it.formatado} - ${it.nome}: ${detalhe}`, 'erro');

  if (falhas >= CONFIG.FILA.maxFalhasSeguidas) {
    novoEstado = 'pausada';
    await log(`${falhas} empresas seguidas com erro: pausei para você conferir a página. Clique em Continuar.`, 'erro');
    falhas = 0;
  } else if (c.estado === 'pausando') {
    novoEstado = 'pausada';
    await log('Automação pausada.');
  }
  await mudarControle({ atual: null, falhasSeguidas: falhas, estado: novoEstado });
  await descartarPendente();
  const continuar = novoEstado === 'processando';
  // A próxima empresa é carregada PELO NAVEGADOR (não pela própria página): depois de um
  // download, o Chrome bloqueia "vários downloads automáticos" da mesma página até uma
  // navegação feita pelo navegador. Recarregar pela página (location.reload) não libera.
  if (continuar) {
    setTimeout(() => {
      controle().then((c2) => {
        if (c2.estado === 'processando' && !c2.atual) return carregarAbaDaAutomacao();
        return null;
      }).catch((e) => log(`Não consegui abrir a próxima empresa: ${e.message}`, 'erro'));
    }, CONFIG.FILA.pausaEntreEmpresas);
  }
  return { continuar };
}

// ------------------------------- comandos da janela -------------------------------
async function iniciar({ pasta, texto }) {
  const pastaLimpa = LISTA.limparPastaPrincipal(pasta);
  if (!pastaLimpa || !LISTA.caminhoValido(pastaLimpa)) throw new Error('informe um nome válido para a pasta principal');
  const lida = LISTA.lerLista(texto);
  if (!lida.itens.length) throw new Error('a lista não tem nenhuma empresa válida');
  for (const it of lida.itens) {
    if (!LISTA.caminhoValido(LISTA.caminhoDoArquivo(pastaLimpa, it))) throw new Error(`nome inválido para a empresa ${it.formatado}`);
  }
  const c = await controle();
  if (c.estado === 'processando' || c.estado === 'pausando') throw new Error('a automação já está em andamento');

  await gravar(K.config, { pasta: pastaLimpa, itens: lida.itens, rejeitadas: lida.rejeitadas });
  const andamento = await ler(chaveAndamento(pastaLimpa), {});
  const r = LISTA.resumo(lida.itens, andamento);
  // Só restam empresas com erro: refaz cada uma uma vez.
  const refazerErros = r.pendentes === 0 && r.erros > 0;
  await mudarControle({ estado: 'processando', atual: null, falhasSeguidas: 0, refeitas: [], refazerErros });
  await log(`Iniciada: ${lida.itens.length} empresa(s), pasta Downloads/${pastaLimpa}` +
    (r.concluidas ? ` (${r.concluidas} já concluída(s) nesta pasta ficam como estão)` : '') +
    (refazerErros ? ' - refazendo as empresas com erro' : '') +
    (lida.rejeitadas.length ? ` - ${lida.rejeitadas.length} linha(s) ignorada(s)` : ''));
  await carregarAbaDaAutomacao();
}

async function pausar() {
  const c = await controle();
  if (c.estado !== 'processando') return;
  await mudarControle({ estado: c.atual ? 'pausando' : 'pausada' });
  await log(c.atual ? 'Pausa pedida: a empresa atual termina e a automação pausa.' : 'Automação pausada.');
}

async function continuar() {
  const c = await controle();
  if (c.estado === 'pausando') { await mudarControle({ estado: 'processando' }); await log('Pausa cancelada.'); return; }
  if (c.estado !== 'pausada' && c.estado !== 'parada') return;
  await mudarControle({ estado: 'processando', falhasSeguidas: 0 });
  await log('Continuando.');
  await carregarAbaDaAutomacao();
}

async function parar() {
  const c = await controle();
  if (c.estado === 'parada' || c.estado === 'concluida') return;
  // A empresa atual volta para a fila (não é marcada como erro).
  await mudarControle({ estado: 'parada', atual: null });
  await descartarPendente();
  await log('Automação parada. A empresa em andamento continua pendente.');
}

async function zerar() {
  const c = await controle();
  if (c.estado === 'processando' || c.estado === 'pausando') throw new Error('pare a automação antes de zerar');
  const cfg = await ler(K.config, null);
  if (cfg) await chrome.storage.local.remove(chaveAndamento(cfg.pasta));
  await mudarControle({ estado: 'parada', atual: null, refeitas: [], falhasSeguidas: 0 });
  await log('Andamento zerado (os arquivos já salvos continuam na pasta).');
}

async function abrirPasta() {
  const c = await controle();
  if (c.ultimoDownloadId) {
    try { chrome.downloads.show(c.ultimoDownloadId); return { ok: true, caminho: c.caminhoBase || '' }; } catch (_) { /* arquivo removido */ }
  }
  chrome.downloads.showDefaultFolder();
  return { ok: true, caminho: '', semArquivos: true };
}

// ------------------------------- download do PDF da certidão -------------------------------
// O content.js "arma" a espera antes de a certidão ser pedida (antes do clique em Emitir). O
// primeiro download que a página do TST iniciar depois disso é renomeado para o caminho da
// empresa. Fica guardado em storage.session para sobreviver ao desligamento do service worker.
let pendente = null; // { cnpj, tabId, caminho, pastaEsperada, expira, estado, downloadId, final, tamanho, detalhe }
const pendenteCarregado = chrome.storage.session.get('cndt_pendente').then((r) => { pendente = r.cndt_pendente || null; });
const salvarPendente = () => chrome.storage.session.set({ cndt_pendente: pendente });
async function descartarPendente() { pendente = null; await chrome.storage.session.remove('cndt_pendente'); }
const pendenteAtivo = () => !!pendente && Date.now() < pendente.expira;

async function armarDownload(tabId, cnpj) {
  const c = await controle();
  const { cfg } = await estadoDaFila();
  if (tabId !== c.tabId || cnpj !== c.atual || !cfg) throw new Error('empresa fora da fila');
  const it = cfg.itens.find((x) => x.cnpj === cnpj);
  const caminho = LISTA.caminhoDoArquivo(cfg.pasta, it);
  if (!LISTA.caminhoValido(caminho)) throw new Error('caminho inválido');
  await pendenteCarregado;
  pendente = {
    cnpj, tabId, caminho, pastaEsperada: `/${cfg.pasta}/${it.pasta}/`.toLowerCase(),
    expira: Date.now() + CONFIG.FILA.validadeEsperaDownload, estado: 'aguardando',
  };
  await salvarPendente();
  return { ok: true, caminho };
}

// Downloads feitos pela própria extensão (relatório): endereço -> caminho. Com um ouvinte de
// onDeterminingFilename registrado, o Chrome ignora o "filename" do download() se o ouvinte não
// o confirmar; por isso o ouvinte confirma o nome deste mapa.
const nomesProprios = new Map();

chrome.downloads.onDeterminingFilename.addListener((item, sugerir) => {
  if (item.byExtensionId === chrome.runtime.id) {
    const nome = nomesProprios.get(item.url) || nomesProprios.get(item.finalUrl);
    if (nome) sugerir({ filename: nome, conflictAction: 'uniquify' }); else sugerir();
    return false;
  }
  const origem = `${item.url} ${item.finalUrl || ''} ${item.referrer || ''}`;
  if (!origem.includes(HOST_TST)) return false; // outros downloads: o Chrome decide como sempre
  pendenteCarregado.then(async () => {
    if (!pendenteAtivo() || pendente.downloadId) { sugerir(); return; } // só o 1º download depois de armar
    pendente.downloadId = item.id;
    pendente.estado = 'baixando';
    pendente.detalhe = `download da página (${item.mime || 'tipo desconhecido'}; nome original: ${item.filename})`;
    await salvarPendente();
    // "uniquify": se já existir um arquivo com esse nome, o Chrome cria "CNDT_X (1).pdf" (nunca sobrescreve).
    sugerir({ filename: pendente.caminho, conflictAction: 'uniquify' });
  });
  return true; // resposta assíncrona
});

chrome.downloads.onChanged.addListener(async (d) => {
  await pendenteCarregado;
  if (!pendente || d.id !== pendente.downloadId || !d.state) return;
  if (d.state.current === 'complete') {
    const [it] = await chrome.downloads.search({ id: d.id });
    const final = String((it && it.filename) || '');
    const tamanho = (it && (it.fileSize || it.totalBytes || it.bytesReceived)) || 0;
    const problemas = [];
    if (!it || it.state !== 'complete') problemas.push('o download não terminou');
    if (it && it.exists === false) problemas.push('o arquivo não existe no disco');
    if (!(tamanho > 0)) problemas.push('o arquivo está vazio');
    if (!/\.pdf$/i.test(final) && !(it && /pdf/i.test(it.mime || ''))) problemas.push(`o arquivo não é PDF (${(it && it.mime) || final})`);
    if (!final.replace(/\\/g, '/').toLowerCase().includes(pendente.pastaEsperada)) problemas.push(`foi salvo em "${final}", fora da pasta da empresa`);
    pendente.final = final;
    pendente.tamanho = tamanho;
    pendente.estado = problemas.length ? 'erro' : 'ok';
    pendente.detalhe = problemas.join('; ');
    await salvarPendente();
    if (!problemas.length) {
      await mudarControle({ ultimoDownloadId: d.id, caminhoBase: final.replace(/[\\/][^\\/]+[\\/][^\\/]+$/, '') });
    }
  } else if (d.state.current === 'interrupted') {
    pendente.estado = 'erro';
    pendente.detalhe = `o download foi interrompido (${(d.error && d.error.current) || 'motivo desconhecido'})`;
    await salvarPendente();
  }
});

async function statusDownload(tabId, cnpj) {
  await pendenteCarregado;
  if (!pendente || pendente.tabId !== tabId || pendente.cnpj !== cnpj) return { estado: 'nenhum' };
  return { estado: pendente.estado, final: pendente.final || '', tamanho: pendente.tamanho || 0, detalhe: pendente.detalhe || '' };
}

// ------------------------------- relatório (.txt) -------------------------------
async function baixarComNome(url, filename) {
  nomesProprios.set(url, filename);
  try {
    const id = await chrome.downloads.download({ url, filename, conflictAction: 'uniquify', saveAs: false });
    return id;
  } finally {
    setTimeout(() => nomesProprios.delete(url), 30000);
  }
}

async function salvarRelatorio() {
  const { cfg, andamento } = await estadoDaFila();
  if (!cfg) throw new Error('nenhuma lista');
  const d = new Date(), p2 = (n) => String(n).padStart(2, '0');
  const nome = `RELATORIO_CNDT_${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())}_${p2(d.getHours())}-${p2(d.getMinutes())}-${p2(d.getSeconds())}.txt`;
  const texto = LISTA.textoRelatorio({ pasta: cfg.pasta, itens: cfg.itens, andamento, rejeitadas: cfg.rejeitadas });
  await baixarComNome('data:text/plain;charset=utf-8,' + encodeURIComponent('﻿' + texto), `${cfg.pasta}/${nome}`);
  await log(`Relatório salvo: Downloads/${cfg.pasta}/${nome}`);
  return nome;
}

// ------------------------------- mensagens -------------------------------
const daExtensao = (remetente) => remetente.id === chrome.runtime.id && String(remetente.url || '').startsWith(chrome.runtime.getURL(''));
const doTst = (remetente) => { try { return remetente.id === chrome.runtime.id && !!remetente.tab && new URL(remetente.url).hostname === HOST_TST; } catch (_) { return false; } };

const COMANDOS_JANELA = {
  'cndt:iniciar': (dados) => iniciar(dados || {}),
  'cndt:pausar': pausar,
  'cndt:continuar': continuar,
  'cndt:parar': parar,
  'cndt:zerar': zerar,
  'cndt:abrir-pasta': abrirPasta,
  'cndt:alterar-local': () => chrome.tabs.create({ url: 'chrome://settings/downloads' }),
  'cndt:salvar-relatorio': salvarRelatorio,
  'cndt:limpar-log': () => gravar(K.log, []),
};

const COMANDOS_PAGINA = {
  'cndt:proximo': (tabId) => proximo(tabId),
  'cndt:armar-download': (tabId, d) => armarDownload(tabId, d.cnpj),
  'cndt:status-download': (tabId, d) => statusDownload(tabId, d.cnpj),
  'cndt:resultado': (tabId, d) => registrarResultado(tabId, d),
  'cndt:log': (tabId, d) => log(d.texto, d.tipo),
};

chrome.runtime.onMessage.addListener((msg, remetente, responder) => {
  const tipo = msg && msg.tipo;
  let execucao = null;
  if (COMANDOS_JANELA[tipo] && daExtensao(remetente)) execucao = COMANDOS_JANELA[tipo](msg.dados);
  else if (COMANDOS_PAGINA[tipo] && doTst(remetente)) execucao = COMANDOS_PAGINA[tipo](remetente.tab.id, msg.dados || {});
  else return false;
  Promise.resolve(execucao)
    .then((r) => responder({ ok: true, ...(r && typeof r === 'object' ? r : {}) }))
    .catch((e) => { console.error(PREFIXO, tipo, e); responder({ ok: false, erro: e.message }); });
  return true;
});

// A aba da automação foi fechada no meio: pausa (a empresa atual volta para a fila).
chrome.tabs.onRemoved.addListener(async (tabId) => {
  const c = await controle();
  if (tabId !== c.tabId || !['processando', 'pausando'].includes(c.estado)) return;
  await mudarControle({ estado: 'pausada', atual: null, tabId: null });
  await log('A aba do TST foi fechada: pausei. Clique em Continuar para abrir de novo.', 'erro');
});
