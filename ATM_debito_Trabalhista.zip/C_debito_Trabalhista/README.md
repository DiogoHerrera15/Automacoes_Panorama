# C_debito_Trabalhista: emissão da CNDT (TST), extensão do Chrome

Versão **0.5.0** (17/11/2026). Você informa **a pasta principal** e **a lista de empresas** (`CNPJ;NOME_EMPRESA`). Para
cada empresa, a automação abre a página do TST, digita o CNPJ, espera **você digitar a verificação (captcha)**, clica em
**Emitir Certidão**, salva o PDF como `CNDT_<NOME DA EMPRESA>.pdf` na **pasta da empresa** e passa para a próxima.

Página: https://cndt-certidao.tst.jus.br/gerarCertidao

## 1. Como usar

1. Clique no ícone da extensão: abre a **janela da automação** (a Central pode abri-la com `#cndt_abrir_interface` no endereço do TST).
2. **Bloco 1 – Pasta de destino:** o nome da pasta principal (ex.: `CERTIDOES_CNDT NOVEMBRO 2026`; pode ter subpastas com `\`).
   A janela mostra o caminho completo do primeiro arquivo.
3. **Bloco 2 – Lista de empresas:** cole as empresas, uma por linha:
   ```
   11.222.333/0001-81;EMPRESA EXEMPLO UM LTDA
   11.444.777/0001-61;EMPRESA EXEMPLO DOIS LTDA
   ```
   A janela conta as empresas válidas e aponta as linhas com problema (elas são ignoradas, não impedem o início).
4. **Bloco 3 – Iniciar automação.** A página do TST abre; quando o CNPJ estiver digitado, **digite a verificação** e pare:
   a automação clica em Emitir, salva o PDF e segue para a próxima empresa.

| Botão | O que faz |
|---|---|
| **Iniciar automação** | Salva pasta e lista e começa. Se a mesma pasta já tem empresas concluídas, continua das pendentes. Quando só restam empresas com erro, refaz cada uma uma vez. |
| **Pausar** | A empresa em andamento termina (você pode digitar a verificação dela) e a automação pausa. |
| **Continuar** | Sai da pausa (ou cancela a pausa pedida) e abre a próxima empresa. |
| **Parar** (2 cliques) | Para na hora. A empresa em andamento continua **pendente** (não vira erro). |
| **Abrir pasta de destino** | Abre no Explorador a pasta da última certidão salva (sem nenhuma ainda: a pasta de downloads). |
| **Alterar local…** | Abre a configuração de downloads do Chrome (ver "Onde os arquivos ficam"). |
| **Salvar relatório (.txt)** | Salva o relatório na pasta principal (também é salvo sozinho no fim da lista). |
| **Zerar andamento** (2 cliques) | Esquece o andamento desta pasta para refazer tudo. Os arquivos salvos ficam. |

A janela mostra: empresas, concluídas, pendentes e com erro; barra de progresso; status (Parada, Processando, Pausando,
Pausada, Concluída); empresa atual, CNPJ e o arquivo que será gravado; mensagens da automação; e a lista das empresas
com erro e o motivo. Tema claro/escuro conforme o Windows.

## 2. Lista `CNPJ;NOME_EMPRESA`

- Uma empresa por linha; o `;` separa (o TAB do Excel também vale). Linhas vazias são ignoradas.
- CNPJ com ou sem pontuação; **CNPJ alfanumérico** (2026) e **CPF** também são aceitos (o site aceita).
- Dígitos verificadores são conferidos: CNPJ inválido, linha sem `;`, sem CNPJ ou sem nome são **apontados com o número
  da linha e o motivo** e ignorados. CNPJ repetido: vale a primeira linha. Excel que tirou zeros à esquerda (12 ou 13
  dígitos): completa, se os dígitos verificadores baterem.
- **Só o CNPJ vai para o site.** O nome dá nome à pasta e ao arquivo. Caracteres que o Windows não aceita
  (`< > : " / \ | ? *`) são trocados (`S/A` vira `S-A`).

## 3. Onde os arquivos ficam

```
<pasta de downloads do Chrome>\
└── CERTIDOES_CNDT\                                   <- pasta principal (o nome que você deu)
    ├── EMPRESA EXEMPLO UM LTDA\
    │   └── CNDT_EMPRESA EXEMPLO UM LTDA.pdf
    ├── MESMO NOME S-A - 11444777000161\               <- nomes iguais: o CNPJ entra na pasta e no arquivo
    │   └── CNDT_MESMO NOME S-A - 11444777000161.pdf
    ├── MESMO NOME S-A - 12345678909\
    │   └── CNDT_MESMO NOME S-A - 12345678909.pdf
    └── RELATORIO_CNDT_2026-11-17_10-42-03.txt
```

- **Cada PDF vai só para a pasta da empresa do CNPJ consultado.** A extensão guarda qual empresa está em andamento e só
  aceita o download que a página do TST faz depois que ela preparou o salvamento daquela empresa.
- **Nunca sobrescreve:** se o arquivo já existe (ex.: emitiu de novo), o Chrome grava `CNDT_<NOME> (1).pdf`.
- A empresa só conta como **concluída** depois que o Chrome confirma o arquivo salvo por inteiro, existente, não vazio,
  PDF e dentro da pasta da empresa. Download iniciado não basta.
- **Local:** o Chrome só deixa extensões gravarem **dentro da pasta de downloads dele**. Para criar a pasta principal em
  outro lugar (ex.: `D:\Clientes`), clique em **Alterar local…** e mude a pasta de downloads do Chrome. Deixe
  **"Perguntar onde salvar cada arquivo"** desligado.
- As pastas são criadas pelo Chrome ao salvar o primeiro arquivo nelas (não dá para criar uma pasta vazia antes).
  Se a pasta já existe, é reaproveitada, sem apagar nada.
- Se o Chrome perguntar se a página do TST pode **"baixar vários arquivos"**, clique em **Permitir**.

## 4. Instalar no Chrome

1. `chrome://extensions` > **Modo do desenvolvedor** > **Carregar sem compactação** > pasta `C_debito_Trabalhista`.
2. Confira no cartão: `C_debito_Trabalhista`, versão **0.5.0**. Ao atualizar os arquivos, use a **setinha de recarregar**
   (não remova: o andamento fica guardado no Chrome, por pasta principal).
3. Fixe o ícone (quebra-cabeça do Chrome > fixar) para abrir a janela com um clique.

## 5. O que acontece em cada empresa

1. A página abre com `#cndt_preencher` (abrir a página à mão não dispara nada) e pergunta ao background qual é a empresa.
2. Espera o campo e o site carregarem; o **cursor visual** vai até o campo e clica; limpa e **digita o CNPJ tecla a tecla**.
3. A seta vai ao campo da verificação. A extensão **só observa** sua digitação (eventos marcados pelo navegador como
   vindos do usuário); não lê a imagem, não escreve no campo e não envia o captcha a lugar nenhum.
4. Quando você fica **1,5 s sem digitar** (pelo menos 4 caracteres), confere o CNPJ e o botão, leva a seta até
   **Emitir Certidão** e espera 1,5 s: **digitar** nesse tempo adia o clique; **Esc** cancela (a automação pausa e a empresa
   continua pendente). Então clica (clique real no ponto da seta). Só nesse botão; nunca em "Emitir e Enviar", "Ouvir"
   ou "Emitir Nova". Se você mesmo clicar em Emitir, a automação acompanha do mesmo jeito.
5. Resposta do site (até 60 s): **sucesso** = espera o PDF ser salvo e confirmado (até 45 s) e marca a empresa como
   concluída; **erro** (ex.: verificação incorreta) = a imagem é trocada pelo site e você digita de novo (até **3 envios**);
   uma mensagem de erro antiga na tela não é confundida com a nova.
6. Registra o resultado e o **navegador** recarrega a página para a próxima empresa (recarregar pela própria página faria
   o Chrome bloquear o 2º download automático).

## 6. Erros e recuperação: um problema numa empresa não para a lista

| Situação | O que faz |
|---|---|
| Campo não aparece ou site não carrega em 20 s; campo desabilitado/sem foco | Recarrega a página (até 2 vezes por empresa); depois, empresa **com erro** e segue |
| Valor do CNPJ diferente do esperado; outro elemento cobre o campo | Empresa com erro e segue |
| Verificação incorreta 3 vezes; site sem resposta em 60 s | Empresa com erro e segue |
| Certidão emitida mas PDF não salvo/incompleto/fora da pasta em 45 s | Empresa com erro (motivo no relatório) e segue |
| Ninguém digitou a verificação em 5 min; Esc | **Pausa**: a empresa continua pendente. Clique em Continuar |
| reCAPTCHA, hCaptcha, Cloudflare (verificação extra) | Pausa e deixa com você. Nunca contorna |
| 5 empresas seguidas com erro | Pausa (é quase sempre um problema geral: confira a página) |
| Aba do TST fechada no meio | Pausa; Continuar abre de novo |
| Extensão sem resposta | Aviso na página; nada é marcado |

Todas as esperas têm limite. Para refazer as empresas com erro: quando só restarem elas, clique em **Iniciar automação**.

## 7. Cursor visual e digitação humanizada (0.2.x, mantidos)

- Seta azul por cima da página (`pointer-events: none`: nunca recebe cliques). Movimento suave pela Lei de Fitts
  (0,7 a 2 s), rola a página antes se o alvo estiver fora da tela, para 250-500 ms sobre o alvo e o **clique real sai no
  ponto da seta** (confere com `elementFromPoint` que é o alvo; senão, não clica). Animação de clique; acompanha a rolagem.
- Digitação: um caractere por vez (`keydown`, `keypress`, `beforeinput`, `input`, `keyup`), 220-420 ms entre teclas,
  70-130 ms com a tecla apertada, pausas entre os blocos do número. A máscara do próprio site formata.
- Tempos em `config.js` (`DIGITACAO`, `CURSOR`). Servem para o movimento ser natural e acompanhável; **não tornam a
  automação invisível** (eventos de extensão são marcados pelo navegador como não vindos do usuário). O captcha é da pessoa.

## 8. Arquivos

```
C_debito_Trabalhista/
├── manifest.json     MV3; permissões: downloads, storage, webNavigation; acesso só a cndt-certidao.tst.jus.br
├── config.js         URL, marcador, seletores, tempos, limites (tudo que depende do site)
├── cnpj.js           Funções puras: normalizar, formatar (igual ao site), validar DV (CPF, CNPJ e CNPJ alfanumérico)
├── lista.js          Funções puras: lista CNPJ;NOME, nomes de pasta/arquivo, fila, resumo, relatório
├── interface.html/.css/.js   A janela da automação (blocos 1, 2 e 3, andamento, mensagens)
├── background.js     Fila e andamento, comandos da janela, download do PDF (renomear, salvar, confirmar), relatório
├── cursor.js         Cursor visual
├── pagina.js         Esperas, localizar elementos, clique real, digitação, espera da verificação, resposta do site
├── content.js        O fluxo de uma empresa na página do TST
└── tests/            cnpj.test.js (página, cursor, regras) e lista.test.js (lista, pastas, nomes, fila, relatório)
```

Guardado no Chrome (`chrome.storage.local`): `cndt_config` (pasta e lista), `cndt_controle` (estado, empresa atual),
`cndt_andamento:<pasta>` (resultado por empresa: pastas diferentes têm andamentos separados), `cndt_log`, `cndt_rascunho`.

## 9. Testes

- `node --test tests/` (na pasta da extensão): **15 testes** (formatação e DV; lista: separação, linhas vazias/sem `;`/
  sem nome/CNPJ inválido/repetido, TAB do Excel, zeros perdidos, CPF e CNPJ alfanumérico, nomes iguais, caracteres
  proibidos no Windows, caminhos seguros; fila; relatório; regras de clique e do captcha).
- **0.5.0, ponta a ponta no Microsoft Edge 157** (Chromium) com a **extensão instalada de verdade**, na página real do TST,
  com o envio do formulário **bloqueado na aba de teste** (nada foi enviado ao TST) e a resposta do site simulada
  ("Certidão EMITIDA" + um PDF de exemplo baixado pela própria página, como o site faz); a verificação recebeu um texto
  qualquer digitado pelo teclado do navegador. 22 verificações, todas certas:
  janela abre; contagem (3 válidas, 2 linhas com problema apontadas pelo número); caminho previsto; botões em cada
  estado; 3 empresas processadas em sequência; **Pausar** durante a 2ª (ela terminou e a 3ª ficou pendente) e
  **Continuar**; cada PDF na pasta da sua empresa, com o nome `CNDT_<NOME>.pdf` e o **conteúdo da empresa certa**; nomes
  iguais separados pelo CNPJ; nenhum arquivo com o nome original do site; relatório salvo; **mesma empresa de novo =
  `CNDT_<NOME> (1).pdf`, o primeiro intacto**; **Parar** no meio (empresa pendente, página respeitou).
  Esse teste achou um defeito, corrigido: depois do 1º PDF, o navegador bloqueava o download automático da 2ª empresa
  (a página se recarregava sozinha); agora quem recarrega é o navegador.
- Antes (0.1 a 0.4): CNPJ, cursor, digitação, espera da verificação e clique testados na página real; **emissão real
  pelo usuário com a 0.4.0 no Chrome: funcionou**.
- **Ainda não testado:** a 0.5.0 com uma emissão real (download do PDF verdadeiro do TST) no seu Chrome.
