// Tudo o que muda entre macOS e Windows fica aqui, para o resto do código ser um só nos dois sistemas:
// copiar para a área de transferência, abrir o site no Chrome, abrir pasta/navegador e achar a pasta de
// Downloads. Nada depende de nome de usuário, letra de unidade ou caminho fixo.

import { execFileSync, spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

export const WINDOWS = process.platform === 'win32';
export const MAC = process.platform === 'darwin';

// Atalho de colar/copiar para mostrar nas mensagens.
export const TECLA_CTRL = MAC ? 'Cmd' : 'Ctrl';

function semJanela(cmd, args) {
  const filho = spawn(cmd, args, { detached: true, stdio: 'ignore', windowsHide: true });
  filho.on('error', () => {});
  filho.unref();
  return filho;
}

// Copia o texto para a área de transferência (pbcopy no Mac, clip no Windows). Lança se falhar.
export function copiarTexto(texto) {
  if (MAC) execFileSync('pbcopy', { input: texto });
  else if (WINDOWS) execFileSync('clip', { input: texto, windowsHide: true });
  else execFileSync('xclip', ['-selection', 'clipboard'], { input: texto });
}

// Executável do Chrome no Windows (todos os usuários, 32 bits ou só este usuário). CHROME_PATH tem prioridade.
export function caminhoChrome() {
  const candidatos = [process.env.CHROME_PATH];
  if (WINDOWS) {
    for (const base of [process.env.PROGRAMFILES, process.env['PROGRAMFILES(X86)'], process.env.LOCALAPPDATA]) {
      if (base) candidatos.push(path.join(base, 'Google', 'Chrome', 'Application', 'chrome.exe'));
    }
  } else if (MAC) {
    candidatos.push('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome');
  }
  return candidatos.find((c) => c && fs.existsSync(c)) ?? null;
}

// Abre a URL numa aba nova do Chrome (com o Chrome já aberto, abre nele, com o login do gov.br).
// `aviso(motivo)` é chamado se não der para abrir.
export function abrirNoChrome(url, aviso = () => {}) {
  let filho;
  if (MAC) {
    filho = spawn('open', ['-a', 'Google Chrome', url], { detached: true, stdio: 'ignore' });
  } else {
    const exe = caminhoChrome();
    if (exe) filho = spawn(exe, [url], { detached: true, stdio: 'ignore' });
    else if (WINDOWS) filho = spawn('cmd', ['/c', 'start', '', 'chrome', url], { detached: true, stdio: 'ignore', windowsHide: true });
    else { aviso('Google Chrome não encontrado'); return; }
  }
  filho.on('error', (e) => aviso(e.message));
  filho.on('exit', (codigo) => { if (codigo) aviso(`código ${codigo}`); });
  filho.unref();
}

// Abre a pasta no Finder / Explorador de Arquivos.
export function abrirPasta(caminho) {
  if (MAC) semJanela('open', [caminho]);
  else if (WINDOWS) semJanela('explorer.exe', [caminho]);
  else semJanela('xdg-open', [caminho]);
}

// Abre a URL no navegador padrão.
export function abrirNavegador(url) {
  if (MAC) return semJanela('open', [url]);
  if (WINDOWS) return semJanela('cmd', ['/c', 'start', '', url]);
  return semJanela('xdg-open', [url]);
}

// Pasta onde o Chrome grava os downloads: a escolhida em chrome://settings/downloads (perfil padrão)
// ou, sem ela, a pasta Downloads do usuário (no Windows, mesmo que tenha sido movida para outra unidade).
export function pastaDownloadsPadrao() {
  const preferencias = WINDOWS
    ? path.join(process.env.LOCALAPPDATA ?? path.join(os.homedir(), 'AppData', 'Local'), 'Google', 'Chrome', 'User Data', 'Default', 'Preferences')
    : MAC
      ? path.join(os.homedir(), 'Library', 'Application Support', 'Google', 'Chrome', 'Default', 'Preferences')
      : path.join(os.homedir(), '.config', 'google-chrome', 'Default', 'Preferences');
  try {
    const pasta = JSON.parse(fs.readFileSync(preferencias, 'utf8'))?.download?.default_directory;
    if (pasta && fs.existsSync(pasta)) return pasta;
  } catch {
    // Chrome sem essa preferência (usa a pasta padrão) ou não instalado neste perfil.
  }
  if (WINDOWS) {
    // Pasta "Downloads" do Windows (pode ter sido movida em Propriedades > Local).
    try {
      const saida = execFileSync('reg', ['query', 'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\User Shell Folders', '/v', '{374DE290-123F-4565-9164-39C4925E467B}'], { encoding: 'utf8', windowsHide: true, stdio: ['ignore', 'pipe', 'ignore'] });
      const valor = saida.match(/REG_(?:EXPAND_)?SZ\s+(.+)/)?.[1]?.trim();
      const pasta = valor?.replace(/%([^%]+)%/g, (_, v) => process.env[v] ?? `%${v}%`);
      if (pasta && fs.existsSync(pasta)) return pasta;
    } catch {
      // Sem a chave: vale a pasta padrão.
    }
  }
  return path.join(os.homedir(), 'Downloads');
}

// Apaga o arquivo; no Windows tenta de novo por alguns segundos se o Chrome ou o antivírus ainda
// estiverem com ele aberto logo depois do download.
export async function apagarComPaciencia(arquivo, tentativas = 20) {
  for (let i = 1; ; i++) {
    try {
      fs.unlinkSync(arquivo);
      return;
    } catch (e) {
      if (e.code === 'ENOENT') return;
      if (!['EBUSY', 'EPERM', 'EACCES'].includes(e.code) || i >= tentativas) throw e;
      await new Promise((r) => setTimeout(r, 250));
    }
  }
}

// Troca o arquivo de nome por cima do destino, com a mesma paciência (o Windows recusa enquanto
// outro programa estiver lendo o destino).
export function renomearComPaciencia(origem, destino, tentativas = 30) {
  for (let i = 1; ; i++) {
    try {
      fs.renameSync(origem, destino);
      return;
    } catch (e) {
      if (!['EBUSY', 'EPERM', 'EACCES'].includes(e.code) || i >= tentativas) throw e;
      Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, 100);
    }
  }
}
