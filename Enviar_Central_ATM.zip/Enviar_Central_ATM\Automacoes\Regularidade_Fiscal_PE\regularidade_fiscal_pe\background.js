/*
 * Service worker (MV3). Orquestra a FILA de documentos (src/fila.js) e os downloads.
 * Todos os ouvintes são registrados no topo (exigência do MV3) e o estado fica em chrome.storage,
 * então o worker pode ser suspenso/reiniciado a qualquer momento sem perder o andamento.
 */
self.window = self; // os módulos compartilhados usam "window"
importScripts('src/config.js', 'src/documento.js', 'src/arquivos.js', 'src/fila.js');

const NS = self.EFiscoCRF;
const K_JOB = 'efisco_job';
const K_EVENTOS = 'efisco_eventos';
const K_ESTADO = 'efisco_estado';

const api = {
  storage: chrome.storage.local,
  tabs: chrome.tabs,
  windows: chrome.windows,
  downloads: chrome.downloads,
  alarms: chrome.alarms,
  /** O Chrome só permite a extensão em janela anônima se o usuário marcar "Permitir no modo anônimo". */
  incognitoPermitido: () => new Promise((resolve) => { try { chrome.extension.isAllowedIncognitoAccess((v) => resolve(!!v)); } catch (_) { resolve(false); } }),
  fetch: (url, opcoes) => fetch(url, opcoes),
  agora: () => Date.now(),
  espera: (ms) => new Promise((r) => setTimeout(r, ms)),
  /** Lê o início do arquivo baixado — só funciona se o usuário liberar "Permitir acesso a URLs de arquivo". Senão, null. */
  lerCabecalho: async (caminho) => {
    try {
      // Windows: "C:\Users\..." vira "file:///C:/Users/..." (no Mac o caminho já começa com "/").
      const barra = String(caminho).replace(/\\/g, '/');
      const r = await fetch('file://' + (barra.startsWith('/') ? '' : '/') + encodeURI(barra).replace(/#/g, '%23').replace(/\?/g, '%3F'));
      return new Uint8Array(await r.arrayBuffer()).slice(0, 1024);
    } catch (_) { return null; }
  }
};
const fila = NS.criarFila(api);

/** Eventos observados (abas, janelas, downloads) — só enquanto há uma execução em andamento. */
async function registrarEvento(tipo, dados) {
  const d = await chrome.storage.local.get([K_ESTADO, K_EVENTOS, K_JOB]);
  const ativo = d[K_ESTADO] || (d[K_JOB] && ['executando', 'pausado'].includes(d[K_JOB].estado));
  if (!ativo) return;
  const lista = (d[K_EVENTOS] || []).slice(-49);
  lista.push({ t: Date.now(), tipo, ...dados });
  await chrome.storage.local.set({ [K_EVENTOS]: lista });
}
chrome.tabs.onCreated.addListener((t) => registrarEvento('aba-criada', { url: t.pendingUrl || t.url || '' }));
chrome.windows.onCreated.addListener((w) => registrarEvento('janela-criada', { janela: w.type }));
chrome.downloads.onCreated.addListener((d) => registrarEvento('download-iniciado', {
  url: String(d.finalUrl || d.url || '').slice(0, 200), arquivo: d.filename || '', mime: d.mime || ''
}));
chrome.tabs.onUpdated.addListener((id, mud, tab) => {
  if (!mud.url) return;
  if (/efisco\.sefaz\.pe\.gov\.br/i.test(mud.url) || /\.pdf([?#]|$)/i.test(mud.url)) registrarEvento('aba-url', { tabId: id, url: mud.url.slice(0, 300) });
  fila.aoAbaAtualizada(id, mud.url, tab && tab.openerTabId).catch(() => {});
});
chrome.tabs.onRemoved.addListener((id) => { fila.aoAbaRemovida(id).catch(() => {}); });

// Downloads: pasta/nome do arquivo e validação
chrome.downloads.onDeterminingFilename.addListener((dl, suggest) => {
  fila.aoDeterminarNome(dl).then((s) => (s ? suggest(s) : suggest())).catch(() => suggest());
  return true; // resposta assíncrona
});
chrome.downloads.onChanged.addListener((d) => { fila.aoDownloadMudou(d).catch(() => {}); });
chrome.alarms.onAlarm.addListener((a) => { if (a.name === 'efisco-watchdog') fila.aoAlarme().catch(() => {}); });

// Comandos do painel e mensagens dos content scripts
chrome.runtime.onMessage.addListener((msg, sender, responder) => {
  if (!msg || !msg.tipo) return false;
  const tabId = sender.tab && sender.tab.id;
  const resp = (p) => { p.then(responder, (e) => responder({ ok: false, erro: String((e && e.message) || e) })); return true; };
  switch (msg.tipo) {
    case 'JOB_INICIAR': return resp(fila.iniciar(msg));
    case 'JOB_PAUSAR': return resp(fila.pausar());
    case 'JOB_CONTINUAR': return resp(fila.continuar());
    case 'JOB_PARAR': return resp(fila.parar());
    case 'INCOGNITO_STATUS': return resp(fila.incognitoPermitido().then((permitido) => ({ ok: true, permitido })));
    case 'ABRIR_CONFIG': return resp(chrome.tabs.create({ url: 'chrome://extensions/?id=' + chrome.runtime.id }).then(() => ({ ok: true })));
    case 'ITEM_HELLO': return resp(fila.aoHello(tabId).then((x) => x || {}));
    case 'ITEM_STATUS': return resp(fila.aoStatus(msg));
    case 'ITEM_FINAL': return resp(fila.aoFinal(msg));
    default: return false;
  }
});

// Ícone da extensão → abre (ou foca) o painel em uma aba própria, que não some ao clicar fora.
async function abrirPainel() {
  const url = chrome.runtime.getURL('painel/painel.html');
  const [existente] = await chrome.tabs.query({ url });
  if (existente) {
    await chrome.tabs.update(existente.id, { active: true });
    await chrome.windows.update(existente.windowId, { focused: true });
  } else {
    await chrome.tabs.create({ url });
  }
}
chrome.action.onClicked.addListener(() => { abrirPainel().catch(() => {}); });
