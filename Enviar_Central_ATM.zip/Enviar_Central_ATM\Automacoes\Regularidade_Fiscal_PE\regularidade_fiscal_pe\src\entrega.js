/*
 * Entrega da certidão — depois do clique em "Emitir (e)".
 * O comportamento real do site AINDA PRECISA SER CONFIRMADO; por isso a extensão observa 3 caminhos e registra tudo:
 *   1) download iniciado pelo próprio site;      2) página/aba com um PDF;      3) tela de confirmação (pede ação humana).
 * Confirmações NÃO são acionadas automaticamente (config entrega.confirmacaoAutomatica = false).
 */
(function () {
  'use strict';
  const NS = (window.EFiscoCRF = window.EFiscoCRF || {});
  const { dormir } = NS.wait;

  const INDISPONIVEL = /n[aã]o (foi poss[ií]vel|pode ser|ser[aá] poss[ií]vel) (emitir|gerar)|certid[aã]o .{0,40}(indispon|n[aã]o dispon)|n[aã]o h[aá] certid|existem? (irregularidades|pend[eê]ncias|d[eé]bitos)|n[aã]o foi encontrad/i;
  const PARECE_PDF = /\.pdf([?#]|$)|[?&](tipo|formato|output)=pdf/i;

  /**
   * Aguarda o arquivo (ou um desfecho) por tempo limitado.
   * @param {object} base  retorno de NS.observador.capturar()/baseVazia()
   * @returns {Promise<{via:'download'|'pdf-pagina'|'aba'|'sem_certidao'|'captcha'|'nenhuma', url?:string, tabId?:number, mensagem?:string}>}
   */
  async function aguardar(base) {
    const cfg = NS.CONFIG.entrega;
    const inicio = Date.now();
    let limite = cfg.timeout;
    let avisouHumano = false;
    let ultimoDialogo = '';
    NS.log.info(`[Entrega] Aguardando o arquivo da certidão (até ${Math.round(limite / 1000)} s)...`);

    while (Date.now() - inicio < limite) {
      await NS.job.verificarPausa();
      if (NS.telaCaptcha.detectar()) return { via: 'captcha' };
      if (document.contentType === 'application/pdf') return { via: 'pdf-pagina', url: location.href };

      const eventos = await NS.observador.lerEventos(base.t0);
      if (eventos.some((e) => e.tipo === 'download-iniciado')) return { via: 'download' };
      const aba = eventos.find((e) => e.tipo === 'aba-url' && PARECE_PDF.test(e.url || ''));
      if (aba) return { via: 'aba', url: aba.url, tabId: aba.tabId };

      const d = NS.observador.diferencas(base);
      const texto = d.textoNovo.join(' | ');
      if (INDISPONIVEL.test(texto)) return { via: 'sem_certidao', mensagem: texto.slice(0, 300) };

      const dlg = d.novosDialogos[0];
      if (dlg) {
        const t = NS.observador.limpo(dlg.textContent).slice(0, 300);
        if (t !== ultimoDialogo) {
          ultimoDialogo = t;
          NS.log.aviso(`[Entrega] O site exibiu uma mensagem/confirmação: "${t}"`);
        }
        if (!avisouHumano && !cfg.confirmacaoAutomatica) {
          avisouHumano = true;
          limite = Math.max(limite, cfg.timeoutComHumano);
          const msg = `O e-Fisco pediu uma confirmação ("${t.slice(0, 120)}"). Confirme manualmente na página; a extensão continua observando.`;
          NS.log.aviso('[Entrega] ' + msg + ' (nada foi clicado pela automação)');
          NS.job.status({ humano: msg, etapa: 'aguardando confirmação manual' });
        }
      }
      await dormir(600);
    }
    const resto = NS.observador.diferencas(base);
    return { via: 'nenhuma', mensagem: resto.textoNovo.slice(0, 3).join(' | ') };
  }

  /**
   * Busca o PDF A PARTIR DA PÁGINA do e-Fisco: assim vale a sessão/cookies da janela anônima
   * (o background usa os cookies da janela comum e não enxergaria esta sessão).
   * @returns {Promise<string>} data URL base64 do PDF
   */
  async function obterPdf(url) {
    const r = await fetch(url, { credentials: 'include' });
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    const bytes = new Uint8Array(await r.arrayBuffer());
    if (!NS.arquivos.ehPdf(bytes)) throw new Error('o conteúdo recebido não é um PDF (cabeçalho %PDF- ausente)');
    return NS.arquivos.paraDataUrl(bytes);
  }

  NS.entrega = { aguardar, obterPdf, PARECE_PDF };
})();
