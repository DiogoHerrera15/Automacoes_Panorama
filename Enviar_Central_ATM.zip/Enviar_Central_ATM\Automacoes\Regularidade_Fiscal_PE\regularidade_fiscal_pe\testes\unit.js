/* Testes unitários dos módulos puros. Execute com:  node testes/unit.js */
'use strict';
const path = require('path');
const assert = require('assert');
global.window = global;
const raiz = path.join(__dirname, '..');
['config', 'documento', 'lista', 'arquivos'].forEach((m) => require(path.join(raiz, 'src', `${m}.js`)));
const NS = global.EFiscoCRF;
const D = NS.documento;
let ok = 0;
function teste(nome, fn) {
  try { fn(); ok++; console.log('  ✔', nome); } catch (e) { console.error('  ✘', nome, '\n     ', e.message); process.exitCode = 1; }
}

console.log('Validação de dígitos');
teste('CNPJ de teste 11222333000181 é válido; máscara 11.222.333/0001-81', () => {
  assert.ok(D.validarCnpj('11222333000181')); assert.strictEqual(D.formatarCnpj('11222333000181'), '11.222.333/0001-81');
});
teste('CPF 12345678909 é válido; formata 123.456.789-09; repetidos e DV errado são inválidos', () => {
  assert.ok(D.validarCpf('12345678909')); assert.strictEqual(D.formatarCpf('12345678909'), '123.456.789-09');
  assert.ok(!D.validarCpf('11111111111')); assert.ok(!D.validarCpf('12345678900'));
});
teste('IE de 9 dígitos: 0321418-40 válida; 0123456-78 inválida (DV1 deveria ser 0)', () => {
  assert.ok(D.validarIE9('032141840')); assert.ok(!D.validarIE9('012345678')); assert.strictEqual(D.formatarIE('032141840'), '0321418-40');
});

console.log('Classificação automática');
const C = (x, m) => D.classificar(x, m);
teste('11 dígitos (com ou sem pontuação) → CPF', () => {
  assert.strictEqual(C('12345678909').tipo, 'CPF'); assert.strictEqual(C('123.456.789-09').tipo, 'CPF');
  assert.strictEqual(C('123.456.789-09').digitos, '12345678909');
});
teste('14 dígitos que formam CNPJ válido → CNPJ (com ou sem máscara)', () => {
  assert.strictEqual(C('11222333000181').tipo, 'CNPJ'); assert.strictEqual(C(' 11.222.333/0001-81 ').tipo, 'CNPJ'); assert.ok(C('11222333000181').valido);
});
teste('9 dígitos → IE (válida com DV correto; inválida com DV errado, mas ainda classificada como IE)', () => {
  const a = C('0321418-40'); assert.strictEqual(a.tipo, 'IE'); assert.ok(a.valido);
  const b = C('012345678'); assert.strictEqual(b.tipo, 'IE'); assert.ok(!b.valido); assert.match(b.motivo, /dígito verificador/);
});
teste('14 dígitos com máscara de IE antiga → IE com aviso (DV não verificado)', () => {
  const c = C('18.1.001.0000004-6'); assert.strictEqual(c.tipo, 'IE'); assert.ok(c.valido); assert.ok(c.avisos.length === 1);
});
teste('14 dígitos que NÃO são CNPJ válido e sem máscara de IE → AMBÍGUO (não presume IE)', () => {
  const c = C('11222333000182'); assert.strictEqual(c.tipo, null); assert.ok(c.ambiguo);
});
teste('quantidade de dígitos fora do padrão (ex.: 8, 10, 12) → AMBÍGUO, nunca IE por exclusão', () => {
  ['12345678', '1234567890', '123456789012'].forEach((x) => { const c = C(x); assert.strictEqual(c.tipo, null); assert.ok(c.ambiguo, x); });
});
teste('letras/símbolos → inválido (não ambíguo)', () => {
  const c = C('12A45678909'); assert.strictEqual(c.tipo, null); assert.ok(!c.ambiguo); assert.ok(!c.valido);
});
teste('tipo manual resolve a ambiguidade e valida conforme o tipo escolhido', () => {
  assert.strictEqual(C('11222333000182', 'CNPJ').tipo, 'CNPJ'); assert.ok(!C('11222333000182', 'CNPJ').valido);
  assert.ok(C('18100100000046', 'IE').valido); assert.ok(!C('123', 'CPF').valido);
});

console.log('Lista (vários documentos)');
const EXEMPLO = '11222333000181\n12345678909\n012345678\n 11.222.333/0001-81 \n\n0321418-40\n12345678';
teste('lê, remove espaços, classifica, acha duplicados e ambíguos', () => {
  const it = NS.lista.processar(EXEMPLO);
  assert.deepStrictEqual(it.map((x) => x.tipo), ['CNPJ', 'CPF', 'IE', 'CNPJ', 'IE', null]);
  assert.ok(it[3].duplicado); assert.strictEqual(it[3].duplicadoDe, 'L1'); assert.ok(it[5].ambiguo);
  const r = NS.lista.resumo(it);
  assert.deepStrictEqual([r.total, r.CNPJ, r.CPF, r.IE, r.duplicados, r.ambiguos, r.invalidos, r.executaveis], [6, 1, 1, 2, 1, 1, 1, 3]);
});
teste('fila: só executáveis, na ordem; IE inválida entra se o usuário forçar; ambíguo entra após escolher o tipo', () => {
  let it = NS.lista.processar(EXEMPLO);
  assert.deepStrictEqual(NS.lista.paraFila(it).map((x) => x.digitos), ['11222333000181', '12345678909', '032141840']);
  it = NS.lista.processar(EXEMPLO, { forcar: { L3: true }, tipos: { L7: 'CPF' } });
  const f = NS.lista.paraFila(it);
  assert.deepStrictEqual(f.map((x) => x.id), ['L1', 'L2', 'L3', 'L6']);
  assert.ok(f[2].forcado);
});
teste('aceita separadores ; , e tab (planilha colada)', () => {
  assert.strictEqual(NS.lista.processar('11222333000181;12345678909,032141840\t12345678909').length, 4);
});

console.log('Pasta e arquivos');
const A = NS.arquivos;
teste('nome da pasta: preserva o informado; troca só o que o SO não aceita', () => {
  const a = A.sanitizarNomePasta('CERTIDOES_SEFAZ_NOVEMBRO_2026'); assert.strictEqual(a.nome, 'CERTIDOES_SEFAZ_NOVEMBRO_2026'); assert.ok(!a.alterado);
  const b = A.sanitizarNomePasta(' certidões/nov:2026. '); assert.strictEqual(b.nome, 'certidões_nov_2026'); assert.ok(b.alterado);
  assert.strictEqual(A.sanitizarNomePasta('..').nome, ''); assert.strictEqual(A.sanitizarNomePasta('CON').nome, 'CON_');
});
teste('nome do arquivo padronizado; usa a razão social só quando existe', () => {
  assert.strictEqual(A.nomeArquivo({ tipo: 'CNPJ', digitos: '11222333000181' }), 'CNPJ_11222333000181_CERTIDAO.pdf');
  assert.strictEqual(A.nomeArquivo({ tipo: 'CPF', digitos: '12345678909' }), 'CPF_12345678909_CERTIDAO.pdf');
  assert.strictEqual(A.nomeArquivo({ tipo: 'IE', digitos: '032141840' }), 'IE_032141840_CERTIDAO.pdf');
  assert.strictEqual(A.nomeArquivo({ tipo: 'CNPJ', digitos: '11222333000181', razao: 'Empresa Exemplo Ltda.' }), 'EMPRESA_EXEMPLO_LTDA_CNPJ_11222333000181.pdf');
  assert.strictEqual(A.nomeArquivo({ tipo: 'CNPJ', digitos: '1', razao: '' }), 'CNPJ_1_CERTIDAO.pdf');
});
teste('PDF: aceita %PDF- e rejeita HTML/vazio', () => {
  const pdf = Uint8Array.from(Buffer.from('%PDF-1.4\n' + 'x'.repeat(300))); assert.ok(A.ehPdf(pdf));
  assert.ok(!A.ehPdf(Uint8Array.from(Buffer.from('<html>' + 'x'.repeat(300))))); assert.ok(!A.ehPdf(new Uint8Array(10)));
  assert.ok(A.paraDataUrl(pdf).startsWith('data:application/pdf;base64,'));
});
teste('data URL de PDF: confere cabeçalho e tamanho; rejeita HTML', () => {
  const pdf = Uint8Array.from(Buffer.from('%PDF-1.4\n' + 'x'.repeat(600)));
  const du = A.paraDataUrl(pdf); assert.ok(A.ehPdfDataUrl(du)); assert.strictEqual(A.tamanhoDataUrl(du), pdf.length);
  assert.ok(!A.ehPdfDataUrl(A.paraDataUrl(Uint8Array.from(Buffer.from('<html>' + 'x'.repeat(600))), 'text/html'))); assert.ok(!A.ehPdfDataUrl('lixo'));
});
console.log(`\n${ok} teste(s) ok`);
