﻿# Confere o computador e (se já instalada) a Central de Automações. SÓ LÊ: não instala nem muda nada.
#   powershell -NoProfile -ExecutionPolicy Bypass -File verificar_ambiente.ps1 [-Destino <pasta>] [-SoRequisitos]
# Saída: 0 = sem erros; 1 = há erros (veja as linhas [ERRO]). Avisos não contam como erro.
param(
  [string]$Destino = (Join-Path $env:USERPROFILE 'Central_ATM'),
  [string]$PastaPGFN = (Join-Path $env:USERPROFILE 'Downloads\Auto_PGFN'),
  [switch]$SoRequisitos,
  [string]$Log = ''
)
$ErrorActionPreference = 'Continue'
. (Join-Path $PSScriptRoot 'comum.ps1')
if ($Log) { $script:LOG = $Log }

Write-Host ''
Write-Host '  Verificação do ambiente - Central de Automações' -ForegroundColor Cyan
Info "Pasta de instalação: $Destino"
Info "Pasta da PGFN:       $PastaPGFN"

# ------------------------------------------------------------------ requisitos do Windows
Titulo 'Requisitos'
$os = [Environment]::OSVersion.Version
if ($os.Major -ge 10) { Ok "Windows $($os.Major).$($os.Minor) (build $($os.Build))" } else { Erro "Windows $($os): é preciso Windows 10 ou 11" }
if ($PSVersionTable.PSVersion.Major -ge 5) { Ok "PowerShell $($PSVersionTable.PSVersion)" } else { Erro "PowerShell $($PSVersionTable.PSVersion): é preciso 5.1 ou mais novo" }
$downloads = Join-Path $env:USERPROFILE 'Downloads'
if (Test-Path -LiteralPath $downloads) { Ok "pasta Downloads: $downloads" } else { Erro "pasta Downloads não existe: $downloads" }

$chrome = Achar-Chrome
if ($chrome) { Ok "Google Chrome: $chrome" } else { Erro 'Google Chrome não encontrado (todas as automações usam o Chrome). Instale: winget install Google.Chrome' }

$node = Versao-Node
if ($node -ge 20) { Ok "Node.js v$node (npm $(& npm -v 2>$null))" }
elseif ($node -gt 0) { Erro "Node.js v$node é antigo: o RETIRAR AUTO-INFRAÇÃO precisa da versão 20 ou mais nova" }
else { Erro 'Node.js não encontrado (RETIRAR AUTO-INFRAÇÃO e ATM RFB precisam). Instale: winget install OpenJS.NodeJS.LTS' }

$py = Achar-Python
if ($py) { Ok "Python $($py.Versao) ($($py.Comando -join ' '))" } else { Erro 'Python 3.8+ não encontrado (o ATM RFB precisa). Instale: winget install Python.Python.3.12' }

if (Get-Command winget -ErrorAction SilentlyContinue) { Ok 'winget disponível (instala o que faltar)' } else { Aviso 'winget não encontrado: instale Node/Python pelos sites oficiais (nodejs.org, python.org)' }
$csc = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
if (Test-Path -LiteralPath $csc) { Ok '.NET Framework 4 (compilador da interface PGFN, só se o .exe faltar)' } else { Aviso '.NET Framework 4 (csc.exe) não encontrado: só faz falta se Automacao_PGFN.exe precisar ser recompilado' }

# configuração de downloads do Chrome (perfil padrão)
$prefs = Join-Path $env:LOCALAPPDATA 'Google\Chrome\User Data\Default\Preferences'
if (Test-Path -LiteralPath $prefs) {
  try {
    $pr = Get-Content -LiteralPath $prefs -Raw -Encoding UTF8 | ConvertFrom-Json
    $dir = [string]$pr.download.default_directory
    if (-not $dir -or $dir.TrimEnd('\') -ieq $downloads) { Ok 'o Chrome salva na pasta Downloads' } else { Aviso "o Chrome salva em ""$dir"": volte para $downloads (chrome://settings/downloads)" }
    if ($pr.download.prompt_for_download -eq $true) { Aviso 'o Chrome pergunta onde salvar cada arquivo: desligue em chrome://settings/downloads' } else { Ok '"Perguntar onde salvar cada arquivo" desligado' }
  } catch { Aviso 'não consegui ler as configurações do Chrome' }
} else { Aviso 'o Chrome ainda não foi aberto neste usuário (abra uma vez e rode de novo)' }

if ($SoRequisitos) {
  Write-Host ''
  if ($script:ERROS) { Write-Host "  Requisitos: $($script:ERROS) erro(s), $($script:AVISOS) aviso(s)." -ForegroundColor Yellow; exit 1 }
  Write-Host "  Requisitos OK ($($script:AVISOS) aviso(s))." -ForegroundColor Green; exit 0
}

# ------------------------------------------------------------------ instalação
Titulo 'Central de Automações'
$central = Join-Path $Destino 'Central_de_Automacoes'
foreach ($f in 'Central.ps1', 'Abrir Central.vbs', 'automacoes.json', 'ajuda.json') {
  if (Test-Path -LiteralPath (Join-Path $central $f)) { Ok "$f" } else { Erro "falta $central\$f" }
}
$lnk = Join-Path ([Environment]::GetFolderPath('Desktop')) 'Central de Automações.lnk'
if (Test-Path -LiteralPath $lnk) {
  $alvo = (New-Object -ComObject WScript.Shell).CreateShortcut($lnk).Arguments
  if ($alvo -like "*$central*") { Ok 'atalho "Central de Automações" na Área de Trabalho' } else { Aviso "o atalho da Área de Trabalho aponta para outra pasta: $alvo" }
} else { Aviso 'atalho "Central de Automações" não existe na Área de Trabalho (rode configurar_central.ps1)' }

Titulo 'Automações e dependências'
$exts = @(Extensoes-Chrome)
foreach ($a in (Catalogo $Destino $PastaPGFN)) {
  Write-Host "  - $($a.Nome)" -ForegroundColor White
  if (-not (Test-Path -LiteralPath $a.Pasta)) { Erro "pasta não encontrada: $($a.Pasta)"; continue }
  if ($a.Entrada -notlike '(*' -and -not (Test-Path -LiteralPath $a.Entrada)) { Erro "ponto de entrada não encontrado: $($a.Entrada)" }
  if ($a.Node -and -not (Test-Path -LiteralPath (Join-Path $a.Pasta 'node_modules\pdfjs-dist'))) { Erro "dependências Node não instaladas (rode npm ci em $($a.Pasta))" }
  if ($a.Python) {
    $vpy = Join-Path $a.Pasta '.venv\Scripts\python.exe'
    if (-not (Test-Path -LiteralPath $vpy)) { Erro "ambiente Python (.venv) não criado em $($a.Pasta)" }
    else { & $vpy -c 'import PIL, openpyxl' 2>$null; if ($LASTEXITCODE -eq 0) { Ok '.venv com Pillow e openpyxl' } else { Erro '.venv sem Pillow/openpyxl (rode o instalar.ps1 do ATM_RFB)' } }
  }
  if ($a.Extensao) {
    if (-not (Test-Path -LiteralPath (Join-Path $a.Extensao 'manifest.json'))) { Erro "pasta da extensão sem manifest.json: $($a.Extensao)" }
    else {
      $e = @($exts | Where-Object { $_.Pasta -ieq $a.Extensao.TrimEnd('\') })
      if (-not $e.Count) { Aviso "extensão NÃO carregada no Chrome: carregue $($a.Extensao)" }
      elseif (-not @($e | Where-Object Ligada).Count) { Aviso 'extensão carregada mas DESLIGADA em chrome://extensions' }
      else {
        Ok "extensão carregada e ligada (ID $(@($e.Id | Sort-Object -Unique) -join ', '))"
        if ($a.Anonimo -and -not @($e | Where-Object Anonimo).Count) { Aviso 'ligue "Permitir no modo anônimo" nos Detalhes da extensão' }
      }
    }
  }
}

Titulo 'Ajudante do Windows da PGFN'
$manif = (Get-ItemProperty 'HKCU:\Software\Google\Chrome\NativeMessagingHosts\com.auto_pgfn.salvar_como' -ErrorAction SilentlyContinue).'(default)'
if (-not $manif) { Aviso 'ajudante da PGFN ainda não registrado: depois de carregar a extensão Automação_PGFN, rode Downloads\Auto_PGFN\INSTALAR.bat' }
elseif (-not (Test-Path -LiteralPath $manif)) { Erro "o registro do ajudante aponta para um arquivo que não existe: $manif" }
else {
  try { $m = Get-Content -LiteralPath $manif -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($m.path -like "$PastaPGFN*") { Ok "ajudante registrado ($($m.path))" } else { Aviso "ajudante registrado para outra pasta: $($m.path)" } } catch { Aviso 'não consegui ler o registro do ajudante' }
}

Titulo 'Conferência da própria Central (-Validar)'
if (Test-Path -LiteralPath (Join-Path $central 'Central.ps1')) {
  $antes = [Console]::OutputEncoding
  try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch { }   # a Central escreve em UTF-8 no modo -Validar
  $saida = & powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $central 'Central.ps1') -Validar 2>&1 | Out-String
  try { [Console]::OutputEncoding = $antes } catch { }
  $saida -split "`r?`n" | Where-Object { $_.Trim() } | ForEach-Object { Info $_ }
  if ($saida -match 'ERRO:' -or $saida -match 'pronto : N') { Erro 'a Central apontou automações que não podem ser abertas (veja acima)' } else { Ok 'todas as automações podem ser abertas pela Central' }
}

Write-Host ''
if ($script:ERROS) { Write-Host "  Resultado: $($script:ERROS) erro(s) e $($script:AVISOS) aviso(s). Veja Documentacao\Solucao_Problemas.md." -ForegroundColor Yellow; exit 1 }
Write-Host "  Resultado: nenhum erro ($($script:AVISOS) aviso(s) para conferir)." -ForegroundColor Green
exit 0
