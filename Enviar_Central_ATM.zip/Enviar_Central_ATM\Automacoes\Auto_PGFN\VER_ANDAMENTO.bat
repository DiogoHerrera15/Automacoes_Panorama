@echo off
rem Automacao PGFN - mostra a situacao de cada CNPJ (pode usar com a automacao rodando; so le, nao muda nada).
chcp 65001 >nul
title Automação PGFN - andamento
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0orquestrador\ver_andamento.ps1"
pause
