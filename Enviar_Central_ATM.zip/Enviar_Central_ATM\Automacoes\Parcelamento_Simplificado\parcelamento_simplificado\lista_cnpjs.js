// ============================ LISTA DE EMPRESAS A PROCESSAR ============================
// A extensão processa UMA empresa por vez, na ordem da lista, e guarda o andamento no navegador.
// - Empresa concluída = consulta "sem negociações" (PDF salvo) ou DARF emitido (PDF salvo).
// - Se parar por qualquer situação nova ou erro, a empresa NÃO é dada como concluída: ao rodar de novo,
//   ela recomeça nessa mesma empresa.
//
// MODO_INTERFACE = true (padrão, a partir da versão 1.8.0): a lista de empresas, o nome da pasta de destino e o
//   lote vêm da JANELA da extensão (clique no ícone ou abra pela Central de Automações): você digita a pasta e cola
//   as empresas no formato  cnpj;nome_da_empresa . Neste modo, LISTA_CNPJS, ID_LOTE, PASTA_*, JA_CONCLUIDAS,
//   PULAR_CNPJS, COM_ERRO_INICIAL e CONTINUAR_SOZINHO abaixo NÃO são usados (valem as da janela).
// MODO_INTERFACE = false: volta ao funcionamento antigo, com tudo definido neste arquivo (precisa preencher a lista).
const MODO_INTERFACE = true;

// ---- Daqui para baixo: só valem com MODO_INTERFACE = false (exceto SITUACOES_PROCESSAR e DEVEDORAS_QUALQUER_MES) ----

// Mude este texto para recomeçar a lista do zero (apaga o andamento guardado). Use um nome novo a cada lote.
let ID_LOTE = 'novo-lote-01';

// Pastas onde os PDFs são salvos. São sempre subpastas da pasta Downloads do Chrome (a extensão não
// consegue salvar fora dela); pode usar subpastas aninhadas, separadas por "/".
//  - SEM negociação: PDF da tela "Não existem negociações…"   (nome: CNPJ_data-hora.pdf)
//  - COM negociação: PDF do DARF emitido                      (nome: CNPJ.pdf, ou CNPJ_1.pdf, CNPJ_2.pdf…)
// Use pastas diferentes em cada lote, para não misturar os PDFs.
const PASTA_SEM_NEGOCIACAO = 'Parcelamento/Sem_Negociacao';
const PASTA_COM_NEGOCIACAO = 'Parcelamento/Com_Negociacao';

// EXEMPLO (CNPJs fictícios): apague estas duas linhas e coloque as suas empresas. CNPJ só com os 14 dígitos.
const LISTA_CNPJS = [
  { nome: 'EMPRESA EXEMPLO 1 LTDA', cnpj: '00000000000000' },
  { nome: 'EMPRESA EXEMPLO 2 LTDA', cnpj: '00000000000000' },
];

// Situações da negociação (coluna "Situação" da tabela de consulta) em que a automação emite o DARF.
// Negociações em qualquer outra situação são puladas e anotadas. A comparação ignora maiúsculas e acentos.
const SITUACOES_PROCESSAR = ['Ativo', 'Requerimento em análise'];

// Parcelas marcadas no "Demonstrativo de parcelas": as "A vencer" do mês atual e do mês anterior, MAIS as "Devedora".
// true  = marca TODAS as parcelas "Devedora", de qualquer mês.
// false = marca só as "Devedora" cujo vencimento é do mês atual ou do mês anterior.
const DEVEDORAS_QUALQUER_MES = true;

// Empresas JÁ CONCLUÍDAS antes (CNPJs só com dígitos, entre aspas, separados por vírgula): contam como feitas e a
// automação não as refaz. Serve quando o Chrome perdeu o andamento (extensão removida ou carregada de outra pasta).
// Deixe vazio num lote novo. Para refazer uma empresa, apague o CNPJ daqui.
const JA_CONCLUIDAS = [];

// CNPJs (só dígitos) a pular, sem processar. Ex.: ['00000000000000']
const PULAR_CNPJS = [];

// Erro do sistema da Receita ("Não foi possível prosseguir. Tente mais tarde (Erro N)"): a extensão pula a
// empresa, marca "erro do sistema" e segue para a próxima; no fim da rodada lista as que deram erro, e um
// clique no ícone tenta essas de novo. Aqui ficam as que você já viu dar erro, para entrarem já marcadas
// (uma única vez) em vez de serem tentadas agora. Ex.: ['00000000000000']
const COM_ERRO_INICIAL = [];

// false = para depois de cada empresa, e você clica no ícone da extensão para seguir com a próxima.
// true  = segue sozinha para a próxima empresa (ainda para sozinha em qualquer situação nova ou erro).
let CONTINUAR_SOZINHO = true;
