﻿# Funções e catálogo usados pelos scripts de instalação (carregado com ". .\comum.ps1"; não rode sozinho).
# Tudo aqui só LÊ o computador; quem muda alguma coisa é o instalar.ps1 / configurar_central.ps1.

$PACOTE = Split-Path $PSScriptRoot -Parent           # a pasta Enviar_Central_ATM (onde o pacote foi extraído)
$script:LOG = $null                                   # arquivo de registro (definido pelo script que carregou este)
$script:ERROS = 0
$script:AVISOS = 0

function Registrar([string]$nivel, [string]$texto) {
  $cor = @{ 'OK' = 'Green'; 'AVISO' = 'Yellow'; 'ERRO' = 'Red'; 'INFO' = 'Gray'; 'TITULO' = 'Cyan' }[$nivel]
  $linha = if ($nivel -eq 'TITULO') { "`n== $texto" } elseif ($nivel -eq 'INFO') { "        $texto" } else { "  [{0,-5}] {1}" -f $nivel, $texto }
  Write-Host $linha -ForegroundColor $cor
  if ($nivel -eq 'ERRO') { $script:ERROS++ }
  if ($nivel -eq 'AVISO') { $script:AVISOS++ }
  if ($script:LOG) { try { "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') $linha" | Add-Content -LiteralPath $script:LOG -Encoding UTF8 } catch { } }
}
function Ok($t) { Registrar 'OK' $t }
function Aviso($t) { Registrar 'AVISO' $t }
function Erro($t) { Registrar 'ERRO' $t }
function Info($t) { Registrar 'INFO' $t }
function Titulo($t) { Registrar 'TITULO' $t }

# PATH atualizado (depois de instalar Node/Python a janela atual não enxerga o PATH novo sozinha).
function Atualizar-Path {
  $env:Path = ([Environment]::GetEnvironmentVariable('Path', 'Machine'), [Environment]::GetEnvironmentVariable('Path', 'User') -join ';')
}

function Achar-Chrome {
  $c = @($env:CHROME_PATH)
  foreach ($chave in 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe', 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe') {
    $c += (Get-ItemProperty $chave -ErrorAction SilentlyContinue).'(default)'
  }
  foreach ($b in @($env:ProgramFiles, ${env:ProgramFiles(x86)}, $env:LOCALAPPDATA)) { if ($b) { $c += Join-Path $b 'Google\Chrome\Application\chrome.exe' } }
  foreach ($x in $c) { if ($x -and (Test-Path -LiteralPath $x)) { return $x } }
  return $null
}

# Versão principal do Node.js (0 = não instalado).
function Versao-Node {
  try { $v = & node -v 2>$null; if ($LASTEXITCODE -eq 0 -and "$v" -match 'v(\d+)\.') { return [int]$Matches[1] } } catch { }
  return 0
}

# Python 3.8+ que funciona de verdade (o "python" da Microsoft Store é só um atalho para a loja). $null se não houver.
function Achar-Python {
  foreach ($cand in @(@('py', '-3'), @('python'), @('python3'))) {
    try {
      $exe = $cand[0]; $resto = @($cand | Select-Object -Skip 1)
      $v = & $exe @resto -c "import sys; print('%d.%d' % sys.version_info[:2])" 2>$null
      if ($LASTEXITCODE -eq 0 -and "$v" -match '^(\d+)\.(\d+)$' -and ([int]$Matches[1] -gt 3 -or ([int]$Matches[1] -eq 3 -and [int]$Matches[2] -ge 8))) {
        return [pscustomobject]@{ Comando = $cand; Versao = "$v" }
      }
    } catch { }
  }
  return $null
}

# Extensões "carregadas sem compactação" em todos os perfis do Chrome: Id, Pasta, Ligada, Anonimo, Perfil.
function Extensoes-Chrome {
  $lista = @()
  $base = Join-Path $env:LOCALAPPDATA 'Google\Chrome\User Data'
  if (-not (Test-Path -LiteralPath $base)) { return $lista }
  foreach ($perfil in Get-ChildItem -LiteralPath $base -Directory -ErrorAction SilentlyContinue) {
    foreach ($arq in 'Secure Preferences', 'Preferences') {
      $caminho = Join-Path $perfil.FullName $arq
      if (-not (Test-Path -LiteralPath $caminho)) { continue }
      try { $json = Get-Content -LiteralPath $caminho -Raw -Encoding UTF8 | ConvertFrom-Json } catch { continue }
      if (-not $json.extensions.settings) { continue }
      foreach ($p in $json.extensions.settings.PSObject.Properties) {
        $pasta = [string]$p.Value.path
        if (-not ($pasta -match ':\\')) { continue }
        $lista += [pscustomobject]@{
          Id = $p.Name; Pasta = $pasta.TrimEnd('\'); Perfil = $perfil.Name; Anonimo = [bool]$p.Value.incognito
          Ligada = -not @($p.Value.disable_reasons).Where({ $_ -and $_ -ne 0 }).Count
        }
      }
    }
  }
  return $lista
}

# Catálogo das automações do pacote. Pasta/Entrada/Extensao já resolvidas para a instalação em $Destino.
function Catalogo([string]$Destino, [string]$PastaPGFN) {
  $A = Join-Path $Destino 'Automacoes'
  return @(
    [pscustomobject]@{ Nome = 'RETIRAR AUTO-INFRAÇÃO'; Pasta = "$A\Retirar_Auto_Infracao"; Entrada = "$A\Retirar_Auto_Infracao\ABRIR_INTERFACE.cmd"
      Extensao = "$A\Retirar_Auto_Infracao\extensao-chrome"; Anonimo = $false; Node = $true; Python = $false }
    [pscustomobject]@{ Nome = 'CERTIDÃO RECEITA FEDERAL (ATM RFB)'; Pasta = "$A\ATM_RFB"; Entrada = "$A\ATM_RFB\INTERFACE RFB EMISSAO.cmd"
      Extensao = "$A\ATM_RFB\extensao-chrome"; Anonimo = $true; Node = $true; Python = $true }
    [pscustomobject]@{ Nome = 'PGFN – DOCUMENTOS DE ARRECADAÇÃO'; Pasta = $PastaPGFN; Entrada = "$PastaPGFN\Automacao_PGFN.exe"
      Extensao = "$PastaPGFN\Automação_PGFN"; Anonimo = $true; Node = $false; Python = $false }
    [pscustomobject]@{ Nome = 'SITUAÇÃO FISCAL'; Pasta = "$A\Situacao_Fiscal"; Entrada = '(Chrome no e-CAC + ícone da extensão)'
      Extensao = "$A\Situacao_Fiscal\Situacao_Fiscal"; Anonimo = $false; Node = $false; Python = $false }
    [pscustomobject]@{ Nome = 'PARCELAMENTO SIMPLIFICADO'; Pasta = "$A\Parcelamento_Simplificado"; Entrada = '(Chrome anônimo no e-CAC; a janela da extensão abre sozinha)'
      Extensao = "$A\Parcelamento_Simplificado\parcelamento_simplificado"; Anonimo = $true; Node = $false; Python = $false }
    [pscustomobject]@{ Nome = 'REGULARIDADE FISCAL PE (E-FISCO)'; Pasta = "$A\Regularidade_Fiscal_PE"; Entrada = '(painel da extensão)'
      Extensao = "$A\Regularidade_Fiscal_PE\regularidade_fiscal_pe"; Anonimo = $true; Node = $false; Python = $false }
    [pscustomobject]@{ Nome = 'CNDT – DÉBITOS TRABALHISTAS (TST)'; Pasta = "$A\CNDT_Debito_Trabalhista"; Entrada = '(página do TST; a janela da extensão abre sozinha)'
      Extensao = "$A\CNDT_Debito_Trabalhista\C_debito_Trabalhista"; Anonimo = $false; Node = $false; Python = $false }
  )
}

function Criar-Atalho([string]$arquivo, [string]$destinoCentral) {
  $ws = New-Object -ComObject WScript.Shell
  $lnk = $ws.CreateShortcut($arquivo)
  $lnk.TargetPath = Join-Path $env:WINDIR 'System32\wscript.exe'
  $lnk.Arguments = '"' + (Join-Path $destinoCentral 'Abrir Central.vbs') + '"'
  $lnk.WorkingDirectory = $destinoCentral
  $lnk.IconLocation = (Join-Path $env:WINDIR 'System32\imageres.dll') + ',109'
  $lnk.Description = 'Central de Automações'
  $lnk.Save()
}
