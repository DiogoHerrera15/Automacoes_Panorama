/*
 * Tela intermediária "Não foi possível concluir a verificação de segurança (CAPTCHA)".
 * O botão "Clique aqui para prosseguir (p)" só VOLTA à tela anterior: não resolve nem simula o CAPTCHA.
 * Esta automação reconhece a tela, relata a mensagem e clica UMA vez em "Prosseguir"; a nova verificação
 * de segurança continua sendo exigida (e, se preciso, concluída pelo usuário) antes de qualquer outra ação.
 */
(function () {
  'use strict';
  const NS = (window.EFiscoCRF = window.EFiscoCRF || {});
  const { dormir, esperarOuNulo } = NS.wait;
  const { norm } = NS.dom;

  /** Texto principal e botão "Prosseguir" desta tela, ou null se a página não for ela. */
  function detectar() {
    const cfg = NS.CONFIG.telaCaptcha;
    const texto = norm(document.body ? document.body.innerText : '');
    if (!cfg.frases.some((f) => texto.includes(f))) return null;
    const botao = NS.dom.clicaveisPorTexto(cfg.textoBotao).find((b) => !/localizar|emitir/.test(norm(b.value || b.textContent))) || null;
    const linhas = String(document.body.innerText).split('\n').map((l) => l.replace(/\s+/g, ' ').trim())
      .filter((l) => /verifica[cç][aã]o de seguran[cç]a|complemento|orienta[cç][aã]o|captcha|prosseguir|retorne/i.test(l));
    return { mensagem: linhas[0] || 'Não foi possível concluir a verificação de segurança (CAPTCHA).', linhas, botao };
  }

  /** Move o cursor, clica UMA vez em "Prosseguir" e aguarda a saída da tela. @returns {{navegou:boolean}} */
  async function prosseguir(tela) {
    const cfg = NS.CONFIG.telaCaptcha;
    const botao = tela.botao;
    if (!botao || !NS.wait.estaVisivel(botao)) throw new Error('botão "Clique aqui para prosseguir (p)" não encontrado/visível');
    await NS.cursor.moverPara(botao);
    await dormir(150);
    const p = NS.cursor.posicao();
    const sob = p && document.elementFromPoint(p.x, p.y);
    if (!sob || !(sob === botao || botao.contains(sob))) throw new Error('o cursor não ficou sobre o botão Prosseguir — clique cancelado');
    await NS.cursor.clicar();

    let navegando = false;
    const marcar = () => { navegando = true; };
    window.addEventListener('beforeunload', marcar);
    window.addEventListener('pagehide', marcar);
    try {
      NS.dom.dispararClique(botao);
      NS.log.info('[Prosseguir] Clique realizado (único). Aguardando o retorno à página inicial...');
      await esperarOuNulo(() => navegando || !detectar(), { timeout: cfg.aguardarNavegacao, intervalo: 100, descricao: 'saída da tela de CAPTCHA' });
      return { navegou: navegando, saiuSemRecarga: !navegando && !detectar() };
    } finally {
      window.removeEventListener('beforeunload', marcar);
      window.removeEventListener('pagehide', marcar);
    }
  }

  NS.telaCaptcha = { detectar, prosseguir };
})();
