// "Nome da pasta de destino": validação (regras do Windows), criação, reaproveitamento sem
// sobrescrever, separação por CNPJ, retomada e uso pela interface e pelo terminal.

import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { test } from 'node:test';
import { fileURLToPath } from 'node:url';
import { Assistente } from '../src/assistente.js';
import { iniciarInterface } from '../src/interface/servidor.js';
import { resolverPastaDestino, validarNomePasta } from '../src/pastaDestino.js';
import { salvarListaArquivo, salvarPdf } from '../src/persistencia.js';
import { certidaoFicticia, cnpjDaVez, criarAmbiente, esperarAte, lotesEm } from './ajuda.js';

const A = '00.897.321/0001-30';
const B = '40.842.851/0001-04';
const C = '11.222.333/0001-81';
const RAIZ_PROJETO = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

async function comAmbiente(corpo) {
  const amb = await criarAmbiente();
  try {
    await corpo(amb);
  } finally {
    amb.limpar();
  }
}

const esperarVez = (cfg, documento) => esperarAte(async () => (await cnpjDaVez(cfg))?.cnpj === documento, { mensagem: `vez de ${documento}` });

// Faz o papel do Chrome + extensão para cada documento, na ordem.
async function emitirTodas(cfg, downloads, documentos) {
  for (const doc of documentos) {
    await esperarVez(cfg, doc);
    fs.writeFileSync(path.join(downloads, 'Document.pdf'), certidaoFicticia(doc));
    await esperarAte(() => !fs.existsSync(path.join(downloads, 'Document.pdf')), { mensagem: `PDF de ${doc} movido` });
  }
}

test('validação do nome: aceita nomes comuns e recusa o que o Windows não aceita', () => {
  for (const nome of ['CLIENTE PANORAMA', 'Cliente Ação 2026', 'Lote-11.2026', 'A', 'x'.repeat(100), 'CONSULTORIA', 'Com1 Filial']) {
    assert.deepEqual(validarNomePasta(nome), { ok: true, nome }, nome);
  }
  assert.deepEqual(validarNomePasta('  CLIENTE PANORAMA  '), { ok: true, nome: 'CLIENTE PANORAMA' }, 'espaços nas pontas são tirados');
  assert.deepEqual(validarNomePasta(''), { ok: true, nome: '' }, 'vazio = padrão');
  assert.deepEqual(validarNomePasta(undefined), { ok: true, nome: '' });
  for (const nome of ['a/b', 'a\\b', 'C:', 'a*b', 'a?b', 'a"b', 'a<b', 'a>b', 'a|b', 'a\tb', '.', '..', 'pasta.', 'CON', 'con', 'NUL.txt', 'COM1', 'LPT9', 'x'.repeat(101), '..\\fora', '../fora']) {
    const r = validarNomePasta(nome);
    assert.equal(r.ok, false, `deveria recusar ${JSON.stringify(nome)}`);
    assert.match(r.erro, /pasta de destino|reservado/);
  }
});

test('resolverPastaDestino: caminho completo na pasta base, sem criar nada; recusa a pasta do projeto e arquivo com o mesmo nome', () => comAmbiente(async ({ cfg, downloads }) => {
  const r = resolverPastaDestino(cfg, 'CLIENTE PANORAMA');
  assert.deepEqual(r, { nome: 'CLIENTE PANORAMA', caminho: path.join(downloads, 'CLIENTE PANORAMA'), existe: false });
  assert.equal(fs.existsSync(r.caminho), false, 'só confere, não cria');
  fs.writeFileSync(path.join(downloads, 'arquivo'), 'x');
  assert.match(resolverPastaDestino(cfg, 'arquivo').erro, /arquivo \(não uma pasta\)/);
  // Projeto dentro da pasta base (como no uso real: Downloads\Retirar_Auto_Infracao).
  const cfgProjetoEmDownloads = { ...cfg, raiz: path.join(downloads, 'Retirar_Auto_Infracao') };
  assert.match(resolverPastaDestino(cfgProjetoEmDownloads, 'Retirar_Auto_Infracao').erro, /pasta do próprio projeto/);
  assert.match(resolverPastaDestino(cfgProjetoEmDownloads, 'retirar_auto_infracao').erro ?? 'aceito', process.platform === 'linux' ? /aceito/ : /pasta do próprio projeto/);
}));

test('várias empresas com nome de pasta: tudo em Downloads/<nome>, um PDF por CNPJ, nada em Lote_', () => comAmbiente(async ({ cfg, downloads }) => {
  salvarListaArquivo(cfg, [`${A};EMPRESA A`, `${B};EMPRESA B`, `${C};EMPRESA C`, '123.456.789-09;PESSOA FISICA'].join('\n'));
  const assistente = new Assistente(cfg);
  const logs = [];
  assistente.on('log', (l) => logs.push(l.texto));
  const execucao = assistente.executar({ nomePasta: 'CLIENTE PANORAMA' });
  const pasta = path.join(downloads, 'CLIENTE PANORAMA');
  await esperarVez(cfg, A);
  assert.ok(fs.statSync(pasta).isDirectory(), 'a pasta é criada ao iniciar, antes do primeiro PDF');
  assert.equal(assistente.snapshot().pastaLote, pasta);
  assert.equal(assistente.snapshot().nomePastaDestino, 'CLIENTE PANORAMA');
  await emitirTodas(cfg, downloads, [A, B, C, '123.456.789-09']);
  const { resultado, placar } = await execucao;
  assert.equal(resultado, 'concluido');
  assert.equal(placar.feitas, 4);
  assert.deepEqual(fs.readdirSync(pasta).sort(), [
    '00897321000130;EMPRESA A.pdf',
    '11222333000181;EMPRESA C.pdf',
    '12345678909;PESSOA FISICA.pdf',
    '40842851000104;EMPRESA B.pdf',
    'Relatorio.csv',
  ]);
  assert.deepEqual(lotesEm(cfg.raiz), [], 'nenhuma pasta Lote_ criada');
  assert.deepEqual(fs.readdirSync(downloads).sort(), ['CLIENTE PANORAMA'], 'nada solto em Downloads');
  // Cada PDF é o do CNPJ certo (o relatório aponta o arquivo dentro da pasta escolhida).
  const relatorio = fs.readFileSync(path.join(pasta, 'Relatorio.csv'), 'utf8');
  for (const chave of ['00897321000130', '40842851000104', '11222333000181', '12345678909']) {
    assert.ok(relatorio.includes(path.join(pasta, chave)), `relatório aponta ${chave} na pasta escolhida`);
  }
  assert.ok(logs.some((t) => t.includes(`Pasta de destino: ${pasta} (criada agora)`)));
  assert.ok(logs.some((t) => t.includes(`PDFs deste lote: ${pasta}`)));
}));

test('pasta que já existe é reaproveitada: nada é apagado nem sobrescrito', () => comAmbiente(async ({ cfg, downloads }) => {
  const pasta = path.join(downloads, 'CLIENTE PANORAMA');
  fs.mkdirSync(path.join(pasta, 'subpasta antiga'), { recursive: true });
  const antigos = {
    '00897321000130;EMPRESA A.pdf': 'pdf antigo de A',
    'Relatorio.csv': 'relatorio antigo',
    'anotacoes.txt': 'nao mexer',
    'subpasta antiga/x.txt': 'nao mexer 2',
  };
  for (const [nome, conteudo] of Object.entries(antigos)) fs.writeFileSync(path.join(pasta, nome), conteudo);
  // Certidão "antiga": mais velha que o lote, não pode contar como já emitida.
  const passado = new Date(Date.now() - 86_400_000);
  fs.utimesSync(path.join(pasta, '00897321000130;EMPRESA A.pdf'), passado, passado);

  salvarListaArquivo(cfg, `${A};EMPRESA A\n${B};EMPRESA B`);
  const assistente = new Assistente(cfg);
  const logs = [];
  assistente.on('log', (l) => logs.push(l.texto));
  const execucao = assistente.executar({ nomePasta: 'CLIENTE PANORAMA' });
  await emitirTodas(cfg, downloads, [A, B]);
  assert.equal((await execucao).resultado, 'concluido');

  for (const [nome, conteudo] of Object.entries(antigos)) assert.equal(fs.readFileSync(path.join(pasta, nome), 'utf8'), conteudo, `${nome} intacto`);
  assert.ok(fs.existsSync(path.join(pasta, '00897321000130;EMPRESA A (2).pdf')), 'o PDF novo ganha (2)');
  assert.ok(fs.existsSync(path.join(pasta, '40842851000104;EMPRESA B.pdf')));
  assert.ok(fs.existsSync(path.join(pasta, 'Relatorio (2).csv')), 'o relatório novo ganha (2)');
  assert.ok(logs.some((t) => t.includes('já existia: será reaproveitada')));
}));

test('nome inválido: recusado antes de processar, nada criado e lista mantida', () => comAmbiente(async ({ cfg, downloads }) => {
  salvarListaArquivo(cfg, `${A};EMPRESA A`);
  fs.writeFileSync(path.join(downloads, 'Document.pdf'), certidaoFicticia(A));
  for (const nome of ['CLIENTE/PANORAMA', 'CON', 'pasta.', 'a:b']) {
    await assert.rejects(() => new Assistente(cfg).executar({ nomePasta: nome }), /pasta de destino|reservado/);
  }
  assert.deepEqual(fs.readdirSync(downloads), ['Document.pdf'], 'nada criado e o PDF de Downloads não foi mexido');
  assert.equal(fs.existsSync(cfg.arquivoControle), false);
  assert.deepEqual(lotesEm(cfg.raiz), []);
  assert.ok(fs.readFileSync(cfg.arquivoLista, 'utf8').includes(A));
}));

test('parar e continuar: a retomada segue na mesma pasta de destino, mesmo sem repetir o nome', () => comAmbiente(async ({ cfg, downloads }) => {
  salvarListaArquivo(cfg, `${A};EMPRESA A\n${B};EMPRESA B`);
  const pasta = path.join(downloads, 'CLIENTE PANORAMA');
  const primeira = new Assistente(cfg);
  const execucao = primeira.executar({ nomePasta: 'CLIENTE PANORAMA' });
  await emitirTodas(cfg, downloads, [A]);
  await esperarVez(cfg, B);
  primeira.enviarComando('s');
  assert.equal((await execucao).resultado, 'parado');
  assert.equal(primeira.snapshot().nomePastaDestino, 'CLIENTE PANORAMA', 'a interface reabre com o nome');

  const outra = new Assistente(cfg);
  const retomada = outra.executar(); // sem nome: continua no lote em andamento
  await emitirTodas(cfg, downloads, [B]);
  assert.equal((await retomada).resultado, 'concluido');
  assert.deepEqual(fs.readdirSync(pasta).sort(), ['00897321000130;EMPRESA A.pdf', '40842851000104;EMPRESA B.pdf', 'Relatorio.csv']);
  assert.deepEqual(lotesEm(cfg.raiz), []);
}));

test('organizar Downloads com nome de pasta: certidões vão para a pasta escolhida', () => comAmbiente(async ({ cfg, downloads }) => {
  salvarListaArquivo(cfg, `${A};EMPRESA A\n${B};EMPRESA B`);
  fs.writeFileSync(path.join(downloads, 'Document.pdf'), certidaoFicticia(A));
  const { resultado } = await new Assistente(cfg).executar({ organizar: true, nomePasta: 'ORGANIZADAS' });
  assert.equal(resultado, 'organizado');
  assert.deepEqual(fs.readdirSync(path.join(downloads, 'ORGANIZADAS')), ['00897321000130;EMPRESA A.pdf']);
}));

test('trava: salvarPdf nunca grava fora da pasta, nem com nome de empresa "malicioso"', () => comAmbiente(async ({ downloads }) => {
  const pasta = path.join(downloads, 'DESTINO');
  const arquivo = salvarPdf(pasta, { chave: '00897321000130', documento: A, nome: '..\\..\\fora/../x' }, Buffer.from('%PDF'));
  assert.equal(path.dirname(arquivo), pasta);
}));

test('interface: prévia do caminho, validação no Iniciar e execução completa na pasta escolhida', async () => {
  const amb = await criarAmbiente();
  const ui = await iniciarInterface({ cfg: amb.cfg, porta: 0, abrirPasta: () => {} });
  const api = async (rota, corpo) => {
    const r = await fetch(ui.url.replace(/\/$/, '') + rota, { method: corpo === undefined ? 'GET' : 'POST', headers: { 'Content-Type': 'application/json', 'X-Token': ui.token }, body: corpo === undefined ? undefined : JSON.stringify(corpo) });
    return { status: r.status, dados: await r.json() };
  };
  try {
    const { cfg, downloads } = amb;
    const html = await (await fetch(ui.url)).text();
    assert.ok(html.includes('Nome da pasta de destino') && html.includes('id="pasta-destino"'), 'campo na página');

    const nova = (await api('/api/pasta-destino', { nome: 'CLIENTE PANORAMA' })).dados;
    assert.deepEqual([nova.ok, nova.caminho, nova.existe, nova.padrao], [true, path.join(downloads, 'CLIENTE PANORAMA'), false, false]);
    const padrao = (await api('/api/pasta-destino', { nome: '' })).dados;
    assert.equal(padrao.padrao, true);
    assert.match(path.basename(padrao.caminho), /^Lote_/);
    const ruim = (await api('/api/pasta-destino', { nome: 'a|b' })).dados;
    assert.equal(ruim.ok, false);
    assert.match(ruim.erro, /não pode ter "\|"/);

    // Iniciar com nome inválido: 400, nada roda, nada é criado.
    const recusado = await api('/api/iniciar', { texto: `${A};EMPRESA A`, nomePasta: 'LPT1' });
    assert.equal(recusado.status, 400);
    assert.match(recusado.dados.erro, /reservado/);
    assert.equal((await api('/api/estado')).dados.fase, 'ocioso');
    assert.deepEqual(fs.readdirSync(downloads), []);
    assert.equal((await api('/api/organizar', { texto: `${A};EMPRESA A`, nomePasta: 'a?b' })).status, 400);

    // Nome válido: roda e tudo vai para a pasta.
    assert.equal((await api('/api/iniciar', { texto: `${A};EMPRESA A\n${B};EMPRESA B`, nomePasta: '  CLIENTE PANORAMA ' })).status, 200);
    await esperarVez(cfg, A);
    const durante = (await api('/api/estado')).dados;
    assert.equal(durante.pastaLote, path.join(downloads, 'CLIENTE PANORAMA'));
    assert.equal(durante.nomePastaDestino, 'CLIENTE PANORAMA');
    await emitirTodas(cfg, downloads, [A, B]);
    await esperarAte(async () => (await api('/api/estado')).dados.fase === 'ocioso', { mensagem: 'fim' });
    const fim = (await api('/api/estado')).dados;
    assert.equal(fim.pastaLote, path.join(downloads, 'CLIENTE PANORAMA'));
    assert.ok(fs.existsSync(path.join(downloads, 'CLIENTE PANORAMA', '40842851000104;EMPRESA B.pdf')));

    const existente = (await api('/api/pasta-destino', { nome: 'CLIENTE PANORAMA' })).dados;
    assert.equal(existente.existe, true, 'depois de criada, a prévia avisa que será reaproveitada');
  } finally {
    await ui.fechar();
    amb.limpar();
  }
});

test('terminal: --pasta inválido é recusado com mensagem clara antes de processar', () => comAmbiente(async ({ base, cfg, downloads }) => {
  const rodar = (...args) => spawnSync(process.execPath, [path.join(RAIZ_PROJETO, 'src', 'cli.js'), ...args], {
    env: { ...process.env, PASTA_DOWNLOADS: downloads, ASSISTENTE_TESTE: '1' }, encoding: 'utf8', input: '', timeout: 20000,
  });
  const ruim = rodar('--pasta', 'CLIENTE*PANORAMA');
  assert.equal(ruim.status, 1);
  assert.match(ruim.stderr, /não pode ter "\*"/);
  const semNome = rodar('--pasta');
  assert.equal(semNome.status, 1);
  assert.match(semNome.stderr, /Informe o nome da pasta/);
  assert.deepEqual(fs.readdirSync(downloads), []);
  assert.ok(base && cfg);
}));
