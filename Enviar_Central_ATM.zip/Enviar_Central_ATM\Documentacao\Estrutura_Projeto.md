# Estrutura do pacote e da instalação

## Pacote (`Enviar_Central_ATM`)

```
Enviar_Central_ATM\
├── README_INSTALACAO_COMPLETA.md        manual completo (para pessoas e para o Claude do destino)
├── INSTALAR.cmd                          dois cliques: instala tudo
├── VERIFICAR.cmd                         dois cliques: confere (só lê)
│
├── Central_de_Automacoes\                a Central (versão portátil)
│   ├── Central.ps1                       programa (WinForms); %CENTRAL_ATM% = pasta de instalação
│   ├── Abrir Central.vbs                 abre sem janela do PowerShell (alvo do atalho)
│   ├── automacoes.json                   lista de automações (configuração)
│   ├── ajuda.json                        textos do botão "?" (recursos)
│   ├── LEIA-ME.txt
│   └── README.md
│
├── Automacoes\                           uma pasta por automação, completa
│   ├── Retirar_Auto_Infracao\            Node.js: src\, extensao-chrome\, tests\, package.json/lock, ABRIR_INTERFACE.cmd
│   ├── ATM_RFB\                          Node.js + Python: certidao-rfb.js, interface\, ferramentas\, extensao-chrome\,
│   │                                     package.json/lock, requirements.txt, instalar.ps1, INTERFACE RFB EMISSAO.cmd
│   ├── Auto_PGFN\                        Automacao_PGFN.exe, Automação_PGFN\ (extensão), orquestrador\,
│   │                                     ajudante_salvar_como\, interface\ (fonte C#), instalacao\, INSTALAR.bat
│   ├── Situacao_Fiscal\                  Situacao_Fiscal\ (extensão), ferramentas\, README_projeto.md, COMO_FUNCIONA.html
│   ├── Parcelamento_Simplificado\        parcelamento_simplificado\ (extensão), README.md
│   └── Regularidade_Fiscal_PE\           regularidade_fiscal_pe\ (extensão + painel\ + src\ + testes\)
│
├── Dependencias\LEIA-ME.md               o que é baixado na instalação (nada binário vai no pacote)
├── Instalacao\
│   ├── instalar.ps1                      instalação completa (7 etapas, com registro)
│   ├── verificar_ambiente.ps1            conferência (requisitos, cópias, dependências, extensões, Central)
│   ├── configurar_central.ps1            atalho, Unblock-File, conferência -Validar
│   └── comum.ps1                         funções e catálogo usados pelos três
└── Documentacao\
    ├── Inventario_Automacoes.md
    ├── Estrutura_Projeto.md              este arquivo
    ├── Requisitos_Sistema.md
    └── Solucao_Problemas.md
```

Por que a Central não foi dividida em `Codigo_Fonte\`, `Recursos\` e `Configuracoes\`: o `Central.ps1` procura
`automacoes.json`, `ajuda.json` e `preferencias.json` na **própria pasta**, e o atalho abre o `.vbs` ao lado dele.
Separar exigiria mudar o programa; manter os 5 arquivos juntos preserva o funcionamento original.

## Instalação (no computador de destino)

```
%USERPROFILE%\Central_ATM\                 (-Destino; pode ser outra pasta)
├── Central_de_Automacoes\                 + preferencias.json, central_erros.log (criados em uso)
├── Automacoes\<5 automações>\             + node_modules (Retirar, ATM RFB) e .venv (ATM RFB)
├── _backup_central_<data>\                (só em reinstalações)
└── instalacao_ultima.txt

%USERPROFILE%\Downloads\Auto_PGFN\         PGFN (lugar fixo)
%USERPROFILE%\Downloads\<pastas de resultado>\   criadas pelas automações
Área de Trabalho\Central de Automações.lnk
HKCU\Software\Google\Chrome\NativeMessagingHosts\com.auto_pgfn.salvar_como   (ajudante da PGFN)
```

## Como a Central resolve os caminhos

`Central.ps1` → `Expandir()`:
1. troca `%CENTRAL_ATM%` pela pasta-mãe de `Central_de_Automacoes`;
2. expande as variáveis do Windows (`%USERPROFILE%` etc.).

Para acrescentar uma automação: copie a pasta para `Automacoes\<Nome>` e acrescente um item em `automacoes.json`
(campos `nome`, `categoria`, `icone`, `descricao`, `tipo`, `arquivo`/`url`, `pasta`, `argumentos`, `extensao`, `dica`
e, para Chrome, `anonima`/`painel`) e, se quiser o "?", um item com o **mesmo nome** em `ajuda.json`.
