@echo off
rem Abre a INTERFACE RFB EMISSAO (painel de controle da automacao) no Windows. Dois cliques neste arquivo.
rem Deixe esta janela aberta enquanto usa a interface. Para encerrar: Ctrl+C.
chcp 65001 >nul
title INTERFACE RFB - NAO FECHE ESTA JANELA (pode minimizar)
cd /d "%~dp0"

if not exist "node_modules\pdfjs-dist" goto instalar
if not exist ".venv\Scripts\python.exe" goto instalar
goto abrir

:instalar
echo Primeira vez neste computador: instalando o que falta (precisa de internet)...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalar.ps1" -SemPerguntas
if errorlevel 1 (
  echo.
  echo Algo faltou. Veja a mensagem acima.
  pause
  exit /b 1
)
echo.

:abrir
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js nao encontrado. Rode instalar.cmd
  pause
  exit /b 1
)
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
echo ============================================================
echo  NAO FECHE ESTA JANELA enquanto usa o painel (pode minimizar).
echo  Se fechar, o painel mostra "Sem conexao" e para de funcionar.
echo ============================================================
node interface\servidor.js
pause
