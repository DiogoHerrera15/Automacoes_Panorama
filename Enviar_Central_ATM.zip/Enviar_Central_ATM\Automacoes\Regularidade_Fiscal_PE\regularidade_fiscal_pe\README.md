# EFisco_PE_Certidao_Regularidade_Fiscal — v0.7.0

Extensão Chrome (Manifest V3) que emite, em lote, Certidões de Regularidade Fiscal no e-Fisco da SEFAZ-PE
para **CPF, CNPJ e Inscrição Estadual**, a partir de um painel próprio.

## Usar
0. **Uma vez só**: `chrome://extensions` → **Detalhes** da extensão → ative **"Permitir no modo anônimo"**. Sem isso o
   Chrome não deixa a extensão rodar em janela anônima e a automação **não inicia** (o painel avisa e tem um botão que
   abre essa página de configurações).
1. `chrome://extensions` → **Recarregar** (v0.7.0). Clique no **ícone da extensão**: o painel abre em uma aba própria.
2. Informe o **Nome da pasta** e cole os **documentos** (um por linha). A extensão identifica o tipo, valida e mostra a
   lista; corrija o tipo na tabela se quiser.
3. **INICIAR AUTOMAÇÃO**: ela abre o e-Fisco **sempre em uma janela anônima** e processa um documento por vez. Use PAUSAR/CONTINUAR e PARAR.

## Janela anônima (sempre)
- Toda execução abre uma **janela anônima nova** com o e-Fisco; nunca usa aba comum, nem reaproveita uma aba aberta do
  site. Os documentos seguintes reutilizam a mesma janela anônima. Se ela falhar ao abrir, a fila **pausa** com a causa
  (não cai para aba comum).
- Sessão anônima = cookies separados da janela comum; a página de emissão abre sem login gov.br.
- O PDF por URL é buscado **de dentro da página anônima** (o background usa os cookies da janela comum e não enxergaria
  essa sessão). Já o download iniciado pelo próprio site é tratado normalmente.
- Os PDFs continuam sendo salvos em `Downloads/<pasta>` (o modo anônimo não muda o destino).

## Regras importantes
- **Pasta**: o Chrome só grava dentro de *Downloads*. Os arquivos vão para `Downloads/<NOME DA PASTA>` (criada no
  primeiro arquivo; se já existir é reutilizada; nada é sobrescrito: repetidos viram "(1)", "(2)"...).
- **Arquivos**: `CNPJ_11222333000181_CERTIDAO.pdf`, `CPF_..._CERTIDAO.pdf`, `IE_..._CERTIDAO.pdf`; com a razão social só
  quando o sistema a informa (`EMPRESA_X_CNPJ_....pdf`). Só conta como emitido se o download terminou e é PDF.
- **CAPTCHA**: nunca é resolvido nem contornado. Se aparecer, a execução pausa e pede ação humana. "Prosseguir" só volta
  à tela anterior; depois dele é exigida uma verificação NOVA. Falhas repetidas param o documento (máx. 3 tentativas).
- **Tipos**: 11 dígitos → CPF; 14 dígitos com DV de CNPJ válido → CNPJ; 9 dígitos → IE de PE. Outros tamanhos ou 14
  dígitos que não são CNPJ ficam **ambíguos** (você escolhe o tipo). Documentos com DV inválido não rodam, a menos que
  marque "processar mesmo assim".
- **Localizar (l)** é clicado uma única vez por documento (guarda anti-cliques repetidos / Enter / atalhos).
- **Confirmações do site** após Emitir **não** são clicadas (`entrega.confirmacaoAutomatica = false`): a extensão
  pausa a espera e avisa para você confirmar. Ver "O que ainda precisa ser validado".

## Estrutura
`background.js` + `src/fila.js` (fila, tentativas, pausa/parada, downloads) · `painel/` (interface) ·
`src/lista.js` `src/documento.js` `src/arquivos.js` (classificação, validação, nomes) · content scripts no e-Fisco:
`main.js` (fluxo de 1 documento), `campo-*.js`, `aviso.js`, `cloudflare.js`, `botao-localizar.js`, `tela-captcha.js`,
`resultado.js`, `botao-emitir.js`, `observador.js`, `entrega.js`, `job.js`, `guarda-localizar.js`, `cursor.js`.

## Testes
`node testes/unit.js` · `node testes/fila.test.js` · `node testes/background.test.js` ·
página simulada `testes/mock/efisco-mock.html` + `testes/e2e-loader.js` · painel `testes/painel-teste.html`
(todos via `python3 -m http.server` na raiz). Veja o relatório da entrega para o que foi e o que não foi validado.
