// Pasta de destino escolhida pela pessoa ("Nome da pasta de destino" na interface, --pasta no
// terminal). Com nome, os PDFs da execução vão para <pasta base>/<nome> (a pasta base é a de
// Downloads, ou PASTA_BASE_DESTINO); sem nome, vale o de sempre: Lote_AAAA-MM-DD_HHhMM na
// pasta do projeto. A pasta é criada se não existir e reaproveitada (sem apagar nada) se existir.

import fs from 'node:fs';
import path from 'node:path';

export const LIMITE_NOME_PASTA = 100;

// Caracteres que o Windows não aceita em nome de pasta (e a barra, que também separa pastas no Mac).
const PROIBIDOS = /[<>:"/\\|?*\u0000-\u001F]/;
// Nomes reservados do Windows, sozinhos ou com extensão ("CON", "nul.txt", "COM1"...).
const RESERVADOS = /^(CON|PRN|AUX|NUL|COM[0-9¹²³]|LPT[0-9¹²³])(\..*)?$/i;

// Confere o nome digitado. Devolve { ok: true, nome } (nome '' = usar o padrão) ou
// { ok: false, erro }. Não mexe no disco.
export function validarNomePasta(valor) {
  const nome = String(valor ?? '').normalize('NFC').trim();
  if (!nome) return { ok: true, nome: '' };
  if (nome.length > LIMITE_NOME_PASTA) return { ok: false, erro: `O nome da pasta de destino pode ter no máximo ${LIMITE_NOME_PASTA} caracteres (tem ${nome.length}).` };
  const proibido = nome.match(PROIBIDOS);
  if (proibido) {
    const mostrado = proibido[0] < ' ' ? 'caractere de controle' : `"${proibido[0]}"`;
    return { ok: false, erro: `O nome da pasta de destino não pode ter ${mostrado}. Caracteres não permitidos no Windows: \\ / : * ? " < > |` };
  }
  if (/^\.+$/.test(nome)) return { ok: false, erro: 'O nome da pasta de destino não pode ser só pontos.' };
  if (/[. ]$/.test(nome)) return { ok: false, erro: 'O nome da pasta de destino não pode terminar com ponto ou espaço (o Windows não aceita).' };
  if (RESERVADOS.test(nome)) return { ok: false, erro: `"${nome}" é um nome reservado do Windows. Escolha outro nome para a pasta de destino.` };
  return { ok: true, nome };
}

const mesmoCaminho = (a, b) => {
  const ra = path.resolve(a);
  const rb = path.resolve(b);
  return process.platform === 'win32' || process.platform === 'darwin' ? ra.toLowerCase() === rb.toLowerCase() : ra === rb;
};

// true se `alvo` é a própria `pasta` ou está dentro dela.
export function dentroDe(pasta, alvo) {
  const relativo = path.relative(path.resolve(pasta), path.resolve(alvo));
  return relativo === '' || (!relativo.startsWith('..') && !path.isAbsolute(relativo));
}

// Caminho completo da pasta de destino para o nome informado, já validado. Devolve
// { nome, caminho, existe } ou { erro }. Não cria nada.
export function resolverPastaDestino(cfg, valor) {
  const validacao = validarNomePasta(valor);
  if (!validacao.ok) return { erro: validacao.erro };
  const { nome } = validacao;
  if (!nome) return { nome: '', caminho: '', existe: false };
  const base = path.resolve(cfg.pastaBaseDestino);
  const caminho = path.join(base, nome);
  // Pela validação acima isso nunca acontece; fica como trava contra salvar fora da pasta base.
  if (path.dirname(caminho) !== base) return { erro: 'O nome da pasta de destino não pode apontar para outra pasta.' };
  if (mesmoCaminho(caminho, cfg.raiz) || dentroDe(caminho, cfg.raiz)) {
    return { erro: `"${nome}" é a pasta do próprio projeto. Escolha outro nome para a pasta de destino.` };
  }
  let existe = false;
  try {
    const info = fs.statSync(caminho);
    if (!info.isDirectory()) return { erro: `Já existe um arquivo (não uma pasta) chamado "${nome}" em ${base}. Escolha outro nome.` };
    existe = true;
  } catch (e) {
    if (e.code !== 'ENOENT') return { erro: `Não consegui verificar a pasta ${caminho}: ${e.message}` };
  }
  return { nome, caminho, existe };
}
