/* Configuração central. Tudo que pode mudar entre fases fica aqui. */
(function () {
  'use strict';
  const NS = (window.EFiscoCRF = window.EFiscoCRF || {});

  NS.CONFIG = {
    // CNPJ de teste (somente dígitos). Pode ser sobrescrito pelo popup (chrome.storage).
    // Fase futura: este valor será substituído por uma lista de CNPJs.
    cnpjTeste: '11222333000181',

    // Tipo de documento usado nesta fase (texto da opção no <select>, sem acento/caixa).
    tipoDocumento: 'CNPJ',

    // Endereço da funcionalidade (documentação; a extensão atua em qualquer página de efisco.sefaz.pe.gov.br
    // cujo conteúdo seja a Emissão de CRF).
    urlSistema: 'https://efisco.sefaz.pe.gov.br/sfi_trb_gcc/PREmitirCertidaoRegularidadeFiscalMovel',

    storage: {
      cnpj: 'efisco_cnpj',
      log: 'efisco_log',
      resultado: 'efisco_resultado',
      estado: 'efisco_estado',            // fase em andamento (retomada após recarga de página)
      eventos: 'efisco_eventos',          // abas/janelas/downloads observados (background.js)
      velMouse: 'efisco_vel_mouse',       // multiplicador escolhido no popup
      velDigitacao: 'efisco_vel_digitacao'
    },

    // ───────── VELOCIDADE ─────────
    // Multiplicadores globais (1 = padrão; >1 = mais lento; <1 = mais rápido). O popup pode sobrepô-los.
    // Ajustes finos estão nos blocos "cursor" e "digitacao" abaixo.
    velocidade: { mouse: 1.0, digitacao: 1.0 },

    // Identificação da página. O endereço exato é conferido por host; a página certa é
    // reconhecida pelo CONTEÚDO (título + rótulos), nunca só pela URL.
    pagina: {
      hosts: ['efisco.sefaz.pe.gov.br'],
      // Trecho de caminho que costuma indicar a funcionalidade (usado só para a execução automática).
      caminhoProvavel: 'certidaoregularidadefiscal',
      titulo: 'emissao de certidao de regularidade fiscal',
      rotuloTipo: 'tipo de documento de identificacao',
      rotuloNumero: 'numero do documento de identificacao',
      // Texto do botão usado para reconhecer a página.
      botaoLocalizar: 'localizar'
    },

    // Aviso inicial (modal "Atenção! Extrato Fronteiras ... Fechar").
    aviso: {
      textosDoAviso: ['extrato fronteiras', 'atencao'], // basta um aparecer no contêiner
      textoBotao: 'fechar',
      janelaDeteccao: 4500,   // ms — quanto esperar o aviso aparecer antes de concluir que não há
      tentativasFechar: 3
    },

    // Ids reais conferidos no DOM do e-Fisco. Se não forem encontrados (layout mudou),
    // os campos são localizados pelo rótulo visível.
    seletores: {
      tipoDocumento: '#tpDocumentoIdentificacaoCertidaoRegularidade',
      numeroDocumento: '#NuDocumentoIdentificacaoCertidaoRegularidade'
    },

    // ───────── Fase 2 ─────────
    // Verificação Cloudflare (Turnstile). A automação NUNCA interage com ela: apenas LÊ se já foi concluída
    // (token no campo cf-turnstile-response), aguarda um tempo limitado e, se precisar de humano, pausa e avisa.
    cloudflare: {
      processamento: 15000,   // ms aguardando a verificação concluir sozinha
      esperaHumana: 180000,   // ms aguardando o usuário concluir uma verificação interativa
      lembreteACada: 20000,   // ms entre lembretes no registro
      pausaAposLiberar: [600, 1200]
    },

    // Botão Localizar (l): clicado UMA vez, de propósito, com autorização temporária da guarda.
    // No e-Fisco é um submit de formulário: a página recarrega e a execução é retomada na página nova.
    localizar: {
      seletor: '#btt_localizar',
      texto: 'localizar',
      aguardarNavegacao: 4000,  // ms para perceber se o clique causou recarga/alteração
      aguardarRecarga: 30000    // ms de espera (página sendo substituída) antes de considerar falha
    },

    // Tela intermediária "Não foi possível concluir a verificação de segurança (CAPTCHA)".
    // O botão "Clique aqui para prosseguir (p)" apenas VOLTA à tela anterior: NÃO resolve o CAPTCHA.
    // Depois de voltar, a extensão exige uma verificação NOVA e concluída (ou deixa o usuário concluir).
    telaCaptcha: {
      frases: ['nao foi possivel concluir a verificacao de seguranca'],
      textoBotao: 'clique aqui para prosseguir',
      maxCiclos: 1,             // quantas vezes volta pelo "Prosseguir"; depois PARA e pede ação humana
      aguardarNavegacao: 4000
    },

    // Tabela "Resultado da consulta" (usada se o Localizar devolver registros)
    resultado: {
      seletorTabela: '#table_tabeladados',
      timeout: 12000,           // ms aguardando linhas ou mensagem na página que volta do Localizar
      estabilidade: 800,
      permitirMultiplos: false, // vários registros com o MESMO CNPJ: interrompe para análise
      colunas: { cnpj: 'cnpj/cpf', ie: 'i. estadual', nome: 'nome/razao social', irregularidade: 'irregularidade', selecao: 'x' }
    },

    // Botão Emitir (e) — identificado pelo id real (#btt_emitir) e conferido.
    // (antes: o ÚNICO botão acionado) Identificado pelo id real (#btt_emitir) e conferido
    // (texto "Emitir", tipo button, nunca "Localizar"). Clica UMA vez e observa; confirmações NÃO são acionadas.
    emitir: {
      seletor: '#btt_emitir',
      texto: 'emitir',
      acao: 'clicar'            // 'clicar' | 'posicionar' (só leva o cursor, sem clicar)
    },

    // Observação do que acontece após o clique em Emitir
    observacao: {
      janela: 15000,            // ms observando
      intervalo: 400,
      estabilizar: 2000         // ms sem novas mudanças após detectar algo
    },

    // Retomada após recarga de página (estado gravado em chrome.storage)
    retomada: { validadeMs: 180000, maxRetomadas: 2 },

    // "Pensar" entre uma etapa e outra (ms, sorteado a cada vez).
    pausaEntreEtapas: [600, 1300],

    timeouts: {
      paginaPronta: 20000,
      elemento: 10000,
      habilitar: 8000,      // espera o campo número habilitar após escolher o tipo
      confirmacao: 2500
    },

    tentativas: {
      localizar: 3,         // novas verificações antes de declarar "não encontrado"
      selecionar: 2,
      preencher: 3,
      intervalo: 600        // ms entre tentativas
    },

    // Cursor visual — movimento suave (curva + aceleração/desaceleração), moderadamente lento.
    // fatorVelocidade > 1 deixa mais lento; duracaoMin/Max limitam cada deslocamento.
    cursor: {
      duracaoMin: 600,       // ms — duração mínima de um movimento
      duracaoMax: 1900,      // ms — duração máxima
      fatorVelocidade: 1.15,
      tremor: 1.1,           // px — micro-oscilação durante o trajeto (some ao chegar)
      overshoot: 0.4,        // chance de passar um pouco do alvo e corrigir em trajetos longos
      pausaAntesClique: 300,
      pausaDepoisClique: 340
    },

    // Digitação com ritmo humano: intervalo variável entre teclas, pausas por grupo e hesitações ocasionais.
    digitacao: {
      atrasoMedio: 140,      // ms entre teclas (mediana; varia a cada tecla)
      atrasoMin: 75,
      atrasoMax: 380,
      fatorVelocidade: 1.0,
      pausaInicial: [420, 800],
      pausaGrupo: [180, 420],
      chanceHesitacao: 0.08,
      pausaHesitacao: [480, 900],
      pausaFinal: [350, 700]
    },

    // Fila de documentos (controlada pelo background; estado em chrome.storage)
    fila: {
      maxTentativas: 3,            // tentativas por documento antes de marcar ERRO (nunca há ciclo infinito)
      timeoutItemMs: 240000,       // sem sinal do e-Fisco por este tempo ⇒ erro recuperável
      timeoutEntregaMs: 120000,    // Emitir clicado e nenhum arquivo entregue por este tempo ⇒ erro
      pausaEntreItensMs: 1500,
      esperaEntreTentativasMs: 3000
    },

    // Entrega da certidão (depois do clique em Emitir). O comportamento real do site ainda precisa ser confirmado:
    // a extensão detecta (1) download iniciado pelo site, (2) página/aba com PDF e (3) tela de confirmação.
    entrega: {
      timeout: 60000,              // ms aguardando o arquivo
      timeoutComHumano: 300000,    // ms se o site pedir uma confirmação manual
      confirmacaoAutomatica: false // false = PAUSA e pede ao usuário para confirmar (padrão seguro)
    },

    // Esta automação clica em Localizar/Prosseguir/Emitir: por segurança NÃO executa sozinha ao abrir a página.
    // Use o botão "Executar agora" do popup (ou mude para true sob sua responsabilidade).
    autoExecutar: false
  };
})();
