/* Testes do controlador da fila com um Chrome SIMULADO (storage, tabs, downloads, fetch). Execute: node testes/fila.test.js */
'use strict';
const path = require('path');
const assert = require('assert');
global.window = global;
const raiz = path.join(__dirname, '..');
['config', 'documento', 'arquivos'].forEach((m) => require(path.join(raiz, 'src', `${m}.js`)));
const { criarFila } = require(path.join(raiz, 'src', 'fila.js'));
const NS = global.EFiscoCRF;
NS.CONFIG.fila = { ...NS.CONFIG.fila, pausaEntreItensMs: 1, esperaEntreTentativasMs: 1 };

const PDF = Uint8Array.from(Buffer.from('%PDF-1.4\n' + 'conteudo '.repeat(100) + '\n%%EOF'));
const HTML = Uint8Array.from(Buffer.from('<html>' + 'erro '.repeat(100)));
const esperar = (ms = 25) => new Promise((r) => setTimeout(r, ms));

function ambiente({ fetchBytes = PDF, fetchOk = true, fileSize = 5000, mime = 'application/pdf', exists = true, anonimo = true, janelaFalha = false, abaComum = false } = {}) {
  const mem = {};
  const reg = { tabsCriadas: [], janelas: [], navegacoes: [], downloads: [], tabsRemovidas: [], alarmes: [] };
  let tempo = 1000000; let nextTab = 10; let nextDl = 100;
  const abas = new Set();
  const dls = {};
  const api = {
    storage: {
      get: async (k) => { const ks = Array.isArray(k) ? k : [k]; const o = {}; ks.forEach((x) => { if (x in mem) o[x] = JSON.parse(JSON.stringify(mem[x])); }); return o; },
      set: async (o) => { Object.entries(o).forEach(([k, v]) => { mem[k] = JSON.parse(JSON.stringify(v)); }); },
      remove: async (k) => { (Array.isArray(k) ? k : [k]).forEach((x) => delete mem[x]); }
    },
    incognitoPermitido: async () => anonimo,
    windows: {
      create: async (o) => { if (janelaFalha) throw new Error('bloqueado por política'); const id = nextTab++; abas.add(id); reg.janelas.push({ url: o.url, incognito: o.incognito }); return { id: 1000 + id, tabs: [{ id }] }; }
    },
    tabs: {
      get: async (id) => { if (!abas.has(id)) throw new Error('No tab'); return { id, incognito: !(abaComum && id === 777) }; },
      query: async () => [{ id: 777, incognito: false }, ...[...abas].map((id) => ({ id, incognito: true }))],
      create: async (o) => { reg.tabsCriadas.push(o.url); return { id: nextTab++ }; },
      update: async (id, o) => { reg.navegacoes.push(o.url); return { id }; },
      remove: async (id) => { reg.tabsRemovidas.push(id); abas.delete(id); }
    },
    downloads: {
      download: async (o) => { const id = nextDl++; dls[id] = { id, state: 'in_progress', filename: '/Users/x/Downloads/' + o.filename, mime, fileSize, exists }; reg.downloads.push(o); return id; },
      search: async ({ id }) => [dls[id]].filter(Boolean)
    },
    alarms: { create: async (n) => reg.alarmes.push(n), clear: async () => {} },
    fetch: async () => ({ ok: fetchOk, status: fetchOk ? 200 : 503, arrayBuffer: async () => fetchBytes.buffer.slice(fetchBytes.byteOffset, fetchBytes.byteOffset + fetchBytes.byteLength) }),
    agora: () => tempo, espera: async () => {}
  };
  return { api, mem, reg, dls, abas, avancarTempo: (ms) => { tempo += ms; }, fila: criarFila(api) };
}
const ITENS = [
  { id: 'L1', original: '11222333000181', tipo: 'CNPJ', digitos: '11222333000181', formatado: '11.222.333/0001-81' },
  { id: 'L2', original: '12345678909', tipo: 'CPF', digitos: '12345678909', formatado: '123.456.789-09' },
  { id: 'L3', original: '0321418-40', tipo: 'IE', digitos: '032141840', formatado: '0321418-40' }
];
const status = (E) => E.mem.efisco_job.itens.map((i) => i.status);

let ok = 0;
async function teste(nome, fn) {
  try { await fn(); ok++; console.log('  ✔', nome); } catch (e) { console.error('  ✘', nome, '\n     ', e.stack.split('\n').slice(0, 3).join('\n      ')); process.exitCode = 1; }
}

(async () => {
  console.log('Início e validação');
  await teste('rejeita pasta vazia/inválida e lista vazia; não inicia duas execuções', async () => {
    const E = ambiente();
    assert.ok(!(await E.fila.iniciar({ pasta: '  ', itens: ITENS })).ok);
    assert.ok(!(await E.fila.iniciar({ pasta: 'P', itens: [] })).ok);
    assert.ok((await E.fila.iniciar({ pasta: 'P', itens: ITENS })).ok);
    assert.ok(!(await E.fila.iniciar({ pasta: 'P', itens: ITENS })).ok);
  });
  await teste('inicia: abre o e-Fisco na página de emissão e coloca o 1º documento em processamento (sem tocar nos demais)', async () => {
    const E = ambiente();
    await E.fila.iniciar({ pasta: 'CERTIDOES_SEFAZ_NOVEMBRO_2026', itens: ITENS });
    assert.deepStrictEqual(E.reg.janelas, [{ url: NS.CONFIG.urlSistema, incognito: true }]);
    assert.strictEqual(E.reg.tabsCriadas.length, 0, 'nunca cria aba comum');
    assert.deepStrictEqual(status(E), ['processando', 'pendente', 'pendente']);
    assert.strictEqual(E.mem.efisco_job.pasta, 'CERTIDOES_SEFAZ_NOVEMBRO_2026');
    assert.strictEqual(E.mem.efisco_job.itens[0].tentativas, 1);
  });
  await teste('HELLO: só a aba do job recebe o documento atual', async () => {
    const E = ambiente(); await E.fila.iniciar({ pasta: 'P', itens: ITENS });
    const tab = E.mem.efisco_job.tabId;
    assert.strictEqual(await E.fila.aoHello(999), null);
    const h = await E.fila.aoHello(tab);
    assert.strictEqual(h.item.id, 'L1'); assert.strictEqual(h.item.tipo, 'CNPJ'); assert.strictEqual(h.pasta, 'P');
  });

  console.log('Janela anônima (sempre)');
  await teste('sem permissão para o modo anônimo: NÃO inicia e explica o que ativar (não abre aba comum)', async () => {
    const E = ambiente({ anonimo: false });
    const r = await E.fila.iniciar({ pasta: 'P', itens: ITENS });
    assert.ok(!r.ok); assert.strictEqual(r.codigo, 'incognito-nao-permitido'); assert.match(r.erro, /Permitir no modo an[ôo]nimo/);
    assert.strictEqual(E.reg.janelas.length, 0); assert.strictEqual(E.reg.tabsCriadas.length, 0); assert.strictEqual(E.mem.efisco_job, undefined);
  });
  await teste('falha ao abrir a janela anônima: pausa com a causa; NÃO recorre a aba comum nem gasta tentativa', async () => {
    const E = ambiente({ janelaFalha: true });
    await E.fila.iniciar({ pasta: 'P', itens: ITENS });
    assert.strictEqual(E.mem.efisco_job.estado, 'pausado'); assert.match(E.mem.efisco_job.motivoPausa, /janela an[ôo]nima/);
    assert.strictEqual(E.reg.tabsCriadas.length, 0); assert.strictEqual(E.mem.efisco_job.itens[0].status, 'pendente'); assert.strictEqual(E.mem.efisco_job.itens[0].tentativas, 0);
  });
  await teste('nunca reaproveita uma aba comum do e-Fisco já aberta: abre janela anônima própria', async () => {
    const E = ambiente({ abaComum: true });
    await E.fila.iniciar({ pasta: 'P', itens: ITENS });
    assert.strictEqual(E.reg.janelas.length, 1); assert.ok(E.reg.janelas[0].incognito); assert.notStrictEqual(E.mem.efisco_job.tabId, 777);
  });
  await teste('os documentos seguintes reutilizam a MESMA janela anônima (navega a aba, não abre outra)', async () => {
    const E = ambiente(); await E.fila.iniciar({ pasta: 'P', itens: ITENS });
    await E.fila.aoFinal({ itemId: 'L1', status: 'sem_certidao' }); await esperar();
    assert.strictEqual(E.reg.janelas.length, 1); assert.strictEqual(E.reg.navegacoes.length, 1);
  });
  await teste('CONTINUAR também exige a permissão do modo anônimo', async () => {
    const E = ambiente(); await E.fila.iniciar({ pasta: 'P', itens: ITENS }); await E.fila.pausar();
    E.api.incognitoPermitido = async () => false;
    const r = await E.fila.continuar(); assert.ok(!r.ok); assert.strictEqual(r.codigo, 'incognito-nao-permitido'); assert.strictEqual(E.mem.efisco_job.estado, 'pausado');
  });

  console.log('Entrega do PDF e downloads');
  await teste('PDF obtido DENTRO da janela anônima (data URL) é conferido e gravado em PASTA/NOME', async () => {
    const E = ambiente(); await E.fila.iniciar({ pasta: 'P', itens: ITENS });
    const dataUrl = NS.arquivos.paraDataUrl(PDF);
    await E.fila.aoFinal({ itemId: 'L1', status: 'entrega-pdf', dataUrl });
    assert.strictEqual(E.reg.downloads.length, 1); assert.strictEqual(E.reg.downloads[0].filename, 'P/CNPJ_11222333000181_CERTIDAO.pdf');
    E.dls[100].state = 'complete'; await E.fila.aoDownloadMudou({ id: 100, state: { current: 'complete' } }); await esperar();
    assert.strictEqual(E.mem.efisco_job.itens[0].status, 'concluido');
  });
  await teste('data URL que não é PDF → erro (nada é gravado)', async () => {
    const E = ambiente(); await E.fila.iniciar({ pasta: 'P', itens: ITENS });
    await E.fila.aoFinal({ itemId: 'L1', status: 'entrega-pdf', dataUrl: NS.arquivos.paraDataUrl(HTML, 'text/html') }); await esperar();
    assert.strictEqual(E.mem.efisco_job.itens[0].status, 'erro'); assert.strictEqual(E.reg.downloads.length, 0);
  });
  await teste('PDF por URL: baixa, valida %PDF, salva em PASTA/NOME sem sobrescrever e avança para o próximo', async () => {
    const E = ambiente(); await E.fila.iniciar({ pasta: 'MINHA_PASTA', itens: ITENS });
    await E.fila.aoFinal({ itemId: 'L1', status: 'entrega-url', urlPdf: 'https://efisco.sefaz.pe.gov.br/x.pdf' });
    assert.strictEqual(E.reg.downloads.length, 1);
    assert.strictEqual(E.reg.downloads[0].filename, 'MINHA_PASTA/CNPJ_11222333000181_CERTIDAO.pdf');
    assert.strictEqual(E.reg.downloads[0].conflictAction, 'uniquify');
    assert.ok(E.reg.downloads[0].url.startsWith('data:application/pdf;base64,'));
    E.dls[100].state = 'complete';
    await E.fila.aoDownloadMudou({ id: 100, state: { current: 'complete' } }); await esperar();
    assert.deepStrictEqual(status(E), ['concluido', 'processando', 'pendente']);
    assert.ok(E.mem.efisco_job.itens[0].arquivo.endsWith('MINHA_PASTA/CNPJ_11222333000181_CERTIDAO.pdf'));
  });
  await teste('usa a razão social no nome do arquivo SOMENTE quando informada', async () => {
    const E = ambiente(); await E.fila.iniciar({ pasta: 'P', itens: ITENS });
    await E.fila.aoFinal({ itemId: 'L1', status: 'entrega-url', urlPdf: 'u', razao: 'Empresa Exemplo Ltda' });
    assert.strictEqual(E.reg.downloads[0].filename, 'P/EMPRESA_EXEMPLO_LTDA_CNPJ_11222333000181.pdf');
  });
  await teste('conteúdo que NÃO é PDF não é registrado como emitido', async () => {
    const E = ambiente({ fetchBytes: HTML }); await E.fila.iniciar({ pasta: 'P', itens: ITENS });
    await E.fila.aoFinal({ itemId: 'L1', status: 'entrega-url', urlPdf: 'u' }); await esperar();
    assert.strictEqual(E.mem.efisco_job.itens[0].status, 'erro'); assert.match(E.mem.efisco_job.itens[0].erro, /PDF/);
    assert.strictEqual(E.reg.downloads.length, 0);
  });
  await teste('download iniciado pelo site: define pasta/nome (uniquify) e só conclui após validar tamanho e tipo', async () => {
    const E = ambiente({ fileSize: 8000 }); await E.fila.iniciar({ pasta: 'P', itens: ITENS });
    const sug = await E.fila.aoDeterminarNome({ id: 7, url: 'https://efisco.sefaz.pe.gov.br/gerar', mime: 'application/pdf' });
    assert.deepStrictEqual(sug, { filename: 'P/CNPJ_11222333000181_CERTIDAO.pdf', conflictAction: 'uniquify' });
    E.dls[7] = { id: 7, state: 'complete', filename: '/d/P/CNPJ_11222333000181_CERTIDAO.pdf', mime: 'application/pdf', fileSize: 8000, exists: true };
    await E.fila.aoFinal({ itemId: 'L1', status: 'entrega-download' }); await esperar();
    assert.strictEqual(E.mem.efisco_job.itens[0].status, 'concluido');
  });
  await teste('download vazio/pequeno ou de outro tipo → ERRO (não conta como emitido)', async () => {
    for (const cfg of [{ fileSize: 100 }, { mime: 'text/html' }, { exists: false }]) {
      const E = ambiente(cfg); await E.fila.iniciar({ pasta: 'P', itens: ITENS });
      await E.fila.aoDeterminarNome({ id: 8, url: 'https://efisco.sefaz.pe.gov.br/g' });
      E.dls[8] = { id: 8, state: 'complete', filename: '/d/x.pdf', mime: cfg.mime || 'application/pdf', fileSize: cfg.fileSize ?? 8000, exists: cfg.exists ?? true };
      await E.fila.aoFinal({ itemId: 'L1', status: 'entrega-download' }); await esperar();
      assert.strictEqual(E.mem.efisco_job.itens[0].status, 'erro', JSON.stringify(cfg));
    }
  });
  await teste('downloads de outras origens (não e-Fisco / não PDF) são ignorados', async () => {
    const E = ambiente(); await E.fila.iniciar({ pasta: 'P', itens: ITENS });
    assert.strictEqual(await E.fila.aoDeterminarNome({ id: 9, url: 'https://exemplo.com/a.zip', mime: 'application/zip' }), null);
  });

  console.log('Erros, tentativas e fluxo contínuo');
  await teste('erro recuperável: até 3 tentativas, depois ERRO e segue para o próximo (sem ciclo infinito)', async () => {
    const E = ambiente(); await E.fila.iniciar({ pasta: 'P', itens: ITENS });
    for (let t = 1; t <= 3; t++) {
      assert.strictEqual(E.mem.efisco_job.itens[0].tentativas, t);
      await E.fila.aoFinal({ itemId: 'L1', status: 'erro', recuperavel: true, mensagem: 'campo não recebeu o valor' }); await esperar();
    }
    assert.strictEqual(E.mem.efisco_job.itens[0].status, 'erro'); assert.match(E.mem.efisco_job.itens[0].erro, /3 tentativas/);
    assert.strictEqual(E.mem.efisco_job.itens[1].status, 'processando');
  });
  await teste('erro NÃO recuperável (certidão indisponível) registra e avança sem repetir', async () => {
    const E = ambiente(); await E.fila.iniciar({ pasta: 'P', itens: ITENS });
    await E.fila.aoFinal({ itemId: 'L1', status: 'sem_certidao', mensagem: 'contribuinte com débitos' }); await esperar();
    assert.strictEqual(E.mem.efisco_job.itens[0].tentativas, 1); assert.deepStrictEqual(status(E), ['erro', 'processando', 'pendente']);
  });
  await teste('resultado de item que não é o atual (atrasado) é ignorado', async () => {
    const E = ambiente(); await E.fila.iniciar({ pasta: 'P', itens: ITENS });
    await E.fila.aoFinal({ itemId: 'L3', status: 'sem_certidao' }); assert.deepStrictEqual(status(E), ['processando', 'pendente', 'pendente']);
  });
  await teste('fila completa: todos concluídos → estado "concluido"', async () => {
    const E = ambiente(); await E.fila.iniciar({ pasta: 'P', itens: ITENS });
    for (let i = 0; i < 3; i++) {
      const id = E.mem.efisco_job.atual; const dl = 100 + i;
      await E.fila.aoFinal({ itemId: id, status: 'entrega-url', urlPdf: 'u' });
      E.dls[dl].state = 'complete'; await E.fila.aoDownloadMudou({ id: dl, state: { current: 'complete' } }); await esperar();
    }
    assert.deepStrictEqual(status(E), ['concluido', 'concluido', 'concluido']); assert.strictEqual(E.mem.efisco_job.estado, 'concluido');
    assert.deepStrictEqual(E.reg.downloads.map((d) => d.filename), ['P/CNPJ_11222333000181_CERTIDAO.pdf', 'P/CPF_12345678909_CERTIDAO.pdf', 'P/IE_032141840_CERTIDAO.pdf']);
  });

  console.log('Controles e recuperação');
  await teste('PAUSAR impede o avanço; CONTINUAR retoma', async () => {
    const E = ambiente(); await E.fila.iniciar({ pasta: 'P', itens: ITENS });
    await E.fila.pausar(); assert.strictEqual(E.mem.efisco_job.estado, 'pausado');
    await E.fila.aoFinal({ itemId: 'L1', status: 'sem_certidao' }); await esperar();
    assert.strictEqual(E.mem.efisco_job.itens[1].status, 'pendente', 'não deve avançar pausado');
    await E.fila.continuar(); await esperar(); assert.strictEqual(E.mem.efisco_job.itens[1].status, 'processando');
  });
  await teste('PARAR preserva os resultados já obtidos e marca o restante como interrompido/pendente', async () => {
    const E = ambiente(); await E.fila.iniciar({ pasta: 'P', itens: ITENS });
    await E.fila.aoFinal({ itemId: 'L1', status: 'entrega-url', urlPdf: 'u' }); E.dls[100].state = 'complete'; await E.fila.aoDownloadMudou({ id: 100, state: { current: 'complete' } }); await esperar();
    await E.fila.parar();
    assert.strictEqual(E.mem.efisco_job.estado, 'parado'); assert.deepStrictEqual(status(E), ['concluido', 'interrompido', 'pendente']);
    await E.fila.avancar(); assert.strictEqual(E.mem.efisco_job.itens[2].status, 'pendente', 'parado não avança');
  });
  await teste('CAPTCHA: pausa pedindo ação humana; CONTINUAR tenta o mesmo documento de novo', async () => {
    const E = ambiente(); await E.fila.iniciar({ pasta: 'P', itens: ITENS });
    await E.fila.aoFinal({ itemId: 'L1', status: 'captcha' });
    assert.strictEqual(E.mem.efisco_job.estado, 'pausado'); assert.match(E.mem.efisco_job.motivoPausa, /CAPTCHA/); assert.strictEqual(E.mem.efisco_job.itens[0].status, 'pendente');
    await E.fila.continuar(); await esperar();
    assert.strictEqual(E.mem.efisco_job.itens[0].status, 'processando'); assert.strictEqual(E.mem.efisco_job.itens[0].tentativas, 2);
  });
  await teste('CAPTCHA repetido: após 3 tentativas o documento vira ERRO (não fica em loop)', async () => {
    const E = ambiente(); await E.fila.iniciar({ pasta: 'P', itens: ITENS });
    for (let t = 0; t < 3; t++) { await E.fila.aoFinal({ itemId: 'L1', status: 'captcha' }); if (E.mem.efisco_job.itens[0].status === 'erro') break; await E.fila.continuar(); await esperar(); }
    assert.strictEqual(E.mem.efisco_job.itens[0].status, 'erro');
    await esperar(); assert.strictEqual(E.mem.efisco_job.estado, 'executando', 'não deve ficar pausado depois do erro definitivo');
    assert.strictEqual(E.mem.efisco_job.itens[1].status, 'processando');
  });
  await teste('aba do e-Fisco fechada → pausa; CONTINUAR reabre sem gastar tentativa', async () => {
    const E = ambiente(); await E.fila.iniciar({ pasta: 'P', itens: ITENS });
    const tab = E.mem.efisco_job.tabId; E.abas.delete(tab); await E.fila.aoAbaRemovida(tab);
    assert.strictEqual(E.mem.efisco_job.estado, 'pausado');
    await E.fila.continuar(); await esperar();
    assert.strictEqual(E.reg.janelas.length, 2); assert.ok(E.reg.janelas.every((j) => j.incognito)); assert.strictEqual(E.mem.efisco_job.itens[0].tentativas, 1); assert.strictEqual(E.mem.efisco_job.itens[0].status, 'processando');
  });
  await teste('watchdog: sem sinal do e-Fisco ⇒ nova tentativa; Emitir sem arquivo ⇒ erro', async () => {
    const E = ambiente(); await E.fila.iniciar({ pasta: 'P', itens: ITENS });
    E.avancarTempo(NS.CONFIG.fila.timeoutItemMs + 1000); await E.fila.aoAlarme(); await esperar();
    assert.strictEqual(E.mem.efisco_job.itens[0].tentativas, 2); assert.strictEqual(E.mem.efisco_job.itens[0].status, 'processando');
    await E.fila.aoStatus({ itemId: 'L1', emitirClicado: true });
    assert.strictEqual(E.mem.efisco_job.itens[0].status, 'aguardando_entrega');
    E.avancarTempo(NS.CONFIG.fila.timeoutEntregaMs + 1000); await E.fila.aoAlarme(); await esperar();
    assert.strictEqual(E.mem.efisco_job.itens[0].status, 'erro'); assert.strictEqual(E.mem.efisco_job.itens[1].status, 'processando');
  });
  await teste('esperando ação humana (confirmação manual) o watchdog NÃO dá timeout', async () => {
    const E = ambiente(); await E.fila.iniciar({ pasta: 'P', itens: ITENS });
    await E.fila.aoStatus({ itemId: 'L1', humano: 'O site pediu confirmação' });
    E.avancarTempo(NS.CONFIG.fila.timeoutItemMs * 2); await E.fila.aoAlarme(); await esperar();
    assert.strictEqual(E.mem.efisco_job.itens[0].tentativas, 1);
  });

  console.log(`\n${ok} teste(s) ok`);
})();
