/* Nomes de pasta/arquivo e validação de PDF. Puro (sem DOM, sem chrome). */
(function () {
  'use strict';
  const NS = (window.EFiscoCRF = window.EFiscoCRF || {});
  const RESERVADOS = /^(con|prn|aux|nul|com[0-9]|lpt[0-9])$/i;

  /**
   * Nome de pasta: mantém o que o usuário digitou, trocando só o que o sistema operacional não aceita.
   * @returns {{nome:string, alterado:boolean, motivos:string[]}}
   */
  function sanitizarNomePasta(entrada) {
    const original = String(entrada == null ? '' : entrada);
    const motivos = [];
    let s = original.normalize('NFC');
    if (/[\u0000-\u001f\u007f]/.test(s)) { s = s.replace(/[\u0000-\u001f\u007f]/g, ''); motivos.push('caracteres de controle removidos'); }
    if (/[\\/:*?"<>|]/.test(s)) { s = s.replace(/[\\/:*?"<>|]/g, '_'); motivos.push('caracteres \\ / : * ? " < > | trocados por _'); }
    const aparado = s.trim().replace(/^\.+/, '').replace(/[. ]+$/, '');
    if (aparado !== s) { motivos.push('pontos/espaços nas pontas removidos'); s = aparado; }
    if (RESERVADOS.test(s)) { s += '_'; motivos.push('nome reservado do Windows'); }
    if (s.length > 100) { s = s.slice(0, 100); motivos.push('limitado a 100 caracteres'); }
    return { nome: s, alterado: s !== original.trim() || motivos.length > 0, motivos };
  }

  /** Parte de nome de arquivo: sem acentos, maiúsculas, só A-Z 0-9 e _. */
  function sanitizarParte(s, max = 60) {
    return String(s == null ? '' : s).normalize('NFD').replace(/[̀-ͯ]/g, '').toUpperCase()
      .replace(/[^A-Z0-9]+/g, '_').replace(/^_+|_+$/g, '').slice(0, max).replace(/_+$/, '');
  }

  /**
   * Nome do arquivo. Com razão social (só se obtida no sistema): EMPRESA_EXEMPLO_CNPJ_11222333000181.pdf
   * Sem ela: CNPJ_11222333000181_CERTIDAO.pdf. Nunca inventa o nome do contribuinte.
   */
  function nomeArquivo({ tipo, digitos, razao }) {
    const t = sanitizarParte(tipo, 8) || 'DOC';
    const d = String(digitos || '').replace(/\D/g, '');
    const r = sanitizarParte(razao);
    return r ? `${r}_${t}_${d}.pdf` : `${t}_${d}_CERTIDAO.pdf`;
  }

  /** O conteúdo é um PDF? Cabeçalho "%PDF-" nos primeiros 1024 bytes e tamanho mínimo plausível. */
  function ehPdf(bytes) {
    if (!bytes || bytes.length < 200) return false;
    const n = Math.min(bytes.length, 1024);
    let cab = '';
    for (let i = 0; i < n; i++) cab += String.fromCharCode(bytes[i]);
    return cab.includes('%PDF-');
  }

  /** ArrayBuffer/Uint8Array → data URL base64 (service worker não tem URL.createObjectURL). */
  function paraDataUrl(bytes, mime = 'application/pdf') {
    let bin = '';
    const passo = 0x8000;
    for (let i = 0; i < bytes.length; i += passo) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + passo));
    return `data:${mime};base64,${btoa(bin)}`;
  }

  /** Data URL de PDF válida? Confere o cabeçalho decodificando só o começo do base64. */
  function ehPdfDataUrl(dataUrl) {
    const m = /^data:[^;,]*;base64,(.+)$/s.exec(dataUrl || '');
    if (!m || m[1].length < 300) return false;
    try { const cab = atob(m[1].slice(0, 1400)); return cab.includes('%PDF-'); } catch (_) { return false; }
  }
  /** Tamanho aproximado (bytes) do conteúdo de uma data URL base64. */
  function tamanhoDataUrl(dataUrl) {
    const m = /^data:[^;,]*;base64,(.+)$/s.exec(dataUrl || '');
    if (!m) return 0;
    const b = m[1]; return Math.floor((b.length * 3) / 4) - (b.endsWith('==') ? 2 : b.endsWith('=') ? 1 : 0);
  }

  NS.arquivos = { sanitizarNomePasta, sanitizarParte, nomeArquivo, ehPdf, paraDataUrl, ehPdfDataUrl, tamanhoDataUrl };
})();
