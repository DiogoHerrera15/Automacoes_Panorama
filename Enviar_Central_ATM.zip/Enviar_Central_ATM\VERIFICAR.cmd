@echo off
rem Confere o computador e a instalacao da Central (so le; nao muda nada).
chcp 65001 >nul
title Central de Automacoes - verificacao
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Instalacao\verificar_ambiente.ps1" %*
echo.
pause
