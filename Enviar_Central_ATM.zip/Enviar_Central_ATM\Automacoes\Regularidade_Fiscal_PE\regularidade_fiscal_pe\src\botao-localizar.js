/*
 * Botão "Localizar (l)": UM clique, de propósito, com autorização temporária da guarda.
 * Sem repetição automática de clique (evita consultas duplicadas e novos erros de CAPTCHA).
 */
(function () {
  'use strict';
  const NS = (window.EFiscoCRF = window.EFiscoCRF || {});
  const { dormir, esperarOuNulo, esperarPor, tentar } = NS.wait;
  const { norm } = NS.dom;

  const textoDe = (el) => norm(el.tagName === 'INPUT' ? el.value : el.textContent);

  /** É inequivocamente o Localizar? (e não o Emitir) */
  function ehLocalizar(el) {
    if (!el) return false;
    const t = textoDe(el);
    if (el.id === 'btt_emitir' || t.includes('emitir')) return false;
    return el.id === 'btt_localizar' || t === 'localizar' || t.startsWith('localizar ');
  }

  function localizarBotao() {
    const { seletor } = NS.CONFIG.localizar;
    const porId = seletor && document.querySelector(seletor);
    if (porId) return ehLocalizar(porId) ? porId : null;
    return [...document.querySelectorAll('input[type=submit], input[type=button], button')].find(ehLocalizar) || null;
  }

  function cursorSobre(botao) {
    const p = NS.cursor.posicao();
    if (!p) return false;
    const el = document.elementFromPoint(p.x, p.y);
    return !!el && (el === botao || botao.contains(el));
  }

  /** @returns {Promise<{navegou:boolean}>} */
  async function acionar() {
    const cfg = NS.CONFIG.localizar;
    const { tentativas, timeouts } = NS.CONFIG;

    const botao = await tentar('Localizar botão Localizar', async () => {
      const b = localizarBotao();
      if (!b || !NS.wait.estaVisivel(b)) throw new Error('botão "Localizar (l)" não encontrado/visível');
      if (b.disabled) await esperarPor(() => !b.disabled, { timeout: timeouts.habilitar, descricao: 'habilitação do botão Localizar' });
      return b;
    }, tentativas.localizar, tentativas.intervalo);

    await NS.aviso.fecharSePresente({ janela: 0 });
    await NS.cursor.moverPara(botao);
    await dormir(150);
    if (!cursorSobre(botao)) throw new Error('o cursor não ficou sobre o botão Localizar — clique cancelado');
    await NS.cursor.clicar();
    if (!ehLocalizar(botao) || botao.disabled) throw new Error('o botão Localizar mudou de estado imediatamente antes do clique — cancelado');

    let navegando = false;
    const marcar = () => { navegando = true; };
    window.addEventListener('beforeunload', marcar);
    window.addEventListener('pagehide', marcar);
    try {
      NS.guarda.autorizar();                 // autoriza UM clique intencional
      NS.dom.dispararClique(botao);
      NS.log.info('[Localizar] Clique realizado (único). Verificando o efeito...');
      await esperarOuNulo(() => navegando, { timeout: cfg.aguardarNavegacao, intervalo: 100, descricao: 'recarga após Localizar' });
      return { navegou: navegando };
    } finally {
      NS.guarda.revogar();                   // nenhum outro clique no Localizar é permitido
      window.removeEventListener('beforeunload', marcar);
      window.removeEventListener('pagehide', marcar);
    }
  }

  NS.botaoLocalizar = { ehLocalizar, localizarBotao, acionar };
})();
