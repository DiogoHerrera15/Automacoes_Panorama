// Service worker:
//  1) abre a JANELA da extensão (interface.html: pasta de destino, lista de empresas, iniciar/parar e andamento):
//     ao clicar no ícone e, automaticamente, quando a Central de Automações abre o e-CAC para esta automação;
//  2) repassa mensagens entre a janela principal e os iframes de outro domínio do e-CAC
//     (o conteúdo do Parcelamento fica num iframe que a janela principal não consegue acessar);
//  3) captura a tela da aba do e-CAC, monta um PDF e salva numa subpasta de Downloads.
// O content script só existe nas páginas do e-CAC (ver "matches" no manifest).

const PREFIXO = '[parcelamento_simplificado]';

// Pasta de destino: subpastas de Downloads separadas por "/". Cada parte aceita letras (com acento), números, espaços e
// símbolos comuns, mas nada que o Windows recuse (< > : " | ? * \ e caracteres de controle), nunca "." ou ".." (não deixa
// sair de Downloads), e não começa/termina com espaço nem termina com ponto. A interface já entrega nomes limpos;
// esta conferência é a segunda barreira.
const NOMES_RESERVADOS = /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(\..*)?$/i;
const pastaValida = (p) => typeof p === 'string' && p.length > 0 && p.length <= 400 &&
  p.split('/').every((s) => s.length > 0 && s.length <= 140 && !/[<>:"|?*\\\u0000-\u001f]/.test(s) &&
    !/^\.+$/.test(s) && !/^\s|[\s.]$/.test(s) && !NOMES_RESERVADOS.test(s));

// ------------------------------- janela da interface -------------------------------
const URL_INTERFACE = chrome.runtime.getURL('interface.html');

async function abrirInterface() {
  const { ps_janela: id } = await chrome.storage.session.get('ps_janela');
  if (id) {
    try { // já aberta: só traz para a frente
      await chrome.windows.update(id, { focused: true });
      return;
    } catch (_) { /* foi fechada */ }
  }
  const w = await chrome.windows.create({ url: URL_INTERFACE, type: 'popup', width: 680, height: 900 });
  await chrome.storage.session.set({ ps_janela: w.id });
}

// Clique no ícone: abre a interface (o início da automação é o botão "Iniciar automação" dela).
chrome.action.onClicked.addListener(() => {
  abrirInterface().catch((e) => console.warn(PREFIXO, 'não consegui abrir a interface:', e.message));
});

// A Central de Automações abre o e-CAC com o marcador "#ps_abrir_interface" no endereço: é o sinal para abrir a
// interface sozinha (o marcador fica depois do "#", nunca é enviado ao servidor da Receita).
chrome.webNavigation.onBeforeNavigate.addListener((d) => {
  if (d.frameId !== 0 || !String(d.url).includes('ps_abrir_interface')) return;
  abrirInterface().catch((e) => console.warn(PREFIXO, 'não consegui abrir a interface:', e.message));
}, { url: [{ hostEquals: 'cav.receita.fazenda.gov.br', pathPrefix: '/autenticacao/login' }] });

// ------------------------------- PDF a partir de uma imagem JPEG -------------------------------
// PDF mínimo de 1 página, do tamanho da imagem (96 dpi -> pontos), com o JPEG embutido.
function montarPdf(jpg, w, h) {
  const enc = new TextEncoder();
  const W = +(w * 0.75).toFixed(2);
  const H = +(h * 0.75).toFixed(2);
  const conteudo = `q ${W} 0 0 ${H} 0 0 cm /Im0 Do Q`;
  const partes = [];
  const offs = [];
  let pos = 0;
  const add = (x) => {
    const b = typeof x === 'string' ? enc.encode(x) : x;
    partes.push(b);
    pos += b.length;
  };
  const obj = (n, corpo) => {
    offs[n] = pos;
    add(`${n} 0 obj\n${corpo}\nendobj\n`);
  };

  add('%PDF-1.4\n');
  obj(1, '<< /Type /Catalog /Pages 2 0 R >>');
  obj(2, '<< /Type /Pages /Kids [3 0 R] /Count 1 >>');
  obj(3, `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${W} ${H}] /Resources << /XObject << /Im0 4 0 R >> >> /Contents 5 0 R >>`);
  offs[4] = pos;
  add(`4 0 obj\n<< /Type /XObject /Subtype /Image /Width ${w} /Height ${h} /ColorSpace /DeviceRGB ` +
      `/BitsPerComponent 8 /Filter /DCTDecode /Length ${jpg.length} >>\nstream\n`);
  add(jpg);
  add('\nendstream\nendobj\n');
  obj(5, `<< /Length ${conteudo.length} >>\nstream\n${conteudo}\nendstream`);

  const xref = pos;
  let t = 'xref\n0 6\n0000000000 65535 f \n';
  for (let n = 1; n <= 5; n++) t += `${String(offs[n]).padStart(10, '0')} 00000 n \n`;
  t += `trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF\n`;
  add(t);

  const saida = new Uint8Array(pos);
  let p = 0;
  for (const b of partes) { saida.set(b, p); p += b.length; }
  return saida;
}

function bytesParaBase64(bytes) {
  let s = '';
  for (let i = 0; i < bytes.length; i += 0x8000) {
    s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
  }
  return btoa(s);
}

function dataUrlParaBytes(dataUrl) {
  const bin = atob(dataUrl.slice(dataUrl.indexOf(',') + 1));
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return bytes;
}

function esperarDownload(id, limiteMs = 15000) {
  return new Promise((resolve) => {
    const fim = (caminho) => {
      chrome.downloads.onChanged.removeListener(ouvir);
      clearTimeout(timer);
      resolve(caminho);
    };
    const buscar = async () => {
      const [item] = await chrome.downloads.search({ id });
      return item && item.filename;
    };
    const ouvir = async (d) => {
      if (d.id !== id || !d.state) return;
      if (d.state.current === 'complete' || d.state.current === 'interrupted') fim(await buscar());
    };
    const timer = setTimeout(async () => fim(await buscar()), limiteMs);
    chrome.downloads.onChanged.addListener(ouvir);
  });
}

// Captura a parte visível da aba, gera o PDF e salva em Downloads/<pasta>/<nome>.
async function capturarEmPdf({ pasta, nome }, tabId) {
  if (!pastaValida(pasta) || !/^[\w.-]+\.pdf$/.test(nome)) throw new Error('nome de pasta/arquivo inválido');
  const tab = await chrome.tabs.get(tabId);
  if (!tab.active) throw new Error('a aba do e-CAC não está em primeiro plano; deixe-a visível durante a captura');
  const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'jpeg', quality: 92 });
  const jpg = dataUrlParaBytes(dataUrl);
  const bmp = await createImageBitmap(new Blob([jpg], { type: 'image/jpeg' }));
  const pdf = montarPdf(jpg, bmp.width, bmp.height);
  // Só avança se o arquivo foi MESMO salvo por inteiro, na pasta pedida (antes, passados 15 s sem terminar, seguia assim mesmo).
  const { caminho } = await baixarComNome('data:application/pdf;base64,' + bytesParaBase64(pdf), `${pasta}/${nome}`);
  // Aba anônima: o salvamento é igual (mesma pasta Downloads do Chrome); só registramos para conferência.
  console.log(PREFIXO, `PDF da tela salvo em ${caminho || `Downloads/${pasta}/${nome}`}${tab.incognito ? ' (aba anônima)' : ''}`);
  return { ok: true, caminho: caminho || `Downloads/${pasta}/${nome}`, anonima: !!tab.incognito };
}

// ------------------------------- PDF do DARF (gerado pela própria página do e-CAC) -------------------------------
// Antes de clicar em "Emitir DARF de parcela", o content script "arma" este estado. Daí em diante:
//  - se a página iniciar um download, ele é renomeado e guardado em Downloads/<pasta>/<nome>;
//  - se a página abrir uma nova aba (PDF aberto em vez de baixado) e nenhum download começar em 8 s,
//    tenta baixar o endereço dessa aba.
// O content script consulta o andamento com 'status-darf'.
let darf = null; // { tabId, pasta, nome, expira, estado, caminho, detalhe, novaAba, downloadId }
const DARF_VALIDADE_MS = 120000;
const darfAtivo = () => !!darf && Date.now() < darf.expira;

// Downloads feitos pela PRÓPRIA extensão (print em PDF, relatório): endereço -> caminho desejado em Downloads.
// Com um ouvinte de onDeterminingFilename registrado, o Chrome ignora o "filename" do download() se o ouvinte não o
// confirmar (o arquivo caía em Downloads\download.pdf, fora da pasta da empresa). O ouvinte confirma o nome deste mapa.
const nomesProprios = new Map();

async function baixarComNome(url, filename) {
  nomesProprios.set(url, filename);
  try {
    const id = await chrome.downloads.download({ url, filename, conflictAction: 'uniquify', saveAs: false });
    const caminho = await esperarDownload(id);
    const [salvo] = await chrome.downloads.search({ id });
    if (!salvo || salvo.state !== 'complete') {
      throw new Error(`o arquivo não terminou de ser salvo (${salvo ? (salvo.error || salvo.state) : 'download não encontrado'})`);
    }
    // confere que foi parar na pasta pedida (e não em Downloads\download.pdf)
    const final = String(caminho || salvo.filename || '').replace(/\\/g, '/');
    const pastaPedida = filename.split('/').slice(0, -1).join('/');
    if (!final.toLowerCase().includes(`/${pastaPedida.toLowerCase()}/`)) {
      throw new Error(`o Chrome salvou "${caminho}" em vez de "Downloads/${filename}"`);
    }
    return { id, caminho };
  } finally {
    nomesProprios.delete(url);
  }
}

chrome.downloads.onDeterminingFilename.addListener((item, sugerir) => {
  if (item.byExtensionId === chrome.runtime.id) { // downloads desta extensão (PDF da tela, relatório)
    const nome = nomesProprios.get(item.url) || nomesProprios.get(item.finalUrl);
    if (nome) sugerir({ filename: nome, conflictAction: 'uniquify' }); else sugerir();
    return;
  }
  if (!darfAtivo() || darf.downloadId) return;          // só o primeiro download depois do clique
  const origem = `${item.url} ${item.finalUrl || ''} ${item.referrer || ''}`;
  if (!origem.includes('receita.fazenda.gov.br')) return;
  darf.downloadId = item.id;
  darf.estado = 'baixando';
  darf.detalhe = `download iniciado pela página (${item.mime || 'tipo desconhecido'}; nome original: ${item.filename})` +
    (item.incognito ? ' [aba anônima: guardado na mesma pasta Downloads]' : '');
  console.log(PREFIXO, darf.detalhe);
  sugerir({ filename: `${darf.pasta}/${darf.nome}`, conflictAction: 'uniquify' });
});

chrome.downloads.onChanged.addListener(async (d) => {
  if (!darf || d.id !== darf.downloadId || !d.state) return;
  if (d.state.current === 'complete') {
    const [it] = await chrome.downloads.search({ id: d.id });
    darf.estado = 'ok';
    darf.caminho = it && it.filename;
    if (it && it.mime && !/pdf/i.test(it.mime)) darf.detalhe = `atenção: o arquivo baixado é do tipo ${it.mime}, não PDF`;
    console.log(PREFIXO, 'DARF salvo em', darf.caminho, darf.detalhe || '');
  } else if (d.state.current === 'interrupted') {
    darf.estado = 'erro';
    darf.detalhe = `o download foi interrompido (${(d.error && d.error.current) || 'motivo desconhecido'})`;
  }
});

chrome.tabs.onCreated.addListener((tab) => {
  if (!darfAtivo() || tab.openerTabId !== darf.tabId) return;
  darf.novaAba = { id: tab.id, url: tab.pendingUrl || tab.url || '' };
  console.log(PREFIXO, 'a página abriu uma nova aba:', darf.novaAba.url);
  setTimeout(() => baixarDaNovaAba(tab.id), 8000);
});

async function baixarDaNovaAba(tabId) {
  if (!darfAtivo() || darf.downloadId) return; // já houve download: nada a fazer
  let url = '';
  try { url = (await chrome.tabs.get(tabId)).url || ''; } catch (_) { /* aba fechada */ }
  darf.novaAba = { id: tabId, url };
  if (!/^(https?|blob):/.test(url)) {
    darf.estado = 'erro';
    darf.detalhe = `a nova aba abriu em "${url || 'endereço desconhecido'}" e não consegui baixar o PDF dela`;
    return;
  }
  try {
    darf.downloadId = await chrome.downloads.download({
      url, filename: `${darf.pasta}/${darf.nome}`, conflictAction: 'uniquify', saveAs: false,
    });
    darf.estado = 'baixando';
    darf.detalhe = `baixando o endereço da nova aba: ${url.slice(0, 120)}`;
  } catch (e) {
    darf.estado = 'erro';
    darf.detalhe = `não consegui baixar o endereço da nova aba (${e.message}): ${url.slice(0, 120)}`;
  }
}

// ------------------------------- relatório de problemas (.txt) -------------------------------
// <pasta principal>/RELATORIO_PROBLEMAS_<data-hora>.txt (nome com data e hora: nunca sobrescreve um relatório anterior).
async function salvarRelatorioTxt(pasta, texto) {
  const d = new Date(), p2 = (n) => String(n).padStart(2, '0');
  const nome = `RELATORIO_PROBLEMAS_${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())}_${p2(d.getHours())}-${p2(d.getMinutes())}-${p2(d.getSeconds())}.txt`;
  const { caminho } = await baixarComNome('data:text/plain;charset=utf-8,' + encodeURIComponent('﻿' + texto), `${pasta}/${nome}`);
  return caminho || `Downloads/${pasta}/${nome}`;
}

// Pedido da janela da extensão (botão "Salvar relatório"): vem de uma página da própria extensão, não do e-CAC.
chrome.runtime.onMessage.addListener((msg, remetente, responder) => {
  if (!msg || msg.ps !== 'salvar-relatorio-janela' || remetente.id !== chrome.runtime.id) return false;
  if (!String(remetente.url || '').startsWith(chrome.runtime.getURL(''))) return false;
  const { pasta, texto } = msg.dados || {};
  if (!pastaValida(pasta) || typeof texto !== 'string' || texto.length > 2000000) { responder({ ok: false, erro: 'pedido inválido' }); return false; }
  salvarRelatorioTxt(pasta, texto).then((caminho) => responder({ ok: true, caminho }), (e) => responder({ ok: false, erro: e.message }));
  return true;
});

// ------------------------------- mensagens do content script -------------------------------
chrome.runtime.onMessage.addListener((msg, remetente, responder) => {
  if (!msg || !remetente.tab || remetente.id !== chrome.runtime.id) return false;

  // Janela principal -> todos os frames da aba. Quem tiver resposta (o frame certo) responde;
  // os demais ficam em silêncio. Sem resposta, devolve null.
  if (msg.ps === 'repassar') {
    chrome.tabs.sendMessage(remetente.tab.id, { ps: 'frame', dados: msg.dados })
      .then((resp) => responder(resp || null))
      .catch(() => responder(null));
    return true; // resposta assíncrona
  }

  let doEcac = false;
  try { doEcac = new URL(remetente.url).hostname.endsWith('cav.receita.fazenda.gov.br'); } catch (_) { /* url inválida */ }

  // Prepara o salvamento do PDF que a página vai gerar (ver bloco do DARF acima).
  if (msg.ps === 'armar-darf') {
    const { pasta, nome } = msg.dados || {};
    if (!doEcac || !pastaValida(pasta) || !/^[\w.-]+\.pdf$/.test(nome || '')) {
      responder({ ok: false, erro: 'pedido inválido' });
      return false;
    }
    darf = { tabId: remetente.tab.id, pasta, nome, expira: Date.now() + DARF_VALIDADE_MS, estado: 'aguardando' };
    responder({ ok: true });
    return false;
  }
  if (msg.ps === 'status-darf') {
    responder(darf ? { estado: darf.estado, caminho: darf.caminho, detalhe: darf.detalhe, novaAba: darf.novaAba || null } : null);
    return false;
  }

  // Relatório de problemas (texto) na pasta principal escolhida: RELATORIO_PROBLEMAS_<data-hora>.txt. Nome com data e
  // hora: nunca sobrescreve um relatório anterior.
  if (msg.ps === 'salvar-relatorio') {
    const { pasta, texto } = msg.dados || {};
    if (!doEcac || !pastaValida(pasta) || typeof texto !== 'string' || texto.length > 2000000) {
      responder({ ok: false, erro: 'pedido inválido' });
      return false;
    }
    salvarRelatorioTxt(pasta, texto)
      .then((caminho) => responder({ ok: true, caminho }))
      .catch((e) => responder({ ok: false, erro: e.message }));
    return true;
  }

  // Captura de tela: só aceita pedidos vindos de páginas do e-CAC.
  if (msg.ps === 'capturar') {
    if (!doEcac) { responder({ ok: false, erro: 'captura permitida só no e-CAC' }); return false; }
    capturarEmPdf(msg.dados, remetente.tab.id)
      .then(responder)
      .catch((e) => { console.error(PREFIXO, 'falha ao salvar PDF:', e); responder({ ok: false, erro: e.message }); });
    return true;
  }
  return false;
});
