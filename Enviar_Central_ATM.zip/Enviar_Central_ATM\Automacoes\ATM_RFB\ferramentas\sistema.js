// Tudo o que muda entre macOS e Windows fica aqui, para o resto do código ser um só nos dois sistemas:
// onde está o Chrome, qual é o Python do projeto e como abrir uma pasta ou a janela da interface.
// Nada aqui depende de usuário, letra de unidade ou caminho fixo: usa o que o próprio sistema informa.
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

export const WINDOWS = process.platform === 'win32';
export const MAC = process.platform === 'darwin';

// Executável do Chrome. CHROME_PATH tem prioridade (Chrome instalado num lugar diferente do padrão).
export function caminhoChrome() {
  const candidatos = [process.env.CHROME_PATH];
  if (MAC) {
    candidatos.push(
      '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
      path.join(os.homedir(), 'Applications', 'Google Chrome.app', 'Contents', 'MacOS', 'Google Chrome'),
    );
  } else if (WINDOWS) {
    // Instalação para todos os usuários (Arquivos de Programas, 64 ou 32 bits) ou só para este usuário (AppData).
    for (const base of [process.env.PROGRAMFILES, process.env['PROGRAMFILES(X86)'], process.env.LOCALAPPDATA]) {
      if (base) candidatos.push(path.join(base, 'Google', 'Chrome', 'Application', 'chrome.exe'));
    }
  } else {
    candidatos.push('/usr/bin/google-chrome', '/usr/bin/google-chrome-stable');
  }
  return candidatos.find((c) => c && fs.existsSync(c)) ?? null;
}

// Abre o Chrome com estes argumentos. Com o Chrome já aberto, a aba/janela nova abre nele.
// Devolve false se não achou o Chrome (no Windows ainda tenta pelo registro, com "start chrome").
export function abrirChrome(argumentos) {
  const exe = caminhoChrome();
  if (exe) {
    spawn(exe, argumentos, { detached: true, stdio: 'ignore' }).unref();
    return true;
  }
  if (WINDOWS) {
    spawn('cmd', ['/c', 'start', '', 'chrome', ...argumentos], { detached: true, stdio: 'ignore', windowsHide: true }).unref();
    return true;
  }
  return false;
}

// Python do ambiente próprio do projeto (.venv); sem ele, o Python do sistema.
export function pythonDoProjeto(raiz) {
  const venv = WINDOWS ? path.join(raiz, '.venv', 'Scripts', 'python.exe') : path.join(raiz, '.venv', 'bin', 'python3');
  if (fs.existsSync(venv)) return venv;
  return WINDOWS ? 'python' : 'python3';
}

// Variáveis para o Python escrever em UTF-8 (nomes com acento) mesmo com a saída redirecionada no Windows.
export const AMBIENTE_PYTHON = { PYTHONUTF8: '1', PYTHONIOENCODING: 'utf-8' };

// Abre a pasta no Finder / Explorador de Arquivos.
export function abrirPasta(pasta) {
  const [cmd, args] = MAC ? ['open', [pasta]] : WINDOWS ? ['explorer.exe', [pasta]] : ['xdg-open', [pasta]];
  spawn(cmd, args, { detached: true, stdio: 'ignore' }).on('error', () => {}).unref();
}

// Janela própria (sem barra de endereço) no Chrome para a interface; sem Chrome, o navegador padrão.
export function abrirJanelaApp(url) {
  const exe = caminhoChrome();
  if (MAC && exe) {
    // -n: abre mesmo com o Chrome já aberto.
    spawn('open', ['-na', 'Google Chrome', '--args', `--app=${url}`, '--window-size=1240,860'], { detached: true, stdio: 'ignore' }).unref();
  } else if (exe) {
    spawn(exe, [`--app=${url}`, '--window-size=1240,860'], { detached: true, stdio: 'ignore' }).unref();
  } else if (WINDOWS) {
    spawn('cmd', ['/c', 'start', '', url], { detached: true, stdio: 'ignore', windowsHide: true }).unref();
  } else {
    spawn(MAC ? 'open' : 'xdg-open', [url], { detached: true, stdio: 'ignore' }).on('error', () => {}).unref();
  }
}

// Comando de instalação para mostrar nas mensagens de erro.
export const COMANDO_INSTALAR = WINDOWS ? 'instalar.cmd (ou, no PowerShell: .\\instalar.ps1)' : 'bash instalar.sh';
