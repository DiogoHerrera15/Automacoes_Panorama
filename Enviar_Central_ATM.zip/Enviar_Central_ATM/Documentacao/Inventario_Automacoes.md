# Inventário das automações

Levantamento feito em 17/11/2026 na máquina de origem, a partir de `Documents\Central_Automacoes\automacoes.json`
(a lista que a Central usa) e dos caminhos **reais** de cada projeto. Cópias duplicadas foram comparadas arquivo por
arquivo (hash MD5) antes de escolher qual entra no pacote.

**Resumo:** 9 automações cadastradas na Central → **9 incluídas** (a 7ª, CNDT, e a 8ª, CND Prefeitura do Recife, acrescentadas em 17/11/2026; a 9ª, Certidão Negativa SEFAZ-PE, em 18/11/2026), cada uma na sua pasta em `Automacoes\`.

Legenda da situação:
- **Verificado aqui** = conferido na máquina de origem (instalação de teste completa numa pasta temporária: cópia,
  `npm ci`, `.venv`, Central `-Validar` e autoteste da janela).
- **Depende do destino** = só dá para confirmar no computador novo (extensões carregadas, certificado, sites reais).

---

## 1. RETIRAR AUTO-INFRAÇÃO

| Item | Valor |
|---|---|
| Finalidade | Certidão de Débitos Trabalhistas (MTE) em lote, por CPF/CNPJ |
| Origem | `%USERPROFILE%\Downloads\Retirar_Auto_Infracao`: versão do Git de 17/11/2026 (`Retirar_Auto_Infracao_PARA_GIT.zip`: pasta de destino obrigatória, pasta principal, PDF com o nome da empresa) + porte para Windows reaplicado (`src\sistema.js`, `.cmd`, porta 47331) |
| Pasta no pacote | `Automacoes\Retirar_Auto_Infracao` |
| Instalada em | `%CENTRAL_ATM%\Automacoes\Retirar_Auto_Infracao` |
| Tipo na Central | `terminal` |
| Ponto de entrada | `ABRIR_INTERFACE.cmd` → `node src\interface\iniciar.js` (interface em `http://127.0.0.1:47331`, token) |
| Outros | `INICIAR.cmd` (modo linha de comando, `src\cli.js`), `.command` (Mac, sem uso no Windows) |
| Dependências | Node.js ≥ 20; `pdfjs-dist` 4.10.38 (+ `@napi-rs/canvas`), travadas em `package-lock.json` → `npm ci` |
| Extensão Chrome | `extensao-chrome` ("Retirar_Auto_Infracao" v1.12); fala com o assistente na porta **47321** (`GET /cnpj`) |
| Modo anônimo | não exigido |
| Dados do usuário (não vão no pacote) | `dados\` (vai vazia), PDFs, `Relatorio.csv`; `COLE_OS_CNPJS_AQUI.txt` vai só com o cabeçalho |
| Saída | `<pasta principal (padrão Downloads)>\<NOME DA PASTA DE DESTINO>\<NOME DA EMPRESA>.pdf` (nomes iguais: `NOME - CNPJ.pdf`; sem nome: `<CNPJ>.pdf`); pela linha de comando, `Lote_AAAA-MM-DD_HHhMM\` na pasta do projeto |
| Testes | `npm test` (53 testes, sem Chrome e sem site; passaram no Windows em 17/11/2026) |
| Situação | **Verificado aqui**: cópia completa, `npm ci` OK, Central encontra o ponto de entrada. **Depende do destino**: extensão carregada; site do MTE |

## 2. CERTIDÃO RECEITA FEDERAL (ATM RFB)

| Item | Valor |
|---|---|
| Finalidade | Certidão de Débitos Relativos a Créditos Tributários Federais e à Dívida Ativa da União, em lote |
| Origem | `%USERPROFILE%\Downloads\ATM_RFB` + atualização do Git de 17/11/2026 (`ferramentas\lote.py`: pasta e documento pelo nome da empresa; `ATUALIZACOES.md`) |
| Pasta no pacote | `Automacoes\ATM_RFB` |
| Tipo na Central | `terminal` |
| Ponto de entrada | `INTERFACE RFB EMISSAO.cmd` → `node interface\servidor.js` (porta **47330**); na 1ª vez roda `instalar.ps1 -SemPerguntas` |
| Outros | `instalar.cmd/.ps1` (instalador próprio), `iniciar.cmd/.ps1` (linha de comando), `ferramentas\lote.py`, `entrega_nomeada.py` |
| Dependências | Node.js ≥ 18 + `pdfjs-dist` 4.10.38 (`npm ci`); Python 3.8+ com Pillow e openpyxl em `.venv` própria (`requirements.txt`) |
| Extensão Chrome | `extensao-chrome` ("Automacao_RFB" v1.8) — ligar **Permitir no modo anônimo** |
| Dados do usuário (não vão) | `empresas.csv`, `Controle.json`, `Relatorio.csv`, `certidoes\`, `*.pdf`, `interface\config.json`, `lista_cnpjs.txt` (regra do `.gitignore` dele) |
| Modelo | `lista_cnpjs.exemplo.txt` |
| Saída | `Downloads\<pasta do lote>\<NOME DA EMPRESA>\<CNPJ>;<NOME DA EMPRESA>.pdf` (sem certidão: `IRREGULAR - <CNPJ>;<NOME>.pdf`; nomes iguais: pasta `NOME - CNPJ`; mapa fixo em `_controle\pastas.json`); lotes antigos com pasta por CNPJ continuam como estão |
| Situação | **Verificado aqui**: `instalar.ps1` dele rodou na instalação de teste (npm ci + `.venv` com Pillow/openpyxl). **Depende do destino**: extensão; site da Receita |

## 3. PGFN – DOCUMENTOS DE ARRECADAÇÃO

| Item | Valor |
|---|---|
| Finalidade | e-CAC → Regularize → SISPAR: emite os documentos de arrecadação das negociações "DEFERIDA E CONSOLIDADA" por CNPJ |
| Origem | `%USERPROFILE%\Downloads\Auto_PGFN` (cópia ativa; `Downloads\ATM_PGFN` é uma cópia antiga empacotada) |
| Pasta no pacote | `Automacoes\Auto_PGFN` — mesma lista de arquivos do `instalacao\gerar_pacote.ps1` do próprio projeto + `README.md` |
| Instalada em | **`%USERPROFILE%\Downloads\Auto_PGFN` (obrigatório)** |
| Tipo na Central | `janela` |
| Ponto de entrada | `Automacao_PGFN.exe` (interface C#; fonte em `interface\AutomacaoPGFN.cs`, recompila com `interface\compilar.bat`) |
| Outros | `INICIAR_AUTOMACAO.bat` (modo antigo com `cnpjs.json`), `VER_ANDAMENTO.bat`, `orquestrador\orquestrador.ps1` |
| Dependências | só Chrome e Windows (.NET Framework 4 já vem no Windows) |
| Extensão Chrome | `Automação_PGFN` (v0.39.0) — ligar **Permitir no modo anônimo** |
| Ajudante do Windows | `ajudante_salvar_como\` registrado como native messaging host `com.auto_pgfn.salvar_como` (HKCU) pelo `INSTALAR.bat` **depois** de carregar a extensão (usa o ID dela). O manifesto do ajudante desta máquina NÃO vai no pacote |
| Dados do usuário (não vão) | `configuracoes\*.json` (listas e andamentos por certificado), `cnpjs.json`, `Documentos_arrecadacao\`, `orquestrador\*.json/*.log`, `_recuperacao\`, `PGFN_11-2026*`, `pacotes\`, `CONTINUIDADE_AUTOMACAO_PGFN.md` (documento interno com CNPJs) |
| Modelo | `instalacao\cnpjs.exemplo.json` |
| Atenção | fecha **todas** as janelas do Chrome a cada CNPJ; usa o mouse por alguns segundos ao escolher o certificado |
| Situação | **Verificado aqui**: arquivos completos (lista do próprio empacotador), Central encontra o `.exe`. **Depende do destino**: extensão + `INSTALAR.bat` (ajudante), certificado instalado, e-CAC |

## 4. SITUAÇÃO FISCAL

| Item | Valor |
|---|---|
| Finalidade | Minhas Dívidas e Pendências (e-CAC): certidão e relatório da situação fiscal por CNPJ |
| Origem | extensão ativa `Desktop\ATM_SIT_FISCAL\Situacao_Fiscal` (idêntica à de `Documents\Autom_Situacao_Fiscal`, conferido) + `ferramentas\` e `README.md` do projeto completo `Documents\Autom_Situacao_Fiscal` |
| Pasta no pacote | `Automacoes\Situacao_Fiscal` (`Situacao_Fiscal\` = extensão; `ferramentas\`; `README_projeto.md`; `COMO_FUNCIONA.html`; `LEIA-ME_PRIMEIRO.txt`) |
| Tipo na Central | `chrome` (abre `https://cav.receita.fazenda.gov.br/autenticacao/login`; inicia pelo ícone da extensão) |
| Dependências | só Chrome (as `ferramentas\*.js` opcionais usam Node.js) |
| Extensão Chrome | `Situacao_Fiscal` (v1.3.1; desde a v1.2.0: painel externo aberto pela Central, início automático depois do login no e-CAC, CNPJs inválidos ignorados) |
| Dados do usuário (não vão) | `progresso_situacao_fiscal.csv`, `lista_cnpjs.txt`; `HISTORICO.md` e `CODIGO_COMPLETO.md` ficaram de fora (contêm CNPJs de clientes) |
| **Alterado no pacote** | o `content.js` original traz embutida uma lista padrão de ~200 clientes (`DOCUMENTOS`), gravada como configuração na primeira vez que a extensão roda. Na cópia do pacote ela foi **esvaziada** (`const DOCUMENTOS = [];`) e a `PASTA_RAIZ` padrão virou `Situacao_Fiscal`; os exemplos de `popup.html`, `LEIA-ME.md` e `COMO_FUNCIONA.html` viraram fictícios. Uso: informe a pasta e a lista pela janela da extensão (como já era o uso normal). O resto do código é idêntico (conferido por hash) |
| Saída | `Downloads\<pasta>\<empresa>\RFB_<CNPJ>.pdf`, relatório, `Com_Pendencia_<CNPJ>.pdf`, `Erro_de_Procuracao_<CNPJ>.pdf` |
| Situação | **Verificado aqui**: arquivos completos, Central OK. **Depende do destino**: extensão, certificado, e-CAC |

## 5. PARCELAMENTO SIMPLIFICADO

| Item | Valor |
|---|---|
| Finalidade | Por `cnpj;nome`: troca o perfil no e-CAC, consulta o Parcelamento Simplificado e salva o PDF da consulta ou do DARF |
| Origem | `Desktop\ATM_simplicado_1\parcelamento_simplificado` (v1.8.5) + `README.md` |
| Pasta no pacote | `Automacoes\Parcelamento_Simplificado` |
| Tipo na Central | `chrome`, `"anonima": true` (abre `...autenticacao/login#ps_abrir_interface` em janela anônima; a extensão abre a janela dela sozinha) |
| Dependências | só Chrome |
| Extensão Chrome | `parcelamento_simplificado` (v1.8.5) — ligar **Permitir no modo anônimo** |
| Não incluídos | `_backup_*` (versões antigas) e a cópia duplicada `ATM_simplicado_1\Retirar_Auto_Infracao` (não usada pela Central) |
| Saída | `Downloads\<pasta>\<empresa>\<CNPJ>.pdf`; `RELATORIO_PROBLEMAS_<data-hora>.txt` |
| Situação | **Verificado aqui**: arquivos completos, Central OK. **Depende do destino**: extensão + anônimo, certificado, e-CAC |

## 6. REGULARIDADE FISCAL PE (E-FISCO)

| Item | Valor |
|---|---|
| Finalidade | Certidão de Regularidade Fiscal estadual (SEFAZ-PE, e-Fisco) para CPF, CNPJ e IE, em lote |
| Origem | `Desktop\ATM_REGULARIDADE_FISCAL_PE\regularidade_fiscal_pe` (v0.7.0, do repositório; ajuste de caminho Windows no `background.js`) |
| Pasta no pacote | `Automacoes\Regularidade_Fiscal_PE` |
| Tipo na Central | `chrome` com `"painel": "painel/painel.html"` (abre o painel da extensão; sem extensão, abre o site) |
| Dependências | só Chrome (testes com Node.js: `testes\unit.js`, `fila.test.js`, `background.test.js`) |
| Extensão Chrome | `EFisco_PE_Certidao_Regularidade_Fiscal` (v0.7.0) — ligar **Permitir no modo anônimo** (sem isso não inicia) |
| Saída | `Downloads\<PASTA>\CNPJ_<n>_CERTIDAO.pdf` (CPF_/IE_) |
| Situação | **Verificado aqui**: 52 testes da extensão passaram (17/11), Central OK. **Depende do destino**: extensão + anônimo; ainda não rodou no site real (CAPTCHA/Cloudflare exigem pessoa) |

## 7. CNDT – DÉBITOS TRABALHISTAS (TST)

| Item | Valor |
|---|---|
| Finalidade | Certidão Negativa de Débitos Trabalhistas (CNDT, do TST) em lote, por CNPJ (CPF também) |
| Origem | `%USERPROFILE%\Desktop\C_debito_Trabalhista` (de `ATM_debito_Trabalhista.zip`, v0.5.0; atualizada pelo autor para 0.6.0 e ajustada para 0.6.1 na integração) |
| Pasta no pacote | `Automacoes\CNDT_Debito_Trabalhista\C_debito_Trabalhista` |
| Tipo na Central | `chrome` (abre `https://cndt-certidao.tst.jus.br/gerarCertidao#cndt_abrir_interface`; o marcador faz a extensão abrir a janela dela) |
| Dependências | só Chrome (testes com Node.js: `node --test tests/`, 15 testes) |
| Extensão Chrome | `C_debito_Trabalhista` (v0.6.1) — não precisa de modo anônimo; permissões: downloads, storage, webNavigation, alarms |
| Novidade 0.6.0 | F5 entre CNPJs só depois do PDF salvo e confirmado; vigia do F5 (página diferente ou travada = nova tentativa, até 3, depois pausa); cada empresa consultada uma única vez; sem F5 depois da última |
| Captcha | **digitado pela pessoa** em cada empresa; a extensão só percebe que a pessoa parou de digitar e clica em Emitir Certidão. Nunca lê nem preenche a verificação |
| Andamento | `chrome.storage.local` por pasta principal (`cndt_andamento:<pasta>`): mesma pasta continua de onde parou |
| Saída | `Downloads\<pasta principal>\<EMPRESA>\CNDT_<EMPRESA>.pdf` (nomes iguais ganham ` - <CNPJ>`); `RELATORIO_CNDT_<data-hora>.txt` |
| Ajuste na integração (0.6.1, reaplicado sobre a 0.6.0) | ao abrir a próxima empresa, se a aba está na página de emissão só com outro "#", recarrega depois de trocar o marcador (a troca do "#" sozinha não recarrega e a empresa não começaria); sem aba da automação, reaproveita a aba do TST aberta pela Central |
| Situação | **Verificado aqui**: 15 testes passaram, Central `-Validar` pronta, extensão carregada e ligada no Chrome de origem. **Depende do destino**: extensão; emissão real (captcha pela pessoa) |

---

## 8. CND – PREFEITURA DO RECIFE

| Item | Valor |
|---|---|
| Finalidade | Certidão Negativa de Débitos Mercantis da Prefeitura do Recife (portal Recife em Dia) em lote, por CNPJ/CPF + Inscrição Mercantil |
| Origem | `%USERPROFILE%\Desktop\Certidao_Negativa_Debitos_Automacao` (de `Certidao_Negativa_Debitos_Automacao.zip`, v0.4.0, idêntica à pasta já carregada no Chrome). README escrito na integração (o ZIP não trazia) |
| Pasta no pacote | `Automacoes\CND_Prefeitura_Recife` (sem `logs\` e `evidencias\`; o CNPJ/nome de exemplo dos testes e da janela foram trocados por dados fictícios nesta cópia) |
| Tipo na Central | `chrome` com `"painel": "interface.html"`: abre a janela da extensão; o botão Iniciar dela abre o portal. Sem a extensão, abre o portal sem o marcador |
| Ponto de entrada próprio | `INICIAR.cmd` (abre o portal com `#cndrecife_localizar`; com lista salva, começa pela próxima empresa pendente) |
| Dependências | só Chrome (testes com Node.js: `node --test tests\lista.test.js`, 6 testes) |
| Extensão Chrome | `Certidao_Negativa_Debito_PrefeituraRecife` (v0.4.0) — não precisa de modo anônimo; permissões: storage, webNavigation, alarms, downloads; acesso só a `recifeemdia.recife.pe.gov.br` |
| Lista | `cnpj;im;nome_empresa` (IM até 7 dígitos, DV módulo 11 conferido) |
| Captcha | **digitado pela pessoa** (5 caracteres); a automação envia depois de 1,5 s sem digitar ou pelo botão da janela |
| Andamento | `chrome.storage.local` por pasta principal (`cndrecife_fila:<pasta>`) |
| Saída | `Downloads\<pasta principal>\<EMPRESA>\Certidao_<EMPRESA>.pdf` (nomes iguais ganham ` - <CNPJ>`) |
| Situação | **Verificado aqui**: 6 testes passaram, Central `-Validar` pronta, autoteste da janela, extensão carregada e ligada no Chrome de origem. **Depende do destino**: extensão; emissão real (CAPTCHA pela pessoa) |

---

## 9. CERTIDÃO NEGATIVA SEFAZ-PE

| Item | Valor |
|---|---|
| Finalidade | Certidão Negativa do Portal de Atendimento da SEFAZ-PE (`atendimento.sefaz.pe.gov.br`) em lote, por CNPJ, CPF ou Inscrição Estadual |
| Origem | `%USERPROFILE%\Desktop\Automacao_Sefaz-PE` (= `Automacao_Sefaz-PE.zip`, v0.6.1, conferidos por hash) |
| Pasta no pacote | `Automacoes\Certidao_Negativa_SEFAZ_PE` (sem os registros de `logs\`; `dados\config.json` sem certificado e sem pasta, `dados\lista_documentos.txt` vazio; CNPJ, nome, titular e número de série dos exemplos dos testes trocados por dados fictícios nesta cópia) |
| Tipo na Central | `terminal` |
| Ponto de entrada | `INTERFACE.cmd` → `node interface\servidor.js` (interface em `http://127.0.0.1:47831`). Linha de comando: `INICIAR.cmd` (`iniciar.js`; `--modo acesso` só faz o login) |
| Dependências | Node.js 20+ (sem `node_modules`: só módulos do próprio Node); PowerShell 5.1 + .NET (UI Automation) para a janela de certificados; nada é instalado |
| Extensão Chrome | `Retirar_Certidao_SEFAZ-PE` (v0.6.1) — ligar **Permitir no modo anônimo**; permissões: storage, scripting, downloads, debugger (só para gerar o PDF da página quando o site não oferece o PDF) |
| Certificado | escolhido na interface; na janela "Selecione um certificado" do Chrome o script clica pelo **número de série** (nunca pela posição) e em OK. PIN/senha: a pessoa digita. Desligável no bloco 1 |
| Lista | `CNPJ;<n>;NOME`, `CPF;<n>;NOME`, `IE;<n>;NOME` ou o antigo `cnpj;nome`; inválidas não impedem as demais |
| Dados do usuário (preservados nas atualizações) | `dados\config.json` e `dados\lista_documentos.txt` (o `instalar.ps1` não os sobrescreve se já existirem) |
| Saída | **Área de Trabalho**`\<pasta>\`: `<CNPJ>_NOME.pdf` / `CPF_<n>_NOME.pdf` / `IE_<n>_NOME.pdf` (sem sobrescrever: `_2`, `_3`), `resultado_certidoes_<data-hora>.xlsx`, `controle_execucao.json` (retomada), `relatorios\` |
| Testes | `node tests\<nome>.test.js` (10 arquivos, 196 verificações; sem portal, sem mover o mouse). Criam registros em `logs\`: apague depois |
| Situação | **Verificado aqui**: 196 verificações passaram (na pasta de origem e na cópia do pacote), Central `-Validar` pronta, autoteste da janela. **Depende do destino**: extensão + anônimo, certificado instalado, login gov.br e emissão real |

---

## Central de Automações

| Item | Valor |
|---|---|
| Origem | `%USERPROFILE%\Documents\Central_Automacoes` |
| Pasta no pacote | `Central_de_Automacoes` |
| Incluído | `Central.ps1` (portátil: `%CENTRAL_ATM%`), `Abrir Central.vbs`, `automacoes.json` e `ajuda.json` (caminhos relativos), `LEIA-ME.txt`, `README.md` |
| Não incluído | `backup_*`, `capturas\` (imagens de teste), `central_erros.log`, `preferencias.json` (tema; criado sozinho) |
| Situação | **Verificado aqui**: instalação de teste → `-Validar` com todas `pronto : sim`; autoteste da janela: um botão "?" por automação, busca, 4 filtros, ajuda por clique e teclado, temas claro/escuro, 3 tamanhos de janela, 0 automações iniciadas |

## Encontradas na máquina e NÃO incluídas (com motivo)

| Pasta | Motivo |
|---|---|
| `Downloads\ATM_PGFN` | cópia antiga/empacotada da PGFN (a ativa é `Downloads\Auto_PGFN`) |
| `Desktop\ATM_RFB` | idêntica a `Downloads\ATM_RFB` (hash) |
| `Desktop\Autom_Situacao_Fiscal`, `Documents\Autom_Situacao_Fiscal` | projeto completo da Situação Fiscal; extensão idêntica à incluída; ferramentas e README incluídos |
| `Desktop\ATM_SIT_FISCAL\Situacao_Fiscal_envio_ATM` (+ .zip) | pacote de envio antigo; extensão idêntica; `COMO_FUNCIONA.html` e `LEIA-ME_PRIMEIRO.txt` incluídos |
| `Desktop\ATM_simplificado`, `Documents\ATM_simplificado`, `Downloads\Auto_Simplificado`, `Downloads\Automacao_Simplificado`, `Documents\Codigo_ATT` | versões antigas/variantes do Parcelamento Simplificado (a Central usa `Desktop\ATM_simplicado_1`) |
| `Desktop\ATM_simplicado_1\Retirar_Auto_Infracao` | cópia duplicada do Retirar, não usada pela Central |
| `Downloads\Retirar_Auto_Infracao_backup_*`, `*\_backup_*`, `Central_Automacoes\backup_*` | backups |
| `Documents\robo` | robô Java antigo, excluído da Central por escolha do usuário (os `.bat` apontam para `C:\robo\executavel`, que não existe) |
| `Downloads\AGM_PARCELAMENTO_SIMPLIFICADO*`, `PARCELAMENTOS`, `Situacao_Fiscal_Assecon`, `teste_novembro` | pastas de **resultados** (PDFs de clientes), não são automações |
