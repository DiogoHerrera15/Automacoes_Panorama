# Requisitos do sistema

## Obrigatórios

| Requisito | Para quê | Versão mínima | Instalação (fonte oficial) |
|---|---|---|---|
| Windows 10 ou 11 (64 bits) | tudo | 10 | — |
| Windows PowerShell | Central e instaladores | 5.1 (já vem no Windows) | — |
| Google Chrome | todas as automações | atual | `winget install Google.Chrome` ou google.com/chrome |
| Node.js + npm | Retirar Auto-Infração (≥ 20), ATM RFB (≥ 18), Certidão Negativa SEFAZ-PE (sem pacotes npm) | **20** | `winget install OpenJS.NodeJS.LTS` ou nodejs.org |
| Python 3 | ATM RFB (Pillow, openpyxl) | 3.8 | `winget install Python.Python.3.12 --scope user` ou python.org (marcar "Add python.exe to PATH") |
| Internet | `npm ci`, `pip install` na instalação; sites das automações | — | — |
| Certificado digital da pessoa (A1 ou A3) instalado no Windows | PGFN, Situação Fiscal, Parcelamento Simplificado (e-CAC), Certidão Negativa SEFAZ-PE (gov.br) | — | pela própria pessoa |

## Já vêm no Windows (o verificador confere)

- .NET Framework 4 (`C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe`): só para recompilar `Automacao_PGFN.exe`.
- Windows Script Host (`wscript.exe`): abre a Central sem janela do PowerShell.
- UI Automation do Windows (.NET, usado pelo PowerShell): a Certidão Negativa SEFAZ-PE clica no certificado na janela
  "Selecione um certificado" do Chrome. Nada é instalado (não usa PyAutoGUI nem pywinauto).
- `robocopy`: cópia dos arquivos na instalação.

## Permissões

- Tudo roda no **usuário atual**, sem administrador. Exceção possível: o instalador do Node.js (MSI) pode pedir UAC.
- Política de execução: os scripts são chamados com `-ExecutionPolicy Bypass` (só naquele processo; nada global muda).

## Configurações do Chrome (feitas pela pessoa)

- `chrome://extensions`: Modo do desenvolvedor ligado; 9 extensões carregadas sem compactação; "Permitir no modo
  anônimo" em ATM RFB, PGFN, Parcelamento Simplificado, Regularidade Fiscal PE e Certidão Negativa SEFAZ-PE.
- `chrome://settings/downloads`: pasta padrão = `Downloads` do usuário; "Perguntar onde salvar cada arquivo" desligado.

## Portas locais usadas

| Porta | Quem |
|---|---|
| 47330 | interface do ATM RFB (`interface\servidor.js`) |
| 47331 | interface do Retirar Auto-Infração |
| 47321 | assistente do Retirar ↔ extensão (`GET /cnpj`) |
| 47831 | interface da Certidão Negativa SEFAZ-PE e ponte com a extensão `Retirar_Certidao_SEFAZ-PE` |

Todas em `127.0.0.1` (não abrem nada para a rede). Se outro programa usar a porta, a interface avisa ao abrir.

## Espaço em disco

Pacote ≈ 1 MB (ZIP). Depois de instalar: ≈ 75 MB por projeto Node com `node_modules` (Retirar, ATM RFB) e ≈ 30 MB da
`.venv` → ≈ 200 MB no total, mais os PDFs gerados (em Downloads; os da SEFAZ-PE na Área de Trabalho).

## Versões conferidas na máquina de origem (17 e 18/11/2026)

Windows 10 Pro 19045, PowerShell 5.1.19041, Chrome atual, Node.js v26.13.0 / npm 11.20.0, Python 3.15.2.
