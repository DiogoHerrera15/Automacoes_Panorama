// Lista inteira (nucleo/lote.js), planilha (nucleo/planilha.js) e a rota /registro do controle,
// numa pasta temporária. Uso: node tests/lote.test.js
'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const http = require('http');
const { execFileSync } = require('child_process');
const Lista = require('../nucleo/lista');
const Lote = require('../nucleo/lote');
const { criarControle } = require('../nucleo/controle');

function pdfDeTeste(texto) {
  return Buffer.from(['%PDF-1.4', '1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj', '2 0 obj << /Type /Pages /Kids [3 0 R] /Count 1 >> endobj', '3 0 obj << /Type /Page /Parent 2 0 R >> endobj', `% ${texto} ` + 'x'.repeat(1500), 'trailer << /Root 1 0 R >>', '%%EOF'].join('\n'), 'latin1');
}

// Lista mista com uma linha inválida e uma de 11 dígitos sem tipo (não pode virar CPF nem IE).
const TEXTO = [
  'CNPJ;11.444.777/0001-61;EMPRESA EXEMPLO PE LTDA',
  '11.222.333/0001-81;EMPRESA BETA',
  'CPF;529.982.247-25;PESSOA GAMA',
  'IE;0321418-40;EMPRESA DELTA',
  '52998224725;SEM TIPO',
  'CNPJ;11.111.111/1111-11;CNPJ INVALIDO',
].join('\n');

(async () => {
  const checks = [];
  const ok = (nome, cond, extra) => checks.push([nome, !!cond, extra]);
  const base = fs.mkdtempSync(path.join(os.tmpdir(), 'sefazpe-lote-'));
  try {
    const lista = Lista.interpretarLista(TEXTO);
    ok('lista: 4 válidos e 2 com problema (CPF e IE não confundidos)', lista.resumo.validos === 4 && lista.resumo.invalidos === 2 && lista.registros[2].tipo === 'CPF' && lista.registros[3].tipo === 'IE' && lista.registros[4].status === 'invalido');

    // ---- Lote: ordem, contadores, controle -----------------------------------------------------
    const pasta = path.join(base, 'R1'); fs.mkdirSync(pasta);
    const lote = Lote.criarLote({ pasta, registros: lista.registros });
    let r = lote.resumo();
    ok('total = registros válidos; inválidos contados à parte', r.total === 4 && r.pendente === 4 && r.invalido === 2 && r.percentual === 0);
    ok('arquivo de controle criado na pasta de resultados', fs.existsSync(path.join(pasta, 'controle_execucao.json')));
    const a1 = lote.proximo();
    ok('o primeiro é o da 1ª linha (ordem da lista) e fica "processando"', a1.linha === 1 && lote.resumo().processando === 1 && lote.resumo().atual.posicao === 1);
    const pdf1 = path.join(pasta, 'a.pdf'); fs.writeFileSync(pdf1, pdfDeTeste('um'));
    lote.concluirAtual({ status: 'sucesso', caminho: pdf1 });
    const a2 = lote.proximo();
    lote.concluirAtual({ status: 'erro', codigo: 'ERRO_EMISSAO', etapa: 'Aguardar a confirmação', mensagem: 'Certidão indisponível' });
    const a3 = lote.proximo();
    ok('a sequência segue a lista: 1, 2, 3', a2.linha === 2 && a3.linha === 3);
    r = lote.resumo();
    ok('contadores e percentual (2 de 4 finalizados = 50%) com o atual em processamento', r.sucesso === 1 && r.erro === 1 && r.processando === 1 && r.pendente === 1 && r.percentual === 50 && r.atual.posicao === 3);
    // Interrupção no meio do 3º registro.
    lote.interromper();
    const salvo = JSON.parse(fs.readFileSync(path.join(pasta, 'controle_execucao.json'), 'utf8'));
    const reg = (l) => salvo.registros.find((x) => x.linha === l);
    ok('controle guarda tipo, identificador, nome, status, tentativas, mensagem, caminho e data', reg(1).status === 'sucesso' && reg(1).caminho === pdf1 && reg(1).concluidoEm && reg(2).status === 'erro' && reg(2).mensagem === 'Certidão indisponível' && reg(2).tentativas === 1 && reg(3).status === 'pendente' && reg(1).tipo === 'CNPJ' && reg(1).identificador === '11444777000161' && reg(1).nome);

    // ---- Retomada --------------------------------------------------------------------------------
    const lote2 = Lote.criarLote({ pasta, registros: lista.registros });
    r = lote2.resumo();
    ok('retomada: o concluído com PDF válido é pulado; erro e interrompido voltam a pendente', r.sucesso === 1 && r.pendente === 3 && r.retomada.sucessoMantido === 1 && r.retomada.erroDeNovo === 1);
    ok('retomada: começa pelo primeiro ainda pendente (linha 2, o que deu erro)', lote2.proximo().linha === 2);
    fs.unlinkSync(pdf1);
    const lote3 = Lote.criarLote({ pasta, registros: lista.registros });
    ok('retomada: "concluído" cujo PDF sumiu volta a pendente (não é pulado sem o arquivo)', lote3.resumo().sucesso === 0 && lote3.resumo().retomada.sucessoSemPdf === 1);

    // ---- Planilha -------------------------------------------------------------------------------
    const pasta2 = path.join(base, 'R2'); fs.mkdirSync(pasta2);
    const l4 = Lote.criarLote({ pasta: pasta2, registros: lista.registros });
    l4.proximo(); l4.concluirAtual({ status: 'nao_encontrado', mensagem: 'Nenhum registro encontrado.' });
    const plan = l4.gerarPlanilha('2026-11-18_16h00');
    ok('planilha .xlsx criada na pasta de resultados', fs.existsSync(plan) && path.dirname(plan) === pasta2 && /resultado_certidoes_.*\.xlsx$/.test(plan));
    let entradas = '';
    try {
      entradas = execFileSync('powershell.exe', ['-NoProfile', '-Command', `Add-Type -AssemblyName System.IO.Compression.FileSystem; $z=[IO.Compression.ZipFile]::OpenRead('${plan}'); $s=New-Object IO.StreamReader($z.GetEntry('xl/worksheets/sheet1.xml').Open()); $x=$s.ReadToEnd(); $n=$z.Entries.Count; $z.Dispose(); $n; if ($x -match 'Não encontrado' -and $x -match 'EMPRESA DELTA' -and $x -match 'Inválido') { 'conteudo-ok' }`], { encoding: 'utf8', windowsHide: true });
    } catch (e) { entradas = e.message; }
    ok('planilha é um ZIP íntegro (aberto pelo .NET) com status, nomes e linhas inválidas', /6\s+conteudo-ok/.test(entradas), entradas.trim());

    // ---- Ponte /registro de ponta a ponta --------------------------------------------------------
    const linhas = [];
    const registro = { escrever: (tag, mensagem, nivel) => linhas.push({ tag, mensagem, nivel }), adicionarArquivo() {}, removerArquivo() {} };
    const pasta3 = path.join(base, 'R3'); fs.mkdirSync(pasta3);
    const controle = criarControle({ registro, abrirNavegador: false, selecionarCertificado: () => ({ fim: new Promise(() => {}), parar() {} }) });
    const srv = http.createServer((req, res) => { if (!controle.tratarPonte(req, res)) { res.writeHead(404); res.end(); } });
    await new Promise((ok_) => srv.listen(47994, '127.0.0.1', ok_));
    const pedir = (c, corpo) => fetch('http://127.0.0.1:47994' + c, { method: corpo ? 'POST' : 'GET', headers: { 'Content-Type': 'application/json', Origin: 'chrome-extension://abc' }, body: corpo ? JSON.stringify(corpo) : undefined }).then((x) => x.json());
    try {
      const lote5 = Lote.criarLote({ pasta: pasta3, registros: lista.registros });
      const ini = controle.iniciar({ modo: 'certidao_negativa', config: { pastaResultados: pasta3 }, lote: lote5, intervaloSegundos: 5 });
      const s = await pedir('/sessao');
      ok('a sessão leva o 1º registro e a posição na lista (1/4, intervalo 5 s)', ini.ok && s.config.registro.linha === 1 && s.config.lote.total === 4 && s.config.lote.posicao === 1 && s.config.lote.intervaloMs === 5000);
      await pedir('/reivindicar', { token: s.token, tabId: 3 });
      // Ocorrência de recuperação e captura da página no registro atual.
      await pedir('/evento', { token: s.token, tipo: 'ocorrencia', ocorrencia: { etapa: 'Clicar em "Pesquisar"', codigo: 'ETAPA_DEMORADA', problema: 'passou de 120 s', acao: 'Recarregando a página e refazendo este registro (tentativa 2/3).', tentativa: '1/3', decorridoSeg: 125 } });
      const jpg = Buffer.concat([Buffer.from([0xFF, 0xD8, 0xFF, 0xE0]), Buffer.alloc(200, 1), Buffer.from([0xFF, 0xD9])]);
      const ev = await pedir('/evidencia', { token: s.token, base64: jpg.toString('base64') });
      const at = controle.estado().lote.itens.find((i) => i.linha === 1);
      ok('ocorrência entra no histórico do registro (etapa, problema, ação, tentativa) e a captura vai para relatorios\\falhas', at.historico.length === 1 && at.historico[0].tentativa === '1/3' && /Recarregando/.test(at.historico[0].acao) && ev.ok && fs.existsSync(ev.caminho) && ev.caminho.includes(path.join('relatorios', 'falhas')) && at.evidencia === ev.caminho);
      const naoJpg = await pedir('/evidencia', { token: s.token, base64: Buffer.from('<html>').toString('base64') });
      ok('captura que não é imagem JPEG é recusada', !naoJpg.ok);      // 1º: PDF salvo pelo computador → sucesso; resposta traz o 2º.
      await pedir('/arquivo', { token: s.token, via: 'blob', base64: pdfDeTeste('reg1').toString('base64'), nomeSite: 'EMPRESA EXEMPLO PE LTDA' });
      const p1 = await pedir('/registro', { token: s.token, situacao: 'sucesso' });
      ok('após o 1º com PDF salvo: vem o 2º, sem novo login nem novo Iniciar', p1.ok && p1.proximo && p1.proximo.linha === 2 && p1.lote.posicao === 2 && p1.intervaloMs === 5000);
      // 2º: a página diz "sucesso", mas nenhum PDF deste registro chegou → erro (nunca sucesso).
      const p2 = await pedir('/registro', { token: s.token, situacao: 'sucesso' });
      ok('"sucesso" sem PDF deste registro salvo vira ERRO (o PDF do anterior não conta)', p2.proximo && p2.proximo.linha === 3 && controle.estado().lote.itens.find((i) => i.linha === 2).status === 'erro');
      // 3º (CPF): erro de um registro → a lista continua.
      const p3 = await pedir('/registro', { token: s.token, situacao: 'erro', codigo: 'BOTAO_EMITIR_AUSENTE', etapa: 'Clicar em "Emitir Certidão"', mensagem: 'Certidão indisponível' });
      ok('erro de um registro: anotado e o próximo (IE) vem em seguida', p3.proximo && p3.proximo.tipo === 'IE');
      const meio = controle.estado().lote;
      ok('estado da interface: contadores, percentual e registro atual', meio.total === 4 && meio.sucesso === 1 && meio.erro === 2 && meio.processando === 1 && meio.percentual === 75 && meio.atual.posicao === 4 && meio.atual.tipo === 'IE');
      const p4 = await pedir('/registro', { token: s.token, situacao: 'nao_encontrado', mensagem: 'Nenhum registro encontrado.' });
      let xml = '';
      try { xml = execFileSync('powershell.exe', ['-NoProfile', '-Command', `Add-Type -AssemblyName System.IO.Compression.FileSystem; $z=[IO.Compression.ZipFile]::OpenRead('${p4.planilha}'); $s=New-Object IO.StreamReader($z.GetEntry('xl/worksheets/sheet1.xml').Open()); $x=$s.ReadToEnd(); $z.Dispose(); if ($x -match 'Recuperações' -and $x -match 'ETAPA_DEMORADA|passou de 120 s' -and $x -match 'Tempo') { 'ok-recuperacao' }`], { encoding: 'utf8', windowsHide: true }); } catch (e) { xml = e.message; }
      ok('planilha final tem tempo, recuperações (horário, etapa, problema, ação) e captura', /ok-recuperacao/.test(xml), xml.trim());
      ok('último registro: fim da lista, planilha gerada na pasta', p4.ok && p4.proximo === null && p4.planilha && fs.existsSync(p4.planilha) && p4.resumo.sucesso === 1 && p4.resumo.erro === 2 && p4.resumo.naoEncontrado === 1);
      ok('relatório final no registro (PROCESSAMENTO FINALIZADO e contagens)', linhas.some((l) => l.mensagem === 'PROCESSAMENTO FINALIZADO') && linhas.some((l) => l.mensagem === 'Certidões salvas: 1') && linhas.some((l) => /Registros não encontrados: 1/.test(l.mensagem)));
      const pdfs = fs.readdirSync(pasta3).filter((f) => f.endsWith('.pdf'));
      ok('um PDF por registro com sucesso, com o nome do registro certo', pdfs.length === 1 && pdfs[0] === '11.444.777_0001-61_EMPRESA_EXEMPLO_PE_LTDA.pdf', pdfs.join(', '));
      await pedir('/evento', { token: s.token, tipo: 'status', status: 'concluido' });
    } finally {
      srv.close();
    }

    // Parada no meio: o registro atual volta a pendente no controle.
    const pasta4 = path.join(base, 'R4'); fs.mkdirSync(pasta4);
    const c2 = criarControle({ registro, abrirNavegador: false, selecionarCertificado: () => ({ fim: new Promise(() => {}), parar() {} }) });
    c2.iniciar({ modo: 'certidao_negativa', config: { pastaResultados: pasta4 }, lote: Lote.criarLote({ pasta: pasta4, registros: lista.registros }) });
    c2.comando('parar');
    const ctl = JSON.parse(fs.readFileSync(path.join(pasta4, 'controle_execucao.json'), 'utf8'));
    ok('Parar no meio: nada fica "processando" no controle (retomada refaz o atual)', !ctl.registros.some((x) => x.status === 'processando'));
    const pasta5 = path.join(base, 'R5'); fs.mkdirSync(pasta5);
    const l5 = Lote.criarLote({ pasta: pasta5, registros: lista.registros });
    while (l5.proximo()) l5.concluirAtual({ status: 'nao_encontrado' });
    const c3 = criarControle({ registro, abrirNavegador: false });
    const ini3 = c3.iniciar({ modo: 'certidao_negativa', config: { pastaResultados: pasta5 }, lote: Lote.criarLote({ pasta: pasta5, registros: lista.registros }) });
    ok('tudo já processado: Iniciar avisa que não há pendentes (não refaz nada)', !ini3.ok && /Nada pendente/.test(ini3.erro));
  } finally {
    fs.rmSync(base, { recursive: true, force: true });
  }
  let falhas = 0;
  for (const [nome, passou, extra] of checks) { console.log(passou ? 'ok   ' : 'FALHA', nome, passou || !extra ? '' : `→ ${extra}`); if (!passou) falhas++; }
  console.log(`\n${checks.length - falhas}/${checks.length} verificações passaram.`);
  process.exit(falhas ? 1 : 0);
})();
