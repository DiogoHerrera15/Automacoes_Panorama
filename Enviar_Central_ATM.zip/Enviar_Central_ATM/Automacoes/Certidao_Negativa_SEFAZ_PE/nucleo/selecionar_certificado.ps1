﻿# Seleção do certificado na janela NATIVA do Chrome "Selecione um certificado".
#
# Essa janela não faz parte da página: a extensão não a enxerga. Este script usa a API de
# acessibilidade do Windows (UI Automation, a mesma dos leitores de tela) para:
#   1. encontrar a janela pelo título e ler as linhas (titular, emissor, número de série);
#   2. identificar a linha do certificado escolhido na interface PELO NÚMERO DE SÉRIE
#      (ou, se a janela não mostrar o número, por titular + emissor, desde que seja única);
#   3. mover o cursor REAL do Windows, suavemente, até a linha e até o botão "OK";
#   4. conferir, imediatamente antes de cada clique, que o elemento sob o cursor é o esperado;
#   5. clicar em "OK" e esperar a janela fechar.
#
# Nunca escolhe outro certificado, nunca usa a posição da linha na lista como critério, não
# digita PIN/senha e não acessa chave privada. Se a identificação não for segura, não clica e
# devolve "manual". Mexer o mouse ou apertar ESC durante o controle cancela na hora.
#
# Saída: uma linha JSON por evento ({"tipo":"progresso"|"resultado", ...}).
# Uso de teste: -LinhasTeste '<json>' só executa a correspondência (sem janela nem mouse).

param(
  [string]$Serial = '',
  [string]$Titular = '',
  [string]$Emissor = '',
  [string]$Documento = '',      # CPF/CNPJ do titular (só dígitos), conferido com "TITULAR:CPF" da linha
  [string]$PaginasTeste = '',   # teste da busca com rolagem (lista simulada, sem janela nem mouse)
  [ValidateSet('lento', 'normal', 'rapido')][string]$Velocidade = 'normal',
  [int]$EsperaJanela = 60,
  [switch]$SomenteVerificar,
  [string]$LinhasTeste = '',
  # Só para teste de validação: termina clicando em "Cancelar" em vez de "OK" (nada é autenticado).
  [ValidateSet('OK', 'Cancelar')][string]$BotaoFinal = 'OK'
)

$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

function Emitir([string]$tipo, [string]$mensagem, [hashtable]$extra = @{}) {
  $o = [ordered]@{ tipo = $tipo; mensagem = $mensagem }
  foreach ($k in $extra.Keys) { $o[$k] = $extra[$k] }
  [Console]::Out.WriteLine(($o | ConvertTo-Json -Compress -Depth 5))
  [Console]::Out.Flush()
}

function Normalizar([string]$s) {
  if (-not $s) { return '' }
  $d = $s.Normalize([Text.NormalizationForm]::FormD)
  $sb = New-Object Text.StringBuilder
  foreach ($c in $d.ToCharArray()) {
    if ([Globalization.CharUnicodeInfo]::GetUnicodeCategory($c) -ne [Globalization.UnicodeCategory]::NonSpacingMark) { [void]$sb.Append($c) }
  }
  return (($sb.ToString() -replace '\s+', ' ').Trim()).ToLowerInvariant()
}

# "01:23:45..." / "0123 45..." / "000123..." → "012345..." (só para comparar números de série)
function SerialLimpo([string]$s) {
  return (($s -replace '[\s:.-]', '').ToUpperInvariant()).TrimStart('0')
}

# Mascara o CPF que aparece no titular ("NOME:12345678900" → "NOME:***...00") nos registros.
function Mascarar([string]$s) {
  return ($s -replace '(:\d{3})\d{6}(\d{2})', '$1******$2')
}

# ---- Correspondência (pura, testável com -LinhasTeste) ---------------------------------------
# $linhas: lista de @{ textos = @('...', '...') }. Devolve @{ indice; criterio } ou @{ indice = -1; motivo }.
# Os outros dados visíveis da linha NÃO contradizem o certificado escolhido? (o Chrome mostra
# "TITULAR:CPF", o emissor e a série; a validade não aparece nessa janela)
function DadosConferem($textos, [string]$titular, [string]$emissor, [string]$documento) {
  $junto = Normalizar ($textos -join ' | ')
  $doc = ($documento -replace '\D', '')
  if ($doc) {
    foreach ($t in $textos) {
      if ($t -match ':\s*(\d{11}|\d{14})\b' -and $Matches[1] -ne $doc) { return 'o CPF/CNPJ da linha é outro' }
    }
  }
  $emi = Normalizar $emissor
  $temEmissor = @($textos | Where-Object { (Normalizar $_) -match '^ac |autoridade|certifica' }).Count -gt 0
  if ($emi -and $temEmissor -and -not $junto.Contains($emi)) { return 'o emissor da linha é outro' }
  $tit = Normalizar $titular
  if ($tit -and $doc -and -not $junto.Contains($tit)) { return 'o titular da linha é outro' }
  return $null
}

# $linhas: lista de @{ textos }. Devolve @{ indice; criterio } ou @{ indice = -1; motivo; continuar }.
# "continuar" = vale rolar a lista e procurar mais (o certificado pode estar fora da área visível).
function Corresponder($linhas, [string]$serial, [string]$titular, [string]$emissor, [string]$documento = '') {
  $alvo = SerialLimpo $serial
  $tit = Normalizar $titular
  $emi = Normalizar $emissor
  $porSerial = @()
  $algumSerialLegivel = $false
  $porNome = @()
  $recusada = $null
  for ($i = 0; $i -lt $linhas.Count; $i++) {
    $textos = @($linhas[$i].textos)
    foreach ($t in $textos) {
      if ($t -match '^[0-9A-Fa-f][0-9A-Fa-f\s:.-]{7,}$') {
        $algumSerialLegivel = $true
        if ($alvo -and (SerialLimpo $t) -eq $alvo) {
          $contra = DadosConferem $textos $titular $emissor $documento
          if ($contra) { $recusada = $contra } else { $porSerial += $i }
        }
      }
    }
    $junto = Normalizar ($textos -join ' | ')
    if ($tit -and $emi -and $junto.Contains($tit) -and $junto.Contains($emi)) { $porNome += $i }
  }
  $porSerial = @($porSerial | Select-Object -Unique)
  if ($porSerial.Count -eq 1) { return @{ indice = $porSerial[0]; criterio = 'número de série' } }
  if ($porSerial.Count -gt 1) { return @{ indice = -1; motivo = 'mais de uma linha com o mesmo número de série' } }
  if ($recusada) { return @{ indice = -1; motivo = "a linha com o número de série tem dados diferentes do escolhido ($recusada)" } }
  if ($algumSerialLegivel) { return @{ indice = -1; continuar = $true; motivo = 'nenhuma linha com o número de série do certificado escolhido' } }
  # A janela não mostra números de série legíveis: aceita titular + emissor só se for único.
  if ($porNome.Count -eq 1) { return @{ indice = $porNome[0]; criterio = 'titular + emissor (número de série não visível)' } }
  if ($porNome.Count -gt 1) { return @{ indice = -1; motivo = 'mais de um certificado com o mesmo titular e emissor e sem número de série visível' } }
  return @{ indice = -1; continuar = $true; motivo = 'nenhuma linha com o titular e o emissor do certificado escolhido' }
}

# ---- Busca com rolagem (0.6.2) ------------------------------------------------------------------
# A lista pode ter mais certificados do que cabem na área visível. A busca lê as linhas VISÍVEIS,
# compara, e, se não achar, rola a lista (roda do mouse físico, só dentro da área da lista):
# primeiro para baixo até o fim, depois para cima até o início. Para quando acha, quando a
# rolagem não traz nenhuma linha nova (início/fim da lista) ou no limite de passos. Linhas já
# analisadas não são analisadas de novo. As funções de leitura e de rolagem são passadas por
# parâmetro: na janela real usam UI Automation + mouse; no teste (-PaginasTeste), uma lista
# simulada.
#   $ler   = { devolve @( @{ textos; elemento? } ) das linhas visíveis }
#   $rolar = { param($sentido) +1 = para baixo, -1 = para cima }
function BuscarCertificado($ler, $rolar, [string]$serial, [string]$titular, [string]$emissor, [string]$documento, [int]$maxPassos = 40) {
  $vistos = New-Object 'System.Collections.Generic.HashSet[string]'
  $rolagens = 0
  $ultimoMotivo = $null
  foreach ($sentido in @(1, -1)) {
    $anterior = $null
    for ($passo = 0; $passo -le $maxPassos; $passo++) {
      $linhas = @(& $ler)
      $assinatura = (@($linhas | ForEach-Object { @($_.textos) -join ' | ' }) -join ' || ')
      # Fim da lista neste sentido: a rolagem não mudou nada na área visível (início/fim).
      if ($passo -gt 0 -and $assinatura -eq $anterior) { break }
      $anterior = $assinatura
      $novas = @($linhas | Where-Object { $vistos.Add((@($_.textos) -join ' | ')) })
      # Só analisa de novo quando há linhas que ainda não tinham sido vistas.
      if ($passo -eq 0 -or $novas.Count) {
        $m = Corresponder $linhas $serial $titular $emissor $documento
        if ($m.indice -ge 0) { return @{ encontrado = $true; linha = $linhas[$m.indice]; criterio = $m.criterio; analisados = $vistos.Count; rolagens = $rolagens } }
        $ultimoMotivo = $m.motivo
        if (-not $m.continuar) { return @{ encontrado = $false; motivo = $m.motivo; analisados = $vistos.Count; rolagens = $rolagens; definitivo = $true } }
      }
      & $rolar $sentido
      $rolagens++
    }
  }
  return @{ encontrado = $false; motivo = "$ultimoMotivo (lista inteira percorrida: $($vistos.Count) certificado(s) analisado(s))"; analisados = $vistos.Count; rolagens = $rolagens }
}

if ($LinhasTeste) {
  # JSON em base64 (UTF-8), para não depender de aspas na linha de comando.
  $json = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($LinhasTeste))
  # No PowerShell 5.1, ConvertFrom-Json entrega o array inteiro como um só item: desembrulha.
  $linhas = @(($json | ConvertFrom-Json) | ForEach-Object { $_ })
  $r = Corresponder $linhas $Serial $Titular $Emissor $Documento
  Emitir 'resultado' 'teste de correspondência' @{ indice = $r.indice; criterio = $r.criterio; motivo = $r.motivo }
  exit 0
}

if ($PaginasTeste) {
  # Simulação da busca com rolagem: { linhas: [...todas, em ordem], visiveis: N, inicio: k, passo: p }
  $sim = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($PaginasTeste)) | ConvertFrom-Json
  $todas = @($sim.linhas | ForEach-Object { $_ })
  $script:pos = [int]$sim.inicio
  $script:leituras = 0
  $script:rolagensSim = @()
  $ler = {
    $script:leituras++
    $fimV = [Math]::Min($todas.Count, $script:pos + [int]$sim.visiveis) - 1
    if ($fimV -lt $script:pos) { return @() }
    return @($todas[$script:pos..$fimV] | ForEach-Object { @{ textos = @($_.textos); indice = [array]::IndexOf($todas, $_) } })
  }
  $rolar = {
    param($sentido)
    $script:rolagensSim += $sentido
    $script:pos = [Math]::Max(0, [Math]::Min($todas.Count - [int]$sim.visiveis, $script:pos + $sentido * [int]$sim.passo))
  }
  $r = BuscarCertificado $ler $rolar $Serial $Titular $Emissor $Documento
  Emitir 'resultado' 'teste de busca com rolagem' @{ encontrado = $r.encontrado; indice = $(if ($r.encontrado) { $r.linha.indice } else { -1 }); criterio = $r.criterio; motivo = $r.motivo; analisados = $r.analisados; rolagens = ($script:rolagensSim -join ','); leituras = $script:leituras }
  exit 0
}

# ---- Windows: DPI, mouse, teclado ---------------------------------------------------------------
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class SefazpeNativo {
  [StructLayout(LayoutKind.Sequential)] public struct PONTO { public int X; public int Y; }
  [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
  [DllImport("user32.dll")] public static extern bool SetProcessDpiAwarenessContext(IntPtr valor);
  [DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
  [DllImport("user32.dll")] public static extern bool GetCursorPos(out PONTO p);
  [DllImport("user32.dll")] public static extern void mouse_event(uint flags, uint dx, uint dy, uint data, UIntPtr extra);
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
  [DllImport("user32.dll")] public static extern short GetAsyncKeyState(int tecla);
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, IntPtr pid);
  [DllImport("kernel32.dll")] public static extern uint GetCurrentThreadId();
  [DllImport("user32.dll")] public static extern bool AttachThreadInput(uint de, uint para, bool juntar);
  [DllImport("user32.dll")] public static extern bool BringWindowToTop(IntPtr h);
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int modo);
  [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr h);
  [DllImport("user32.dll")] public static extern IntPtr WindowFromPoint(PONTO p);
  [DllImport("user32.dll")] public static extern IntPtr GetAncestor(IntPtr h, uint tipo);

  // Janela de topo (GA_ROOT) que recebe um clique no ponto (x, y).
  public static IntPtr JanelaDeTopoNoPonto(int x, int y) {
    PONTO p; p.X = x; p.Y = y;
    IntPtr h = WindowFromPoint(p);
    return h == IntPtr.Zero ? IntPtr.Zero : GetAncestor(h, 2);
  }

  // Traz a janela do Chrome para a frente. O Windows só deixa o processo que está "em primeiro
  // plano" trocar a janela da frente; por isso a entrada desta linha de execução é ligada
  // temporariamente à da janela atual (técnica padrão de AttachThreadInput).
  public static bool TrazerParaFrente(IntPtr h) {
    if (h == IntPtr.Zero) return false;
    if (IsIconic(h)) ShowWindow(h, 9); // SW_RESTORE
    IntPtr frente = GetForegroundWindow();
    if (frente == h) return true;
    uint atual = GetCurrentThreadId();
    uint deFrente = GetWindowThreadProcessId(frente, IntPtr.Zero);
    bool ligado = deFrente != 0 && deFrente != atual && AttachThreadInput(atual, deFrente, true);
    try { BringWindowToTop(h); SetForegroundWindow(h); }
    finally { if (ligado) AttachThreadInput(atual, deFrente, false); }
    return GetForegroundWindow() == h;
  }
}
'@
# Coordenadas em pixels físicos (escala de exibição de 125%, 150%... já considerada).
try { [void][SefazpeNativo]::SetProcessDpiAwarenessContext([IntPtr](-4)) } catch { try { [void][SefazpeNativo]::SetProcessDPIAware() } catch { } }

Add-Type -AssemblyName UIAutomationClient, UIAutomationTypes
$AE = [System.Windows.Automation.AutomationElement]
$TS = [System.Windows.Automation.TreeScope]
$CT = [System.Windows.Automation.ControlType]

$PERFIS = @{
  lento  = @{ min = 900; max = 2200; antes = @(250, 500); clique = @(400, 800) }
  normal = @{ min = 600; max = 1500; antes = @(150, 350); clique = @(300, 600) }
  rapido = @{ min = 350; max = 900;  antes = @(80, 180);  clique = @(200, 400) }
}
$PERFIL = $PERFIS[$Velocidade]
$rnd = New-Object System.Random
function Entre($a, $b) { return $a + $rnd.NextDouble() * ($b - $a) }

class Interrompido : System.Exception { Interrompido([string]$m) : base($m) { } }

$script:ultimoX = $null
$script:ultimoY = $null

function VerificarInterrupcao {
  if ([SefazpeNativo]::GetAsyncKeyState(0x1B) -band 0x8000) { throw [Interrompido]::new('ESC pressionado') }
  if ($null -ne $script:ultimoX) {
    $p = New-Object SefazpeNativo+PONTO
    [void][SefazpeNativo]::GetCursorPos([ref]$p)
    if ([Math]::Abs($p.X - $script:ultimoX) -gt 6 -or [Math]::Abs($p.Y - $script:ultimoY) -gt 6) { throw [Interrompido]::new('o mouse foi movido por você') }
  }
}

# Movimento humanizado do cursor real: curva Bézier, aceleração/desaceleração (minimum-jerk),
# quadros irregulares; verifica a cada quadro se você assumiu o mouse.
function MoverAte([double]$x1, [double]$y1) {
  $p = New-Object SefazpeNativo+PONTO
  [void][SefazpeNativo]::GetCursorPos([ref]$p)
  $x0 = [double]$p.X; $y0 = [double]$p.Y
  $script:ultimoX = $p.X; $script:ultimoY = $p.Y
  Start-Sleep -Milliseconds ([int](Entre $PERFIL.antes[0] $PERFIL.antes[1]))
  $dx = $x1 - $x0; $dy = $y1 - $y0
  $dist = [Math]::Sqrt($dx * $dx + $dy * $dy)
  if ($dist -lt 2) { return }
  $dur = [Math]::Min($PERFIL.max, [Math]::Max($PERFIL.min, $PERFIL.min + 220 * [Math]::Log($dist / 40 + 1, 2))) * (Entre 0.9 1.1)
  $nx = -$dy / $dist; $ny = $dx / $dist
  $amp = [Math]::Min(90, $dist * (Entre 0.06 0.18)) * $(if ($rnd.NextDouble() -lt 0.5) { -1 } else { 1 })
  $c1x = $x0 + $dx * 0.28 + $nx * $amp; $c1y = $y0 + $dy * 0.28 + $ny * $amp
  $c2x = $x0 + $dx * 0.72 + $nx * $amp * 0.45; $c2y = $y0 + $dy * 0.72 + $ny * $amp * 0.45
  $inicio = [DateTime]::UtcNow
  while ($true) {
    VerificarInterrupcao
    $t = [Math]::Min(1.0, ([DateTime]::UtcNow - $inicio).TotalMilliseconds / $dur)
    $k = $t * $t * $t * (10 + $t * (-15 + 6 * $t))
    $u = 1 - $k
    $x = $u * $u * $u * $x0 + 3 * $u * $u * $k * $c1x + 3 * $u * $k * $k * $c2x + $k * $k * $k * $x1
    $y = $u * $u * $u * $y0 + 3 * $u * $u * $k * $c1y + 3 * $u * $k * $k * $c2y + $k * $k * $k * $y1
    $xi = [int][Math]::Round($x); $yi = [int][Math]::Round($y)
    [void][SefazpeNativo]::SetCursorPos($xi, $yi)
    $script:ultimoX = $xi; $script:ultimoY = $yi
    if ($t -ge 1) { break }
    Start-Sleep -Milliseconds ([int](Entre 12 22))
  }
}

function CentroDe($el) {
  $r = $el.Current.BoundingRectangle
  if ($r.IsEmpty -or $r.Width -lt 2 -or $r.Height -lt 2) { return $null }
  return @{ x = $r.X + $r.Width / 2; y = $r.Y + $r.Height / 2 }
}

# O clique no ponto (x, y) vai cair no alvo, sem outra janela por cima?
# Teste REAL (18/11/2026): no diálogo do Chrome, a consulta de acessibilidade por ponto
# (AutomationElement.FromPoint) devolve a ÁREA DA PÁGINA que fica embaixo do diálogo, porque o
# Chrome desenha o diálogo dentro da mesma janela do Windows. Por isso a conferência é:
#   1. a janela do Windows que recebe o clique no ponto é exatamente a janela do Chrome que
#      contém o diálogo (nenhuma outra janela por cima); e
#   2. o ponto está dentro do retângulo atual do alvo, e o alvo dentro do diálogo aberto.
# (Se o FromPoint devolver o próprio alvo, também vale.)
$script:dialogoAtual = $null
function Contem($r, [double]$x, [double]$y) { return ($x -ge $r.Left -and $x -le $r.Right -and $y -ge $r.Top -and $y -le $r.Bottom) }
function SobOCursorE($alvo, [double]$x, [double]$y) {
  try {
    $r = $alvo.Current.BoundingRectangle
    if (-not (Contem $r $x $y)) { return $false }
    if ($script:hwndChrome -ne [IntPtr]::Zero) {
      $topo = [SefazpeNativo]::JanelaDeTopoNoPonto([int][Math]::Round($x), [int][Math]::Round($y))
      if ($topo -ne $script:hwndChrome) { return $false }
    }
    if ($script:dialogoAtual) {
      $d = $script:dialogoAtual.Current
      if ($d.IsOffscreen -or -not (Contem $d.BoundingRectangle $x $y)) { return $false }
    }
    if ($script:hwndChrome -ne [IntPtr]::Zero -and $script:dialogoAtual) { return $true }
    # Sem identificador da janela: exige o próprio alvo (ou filho) sob o cursor.
    $idAlvo = ($alvo.GetRuntimeId() -join ',')
    for ($n = $AE::FromPoint((New-Object System.Windows.Point($x, $y))); $n; $n = $Andar.GetParent($n)) {
      if (($n.GetRuntimeId() -join ',') -eq $idAlvo) { return $true }
    }
  } catch { }
  return $false
}

# Nome da janela de topo que está no ponto (para o diagnóstico "o que está por cima").
function JanelaNoPonto([double]$x, [double]$y) {
  try {
    $h = [SefazpeNativo]::JanelaDeTopoNoPonto([int]$x, [int]$y)
    if ($h -ne [IntPtr]::Zero) { return $AE::FromHandle($h).Current.Name }
    $n = $AE::FromPoint((New-Object System.Windows.Point($x, $y)))
    $raiz = $AE::RootElement.GetRuntimeId() -join ','
    while ($n) {
      $pai = $Andar.GetParent($n)
      if (-not $pai -or ($pai.GetRuntimeId() -join ',') -eq $raiz) { return $n.Current.Name }
      $n = $pai
    }
  } catch { }
  return '?'
}

$script:hwndChrome = [IntPtr]::Zero
function TrazerChromeParaFrente {
  if ($script:hwndChrome -eq [IntPtr]::Zero) { return $false }
  return [SefazpeNativo]::TrazerParaFrente($script:hwndChrome)
}

function Clicar($alvo) {
  $c = CentroDe $alvo
  if (-not $c) { throw 'o elemento não tem posição na tela' }
  [void](TrazerChromeParaFrente)
  MoverAte $c.x $c.y
  Start-Sleep -Milliseconds ([int](Entre $PERFIL.clique[0] $PERFIL.clique[1]))
  VerificarInterrupcao
  if (-not (SobOCursorE $alvo $c.x $c.y)) {
    # Outra janela por cima: traz o Chrome para a frente mais uma vez e confere de novo.
    [void](TrazerChromeParaFrente)
    Start-Sleep -Milliseconds 350
    $c = CentroDe $alvo
    if ($c) { MoverAte $c.x $c.y; Start-Sleep -Milliseconds 200; VerificarInterrupcao }
    if (-not $c -or -not (SobOCursorE $alvo $c.x $c.y)) {
      $porCima = if ($c) { JanelaNoPonto $c.x $c.y } else { '?' }
      throw "outra janela está por cima do diálogo (`"$porCima`"); o clique não foi feito"
    }
  }
  [SefazpeNativo]::mouse_event(0x0002, 0, 0, 0, [UIntPtr]::Zero)
  Start-Sleep -Milliseconds ([int](Entre 60 130))
  [SefazpeNativo]::mouse_event(0x0004, 0, 0, 0, [UIntPtr]::Zero)
}

# ---- Janela "Selecione um certificado" --------------------------------------------------------
# Estrutura REAL (lida no Chrome do usuário em 18/11/2026, Chrome em português):
#   Window "Google Chrome" (Chrome_WidgetWin_1, janela de topo)
#    └ Pane (BrowserRootView)
#       └ Window "Selecione um certificado" (RootView)        ← o diálogo fica DENTRO da janela do Chrome
#          └ ... DataGrid (TableView)
#               ├ DataItem (cabeçalho: Tema | Emissor | Serial)  ← sem SelectionItem
#               └ DataItem [Invoke, SelectionItem]               ← uma linha por certificado
#                    ├ DataItem "TITULAR:CPF"  ├ DataItem "AC ..."  └ DataItem "0123456789ABCDEF"
#          └ Button "OK" / "Cancelar" / "Informações do certificado" (MdTextButton)
# Erro da 0.4.2: a busca descia em TODO o conteúdo das janelas do Chrome e aceitou o texto
# "Selecione um certificado" da PÁGINA da interface (Document web). Agora: o título tem de ser
# de um elemento Window/Pane do próprio Chrome (nunca dentro de um Document) e o candidato só é
# aceito se tiver tabela de certificados E botão OK; senão a busca continua.
$TITULOS = @('selecione um certificado', 'selecionar um certificado', 'select a certificate', 'selecionar certificado')
$Andar = [System.Windows.Automation.TreeWalker]::ControlViewWalker

function DentroDePagina($el) {
  for ($n = $el; $n; $n = $Andar.GetParent($n)) {
    try { if ($n.Current.ControlType -eq $CT::Document) { return $true } } catch { return $true }
  }
  return $false
}

function TabelaDe($dialogo) {
  $cond = New-Object System.Windows.Automation.OrCondition(@(
    (New-Object System.Windows.Automation.PropertyCondition($AE::ControlTypeProperty, $CT::DataGrid)),
    (New-Object System.Windows.Automation.PropertyCondition($AE::ControlTypeProperty, $CT::Table)),
    (New-Object System.Windows.Automation.PropertyCondition($AE::ControlTypeProperty, $CT::List))
  ))
  return $dialogo.FindFirst($TS::Descendants, $cond)
}

# Um candidato é o diálogo de certificados se tiver a tabela e o botão OK.
function ValidarDialogo($el, $topo) {
  if (-not $el -or (DentroDePagina $el)) { return $null }
  if ((TabelaDe $el) -and (BotaoOk $el)) { return @{ janela = $el; topo = $topo } }
  return $null
}

function ProcurarJanela {
  $condTitulo = New-Object System.Windows.Automation.AndCondition(@(
    (New-Object System.Windows.Automation.OrCondition(@(
      (New-Object System.Windows.Automation.PropertyCondition($AE::ControlTypeProperty, $CT::Window)),
      (New-Object System.Windows.Automation.PropertyCondition($AE::ControlTypeProperty, $CT::Pane))
    ))),
    (New-Object System.Windows.Automation.OrCondition(@($TITULOS | ForEach-Object {
      New-Object System.Windows.Automation.PropertyCondition($AE::NameProperty, $_, [System.Windows.Automation.PropertyConditionFlags]::IgnoreCase)
    })))
  ))
  $cond = New-Object System.Windows.Automation.PropertyCondition($AE::ClassNameProperty, 'Chrome_WidgetWin_1')
  foreach ($w in $AE::RootElement.FindAll($TS::Children, $cond)) {
    try {
      # Diálogo como janela de topo (versões antigas do Chrome).
      if ($TITULOS -contains (Normalizar $w.Current.Name)) { $v = ValidarDialogo $w $w; if ($v) { return $v } }
      # Diálogo dentro da janela do Chrome (versões atuais). Só elementos Window/Pane do Chrome:
      # o texto de uma página (Text dentro de Document) nunca é aceito.
      foreach ($d in $w.FindAll($TS::Descendants, $condTitulo)) {
        $v = ValidarDialogo $d $w
        if ($v) { return $v }
      }
    } catch { }
  }
  return $null
}

function BotaoOk($dialogo) {
  $cond = New-Object System.Windows.Automation.PropertyCondition($AE::ControlTypeProperty, $CT::Button)
  foreach ($b in $dialogo.FindAll($TS::Descendants, $cond)) {
    if ((Normalizar $b.Current.Name) -eq 'ok') { return $b }
  }
  return $null
}

function BotaoChamado($dialogo, [string]$nome) {
  $cond = New-Object System.Windows.Automation.PropertyCondition($AE::ControlTypeProperty, $CT::Button)
  foreach ($b in $dialogo.FindAll($TS::Descendants, $cond)) {
    if ((Normalizar $b.Current.Name) -eq (Normalizar $nome)) { return $b }
  }
  return $null
}

function SuportaSelecao($el) {
  try { [void]$el.GetCurrentPattern([System.Windows.Automation.SelectionItemPattern]::Pattern); return $true } catch { return $false }
}

# Linhas = filhos DIRETOS da tabela que são selecionáveis (o cabeçalho não é). As células de cada
# linha (titular, emissor, série) viram os "textos" da linha — elas NÃO contam como linhas.
function LinhasDaJanela($dialogo) {
  $tabela = TabelaDe $dialogo
  if (-not $tabela) { return @() }
  $linhas = @()
  for ($l = $Andar.GetFirstChild($tabela); $l; $l = $Andar.GetNextSibling($l)) {
    $ct = $l.Current.ControlType
    if ($ct -ne $CT::DataItem -and $ct -ne $CT::ListItem -and $ct -ne $CT::TreeItem) { continue }
    if (-not (SuportaSelecao $l)) { continue }
    $textos = @($l.Current.Name)
    for ($c = $Andar.GetFirstChild($l); $c; $c = $Andar.GetNextSibling($c)) { if ($c.Current.Name) { $textos += $c.Current.Name } }
    $linhas += @{ elemento = $l; textos = @($textos | Where-Object { $_ } | Select-Object -Unique) }
  }
  return $linhas
}

# Linhas VISÍVEIS: dentro da área da lista (as que ficaram acima/abaixo, fora da rolagem, não
# podem ser clicadas e não contam como "vistas" ainda).
function LinhasVisiveis($dialogo) {
  $grade = TabelaDe $dialogo
  if (-not $grade) { return @() }
  $g = $grade.Current.BoundingRectangle
  return @(LinhasDaJanela $dialogo | Where-Object {
    try {
      $r = $_.elemento.Current.BoundingRectangle
      -not $_.elemento.Current.IsOffscreen -and -not $r.IsEmpty -and $r.Top -lt $g.Bottom - 2 -and $r.Bottom -gt $g.Top + 2
    } catch { $false }
  })
}

# Rola a lista de certificados com a roda do mouse FÍSICO, com o cursor no meio da área da lista
# (conferido: o ponto é do Chrome com o diálogo, nunca de outra janela). sentido: +1 = descer.
function RolarLista($dialogo, [int]$sentido) {
  $grade = TabelaDe $dialogo
  if (-not $grade) { throw 'a lista de certificados não está acessível' }
  $g = $grade.Current.BoundingRectangle
  $x = $g.X + $g.Width * 0.5
  $y = $g.Y + $g.Height * 0.5
  $topo = [SefazpeNativo]::JanelaDeTopoNoPonto([int]$x, [int]$y)
  if ($script:hwndChrome -ne [IntPtr]::Zero -and $topo -ne $script:hwndChrome) { throw 'outra janela está por cima da lista de certificados' }
  MoverAte $x $y
  VerificarInterrupcao
  $delta = -120 * $sentido # roda para baixo = valor negativo
  $dados = if ($delta -lt 0) { [uint32](4294967296 + $delta) } else { [uint32]$delta }
  [SefazpeNativo]::mouse_event(0x0800, 0, 0, $dados, [UIntPtr]::Zero) # MOUSEEVENTF_WHEEL
  Start-Sleep -Milliseconds 350
}

# A linha achada pode estar cortada na borda da lista: rola até o centro dela ficar dentro.
function GarantirLinhaVisivel($dialogo, $linha) {
  for ($i = 0; $i -lt 4; $i++) {
    $grade = TabelaDe $dialogo
    $g = $grade.Current.BoundingRectangle
    $c = CentroDe $linha.elemento
    if ($c -and $c.y -gt $g.Top + 4 -and $c.y -lt $g.Bottom - 4) { return $true }
    $sentido = if (-not $c -or $c.y -ge $g.Bottom - 4) { 1 } else { -1 }
    RolarLista $dialogo $sentido
  }
  return $false
}

function EstaSelecionada($linha) {
  try {
    $pad = $linha.GetCurrentPattern([System.Windows.Automation.SelectionItemPattern]::Pattern)
    return @{ suportado = $true; valor = $pad.Current.IsSelected }
  } catch { return @{ suportado = $false; valor = $false } }
}

function Diagnostico($dialogo) {
  $itens = @()
  foreach ($e in $dialogo.FindAll($TS::Descendants, [System.Windows.Automation.Condition]::TrueCondition)) {
    if ($itens.Count -ge 25) { break }
    $itens += ('{0}:"{1}"' -f $e.Current.ControlType.ProgrammaticName.Replace('ControlType.', ''), (Mascarar $e.Current.Name))
  }
  return ($itens -join ' | ')
}

# ---- Execução -------------------------------------------------------------------------------------
try {
  Emitir 'progresso' 'Aguardando a janela "Selecione um certificado" do Chrome...'
  $fim = [DateTime]::UtcNow.AddSeconds($EsperaJanela)
  $achado = $null
  while (-not $achado -and [DateTime]::UtcNow -lt $fim) {
    $achado = ProcurarJanela
    if (-not $achado) { Start-Sleep -Milliseconds 500 }
  }
  if (-not $achado) {
    Emitir 'resultado' "A janela de seleção de certificado não apareceu em $EsperaJanela s." @{ resultado = 'nao_encontrada' }
    exit 0
  }
  $dialogo = $achado.janela
  $script:dialogoAtual = $dialogo
  Start-Sleep -Milliseconds 600 # a janela termina de montar
  $linhas = @(LinhasDaJanela $dialogo)
  $ok = BotaoOk $dialogo
  $resumo = @($linhas | ForEach-Object { Mascarar ($_.textos -join ' / ') })
  $nomeTopo = ''
  try { $nomeTopo = ($achado.topo.Current.Name -replace ' - Google Chrome$', '') } catch { }
  Emitir 'progresso' "Janela de certificados identificada (Chrome: `"$nomeTopo`"): $($linhas.Count) certificado(s) listado(s)." @{ linhas = $resumo }
  Emitir 'progresso' 'Identificando o certificado configurado...'

  if ($SomenteVerificar) {
    Emitir 'resultado' 'Verificação concluída (nada foi clicado).' @{ resultado = 'verificado'; diagnostico = (Diagnostico $dialogo) }
    exit 0
  }
  if (-not $linhas.Count -or -not $ok) {
    Emitir 'resultado' 'Não consegui ler as linhas ou o botão OK da janela. Selecione o certificado manualmente.' @{ resultado = 'manual'; diagnostico = (Diagnostico $dialogo) }
    exit 0
  }

  try { $script:hwndChrome = [IntPtr]$achado.topo.Current.NativeWindowHandle } catch { }
  if (-not (TrazerChromeParaFrente)) { Emitir 'progresso' 'Aviso: o Windows não confirmou o Chrome na frente; a posição será conferida antes de cada clique.' }
  Start-Sleep -Milliseconds 300

  # Procura o certificado nas linhas visíveis e, se preciso, rolando a lista (0.6.2).
  $busca = BuscarCertificado { LinhasVisiveis $dialogo } { param($s) Emitir 'progresso' "Rolando a lista para $(if ($s -gt 0) { 'baixo' } else { 'cima' }) em busca do certificado..."; RolarLista $dialogo $s } $Serial $Titular $Emissor $Documento
  if (-not $busca.encontrado) {
    if (-not (BotaoOk $dialogo) -and -not (ProcurarJanela)) {
      Emitir 'resultado' 'A janela de certificados fechou durante a busca. Se ela abrir de novo, selecione o certificado manualmente.' @{ resultado = 'manual' }
      exit 0
    }
    Emitir 'resultado' "Certificado configurado não encontrado na lista ($($busca.motivo)). Selecione-o manualmente." @{ resultado = 'manual'; diagnostico = (Diagnostico $dialogo) }
    exit 0
  }
  if ($busca.rolagens) { Emitir 'progresso' "Certificado localizado depois de $($busca.rolagens) rolagem(ns) da lista ($($busca.analisados) certificado(s) analisado(s))." }
  $m = @{ criterio = $busca.criterio }
  $linhaAchada = $busca.linha
  if (-not (GarantirLinhaVisivel $dialogo $linhaAchada)) {
    Emitir 'resultado' 'O certificado foi encontrado, mas não ficou visível na lista para o clique. Selecione-o manualmente.' @{ resultado = 'manual' }
    exit 0
  }
  # Daqui em diante: as linhas atuais (para conferir que SÓ a escolhida fica selecionada).
  $linhas = @(LinhasDaJanela $dialogo)
  $idAchada = $linhaAchada.elemento.GetRuntimeId() -join ','
  $m.indice = -1
  for ($j = 0; $j -lt $linhas.Count; $j++) { if (($linhas[$j].elemento.GetRuntimeId() -join ',') -eq $idAchada) { $m.indice = $j } }
  if ($m.indice -lt 0) {
    Emitir 'resultado' 'A lista mudou durante a busca. Selecione o certificado manualmente.' @{ resultado = 'manual' }
    exit 0
  }
  $linha = $linhas[$m.indice].elemento
  Emitir 'progresso' "Certificado identificado por $($m.criterio): $(Mascarar ($linhas[$m.indice].textos -join ' / '))."

  # Só a linha identificada pode ficar selecionada: confere ela E as demais.
  function SelecaoCorreta {
    $s = EstaSelecionada $linha
    if (-not $s.suportado) { return @{ suportado = $false; valor = $true } }
    if (-not $s.valor) { return @{ suportado = $true; valor = $false } }
    for ($j = 0; $j -lt $linhas.Count; $j++) {
      if ($j -ne $m.indice -and (EstaSelecionada $linhas[$j].elemento).valor) { return @{ suportado = $true; valor = $false } }
    }
    return @{ suportado = $true; valor = $true }
  }

  $sel = SelecaoCorreta
  if (-not $sel.valor -or -not $sel.suportado) {
    Emitir 'progresso' 'Movendo o mouse do Windows até o certificado...'
    Clicar $linha
    Start-Sleep -Milliseconds 400
    $sel = SelecaoCorreta
    if ($sel.suportado -and -not $sel.valor) {
      # O clique físico não selecionou: seleciona a MESMA linha pela acessibilidade e confere.
      try { $linha.GetCurrentPattern([System.Windows.Automation.SelectionItemPattern]::Pattern).Select() } catch { }
      Start-Sleep -Milliseconds 300
      $sel = SelecaoCorreta
      if (-not $sel.valor) {
        Emitir 'resultado' 'O certificado não ficou selecionado depois do clique. Selecione manualmente.' @{ resultado = 'manual'; diagnostico = (Diagnostico $dialogo) }
        exit 0
      }
    }
  } else {
    Emitir 'progresso' 'O certificado correto já está selecionado na janela.'
  }

  # Última conferência antes do OK: a linha certa (e só ela) continua selecionada.
  $sel = SelecaoCorreta
  if (-not $sel.valor) {
    Emitir 'resultado' 'A seleção mudou antes do OK. Selecione manualmente.' @{ resultado = 'manual' }
    exit 0
  }
  $final = if ($BotaoFinal -eq 'OK') { $ok } else { BotaoChamado $dialogo 'Cancelar' }
  if (-not $final -or -not $final.Current.IsEnabled) {
    Emitir 'resultado' "O botão $BotaoFinal está ausente ou desabilitado. Selecione manualmente." @{ resultado = 'manual' }
    exit 0
  }
  Emitir 'progresso' "Confirmando seleção: movendo o mouse do Windows até o botão $BotaoFinal..."
  Clicar $final
  Emitir 'progresso' "$BotaoFinal clicado. Aguardando a janela fechar..."

  function JanelaFechou([int]$segundos) {
    $limite = [DateTime]::UtcNow.AddSeconds($segundos)
    while ([DateTime]::UtcNow -lt $limite) {
      try { if ($dialogo.Current.IsOffscreen) { return $true }; [void]$dialogo.Current.Name } catch { return $true }
      if (-not (ProcurarJanela)) { return $true }
      Start-Sleep -Milliseconds 400
    }
    return $false
  }
  $fechou = JanelaFechou 4
  if (-not $fechou) {
    # O clique não fechou a janela (foco em outra janela, por exemplo). A janela ainda está aberta
    # e a seleção continua correta: aciona o MESMO botão pela acessibilidade, uma única vez.
    if ((SelecaoCorreta).valor) {
      try { $final.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern).Invoke(); Emitir 'progresso' "A janela não fechou com o clique; botão $BotaoFinal acionado pela acessibilidade do Windows." } catch { }
      $fechou = JanelaFechou 10
    }
  }
  if ($fechou -and $BotaoFinal -eq 'OK') {
    Emitir 'resultado' "Certificado confirmado na janela do Chrome ($($m.criterio)). Se pedir PIN ou senha, digite você." @{ resultado = 'ok'; criterio = $m.criterio }
  } elseif ($fechou) {
    Emitir 'resultado' 'Teste concluído: certificado selecionado e janela fechada com Cancelar (nada foi autenticado).' @{ resultado = 'teste_cancelado'; criterio = $m.criterio }
  } else {
    Emitir 'resultado' "O $BotaoFinal foi clicado, mas a janela continua aberta. Confira e conclua manualmente." @{ resultado = 'manual' }
  }
} catch [Interrompido] {
  Emitir 'resultado' "Controle do mouse interrompido: $($_.Exception.Message). Conclua a seleção manualmente." @{ resultado = 'interrompido' }
} catch {
  Emitir 'resultado' "Erro na seleção nativa: $($_.Exception.Message). Selecione o certificado manualmente." @{ resultado = 'erro' }
}
