@echo off
rem Certidao_Negativa_Debito_PrefeituraRecife - abre o Chrome no portal Recife em Dia.
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0iniciar.ps1" %*
if errorlevel 1 pause
