# Certidao_Negativa_Debito_PrefeituraRecife - iniciador (Windows).
# Abre o Google Chrome no portal Recife em Dia com o marcador da automacao (#cndrecife_localizar).
# A extensao (instalada no Chrome) ve o marcador e executa a etapa: aguardar a pagina, achar o
# titulo e localizar o botao "Emitir Certidao" (sem clicar).
# Mesmo mecanismo da Central de Automacoes (tipo "chrome": Start-Process chrome.exe <url>).
#
# Uso: iniciar.ps1 [-Anonima]   (janela anonima exige "Permitir no modo anonimo" na extensao)

param([switch]$Anonima)

$ErrorActionPreference = 'Stop'
$URL = 'https://recifeemdia.recife.pe.gov.br/certidoesNegativasDebitos#cndrecife_localizar'
$AQUI = Split-Path -Parent $MyInvocation.MyCommand.Path
$PASTA_LOG = Join-Path $AQUI 'logs'
New-Item -ItemType Directory -Force -Path $PASTA_LOG | Out-Null
$ARQ_LOG = Join-Path $PASTA_LOG ('iniciador_' + (Get-Date -Format 'yyyy-MM-dd') + '.log')

function Log([string]$texto) {
  $linha = (Get-Date -Format 'HH:mm:ss') + ' ' + $texto
  Write-Host $texto
  Add-Content -LiteralPath $ARQ_LOG -Value $linha -Encoding UTF8
}

# Mesma busca da Central (Achar-Chrome): CHROME_PATH, Arquivos de Programas e AppData.
function Achar-Chrome {
  foreach ($base in @($env:CHROME_PATH, $env:ProgramFiles, ${env:ProgramFiles(x86)}, $env:LOCALAPPDATA)) {
    if (-not $base) { continue }
    $exe = if ($base -like '*.exe') { $base } else { Join-Path $base 'Google\Chrome\Application\chrome.exe' }
    if (Test-Path -LiteralPath $exe) { return $exe }
  }
  return $null
}

Log '[INICIANDO] Certidao_Negativa_Debito_PrefeituraRecife'
Log '[ETAPA 1] Iniciando navegador...'
$chrome = Achar-Chrome
if (-not $chrome) {
  Log '[ERRO] Google Chrome nao encontrado. Instale o Chrome ou defina a variavel CHROME_PATH com o caminho do chrome.exe.'
  exit 1
}
Log ('           Chrome: ' + $chrome)

Log '[ETAPA 2] Acessando portal Recife em Dia...'
$argumentos = if ($Anonima) { '--incognito "' + $URL + '"' } else { '"' + $URL + '"' }
try {
  Start-Process -FilePath $chrome -ArgumentList $argumentos | Out-Null
} catch {
  Log ('[ERRO] Nao foi possivel abrir o Chrome: ' + $_.Exception.Message)
  exit 1
}
Log ('           ' + $URL)
Log '[STATUS] Chrome aberto. As etapas 3 a 5 sao feitas pela extensao, na propria pagina'
Log '         (painel no canto inferior direito e console F12 com o prefixo [CND_RECIFE]).'
Log '         Se nada aparecer na pagina, confira se a extensao esta instalada e ligada (README, secao 2).'
exit 0
