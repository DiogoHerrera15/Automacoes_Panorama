// Teste ponta a ponta no GOOGLE CHROME, na página real do portal Recife em Dia, com a extensão
// carregada de verdade (perfil temporário; a extensão entra pelo protocolo de depuração,
// Extensions.loadUnpacked, porque o Chrome 137+ não aceita mais --load-extension).
// O formulário NUNCA é enviado: o teste não clica em Enviar nem aperta Enter. O texto posto no
// campo da verificação (cenário A) é um valor qualquer, só para testar o botão de confirmação.
//
// Uso (na pasta do projeto):  node tests\teste_fluxo_chrome.js
// Cenários:
//   A) janela > Iniciar > cursor clica em "Emitir Certidão" > preenche IM e CNPJ > espera o CAPTCHA:
//      sem recargas na espera; dados alterados avisados e preenchidos de novo; F5 na espera
//      preenche de novo; confirmação recusada sem os 5 caracteres e aceita com eles; nada enviado
//   B) página inicial sem o botão: 3 tentativas, falha controlada, nenhum clique
//   C) formulário devolve 503 na 1ª carga: recarrega o FORMULÁRIO e preenche na 2ª tentativa
//   D) formulário nunca fica completo (imagem da verificação não carrega): 3 tentativas e falha
//   E) página aberta sem o marcador: nada acontece
// Gera em evidencias\: cursor_em_movimento.png, dados_preenchidos_aguardando_captcha.png e janela_automacao.png.

const { spawn } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');
const assert = require('assert');

const RAIZ = path.resolve(__dirname, '..');
const EXT = path.join(RAIZ, 'Certidao_Negativa_Debito_PrefeituraRecife');
const URL_PAGINA = 'https://recifeemdia.recife.pe.gov.br/certidoesNegativasDebitos';
const URL_MARCADA = URL_PAGINA + '#cndrecife_localizar';
const CHROME = process.env.CHROME_PATH ||
  [process.env.ProgramFiles, process.env['ProgramFiles(x86)'], process.env.LOCALAPPDATA]
    .filter(Boolean).map((b) => path.join(b, 'Google', 'Chrome', 'Application', 'chrome.exe')).find((p) => fs.existsSync(p));
const espera = (ms) => new Promise((r) => setTimeout(r, ms));
const EVID = path.join(RAIZ, 'evidencias');
const LISTA_TESTE = [
  '11.222.333/0001-81;6733697;EMPRESA EXEMPLO RECIFE LTDA',
  '12345678000190;1234567;EMPRESA EXEMPLO A', // exemplo ilustrativo: CNPJ inválido, deve ser apontado e ignorado
].join('\n');

// ---- CDP pelo "pipe" (fd 3 = comandos, fd 4 = respostas; mensagens terminadas em \0) -----
let proc; let seq = 0; const pendentes = new Map(); const ouvintes = []; let resto = '';
function cdp(method, params = {}, sessionId) {
  const id = ++seq;
  proc.stdio[3].write(JSON.stringify({ id, method, params, sessionId }) + '\0');
  return new Promise((ok, falha) => pendentes.set(id, { ok, falha, method }));
}
function aoEvento(fn) { ouvintes.push(fn); return () => { const i = ouvintes.indexOf(fn); if (i >= 0) ouvintes.splice(i, 1); }; }
function receber(buf) {
  resto += buf.toString('utf8');
  let i;
  while ((i = resto.indexOf('\0')) >= 0) {
    const m = JSON.parse(resto.slice(0, i));
    resto = resto.slice(i + 1);
    if (m.id && pendentes.has(m.id)) {
      const p = pendentes.get(m.id); pendentes.delete(m.id);
      m.error ? p.falha(new Error(`${p.method}: ${m.error.message}`)) : p.ok(m.result);
    } else if (m.method) ouvintes.slice().forEach((f) => f(m));
  }
}
async function avaliar(sessao, expr) {
  const r = await cdp('Runtime.evaluate', { expression: expr, awaitPromise: true, returnByValue: true }, sessao);
  if (r.exceptionDetails) throw new Error(JSON.stringify(r.exceptionDetails).slice(0, 400));
  return r.result.value;
}

let SW; let EXT_ID;
async function sessaoDoServiceWorker() {
  for (let i = 0; i < 40; i++) {
    const { targetInfos } = await cdp('Target.getTargets');
    const sw = targetInfos.find((t) => t.type === 'service_worker' && t.url.startsWith(`chrome-extension://${EXT_ID}/`));
    if (sw) {
      const { sessionId } = await cdp('Target.attachToTarget', { targetId: sw.targetId, flatten: true });
      // O worker pode estar ainda iniciando: espera a API da extensão existir nele.
      for (let j = 0; j < 20; j++) {
        if (await avaliar(sessionId, 'typeof chrome !== "undefined" && !!chrome.storage').catch(() => false)) return sessionId;
        await espera(250);
      }
    }
    await espera(500);
  }
  throw new Error('service worker da extensão não encontrado');
}
async function estado() {
  SW = SW || await sessaoDoServiceWorker();
  try { return await avaliar(SW, 'chrome.storage.local.get(null)'); } catch (_) { SW = await sessaoDoServiceWorker(); return avaliar(SW, 'chrome.storage.local.get(null)'); }
}
const limparEstado = async () => { await estado(); await avaliar(SW, 'chrome.storage.local.clear().then(() => true)'); };
async function aguardar(cond, limite, passo = 400) {
  const fim = Date.now() + limite;
  for (;;) {
    const e = await estado();
    if (cond(e)) return e;
    if (Date.now() > fim) return e;
    await espera(passo);
  }
}
// Configura a fila direto no storage (cenários B a D; o A usa a janela de verdade).
async function configurarFila(texto) {
  const lista = require(path.join(EXT, 'lista.js')).lerLista(texto);
  await avaliar(SW, `chrome.storage.local.set({ cndrecife_config: ${JSON.stringify({ pasta: 'TESTE', texto, ...lista })} }).then(() => true)`);
}

async function anexar(targetId) {
  const { sessionId } = await cdp('Target.attachToTarget', { targetId, flatten: true });
  await cdp('Page.enable', {}, sessionId);
  await cdp('Network.enable', {}, sessionId);
  return sessionId;
}
// Acompanha uma aba: navegações, cargas por caminho (interceptação opcional) e POSTs ao site.
async function acompanhar(targetId, interceptar) {
  const sessionId = await anexar(targetId);
  const navegacoes = []; const cargas = {}; const posts = [];
  const sair = [];
  sair.push(aoEvento((m) => {
    if (m.sessionId !== sessionId) return;
    if (m.method === 'Page.frameNavigated' && !m.params.frame.parentId) navegacoes.push(m.params.frame.url);
    if (m.method === 'Network.requestWillBeSent' && m.params.request.method === 'POST') posts.push(m.params.request.url);
  }));
  if (interceptar) {
    await cdp('Fetch.enable', { patterns: [{ urlPattern: '*recifeemdia.recife.pe.gov.br*', resourceType: 'Document', requestStage: 'Response' }] }, sessionId);
    sair.push(aoEvento(async (m) => {
      if (m.sessionId !== sessionId || m.method !== 'Fetch.requestPaused') return;
      const caminho = new URL(m.params.request.url).pathname;
      cargas[caminho] = (cargas[caminho] || 0) + 1;
      try { await interceptar(m.params, cargas[caminho], sessionId, caminho); } catch (e) { console.error('interceptação:', e.message); }
    }));
  }
  return { targetId, sessionId, navegacoes, cargas, posts, fechar: async () => { sair.forEach((f) => f()); await cdp('Target.closeTarget', { targetId }).catch(() => {}); } };
}
async function abrirAba(url, interceptar) {
  const { targetId } = await cdp('Target.createTarget', { url: 'about:blank' });
  const aba = await acompanhar(targetId, interceptar);
  await cdp('Target.activateTarget', { targetId });
  await cdp('Page.navigate', { url }, aba.sessionId);
  return aba;
}
async function corpoReal(p, s) {
  const r = await cdp('Fetch.getResponseBody', { requestId: p.requestId }, s);
  return r.base64Encoded ? Buffer.from(r.body, 'base64').toString('utf8') : r.body;
}
const responder = (p, s, html, status = 200) => cdp('Fetch.fulfillRequest', {
  requestId: p.requestId, responseCode: status, responseHeaders: [{ name: 'Content-Type', value: 'text/html; charset=utf-8' }],
  body: Buffer.from(html, 'utf8').toString('base64'),
}, s);
const seguir = (p, s) => cdp('Fetch.continueRequest', { requestId: p.requestId }, s);
async function foto(sessao, nome) {
  const r = await cdp('Page.captureScreenshot', { format: 'png' }, sessao);
  const arq = path.join(EVID, nome);
  fs.writeFileSync(arq, Buffer.from(r.data, 'base64'));
  return arq;
}
const textos = (e) => (e.cndrecife_log || []).map((l) => l.texto);
const mostrar = (e, filtro = () => true) => textos(e).filter(filtro).forEach((t) => console.log('    | ' + t));
const campos = (s) => avaliar(s, `(() => ({ im: document.querySelector('#inscricao').value, doc: document.querySelector('#numeroDocumento').value,
  cap: document.querySelector('#captcha_code').value, path: location.pathname,
  painel: (() => { const h = document.querySelector('cndrecife-camada'); const a = h && h.shadowRoot.querySelector('.acoes'); return a && !a.hidden ? a.innerText : ''; })() }))()`);
const botaoPainel = (s, rotulo) => avaliar(s, `(() => { const h = document.querySelector('cndrecife-camada');
  const b = [...h.shadowRoot.querySelectorAll('.acoes button')].find(x => x.textContent === ${JSON.stringify(rotulo)}); b.click(); return true; })()`);

(async () => {
  assert.ok(CHROME, 'Google Chrome não encontrado (defina CHROME_PATH)');
  fs.mkdirSync(EVID, { recursive: true });
  const perfil = fs.mkdtempSync(path.join(os.tmpdir(), 'cndrecife_chrome_'));
  proc = spawn(CHROME, [
    '--remote-debugging-pipe', '--enable-unsafe-extension-debugging', `--user-data-dir=${perfil}`,
    '--no-first-run', '--no-default-browser-check', '--window-size=1366,900',
    // Sem janela por padrão (ninguém interfere na espera do CAPTCHA). VISIVEL=1 mostra a janela.
    ...(process.env.VISIVEL ? [] : ['--headless=new']),
    'about:blank',
  ], { stdio: ['ignore', 'ignore', 'ignore', 'pipe', 'pipe'] });
  proc.stdio[4].on('data', receber);
  const verificacoes = [];
  const ok = (cond, desc) => { assert.ok(cond, desc); verificacoes.push(desc); console.log('  ✔ ' + desc); };

  try {
    const versao = await cdp('Browser.getVersion');
    ok(/Chrome\//.test(versao.product), `navegador: ${versao.product}`);
    EXT_ID = (await cdp('Extensions.loadUnpacked', { path: EXT })).id;
    SW = await sessaoDoServiceWorker();
    const man = await avaliar(SW, 'chrome.runtime.getManifest()');
    ok(man.name === 'Certidao_Negativa_Debito_PrefeituraRecife', `extensão carregada no Chrome: ${man.name} ${man.version}`);
    await cdp('Target.setDiscoverTargets', { discover: true });

    // A) Fluxo completo pela janela -------------------------------------------------------------
    console.log('\nA) Janela > Iniciar > formulário preenchido > espera do CAPTCHA');
    await limparEstado();
    const { targetId: idJanela } = await cdp('Target.createTarget', { url: `chrome-extension://${EXT_ID}/interface.html` });
    const janela = await anexar(idJanela);
    await espera(1200);
    const novaAba = new Promise((ok2) => { const sair = aoEvento((m) => {
      if (m.method === 'Target.targetCreated' && m.params.targetInfo.type === 'page' && /recifeemdia/.test(m.params.targetInfo.url)) { sair(); ok2(m.params.targetInfo.targetId); }
    }); });
    const contagem = await avaliar(janela, `(() => { const p = document.getElementById('pasta'), l = document.getElementById('lista');
      p.value = 'CERTIDOES RECIFE TESTE'; l.value = ${JSON.stringify(LISTA_TESTE)};
      l.dispatchEvent(new Event('input')); return { contagem: document.getElementById('contagem').textContent,
      problemas: document.getElementById('problemas').innerText, caminho: document.getElementById('caminho').textContent }; })()`);
    ok(/^1 empresa\(s\) válida\(s\), 1 linha\(s\) com problema/.test(contagem.contagem) && /Linha 2: CNPJ inválido/.test(contagem.problemas),
      `janela: "${contagem.contagem}"; ${contagem.problemas}`);
    ok(contagem.caminho === 'Downloads\\CERTIDOES RECIFE TESTE\\EMPRESA EXEMPLO RECIFE LTDA\\Certidao_EMPRESA EXEMPLO RECIFE LTDA.pdf', `caminho previsto: ${contagem.caminho}`);
    await avaliar(janela, 'document.getElementById("iniciar").click(), true');
    const a = await acompanhar(await novaAba);
    // cursor em movimento
    let fotoMov = null;
    for (const t0 = Date.now(); Date.now() - t0 < 30000 && !fotoMov;) {
      const c = await avaliar(a.sessionId, `(() => { const c = document.getElementById('cndrecife-cursor'); return c && c.style.opacity === '1' && location.pathname; })()`).catch(() => null);
      if (c === '/certidoesNegativasDebitos') { await espera(350); fotoMov = await foto(a.sessionId, 'cursor_em_movimento.png'); }
      await espera(80);
    }
    // (depois de preencher, o cursor ainda vai até o campo do CAPTCHA antes de mostrar a mensagem)
    let e = await aguardar((x) => textos(x).some((t) => t.startsWith('[STATUS] Dados preenchidos com sucesso')) || x.cndrecife_resultado, 90000);
    mostrar(e, (t) => !/^\[ETAPA [2345]\]/.test(t));
    ok(e.cndrecife_execucao.fase === 'AGUARDANDO_CAPTCHA' && !e.cndrecife_execucao.encerrada, 'chegou à espera do CAPTCHA');
    ok(e.cndrecife_execucao.registro.nome === 'EMPRESA EXEMPLO RECIFE LTDA', `empresa em andamento: ${e.cndrecife_execucao.registro.nome}`);
    await espera(1500);
    let f = await campos(a.sessionId);
    ok(f.im === '6733697', `Inscrição Mercantil no campo: ${f.im}`);
    ok(f.doc === '11222333000181', `CPF/CNPJ no campo: ${f.doc} (11.222.333/0001-81; o site só aceita números)`);
    ok(f.cap === '', 'campo do CAPTCHA intocado (vazio)');
    ok(/Dados preenchidos com sucesso\. Resolva o CAPTCHA manualmente para continuar\./.test(f.painel), 'mensagem de espera do CAPTCHA no painel');
    const hora = (p) => new Date((e.cndrecife_log.find((l) => l.texto.startsWith(p)) || {}).hora).getTime();
    const tIM = hora('[ETAPA 9] Preenchendo') - hora('[ETAPA 8] Preenchendo');
    const tDoc = hora('[ETAPA 10] Conferindo') - hora('[ETAPA 9] Preenchendo');
    ok(tIM > 2500 && tDoc > 5000, `digitação humana: IM em ${(tIM / 1000).toFixed(1)} s, CNPJ em ${(tDoc / 1000).toFixed(1)} s (com cursor até o campo)`);
    const fila = Object.entries(e).find(([k]) => k.startsWith('cndrecife_fila:'));
    ok(fila && fila[0] === 'cndrecife_fila:CERTIDOES RECIFE TESTE' && fila[1]['11222333000181|6733697'].estado === 'aguardando_captcha', 'fila: empresa "aguardando_captcha", na fila da pasta escolhida');
    const fotoPreenchido = await foto(a.sessionId, 'dados_preenchidos_aguardando_captcha.png');

    // Espera sem ações indevidas: 70 s (mais que a vigia de 60 s), sem recarga, dados intactos.
    // Registra entradas REAIS de teclado/mouse (isTrusted) na página: a automação só gera
    // eventos sintéticos; um evento real aqui seria alguém mexendo na janela de teste.
    await avaliar(a.sessionId, `(() => { window.__reais = []; for (const t of ['keydown', 'mousedown', 'click'])
      document.addEventListener(t, (ev) => { if (ev.isTrusted) window.__reais.push(t + ' em ' + (ev.target.id || ev.target.tagName)); }, true); return true; })()`);
    const navAntes = a.navegacoes.length;
    const ESPERA_TESTE = Number(process.env.ESPERA_CAPTCHA_MS || 10000); // 70000 confere além da vigia de 60 s
    console.log(`    (aguardando ${ESPERA_TESTE / 1000} s para conferir que nada é recarregado na espera...)`);
    await espera(ESPERA_TESTE);
    f = await campos(a.sessionId);
    e = await estado();
    const reais = await avaliar(a.sessionId, 'window.__reais');
    ok(reais.length === 0, `nenhuma entrada real de teclado/mouse durante a espera${reais.length ? ': ' + reais.join(', ') : ''}`);
    ok(a.navegacoes.length === navAntes && f.im === '6733697' && f.doc === '11222333000181' && e.cndrecife_execucao.fase === 'AGUARDANDO_CAPTCHA',
      `em ${ESPERA_TESTE / 1000} s de espera: nenhuma recarga, dados intactos, ainda aguardando`);
    ok(a.posts.filter((u) => /consultarPdf/.test(u)).length === 0, 'nada enviado ao site (nenhum POST /consultarPdf)');

    // Dados alterados (como se a pessoa apagasse a IM): aviso e "Preencher os campos de novo".
    await avaliar(a.sessionId, `(() => { const c = document.querySelector('#inscricao'); c.value = ''; return true; })()`);
    await espera(1800);
    e = await estado();
    ok(textos(e).some((t) => t.startsWith('[AVISO] Os dados nos campos foram alterados')), 'alteração dos campos detectada e avisada');
    await botaoPainel(a.sessionId, 'Preencher os campos de novo');
    await aguardar((x) => textos(x).some((t) => t.startsWith('[ETAPA 11] Campos conferidos de novo')), 30000);
    f = await campos(a.sessionId);
    ok(f.im === '6733697' && f.doc === '11222333000181', 'IM preenchida de novo; CNPJ não foi digitado de novo (já estava certo)');

    // F5 durante a espera: preenche os mesmos dados de novo, sem trocar de empresa.
    await cdp('Page.reload', {}, a.sessionId);
    e = await aguardar((x) => textos(x).filter((t) => t.startsWith('[STATUS] Dados preenchidos com sucesso')).length >= 2, 60000);
    await espera(1500);
    f = await campos(a.sessionId);
    ok(textos(e).some((t) => t.startsWith('[RECUPERAÇÃO] A página foi recarregada')) && f.im === '6733697' && f.doc === '11222333000181' && e.cndrecife_execucao.fase === 'AGUARDANDO_CAPTCHA',
      'F5 na espera: mesmos dados preenchidos de novo, mesma empresa, continua aguardando');

    // "Enviar agora" com o campo da verificação vazio: recusado, nada enviado. (O teste nunca
    // digita no CAPTCHA: com 5 caracteres a automação ENVIA o formulário de verdade.)
    await botaoPainel(a.sessionId, 'Já digitei – enviar agora');
    await espera(500);
    f = await campos(a.sessionId);
    e = await estado();
    ok(/tem 0 caractere\(s\); o site exige 5/.test(f.painel) && e.cndrecife_execucao.fase === 'AGUARDANDO_CAPTCHA', 'envio recusado com o campo da verificação vazio');
    ok(a.posts.filter((u) => /consultarPdf/.test(u)).length === 0, 'nada enviado ao site');
    const fotoJanela = await (async () => { await cdp('Target.activateTarget', { targetId: idJanela }); await espera(800); return foto(janela, 'janela_automacao.png'); })();
    ok(fotoMov && fotoPreenchido && fotoJanela, `fotos: ${[fotoMov, fotoPreenchido, fotoJanela].map((x) => path.relative(RAIZ, x)).join(', ')}`);
    await a.fechar();
    await cdp('Target.closeTarget', { targetId: idJanela }).catch(() => {});

    // B) Sem o botão ------------------------------------------------------------------------
    console.log('\nB) Página inicial sem o botão');
    await limparEstado(); await configurarFila(LISTA_TESTE);
    const b = await abrirAba(URL_MARCADA, async (p, n, s, caminho) => {
      if (caminho !== '/certidoesNegativasDebitos') return seguir(p, s);
      const html = await corpoReal(p, s);
      await responder(p, s, html.replace(/<a href="\/emissaoCertidao\/4">Emitir Certidão<\/a>/, '<span>(removido no teste)</span>'));
    });
    e = await aguardar((x) => x.cndrecife_resultado, 120000);
    ok(e.cndrecife_resultado && e.cndrecife_resultado.ok === false && /ETAPA 5/.test(e.cndrecife_resultado.etapa) && e.cndrecife_resultado.tentativas === 3,
      `falha controlada na ${e.cndrecife_resultado && e.cndrecife_resultado.etapa} após 3 tentativas`);
    ok(!b.navegacoes.some((u) => /emissaoCertidao/.test(u)), 'nenhum clique em link do menu');
    await b.fechar();

    // C) Formulário com 503 na 1ª carga ----------------------------------------------------------
    console.log('\nC) Formulário devolve 503 na 1ª carga');
    await limparEstado(); await configurarFila(LISTA_TESTE);
    const c = await abrirAba(URL_MARCADA, async (p, n, s, caminho) => {
      if (caminho === '/emissaoCertidao/4' && n === 1) return responder(p, s, '<html><body><h1>503 Service Unavailable</h1></body></html>', 503);
      return seguir(p, s);
    });
    e = await aguardar((x) => x.cndrecife_execucao && x.cndrecife_execucao.fase === 'AGUARDANDO_CAPTCHA' || x.cndrecife_resultado, 120000);
    f = await campos(c.sessionId);
    ok(e.cndrecife_execucao.fase === 'AGUARDANDO_CAPTCHA' && e.cndrecife_execucao.tentativa === 2 && f.im === '6733697' && f.doc === '11222333000181',
      'recarregou só o formulário e preencheu na 2ª tentativa');
    ok(c.cargas['/certidoesNegativasDebitos'] === 1 && c.cargas['/emissaoCertidao/4'] === 2, `cargas: início ${c.cargas['/certidoesNegativasDebitos']}, formulário ${c.cargas['/emissaoCertidao/4']}`);
    await c.fechar();

    // D) Formulário nunca completo -------------------------------------------------------------
    console.log('\nD) Formulário sem a imagem da verificação');
    await limparEstado(); await configurarFila(LISTA_TESTE);
    const d = await abrirAba(URL_MARCADA, async (p, n, s, caminho) => {
      if (caminho !== '/emissaoCertidao/4') return seguir(p, s);
      const html = await corpoReal(p, s);
      await responder(p, s, html.replace(/src="\/captcha\/showImage[^"]*"/, 'src="/captcha/inexistente_teste.png"'));
    });
    e = await aguardar((x) => x.cndrecife_resultado, 200000);
    ok(e.cndrecife_resultado && e.cndrecife_resultado.ok === false && /ETAPA 7/.test(e.cndrecife_resultado.etapa) && e.cndrecife_resultado.tentativas === 3
      && /imagem da verificação/.test(e.cndrecife_resultado.motivo), `falha controlada: ${e.cndrecife_resultado && e.cndrecife_resultado.motivo}`);
    const filaD = e['cndrecife_fila:TESTE'] || {};
    ok(filaD['11222333000181|6733697'] && filaD['11222333000181|6733697'].estado === 'erro', 'empresa marcada "erro" na fila (continua para nova tentativa)');
    await d.fechar();

    // E) Sem o marcador ----------------------------------------------------------------------
    console.log('\nE) Página aberta sem o marcador');
    await limparEstado();
    const g = await abrirAba(URL_PAGINA);
    await espera(8000);
    e = await estado();
    const nada = await avaliar(g.sessionId, '!document.querySelector("cndrecife-camada") && !document.getElementById("cndrecife-cursor") && location.pathname');
    ok(nada === '/certidoesNegativasDebitos' && !e.cndrecife_resultado && !(e.cndrecife_log || []).length, 'nada acontece (sem cursor, sem clique, sem registro)');
    await g.fechar();

    console.log(`\nTODAS AS ${verificacoes.length} VERIFICAÇÕES PASSARAM (Google Chrome).`);
  } catch (err) {
    console.error('\nFALHOU:', err.message);
    try { mostrar(await estado()); } catch (_) {}
    process.exitCode = 1;
  } finally {
    try { await Promise.race([cdp('Browser.close'), espera(3000)]); } catch (_) {}
    await espera(1500);
    try { proc.kill(); } catch (_) {}
    try { fs.rmSync(perfil, { recursive: true, force: true }); } catch (_) {}
    process.exit();
  }
})();
