// Testes da leitura da lista (node --test tests/).
const test = require('node:test');
const assert = require('node:assert');
const L = require('../Certidao_Negativa_Debito_PrefeituraRecife/lista.js');

test('empresa do primeiro teste: CNPJ com e sem máscara, IM 6733697', () => {
  for (const doc of ['11.222.333/0001-81', '11222333000181', ' 11 222 333 0001 81 ']) {
    const { registros, invalidas } = L.lerLista(`${doc};6733697;EMPRESA EXEMPLO RECIFE LTDA`);
    assert.strictEqual(invalidas.length, 0, doc);
    assert.deepStrictEqual(
      { doc: registros[0].doc, tipo: registros[0].tipo, im: registros[0].im, pasta: registros[0].pasta, arquivo: registros[0].arquivo },
      { doc: '11222333000181', tipo: 'CNPJ', im: '6733697', pasta: 'EMPRESA EXEMPLO RECIFE LTDA', arquivo: 'Certidao_EMPRESA EXEMPLO RECIFE LTDA.pdf' },
    );
    assert.strictEqual(registros[0].docFormatado, '11.222.333/0001-81');
  }
});

test('IM: dígito verificador igual ao do site (modulo11)', () => {
  assert.ok(L.normalizarIM('6733697').ok);
  assert.ok(L.normalizarIM('673369-7').ok);
  assert.ok(!L.normalizarIM('6733698').ok);
  assert.ok(!L.normalizarIM('12345678').ok, 'mais de 7 dígitos');
  assert.ok(!L.normalizarIM('0000000').ok, 'zerada');
  assert.ok(!L.normalizarIM('67A3697').ok, 'letra');
  // zeros à esquerda são preservados (texto)
  const dv = L.dvInscricao('012345');
  assert.strictEqual(L.normalizarIM(`012345${dv}`).im, `012345${dv}`);
});

test('CPF aceito; CNPJ que perdeu zeros no Excel é completado', () => {
  const cpf = L.normalizarDocumento('529.982.247-25');
  assert.ok(cpf.ok && cpf.tipo === 'CPF' && cpf.doc === '52998224725');
  const c = L.normalizarDocumento('191000100'.padStart(9, '0') + '0'); // propositalmente inválido
  assert.ok(!c.ok);
  const semZeros = L.normalizarDocumento('6057223000171'); // 06.057.223/0001-71 sem o zero
  assert.ok(semZeros.ok && semZeros.doc === '06057223000171' && semZeros.aviso);
});

test('linhas inválidas não bloqueiam as demais, com número da linha e motivo', () => {
  const texto = [
    '11222333000181;6733697;EMPRESA EXEMPLO RECIFE LTDA',
    '',
    '12345678000190;1234567;EMPRESA EXEMPLO A', // CNPJ inválido
    '11222333000181;6733697;EMPRESA REPETIDA', // repetida
    '11222333000181;SEM NOME', // 2 campos
    '11222333000181;6733698;EMPRESA X', // IM inválida
    '529.982.247-25\t6733697\tPESSOA FISICA: TESTE / S/A', // TAB do Excel; nome com caracteres proibidos
  ].join('\r\n');
  const r = L.lerLista(texto);
  assert.deepStrictEqual(r.registros.map((x) => x.linha), [1, 7]);
  assert.deepStrictEqual(r.invalidas.map((x) => x.linha), [3, 5, 6]);
  assert.ok(/CNPJ inválido/.test(r.invalidas[0].motivo));
  assert.ok(/3 campos/.test(r.invalidas[1].motivo));
  assert.ok(/Inscrição Mercantil inválida/.test(r.invalidas[2].motivo));
  assert.strictEqual(r.avisos.length, 1);
  assert.strictEqual(r.registros[1].pasta, 'PESSOA FISICA- TESTE - S-A');
});

test('nomes iguais ganham o CPF/CNPJ na pasta', () => {
  const r = L.lerLista('11222333000181;6733697;MESMO NOME\n52998224725;6733697;Mesmo Nome');
  assert.deepStrictEqual(r.registros.map((x) => x.pasta), ['MESMO NOME - 11222333000181', 'Mesmo Nome - 52998224725']);
});

test('pasta principal segura, dentro de Downloads', () => {
  assert.deepStrictEqual(L.normalizarPastaPrincipal('CERTIDOES RECIFE'), { ok: true, pasta: 'CERTIDOES RECIFE' });
  assert.deepStrictEqual(L.normalizarPastaPrincipal('CLIENTES\\NOV:2026'), { ok: true, pasta: 'CLIENTES/NOV-2026' });
  assert.ok(!L.normalizarPastaPrincipal('C:\\Temp').ok);
  assert.ok(!L.normalizarPastaPrincipal('').ok);
  const { registros } = L.lerLista('11222333000181;6733697;EMPRESA EXEMPLO RECIFE LTDA');
  assert.strictEqual(L.caminhoArquivo('CERTIDOES RECIFE', registros[0]),
    'CERTIDOES RECIFE/EMPRESA EXEMPLO RECIFE LTDA/Certidao_EMPRESA EXEMPLO RECIFE LTDA.pdf');
});
