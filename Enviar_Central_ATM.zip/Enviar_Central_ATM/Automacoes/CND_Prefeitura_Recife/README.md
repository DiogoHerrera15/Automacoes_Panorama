# Certidao_Negativa_Debito_PrefeituraRecife: CND Mercantil (Recife em Dia), extensão do Chrome

> Este README foi escrito na integração com a Central de Automações (17/11/2026), a partir do código da versão
> **0.4.0**: o pacote recebido (`Certidao_Negativa_Debitos_Automacao.zip`) não trazia documentação.

Para cada empresa da lista (`cnpj;im;nome_empresa`), a automação abre o portal **Recife em Dia**
(https://recifeemdia.recife.pe.gov.br/certidoesNegativasDebitos), clica em **Emitir Certidão**, preenche a
**Inscrição Mercantil** e o **CPF/CNPJ**, espera **você digitar o CAPTCHA**, envia e salva o PDF como
`Certidao_<NOME DA EMPRESA>.pdf` na pasta da empresa. Depois passa para a próxima.

## 1. Como usar

1. Abra pela **Central de Automações** (cartão "CND – PREFEITURA DO RECIFE") ou clique no ícone da extensão: abre a
   **janela da automação**.
2. **Pasta principal** (ex.: `CERTIDOES RECIFE`; aceita subpastas com `\`). A janela mostra o caminho do 1º arquivo.
3. **Empresas**, uma por linha:
   ```
   11222333000181;6733697;NOME DA EMPRESA
   ```
   - CPF/CNPJ com ou sem pontuação (o site recebe só os números); zeros perdidos no Excel são completados.
   - IM: até 7 dígitos, com o dígito verificador conferido (mesma regra do site).
   - O TAB do Excel também separa. Linhas com problema são apontadas e ignoradas; repetidas (mesmo CPF/CNPJ e IM) também.
4. **Iniciar automação**: abre o portal e começa. Quando aparecer *"Dados preenchidos com sucesso. Resolva o CAPTCHA
   manualmente para continuar."*, digite os **5 caracteres** e pare: depois de **1,5 s** sem digitar, a automação clica
   em **Enviar** (ou use **"Já digitei o CAPTCHA – enviar"** na janela).
5. Com o PDF salvo e confirmado, espera 2 s e abre a próxima empresa. No fim: `[FIM] Lista processada: X de Y`.

Para refazer as empresas com erro, clique em **Iniciar automação** de novo com a mesma pasta (concluídas são puladas).

## 2. Instalar no Chrome

1. `chrome://extensions` > **Modo do desenvolvedor** > **Carregar sem compactação** > pasta
   `Certidao_Negativa_Debito_PrefeituraRecife`.
2. Confira a versão **0.4.0**. Ao atualizar os arquivos, use a **setinha de recarregar** (não remova: o andamento fica
   guardado no Chrome, por pasta principal).
3. Em `chrome://settings/downloads`, deixe **"Perguntar onde salvar cada arquivo"** desligado.

Sem a Central: `INICIAR.cmd` abre o portal com o marcador `#cndrecife_localizar` (com uma lista já salva, a
automação começa pela próxima empresa pendente; sem lista, abre a janela). Registro em `logs\`.

## 3. Onde os arquivos ficam

```
<pasta de downloads do Chrome>\<pasta principal>\<EMPRESA>\Certidao_<EMPRESA>.pdf
```

- Nomes iguais ganham ` - <CPF/CNPJ>` na pasta e no arquivo. Caracteres proibidos no Windows viram `-`.
- Nunca sobrescreve: repetido vira `(1)`. Só o download feito pelo portal **depois do Enviar** da empresa em
  andamento é renomeado; se o site abrir o PDF na aba, a extensão baixa esse endereço.
- A empresa só é concluída depois que o Chrome confirma o arquivo completo, não vazio e PDF.

## 4. Erros e recuperação

| Situação | O que faz |
|---|---|
| Página não carrega, erro de rede, 502/503, botão ou formulário não aparecem | Recarrega (até 3 tentativas por fase); depois, empresa com erro |
| CAPTCHA recusado | Digite de novo; até 3 envios, depois empresa com erro e segue para a próxima |
| Nenhum PDF em 90 s depois do Enviar | Volta a esperar o CAPTCHA (a página continua preenchida) |
| Espera do CAPTCHA | **Nada é recarregado sozinho**. Se recarregar a página, os mesmos dados são preenchidos de novo |
| Aba do portal fechada | A empresa fica com erro; Iniciar de novo continua |
| Página aberta sem o marcador e sem execução | Nada acontece |

## 5. Arquivos

```
Certidao_Negativa_Debitos_Automacao\
├── INICIAR.cmd / iniciar.ps1          abre o Chrome no portal com o marcador (opção -Anonima)
├── Certidao_Negativa_Debito_PrefeituraRecife\   a extensão (MV3; acesso só a recifeemdia.recife.pe.gov.br)
│   ├── config.js      endereços, seletores, tempos, limites
│   ├── lista.js       lista cnpj;im;nome, CPF/CNPJ, IM (módulo 11), nomes de pasta/arquivo
│   ├── background.js  fila, fases, recargas, vigia, download e renomeio do PDF
│   ├── content.js / pagina.js / cursor.js   fluxo na página, esperas, cursor e digitação humana
│   └── interface.html/.css/.js   a janela da automação
├── tests\             lista.test.js (node --test) e teste_fluxo_chrome.js (ponta a ponta, sem enviar)
├── evidencias\        capturas do teste
└── logs\              registro do iniciador
```

Testes: `node --test tests\lista.test.js` (6 testes, passaram na integração).
