// Configurações fixas da automação da Certidão Negativa de Débitos (Prefeitura do Recife).
// Tudo o que depende do portal Recife em Dia fica aqui, para que uma mudança no site exija
// ajuste em um lugar só.
//
// Carregado como content script (antes dos demais), pelo background.js (importScripts) e
// pelos testes do Node (require).

(function (raiz) {
  const CONFIG = {
    NOME: 'Certidao_Negativa_Debito_PrefeituraRecife',

    // Página inicial. O marcador depois do "#" não é enviado à Prefeitura: só diz à extensão
    // que esta aba foi aberta pela automação (abrir a página à mão não dispara nada).
    URL_INICIAL: 'https://recifeemdia.recife.pe.gov.br/certidoesNegativasDebitos',
    MARCADOR: 'cndrecife_localizar',
    HOST_ESPERADO: 'recifeemdia.recife.pe.gov.br',
    CAMINHO_ESPERADO: /^\/certidoesNegativasDebitos\/?$/i,

    // Seletores (ver README, seção "Como o botão é identificado").
    // O portal é Drupal: o conteúdo da página é o "article" do nó cujo atributo "about" é o
    // endereço da página. O menu superior tem dezenas de links "Emitir Certidão" (um para cada
    // tipo de certidão); só o link DENTRO desse article é o desta página.
    SELETORES: {
      titulo: 'h1.page-header',
      textoTitulo: /^\s*certid[aã]o\s+negativa\s+de\s+d[eé]bitos\s*$/i,
      artigo: 'article[about="/certidoesNegativasDebitos"]',
      // 1ª opção: link no corpo do article, pelo destino (/emissaoCertidao/<n>).
      botaoEmitir: 'article[about="/certidoesNegativasDebitos"] .field--name-body a[href*="/emissaoCertidao/"]',
      // 2ª opção (reserva): qualquer link com o texto, na região de conteúdo, fora dos menus.
      regiaoConteudo: '.region-content',
      textoBotaoEmitir: /^\s*emitir\s+certid[aã]o\s*$/i,
      hrefBotaoEmitir: /\/emissaoCertidao\/\d+\/?$/i,
      // Onde ficam os links de navegação, que NUNCA são o botão desta página.
      menus: 'nav, header, footer, [role="menu"], [role="menubar"], [role="menuitem"], .sf-menu, .menu',
      // Páginas de erro/manutenção do servidor (texto na página).
      textoErroServidor: /(503 service|502 bad gateway|504 gateway|service unavailable|erro interno|em manuten[cç][aã]o)/i,
    },

    // Esperas (ms). Todas com limite: nada fica esperando para sempre.
    TEMPOS: {
      intervaloVerificacao: 250, // de quanto em quanto tempo olha a página de novo
      esperaDocumento: 30000, // até document.readyState sair de "loading"
      esperaTitulo: 20000, // até o título "Certidão Negativa de Débitos" aparecer visível
      esperaBotao: 15000, // depois do título, até o link "Emitir Certidão" ficar visível
      estabilidade: 600, // o botão precisa continuar o mesmo e visível por este tempo
      esperaNavegacaoClique: 15000, // depois do clique, até o navegador começar a abrir a próxima tela
      // Vigia do background: se a página não responder neste tempo depois de aberta ou
      // recarregada (carga travada, erro de rede), recarrega.
      vigiaCarga: 60000,
    },

    // Recuperação: quantas vezes recarregar a página antes de desistir desta etapa.
    MAX_RECARGAS: 2,

    // Destaque visual do botão localizado (moldura por cima, sem mexer no conteúdo da página).
    DESTAQUE: { ativo: true, cor: '#e8590c', duracao: 0 }, // duracao 0 = fica até recarregar

    // Etapa 2: clicar em "Emitir Certidão" (com o cursor) e esperar a tela seguinte.
    CLICAR_EMITIR: true,

    // Tela seguinte: "Certidão Negativa de Débitos Mercantis" (/emissaoCertidao/<n>), com o
    // formulário de CPF/CNPJ e a verificação (captcha). Esta etapa só confirma que ela carregou.
    TELA_EMISSAO: {
      caminho: /^\/emissaoCertidao\/\d+\/?$/i,
      titulo: 'h1',
      textoTitulo: /certid[aã]o\s+negativa\s+de\s+d[eé]bitos/i,
      formulario: '#emitir-form',
      campoDocumento: '#numeroDocumento',
      campoInscricao: '#inscricao',
      campoCaptcha: '#captcha_code',
      imagemCaptcha: '#emitir-form img[id^="captcha_"], #emitir-form .emprel-captcha img',
      botaoEnviar: '#emitirPdf',
      carregando: '#loading', // "Carregando..." do site: precisa estar escondido
      esperaTela: 30000, // até a tela ficar completa depois de carregar
    },

    // Preenchimento (etapa 3). Os dois campos do site só aceitam números (máscara mNum):
    // a IM vai como está (até 7 dígitos) e o CPF/CNPJ só com os dígitos (11 ou 14).
    PREENCHIMENTO: {
      esperaCampo: 15000, // até o campo existir e aceitar digitação
      esperaMascara: 400, // depois da última tecla, para a máscara do site (setTimeout no keyup) agir
      tentativasPorCampo: 2, // digitação que não conferiu: apaga e digita de novo uma vez
    },

    // Espera do CAPTCHA (sempre pela pessoa; a automação nunca escreve nesse campo).
    CAPTCHA: {
      tamanho: 5, // o site exige 5 caracteres (validarCaptcha)
      intervaloVigia: 1000, // de quanto em quanto tempo confere se os dados continuam nos campos
      silencio: 1500, // com 5 caracteres, este tempo sem a pessoa digitar = terminou: clica em Enviar
      limiteResposta: 60000, // depois do Enviar, espera pela resposta do site (erro ou download)
      maxEnvios: 3, // envios recusados pelo site (ex.: caracteres errados); depois, erro e próxima empresa
      mensagem: 'Dados preenchidos com sucesso. Resolva o CAPTCHA manualmente para continuar.',
    },

    // Download da certidão (ETAPA 13). O site, depois do Enviar, abre /downloadPdf/<token>/.
    // O PDF é salvo em Downloads\<pasta principal>\<EMPRESA>\Certidao_<EMPRESA>.pdf.
    DOWNLOAD: {
      caminhoSite: /\/downloadPdf\//i,
      limite: 90000, // do Enviar até o PDF salvo; passou disso, volta a esperar o CAPTCHA
      pausaEntreEmpresas: 2000, // depois de salvar, antes de abrir a próxima empresa
    },

    // Digitação em ritmo humano (mesmos valores da CNDT, de estudos de digitação):
    // 220 a 420 ms entre teclas, 70 a 130 ms com a tecla apertada, pausas entre os blocos do
    // número (como quem lê o CNPJ em partes) e, de vez em quando, uma hesitação.
    DIGITACAO: {
      intervaloMin: 220,
      intervaloMax: 420,
      teclaApertadaMin: 70,
      teclaApertadaMax: 130,
      pausaEntreBlocosMin: 350,
      pausaEntreBlocosMax: 750,
      chancePausa: 0.1,
      pausaMin: 300,
      pausaMax: 650,
      esperaAntesDeDigitar: 500, // depois do clique no campo, antes da primeira tecla
    },

    // Cursor visual em velocidade humana (mesmo padrão da CNDT).
    // Tempo do movimento pela Lei de Fitts (MacKenzie, 1992): T = a + b * log2(D/L + 1).
    // Com a = 400 ms e b = 230 ms/bit, ir ~600 px até um link de ~95 px leva ~1,1 s.
    CURSOR: {
      ativo: true,
      cor: '#1f5fa8',
      fittsA: 400,
      fittsB: 230,
      duracaoMin: 700,
      duracaoMax: 2000,
      tremor: 1.2, // px de tremor da mão durante o movimento
      reacaoMin: 250, // tempo de reação antes de começar a mover
      reacaoMax: 600,
      limiteRolagem: 2000,
      paradaAntesDoCliqueMin: 250, // cursor parado sobre o alvo antes de clicar
      paradaAntesDoCliqueMax: 550,
      botaoApertadoMin: 80, // mousedown até mouseup
      botaoApertadoMax: 140,
    },

    PREFIXO_LOG: '[CND_RECIFE]',
    MAX_LINHAS_LOG: 300,
  };

  raiz.CNDRECIFE = raiz.CNDRECIFE || {};
  raiz.CNDRECIFE.CONFIG = CONFIG;
  if (typeof module !== 'undefined' && module.exports) module.exports = CONFIG;
})(typeof globalThis !== 'undefined' ? globalThis : self);
