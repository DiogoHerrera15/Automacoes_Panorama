// Cursor visual (mesmo padrão da automação da CNDT): uma seta desenhada por cima da página
// que vai, em velocidade humana, até onde a automação vai clicar. É só a parte visual; quem
// dispara o clique real é o pagina.js (clicar), que primeiro chama moverPara() e depois
// animarClique() no mesmo ponto do clique.
//
// - pointer-events: none: o cursor nunca recebe cliques nem atrapalha a pessoa ou o site.
// - Movimento pela Lei de Fitts, com curva leve, aceleração/desaceleração, uma pequena
//   passada do ponto e correção (como a mão de uma pessoa) e tempos levemente variáveis.
// - O movimento usa o relógio (não requestAnimationFrame): com a aba em segundo plano a
//   animação termina no tempo previsto e a automação não trava.
// - Qualquer falha do cursor é só registrada: nunca interrompe a automação.

(function (raiz) {
  const { CONFIG } = raiz.CNDRECIFE;
  const C = CONFIG.CURSOR;
  const ID = 'cndrecife-cursor';

  let caixa = null;
  let x = 0;
  let y = 0;
  let alvoParado = null; // { el, dx, dy }
  let movendo = false;

  const dormir = (ms) => new Promise((r) => setTimeout(r, ms));
  const aleatorio = (min, max) => min + Math.random() * (max - min);
  const suavizar = (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2); // ease-in-out

  function falha(onde, e) {
    console.warn(CONFIG.PREFIXO_LOG, `Cursor visual (${onde}) falhou; a automação segue sem ele.`, e);
  }

  function posicionar(nx, ny) {
    x = nx;
    y = ny;
    if (caixa) caixa.style.transform = `translate(${Math.round(x)}px, ${Math.round(y)}px)`;
  }

  function acompanhar() {
    if (movendo || !alvoParado || !alvoParado.el.isConnected) return;
    const r = alvoParado.el.getBoundingClientRect();
    posicionar(r.left + alvoParado.dx, r.top + alvoParado.dy);
  }

  function criar() {
    if (caixa && caixa.isConnected) return caixa;
    caixa = document.createElement('div');
    caixa.id = ID;
    caixa.setAttribute('aria-hidden', 'true');
    Object.assign(caixa.style, {
      position: 'fixed', left: '0', top: '0', width: '0', height: '0',
      zIndex: '2147483646', pointerEvents: 'none', transition: 'opacity .25s', opacity: '0',
    });
    // Seta (a ponta fica exatamente no ponto (0,0) = ponto do clique).
    caixa.innerHTML = `
      <svg width="26" height="30" viewBox="0 0 26 30" style="position:absolute;left:-3px;top:-2px;overflow:visible;filter:drop-shadow(1px 2px 2px rgba(0,0,0,.35))">
        <path d="M3 2 L3 24 L9 18.5 L13 27.5 L17 25.8 L13 17 L21 17 Z" fill="${C.cor}" stroke="#fff" stroke-width="1.6" stroke-linejoin="round"/>
      </svg>`;
    document.documentElement.appendChild(caixa);
    window.addEventListener('scroll', acompanhar, { passive: true, capture: true });
    window.addEventListener('resize', acompanhar, { passive: true });
    return caixa;
  }

  // Aparece num ponto inicial longe do alvo (parte de cima, à direita), para o
  // deslocamento até o elemento ser visível.
  function mostrar() {
    if (!C.ativo) return;
    try {
      const novo = !caixa || !caixa.isConnected;
      criar();
      if (novo) posicionar(Math.min(window.innerWidth - 60, window.innerWidth * aleatorio(0.55, 0.75)), window.innerHeight * aleatorio(0.12, 0.25));
      caixa.style.opacity = '1';
    } catch (e) {
      falha('mostrar', e);
    }
  }

  function esconder() {
    try {
      if (caixa) caixa.style.opacity = '0';
      alvoParado = null;
    } catch (e) {
      falha('esconder', e);
    }
  }

  // Ponto onde o cursor para (e onde o clique acontece): perto do centro, nunca exatamente
  // no mesmo pixel (uma pessoa não acerta sempre o centro).
  function pontoDoElemento(el, desvio) {
    const r = el.getBoundingClientRect();
    const d = desvio || { fx: 0.5, fy: 0.5 };
    const dx = r.width * d.fx;
    const dy = r.height * d.fy;
    return { dx, dy, x: r.left + dx, y: r.top + dy };
  }

  // Lei de Fitts: alvo longe ou pequeno = movimento mais demorado, ±10% de variação.
  function duracaoDoMovimento(distancia, larguraAlvo) {
    const bits = Math.log2(distancia / Math.max(8, larguraAlvo) + 1);
    const t = (C.fittsA + C.fittsB * bits) * (0.9 + Math.random() * 0.2);
    return Math.min(C.duracaoMax, Math.max(C.duracaoMin, t));
  }

  function dentroDaTela(el) {
    const r = el.getBoundingClientRect();
    return r.top >= 0 && r.left >= 0 && r.bottom <= window.innerHeight && r.right <= window.innerWidth;
  }

  // Rola até o elemento (se preciso) com rolagem suave e espera parar, com limite de tempo.
  async function rolarAte(el) {
    if (dentroDaTela(el)) return true;
    el.scrollIntoView({ block: 'center', inline: 'nearest', behavior: 'smooth' });
    const fim = Date.now() + C.limiteRolagem;
    let anterior = null;
    let estavel = 0;
    while (Date.now() < fim && estavel < 3) {
      await dormir(50);
      const topo = el.getBoundingClientRect().top;
      estavel = dentroDaTela(el) && anterior !== null && Math.abs(topo - anterior) < 0.5 ? estavel + 1 : 0;
      anterior = topo;
    }
    if (!dentroDaTela(el)) el.scrollIntoView({ block: 'center', inline: 'nearest', behavior: 'instant' });
    return dentroDaTela(el);
  }

  // Um trecho do movimento, de (x, y) até o ponto devolvido por `destinoFn`, em `duracao` ms.
  async function trecho(destinoFn, duracao, curva) {
    const x0 = x;
    const y0 = y;
    const inicio = Date.now();
    for (;;) {
      const destino = destinoFn(); // o elemento pode se mover durante a animação
      const t = Math.min(1, (Date.now() - inicio) / duracao);
      const k = suavizar(t);
      const arco = Math.sin(Math.PI * t) * curva;
      const len = Math.hypot(destino.x - x0, destino.y - y0) || 1;
      // pequeno tremor da mão, que some perto do fim
      const tremor = (1 - t) * C.tremor;
      posicionar(
        x0 + (destino.x - x0) * k + (-(destino.y - y0) / len) * arco + aleatorio(-tremor, tremor),
        y0 + (destino.y - y0) * k + ((destino.x - x0) / len) * arco + aleatorio(-tremor, tremor),
      );
      if (t >= 1) return destino;
      await dormir(16);
    }
  }

  // Leva o cursor até o elemento. Devolve o ponto final {x, y} (coordenadas da janela),
  // usado para o clique real. Com o cursor desligado ou com falha, só rola e devolve o ponto.
  async function moverPara(el) {
    await rolarAte(el);
    // Em campos de texto a pessoa clica mais à esquerda (onde começa o texto); nos demais, perto do centro.
    const campoTexto = el.tagName === 'INPUT' && /^(text|tel|search|email|)$/i.test(el.getAttribute('type') || '');
    const desvio = campoTexto ? { fx: aleatorio(0.12, 0.3), fy: aleatorio(0.4, 0.6) } : { fx: aleatorio(0.35, 0.65), fy: aleatorio(0.35, 0.65) };
    if (!C.ativo) return pontoDoElemento(el, desvio);
    try {
      mostrar();
      alvoParado = null;
      movendo = true;
      await dormir(aleatorio(C.reacaoMin, C.reacaoMax)); // tempo de reação antes de mexer o mouse
      const alvo = () => pontoDoElemento(el, desvio);
      const d0 = alvo();
      const distancia = Math.hypot(d0.x - x, d0.y - y);
      const duracao = duracaoDoMovimento(distancia, el.getBoundingClientRect().width);
      const curva = Math.min(60, distancia * 0.15) * (Math.random() < 0.5 ? -1 : 1);
      // Movimento principal até um pouco depois do alvo (passada) e correção curta de volta.
      const passada = distancia > 150 ? aleatorio(4, 10) : 0;
      const ang = Math.atan2(d0.y - y, d0.x - x);
      if (passada) {
        await trecho(() => { const p = alvo(); return { x: p.x + Math.cos(ang) * passada, y: p.y + Math.sin(ang) * passada }; }, duracao * 0.88, curva);
        await trecho(alvo, aleatorio(120, 200), 0);
      } else {
        await trecho(alvo, duracao, curva);
      }
      const destino = alvo();
      posicionar(destino.x, destino.y);
      alvoParado = { el, dx: destino.dx, dy: destino.dy };
      return destino;
    } catch (e) {
      falha('mover', e);
      return pontoDoElemento(el, desvio);
    } finally {
      movendo = false;
    }
  }

  // Animação do clique: a seta "afunda" e sai uma onda no ponto (x, y).
  function animarClique(px = x, py = y) {
    if (!C.ativo) return;
    try {
      const onda = document.createElement('div');
      onda.setAttribute('aria-hidden', 'true');
      Object.assign(onda.style, {
        position: 'fixed', left: `${px - 14}px`, top: `${py - 14}px`, width: '28px', height: '28px',
        borderRadius: '50%', border: `3px solid ${C.cor}`, pointerEvents: 'none', zIndex: '2147483645',
        opacity: '0.9', transform: 'scale(0.3)', transition: 'transform .45s ease-out, opacity .45s ease-out',
      });
      document.documentElement.appendChild(onda);
      requestAnimationFrame(() => {
        onda.style.transform = 'scale(1.6)';
        onda.style.opacity = '0';
      });
      setTimeout(() => onda.remove(), 600);
      if (caixa) {
        const svg = caixa.firstElementChild;
        svg.style.transition = 'transform .09s';
        svg.style.transform = 'scale(0.82)';
        setTimeout(() => { svg.style.transform = ''; }, 140);
      }
    } catch (e) {
      falha('clique', e);
    }
  }

  raiz.CNDRECIFE.CURSOR = { mostrar, esconder, moverPara, animarClique, rolarAte, pontoDoElemento, duracaoDoMovimento };
})(typeof globalThis !== 'undefined' ? globalThis : self);
