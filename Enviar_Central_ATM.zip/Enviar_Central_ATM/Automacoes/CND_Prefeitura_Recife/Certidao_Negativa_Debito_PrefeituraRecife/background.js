// Background (service worker): gerencia a EXECUÇÃO (a página só age e informa).
// - Janela da automação: abre pelo ícone; recebe "Iniciar" com a pasta e a lista.
// - Fila de empresas (cnpj;im;nome_empresa), por pasta principal.
// - Fases da empresa em andamento e tentativas de cada fase; recargas controladas (a página
//   pede; quem recarrega é o navegador) e vigia de cargas travadas ou com erro de rede.
// - Na espera do CAPTCHA (fase AGUARDANDO_CAPTCHA) NADA é recarregado automaticamente.
//
// chrome.storage.local:
//   cndrecife_config        { pasta, pastaDigitada, texto, registros, invalidas, avisos, salvoEm }
//   cndrecife_fila:<pasta>  { [id cpf/cnpj|im]: { estado, motivo, hora } }
//   cndrecife_execucao      { tabId, fase, registro, tentativa, urlFase, aguardandoInicio, prazo, encerrada, ... }
//   cndrecife_log           [{ hora, texto }]  (últimas CONFIG.MAX_LINHAS_LOG linhas)
//   cndrecife_resultado     { ok, fase, etapa, motivo, ... , hora }
//   cndrecife_rascunho      { pasta, texto }  (o que está digitado na janela)

importScripts('config.js', 'lista.js');
const CONFIG = self.CNDRECIFE.CONFIG;
const LISTA = self.CNDRECIFE.LISTA;
const MAX_TENTATIVAS = CONFIG.MAX_RECARGAS + 1;
const ALARME = 'cndrecife_vigia';
const URL_COM_MARCADOR = `${CONFIG.URL_INICIAL}#${CONFIG.MARCADOR}`;
// Estados da empresa na fila que tiram ela da fila. (Por enquanto nenhum: a empresa só será
// "concluida" quando a etapa de emissão e download existir.)
const ESTADOS_FINAIS = ['concluida'];

// Uma alteração de cada vez no storage (mensagens chegam em rajada).
let fila = Promise.resolve();
const emSerie = (fn) => (fila = fila.then(fn, fn));

const ler = async (chave, padrao) => (await chrome.storage.local.get(chave))[chave] ?? padrao;
const gravar = (obj) => chrome.storage.local.set(obj);
const agora = () => new Date().toISOString();

async function log(texto) {
  console.log(CONFIG.PREFIXO_LOG, texto);
  const linhas = await ler('cndrecife_log', []);
  linhas.push({ hora: agora(), texto });
  await gravar({ cndrecife_log: linhas.slice(-CONFIG.MAX_LINHAS_LOG) });
}

// ---- Janela da automação ------------------------------------------------------------------

async function abrirJanela() {
  const url = chrome.runtime.getURL('interface.html');
  const abas = await chrome.tabs.query({ url });
  if (abas.length) {
    await chrome.windows.update(abas[0].windowId, { focused: true });
    return;
  }
  await chrome.windows.create({ url, type: 'popup', width: 560, height: 820 });
}

// ---- Fila de empresas ----------------------------------------------------------------------

const chaveFila = (pasta) => `cndrecife_fila:${pasta}`;

async function marcarNaFila(registro, estado, motivo) {
  const config = await ler('cndrecife_config', null);
  if (!config || !registro) return;
  const chave = chaveFila(config.pasta);
  const itens = await ler(chave, {});
  itens[registro.id] = { estado, motivo: motivo || '', hora: agora(), rodada: config.rodada };
  await gravar({ [chave]: itens });
}

async function proximoRegistro() {
  const config = await ler('cndrecife_config', null);
  if (!config || !config.registros || !config.registros.length) return null;
  const itens = await ler(chaveFila(config.pasta), {});
  // Pula as concluídas e as que já deram erro NESTA rodada (um novo Iniciar tenta de novo).
  return config.registros.find((r) => {
    const item = itens[r.id] || {};
    return !ESTADOS_FINAIS.includes(item.estado) && !(item.estado === 'erro' && item.rodada === config.rodada);
  }) || null;
}

// ---- Execução -------------------------------------------------------------------------------

// Fases: LOCALIZAR (página inicial, até o clique em "Emitir Certidão"), TELA_EMISSAO (página
// aberta pelo clique: espera o formulário e preenche IM e CPF/CNPJ) e AGUARDANDO_CAPTCHA
// (dados preenchidos; a pessoa resolve o CAPTCHA). Cada fase tem a sua contagem de tentativas
// e o seu endereço (urlFase), usado quando é preciso voltar à página certa.
async function novaExecucao(tabId) {
  const registro = await proximoRegistro();
  const exec = {
    tabId, fase: 'LOCALIZAR', urlFase: URL_COM_MARCADOR, registro, tentativa: 1, aguardandoInicio: true,
    prazo: Date.now() + CONFIG.TEMPOS.vigiaCarga, encerrada: false, iniciadaEm: agora(),
  };
  await gravar({ cndrecife_execucao: exec, cndrecife_resultado: null });
  await log('------------------------------------------------------------');
  await chrome.alarms.create(ALARME, { periodInMinutes: 0.5 });
  if (registro) await marcarNaFila(registro, 'em_andamento');
  else {
    await log('[AVISO] Nenhuma empresa pendente na lista. Na janela da automação, informe a pasta, cole as empresas (cnpj;im;nome_empresa) e clique em Iniciar.');
    await abrirJanela().catch(() => {});
  }
  return exec;
}

async function encerrar(exec, resultado) {
  exec.encerrada = true;
  exec.aguardandoInicio = false;
  await gravar({ cndrecife_execucao: exec, cndrecife_resultado: { ...resultado, empresa: exec.registro ? exec.registro.nome : null, hora: agora() } });
  await chrome.alarms.clear(ALARME);
  if (exec.registro) {
    if (resultado.ok && resultado.fase === 'CONCLUIDA') await marcarNaFila(exec.registro, 'concluida', resultado.arquivo);
    else if (!resultado.ok) await marcarNaFila(exec.registro, 'erro', resultado.motivo);
  }
}

// Recarga controlada: só se ainda há tentativas; senão encerra a etapa com falha.
async function recarregar(exec, etapa, motivo) {
  if (exec.tentativa >= MAX_TENTATIVAS) {
    await log(`[ERRO] Etapa interrompida em "${etapa}" após ${exec.tentativa} tentativa(s). Motivo: ${motivo}`);
    await log('[STATUS] Encerrado com falha. A empresa continua na fila; clique em Iniciar de novo para repetir.');
    await encerrar(exec, { ok: false, fase: exec.fase, etapa, motivo, tentativas: exec.tentativa });
    return false;
  }
  exec.tentativa += 1;
  exec.erroPendente = false;
  exec.aguardandoInicio = true;
  exec.prazo = Date.now() + CONFIG.TEMPOS.vigiaCarga;
  await gravar({ cndrecife_execucao: exec });
  await chrome.alarms.create(ALARME, { periodInMinutes: 0.5 });
  return irParaPaginaDaFase(exec, etapa);
}

async function irParaPaginaDaFase(exec, etapa) {
  try {
    const aba = await chrome.tabs.get(exec.tabId);
    const url = new URL(aba.url || aba.pendingUrl || 'about:blank');
    const naTelaEmissao = exec.fase !== 'LOCALIZAR';
    const certa = url.hostname === CONFIG.HOST_ESPERADO && (naTelaEmissao
      ? CONFIG.TELA_EMISSAO.caminho.test(url.pathname)
      : CONFIG.CAMINHO_ESPERADO.test(url.pathname) && url.hash.includes(CONFIG.MARCADOR));
    if (certa) await chrome.tabs.reload(exec.tabId, { bypassCache: true });
    else await chrome.tabs.update(exec.tabId, { url: exec.urlFase || URL_COM_MARCADOR }); // página diferente: volta ao endereço da fase
    return true;
  } catch (e) {
    await log(`[ERRO] Não foi possível recarregar a aba (${e.message}).`);
    await encerrar(exec, { ok: false, fase: exec.fase, etapa, motivo: `aba indisponível: ${e.message}`, tentativas: exec.tentativa });
    return false;
  }
}

// Abre o portal (com o marcador) numa janela normal do Chrome, reaproveitando a aba da
// execução anterior se ela ainda existir.
async function abrirPortal(exec) {
  if (exec) {
    try {
      await chrome.tabs.update(exec.tabId, { url: URL_COM_MARCADOR, active: true });
      const aba = await chrome.tabs.get(exec.tabId);
      await chrome.windows.update(aba.windowId, { focused: true });
      return;
    } catch (_) { /* aba fechada: abre outra */ }
  }
  const normais = await chrome.windows.getAll({ windowTypes: ['normal'] });
  if (normais.length) {
    await chrome.tabs.create({ windowId: normais[0].id, url: URL_COM_MARCADOR, active: true });
    await chrome.windows.update(normais[0].id, { focused: true });
  } else {
    await chrome.windows.create({ url: URL_COM_MARCADOR, type: 'normal' });
  }
}

// ---- Mensagens da página e da janela ------------------------------------------------------

chrome.runtime.onMessage.addListener((msg, remetente, responder) => {
  const tabId = remetente.tab && remetente.tab.id;
  emSerie(async () => {
    let exec = await ler('cndrecife_execucao', null);
    const daAba = exec && exec.tabId === tabId && !exec.encerrada;
    switch (msg && msg.tipo) {
      // ---- janela ----
      case 'iniciar': {
        const pasta = LISTA.normalizarPastaPrincipal(msg.pasta);
        if (!pasta.ok) return { ok: false, erro: pasta.motivo };
        const lida = LISTA.lerLista(msg.texto);
        if (!lida.registros.length) return { ok: false, erro: 'nenhuma empresa válida na lista' };
        await gravar({ cndrecife_config: { pasta: pasta.pasta, pastaDigitada: msg.pasta, texto: msg.texto, ...lida, rodada: Date.now(), salvoEm: agora() }, cndrecife_log: [] });
        if (exec && !exec.encerrada) {
          await log('[AVISO] Execução anterior substituída por um novo Iniciar.');
          await encerrar(exec, { ok: false, fase: exec.fase, etapa: 'reiniciada', motivo: 'substituída por um novo Iniciar' });
        }
        const itens = await ler(chaveFila(pasta.pasta), {});
        const pendentes = lida.registros.filter((r) => !ESTADOS_FINAIS.includes((itens[r.id] || {}).estado)).length;
        await abrirPortal(exec);
        return { ok: true, pendentes, invalidas: lida.invalidas.length };
      }
      case 'confirmarCaptchaPelaJanela':
        if (!exec || exec.encerrada || exec.fase !== 'AGUARDANDO_CAPTCHA') return { ok: false, erro: 'nenhuma empresa aguardando o CAPTCHA' };
        try { return await chrome.tabs.sendMessage(exec.tabId, { tipo: 'confirmarCaptcha' }); } catch (e) { return { ok: false, erro: 'a página do portal não respondeu' }; }

      // ---- página ----
      case 'inicio': {
        // Execução em andamento nesta aba: continua (na fase em que está). Sem ela, só começa
        // uma nova se a página foi aberta com o marcador; senão a página não é conosco.
        if (!daAba) {
          if (!msg.temMarcador) return { ativo: false };
          exec = await novaExecucao(tabId);
        }
        if (exec.fase === 'ENVIANDO') exec.fase = 'AGUARDANDO_CAPTCHA'; // recarregada no meio do envio: espera de novo
        const recarregadaNaEspera = exec.fase === 'AGUARDANDO_CAPTCHA';
        exec.aguardandoInicio = false;
        await gravar({ cndrecife_execucao: exec });
        const anteriores = daAba ? (await ler('cndrecife_log', [])).slice(-40).map((l) => l.texto) : [];
        return {
          ativo: true, fase: exec.fase, tentativa: exec.tentativa, maxTentativas: MAX_TENTATIVAS,
          registro: exec.registro, recarregadaNaEspera, log: anteriores,
        };
      }
      case 'log':
        await log(String(msg.texto));
        return { ok: true };
      case 'clicando': // a página vai clicar em "Emitir Certidão": passa para a fase TELA_EMISSAO
        if (!daAba) return { ok: false };
        Object.assign(exec, {
          fase: 'TELA_EMISSAO', urlFase: msg.href, tentativaLocalizar: exec.tentativa, tentativa: 1,
          cliqueEm: Date.now(), aguardandoInicio: true, prazo: Date.now() + CONFIG.TEMPOS.vigiaCarga,
        });
        await gravar({ cndrecife_execucao: exec });
        await chrome.alarms.create(ALARME, { periodInMinutes: 0.5 });
        return { ok: true };
      case 'voltarFase': // o clique não deu certo: volta para LOCALIZAR (se nada começou a carregar)
        if (!daAba) return { ok: false };
        if ((exec.ultimaNavegacao || 0) > (exec.cliqueEm || 0)) return { ok: false, navegando: true };
        Object.assign(exec, { fase: 'LOCALIZAR', urlFase: URL_COM_MARCADOR, tentativa: exec.tentativaLocalizar || exec.tentativa, aguardandoInicio: false });
        await gravar({ cndrecife_execucao: exec });
        return { ok: true };
      case 'preenchido': // IM e CPF/CNPJ conferidos: espera a pessoa resolver o CAPTCHA (sem vigia, sem recargas)
        if (!daAba) return { ok: false };
        Object.assign(exec, { fase: 'AGUARDANDO_CAPTCHA', aguardandoInicio: false, preenchidoEm: agora() });
        await gravar({ cndrecife_execucao: exec });
        await chrome.alarms.clear(ALARME);
        await marcarNaFila(exec.registro, 'aguardando_captcha');
        return { ok: true };
      case 'enviando': // a página vai clicar em Enviar (ou a pessoa enviou): o próximo PDF do site é desta empresa
        if (!daAba) return { ok: false };
        Object.assign(exec, { fase: 'ENVIANDO', envioEm: Date.now(), downloadId: null });
        await gravar({ cndrecife_execucao: exec });
        await chrome.alarms.create(ALARME_DOWNLOAD, { when: Date.now() + CONFIG.DOWNLOAD.limite });
        return { ok: true };
      case 'envioFalhou': // o site recusou (ex.: caracteres errados) ou não respondeu: volta a esperar o CAPTCHA
        if (!daAba || exec.fase !== 'ENVIANDO' || exec.downloadId) return { ok: false };
        Object.assign(exec, { fase: 'AGUARDANDO_CAPTCHA', envioEm: null });
        await gravar({ cndrecife_execucao: exec });
        await chrome.alarms.clear(ALARME_DOWNLOAD);
        return { ok: true };
      case 'desistirEmpresa': // muitos envios recusados: erro nesta empresa e segue para a próxima
        if (!daAba) return { ok: false };
        await encerrar(exec, { ok: false, fase: exec.fase, etapa: 'ETAPA 12 – envio', motivo: msg.motivo, tentativas: exec.tentativa });
        agendarProxima(exec);
        return { ok: true };
      case 'recuperar': // botão da página: recarregar e preencher de novo (mesma empresa)
        if (!daAba) return { ok: false };
        await log('[RECUPERAÇÃO] Recarregando o formulário a pedido; a mesma empresa será preenchida de novo.');
        return { ok: await irParaPaginaDaFase(exec, 'recuperação') };
      case 'recarregar':
        if (!daAba) return { ok: false };
        if (exec.fase === 'AGUARDANDO_CAPTCHA' || exec.fase === 'ENVIANDO') return { ok: false }; // nunca recarrega sozinho na espera do CAPTCHA
        return { ok: await recarregar(exec, msg.etapa, msg.motivo) };
      case 'resultado':
        if (daAba) await encerrar(exec, msg.resultado);
        return { ok: true };
      case 'abrirJanela':
        await abrirJanela();
        return { ok: true };
      case 'estado':
        return { execucao: exec, log: await ler('cndrecife_log', []), resultado: await ler('cndrecife_resultado', null) };
      default:
        return { ok: false, erro: 'mensagem desconhecida' };
    }
  }).then(responder, (e) => responder({ ok: false, erro: String(e) }));
  return true; // resposta assíncrona
});

// ---- Download da certidão (ETAPA 13) --------------------------------------------------------
//
// Depois do Enviar, o site abre /downloadPdf/<token>/. Só o download que acontece com a
// empresa em ENVIANDO, vindo do portal, é renomeado: Downloads\<pasta>\<EMPRESA>\Certidao_<EMPRESA>.pdf
// (nome já existente: o Chrome cria "(1)", nunca sobrescreve). A empresa só é concluída depois
// que o Chrome confirma o arquivo salvo por inteiro, não vazio e .pdf.

const ALARME_DOWNLOAD = 'cndrecife_download';
const doPortal = (url) => { try { return new URL(url).hostname === CONFIG.HOST_ESPERADO; } catch (_) { return false; } };

async function caminhoDoPdf(exec) {
  const config = await ler('cndrecife_config', null);
  return config && exec.registro ? LISTA.caminhoArquivo(config.pasta, exec.registro) : null;
}

chrome.downloads.onDeterminingFilename.addListener((item, sugerir) => {
  emSerie(async () => {
    const exec = await ler('cndrecife_execucao', null);
    const nosso = exec && !exec.encerrada && exec.fase === 'ENVIANDO' && !exec.downloadId &&
      (doPortal(item.url) || doPortal(item.finalUrl) || doPortal(item.referrer));
    const caminho = nosso ? await caminhoDoPdf(exec) : null;
    if (!caminho) return sugerir(); // não é a certidão em andamento: o Chrome decide o nome
    exec.downloadId = item.id;
    await gravar({ cndrecife_execucao: exec });
    await log(`[ETAPA 13] Certidão recebida do site; salvando como Downloads\\${caminho.replace(/\//g, '\\')}...`);
    sugerir({ filename: caminho, conflictAction: 'uniquify' });
  }).catch(() => sugerir());
  return true; // resposta assíncrona
});

// Se o site mostrar o PDF na própria aba (em vez de baixar), a extensão baixa esse endereço.
chrome.webNavigation.onCommitted.addListener((d) => {
  if (d.frameId !== 0 || !CONFIG.DOWNLOAD.caminhoSite.test(new URL(d.url).pathname)) return;
  emSerie(async () => {
    const exec = await ler('cndrecife_execucao', null);
    if (!exec || exec.tabId !== d.tabId || exec.encerrada || exec.fase !== 'ENVIANDO' || exec.downloadId) return;
    const caminho = await caminhoDoPdf(exec);
    await log('[ETAPA 13] O site abriu a certidão na aba; baixando o arquivo...');
    chrome.downloads.download({ url: d.url, filename: caminho, conflictAction: 'uniquify' }).catch((e) => log(`[ERRO] Não foi possível baixar a certidão: ${e.message}`));
  });
}, filtro_portal());
function filtro_portal() { return { url: [{ hostEquals: CONFIG.HOST_ESPERADO }] }; }

chrome.downloads.onChanged.addListener((delta) => {
  if (!delta.state || !['complete', 'interrupted'].includes(delta.state.current)) return;
  emSerie(async () => {
    const exec = await ler('cndrecife_execucao', null);
    if (!exec || exec.encerrada || exec.downloadId !== delta.id) return;
    const [item] = await chrome.downloads.search({ id: delta.id });
    await chrome.alarms.clear(ALARME_DOWNLOAD);
    const tamanho = item ? (item.fileSize || item.bytesReceived || 0) : 0;
    const ehPdf = item && (/\.pdf$/i.test(item.filename) || /pdf/i.test(item.mime || ''));
    if (delta.state.current === 'complete' && item && item.exists !== false && tamanho > 0 && ehPdf) {
      await log(`[SALVO] ${item.filename} (${Math.round(tamanho / 1024)} KB)`);
      await log(`[SUCESSO] Certidão de ${exec.registro.nome} salva na pasta da empresa.`);
      await encerrar(exec, { ok: true, fase: 'CONCLUIDA', etapa: 'ETAPA 13 – download', arquivo: item.filename, tentativas: exec.tentativa });
      chrome.tabs.sendMessage(exec.tabId, { tipo: 'certidaoSalva', caminho: item.filename }).catch(() => {});
    } else {
      const motivo = delta.state.current === 'interrupted' ? `download interrompido (${(item && item.error) || 'sem detalhe'})`
        : !ehPdf ? `o arquivo recebido não é PDF (${item && item.filename})` : 'arquivo vazio ou não encontrado';
      await log(`[ERRO] ETAPA 13 – download: ${motivo}.`);
      await encerrar(exec, { ok: false, fase: 'ENVIANDO', etapa: 'ETAPA 13 – download', motivo, tentativas: exec.tentativa });
    }
    agendarProxima(exec);
  });
});

// Envio sem download no prazo: volta a esperar o CAPTCHA (a página continua preenchida).
chrome.alarms.onAlarm.addListener((a) => {
  if (a.name !== ALARME_DOWNLOAD) return;
  emSerie(async () => {
    const exec = await ler('cndrecife_execucao', null);
    if (!exec || exec.encerrada || exec.fase !== 'ENVIANDO') return;
    if (exec.downloadId) return; // download em andamento: o onChanged decide
    exec.fase = 'AGUARDANDO_CAPTCHA';
    await gravar({ cndrecife_execucao: exec });
    await log(`[AVISO] Nenhuma certidão chegou em ${CONFIG.DOWNLOAD.limite / 1000} s depois do Enviar. Confira a página; digite o CAPTCHA de novo se for preciso.`);
  });
});

// Próxima empresa da fila (na mesma aba), depois de uma pausa; ou fim da lista.
function agendarProxima(exec) {
  setTimeout(() => emSerie(async () => {
    const atual = await ler('cndrecife_execucao', null);
    if (!atual || atual.iniciadaEm !== exec.iniciadaEm) return; // outra execução já começou
    const prox = await proximoRegistro();
    if (!prox) {
      const config = await ler('cndrecife_config', null);
      const itens = config ? await ler(chaveFila(config.pasta), {}) : {};
      const regs = config ? config.registros : [];
      const ok = regs.filter((r) => (itens[r.id] || {}).estado === 'concluida').length;
      await log(`[FIM] Lista processada: ${ok} de ${regs.length} certidão(ões) salva(s)` + (regs.length - ok ? `; ${regs.length - ok} com erro (clique em Iniciar para tentar de novo).` : '.'));
      return;
    }
    await log(`[PRÓXIMA] ${prox.nome} – ${prox.docFormatado} – IM ${prox.im}`);
    try {
      await chrome.tabs.update(exec.tabId, { url: URL_COM_MARCADOR });
    } catch (_) {
      await abrirPortal(null);
    }
  }), CONFIG.DOWNLOAD.pausaEntreEmpresas);
}

// ---- Ícone da extensão: abre a janela ---------------------------------------------------------

chrome.action.onClicked.addListener(() => abrirJanela());

// ---- Vigia da carga ----------------------------------------------------------------------

const filtro = { url: [{ hostEquals: CONFIG.HOST_ESPERADO }] };

// Nome da etapa de carga conforme a fase (para os registros).
const etapaCarga = (e) => (e && e.fase !== 'LOCALIZAR' ? 'ETAPA 7 – carregamento da próxima tela' : 'ETAPA 3 – carregamento');

// Tira o marcador do endereço: recargas automáticas do navegador numa página de erro não
// reiniciam a automação depois que ela desistiu.
const pararRecargasDoNavegador = (tabId) => chrome.tabs.update(tabId, { url: CONFIG.URL_INICIAL }).catch(() => {});

// Navegação no portal: na aba de uma execução em andamento, acompanha (inclusive a abertura
// da tela de emissão depois do clique, que não tem o marcador); em outra aba, só começa uma
// execução nova se o endereço tem o marcador (iniciador, Central ou janela).
chrome.webNavigation.onBeforeNavigate.addListener((d) => {
  if (d.frameId !== 0) return;
  emSerie(async () => {
    const exec = await ler('cndrecife_execucao', null);
    if (exec && exec.tabId === d.tabId && !exec.encerrada) {
      exec.ultimaNavegacao = Date.now();
      if (exec.fase === 'AGUARDANDO_CAPTCHA' || exec.fase === 'ENVIANDO') {
        // Espera do CAPTCHA / envio: só registra. Nada de vigia nem recarga automática.
        const caminho = new URL(d.url).pathname;
        if (!CONFIG.TELA_EMISSAO.caminho.test(caminho) && !CONFIG.DOWNLOAD.caminhoSite.test(caminho)) await log(`[AVISO] Navegação durante a espera do CAPTCHA: ${caminho}`);
        await gravar({ cndrecife_execucao: exec });
        return;
      }
      // Clique, recarga nossa, recarga automática do navegador numa página de erro, F5:
      // continua a MESMA execução, sem zerar tentativas nem registros. O prazo da vigia não
      // é renovado aqui: recargas do navegador não a adiam para sempre.
      if (exec.erroPendente) {
        // Depois de um erro de rede, o próprio navegador recarregou a página antes de nós.
        // Essa recarga conta como tentativa (o limite continua valendo).
        exec.erroPendente = false;
        if (exec.tentativa >= MAX_TENTATIVAS) {
          await log(`[ERRO] Etapa interrompida em "${etapaCarga(exec)}" após ${exec.tentativa} tentativa(s). Motivo: ${exec.ultimoErro}`);
          await log('[STATUS] Encerrado com falha. A empresa continua na fila; clique em Iniciar de novo para repetir.');
          await encerrar(exec, { ok: false, fase: exec.fase, etapa: etapaCarga(exec), motivo: exec.ultimoErro, tentativas: exec.tentativa });
          await pararRecargasDoNavegador(exec.tabId);
          return;
        }
        exec.tentativa += 1;
        await log(`[RECARGA] O navegador recarregou a página sozinho (tentativa ${exec.tentativa} de ${MAX_TENTATIVAS}); acompanhando essa carga.`);
      }
      exec.aguardandoInicio = true;
      await gravar({ cndrecife_execucao: exec });
      return;
    }
    if (d.url.includes(`#${CONFIG.MARCADOR}`)) await novaExecucao(d.tabId);
  });
}, filtro);

// Erro de rede na carga (sem internet, DNS, servidor fora): o content script não roda.
chrome.webNavigation.onErrorOccurred.addListener((d) => {
  if (d.frameId !== 0) return;
  if (/ERR_ABORTED/.test(d.error)) return; // navegação cancelada (ex.: outra carga por cima, download)
  emSerie(async () => {
    const exec = await ler('cndrecife_execucao', null);
    if (!exec || exec.tabId !== d.tabId || exec.encerrada || !exec.aguardandoInicio) return;
    if (exec.fase === 'AGUARDANDO_CAPTCHA' || exec.fase === 'ENVIANDO') {
      await log(`[AVISO] Erro de rede durante a espera do CAPTCHA (${d.error}). Nada foi recarregado: use "Recarregar e preencher de novo" no painel quando quiser.`);
      return;
    }
    exec.erroPendente = true;
    exec.ultimoErro = `erro de rede (${d.error})`;
    await gravar({ cndrecife_execucao: exec });
    await log(`[FALHA] ${etapaCarga(exec)}: ${exec.ultimoErro} (tentativa ${exec.tentativa} de ${MAX_TENTATIVAS}).`);
    // Espera curta antes de tentar de novo (sem prender a fila). Se nesse tempo o próprio
    // navegador já recarregou a página (erroPendente foi limpo), não recarrega por cima.
    setTimeout(() => emSerie(async () => {
      const atual = await ler('cndrecife_execucao', null);
      if (!atual || atual.tabId !== d.tabId || atual.encerrada || !atual.erroPendente) return;
      if (atual.tentativa < MAX_TENTATIVAS) await log(`[RECARGA] Recarregando a página (tentativa ${atual.tentativa + 1} de ${MAX_TENTATIVAS})...`);
      if (!(await recarregar(atual, etapaCarga(atual), atual.ultimoErro))) await pararRecargasDoNavegador(atual.tabId);
    }), 3000);
  });
});

// Carga que não termina (a página não chegou a avisar o início dentro do prazo).
chrome.alarms.onAlarm.addListener((a) => {
  if (a.name !== ALARME) return;
  emSerie(async () => {
    const exec = await ler('cndrecife_execucao', null);
    if (!exec || exec.encerrada || exec.fase === 'AGUARDANDO_CAPTCHA' || exec.fase === 'ENVIANDO') return chrome.alarms.clear(ALARME);
    if (!exec.aguardandoInicio || Date.now() < exec.prazo) return;
    await log(`[FALHA] ${etapaCarga(exec)}: a página não respondeu em ${CONFIG.TEMPOS.vigiaCarga / 1000} s (tentativa ${exec.tentativa} de ${MAX_TENTATIVAS}).`);
    await recarregar(exec, etapaCarga(exec), 'a página não respondeu (carga travada)');
  });
});

chrome.tabs.onRemoved.addListener((tabId) => {
  emSerie(async () => {
    const exec = await ler('cndrecife_execucao', null);
    if (exec && exec.tabId === tabId && !exec.encerrada) {
      await log('[AVISO] A aba do portal foi fechada antes do fim. A empresa continua na fila.');
      await encerrar(exec, { ok: false, fase: exec.fase, etapa: 'aba fechada', motivo: 'a aba foi fechada', tentativas: exec.tentativa });
    }
  });
});
