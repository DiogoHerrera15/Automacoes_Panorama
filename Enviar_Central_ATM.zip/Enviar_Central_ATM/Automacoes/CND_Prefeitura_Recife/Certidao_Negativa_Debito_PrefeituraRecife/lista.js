// Lista de empresas no formato  cnpj;im;nome_empresa  (ou cpf;im;nome_empresa).
// Funções puras: leitura e validação das linhas, CPF/CNPJ, Inscrição Mercantil, nomes de
// pasta e de arquivo. Usado pela janela da automação, pelo background (importScripts) e pelos
// testes do Node (require).
//
// Regras do site (formulário /emissaoCertidao/4, conferidas no código da página):
// - CPF ou CNPJ: só números (máscara mNum), 11 ou 14 dígitos, dígitos verificadores válidos.
// - Inscrição Mercantil: só números, 1 a 7 dígitos, dígito verificador módulo 11 (função
//   validarInscricao/modulo11 do site), não pode ser zero.

(function (raiz) {
  const somenteDigitos = (s) => String(s == null ? '' : s).replace(/\D/g, '');

  function cpfValido(d) {
    if (!/^\d{11}$/.test(d) || /^(\d)\1{10}$/.test(d)) return false;
    for (const n of [9, 10]) {
      let soma = 0;
      for (let i = 0; i < n; i++) soma += Number(d[i]) * (n + 1 - i);
      const dv = ((soma * 10) % 11) % 10;
      if (dv !== Number(d[n])) return false;
    }
    return true;
  }

  function cnpjValido(d) {
    if (!/^\d{14}$/.test(d) || /^(\d)\1{13}$/.test(d)) return false;
    const pesos = [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2];
    for (const n of [12, 13]) {
      let soma = 0;
      for (let i = 0; i < n; i++) soma += Number(d[i]) * pesos[pesos.length - n + i];
      const resto = soma % 11;
      const dv = resto < 2 ? 0 : 11 - resto;
      if (dv !== Number(d[n])) return false;
    }
    return true;
  }

  const formatarCnpj = (d) => d.replace(/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})$/, '$1.$2.$3/$4-$5');
  const formatarCpf = (d) => d.replace(/^(\d{3})(\d{3})(\d{3})(\d{2})$/, '$1.$2.$3-$4');

  // CPF ou CNPJ escrito de qualquer jeito -> { ok, doc (só dígitos, como o site exige), tipo, formatado, aviso }
  function normalizarDocumento(texto) {
    const bruto = String(texto == null ? '' : texto).trim();
    if (!bruto) return { ok: false, motivo: 'CPF/CNPJ vazio' };
    if (/[a-z]/i.test(bruto)) return { ok: false, motivo: `CPF/CNPJ com letras ("${bruto}"): o campo do site aceita só números` };
    if (/[^\d.\-\/\s]/.test(bruto)) return { ok: false, motivo: `CPF/CNPJ com caracteres inválidos ("${bruto}")` };
    const d = somenteDigitos(bruto);
    if (d.length === 14) {
      return cnpjValido(d) ? { ok: true, doc: d, tipo: 'CNPJ', formatado: formatarCnpj(d) } : { ok: false, motivo: `CNPJ inválido (dígitos verificadores não conferem): ${bruto}` };
    }
    if (d.length === 11) {
      if (cpfValido(d)) return { ok: true, doc: d, tipo: 'CPF', formatado: formatarCpf(d) };
      const comoCnpj = d.padStart(14, '0'); // CNPJ que perdeu 3 zeros no Excel
      if (cnpjValido(comoCnpj)) return { ok: true, doc: comoCnpj, tipo: 'CNPJ', formatado: formatarCnpj(comoCnpj), aviso: 'zeros à esquerda completados' };
      return { ok: false, motivo: `CPF inválido (dígitos verificadores não conferem): ${bruto}` };
    }
    if (d.length === 12 || d.length === 13) { // o Excel tira zeros à esquerda
      const c = d.padStart(14, '0');
      if (cnpjValido(c)) return { ok: true, doc: c, tipo: 'CNPJ', formatado: formatarCnpj(c), aviso: 'zeros à esquerda completados' };
      return { ok: false, motivo: `CNPJ com ${d.length} dígitos e inválido mesmo completando os zeros: ${bruto}` };
    }
    if (d.length === 9 || d.length === 10) {
      const c = d.padStart(11, '0');
      if (cpfValido(c)) return { ok: true, doc: c, tipo: 'CPF', formatado: formatarCpf(c), aviso: 'zeros à esquerda completados' };
    }
    return { ok: false, motivo: `CPF/CNPJ com ${d.length} dígitos (esperado 11 ou 14): ${bruto}` };
  }

  // Dígito verificador da Inscrição Mercantil: igual à função modulo11 do site
  // (pesos 2..9 da direita para a esquerda; 11 - resto; acima de 9 vira 0).
  function dvInscricao(numero) {
    let soma = 0;
    let fator = 2;
    for (let i = numero.length - 1; i >= 0; i--) {
      soma += Number(numero[i]) * fator;
      fator = fator === 9 ? 2 : fator + 1;
    }
    const dv = 11 - (soma % 11);
    return dv > 9 ? 0 : dv;
  }

  // Inscrição Mercantil: texto, preservando os dígitos (inclusive zeros à esquerda).
  // Aceita pontos, traço, barra e espaços, que são retirados (o site só aceita números).
  function normalizarIM(texto) {
    const bruto = String(texto == null ? '' : texto).trim();
    if (!bruto) return { ok: false, motivo: 'Inscrição Mercantil vazia' };
    if (/[^\d.\-\/\s]/.test(bruto)) return { ok: false, motivo: `Inscrição Mercantil com caracteres inválidos ("${bruto}")` };
    const d = somenteDigitos(bruto);
    if (d.length > 7) return { ok: false, motivo: `Inscrição Mercantil com ${d.length} dígitos (máximo 7): ${bruto}` };
    if (/^0+$/.test(d)) return { ok: false, motivo: `Inscrição Mercantil zerada: ${bruto}` };
    if (d.length < 2 || dvInscricao(d.slice(0, -1)) !== Number(d.slice(-1))) {
      return { ok: false, motivo: `Inscrição Mercantil inválida (dígito verificador não confere): ${bruto}` };
    }
    return { ok: true, im: d };
  }

  // Nome de pasta/arquivo aceito pelo Windows: troca < > : " / \ | ? * e controles por "-",
  // junta espaços, tira pontos/espaços do fim, evita nomes reservados e limita o tamanho.
  function nomeSeguro(texto, max = 100) {
    let s = String(texto == null ? '' : texto).normalize('NFC')
      .replace(/[<>:"\/\\|?*\u0000-\u001f]/g, '-')
      .replace(/\s+/g, ' ').trim()
      .replace(/[. ]+$/, '');
    if (s.length > max) s = s.slice(0, max).replace(/[. ]+$/, '');
    if (/^(con|prn|aux|nul|com\d|lpt\d)$/i.test(s)) s = `_${s}`;
    return s;
  }

  // Pasta principal (dentro de Downloads). Aceita subpastas com \ ou /. Sem "..", sem caminho absoluto.
  function normalizarPastaPrincipal(texto) {
    const bruto = String(texto == null ? '' : texto).trim();
    if (!bruto) return { ok: false, motivo: 'informe o nome da pasta principal' };
    if (/^[a-z]:|^[\\/]/i.test(bruto)) return { ok: false, motivo: 'use só o nome da pasta (ela fica dentro de Downloads), sem C:\\ nem barra no início' };
    const partes = bruto.split(/[\\/]+/).map((p) => nomeSeguro(p)).filter(Boolean);
    if (!partes.length || partes.some((p) => p === '..' || p === '.')) return { ok: false, motivo: 'nome de pasta inválido' };
    return { ok: true, pasta: partes.join('/') };
  }

  // Lê o texto colado: uma empresa por linha, separada por ";" (o TAB do Excel também vale).
  // Devolve { registros, invalidas, avisos }. Linhas com problema não bloqueiam as demais.
  function lerLista(texto) {
    const registros = [];
    const invalidas = [];
    const avisos = [];
    const vistos = new Map(); // doc|im -> linha
    const linhas = String(texto == null ? '' : texto).replace(/^\uFEFF/, '').split(/\r?\n/);
    linhas.forEach((original, i) => {
      const n = i + 1;
      const linha = original.trim();
      if (!linha) return;
      const campos = linha.split(linha.includes(';') ? ';' : '\t');
      if (campos.length < 3) {
        invalidas.push({ linha: n, texto: linha, motivo: 'esperado cnpj;im;nome_empresa (3 campos separados por ";")' });
        return;
      }
      const [docTxt, imTxt, ...resto] = campos;
      const nome = resto.join(';').replace(/\s+/g, ' ').trim();
      const doc = normalizarDocumento(docTxt);
      if (!doc.ok) { invalidas.push({ linha: n, texto: linha, motivo: doc.motivo }); return; }
      const im = normalizarIM(imTxt);
      if (!im.ok) { invalidas.push({ linha: n, texto: linha, motivo: im.motivo }); return; }
      if (!nome || !nomeSeguro(nome)) { invalidas.push({ linha: n, texto: linha, motivo: 'nome da empresa vazio' }); return; }
      const chave = `${doc.doc}|${im.im}`;
      if (vistos.has(chave)) {
        avisos.push({ linha: n, texto: linha, motivo: `repetida (mesmo CPF/CNPJ e IM da linha ${vistos.get(chave)}): ignorada` });
        return;
      }
      vistos.set(chave, n);
      if (doc.aviso) avisos.push({ linha: n, texto: linha, motivo: `${doc.tipo}: ${doc.aviso} (${doc.formatado})` });
      registros.push({ id: chave, linha: n, doc: doc.doc, tipo: doc.tipo, docFormatado: doc.formatado, im: im.im, nome });
    });

    // Pasta e arquivo de cada empresa. Nomes iguais (depois de ajustados para o Windows)
    // ganham o CPF/CNPJ, para cada certidão ir para a pasta da sua empresa.
    const contagem = new Map();
    for (const r of registros) {
      const k = nomeSeguro(r.nome).toLowerCase();
      contagem.set(k, (contagem.get(k) || 0) + 1);
    }
    for (const r of registros) {
      const base = nomeSeguro(r.nome);
      r.pasta = contagem.get(base.toLowerCase()) > 1 ? nomeSeguro(`${base} - ${r.doc}`, 120) : base;
      r.arquivo = `Certidao_${r.pasta}.pdf`;
    }
    return { registros, invalidas, avisos };
  }

  // Caminho do PDF dentro de Downloads (usado na etapa de download).
  const caminhoArquivo = (pastaPrincipal, registro) => `${pastaPrincipal}/${registro.pasta}/${registro.arquivo}`;

  const LISTA = { somenteDigitos, cpfValido, cnpjValido, normalizarDocumento, dvInscricao, normalizarIM, nomeSeguro, normalizarPastaPrincipal, lerLista, caminhoArquivo };
  raiz.CNDRECIFE = raiz.CNDRECIFE || {};
  raiz.CNDRECIFE.LISTA = LISTA;
  if (typeof module !== 'undefined' && module.exports) module.exports = LISTA;
})(typeof globalThis !== 'undefined' ? globalThis : self);
