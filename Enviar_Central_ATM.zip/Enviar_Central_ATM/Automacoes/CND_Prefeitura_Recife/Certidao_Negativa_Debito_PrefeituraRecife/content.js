// Fluxo da automação nas páginas do portal Recife em Dia. Duas fases, guardadas no background
// (a página muda no meio):
//
//   LOCALIZAR (página /certidoesNegativasDebitos, aberta com o marcador #cndrecife_localizar)
//     aguardar o carregamento > confirmar o endereço > localizar o título "Certidão Negativa de
//     Débitos" > localizar e validar o link "Emitir Certidão" > levar o cursor até ele, em
//     velocidade humana, e clicar.
//   TELA_EMISSAO (página /emissaoCertidao/<n>, aberta pelo clique)
//     aguardar a tela "Certidão Negativa de Débitos Mercantis" ficar completa (formulário,
//     campos, verificação, botão Enviar) > preencher a Inscrição Mercantil e o CPF/CNPJ da
//     empresa em andamento (cursor + digitação humana) > conferir os valores.
//   AGUARDANDO_CAPTCHA
//     a pessoa resolve o CAPTCHA e confirma (painel ou janela). Sem recargas automáticas;
//     se a página for recarregada, preenche os mesmos dados de novo. NÃO clica em Enviar.
//
// As próximas etapas (Enviar, download e pastas) entram em confirmar(), em aguardarCaptcha().
// Sem o marcador e sem uma execução em andamento nesta aba, não faz nada.

(function () {
  const { CONFIG, PAGINA } = globalThis.CNDRECIFE;
  const T = CONFIG.TEMPOS;
  const E = CONFIG.TELA_EMISSAO;

  if (window.top !== window) return; // só a janela principal
  if (globalThis.CNDRECIFE.iniciado) return;
  globalThis.CNDRECIFE.iniciado = true;
  const temMarcador = location.hash.includes(CONFIG.MARCADOR);

  function enviar(msg) {
    return new Promise((ok) => {
      try {
        chrome.runtime.sendMessage(msg, (r) => ok(chrome.runtime.lastError ? null : r));
      } catch (_) {
        ok(null); // extensão recarregada/removida: a página continua normal
      }
    });
  }

  // Registro: console da página (F12), painel na tela e o background (chrome.storage.local).
  function registrar(texto) {
    console.log(CONFIG.PREFIXO_LOG, texto);
    PAGINA.linhaNoPainel(texto);
    enviar({ tipo: 'log', texto });
  }

  // Falha numa etapa: recarrega a página (o background controla as tentativas) ou encerra.
  async function falhar(etapa, motivo, ctx) {
    registrar(`[FALHA] ${etapa}: ${motivo} (tentativa ${ctx.tentativa} de ${ctx.maxTentativas}).`);
    if (ctx.tentativa < ctx.maxTentativas) {
      registrar(`[RECARGA] Recarregando a página (tentativa ${ctx.tentativa + 1} de ${ctx.maxTentativas})...`);
      const r = await enviar({ tipo: 'recarregar', etapa, motivo });
      if (r && r.ok) return; // o background recarrega; esta página termina aqui
      registrar('[ERRO] O background não respondeu ao pedido de recarga.');
    }
    registrar(`[ERRO] Etapa interrompida em "${etapa}" após ${ctx.tentativa} tentativa(s). Motivo: ${motivo}`);
    registrar('[STATUS] Encerrado com falha. Abra a automação de novo para repetir.');
    await enviar({ tipo: 'resultado', resultado: { ok: false, fase: ctx.fase, etapa, motivo, tentativas: ctx.tentativa, url: location.href } });
  }

  // ---- Fase LOCALIZAR ----------------------------------------------------------------------

  async function faseLocalizar(ctx) {
    if (ctx.tentativa === 1) {
      registrar(`[INICIANDO] ${CONFIG.NOME}`);
      registrar('[ETAPA 1] Navegador iniciado.');
    } else {
      registrar(`[INICIANDO] ${CONFIG.NOME} – tentativa ${ctx.tentativa} de ${ctx.maxTentativas} (após recarga)`);
    }

    // ETAPA 2: o endereço é o do portal esperado?
    registrar('[ETAPA 2] Acessando portal Recife em Dia...');
    if (!PAGINA.enderecoEsperado()) {
      return falhar('ETAPA 2 – endereço', `a página aberta não é a esperada (${location.origin}${location.pathname})`, ctx);
    }
    registrar(`[ETAPA 2] Endereço confirmado: ${location.origin}${location.pathname}`);

    // ETAPA 3: documento carregado (o content script roda em document_idle; confere mesmo assim).
    registrar('[ETAPA 3] Aguardando carregamento...');
    const t0 = Date.now();
    const pronto = await PAGINA.esperar(() => document.readyState !== 'loading' && document.body, T.esperaDocumento);
    if (!pronto) return falhar('ETAPA 3 – carregamento', `a página não terminou de carregar em ${T.esperaDocumento / 1000} s`, ctx);
    if (PAGINA.paginaDeErro()) return falhar('ETAPA 3 – carregamento', 'o servidor devolveu uma página de erro/manutenção', ctx);

    // ETAPA 4: título.
    registrar('[ETAPA 4] Localizando título da página...');
    const titulo = await PAGINA.esperar(PAGINA.localizarTitulo, T.esperaTitulo);
    if (!titulo) {
      const motivo = PAGINA.paginaDeErro() ? 'o servidor devolveu uma página de erro/manutenção'
        : `título "Certidão Negativa de Débitos" não apareceu em ${T.esperaTitulo / 1000} s`;
      return falhar('ETAPA 4 – título', motivo, ctx);
    }
    registrar(`[ETAPA 4] Título encontrado: "${PAGINA.textoLimpo(titulo)}" (${(Date.now() - t0) / 1000} s).`);

    // ETAPA 5: botão "Emitir Certidão".
    registrar('[ETAPA 5] Procurando elemento "Emitir Certidão"...');
    let achado = null;
    let ultimo = null;
    await PAGINA.esperar(() => {
      ultimo = PAGINA.localizarBotao(titulo);
      achado = ultimo.el ? ultimo : null;
      return achado;
    }, T.esperaBotao);
    if (!achado) {
      const detalhe = ultimo && ultimo.rejeitados && ultimo.rejeitados.length ? ` [${[...new Set(ultimo.rejeitados)].slice(0, 3).join(' | ')}]` : '';
      return falhar('ETAPA 5 – botão', `${ultimo ? ultimo.motivo : 'link não encontrado'}${detalhe}`, ctx);
    }

    // Estável: o mesmo elemento continua lá e válido depois de um instante (página não está se refazendo).
    await PAGINA.dormir(T.estabilidade);
    const conferido = PAGINA.localizarBotao(titulo);
    if (conferido.el !== achado.el) return falhar('ETAPA 5 – botão', 'o link mudou durante a conferência (página instável)', ctx);

    const uso = PAGINA.disponivelParaInteracao(achado.el);
    if (!uso.ok) return falhar('ETAPA 5 – botão', `link encontrado mas não disponível: ${uso.motivo}`, ctx);

    const el = achado.el;
    PAGINA.destacar(el, 'Emitir Certidão (localizado)');
    registrar(`[ETAPA 5] Seletor: ${achado.seletor} (método: ${achado.metodo}; ${achado.candidatos} candidato(s)).`);
    registrar(`[ETAPA 5] Destino: ${el.href}`);
    registrar('[SUCESSO] Elemento identificado corretamente.');

    if (!CONFIG.CLICAR_EMITIR) {
      registrar('[STATUS] Aguardando próxima etapa.');
      await enviar({ tipo: 'resultado', resultado: { ok: true, fase: 'LOCALIZAR', seletor: achado.seletor, href: el.href, tentativas: ctx.tentativa, clicado: false } });
      return;
    }

    // ETAPA 6: cursor até o botão e clique. O background passa para a fase TELA_EMISSAO
    // ANTES do clique (depois dele a página já pode ter sido trocada).
    registrar('[ETAPA 6] Levando o cursor até "Emitir Certidão"...');
    await enviar({ tipo: 'clicando', href: el.href });
    PAGINA.removerDestaque();
    const clique = await PAGINA.clicar(el);
    if (!clique.ok) {
      await enviar({ tipo: 'voltarFase' });
      return falhar('ETAPA 6 – clique', `não foi possível clicar: ${clique.motivo}`, ctx);
    }
    registrar(`[ETAPA 6] Clique em "Emitir Certidão" realizado (ponto ${clique.ponto.x}, ${clique.ponto.y}).`);
    registrar('[ETAPA 7] Aguardando a próxima tela carregar...');

    // Se em alguns segundos a página continuar esta mesma, o clique não abriu a tela.
    // (Se o navegador já está carregando a próxima tela, devagar, o background avisa e quem
    // cuida é a vigia dele.)
    await PAGINA.dormir(T.esperaNavegacaoClique);
    const volta = await enviar({ tipo: 'voltarFase' });
    if (volta && volta.navegando) {
      registrar('[ETAPA 7] A próxima tela está demorando para carregar; aguardando...');
      return;
    }
    return falhar('ETAPA 6 – clique', `o clique não abriu a próxima tela em ${T.esperaNavegacaoClique / 1000} s`, ctx);
  }

  // ---- Fase TELA_EMISSAO ------------------------------------------------------------------

  async function faseTelaEmissao(ctx) {
    if (ctx.tentativa > 1) registrar(`[ETAPA 7] Tela de emissão – tentativa ${ctx.tentativa} de ${ctx.maxTentativas} (após recarga)`);
    registrar(`[ETAPA 7] Nova página aberta: ${location.origin}${location.pathname}`);
    // Recarregada durante a espera do CAPTCHA: problemas viram aviso + recuperação pela pessoa.
    const falharTela = ctx.fase === 'AGUARDANDO_CAPTCHA' ? problemaNaEspera : (etapa, motivo) => falhar(etapa, motivo, ctx);
    if (location.hostname !== CONFIG.HOST_ESPERADO || !E.caminho.test(location.pathname)) {
      return falharTela('ETAPA 7 – próxima tela', `a página aberta não é a tela de emissão (${location.pathname})`);
    }

    const t0 = Date.now();
    let estado = null;
    await PAGINA.esperar(() => {
      estado = PAGINA.estadoTelaEmissao();
      // Página de erro do servidor no lugar do formulário: não adianta esperar.
      if (!estado.pronta && !document.querySelector(E.formulario) && document.readyState === 'complete' &&
          CONFIG.SELETORES.textoErroServidor.test(document.body ? document.body.innerText.slice(0, 3000) : '')) {
        estado.erroServidor = true;
        return true;
      }
      return estado.pronta;
    }, E.esperaTela);
    if (!estado || !estado.pronta) {
      const motivo = estado && estado.erroServidor ? 'o servidor devolveu uma página de erro/manutenção'
        : `a tela não ficou completa em ${E.esperaTela / 1000} s (faltou: ${estado ? estado.falta : 'tudo'})`;
      return falharTela('ETAPA 7 – próxima tela', motivo);
    }

    const segundos = ((Date.now() - t0) / 1000).toFixed(1);
    registrar(`[ETAPA 7] Tela carregada: "${estado.titulo}" (${segundos} s).`);
    registrar(`[ETAPA 7] Conferido: formulário ${E.formulario}, campos ${E.campoInscricao} e ${E.campoDocumento}, verificação ${E.campoCaptcha} (imagem carregada) e botão Enviar ${E.botaoEnviar}.`);
    registrar('[SUCESSO] Formulário carregado corretamente.');

    const reg = ctx.registro;
    if (!reg) {
      registrar('[AVISO] Nenhuma empresa pendente na lista: nada a preencher. Abra a janela da automação (ícone da extensão), cole as empresas e clique em Iniciar.');
      await enviar({ tipo: 'resultado', resultado: { ok: false, fase: 'TELA_EMISSAO', etapa: 'ETAPA 8 – dados', motivo: 'nenhuma empresa pendente na lista', url: location.href } });
      await enviar({ tipo: 'abrirJanela' });
      return;
    }
    return preencherEAguardar(ctx, reg, estado);
  }

  // ---- Preenchimento (IM e CPF/CNPJ) e espera do CAPTCHA manual ----------------------------

  // Problema depois que os dados já foram preenchidos uma vez (página recarregada na espera do
  // CAPTCHA): nada de recarga automática; mostra o problema e oferece a recuperação.
  function problemaNaEspera(etapa, motivo) {
    registrar(`[AVISO] ${etapa}: ${motivo}. Nada foi recarregado automaticamente.`);
    PAGINA.mostrarAcoes('Não foi possível preencher os dados nesta página.', motivo, [
      { rotulo: 'Recarregar e preencher de novo', acao: () => enviar({ tipo: 'recuperar' }) },
    ]);
  }

  async function preencherEAguardar(ctx, reg, estado) {
    const naEspera = ctx.fase === 'AGUARDANDO_CAPTCHA';
    const erro = (etapa, motivo) => (naEspera ? problemaNaEspera(etapa, motivo) : falhar(etapa, motivo, ctx));
    if (naEspera) registrar('[RECUPERAÇÃO] A página foi recarregada durante a espera do CAPTCHA: preenchendo os mesmos dados de novo.');
    registrar(`[EMPRESA] ${reg.nome} – ${reg.tipo} ${reg.docFormatado} – IM ${reg.im}`);

    // ETAPA 8: Inscrição Mercantil.
    registrar(`[ETAPA 8] Preenchendo Inscrição Mercantil (${E.campoInscricao}) com ${reg.im}...`);
    const im = await PAGINA.preencherCampo(estado.campoIM, reg.im);
    if (!im.ok) return erro('ETAPA 8 – Inscrição Mercantil', im.motivo);
    registrar(im.jaEstava ? `[ETAPA 8] A Inscrição Mercantil já estava preenchida com ${reg.im} (não foi digitada de novo).` : `[ETAPA 8] Inscrição Mercantil digitada: ${estado.campoIM.value}`);

    // ETAPA 9: CPF ou CNPJ (o site aceita só os números: 11 ou 14 dígitos).
    registrar(`[ETAPA 9] Preenchendo CPF/CNPJ (${E.campoDocumento}) com ${reg.doc} (${reg.docFormatado}; o campo do site aceita só números)...`);
    const doc = await PAGINA.preencherCampo(estado.campo, reg.doc);
    if (!doc.ok) return erro('ETAPA 9 – CPF/CNPJ', doc.motivo);
    registrar(doc.jaEstava ? `[ETAPA 9] O CPF/CNPJ já estava preenchido com ${reg.doc} (não foi digitado de novo).` : `[ETAPA 9] CPF/CNPJ digitado: ${estado.campo.value}`);

    // ETAPA 10: conferência final dos dois campos, depois de a máscara do site agir.
    registrar('[ETAPA 10] Conferindo os valores nos campos...');
    await PAGINA.dormir(CONFIG.PREENCHIMENTO.esperaMascara);
    const vIM = estado.campoIM.value;
    const vDoc = estado.campo.value;
    if (vIM !== reg.im || vDoc !== reg.doc) {
      return erro('ETAPA 10 – conferência', `valores nos campos diferentes do esperado (IM "${vIM}", CPF/CNPJ "${vDoc}")`);
    }
    registrar(`[ETAPA 10] Conferido: Inscrição Mercantil = ${vIM}; CPF/CNPJ = ${vDoc}.`);
    registrar('[SUCESSO] Dados preenchidos corretamente.');
    await enviar({ tipo: 'preenchido' });
    return aguardarCaptcha(reg, estado);
  }

  // ETAPA 11: a pessoa resolve o CAPTCHA. A automação não lê a imagem e não escreve no campo:
  // só observa a digitação (eventos marcados pelo navegador como vindos da pessoa). Quando há
  // 5 caracteres e a pessoa para de digitar, leva o cursor até "Enviar" e clica (ETAPA 12).
  // O background salva o PDF na pasta da empresa e passa para a próxima (ETAPA 13).
  // Sem recargas automáticas: os dados preenchidos ficam.
  async function aguardarCaptcha(reg, estado) {
    const C = CONFIG.CAPTCHA;
    let encerrado = false;
    let enviando = false;
    let envios = 0;
    let avisoAlterado = false;
    let ultimaMsgSite = '';
    let timerSilencio = null;

    const dadosIntactos = () => estado.campoIM.isConnected && estado.campo.isConnected &&
      estado.campoIM.value === reg.im && estado.campo.value === reg.doc;
    const tamanhoCaptcha = () => (estado.captcha.isConnected ? estado.captcha.value.trim().length : 0); // só o tamanho; o conteúdo não é lido
    const mensagemSite = () => {
      const lbl = document.getElementById('lblMensagem');
      const caixa = document.getElementById('mensagem');
      if (!lbl || !caixa || !PAGINA.visivel(caixa)) return { texto: '', erro: false };
      return { texto: PAGINA.textoLimpo(lbl), erro: /alert-danger/.test(caixa.className) };
    };

    // ETAPA 12: envio. `pelaPessoa`: a pessoa já clicou em Enviar ou apertou Enter (o site envia
    // sozinho); aí a automação só acompanha, sem clicar de novo.
    async function enviarFormulario(origem, pelaPessoa = false) {
      if (encerrado || enviando) return { ok: false, erro: 'envio já em andamento' };
      if (!dadosIntactos()) {
        PAGINA.detalheAcoes('Os dados da empresa foram alterados nos campos. Use "Preencher os campos de novo" antes de enviar.');
        return { ok: false, erro: 'os dados nos campos foram alterados' };
      }
      const n = tamanhoCaptcha();
      if (n !== C.tamanho) {
        PAGINA.detalheAcoes(`O campo da verificação tem ${n} caractere(s); o site exige ${C.tamanho}.`);
        return { ok: false, erro: `o campo da verificação tem ${n} caractere(s) (o site exige ${C.tamanho})` };
      }
      enviando = true;
      envios += 1;
      clearTimeout(timerSilencio);
      const antes = mensagemSite().texto;
      await enviar({ tipo: 'enviando', envio: envios });
      if (pelaPessoa) {
        registrar(`[ETAPA 12] Você enviou o formulário (${origem}); acompanhando a resposta do site...`);
      } else {
        registrar(`[ETAPA 12] CAPTCHA digitado (${C.tamanho} caracteres, ${origem}). Levando o cursor até "Enviar"...`);
        if (!dadosIntactos() || tamanhoCaptcha() !== C.tamanho) { enviando = false; await enviar({ tipo: 'envioFalhou', motivo: 'campos mudaram antes do clique' }); return { ok: false, erro: 'campos mudaram' }; }
        const clique = await PAGINA.clicar(estado.enviar);
        if (!clique.ok) {
          enviando = false;
          registrar(`[AVISO] Não foi possível clicar em Enviar: ${clique.motivo}. Clique você mesmo em Enviar.`);
          await enviar({ tipo: 'envioFalhou', motivo: clique.motivo });
          return { ok: false, erro: clique.motivo };
        }
        registrar(`[ETAPA 12] Clique em "Enviar" realizado (envio ${envios}).`);
      }
      PAGINA.mostrarAcoes('Enviado. Aguardando a certidão...', `${reg.nome}: o PDF será salvo como ${reg.arquivo}, na pasta da empresa.`);

      // Resposta do site: erro (ex.: caracteres inválidos) aparece em #mensagem como alert-danger.
      // O sucesso é o download do PDF, acompanhado pelo background.
      const fim = Date.now() + C.limiteResposta;
      let processando = false;
      while (Date.now() < fim && !encerrado) {
        await PAGINA.dormir(400);
        const m = mensagemSite();
        if (m.texto && /processando/i.test(m.texto)) processando = true;
        if (m.erro && (processando || m.texto !== antes)) {
          enviando = false;
          registrar(`[SITE] ${m.texto}`);
          ultimaMsgSite = m.texto;
          await enviar({ tipo: 'envioFalhou', motivo: m.texto });
          if (envios >= C.maxEnvios) {
            registrar(`[ERRO] O site recusou ${envios} envios desta empresa. Ela fica com erro na fila e a automação passa para a próxima.`);
            encerrado = true;
            await enviar({ tipo: 'desistirEmpresa', motivo: `o site recusou ${envios} envios: ${m.texto}` });
            return { ok: false, erro: m.texto };
          }
          registrar(`[ETAPA 11] Digite o CAPTCHA de novo (envio ${envios} de ${C.maxEnvios}). Se a imagem não mudou, clique no ícone de atualizar ao lado dela.`);
          PAGINA.mostrarAcoes(`O site recusou: ${m.texto}`, 'Digite os caracteres de novo; a automação envia sozinha quando você parar de digitar.', botoesEspera());
          return { ok: false, erro: m.texto };
        }
      }
      if (!encerrado && enviando) {
        enviando = false;
        registrar(`[AVISO] O site não respondeu em ${C.limiteResposta / 1000} s. Confira a página; você pode digitar o CAPTCHA de novo.`);
        await enviar({ tipo: 'envioFalhou', motivo: 'sem resposta do site' });
        PAGINA.mostrarAcoes('O site não respondeu ao envio.', 'Digite o CAPTCHA de novo ou use "Recarregar e preencher de novo".', botoesEspera());
      }
      return { ok: true };
    }
    const confirmar = () => enviarFormulario('confirmado no botão');

    async function preencherDeNovo() {
      if (encerrado || enviando) return;
      clearTimeout(timerSilencio);
      registrar('[ETAPA 11] Preenchendo os campos de novo, a pedido...');
      const a = await PAGINA.preencherCampo(estado.campoIM, reg.im);
      const b = a.ok ? await PAGINA.preencherCampo(estado.campo, reg.doc) : a;
      if (a.ok && b.ok) {
        avisoAlterado = false;
        registrar(`[ETAPA 11] Campos conferidos de novo: IM = ${estado.campoIM.value}; CPF/CNPJ = ${estado.campo.value}.`);
        PAGINA.detalheAcoes(detalhe);
      } else registrar(`[AVISO] Não foi possível preencher de novo: ${(a.ok ? b : a).motivo}`);
    }

    // Deixa o cursor no campo da verificação, para a pessoa já digitar (sem escrever nada nele).
    const foco = await PAGINA.clicar(estado.captcha);
    if (!foco.ok) estado.captcha.focus({ preventScroll: true });
    PAGINA.destacar(estado.captcha, 'Digite aqui o CAPTCHA');

    const detalhe = `${reg.nome} – ${reg.tipo} ${reg.docFormatado} – IM ${reg.im}. Digite os ${C.tamanho} caracteres: quando você parar de digitar, a automação clica em Enviar e salva ${reg.arquivo}.`;
    function botoesEspera() {
      return [
        { rotulo: 'Já digitei – enviar agora', acao: confirmar },
        { rotulo: 'Preencher os campos de novo', acao: preencherDeNovo, secundario: true },
        { rotulo: 'Recarregar e preencher de novo', acao: () => enviar({ tipo: 'recuperar' }), secundario: true },
      ];
    }
    registrar('[ETAPA 11] Aguardando você resolver o CAPTCHA manualmente (a automação não digita nesse campo e não recarrega a página).');
    registrar(`[STATUS] ${C.mensagem}`);
    PAGINA.mostrarAcoes(C.mensagem, detalhe, botoesEspera());

    // Digitação da PESSOA no campo da verificação (só eventos reais, isTrusted). Com 5
    // caracteres e `silencio` ms sem digitar, envia. Digitar de novo adia o envio.
    const aoDigitar = (ev) => {
      if (!ev.isTrusted || encerrado || enviando) return;
      clearTimeout(timerSilencio);
      if (tamanhoCaptcha() === C.tamanho) {
        timerSilencio = setTimeout(() => enviarFormulario('você parou de digitar'), C.silencio);
      }
    };
    estado.captcha.addEventListener('input', aoDigitar, true);
    estado.captcha.addEventListener('keyup', aoDigitar, true);
    // A pessoa mesma enviou: Enter no campo da verificação ou clique em Enviar (o site envia).
    estado.captcha.addEventListener('keypress', (ev) => {
      if (ev.isTrusted && (ev.key === 'Enter' || ev.keyCode === 13)) enviarFormulario('Enter no campo da verificação', true);
    }, true);
    estado.enviar.addEventListener('click', (ev) => {
      if (ev.isTrusted) enviarFormulario('clique em Enviar', true);
    }, true);

    // Vigia (só leitura): dados alterados e mensagens do site fora de um envio.
    const vigia = setInterval(() => {
      if (encerrado) return clearInterval(vigia);
      if (!dadosIntactos() && !avisoAlterado) {
        avisoAlterado = true;
        registrar(`[AVISO] Os dados nos campos foram alterados (IM "${estado.campoIM.value}", CPF/CNPJ "${estado.campo.value}"). Use "Preencher os campos de novo".`);
        PAGINA.detalheAcoes('Os dados da empresa foram alterados nos campos. Use "Preencher os campos de novo".');
      }
      if (enviando) return;
      const msg = mensagemSite().texto;
      if (msg && msg !== ultimaMsgSite) registrar(`[SITE] ${msg}`);
      ultimaMsgSite = msg;
    }, C.intervaloVigia);

    // Mensagens do background: confirmação pela janela; certidão salva (ETAPA 13).
    chrome.runtime.onMessage.addListener((m, _r, responder) => {
      if (m && m.tipo === 'confirmarCaptcha') { confirmar().then(responder); return true; }
      if (m && m.tipo === 'certidaoSalva') {
        encerrado = true;
        clearInterval(vigia);
        PAGINA.mostrarAcoes('Certidão salva.', m.caminho);
        responder({ ok: true });
      }
      return false;
    });
  }

  // ---- Início ------------------------------------------------------------------------------

  async function principal() {
    let ctx = await enviar({ tipo: 'inicio', url: location.href, temMarcador });
    if (!ctx) {
      if (!temMarcador) return; // sem background e sem marcador: não é conosco
      ctx = { ativo: true, fase: 'LOCALIZAR', tentativa: 1, maxTentativas: CONFIG.MAX_RECARGAS + 1, log: [] };
    }
    if (!ctx.ativo) return; // página aberta à mão, sem execução em andamento
    for (const linha of ctx.log || []) PAGINA.linhaNoPainel(linha); // continua o painel da página anterior
    return ctx.fase === 'LOCALIZAR' ? faseLocalizar(ctx) : faseTelaEmissao(ctx); // TELA_EMISSAO ou AGUARDANDO_CAPTCHA (recarregada)
  }

  principal().catch((e) => {
    console.error(CONFIG.PREFIXO_LOG, e);
    registrar(`[ERRO] Erro inesperado: ${e && e.message ? e.message : e}`);
    enviar({ tipo: 'resultado', resultado: { ok: false, etapa: 'inesperado', motivo: String(e && e.message ? e.message : e), url: location.href } });
  });
})();
