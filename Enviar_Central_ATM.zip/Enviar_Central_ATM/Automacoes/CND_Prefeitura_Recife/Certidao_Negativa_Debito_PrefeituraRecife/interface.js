// Janela da automação: pasta principal, lista cnpj;im;nome_empresa, Iniciar e andamento.
// Só mostra e envia pedidos: quem guarda a fila e conduz a execução é o background.

(function () {
  const { CONFIG, LISTA } = globalThis.CNDRECIFE;
  const $ = (id) => document.getElementById(id);
  const ROTULOS = {
    LOCALIZAR: 'Abrindo o portal e localizando "Emitir Certidão"',
    TELA_EMISSAO: 'Abrindo o formulário e preenchendo IM e CPF/CNPJ',
    AGUARDANDO_CAPTCHA: 'Aguardando você digitar o CAPTCHA (a automação envia sozinha)',
    ENVIANDO: 'Enviado; salvando a certidão',
  };

  $('versao').textContent = `${CONFIG.NOME} ${chrome.runtime.getManifest().version}`;

  function analisar() {
    const pasta = LISTA.normalizarPastaPrincipal($('pasta').value);
    const r = LISTA.lerLista($('lista').value);
    $('caminho').textContent = pasta.ok
      ? `Downloads\\${pasta.pasta.replace(/\//g, '\\')}\\${r.registros[0] ? `${r.registros[0].pasta}\\${r.registros[0].arquivo}` : '<EMPRESA>\\Certidao_<EMPRESA>.pdf'}`
      : pasta.motivo;
    $('contagem').textContent = `${r.registros.length} empresa(s) válida(s)` + (r.invalidas.length ? `, ${r.invalidas.length} linha(s) com problema (serão ignoradas)` : '');
    const ul = $('problemas');
    ul.textContent = '';
    for (const p of r.invalidas) { const li = document.createElement('li'); li.textContent = `Linha ${p.linha}: ${p.motivo}`; ul.appendChild(li); }
    for (const p of r.avisos) { const li = document.createElement('li'); li.className = 'aviso-linha'; li.textContent = `Linha ${p.linha}: ${p.motivo}`; ul.appendChild(li); }
    return { pasta, r };
  }

  function aviso(texto) {
    $('aviso').hidden = !texto;
    $('aviso').textContent = texto || '';
  }

  // Rascunho: o que foi digitado continua aqui se a janela for fechada.
  let timer = null;
  function salvarRascunho() {
    clearTimeout(timer);
    timer = setTimeout(() => chrome.storage.local.set({ cndrecife_rascunho: { pasta: $('pasta').value, texto: $('lista').value } }), 400);
  }
  for (const id of ['pasta', 'lista']) $(id).addEventListener('input', () => { analisar(); salvarRascunho(); });

  $('iniciar').addEventListener('click', async () => {
    const { pasta, r } = analisar();
    if (!pasta.ok) return aviso(pasta.motivo);
    if (!r.registros.length) return aviso('Nenhuma empresa válida na lista.');
    $('iniciar').disabled = true;
    const resp = await chrome.runtime.sendMessage({ tipo: 'iniciar', pasta: $('pasta').value, texto: $('lista').value });
    $('iniciar').disabled = false;
    aviso(resp && resp.ok ? `Iniciado: ${resp.pendentes} empresa(s) na fila. A página do portal foi aberta.` : `Não iniciou: ${(resp && resp.erro) || 'sem resposta da extensão'}`);
  });

  $('confirmar').addEventListener('click', async () => {
    const resp = await chrome.runtime.sendMessage({ tipo: 'confirmarCaptchaPelaJanela' });
    aviso(resp && resp.ok ? 'Confirmação enviada para a página.' : `Não confirmou: ${(resp && resp.erro) || 'sem resposta'}`);
  });

  function mostrarEstado(dados) {
    const exec = dados.cndrecife_execucao;
    const res = dados.cndrecife_resultado;
    const reg = exec && exec.registro;
    let status = 'Parada';
    if (exec && !exec.encerrada) status = ROTULOS[exec.fase] || exec.fase;
    else if (res) status = res.ok ? `Certidão salva: ${res.arquivo || ''}` : `Erro na última empresa: ${res.motivo || ''}`;
    $('status').textContent = status;
    $('empresa').textContent = reg ? reg.nome : '–';
    $('doc').textContent = reg ? `${reg.docFormatado} (${reg.tipo}; no site: ${reg.doc})` : '–';
    $('im').textContent = reg ? reg.im : '–';
    $('arquivo').textContent = reg && dados.cndrecife_config ? `Downloads\\${LISTA.caminhoArquivo(dados.cndrecife_config.pasta, reg).replace(/\//g, '\\')}` : '–';
    $('confirmar').hidden = !(exec && !exec.encerrada && exec.fase === 'AGUARDANDO_CAPTCHA');
    const log = $('log');
    const fim = log.scrollTop + log.clientHeight >= log.scrollHeight - 5;
    log.textContent = (dados.cndrecife_log || []).slice(-80).map((l) => l.texto).join('\n');
    if (fim) log.scrollTop = log.scrollHeight;
  }

  async function atualizar() {
    mostrarEstado(await chrome.storage.local.get(['cndrecife_execucao', 'cndrecife_resultado', 'cndrecife_log', 'cndrecife_config']));
  }
  chrome.storage.onChanged.addListener((mud, area) => {
    if (area === 'local' && Object.keys(mud).some((k) => /^cndrecife_(execucao|resultado|log|config)$/.test(k))) atualizar();
  });

  (async () => {
    const { cndrecife_rascunho: r, cndrecife_config: c } = await chrome.storage.local.get(['cndrecife_rascunho', 'cndrecife_config']);
    $('pasta').value = (r && r.pasta) || (c && c.pastaDigitada) || 'CERTIDOES RECIFE';
    $('lista').value = (r && r.texto) || (c && c.texto) || '';
    analisar();
    atualizar();
  })();
})();
