// Interação com a página do portal Recife em Dia: esperar com limite de tempo, localizar e
// validar elementos, destacar o botão e mostrar o painel de registros. Não decide o fluxo
// (isso é o content.js) e não altera o conteúdo da página: o destaque e o painel ficam numa
// camada própria (shadow DOM), por cima, sem receber cliques.

(function (raiz) {
  const { CONFIG } = raiz.CNDRECIFE;
  const S = CONFIG.SELETORES;

  const dormir = (ms) => new Promise((r) => setTimeout(r, ms));
  const textoLimpo = (el) => (el && el.textContent ? el.textContent.replace(/\s+/g, ' ').trim() : '');

  // Repete `teste` até devolver algo verdadeiro ou estourar `limite`. Devolve o valor ou null.
  async function esperar(teste, limite, intervalo = CONFIG.TEMPOS.intervaloVerificacao) {
    const fim = Date.now() + limite;
    for (;;) {
      try {
        const r = teste();
        if (r) return r;
      } catch (e) {
        console.warn(CONFIG.PREFIXO_LOG, 'Erro durante a espera (segue tentando):', e);
      }
      if (Date.now() >= fim) return null;
      await dormir(intervalo);
    }
  }

  function visivel(el) {
    if (!el || !el.isConnected) return false;
    const st = getComputedStyle(el);
    if (st.display === 'none' || st.visibility === 'hidden' || Number(st.opacity) === 0) return false;
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0;
  }

  // O endereço é o do portal e da página esperados?
  function enderecoEsperado(loc = location) {
    return loc.hostname === CONFIG.HOST_ESPERADO && CONFIG.CAMINHO_ESPERADO.test(loc.pathname);
  }

  function paginaDeErro() {
    const corpo = document.body ? document.body.innerText.slice(0, 3000) : '';
    return !document.querySelector(S.titulo) && S.textoErroServidor.test(corpo);
  }

  // O título "Certidão Negativa de Débitos" (h1 do Drupal), visível.
  function localizarTitulo() {
    for (const h of document.querySelectorAll(S.titulo)) {
      if (S.textoTitulo.test(textoLimpo(h)) && visivel(h)) return h;
    }
    return null;
  }

  function dentroDeMenu(el) {
    return !!(el && el.closest(S.menus));
  }

  // Confere um candidato a botão "Emitir Certidão". Devolve a lista de problemas (vazia = ok).
  function problemasDoBotao(el, titulo) {
    const p = [];
    if (!S.textoBotaoEmitir.test(textoLimpo(el))) p.push(`texto diferente ("${textoLimpo(el)}")`);
    if (!S.hrefBotaoEmitir.test(el.getAttribute('href') || '')) p.push(`destino inesperado (${el.getAttribute('href')})`);
    if (dentroDeMenu(el)) p.push('está num menu de navegação');
    // Se o article da página existe, o link tem de estar nele. Se o site mudou o article, valem
    // as conferências de região e posição abaixo.
    if (document.querySelector(S.artigo) && !el.closest(S.artigo)) p.push('fora do conteúdo da página Certidão Negativa de Débitos');
    if (titulo) {
      // Precisa vir DEPOIS do título no documento e na mesma região de conteúdo.
      if (!(titulo.compareDocumentPosition(el) & Node.DOCUMENT_POSITION_FOLLOWING)) p.push('não está depois do título');
      const regiao = titulo.closest(S.regiaoConteudo);
      if (regiao && !regiao.contains(el)) p.push('fora da região do título');
      const rt = titulo.getBoundingClientRect();
      const rb = el.getBoundingClientRect();
      if (rb.top < rt.bottom - 1) p.push('não está abaixo do título na tela');
    }
    if (!visivel(el)) p.push('não está visível');
    if (el.getAttribute('aria-disabled') === 'true' || el.hasAttribute('disabled')) p.push('desabilitado');
    return p;
  }

  // Localiza o link "Emitir Certidão" desta página. 1º pelo seletor estável (article do nó +
  // destino /emissaoCertidao/); se não achar, pelo texto, na região de conteúdo e fora dos
  // menus. Só aceita se a validação completa passar e houver exatamente um candidato válido.
  function localizarBotao(titulo) {
    const tentativas = [
      { metodo: 'seletor', seletor: S.botaoEmitir, lista: () => [...document.querySelectorAll(S.botaoEmitir)] },
      {
        metodo: 'texto',
        seletor: `${S.regiaoConteudo} a (texto ${S.textoBotaoEmitir}, fora dos menus)`,
        lista: () => {
          const regiao = (titulo && titulo.closest(S.regiaoConteudo)) || document.querySelector(S.regiaoConteudo) || document;
          return [...regiao.querySelectorAll('a')].filter((a) => S.textoBotaoEmitir.test(textoLimpo(a)) && !dentroDeMenu(a));
        },
      },
    ];
    const rejeitados = [];
    for (const t of tentativas) {
      const candidatos = t.lista();
      const validos = candidatos.filter((el) => {
        const p = problemasDoBotao(el, titulo);
        if (p.length) rejeitados.push(`${t.metodo}: ${p.join('; ')}`);
        return !p.length;
      });
      if (validos.length === 1) return { el: validos[0], metodo: t.metodo, seletor: t.seletor, candidatos: candidatos.length };
      if (validos.length > 1) {
        return { el: null, motivo: `${validos.length} links "Emitir Certidão" válidos no conteúdo (ambíguo)`, rejeitados };
      }
    }
    return { el: null, motivo: rejeitados.length ? 'nenhum candidato passou na validação' : 'link não encontrado', rejeitados };
  }

  // Disponível para interação: depois de trazê-lo para a tela (rolagem não altera o conteúdo),
  // o ponto central do link é o próprio link (nada por cima dele).
  function disponivelParaInteracao(el) {
    let r = el.getBoundingClientRect();
    if (r.top < 0 || r.bottom > innerHeight || r.left < 0 || r.right > innerWidth) {
      el.scrollIntoView({ block: 'center', inline: 'nearest' });
      r = el.getBoundingClientRect();
    }
    const x = r.left + r.width / 2;
    const y = r.top + r.height / 2;
    const atingido = document.elementFromPoint(x, y);
    if (!atingido) return { ok: false, motivo: 'o link ficou fora da área visível' };
    if (atingido !== el && !el.contains(atingido)) {
      const nome = atingido.tagName.toLowerCase() + (atingido.id ? '#' + atingido.id : '');
      return { ok: false, motivo: `outro elemento cobre o link (${nome})` };
    }
    return { ok: true };
  }

  // Caminho CSS do elemento, só para o registro (não é usado para localizar).
  function caminhoCss(el) {
    const partes = [];
    for (let e = el; e && e.nodeType === 1 && e !== document.body; e = e.parentElement) {
      let s = e.tagName.toLowerCase();
      if (e.id) { partes.unshift(`${s}#${e.id}`); break; }
      if (e.tagName === 'ARTICLE' && e.getAttribute('about')) s += `[about="${e.getAttribute('about')}"]`;
      else if (e.classList.length) s += '.' + [...e.classList].slice(0, 2).join('.');
      partes.unshift(s);
    }
    return partes.join(' > ');
  }

  // ---- Camada visual (shadow DOM): destaque do botão e painel de registros ---------------

  let camada = null;
  function obterCamada() {
    if (camada && camada.host.isConnected) return camada;
    const host = document.createElement('cndrecife-camada');
    host.style.cssText = 'all:initial;position:absolute;top:0;left:0;width:0;height:0;z-index:2147483647;pointer-events:none';
    const sombra = host.attachShadow({ mode: 'open' });
    sombra.innerHTML = `
      <style>
        .moldura{position:absolute;border:3px solid ${CONFIG.DESTAQUE.cor};border-radius:4px;box-shadow:0 0 0 4px ${CONFIG.DESTAQUE.cor}55;pointer-events:none}
        .etiqueta{position:absolute;background:${CONFIG.DESTAQUE.cor};color:#fff;font:600 12px Segoe UI,Arial,sans-serif;padding:2px 6px;border-radius:3px;white-space:nowrap;pointer-events:none}
        .painel{position:fixed;right:12px;bottom:12px;width:430px;max-width:calc(100vw - 24px);background:#10213a;color:#e8eef7;
          font:12px/1.45 Consolas,monospace;padding:10px 12px;border-radius:8px;box-shadow:0 4px 18px #0006;pointer-events:auto}
        .painel[hidden]{display:none}
        .rolagem{max-height:30vh;overflow:auto;white-space:pre-wrap;margin-top:4px}
        .painel b{color:#fff}.sucesso{color:#7ee787}.falha{color:#ff8b8b}.aviso{color:#ffd479}
        .fechar{float:right;cursor:pointer;color:#9fb3cf;margin-left:8px}
        .acoes{margin-top:8px;padding:9px 10px;border-radius:6px;background:#fff4d6;color:#3a2a00;font:13px/1.4 Segoe UI,Arial,sans-serif}
        .acoes[hidden]{display:none}
        .acoes p{margin:0 0 7px;font-weight:600}
        .acoes .detalhe{font-weight:normal;font-size:12px;margin-top:-3px}
        .acoes button{font:600 12px Segoe UI,Arial,sans-serif;padding:6px 10px;margin:0 6px 4px 0;border-radius:5px;border:1px solid #1f5fa8;background:#1f5fa8;color:#fff;cursor:pointer}
        .acoes button.secundario{background:#fff;color:#1f5fa8}
      </style>
      <div class="painel" hidden><span class="fechar" title="Esconder">✕</span><b>${CONFIG.NOME}</b>
        <div class="rolagem"><span class="linhas"></span></div>
        <div class="acoes" hidden><p class="titulo"></p><p class="detalhe"></p><div class="botoes"></div></div>
      </div>`;
    sombra.querySelector('.fechar').addEventListener('click', () => { sombra.querySelector('.painel').hidden = true; });
    document.documentElement.appendChild(host);
    camada = { host, sombra };
    return camada;
  }

  function linhaNoPainel(texto) {
    const { sombra } = obterCamada();
    const painel = sombra.querySelector('.painel');
    painel.hidden = false;
    const span = document.createElement('span');
    if (/^\[SUCESSO\]/.test(texto)) span.className = 'sucesso';
    else if (/^\[(FALHA|ERRO)\]/.test(texto)) span.className = 'falha';
    else if (/^\[(AVISO|RECARGA)\]/.test(texto)) span.className = 'aviso';
    span.textContent = texto + '\n';
    sombra.querySelector('.linhas').appendChild(span);
    const rolagem = sombra.querySelector('.rolagem');
    rolagem.scrollTop = rolagem.scrollHeight;
  }

  // Caixa de ações no painel (mensagem + botões). botoes: [{ rotulo, acao, secundario }].
  // Sem argumentos, esconde.
  function mostrarAcoes(titulo, detalhe, botoes = []) {
    const { sombra } = obterCamada();
    const caixa = sombra.querySelector('.acoes');
    if (!titulo) { caixa.hidden = true; return; }
    sombra.querySelector('.painel').hidden = false;
    caixa.querySelector('.titulo').textContent = titulo;
    caixa.querySelector('.detalhe').textContent = detalhe || '';
    const area = caixa.querySelector('.botoes');
    area.textContent = '';
    for (const b of botoes) {
      const bt = document.createElement('button');
      bt.textContent = b.rotulo;
      if (b.secundario) bt.className = 'secundario';
      bt.addEventListener('click', (ev) => { ev.stopPropagation(); b.acao(); });
      area.appendChild(bt);
    }
    caixa.hidden = false;
  }
  function detalheAcoes(texto) {
    if (camada) camada.sombra.querySelector('.acoes .detalhe').textContent = texto || '';
  }

  // Moldura em volta do elemento, na camada própria (posição absoluta na página: acompanha a rolagem).
  function destacar(el, rotulo) {
    if (!CONFIG.DESTAQUE.ativo) return;
    const { sombra } = obterCamada();
    sombra.querySelectorAll('.moldura,.etiqueta').forEach((n) => n.remove());
    const moldura = document.createElement('div');
    moldura.className = 'moldura';
    const etiqueta = document.createElement('div');
    etiqueta.className = 'etiqueta';
    etiqueta.textContent = rotulo;
    sombra.append(moldura, etiqueta);
    const posicionar = () => {
      if (!el.isConnected) return;
      const r = el.getBoundingClientRect();
      const x = r.left + scrollX;
      const y = r.top + scrollY;
      Object.assign(moldura.style, { left: `${x - 6}px`, top: `${y - 4}px`, width: `${r.width + 12}px`, height: `${r.height + 8}px` });
      Object.assign(etiqueta.style, { left: `${x + r.width + 14}px`, top: `${y - 3}px` });
    };
    posicionar();
    addEventListener('resize', posicionar);
    if (CONFIG.DESTAQUE.duracao > 0) setTimeout(() => { moldura.remove(); etiqueta.remove(); }, CONFIG.DESTAQUE.duracao);
  }

  function removerDestaque() {
    if (camada) camada.sombra.querySelectorAll('.moldura,.etiqueta').forEach((n) => n.remove());
  }

  // ---- Clique real, acompanhado pelo cursor visual (mesmo padrão da CNDT) ----------------
  //
  // O cursor vai até o elemento em velocidade humana, para sobre ele e o clique é disparado
  // exatamente no ponto onde a seta está, com a sequência de eventos de um mouse. Antes,
  // confere que nada cobre o elemento nesse ponto: nesse caso não clica e devolve { ok: false }.
  const aleatorio = (min, max) => min + Math.random() * (max - min);
  async function clicar(el) {
    const CURSOR = raiz.CNDRECIFE.CURSOR;
    const C = CONFIG.CURSOR;
    const p = await CURSOR.moverPara(el);
    await dormir(aleatorio(C.paradaAntesDoCliqueMin, C.paradaAntesDoCliqueMax));

    const atingido = document.elementFromPoint(p.x, p.y);
    if (!atingido) return { ok: false, motivo: 'o elemento ficou fora da área visível da página' };
    if (atingido !== el && !el.contains(atingido)) {
      return { ok: false, motivo: `outro elemento cobre o alvo (${atingido.tagName.toLowerCase()}${atingido.id ? '#' + atingido.id : ''})` };
    }

    const base = { bubbles: true, cancelable: true, composed: true, view: window, clientX: p.x, clientY: p.y, button: 0 };
    const ponteiro = { ...base, pointerId: 1, pointerType: 'mouse', isPrimary: true };
    el.dispatchEvent(new PointerEvent('pointerover', ponteiro));
    el.dispatchEvent(new MouseEvent('mouseover', base));
    el.dispatchEvent(new PointerEvent('pointerdown', { ...ponteiro, buttons: 1 }));
    el.dispatchEvent(new MouseEvent('mousedown', { ...base, buttons: 1 }));
    CURSOR.animarClique(p.x, p.y);
    if (typeof el.focus === 'function') el.focus({ preventScroll: true });
    await dormir(aleatorio(C.botaoApertadoMin, C.botaoApertadoMax)); // botão apertado
    el.dispatchEvent(new PointerEvent('pointerup', ponteiro));
    el.dispatchEvent(new MouseEvent('mouseup', base));
    el.dispatchEvent(new MouseEvent('click', base)); // num link, o navegador segue o endereço
    return { ok: true, ponto: { x: Math.round(p.x), y: Math.round(p.y) } };
  }

  // ---- Tela seguinte: "Certidão Negativa de Débitos Mercantis" --------------------------

  // Devolve { pronta: true, ... } quando a tela está completa e utilizável; senão
  // { pronta: false, falta: '<o que ainda falta>' }.
  function estadoTelaEmissao() {
    const E = CONFIG.TELA_EMISSAO;
    const titulo = [...document.querySelectorAll(E.titulo)].find((h) => E.textoTitulo.test(textoLimpo(h)) && visivel(h));
    if (!titulo) return { pronta: false, falta: 'título da tela' };
    const form = document.querySelector(E.formulario);
    if (!form || !visivel(form)) return { pronta: false, falta: `formulário ${E.formulario}` };
    const carregando = document.querySelector(E.carregando);
    if (carregando && visivel(carregando)) return { pronta: false, falta: 'aviso "Carregando..." do site sumir' };
    const campo = document.querySelector(E.campoDocumento);
    if (!campo || !visivel(campo) || campo.disabled || campo.readOnly) return { pronta: false, falta: `campo CPF/CNPJ ${E.campoDocumento}` };
    const captcha = document.querySelector(E.campoCaptcha);
    if (!captcha || !visivel(captcha)) return { pronta: false, falta: `campo da verificação ${E.campoCaptcha}` };
    const img = document.querySelector(E.imagemCaptcha);
    if (!img || !img.complete || !img.naturalWidth) return { pronta: false, falta: 'imagem da verificação carregar' };
    const enviar = document.querySelector(E.botaoEnviar);
    if (!enviar || !visivel(enviar)) return { pronta: false, falta: `botão Enviar ${E.botaoEnviar}` };
    const campoIM = document.querySelector(E.campoInscricao);
    if (!campoIM || !visivel(campoIM) || campoIM.disabled || campoIM.readOnly) return { pronta: false, falta: `campo Inscrição Mercantil ${E.campoInscricao}` };
    return { pronta: true, titulo: textoLimpo(titulo), campo, campoIM, captcha, enviar };
  }

  // ---- Digitação humanizada (mesmo padrão da CNDT) ---------------------------------------

  const D = CONFIG.DIGITACAO;
  const setterValor = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
  const codigoDaTecla = (ch) => (/[0-9]/.test(ch) ? `Digit${ch}` : /[a-z]/i.test(ch) ? `Key${ch.toUpperCase()}` : '');

  // Uma tecla, com os eventos na ordem do navegador: keydown > keypress > beforeinput >
  // (valor muda) > input > [tecla apertada] > keyup. A máscara do site (mNum) roda no keyup,
  // a cada tecla, como faria com uma pessoa. Respeita o maxlength e um preventDefault do site.
  async function pressionar(campo, ch) {
    const tecla = { key: ch, code: codigoDaTecla(ch), keyCode: ch.charCodeAt(0), which: ch.charCodeAt(0), bubbles: true, cancelable: true, composed: true };
    const naoBloqueada = campo.dispatchEvent(new KeyboardEvent('keydown', tecla));
    if (naoBloqueada && campo.dispatchEvent(new KeyboardEvent('keypress', { ...tecla, charCode: ch.charCodeAt(0) }))) {
      const max = campo.maxLength > 0 ? campo.maxLength : Infinity;
      if (campo.value.length < max &&
          campo.dispatchEvent(new InputEvent('beforeinput', { inputType: 'insertText', data: ch, bubbles: true, cancelable: true, composed: true }))) {
        setterValor.call(campo, campo.value + ch);
        campo.dispatchEvent(new InputEvent('input', { inputType: 'insertText', data: ch, bubbles: true, composed: true }));
      }
    }
    const apertada = aleatorio(D.teclaApertadaMin, D.teclaApertadaMax);
    await dormir(apertada);
    campo.dispatchEvent(new KeyboardEvent('keyup', tecla));
    return apertada;
  }

  // Onde terminam os blocos do número, para a pausa de "leitura": CNPJ 2.3.3/4-2, CPF 3.3.3-2, IM 3.3-1.
  function fimDosBlocos(tamanho) {
    if (tamanho === 14) return [2, 5, 8, 12];
    if (tamanho === 11) return [3, 6, 9];
    if (tamanho === 7) return [3, 6];
    return [];
  }

  // Limpa como uma pessoa: Ctrl+A e Backspace. Devolve true se o campo ficou vazio.
  function apagarCampo(campo) {
    if (!campo.value) return true;
    const ctrlA = { key: 'a', code: 'KeyA', ctrlKey: true, bubbles: true, cancelable: true, composed: true };
    campo.dispatchEvent(new KeyboardEvent('keydown', ctrlA));
    campo.select();
    campo.dispatchEvent(new KeyboardEvent('keyup', ctrlA));
    const bs = { key: 'Backspace', code: 'Backspace', keyCode: 8, which: 8, bubbles: true, cancelable: true, composed: true };
    campo.dispatchEvent(new KeyboardEvent('keydown', bs));
    setterValor.call(campo, '');
    campo.dispatchEvent(new InputEvent('input', { inputType: 'deleteContentBackward', bubbles: true, composed: true }));
    campo.dispatchEvent(new KeyboardEvent('keyup', bs));
    return campo.value === '';
  }

  // Digita caractere por caractere, com intervalos variáveis. Se o campo perder o foco no
  // meio (a pessoa clicou em outro lugar), para e devolve { ok: false } em vez de digitar no
  // lugar errado.
  async function digitarHumanizado(campo, texto) {
    const caracteres = [...String(texto)];
    const blocos = fimDosBlocos(caracteres.length);
    await dormir(D.esperaAntesDeDigitar * aleatorio(0.8, 1.4));
    for (let i = 0; i < caracteres.length; i++) {
      if (document.activeElement !== campo) return { ok: false, motivo: 'o campo perdeu o foco durante a digitação' };
      const apertada = await pressionar(campo, caracteres[i]);
      if (i === caracteres.length - 1) break;
      let espera = aleatorio(D.intervaloMin, D.intervaloMax) - apertada;
      if (blocos.includes(i + 1)) espera += aleatorio(D.pausaEntreBlocosMin, D.pausaEntreBlocosMax);
      else if (Math.random() < D.chancePausa) espera += aleatorio(D.pausaMin, D.pausaMax);
      await dormir(Math.max(30, espera));
    }
    campo.dispatchEvent(new Event('change', { bubbles: true }));
    return { ok: true };
  }

  // Preenche um campo e confere. Se o valor já é o esperado, não digita de novo (sem
  // duplicar). Se há outro valor, apaga antes. Até `tentativas` digitações.
  // Devolve { ok, jaEstava, valor, motivo }.
  async function preencherCampo(campo, valor, tentativas = CONFIG.PREENCHIMENTO.tentativasPorCampo) {
    if (campo.value === valor) return { ok: true, jaEstava: true, valor };
    let motivo = '';
    for (let t = 1; t <= tentativas; t++) {
      const clique = await clicar(campo);
      if (!clique.ok) { motivo = `não foi possível clicar no campo: ${clique.motivo}`; continue; }
      if (document.activeElement !== campo) campo.focus({ preventScroll: true });
      if (campo.value && !apagarCampo(campo)) { motivo = 'o campo não pôde ser limpo'; continue; }
      const dig = await digitarHumanizado(campo, valor);
      await dormir(CONFIG.PREENCHIMENTO.esperaMascara); // a máscara do site age no keyup (setTimeout)
      if (dig.ok && campo.value === valor) return { ok: true, valor, tentativa: t };
      motivo = dig.ok ? `valor no campo "${campo.value}" diferente do esperado "${valor}"` : dig.motivo;
    }
    return { ok: false, motivo, valor: campo.value };
  }

  raiz.CNDRECIFE.PAGINA = {
    dormir, esperar, visivel, textoLimpo, enderecoEsperado, paginaDeErro,
    localizarTitulo, localizarBotao, problemasDoBotao, disponivelParaInteracao, caminhoCss,
    destacar, removerDestaque, linhaNoPainel, mostrarAcoes, detalheAcoes, clicar, estadoTelaEmissao,
    apagarCampo, digitarHumanizado, preencherCampo,
  };
})(typeof globalThis !== 'undefined' ? globalThis : self);
