@echo off
rem Uso pela janela de comando, sem interface grafica (equivale ao INICIAR.command do Mac).
rem Opcoes: --verificar --organizar --refazer-puladas --novo-lote
rem (a pasta de destino com nome so existe na interface: ABRIR_INTERFACE.cmd)
chcp 65001 >nul
cd /d "%~dp0"
echo Certidao de Debitos Trabalhistas (MTE) - Retirar_Auto_Infracao
where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo O Node.js nao esta instalado. Instale a versao LTS com:  winget install OpenJS.NodeJS.LTS
  echo ou em https://nodejs.org , feche e abra esta janela de novo.
  pause
  exit /b 1
)
node --input-type=module -e "await import('pdfjs-dist/legacy/build/pdf.mjs'); await import('@napi-rs/canvas')" >nul 2>nul
if errorlevel 1 (
  echo Instalando dependencias (so na primeira vez^)...
  call npm install --no-audit --no-fund
  if errorlevel 1 (
    echo Falhou. Confira a internet e rode de novo.
    pause
    exit /b 1
  )
)
echo Use o seu Chrome ja logado no gov.br. Para parar, digite s e Enter.
node src\cli.js %*
set CODIGO=%ERRORLEVEL%
echo.
echo Execucao encerrada. Confira a pasta do projeto e o relatorio em dados\.
pause
exit /b %CODIGO%
