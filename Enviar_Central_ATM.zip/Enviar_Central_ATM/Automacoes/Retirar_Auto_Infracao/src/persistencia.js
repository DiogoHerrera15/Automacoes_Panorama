// Arquivos do assistente: lista do dia, Controle.json, Relatorio.csv e PDFs do lote.
// Mesmos formatos e nomes do certidao-trabalhista.js original (as pastas de dados agora
// ficam em dados/).

import fs from 'node:fs';
import path from 'node:path';
import { MODELO_LISTA } from './config.js';
import { interpretarLista, nomeLimpo } from './documentos.js';
import { renomearComPaciencia } from './sistema.js';

export const SITUACAO = {
  pendente: 'pendente',
  salvo: 'PDF salvo',
  pulada: 'pulada',
};

export function agora() {
  return new Date().toLocaleString('pt-BR');
}

// 2026-11-05_09h40, na hora do computador.
export function carimbo() {
  const d = new Date();
  const dois = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${dois(d.getMonth() + 1)}-${dois(d.getDate())}_${dois(d.getHours())}h${dois(d.getMinutes())}`;
}

// --- Lista do dia (COLE_OS_CNPJS_AQUI.txt) ---

export function lerListaArquivo(cfg) {
  if (!fs.existsSync(cfg.arquivoLista)) fs.writeFileSync(cfg.arquivoLista, MODELO_LISTA, 'utf8');
  return interpretarLista(fs.readFileSync(cfg.arquivoLista, 'utf8'));
}

// Só as linhas de dados (sem o cabeçalho de comentários), para mostrar na interface.
export function lerTextoDaLista(cfg) {
  if (!fs.existsSync(cfg.arquivoLista)) return '';
  return fs.readFileSync(cfg.arquivoLista, 'utf8').replace(/^﻿/, '').split(/\r?\n/).filter((l) => l.trim() && !l.trim().startsWith('#')).join('\n');
}

// Grava a lista com o cabeçalho de sempre; `texto` são as linhas de dados.
export function salvarListaArquivo(cfg, texto) {
  const linhas = String(texto).replace(/^﻿/, '').split(/\r?\n/).filter((l) => l.trim());
  fs.writeFileSync(cfg.arquivoLista, `${MODELO_LISTA}${linhas.join('\n')}${linhas.length ? '\n' : ''}`, 'utf8');
}

// --- Controle.json ---

export function novoControle() {
  return { loteIniciadoEm: agora(), loteIniciadoMs: Date.now(), documentos: {} };
}

export function carregarControle(cfg) {
  try {
    return JSON.parse(fs.readFileSync(cfg.arquivoControle, 'utf8'));
  } catch (e) {
    if (e.code === 'ENOENT') return novoControle();
    throw new Error(`Não consegui ler ${cfg.arquivoControle}: ${e.message}`);
  }
}

// Para a interface: nunca lança, devolve null se não houver controle legível.
export function lerControleSeExiste(cfg) {
  try {
    return JSON.parse(fs.readFileSync(cfg.arquivoControle, 'utf8'));
  } catch {
    return null;
  }
}

// Grava num temporário e renomeia, para não deixar o controle pela metade se cair.
export function gravarControle(cfg, controle) {
  fs.mkdirSync(cfg.pastaDados, { recursive: true });
  const temporario = `${cfg.arquivoControle}.tmp`;
  fs.writeFileSync(temporario, JSON.stringify(controle, null, 2), 'utf8');
  renomearComPaciencia(temporario, cfg.arquivoControle); // no Windows, espera se outro programa estiver lendo
}

// --- Relatorio.csv ---

function celulaCsv(valor) {
  const texto = String(valor ?? '');
  return /[;"\r\n]/.test(texto) ? `"${texto.replace(/"/g, '""')}"` : texto;
}

// Devolve true se gravou; false se a planilha estava travada por outro programa.
export function gravarRelatorio(cfg, registros, controle) {
  const cabecalho = ['Linha', 'Empresa', 'CNPJ', 'Situação', 'Mensagem', 'PDF', 'Processado em'];
  const linhas = registros.map((r) => {
    const c = r.problema ? null : controle.documentos[r.chave];
    return c
      ? [r.linha, r.nome, r.documento, c.situacao, c.mensagem, c.pdf, c.processadoEm]
      : [r.linha, r.nome, r.documento, 'CPF/CNPJ inválido', r.problema, '', ''];
  });
  // BOM e ";" para o Excel em português abrir com acentos e colunas certas.
  const csv = `﻿${[cabecalho, ...linhas].map((l) => l.map(celulaCsv).join(';')).join('\r\n')}\r\n`;
  fs.mkdirSync(cfg.pastaDados, { recursive: true });
  try {
    fs.writeFileSync(cfg.arquivoRelatorio, csv, 'utf8');
    return true;
  } catch (e) {
    if (e.code !== 'EBUSY' && e.code !== 'EPERM' && e.code !== 'EACCES') throw e;
    return false;
  }
}

// --- Lote ---

// Fecha o lote: guarda o relatório em dados/Relatorios/ e apaga o controle e a lista do
// dia, para o próximo lote começar do zero.
export function encerrarLote(cfg) {
  let pastaLote = '';
  try {
    pastaLote = JSON.parse(fs.readFileSync(cfg.arquivoControle, 'utf8')).pastaLote ?? '';
  } catch {
    // Sem controle: não há pasta de lote para guardar o relatório.
  }
  if (fs.existsSync(cfg.arquivoRelatorio)) {
    fs.mkdirSync(cfg.pastaRelatorios, { recursive: true });
    fs.copyFileSync(cfg.arquivoRelatorio, path.join(cfg.pastaRelatorios, `Relatorio_${carimbo()}.csv`));
    // A pasta de destino pode ser reaproveitada em outro lote: o relatório novo nunca
    // sobrescreve o anterior (Relatorio.csv, Relatorio (2).csv...).
    if (pastaLote && fs.existsSync(pastaLote)) fs.copyFileSync(cfg.arquivoRelatorio, caminhoLivre(pastaLote, 'Relatorio', '.csv'));
  }
  fs.rmSync(cfg.arquivoControle, { force: true });
  fs.rmSync(cfg.arquivoRelatorio, { force: true });
  fs.writeFileSync(cfg.arquivoLista, MODELO_LISTA, 'utf8');
}

// Primeiro caminho livre `<pasta>/<base><ext>`, depois `<base> (2)<ext>`, `(3)`...
export function caminhoLivre(pasta, base, ext) {
  for (let n = 1; ; n++) {
    const caminho = path.join(pasta, n === 1 ? `${base}${ext}` : `${base} (${n})${ext}`);
    if (!fs.existsSync(caminho)) return caminho;
  }
}

// Nomes que o arquivo da empresa pode ter, do preferido ao alternativo:
//   NOME DA EMPRESA                  (o que o usuário vê na lista)
//   NOME DA EMPRESA - <CNPJ>         (se já existe um arquivo com esse nome, ou se outra
//                                     empresa da lista tem o mesmo nome: `nomeDuplicado`)
//   <CNPJ>                           (empresa sem nome: nunca interrompe a execução)
export function candidatosDeNome(empresa) {
  const nome = nomeLimpo(empresa.nome);
  if (!nome) return [empresa.chave];
  const comDocumento = `${nome} - ${empresa.chave}`;
  return empresa.nomeDuplicado ? [comDocumento] : [nome, comDocumento];
}

// Grava o PDF na pasta de destino pelo primeiro nome livre. O "wx" falha se o arquivo já
// existe, então um documento anterior nunca é sobrescrito; se todos os nomes estiverem
// ocupados, o último ganha " (2)", " (3)"... Devolve o caminho gravado.
export function salvarPdf(pastaDoLote, empresa, pdf) {
  const candidatos = candidatosDeNome(empresa);
  fs.mkdirSync(pastaDoLote, { recursive: true }); // se a pasta tiver sido apagada no meio da execução
  const tentar = (base, n) => {
    const arquivo = path.join(pastaDoLote, n === 1 ? `${base}.pdf` : `${base} (${n}).pdf`);
    try {
      fs.writeFileSync(arquivo, pdf, { flag: 'wx' });
      return arquivo;
    } catch (e) {
      if (e.code !== 'EEXIST') throw e;
      return null;
    }
  };
  for (const base of candidatos) {
    const arquivo = tentar(base, 1);
    if (arquivo) return arquivo;
  }
  for (let n = 2; ; n++) {
    const arquivo = tentar(candidatos.at(-1), n);
    if (arquivo) return arquivo;
  }
}

// Marca `nomeDuplicado` nas empresas cujo nome (sem diferenciar maiúsculas) é igual ao de
// outra empresa da lista: todas passam a usar "NOME - CNPJ", e nenhuma fica com o nome
// puro, que ficaria ambíguo.
export function marcarNomesDuplicados(empresas) {
  const porNome = new Map();
  for (const empresa of empresas) {
    const nome = nomeLimpo(empresa.nome).toLowerCase();
    if (nome) porNome.set(nome, [...(porNome.get(nome) ?? []), empresa]);
  }
  for (const empresa of empresas) delete empresa.nomeDuplicado;
  for (const grupo of porNome.values()) {
    if (grupo.length > 1) for (const empresa of grupo) empresa.nomeDuplicado = true;
  }
}
