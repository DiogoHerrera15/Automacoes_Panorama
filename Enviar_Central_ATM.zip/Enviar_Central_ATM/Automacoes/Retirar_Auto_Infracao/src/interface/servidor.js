// Servidor da interface gráfica: uma página web local (só neste computador) que controla o
// mesmo Assistente usado pelo terminal.
//
//   GET  /                 página (com o token da sessão)
//   GET  /api/estado       situação atual                                  (token)
//   GET  /api/eventos      fluxo de eventos (SSE): 'estado' e 'log'         (token na URL)
//   POST /api/validar      confere um texto de lista, sem salvar
//   POST /api/lista        salva a lista do dia (COLE_OS_CNPJS_AQUI.txt)
//   POST /api/iniciar      inicia/continua o lote
//   POST /api/comando      c = copiar de novo, p = pular, s = parar
//   POST /api/organizar    move para o lote as certidões que já estão em Downloads
//   POST /api/novo-lote    encerra o lote atual (apaga lista e controle)
//   POST /api/abrir-pasta  abre a pasta do lote ou a pasta do projeto no Finder
//   POST /api/encerrar     fecha a interface
//
// Segurança: escuta só em 127.0.0.1; confere o cabeçalho Host (contra DNS rebinding) e
// exige o token da sessão em toda chamada, o que impede que outra página aberta no
// navegador controle a automação.

import crypto from 'node:crypto';
import fs from 'node:fs';
import http from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { Assistente, ErroDeUso } from '../assistente.js';
import { criarConfig, PORTA_INTERFACE } from '../config.js';
import os from 'node:os';
import { interpretarLista, nomeDePasta } from '../documentos.js';
import { lerListaArquivo, salvarListaArquivo } from '../persistencia.js';
import { contarItens, montarItens } from '../resumo.js';
import { WINDOWS, abrirPasta as abrirPastaNoSistema } from '../sistema.js';

export const NOME_APP = 'retirar-auto-infracao';

const PUBLICO = path.join(path.dirname(fileURLToPath(import.meta.url)), 'publico');
const ARQUIVOS = {
  '/app.js': ['app.js', 'text/javascript; charset=utf-8'],
  '/estilo.css': ['estilo.css', 'text/css; charset=utf-8'],
};
const LIMITE_CORPO = 1_000_000;

class ErroHttp extends Error {
  constructor(status, mensagem) {
    super(mensagem);
    this.status = status;
  }
}

// Finder no macOS, Explorador de Arquivos no Windows.
function abrirNoFinder(caminho) {
  abrirPastaNoSistema(caminho);
}

function responder(res, status, dados) {
  const corpo = JSON.stringify(dados);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(corpo);
}

function lerCorpo(req) {
  return new Promise((resolve, reject) => {
    let tamanho = 0;
    const partes = [];
    req.on('data', (parte) => {
      tamanho += parte.length;
      if (tamanho > LIMITE_CORPO) {
        reject(new ErroHttp(413, 'Corpo grande demais.'));
        req.destroy();
        return;
      }
      partes.push(parte);
    });
    req.on('end', () => {
      try {
        resolve(partes.length ? JSON.parse(Buffer.concat(partes).toString('utf8')) : {});
      } catch {
        reject(new ErroHttp(400, 'JSON inválido.'));
      }
    });
    req.on('error', reject);
  });
}

// Sobe a interface. `porta: 0` escolhe uma porta livre (testes). Devolve
// { porta, url, token, assistente, fechar }.
export async function iniciarInterface({
  cfg = criarConfig(),
  porta = PORTA_INTERFACE,
  assistente = new Assistente(cfg),
  abrirPasta = abrirNoFinder,
  aoEncerrar = () => {},
} = {}) {
  const token = crypto.randomBytes(24).toString('hex');
  const clientes = new Set();
  let portaReal = porta;

  const enviar = (res, evento, dados) => res.write(`event: ${evento}\ndata: ${JSON.stringify(dados)}\n\n`);
  assistente.on('log', (entrada) => clientes.forEach((r) => enviar(r, 'log', entrada)));
  assistente.on('estado', () => {
    if (!clientes.size) return;
    const snapshot = assistente.snapshot();
    clientes.forEach((r) => enviar(r, 'estado', snapshot));
  });

  const hostPermitido = (req) => [`127.0.0.1:${portaReal}`, `localhost:${portaReal}`].includes(req.headers.host ?? '');
  const tokenOk = (req, url) => (req.headers['x-token'] ?? url.searchParams.get('t')) === token;

  // Lista pronta para o clique em "Iniciar": salva o texto (se veio) e confere se há algo válido.
  function prepararLista(texto) {
    if (typeof texto === 'string') salvarListaArquivo(cfg, texto);
    const registros = lerListaArquivo(cfg);
    if (!registros.some((r) => !r.problema)) {
      throw new ErroHttp(400, registros.length ? 'Não há nenhum CPF/CNPJ válido na lista. Corrija as linhas marcadas como inválidas.' : 'A lista está vazia. Informe pelo menos um CPF ou CNPJ.');
    }
  }

  function exigirOcioso(mensagem = 'Pare a execução antes de fazer isso.') {
    if (assistente.fase !== 'ocioso') throw new ErroHttp(409, mensagem);
  }

  // Roda em segundo plano; erros viram mensagem no registro, sem derrubar a interface.
  function executarEmSegundoPlano(opcoes) {
    assistente.executar(opcoes).catch((e) => assistente.log(e instanceof ErroDeUso ? e.message : `Erro inesperado: ${e.stack ?? e.message}`, 'erro'));
  }

  const numeroPausa = (valor) => Math.min(600, Math.max(0, Number(valor) || 0));

  // Pasta principal pedida na tela (opcional): caminho completo de uma pasta que já existe.
  function lerPastaPrincipal(valor) {
    if (typeof valor !== 'string' || !valor.trim()) return undefined;
    let pasta = valor.trim();
    if (pasta === '~' || pasta.startsWith('~/')) pasta = path.join(os.homedir(), pasta.slice(1));
    if (!path.isAbsolute(pasta)) throw new ErroHttp(400, WINDOWS
      ? 'A pasta principal precisa ser um caminho completo (por exemplo C:\\Users\\voce\\Downloads).'
      : 'A pasta principal precisa ser um caminho completo (começando com / ou ~).');
    pasta = path.resolve(pasta);
    if (!fs.existsSync(pasta) || !fs.statSync(pasta).isDirectory()) throw new ErroHttp(400, `A pasta principal não existe: ${pasta}`);
    return pasta;
  }

  // "Nome da pasta de destino" e pasta principal, prontos para o assistente. Sem `nomePasta`
  // na chamada, vale o comportamento de antes (lote em andamento ou Lote_AAAA-MM-DD_HHhMM).
  function lerDestino(corpo) {
    const destino = { pastaPrincipal: lerPastaPrincipal(corpo.pastaPrincipal) };
    if (corpo.nomePasta !== undefined) {
      if (typeof corpo.nomePasta !== 'string' || !nomeDePasta(corpo.nomePasta)) throw new ErroHttp(400, 'Informe o nome da pasta de destino.');
      destino.nomePasta = corpo.nomePasta;
    }
    return destino;
  }

  // Mostra na tela onde os PDFs vão ficar e se a pasta já existe (sem criar nada).
  function descreverDestino(corpo) {
    let principal;
    try {
      principal = lerPastaPrincipal(corpo.pastaPrincipal) ?? cfg.pastaPrincipal;
    } catch (e) {
      return { erro: e.message };
    }
    const nome = nomeDePasta(String(corpo.nomePasta ?? ''));
    if (!nome) return { principal, nome: '', caminho: '', existe: false, arquivos: 0, erro: String(corpo.nomePasta ?? '').trim() ? 'Esse nome não pode ser usado (só tem caracteres proibidos).' : '' };
    const caminho = path.join(principal, nome);
    const existe = fs.existsSync(caminho);
    let arquivos = 0;
    try {
      if (existe) arquivos = fs.readdirSync(caminho).filter((a) => !a.startsWith('.')).length;
    } catch {
      // Sem permissão para listar: só não mostra a contagem.
    }
    return { principal, nome, caminho, existe, arquivos, erro: '' };
  }

  const rotasPost = {
    '/api/validar': (corpo) => {
      const itens = montarItens(interpretarLista(String(corpo.texto ?? '')), null);
      const resposta = { itens, contagem: contarItens(itens) };
      if (typeof corpo.nomePasta === 'string') resposta.destino = descreverDestino(corpo);
      return resposta;
    },
    '/api/lista': (corpo) => {
      exigirOcioso('A lista não pode ser alterada durante a execução.');
      salvarListaArquivo(cfg, corpo.texto ?? '');
      assistente.mudou();
      return { ok: true };
    },
    '/api/iniciar': (corpo) => {
      exigirOcioso('Já existe uma execução em andamento.');
      const destino = lerDestino(corpo);
      prepararLista(corpo.texto);
      const pausaMin = numeroPausa(corpo.pausaMin);
      executarEmSegundoPlano({ ...destino, refazerPuladas: Boolean(corpo.refazerPuladas), pausaMin, pausaMax: Math.max(pausaMin, numeroPausa(corpo.pausaMax)) });
      return { ok: true };
    },
    '/api/comando': (corpo) => {
      if (!['c', 'p', 's'].includes(corpo.comando)) throw new ErroHttp(400, 'Comando desconhecido.');
      if (assistente.fase !== 'executando') throw new ErroHttp(409, 'Não há execução em andamento.');
      assistente.enviarComando(corpo.comando);
      return { ok: true };
    },
    '/api/organizar': (corpo) => {
      exigirOcioso();
      const destino = lerDestino(corpo);
      prepararLista(corpo.texto);
      executarEmSegundoPlano({ ...destino, organizar: true });
      return { ok: true };
    },
    '/api/novo-lote': () => {
      exigirOcioso();
      try {
        assistente.novoLote();
      } catch (e) {
        throw new ErroHttp(500, `Não consegui encerrar o lote: ${e.message}`);
      }
      return { ok: true };
    },
    '/api/abrir-pasta': (corpo) => {
      const { pastaLote } = assistente.snapshot();
      const alvo = corpo.alvo === 'lote' && pastaLote && fs.existsSync(pastaLote) ? pastaLote : cfg.raiz;
      abrirPasta(alvo);
      return { ok: true, pasta: alvo };
    },
    '/api/encerrar': () => {
      exigirOcioso('Pare a execução antes de fechar a interface.');
      setTimeout(() => aoEncerrar(), 200);
      return { ok: true };
    },
  };

  async function tratar(req, res) {
    const url = new URL(req.url, 'http://interface.local');
    if (!hostPermitido(req)) throw new ErroHttp(403, 'Host não permitido.');

    if (req.method === 'GET') {
      if (url.pathname === '/api/ping') return responder(res, 200, { app: NOME_APP });
      if (url.pathname === '/') {
        const html = fs.readFileSync(path.join(PUBLICO, 'index.html'), 'utf8').replace('{{TOKEN}}', token);
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
        return res.end(html);
      }
      if (ARQUIVOS[url.pathname]) {
        const [arquivo, tipo] = ARQUIVOS[url.pathname];
        res.writeHead(200, { 'Content-Type': tipo, 'Cache-Control': 'no-store' });
        return res.end(fs.readFileSync(path.join(PUBLICO, arquivo)));
      }
      if (url.pathname === '/api/estado') {
        if (!tokenOk(req, url)) throw new ErroHttp(403, 'Token inválido.');
        return responder(res, 200, assistente.snapshot());
      }
      if (url.pathname === '/api/eventos') {
        if (!tokenOk(req, url)) throw new ErroHttp(403, 'Token inválido.');
        res.writeHead(200, { 'Content-Type': 'text/event-stream; charset=utf-8', 'Cache-Control': 'no-store', Connection: 'keep-alive' });
        res.write('retry: 2000\n\n');
        enviar(res, 'logs', assistente.logs);
        enviar(res, 'estado', assistente.snapshot());
        clientes.add(res);
        req.on('close', () => clientes.delete(res));
        return undefined;
      }
      throw new ErroHttp(404, 'Não encontrado.');
    }

    if (req.method === 'POST') {
      if (!tokenOk(req, url)) throw new ErroHttp(403, 'Token inválido.');
      if (!/^application\/json/i.test(req.headers['content-type'] ?? '')) throw new ErroHttp(415, 'Use application/json.');
      if (req.headers.origin && req.headers.origin !== `http://${req.headers.host}`) throw new ErroHttp(403, 'Origem não permitida.');
      const rota = rotasPost[url.pathname];
      if (!rota) throw new ErroHttp(404, 'Não encontrado.');
      return responder(res, 200, await rota(await lerCorpo(req)));
    }
    throw new ErroHttp(405, 'Método não permitido.');
  }

  const servidor = http.createServer((req, res) => {
    tratar(req, res).catch((e) => {
      if (res.headersSent) return res.end();
      const status = e instanceof ErroHttp ? e.status : e instanceof ErroDeUso ? 400 : 500;
      return responder(res, status, { erro: e.message });
    });
  });

  await new Promise((resolve, reject) => {
    servidor.once('error', reject);
    servidor.listen(porta, '127.0.0.1', resolve);
  });
  portaReal = servidor.address().port;

  const heartbeat = setInterval(() => clientes.forEach((r) => r.write(': batimento\n\n')), 15000);
  heartbeat.unref();

  return {
    porta: portaReal,
    url: `http://127.0.0.1:${portaReal}/`,
    token,
    assistente,
    fechar: () => new Promise((resolve) => {
      clearInterval(heartbeat);
      clientes.forEach((r) => r.end());
      clientes.clear();
      servidor.close(() => resolve());
      servidor.closeAllConnections?.();
    }),
  };
}
