# Situacao_Fiscal — versão 1.3.1

## Painel (interface externa) — aberto pela Central de Automações

O cartão **SITUAÇÃO FISCAL** da Central abre `painel/painel.html`, uma página da própria extensão. Ela é o painel
principal: configura, inicia, pausa, para e acompanha a execução. A janela do ícone mostra só um resumo e o botão
**Abrir painel**.

**Fluxo:** Central → SITUAÇÃO FISCAL → pasta → lista `cnpj;nome_empresa` → **Salvar e preparar execução** → login
no e-CAC (manual) → a automação começa sozinha → acompanhar no painel.

- **Nome da pasta de destino:** fica dentro de Downloads. Use `/` para subpastas (ex.:
  `Situacao_Fiscal_Cliente/Certificado`). Cada empresa ganha a própria subpasta.
- **CNPJs e empresas:** um por linha (`cnpj;nome_empresa`, com ou sem máscara; aceita colar do Excel). Cada linha é
  validada sozinha. **Registros inválidos nunca bloqueiam os válidos**: são ignorados e listados à parte, com o
  motivo. Os casos tratados são CPF, quantidade de dígitos errada, dígitos verificadores inválidos, letras e repetidos.
  Zeros à esquerda são preservados; se o Excel os tirou, são repostos. Se nenhum registro for válido, o painel avisa
  que não há empresa apta.
- **Salvar e preparar execução:** grava a configuração e o comando "executar" e abre o e-CAC (ou a página Minhas
  Dívidas, se já estiver aberta). O que se digita no painel também fica salvo como rascunho.
- **Início automático:** quando a aba chega à página inicial **autenticada** do e-CAC (`cav.receita.fazenda.gov.br/ecac/`),
  o service worker leva essa aba para Minhas Dívidas e Pendências, e a página começa sozinha. Isso só acontece com
  execução preparada, comando "executar", CNPJs restantes e nenhuma outra aba já na página. Não há laço: o
  service worker abre a página no máximo uma vez a cada 60 s por aba. Abrir o portal **sem** execução preparada não
  inicia nada. Login, certificado e captcha são sempre manuais.
- **Iniciar / Continuar · Pausar · Parar com segurança:** Pausar e Parar valem **ao terminar a empresa atual** (nenhum
  download fica pela metade). Continuar retoma de onde parou.
- **Abrir pasta de resultados:** grava `Resumo_Situacao_Fiscal.csv` na pasta (situação de cada CNPJ e os
  ignorados) e abre o Explorador nela.
- **Zerar progresso:** dois cliques; só com a execução parada. Os arquivos ficam.
- **Acompanhamento em tempo real:**
  - status, pasta, total de registros, válidos, ignorados, concluídas, restantes, erro de procuração e falha de
    navegação;
  - barra de progresso, empresa e CNPJ atuais, etapa e último concluído;
  - tabela das empresas (com filtros) e histórico de eventos;
  - estados: em execução, recuperando falha, pausada, parada, concluída (com ou sem pendentes), aguardando login,
    aguardando intervenção manual.

**Comunicação:** só por `chrome.storage.local`, sem portas, sem programa externo e sem caminhos fixos. Cada chave tem
um único escritor (`comum.js` → `SF.CHAVES`):

| Chave | Quem grava |
|---|---|
| `situacao_fiscal_config` e `situacao_fiscal_controle` | o painel |
| `situacao_fiscal_status` e `situacao_fiscal_eventos` | a página do portal |
| `situacao_fiscal_bg` | o service worker |

A página publica uma pulsação a cada 4 s. Sem pulsação há mais de 15 s, o painel considera a página fechada e se
reconecta sozinho quando ela volta. Uma segunda aba na página não inicia enquanto a primeira estiver ativa, o que
evita consultas em dobro.

A lista `DOCUMENTOS` e a `PASTA_RAIZ` no início do `content.js` ficaram só como referência; a lista em uso vem do
painel. Na 1.2.0, uma configuração antiga (da janela do ícone) aparece no painel, mas só roda depois de "Salvar e
preparar execução".

**Placar:** o aviso no canto inferior esquerdo mostra sempre, no topo, quantos CNPJs da lista já foram analisados e
quantos faltam, com uma barra de progresso. Ex.: `Analisados: 207 de 208 (99%) · Faltam: 1 (1 pendente)`. "Analisado"
é o CNPJ concluído, inclusive o erro de procuração com evidência salva.

Processa uma **lista de CNPJs**, um por vez. Para cada um, na página **Minhas Dívidas e Pendências**
(`https://servicos.receitafederal.gov.br/servico/pendencias/#/analise-pendencias`):

1. reconhece a tela (título + blocos **Dados Cadastrais** e **Resultado da Análise**) e registra a estrutura no console;
2. aceita os cookies, se o aviso estiver visível (um único clique em **Aceitar**);
3. abre o perfil no canto superior direito (avatar + identificação + seta);
4. confirma o painel lateral (**Representar** e **Representações Recentes**);
5. digita o CPF/CNPJ em **Digite o CPF ou CNPJ** (só os dígitos; a máscara do portal formata) e confere o valor;
6. abre **Digite um perfil de representação** e escolhe a opção com texto exatamente **Procurador**;
7. espera o botão azul **Representar** habilitar e clica uma única vez;
8. espera **Representação Atual** e compara o CNPJ ao lado de "Procurador de:" com o pedido. Se divergir, para sem salvar.
   Se o portal **recusar** (ex.: "Sua autorização como procurador não permite acesso a este serviço."), confere o CNPJ
   no campo, recorta da seção **Trocar Representação** até o campo **Procurador** (CNPJ, mensagem e perfil; sem o
   botão), salva o PDF de evidência e segue para o próximo CNPJ;
   Se a empresa **já estiver** em Representação Atual (ex.: retomada após F5), não representa de novo e vai à etapa 9.
   A extensão **nunca encerra uma representação**: se aparecer a confirmação "Encerrar representação — Você tem
   certeza…?", clica em **Cancelar** e continua o processo de onde estava. O CNPJ da própria conta logada segue o fluxo normal de Trocar Representação; se o portal recusar, salva a evidência;
9. fecha o painel com um clique no fundo escurecido e confere que a página mostra o CNPJ representado;
10. lê o **status** e a **mensagem** do Resultado da Análise (registra, por exemplo, "débito a vencer"). Se for
    **Com pendência**, captura a tela e salva em PDF antes de rolar;
11. em **qualquer** status, rola a página de forma gradual (passando pelo Detalhamento da Análise) até os botões do
    rodapé, vê quais existem e baixa **um por vez**: **Baixar Certidão** → `Certidao_<EMPRESA>.pdf`, depois
    **Baixar Relatório** → `situação fiscal/Relatorio_<EMPRESA>.pdf` (extensão original). Só avança para o próximo
    CNPJ com os arquivos confirmados.

**Falha no download (certidão ou relatório)** — a própria extensão recarrega e tenta de novo, sem F5 manual:

- gatilhos: o portal mostra um aviso de falha (ex.: "Não foi possível emitir a certidão. Tente novamente daqui alguns
  minutos", código **043**) antes de o download começar, **ou** o download não começa em 30 s após o clique;
- o primeiro gatilho encerra a tentativa e dispara **uma única** recarga. Antes do F5, a extensão guarda o CNPJ, a
  etapa e os arquivos já salvos;
- depois do F5, confere o mesmo CNPJ (Representação Atual e Dados Cadastrais) e baixa **só o documento que falta**.
  Um documento só conta como salvo quando o download termina. Se o download já começou, a extensão acompanha até o
  fim;
- espera antes da recarga: 15 s na 1ª (`ESPERA_DOWNLOAD_1A_MS`); se persistir, 2 min ("alguns minutos",
  `ESPERA_FALHA_PORTAL_MS`). No máximo `MAX_RECARGAS_DOWNLOAD` (4) recargas; esgotadas, o CNPJ fica **PENDENTE**,
  com o motivo registrado, e a fila segue (nova tentativa no fim da lista).

Só um arquivo salvo **fora da pasta esperada** para a execução com aviso vermelho e pede F5, por segurança.

## Falhas temporárias do portal

Quando o portal mostra "Não foi possível concluir a ação para o contribuinte… tente novamente dentro de alguns
minutos", fica carregando sem progresso (`TIMEOUT_CARREGANDO_MS`, 60 s) ou não confirma a representação:

1. guarda o CNPJ atual, a etapa em que parou e os arquivos já salvos;
2. espera (o número de minutos que o portal indicar; "alguns minutos" = `ESPERA_FALHA_PORTAL_MS`, 2 min;
   carregamento travado = `ESPERA_CARREGAMENTO_MS`, 15 s), com contagem regressiva no aviso;
3. recarrega a página (F5) e retoma o **mesmo** CNPJ: se ele continua em Representação Atual, vai direto à análise;
   se a representação se perdeu, refaz CNPJ + Procurador + Representar. Só baixa o que ainda falta;
4. no máximo `MAX_RECARGAS_POR_CNPJ` (3) recargas por CNPJ. Persistindo, o CNPJ fica **PENDENTE** e a fila segue.
   No fim, o aviso lista os pendentes; um F5 depois tenta de novo só esses.

### "Estamos processando sua solicitação. Tente novamente em instantes."

Reconhecida pelo texto (a data e a hora depois dela são ignoradas), em qualquer etapa — inclusive na etapa 1, em que
a tela "em processamento" já vale como página reconhecida (o perfil continua no cabeçalho):

1. a extensão acompanha a página por até `ESPERA_PROCESSANDO_NA_PAGINA_MS` (60 s); se o resultado aparecer, confere o
   CNPJ em Dados Cadastrais e segue normalmente;
2. se demorar mais, o CNPJ fica **PENDENTE** (arquivos já salvos preservados) e a extensão **segue para o próximo
   CNPJ**, sem recarregar: abre o perfil e usa Trocar Representação a partir da própria tela "em processamento";
3. no fim da lista, tenta os pendentes de novo (`RODADAS_PENDENTES`, 1 vez). Se ainda falharem, o aviso final lista
   os pendentes; um F5 mais tarde tenta só esses.

### Recarga depois de "Representar" com a empresa anterior

Se o portal recarregar a página logo depois de **Representar** e ela voltar mostrando a empresa **anterior** (a
representação não pegou), a extensão repete o **mesmo CNPJ**: abre o perfil, Trocar Representação, CNPJ, Procurador e
Representar. Até `MAX_TENTATIVAS_REPRESENTAR` (3) tentativas seguidas; depois, o CNPJ fica PENDENTE e a fila segue.

## Intervalo entre empresas

Depois de concluir uma empresa (downloads ou evidência de erro de procuração salvos), espera pelo menos
`INTERVALO_ENTRE_EMPRESAS_MS` (5 s) e a página parar de carregar antes de abrir o perfil para a próxima.

## Vários downloads

A extensão libera, **só para `servicos.receitafederal.gov.br`**, a permissão do Chrome "Downloads automáticos"
(evita o bloqueio "Este site tentou baixar vários arquivos"). Ela é aplicada na instalação e antes de cada download.
Para conferir ou desfazer: `chrome://settings/content/automaticDownloads`. Os documentos continuam sendo baixados um
por vez, e cada arquivo é conferido na pasta da empresa certa.

## Onde os arquivos ficam

Dentro dos Downloads do Chrome (o Chrome não deixa extensões gravarem fora dela), na pasta informada no painel.
Desde a v1.3.0, **cada arquivo leva o nome da empresa** (o mesmo da pasta), além do tipo do documento:

```
<pasta do painel>/<EMPRESA>/Certidao_<EMPRESA>.pdf                                (certidão, quando o portal oferece)
<pasta do painel>/<EMPRESA>/situação fiscal/Relatorio_<EMPRESA>.pdf               (relatório; extensão original)
<pasta do painel>/<EMPRESA>/Com_Pendencia_<EMPRESA>.pdf                           (só com pendência)
<pasta do painel>/<EMPRESA>/Erro_de_Procuracao/Erro_de_Procuracao_<EMPRESA>.pdf   (quando o portal recusa)
```

- O CNPJ continua sendo usado nas consultas e no registro interno (o progresso guarda, por CNPJ, o caminho de cada
  arquivo); o nome da empresa só identifica pastas e arquivos.
- **Nada é sobrescrito:** se o arquivo já existir (ex.: lista rodada de novo após "Zerar"), o Chrome numera o novo
  (`Certidao_<EMPRESA> (1).pdf`). Na retomada normal não há cópias: só o documento que falta é baixado.
- Um documento só conta como salvo quando o download termina, na pasta da empresa certa e com o nome pedido
  (`SF.arquivoConfere`, que aceita a numeração).
- Nome muito longo: o caminho relativo fica em até 215 caracteres (limite do Windows); só o nome do arquivo é
  encurtado, a pasta mantém o nome inteiro.
- Arquivos baixados por versões anteriores (`RFB_<CNPJ>.pdf`, `Com_Pendencia_<CNPJ>.pdf`, relatório com o nome
  original) **não são alterados**.

- `<EMPRESA>` = o nome escrito na lista depois do `;` (ex.: `PRATICA CONSULTORIA & CONSTRUCOES LTDA`). Sem nome na
  lista, usa o nome de Dados Cadastrais; sem nenhum dos dois, os dígitos do CNPJ. Caracteres que o Windows não aceita
  (`<>:"/\|?*`) viram `_`; ponto no fim do nome é retirado.
- Nome repetido na lista (ex.: filiais, todas "… LTDA PE") ganha o nº da filial no fim, na pasta **e** nos arquivos:
  `… LTDA PE 0002`, `… LTDA PE 0003`… Empresas diferentes com o mesmo nome e a mesma filial ganham o CNPJ inteiro.
- Cada pasta raiz tem o próprio registro de progresso: numa pasta nova, a lista começa do primeiro CNPJ.

## Empresa representada (etapa 8) — v1.3.1

- A empresa é confirmada pelo **CNPJ** mostrado em "Representação Atual" e em Dados Cadastrais. Quando a linha tem
  mais de um número (ex.: MEI "FULANA DE TAL 12345678909 · 11.222.333/0001-81", em que o CPF
  faz parte do nome), vale o CNPJ pedido; senão, o CNPJ com pontuação. Até a v1.3.0 valia o primeiro número (o CPF
  do nome), o que gerava uma falsa "divergência".
- Divergência de verdade (o portal representou outra empresa) **não para mais a execução**: nada é salvo, a página
  recarrega e o mesmo CNPJ é tentado de novo (até 3 vezes). Se persistir, o CNPJ fica PENDENTE (com o motivo no
  painel), a fila segue para o próximo e ele é tentado mais uma vez no fim da lista.

Em `chrome://settings/downloads`, deixe **desligado** "Perguntar onde salvar cada arquivo", senão o Chrome abre a
janela de salvar para o relatório.

## Lista de CNPJs

A lista é informada no **painel** (campo "CNPJs e empresas"), uma linha por empresa, na ordem desejada, no formato
`cnpj;nome_empresa`; o nome dá nome à pasta e aparece nos avisos. Exemplo:

```
11.222.333/0001-81;EMPRESA EXEMPLO LTDA
11444777000161;OUTRA EMPRESA EXEMPLO
```

- Ao concluir um CNPJ, a extensão registra a conclusão (`chrome.storage.local`) e avança **uma vez** para o próximo,
  na mesma aba: abre o perfil, usa **Trocar Representação**, espera **Representação Atual** mostrar o novo CNPJ
  (enquanto mostrar o anterior, aguarda) e repete a análise. Depois do último, encerra.
- Os itens já concluídos são pulados ao abrir/recarregar a página. Na primeira vez com esta versão, um CNPJ cujo
  relatório já está em `RFB_CNPJ/<CNPJ>/situação fiscal/` conta como concluído (não refaz nem baixa de novo).
- Cada CNPJ começa com os próprios dados; comparação, nomes de arquivo e pastas saem do CNPJ confirmado.
- Recusa da representação = CNPJ concluído com "Erro de procuração — evidência salva"; a fila continua.
- Se um CNPJ falhar de outro jeito (divergência, tempo esgotado…), a execução para nele e mostra o motivo; o
  painel mostra "Aguardando intervenção manual".
- **Ícone da extensão** = resumo e botão **Abrir painel**. Zerar o registro de concluídos é o botão
  **Zerar progresso** do painel, com dois cliques.
- Empresas DIFERENTES com o mesmo nome e o mesmo nº de filial ganham o CNPJ inteiro no nome da pasta, para os
  documentos nunca se misturarem.

Se o portal recarregar a página logo depois de **Representar**, a extensão não clica de novo: se a página já mostra a
empresa pedida, segue para as etapas 9 a 11 (proteção válida por 5 minutos).

## Instalar

1. Abra `chrome://extensions` e ligue o **Modo do desenvolvedor**.
2. Clique em **Carregar sem compactação** e escolha esta pasta `Situacao_Fiscal`.
3. Depois de editar arquivos, clique no ícone de recarregar (↻) da extensão e recarregue a página.

## Testar

- Abra Minhas Dívidas e Pendências e aperte F5. Deixe a aba **visível** durante a captura da tela (etapa 10).
- O aviso no canto inferior esquerdo mostra a etapa; verde ao fim, vermelho com a etapa e o motivo se algo falhar.
- Detalhes no console (F12), com o prefixo `[Situacao_Fiscal]`.
- Tempos e velocidades (seta e digitação, separadas): bloco **CONFIGURAÇÃO** no início de `content.js`.

## Arquivos

- `manifest.json` — Manifest V3; o content script roda só em `servicos.receitafederal.gov.br`.
  `<all_urls>` é exigido pelo Chrome para capturar a tela (`captureVisibleTab`).
- `background.js` — navegação interna do portal, início automático depois do login no e-CAC, pedidos do painel,
  captura da tela em PDF e redirecionamento do download do relatório para a pasta da empresa.
- `content.js` — reconhecimento da página, seta animada, o fluxo das 11 etapas e o status/histórico para o painel.
- `comum.js` — regras comuns (validação da lista, chaves do storage, classificação de cada CNPJ).
- `painel/` — o painel externo (`painel.html`, `painel.css`, `painel.js`), aberto pela Central de Automações.
- `popup.html` / `popup.js` — janela do ícone: resumo e botão "Abrir painel".
