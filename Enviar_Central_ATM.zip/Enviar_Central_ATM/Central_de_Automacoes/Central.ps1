﻿# Central de Automações - Panorama
# Abre cada automação pelo MESMO ponto de entrada usado ao abri-la sozinha (mesmo arquivo, mesma pasta
# de trabalho, mesmos argumentos). A central não altera nada nas automações: só as inicia.
# A lista fica em automacoes.json, a ajuda de cada automação em ajuda.json e o tema escolhido em
# preferencias.json (todos nesta pasta).
#
# Uso:  dois cliques no atalho "Central de Automações" da Área de Trabalho
#       ou:  powershell -NoProfile -ExecutionPolicy Bypass -STA -File Central.ps1
#       Conferir a lista sem abrir a janela:  ... -File Central.ps1 -Validar
#       Abrir uma automação direto (mesmo caminho do botão):  ... -File Central.ps1 -Abrir "RETIRAR AUTO-INFRAÇÃO"
#       Autoteste da janela (busca, filtros, ajuda, temas e capturas; não inicia nenhuma automação):
#                                             ... -File Central.ps1 -TesteJanela <pasta-de-saida> [-Preferencias <arquivo>] [-Escala 1.25]
param([switch]$Validar, [string]$Abrir = '', [string]$TesteJanela = '', [string]$Preferencias = '', [double]$Escala = 0)

$ErrorActionPreference = 'Stop'
$AQUI = $PSScriptRoot
$ARQ_LISTA = Join-Path $AQUI 'automacoes.json'
$ARQ_AJUDA = Join-Path $AQUI 'ajuda.json'
$ARQ_PREF = $(if ($Preferencias) { $Preferencias } else { Join-Path $AQUI 'preferencias.json' })

# A central abre sem janela de comando: qualquer erro inesperado aparece numa caixa de mensagem.
trap {
  if ($Validar -or $Abrir) { Write-Output "ERRO: $($_.Exception.Message)"; exit 1 }
  try { "$(Get-Date -Format s)  $($_.Exception.Message)`r`n$($_.InvocationInfo.PositionMessage)`r`n" | Add-Content -LiteralPath (Join-Path $AQUI 'central_erros.log') -Encoding UTF8 } catch { }
  if ($TesteJanela) { exit 1 }
  Add-Type -AssemblyName System.Windows.Forms
  [Windows.Forms.MessageBox]::Show("A Central de Automações encontrou um erro e vai fechar.`n`n$($_.Exception.Message)`n`nArquivo da lista: $ARQ_LISTA", 'Central de Automações', 'OK', 'Error') | Out-Null
  exit 1
}

# ================================================================ funcionamento (não visual)

# %CENTRAL_ATM% = pasta de instalação (a pasta que contém Central_de_Automacoes e Automacoes). Assim a lista não
# depende de caminhos absolutos: funciona em qualquer computador e em qualquer pasta onde o pacote for instalado.
$CENTRAL_ATM = Split-Path $AQUI -Parent
function Expandir([string]$texto) {
  if (-not $texto) { return '' }
  $texto = $texto -replace '%CENTRAL_ATM%', ($CENTRAL_ATM -replace '\$', '$$$$')
  return [Environment]::ExpandEnvironmentVariables($texto)
}

function Achar-Chrome {
  foreach ($base in @($env:CHROME_PATH, $env:ProgramFiles, ${env:ProgramFiles(x86)}, $env:LOCALAPPDATA)) {
    if (-not $base) { continue }
    $exe = if ($base -like '*.exe') { $base } else { Join-Path $base 'Google\Chrome\Application\chrome.exe' }
    if (Test-Path -LiteralPath $exe) { return $exe }
  }
  return $null
}

# Pastas das extensões carregadas "sem compactação" no Chrome (todos os perfis). As desligadas vêm com o
# prefixo "desligada|".
function Extensoes-Carregadas {
  $pastas = @()
  $base = Join-Path $env:LOCALAPPDATA 'Google\Chrome\User Data'
  if (-not (Test-Path -LiteralPath $base)) { return $pastas }
  foreach ($perfil in Get-ChildItem -LiteralPath $base -Directory -ErrorAction SilentlyContinue) {
    foreach ($arq in 'Secure Preferences', 'Preferences') {
      $caminho = Join-Path $perfil.FullName $arq
      if (-not (Test-Path -LiteralPath $caminho)) { continue }
      try {
        $json = Get-Content -LiteralPath $caminho -Raw -Encoding UTF8 | ConvertFrom-Json
        $json.extensions.settings.PSObject.Properties | ForEach-Object {
          if ($_.Value.path -and $_.Value.path -match ':\\') {
            $pasta = $_.Value.path.TrimEnd('\').ToLowerInvariant()
            if (@($_.Value.disable_reasons).Where({ $_ -and $_ -ne 0 }).Count) { $pastas += "desligada|$pasta" } else { $pastas += $pasta }
          }
        }
      } catch { }
    }
  }
  return $pastas | Sort-Object -Unique
}

# Id da extensão carregada a partir de $pasta (ligada), lido das preferências do Chrome; $null se não achar.
function Id-Extensao([string]$pasta) {
  if (-not $pasta) { return $null }
  $alvo = $pasta.TrimEnd('\').ToLowerInvariant()
  $base = Join-Path $env:LOCALAPPDATA 'Google\Chrome\User Data'
  if (-not (Test-Path -LiteralPath $base)) { return $null }
  foreach ($perfil in Get-ChildItem -LiteralPath $base -Directory -ErrorAction SilentlyContinue) {
    foreach ($arq in 'Secure Preferences', 'Preferences') {
      $caminho = Join-Path $perfil.FullName $arq
      if (-not (Test-Path -LiteralPath $caminho)) { continue }
      try {
        $json = Get-Content -LiteralPath $caminho -Raw -Encoding UTF8 | ConvertFrom-Json
        foreach ($p in $json.extensions.settings.PSObject.Properties) {
          if ($p.Value.path -and $p.Value.path.TrimEnd('\').ToLowerInvariant() -eq $alvo -and
              -not @($p.Value.disable_reasons).Where({ $_ -and $_ -ne 0 }).Count) { return $p.Name }
        }
      } catch { }
    }
  }
  return $null
}

# Texto para busca: sem acentos, minúsculo, e tudo que não é letra/número vira espaço
# ("AUTO-INFRAÇÃO" -> "auto infracao").
function Normalizar([string]$s) {
  if (-not $s) { return '' }
  $n = $s.Normalize([Text.NormalizationForm]::FormD)
  $sem = -join ($n.ToCharArray() | Where-Object { [Globalization.CharUnicodeInfo]::GetUnicodeCategory($_) -ne 'NonSpacingMark' })
  return (($sem.ToLowerInvariant() -replace '[^a-z0-9]+', ' ').Trim())
}

# Ajuda de cada automação (ajuda.json). Só as automações com ajuda mostram o botão "?".
function Ler-Ajudas {
  $mapa = @{}
  if (-not (Test-Path -LiteralPath $ARQ_AJUDA)) { return $mapa }
  $json = Get-Content -LiteralPath $ARQ_AJUDA -Raw -Encoding UTF8 | ConvertFrom-Json
  foreach ($prop in $json.ajuda.PSObject.Properties) { $mapa[(Normalizar $prop.Name)] = $prop.Value }
  return $mapa
}

function Ler-Automacoes {
  $ajudas = Ler-Ajudas
  $json = Get-Content -LiteralPath $ARQ_LISTA -Raw -Encoding UTF8 | ConvertFrom-Json
  $lista = foreach ($a in $json.automacoes) {
    $busca = Normalizar "$($a.nome) $($a.descricao) $($a.categoria)"
    [pscustomobject]@{
      Nome       = $a.nome
      Categoria  = $(if ($a.categoria) { $a.categoria } else { 'Outras' })
      Icone      = $(if ($a.icone) { [string][char][Convert]::ToInt32($a.icone, 16) } else { [string][char]0xE8A5 })
      Descricao  = $a.descricao
      Tipo       = $a.tipo
      Arquivo    = Expandir $a.arquivo
      Pasta      = Expandir $a.pasta
      Argumentos = $a.argumentos
      Url        = $a.url
      Anonima    = [bool]$a.anonima
      Painel     = $a.painel
      Extensao   = Expandir $a.extensao
      Dica       = $a.dica
      Ajuda      = $ajudas[(Normalizar $a.nome)]
      Busca      = $busca
      BuscaJunta = $busca -replace ' ', ''
    }
  }
  return [object[]]($lista | Sort-Object -Property @{ Expression = { $_.Nome }; Ascending = $true } -Culture 'pt-BR')
}

# Todas as palavras digitadas precisam aparecer (pedaços de palavra valem): "auto infracao", "infra", "autoinfracao".
function Combina($a, [string]$termo) {
  $t = Normalizar $termo
  if (-not $t) { return $true }
  foreach ($palavra in $t.Split(' ')) {
    if (-not ($a.Busca.Contains($palavra) -or $a.BuscaJunta.Contains($palavra))) { return $false }
  }
  return $true
}

# Confere se a automação pode ser iniciada. Devolve @{ Ok; Motivo; Aviso }.
function Conferir($a, $extensoes, $chrome) {
  if (-not (Test-Path -LiteralPath $a.Pasta)) { return @{ Ok = $false; Motivo = "a pasta do projeto não existe: $($a.Pasta)"; Aviso = '' } }
  if ($a.Tipo -eq 'chrome') {
    if (-not $chrome) { return @{ Ok = $false; Motivo = 'Google Chrome não encontrado neste computador'; Aviso = '' } }
  } else {
    if (-not (Test-Path -LiteralPath $a.Arquivo)) { return @{ Ok = $false; Motivo = "o arquivo de início não existe: $($a.Arquivo)"; Aviso = '' } }
    if ($a.Arquivo -like '*.cmd' -and -not (Get-Command node -ErrorAction SilentlyContinue)) {
      return @{ Ok = $false; Motivo = 'Node.js não encontrado (instale com: winget install OpenJS.NodeJS.LTS)'; Aviso = '' }
    }
  }
  $aviso = ''
  if ($a.Extensao) {
    if (-not (Test-Path -LiteralPath $a.Extensao)) { $aviso = "pasta da extensão não encontrada: $($a.Extensao)" }
    else {
      $chave = $a.Extensao.TrimEnd('\').ToLowerInvariant()
      if ($extensoes -contains $chave) { }
      elseif ($extensoes -contains "desligada|$chave") { $aviso = 'extensão DESLIGADA no Chrome: ligue o botão dela em chrome://extensions' }
      else { $aviso = "extensão não carregada no Chrome (chrome://extensions > Carregar sem compactação > $($a.Extensao))" }
    }
  }
  return @{ Ok = $true; Motivo = ''; Aviso = $aviso }
}

# Inicia a automação sem prender a central (Start-Process não espera o programa terminar).
$script:iniciadas = 0
function Iniciar($a, $chrome) {
  $script:iniciadas++
  switch ($a.Tipo) {
    'chrome' {
      # "anonima": true no automacoes.json abre o site numa janela anônima (permite escolher outro certificado).
      $url = $a.Url
      # "painel": página da própria extensão (ex.: painel/painel.html). Abre essa página se a extensão estiver
      # carregada e ligada; senão abre o "url" (o site) e o usuário clica no ícone da extensão.
      if ($a.Painel) { $id = Id-Extensao $a.Extensao; if ($id) { $url = "chrome-extension://$id/$($a.Painel)" } }
      $argumentos = if ($a.Anonima) { "--incognito `"$url`"" } else { $url }
      return Start-Process -FilePath $chrome -ArgumentList $argumentos -WorkingDirectory $a.Pasta -PassThru
    }
    'terminal' {
      # Mesmo efeito do duplo clique no .cmd: janela de comando visível, na pasta do projeto.
      $argumentos = '/c ""' + $a.Arquivo + '"' + $(if ($a.Argumentos) { ' ' + $a.Argumentos } else { '' }) + '"'
      return Start-Process -FilePath "$env:ComSpec" -ArgumentList $argumentos -WorkingDirectory $a.Pasta -WindowStyle Normal -PassThru
    }
    default {
      if ($a.Argumentos) { return Start-Process -FilePath $a.Arquivo -ArgumentList $a.Argumentos -WorkingDirectory $a.Pasta -PassThru }
      return Start-Process -FilePath $a.Arquivo -WorkingDirectory $a.Pasta -PassThru
    }
  }
}

$automacoes = Ler-Automacoes
$chrome = Achar-Chrome
$extensoes = Extensoes-Carregadas

# ================================================================ modos sem janela

if ($Validar) {
  [Console]::OutputEncoding = [Text.Encoding]::UTF8
  Write-Output "Central de Automações - $($automacoes.Count) automação(ões), em ordem alfabética:"
  foreach ($a in $automacoes) {
    $conf = Conferir $a $extensoes $chrome
    $alvo = if ($a.Tipo -eq 'chrome') { "Chrome$(if ($a.Anonima) { ' (janela anônima)' }) -> $($a.Url)" } else { $a.Arquivo }
    Write-Output ''
    Write-Output "[$($a.Tipo)] $($a.Nome)   ($($a.Categoria))"
    Write-Output "    inicia : $alvo"
    Write-Output "    pasta  : $($a.Pasta)"
    Write-Output ("    ajuda  : " + $(if ($a.Ajuda) { "sim (fonte: $(Expandir $a.Ajuda.fonte))" } else { 'não' }))
    Write-Output ("    pronto : " + $(if ($conf.Ok) { 'sim' } else { "NÃO - $($conf.Motivo)" }))
    if ($conf.Aviso) { Write-Output "    aviso  : $($conf.Aviso)" }
  }
  exit 0
}

if ($Abrir) {
  [Console]::OutputEncoding = [Text.Encoding]::UTF8
  $a = $automacoes | Where-Object { (Normalizar $_.Nome) -eq (Normalizar $Abrir) } | Select-Object -First 1
  if (-not $a) { Write-Output "Automação não encontrada: $Abrir"; exit 1 }
  $conf = Conferir $a $extensoes $chrome
  if (-not $conf.Ok) { Write-Output "Não iniciou $($a.Nome): $($conf.Motivo)"; exit 1 }
  $proc = Iniciar $a $chrome
  Write-Output "Iniciada: $($a.Nome) (processo $($proc.Id))"
  exit 0
}


# ================================================================ janela

# ---------------------------------------------------------------- nitidez: DPI e renderização de texto
# O powershell.exe não declara suporte a DPI. Sem isto, com a escala do Windows em 125% ou 150%, o Windows estica
# a janela inteira como uma imagem e o texto fica borrado. Aqui a central passa a ser "DPI-aware": o Windows
# entrega os pixels reais e a central desenha tudo (texto, ícones, medidas) já no tamanho certo para a escala.
Add-Type -Namespace CentralDpi -Name Api -MemberDefinition @'
[DllImport("shcore.dll")] public static extern int SetProcessDpiAwareness(int valor);
[DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
[DllImport("user32.dll")] public static extern int GetDpiForSystem();
[DllImport("user32.dll")] public static extern System.IntPtr GetThreadDpiAwarenessContext();
[DllImport("user32.dll")] public static extern int GetAwarenessFromDpiAwarenessContext(System.IntPtr contexto);
'@
try { [CentralDpi.Api]::SetProcessDpiAwareness(1) | Out-Null } catch { try { [CentralDpi.Api]::SetProcessDPIAware() | Out-Null } catch { } }
$script:dpiConsciente = try { [CentralDpi.Api]::GetAwarenessFromDpiAwarenessContext([CentralDpi.Api]::GetThreadDpiAwarenessContext()) } catch { -1 }
$dpiSistema = try { [CentralDpi.Api]::GetDpiForSystem() } catch { 96 }

Add-Type -AssemblyName System.Windows.Forms, System.Drawing
[Windows.Forms.Application]::EnableVisualStyles()
# Texto dos controles pelo GDI (ClearType), e não pelo GDI+ (suavização em cinza, mais borrada).
try { [Windows.Forms.Application]::SetCompatibleTextRenderingDefault($false) } catch { }

# Escala: 1 em 100%, 1,25 em 125%, 1,5 em 150%. -Escala simula outra escala (testes): medidas e fontes crescem juntas.
$script:FATOR = $(if ($Escala -gt 0) { $Escala } else { $dpiSistema / 96.0 })
$FF = $(if ($Escala -gt 0) { $Escala } else { 1.0 })   # as fontes em pontos já crescem sozinhas com o DPI real
function S([double]$px) { return [int][Math]::Round($px * $script:FATOR) }
function Fonte([string]$familia, [double]$pt, [string]$estilo = 'Regular') { return New-Object Drawing.Font($familia, [float]($pt * $FF), [Drawing.FontStyle]$estilo) }

function Cor([string]$hex) { return [Drawing.ColorTranslator]::FromHtml($hex) }

# ---------------------------------------------------------------- tipografia (Segoe UI, a fonte do Windows)
# Hierarquia: título 20 · nome da automação 12,5 · seções 11 · texto 10 · secundário 9,5 · rótulos 9. Nada abaixo de 9 pt.
$F = @{
  Titulo    = Fonte 'Segoe UI Semibold' 20
  Subtitulo = Fonte 'Segoe UI' 10
  Busca     = Fonte 'Segoe UI' 12
  Botao     = Fonte 'Segoe UI Semibold' 10
  Chip      = Fonte 'Segoe UI Semibold' 9.5
  Rotulo    = Fonte 'Segoe UI Semibold' 9
  Nome      = Fonte 'Segoe UI Semibold' 12.5
  Desc      = Fonte 'Segoe UI' 10
  Status    = Fonte 'Segoe UI Semibold' 9.5
  Rodape    = Fonte 'Segoe UI' 9.5
  Secao     = Fonte 'Segoe UI Semibold' 11
  Texto     = Fonte 'Segoe UI' 10
  TituloAj  = Fonte 'Segoe UI Semibold' 14
  Pequena   = Fonte 'Segoe UI' 9
  Icone     = Fonte 'Segoe MDL2 Assets' 16
  IconeBot  = Fonte 'Segoe MDL2 Assets' 11
  Interrog  = Fonte 'Segoe UI Semibold' 11
}
$TF = [Windows.Forms.TextFormatFlags]
$CENTRO = $TF::HorizontalCenter -bor $TF::VerticalCenter -bor $TF::NoPadding -bor $TF::SingleLine
$ESQUERDA = $TF::Left -bor $TF::VerticalCenter -bor $TF::NoPadding -bor $TF::SingleLine -bor $TF::EndEllipsis

# ---------------------------------------------------------------- temas
# Claro: a mesma família de azuis das interfaces ATM RFB e Retirar_Auto_Infracao. Escuro: mesmas cores, com fundos
# escuros e textos claros. Os tons "Suave" foram escurecidos (claro) e clareados (escuro) para leitura confortável.
$TEMAS = @{
  Claro  = @{
    Fundo = '#F3F5F9'; Cartao = '#FFFFFF'; Borda = '#DEE3EB'; Texto = '#16202E'; Suave = '#4A5668'
    Cabecalho = '#13213C'; CabecalhoTexto = '#B9C7E0'; CabecalhoBotao = '#22355A'; CabecalhoBorda = '#3A5180'
    Campo = '#FFFFFF'; CampoTexto = '#16202E'; CampoAjuda = '#6B778A'; Azul = '#2459E6'; AzulEscuro = '#1A45B8'; Destaque = '#1F51D6'; DestaqueFundo = '#E8EEFF'
    Foco = '#F5B700'; Ok = '#0F7A42'; OkFundo = '#E3F5EA'; Aviso = '#8F5300'; AvisoFundo = '#FFF1D6'; Erro = '#B42318'; ErroFundo = '#FDE8E7'
    Neutro = '#4A5668'; NeutroFundo = '#EEF1F6'; Rodape = '#E8ECF3'; Painel = '#FFFFFF'; Secao = '#1A45B8'; Divisor = '#E6EAF0'
  }
  Escuro = @{
    Fundo = '#0E131D'; Cartao = '#171E2C'; Borda = '#2A3550'; Texto = '#EDF1F8'; Suave = '#AAB5CA'
    Cabecalho = '#080D19'; CabecalhoTexto = '#AAB5CA'; CabecalhoBotao = '#18213A'; CabecalhoBorda = '#33426A'
    Campo = '#1C2435'; CampoTexto = '#EDF1F8'; CampoAjuda = '#97A3B9'; Azul = '#3466F0'; AzulEscuro = '#2852CC'; Destaque = '#9DBBFF'; DestaqueFundo = '#1F2D55'
    Foco = '#F5B700'; Ok = '#5BE39C'; OkFundo = '#13311F'; Aviso = '#F5C26B'; AvisoFundo = '#3A2C12'; Erro = '#FF9A94'; ErroFundo = '#40201F'
    Neutro = '#AAB5CA'; NeutroFundo = '#222B3D'; Rodape = '#121826'; Painel = '#131A28'; Secao = '#9DBBFF'; Divisor = '#252F45'
  }
}

function Ler-Tema {
  try {
    if (Test-Path -LiteralPath $ARQ_PREF) {
      $pref = Get-Content -LiteralPath $ARQ_PREF -Raw -Encoding UTF8 | ConvertFrom-Json
      if ($TEMAS.ContainsKey([string]$pref.tema)) { return [string]$pref.tema }
    }
  } catch { }
  # Primeira abertura: segue o Windows (Configurações > Personalização > Cores > modo de aplicativo).
  try {
    $claro = (Get-ItemProperty 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize' -ErrorAction Stop).AppsUseLightTheme
    if ($claro -eq 0) { return 'Escuro' }
  } catch { }
  return 'Claro'
}

function Salvar-Tema([string]$tema) {
  try { (@{ tema = $tema } | ConvertTo-Json) | Set-Content -LiteralPath $ARQ_PREF -Encoding UTF8 } catch { }
}

$script:tema = Ler-Tema
$script:PAL = @{}
function Carregar-Paleta([string]$tema) {
  $nova = @{}
  foreach ($kv in $TEMAS[$tema].GetEnumerator()) { $nova[$kv.Key] = Cor $kv.Value }
  $script:PAL = $nova
}
Carregar-Paleta $script:tema

$G = @{
  Busca = [string][char]0xE721; Atualizar = [string][char]0xE72C; Abrir = [string][char]0xE8A7; Ok = [string][char]0xE73E
  Sol = [string][char]0xE706; Lua = [string][char]0xE708; Fechar = [string][char]0xE711
}

function Buffer-Duplo($controle) {
  $controle.GetType().GetProperty('DoubleBuffered', [Reflection.BindingFlags]'Instance,NonPublic').SetValue($controle, $true, $null)
}

function Caminho-Arredondado([Drawing.RectangleF]$r, [float]$raio) {
  $gp = New-Object Drawing.Drawing2D.GraphicsPath
  $d = [Math]::Min($raio * 2, [Math]::Min($r.Width, $r.Height))
  $gp.AddArc($r.X, $r.Y, $d, $d, 180, 90)
  $gp.AddArc($r.Right - $d, $r.Y, $d, $d, 270, 90)
  $gp.AddArc($r.Right - $d, $r.Bottom - $d, $d, $d, 0, 90)
  $gp.AddArc($r.X, $r.Bottom - $d, $d, $d, 90, 90)
  $gp.CloseFigure()
  return $gp
}

function Mouse-Sobre($controle) { return $controle.ClientRectangle.Contains($controle.PointToClient([Windows.Forms.Control]::MousePosition)) }

# Botão desenhado pela central: fundo arredondado e ícone + texto pelo GDI (ClearType), centralizados.
function Pintar-Botao($ctl, $e, $fundo, $corTexto, $corBorda, [float]$larguraBorda, [string]$glifo, [string]$texto, $fonte, $fundoPai) {
  $gr = $e.Graphics
  $gr.Clear($fundoPai)
  $gr.SmoothingMode = 'AntiAlias'
  $meia = [float]([Math]::Max(1, $larguraBorda) / 2)
  $r = New-Object Drawing.RectangleF $meia, $meia, ($ctl.Width - 2 * $meia - 1), ($ctl.Height - 2 * $meia - 1)
  $caminho = Caminho-Arredondado $r ([float](S 8))
  $gr.FillPath((New-Object Drawing.SolidBrush $fundo), $caminho)
  if ($larguraBorda -gt 0) { $gr.DrawPath((New-Object Drawing.Pen($corBorda, $larguraBorda)), $caminho) }
  $gr.SmoothingMode = 'None'
  $tamTexto = [Windows.Forms.TextRenderer]::MeasureText($gr, $texto, $fonte, (New-Object Drawing.Size 4000, 100), $CENTRO)
  $larguraGlifo = 0; $espaco = 0
  if ($glifo) { $larguraGlifo = [Windows.Forms.TextRenderer]::MeasureText($gr, $glifo, $F.IconeBot, (New-Object Drawing.Size 400, 100), $CENTRO).Width; if ($texto) { $espaco = S 8 } }
  $total = $larguraGlifo + $espaco + $tamTexto.Width
  $x = [int](($ctl.Width - $total) / 2)
  if ($glifo) {
    [Windows.Forms.TextRenderer]::DrawText($gr, $glifo, $F.IconeBot, (New-Object Drawing.Rectangle $x, 0, $larguraGlifo, ($ctl.Height + 1)), $corTexto, $fundo, $CENTRO)
  }
  if ($texto) { [Windows.Forms.TextRenderer]::DrawText($gr, $texto, $fonte, (New-Object Drawing.Rectangle ($x + $larguraGlifo + $espaco), 0, ($tamTexto.Width + 2), $ctl.Height), $corTexto, $fundo, $CENTRO) }
}

# Monograma da Panorama (não há logotipo no projeto): quadrado azul arredondado com "P", desenhado no tamanho da escala.
function Logo-Imagem([int]$t) {
  $bmp = New-Object Drawing.Bitmap($t, $t)
  $gr = [Drawing.Graphics]::FromImage($bmp)
  $gr.SmoothingMode = 'AntiAlias'; $gr.TextRenderingHint = 'AntiAlias'
  $caminho = Caminho-Arredondado (New-Object Drawing.RectangleF 0, 0, ($t - 1), ($t - 1)) ([float]($t * 0.24))
  $pincel = New-Object Drawing.Drawing2D.LinearGradientBrush((New-Object Drawing.Point 0, 0), (New-Object Drawing.Point $t, $t), (Cor '#3B74FF'), (Cor '#1A45B8'))
  $gr.FillPath($pincel, $caminho)
  $f = New-Object Drawing.Font('Segoe UI', [float]($t * 0.56), [Drawing.FontStyle]::Bold, [Drawing.GraphicsUnit]::Pixel)
  $sf = New-Object Drawing.StringFormat; $sf.Alignment = 'Center'; $sf.LineAlignment = 'Center'
  $gr.DrawString('P', $f, [Drawing.Brushes]::White, (New-Object Drawing.RectangleF 0, ([float]($t * 0.03)), $t, $t), $sf)
  $gr.Dispose()
  return $bmp
}

$form = New-Object Windows.Forms.Form
$form.Text = 'Central de Automações'
$form.AutoScaleMode = 'None'   # as medidas já são calculadas para a escala (função S)
$area = [Windows.Forms.Screen]::PrimaryScreen.WorkingArea
$form.Size = New-Object Drawing.Size([Math]::Min((S 1180), [int]($area.Width * 0.96)), [Math]::Min((S 780), [int]($area.Height * 0.96)))
$form.MinimumSize = New-Object Drawing.Size([Math]::Min((S 660), $area.Width), [Math]::Min((S 560), $area.Height))
$form.StartPosition = 'CenterScreen'
$form.Font = $F.Texto
$form.KeyPreview = $true
$logo = Logo-Imagem 64
$form.Icon = [Drawing.Icon]::FromHandle($logo.GetHicon())
Buffer-Duplo $form

# Dica flutuante (resumo da ajuda e explicações), desenhada com as cores do tema e sem esmaecer.
$dica = New-Object Windows.Forms.ToolTip
$dica.OwnerDraw = $true; $dica.InitialDelay = 350; $dica.AutoPopDelay = 20000; $dica.UseFading = $false; $dica.UseAnimation = $false
$dica.Add_Popup({
  param($s, $e)
  $txt = $dica.GetToolTip($e.AssociatedControl)
  $sz = [Windows.Forms.TextRenderer]::MeasureText($txt, $F.Texto, (New-Object Drawing.Size (S 380), 0), [Windows.Forms.TextFormatFlags]::WordBreak)
  $e.ToolTipSize = New-Object Drawing.Size(($sz.Width + (S 24)), ($sz.Height + (S 20)))
})
$dica.Add_Draw({
  param($s, $e)
  $e.Graphics.FillRectangle((New-Object Drawing.SolidBrush $script:PAL.Painel), $e.Bounds)
  $e.Graphics.DrawRectangle((New-Object Drawing.Pen $script:PAL.Borda), 0, 0, ($e.Bounds.Width - 1), ($e.Bounds.Height - 1))
  $area2 = New-Object Drawing.Rectangle (S 12), (S 10), ($e.Bounds.Width - (S 22)), ($e.Bounds.Height - (S 18))
  [Windows.Forms.TextRenderer]::DrawText($e.Graphics, $e.ToolTipText, $F.Texto, $area2, $script:PAL.Texto, $script:PAL.Painel, [Windows.Forms.TextFormatFlags]::WordBreak)
})

# ---------------------------------------------------------------- cabeçalho: título, tema, busca e Atualizar
$topo = New-Object Windows.Forms.Panel
$topo.Dock = 'Top'; $topo.Height = S 156; $topo.TabIndex = 0

$caixaLogo = New-Object Windows.Forms.PictureBox
$caixaLogo.Image = Logo-Imagem (S 46); $caixaLogo.Size = New-Object Drawing.Size((S 46), (S 46)); $caixaLogo.Location = New-Object Drawing.Point((S 28), (S 24))

$titulo = New-Object Windows.Forms.Label
$titulo.Text = 'Central de Automações'; $titulo.ForeColor = 'White'; $titulo.Font = $F.Titulo
$titulo.AutoSize = $true; $titulo.Location = New-Object Drawing.Point((S 86), (S 17))

$subtitulo = New-Object Windows.Forms.Label
$subtitulo.Text = 'Panorama  ·  encontre a automação pelo nome e abra com um clique'
$subtitulo.Font = $F.Subtitulo; $subtitulo.AutoSize = $true; $subtitulo.Location = New-Object Drawing.Point((S 89), (S 54))

# Campo de busca: caixa arredondada com lupa e texto de ajuda que segue o tema.
$caixaBusca = New-Object Windows.Forms.Panel
$caixaBusca.Location = New-Object Drawing.Point((S 28), (S 94)); $caixaBusca.Height = S 46; $caixaBusca.TabIndex = 0
Buffer-Duplo $caixaBusca
$lupa = New-Object Windows.Forms.Label
$lupa.Text = $G.Busca; $lupa.Font = $F.IconeBot; $lupa.TextAlign = 'MiddleCenter'
$lupa.Location = New-Object Drawing.Point((S 12), (S 11)); $lupa.Size = New-Object Drawing.Size((S 24), (S 24))
$busca = New-Object Windows.Forms.TextBox
$busca.BorderStyle = 'None'; $busca.Font = $F.Busca
$busca.TabIndex = 0; $busca.AccessibleName = 'Buscar automação pelo nome'
$ajudaBusca = New-Object Windows.Forms.Label
$ajudaBusca.Text = 'Buscar automação pelo nome (ex.: auto infração)'; $ajudaBusca.Font = $F.Busca
$ajudaBusca.AutoSize = $true; $ajudaBusca.Cursor = 'IBeam'
$ajudaBusca.Add_Click({ $busca.Focus() })
$caixaBusca.Controls.AddRange(@($busca, $lupa, $ajudaBusca))
$ajudaBusca.BringToFront()
$caixaBusca.Add_Paint({
  param($s, $e)
  $e.Graphics.SmoothingMode = 'AntiAlias'
  $r = New-Object Drawing.RectangleF 1, 1, ($s.Width - 3), ($s.Height - 3)
  $gp = Caminho-Arredondado $r ([float](S 10))
  $e.Graphics.FillPath((New-Object Drawing.SolidBrush $script:PAL.Campo), $gp)
  if ($busca.Focused) { $e.Graphics.DrawPath((New-Object Drawing.Pen($script:PAL.Foco, [float](S 2.5))), $gp) }
})
$busca.Add_GotFocus({ $caixaBusca.Invalidate() })
$busca.Add_LostFocus({ $caixaBusca.Invalidate() })

# Botões do cabeçalho (Atualizar, Claro, Escuro): desenhados pela central, com estado de foco e de mouse.
function Novo-Botao([string]$texto, [string]$glifo) {
  $b = New-Object Windows.Forms.Button
  $b.Text = $texto; $b.FlatStyle = 'Flat'; $b.FlatAppearance.BorderSize = 0; $b.Cursor = 'Hand'; $b.Font = $F.Botao
  $b.UseVisualStyleBackColor = $false
  Buffer-Duplo $b
  $b.Add_MouseEnter({ param($s) $s.Invalidate() })
  $b.Add_MouseLeave({ param($s) $s.Invalidate() })
  $b.Add_GotFocus({ param($s) $s.Invalidate() })
  $b.Add_LostFocus({ param($s) $s.Invalidate() })
  $b.Tag = @{ Glifo = $glifo; Texto = $texto }
  return $b
}
$atualizar = Novo-Botao 'Atualizar' $G.Atualizar
$atualizar.Size = New-Object Drawing.Size((S 128), (S 46)); $atualizar.TabIndex = 1
$atualizar.Tag.Tipo = 'cabecalho'
$dica.SetToolTip($atualizar, 'Confere de novo as pastas e as extensões do Chrome (F5).')

$rotuloTema = New-Object Windows.Forms.Label
$rotuloTema.Text = 'Tema'; $rotuloTema.AutoSize = $true; $rotuloTema.Font = $F.Rotulo
$temaClaro = Novo-Botao 'Claro' $G.Sol
$temaEscuro = Novo-Botao 'Escuro' $G.Lua
$temaClaro.Tag.Tema = 'Claro'; $temaEscuro.Tag.Tema = 'Escuro'
$temaClaro.Tag.Tipo = 'tema'; $temaEscuro.Tag.Tipo = 'tema'
$temaClaro.Size = New-Object Drawing.Size((S 92), (S 34)); $temaEscuro.Size = New-Object Drawing.Size((S 100), (S 34))
$temaClaro.TabIndex = 2; $temaEscuro.TabIndex = 3
$temaClaro.AccessibleName = 'Tema claro'; $temaEscuro.AccessibleName = 'Tema escuro'
$dica.SetToolTip($temaClaro, 'Usar o tema claro (fica salvo para as próximas vezes).')
$dica.SetToolTip($temaEscuro, 'Usar o tema escuro (fica salvo para as próximas vezes).')

foreach ($b in @($atualizar, $temaClaro, $temaEscuro)) {
  $b.Add_Paint({
    param($s, $e)
    $ativo = ($s.Tag.Tipo -eq 'tema' -and $s.Tag.Tema -eq $script:tema)
    $sobre = Mouse-Sobre $s
    $fundo = if ($ativo) { $(if ($sobre) { $script:PAL.AzulEscuro } else { $script:PAL.Azul }) } elseif ($sobre) { $script:PAL.CabecalhoBorda } else { $script:PAL.CabecalhoBotao }
    $borda = if ($s.Focused) { $script:PAL.Foco } elseif ($ativo) { $script:PAL.Azul } else { $script:PAL.CabecalhoBorda }
    Pintar-Botao $s $e $fundo ([Drawing.Color]::White) $borda $(if ($s.Focused) { [float](S 2.5) } else { [float]1 }) $s.Tag.Glifo $s.Tag.Texto $F.Botao $script:PAL.Cabecalho
  })
}

$topo.Controls.AddRange(@($caixaLogo, $titulo, $subtitulo, $caixaBusca, $atualizar, $rotuloTema, $temaClaro, $temaEscuro))

# ---------------------------------------------------------------- filtros por categoria (pílulas do mesmo tamanho de altura)
$barraFiltros = New-Object Windows.Forms.FlowLayoutPanel
$barraFiltros.Dock = 'Top'; $barraFiltros.Height = S 64; $barraFiltros.TabIndex = 1
$barraFiltros.Padding = New-Object Windows.Forms.Padding((S 26), (S 16), (S 26), (S 6)); $barraFiltros.WrapContents = $true
# Se a janela ficar estreita (ou com a ajuda aberta), os filtros passam para a linha de baixo em vez de sumir.
$barraFiltros.AutoSize = $true; $barraFiltros.AutoSizeMode = 'GrowAndShrink'
Buffer-Duplo $barraFiltros

$script:categoriaAtual = ''
$chips = @()
$categorias = @('') + @($automacoes | ForEach-Object { $_.Categoria } | Sort-Object -Unique -Culture 'pt-BR')

foreach ($cat in $categorias) {
  $qtd = @($automacoes | Where-Object { -not $cat -or $_.Categoria -eq $cat }).Count
  $texto = "$(if ($cat) { $cat } else { 'Todas' })   $qtd"
  $b = Novo-Botao $texto ''
  $b.Tag.Categoria = $cat; $b.Tag.Tipo = 'chip'; $b.Font = $F.Chip
  $largura = [Windows.Forms.TextRenderer]::MeasureText($texto, $F.Chip).Width + (S 30)
  $b.Size = New-Object Drawing.Size($largura, (S 34)); $b.Margin = New-Object Windows.Forms.Padding(0, 0, (S 8), (S 8))
  $b.AccessibleName = "Filtro: $(if ($cat) { $cat } else { 'Todas' }) ($qtd)"
  $b.Add_Click({ param($s) $script:categoriaAtual = $s.Tag.Categoria; foreach ($x in $chips) { $x.Invalidate() }; Aplicar-Filtro })
  $b.Add_Paint({
    param($s, $e)
    $ativo = ($s.Tag.Categoria -eq $script:categoriaAtual)
    $sobre = Mouse-Sobre $s
    $fundo = if ($ativo) { $(if ($sobre) { $script:PAL.AzulEscuro } else { $script:PAL.Azul }) } elseif ($sobre) { $script:PAL.DestaqueFundo } else { $script:PAL.Cartao }
    $corTexto = if ($ativo) { [Drawing.Color]::White } else { $script:PAL.Texto }
    $borda = if ($s.Focused) { $script:PAL.Foco } elseif ($ativo) { $script:PAL.Azul } else { $script:PAL.Borda }
    Pintar-Botao $s $e $fundo $corTexto $borda $(if ($s.Focused) { [float](S 2.5) } else { [float]1 }) '' $s.Tag.Texto $F.Chip $script:PAL.Fundo
  })
  $chips += $b
  $barraFiltros.Controls.Add($b)
}

# ---------------------------------------------------------------- grade de cartões
$grade = New-Object Windows.Forms.FlowLayoutPanel
$grade.Dock = 'Fill'; $grade.AutoScroll = $true; $grade.WrapContents = $true; $grade.TabIndex = 2
$grade.Padding = New-Object Windows.Forms.Padding((S 26), (S 4), (S 12), (S 20))
Buffer-Duplo $grade

$vazio = New-Object Windows.Forms.Label
$vazio.AutoSize = $true; $vazio.Font = $F.Texto
$vazio.Margin = New-Object Windows.Forms.Padding((S 4), (S 30), 0, 0); $vazio.Visible = $false

$rodape = New-Object Windows.Forms.Label
$rodape.Dock = 'Bottom'; $rodape.Height = S 36; $rodape.Font = $F.Rodape; $rodape.TextAlign = 'MiddleLeft'
$rodape.Padding = New-Object Windows.Forms.Padding((S 28), 0, (S 12), 0)

# ---------------------------------------------------------------- painel de ajuda (lateral, fica aberto até fechar)
$painelAjuda = New-Object Windows.Forms.Panel
$painelAjuda.Dock = 'Right'; $painelAjuda.Width = S 450; $painelAjuda.Visible = $false; $painelAjuda.TabIndex = 3
$painelAjuda.Padding = New-Object Windows.Forms.Padding(1, 0, 0, 0)
Buffer-Duplo $painelAjuda
$painelAjuda.Add_Paint({ param($s, $e) $e.Graphics.DrawLine((New-Object Drawing.Pen($script:PAL.Borda, 1)), 0, 0, 0, $s.Height) })

$ajudaTopo = New-Object Windows.Forms.Panel
$ajudaTopo.Dock = 'Top'; $ajudaTopo.Height = S 96
$ajudaTopo.Add_Paint({ param($s, $e) $e.Graphics.DrawLine((New-Object Drawing.Pen($script:PAL.Divisor, 1)), (S 24), ($s.Height - 1), ($s.Width - (S 24)), ($s.Height - 1)) })
$ajudaRotulo = New-Object Windows.Forms.Label
$ajudaRotulo.Text = 'AJUDA'; $ajudaRotulo.Font = $F.Rotulo; $ajudaRotulo.AutoSize = $true
$ajudaRotulo.Location = New-Object Drawing.Point((S 24), (S 20))
$ajudaTitulo = New-Object Windows.Forms.Label
$ajudaTitulo.Font = $F.TituloAj; $ajudaTitulo.AutoSize = $true
$ajudaTitulo.Location = New-Object Drawing.Point((S 22), (S 40)); $ajudaTitulo.MaximumSize = New-Object Drawing.Size((S 340), 0)
$ajudaFechar = Novo-Botao '' $G.Fechar
$ajudaFechar.Size = New-Object Drawing.Size((S 36), (S 36)); $ajudaFechar.Anchor = 'Top, Right'
$ajudaFechar.AccessibleName = 'Fechar a ajuda'; $ajudaFechar.TabIndex = 1; $ajudaFechar.Tag.Tipo = 'fechar'
$dica.SetToolTip($ajudaFechar, 'Fechar a ajuda (Esc)')
$ajudaFechar.Add_Paint({
  param($s, $e)
  $sobre = Mouse-Sobre $s
  Pintar-Botao $s $e $(if ($sobre) { $script:PAL.DestaqueFundo } else { $script:PAL.Painel }) $script:PAL.Texto $(if ($s.Focused) { $script:PAL.Foco } else { $script:PAL.Borda }) $(if ($s.Focused) { [float](S 2.5) } else { [float]1 }) $G.Fechar '' $F.Botao $script:PAL.Painel
})
$ajudaTopo.Controls.AddRange(@($ajudaRotulo, $ajudaTitulo, $ajudaFechar))

$ajudaCorpo = New-Object Windows.Forms.FlowLayoutPanel
$ajudaCorpo.Dock = 'Fill'; $ajudaCorpo.FlowDirection = 'TopDown'; $ajudaCorpo.WrapContents = $false; $ajudaCorpo.AutoScroll = $true
$ajudaCorpo.Padding = New-Object Windows.Forms.Padding((S 24), (S 8), (S 16), (S 24)); $ajudaCorpo.TabIndex = 2
Buffer-Duplo $ajudaCorpo
$painelAjuda.Controls.Add($ajudaCorpo); $painelAjuda.Controls.Add($ajudaTopo)

# Ordem de encaixe: cabeçalho, rodapé, painel de ajuda à direita, filtros e a grade no espaço que sobra.
$form.Controls.Add($grade); $form.Controls.Add($barraFiltros); $form.Controls.Add($painelAjuda); $form.Controls.Add($rodape); $form.Controls.Add($topo)

$script:ajudaControles = @()   # rótulos do painel de ajuda e o papel de cada um, para recolorir ao trocar o tema
$script:ajudaAberta = $null    # cartão cuja ajuda está aberta

function Rotulo-Ajuda([string]$texto, $fonte, [string]$papel, [int]$recuo = 0, [int]$espacoAcima = 0, [int]$espacoAbaixo = 6) {
  $l = New-Object Windows.Forms.Label
  $l.Text = $texto; $l.Font = $fonte; $l.AutoSize = $true
  $l.MaximumSize = New-Object Drawing.Size(($painelAjuda.Width - (S 64) - $recuo), 0)
  $l.Margin = New-Object Windows.Forms.Padding($recuo, $espacoAcima, 0, $espacoAbaixo)
  $script:ajudaControles += [pscustomobject]@{ Controle = $l; Papel = $papel }
  $ajudaCorpo.Controls.Add($l)
  return $l
}

function Colorir-Ajuda {
  $painelAjuda.BackColor = $script:PAL.Painel; $ajudaTopo.BackColor = $script:PAL.Painel; $ajudaCorpo.BackColor = $script:PAL.Painel
  $ajudaRotulo.BackColor = $script:PAL.Painel; $ajudaTitulo.BackColor = $script:PAL.Painel
  $ajudaRotulo.ForeColor = $script:PAL.Destaque; $ajudaTitulo.ForeColor = $script:PAL.Texto
  foreach ($item in $script:ajudaControles) {
    $item.Controle.BackColor = $script:PAL.Painel
    switch ($item.Papel) {
      'secao' { $item.Controle.ForeColor = $script:PAL.Secao }
      'suave' { $item.Controle.ForeColor = $script:PAL.Suave }
      'link'  { $item.Controle.LinkColor = $script:PAL.Destaque; $item.Controle.ActiveLinkColor = $script:PAL.Destaque; $item.Controle.ForeColor = $script:PAL.Destaque }
      default { $item.Controle.ForeColor = $script:PAL.Texto }
    }
  }
  $painelAjuda.Invalidate(); $ajudaTopo.Invalidate(); $ajudaFechar.Invalidate()
}

# Abre SÓ as instruções (não inicia a automação). O painel fica aberto até a pessoa fechar.
function Mostrar-Ajuda($cartao) {
  $aj = $cartao.Automacao.Ajuda
  $dica.Active = $false; $dica.Active = $true   # esconde qualquer resumo flutuante
  $form.SuspendLayout(); $ajudaCorpo.SuspendLayout()
  $ajudaCorpo.Controls.Clear(); $script:ajudaControles = @()
  $ajudaTitulo.Text = $cartao.Automacao.Nome
  Rotulo-Ajuda $aj.resumo $F.Texto 'texto' 0 (S 8) | Out-Null
  Rotulo-Ajuda 'Para que serve' $F.Secao 'secao' 0 (S 16) | Out-Null
  Rotulo-Ajuda $aj.serve $F.Texto 'texto' | Out-Null
  Rotulo-Ajuda 'O que preparar antes' $F.Secao 'secao' 0 (S 16) | Out-Null
  foreach ($item in @($aj.preparar)) { Rotulo-Ajuda ("•  " + $item) $F.Texto 'texto' (S 4) | Out-Null }
  Rotulo-Ajuda 'Passo a passo' $F.Secao 'secao' 0 (S 16) | Out-Null
  $n = 1
  foreach ($item in @($aj.passos)) { Rotulo-Ajuda ("$n.  " + $item) $F.Texto 'texto' (S 4) | Out-Null; $n++ }
  Rotulo-Ajuda 'Resultado esperado' $F.Secao 'secao' 0 (S 16) | Out-Null
  Rotulo-Ajuda $aj.resultado $F.Texto 'texto' | Out-Null
  if ($aj.arquivos) {
    Rotulo-Ajuda 'Onde ficam os arquivos' $F.Secao 'secao' 0 (S 16) | Out-Null
    Rotulo-Ajuda $aj.arquivos $F.Texto 'texto' | Out-Null
  }
  $fonte = Expandir $aj.fonte
  if ($fonte) {
    $link = New-Object Windows.Forms.LinkLabel
    $link.Text = 'Ver o documento original do projeto'; $link.Font = $F.Texto; $link.AutoSize = $true
    $link.Margin = New-Object Windows.Forms.Padding(0, (S 20), 0, (S 2))
    $link.Tag = $fonte; $link.TabStop = $true; $link.LinkBehavior = 'HoverUnderline'
    $dica.SetToolTip($link, "Abre $fonte no Bloco de Notas (só leitura do documento; não inicia a automação).")
    # Abre o documento no Bloco de Notas: nunca executa nada do projeto.
    $link.Add_LinkClicked({ param($s) if (Test-Path -LiteralPath $s.Tag) { Start-Process -FilePath "$env:WINDIR\notepad.exe" -ArgumentList ('"' + $s.Tag + '"') } })
    $script:ajudaControles += [pscustomobject]@{ Controle = $link; Papel = 'link' }
    $ajudaCorpo.Controls.Add($link)
    Rotulo-Ajuda $fonte $F.Pequena 'suave' 0 0 | Out-Null
  }
  $ajudaFechar.Location = New-Object Drawing.Point(($painelAjuda.Width - (S 60)), (S 18))
  $ajudaTopo.Height = [Math]::Max((S 96), $ajudaTitulo.Bottom + (S 16))
  Colorir-Ajuda
  $script:ajudaAberta = $cartao
  $painelAjuda.Visible = $true
  $ajudaCorpo.ResumeLayout(); $form.ResumeLayout()
  $ajudaCorpo.AutoScrollPosition = New-Object Drawing.Point(0, 0)
  foreach ($k2 in $cartoes) { $k2.Ajuda.Invalidate(); $k2.Painel.Invalidate() }
  Ajustar-Layout
  $rodape.Text = "Ajuda de $($cartao.Automacao.Nome) aberta.   Esc ou o X fecham a ajuda  ·  o botão Abrir automação inicia o projeto"
  $ajudaFechar.Focus()
}

function Fechar-Ajuda {
  if (-not $painelAjuda.Visible) { return }
  $origem = $script:ajudaAberta
  $painelAjuda.Visible = $false
  $script:ajudaAberta = $null
  foreach ($k2 in $cartoes) { $k2.Ajuda.Invalidate(); $k2.Painel.Invalidate() }
  Ajustar-Layout
  Aplicar-Filtro
  if ($origem -and $origem.Painel.Visible) { $origem.Ajuda.Focus() }
}
$ajudaFechar.Add_Click({ Fechar-Ajuda })

# ---------------------------------------------------------------- cartões (todos do mesmo tamanho, áreas fixas)
# Grade interna do cartão (em pixels a 100%, multiplicados pela escala):
#   margem 22 · ícone 44 · cabeçalho (categoria + nome, até 2 linhas) · descrição (até 2 linhas)
#   · situação (1 linha, em etiqueta) · botão 40. Nada ultrapassa o cartão: textos longos terminam em "…" e o
#   texto completo aparece ao passar o mouse.
$M = S 22
$ALTURA_CARTAO = S 250
$LARGURA_MINIMA = S 320
$ESPACO = S 18
$cartoes = @()
$tipos = @{ janela = 'Abre a janela do programa'; terminal = 'Abre a interface (janela de comando visível)'; chrome = 'Abre o e-CAC no Chrome; inicie pela extensão' }
# Automação do Chrome com "painel" (página da própria extensão): o botão abre o painel, não o site.
function Texto-Tipo($a) { if ($a.Tipo -eq 'chrome' -and $a.Painel) { return 'Abre o painel da automação no Chrome' } return $tipos[$a.Tipo] }
$alturaLinhaNome = [Windows.Forms.TextRenderer]::MeasureText('Ág', $F.Nome).Height
$alturaLinhaDesc = [Windows.Forms.TextRenderer]::MeasureText('Ág', $F.Desc).Height

# Situação do cartão: texto curto na etiqueta e o detalhe completo ao passar o mouse.
function Status($cartao, [string]$curto, [string]$tipo, [string]$detalhe = '') {
  $cartao.StatusTexto = $curto
  $cartao.StatusTipo = $tipo
  $cartao.StatusDetalhe = $(if ($detalhe) { $detalhe } else { $curto })
  $cartao.Status.Text = $curto
  $cartao.Status.ForeColor = Cor-Status $tipo
  $cartao.Status.BackColor = Fundo-Status $tipo
  $dica.SetToolTip($cartao.Status, $cartao.StatusDetalhe)
  Posicionar-Status $cartao
  $cartao.Painel.Invalidate()
}
function Cor-Status([string]$tipo) { switch ($tipo) { 'ok' { $script:PAL.Ok } 'aviso' { $script:PAL.Aviso } 'erro' { $script:PAL.Erro } default { $script:PAL.Neutro } } }
function Fundo-Status([string]$tipo) { switch ($tipo) { 'ok' { $script:PAL.OkFundo } 'aviso' { $script:PAL.AvisoFundo } 'erro' { $script:PAL.ErroFundo } default { $script:PAL.NeutroFundo } } }
function Posicionar-Status($cartao) {
  $maximo = $cartao.Painel.Width - 2 * $M - (S 34)
  $w = [Math]::Min($maximo, [Windows.Forms.TextRenderer]::MeasureText($cartao.Status.Text, $F.Status).Width + (S 4))
  $cartao.Status.Size = New-Object Drawing.Size($w, ([Windows.Forms.TextRenderer]::MeasureText('Ág', $F.Status).Height))
  $cartao.Status.Location = New-Object Drawing.Point(($M + (S 24)), ($ALTURA_CARTAO - $M - (S 40) - (S 14) - (S 26) + [int](((S 26) - $cartao.Status.Height) / 2)))
}

# Texto curto da situação a partir da conferência (o detalhe vai para a dica).
function Resumo-Conferencia($conf) {
  if (-not $conf.Ok) {
    if ($conf.Motivo -like 'a pasta do projeto*') { return @('Pasta do projeto não encontrada', 'erro', "Não pode abrir: $($conf.Motivo)") }
    if ($conf.Motivo -like 'o arquivo de início*') { return @('Arquivo de início não encontrado', 'erro', "Não pode abrir: $($conf.Motivo)") }
    if ($conf.Motivo -like 'Node.js*') { return @('Node.js não instalado', 'erro', "Não pode abrir: $($conf.Motivo)") }
    if ($conf.Motivo -like 'Google Chrome*') { return @('Google Chrome não encontrado', 'erro', "Não pode abrir: $($conf.Motivo)") }
    return @('Não pode abrir', 'erro', $conf.Motivo)
  }
  if ($conf.Aviso -like '*DESLIGADA*') { return @('Extensão desligada no Chrome', 'aviso', "Atenção: $($conf.Aviso)") }
  if ($conf.Aviso -like 'extensão não carregada*') { return @('Extensão não carregada no Chrome', 'aviso', "Atenção: $($conf.Aviso)") }
  if ($conf.Aviso) { return @('Verifique a extensão', 'aviso', "Atenção: $($conf.Aviso)") }
  return @('Pronta para abrir', 'ok', '')
}

foreach ($a in $automacoes) {
  $painel = New-Object Windows.Forms.Panel
  $painel.Height = $ALTURA_CARTAO; $painel.Width = $LARGURA_MINIMA
  $painel.Margin = New-Object Windows.Forms.Padding(0, 0, $ESPACO, $ESPACO)
  Buffer-Duplo $painel

  $categoria = New-Object Windows.Forms.Label
  $categoria.Text = $a.Categoria.ToUpperInvariant(); $categoria.Font = $F.Rotulo; $categoria.AutoSize = $true
  $categoria.Location = New-Object Drawing.Point(($M + (S 44) + (S 14)), ($M + (S 1)))

  $nome = New-Object Windows.Forms.Label
  $nome.Text = $a.Nome; $nome.Font = $F.Nome; $nome.AutoSize = $false; $nome.AutoEllipsis = $true
  $nome.Location = New-Object Drawing.Point(($M + (S 44) + (S 12)), ($M + (S 20))); $nome.Height = 2 * $alturaLinhaNome

  $desc = New-Object Windows.Forms.Label
  $desc.Text = $a.Descricao; $desc.Font = $F.Desc; $desc.AutoSize = $false; $desc.AutoEllipsis = $true
  $desc.Location = New-Object Drawing.Point(($M - (S 2)), ($M + (S 20) + 2 * $alturaLinhaNome + (S 12))); $desc.Height = 2 * $alturaLinhaDesc

  $status = New-Object Windows.Forms.Label
  $status.Font = $F.Status; $status.AutoSize = $false; $status.AutoEllipsis = $true; $status.TextAlign = 'MiddleLeft'
  $status.UseMnemonic = $false

  $botao = New-Object Windows.Forms.Button
  $botao.Text = 'Abrir automação'; $botao.FlatStyle = 'Flat'; $botao.FlatAppearance.BorderSize = 0; $botao.Cursor = 'Hand'
  $botao.Font = $F.Botao; $botao.Height = S 40; $botao.Location = New-Object Drawing.Point($M, ($ALTURA_CARTAO - $M - (S 40)))
  $botao.AccessibleName = "Abrir automação $($a.Nome)"; $botao.UseVisualStyleBackColor = $false
  Buffer-Duplo $botao
  $dica.SetToolTip($botao, "$($a.Nome): $(Texto-Tipo $a)")

  # Botão "?" discreto no canto superior direito: só nos cartões com instruções.
  $ajuda = New-Object Windows.Forms.Button
  $ajuda.Size = New-Object Drawing.Size((S 30), (S 30)); $ajuda.FlatStyle = 'Flat'; $ajuda.FlatAppearance.BorderSize = 0
  $ajuda.Cursor = 'Hand'; $ajuda.Text = ''; $ajuda.AccessibleName = "Ajuda: $($a.Nome)"; $ajuda.UseVisualStyleBackColor = $false
  $ajuda.Visible = [bool]$a.Ajuda
  Buffer-Duplo $ajuda

  $painel.Controls.AddRange(@($ajuda, $categoria, $nome, $desc, $status, $botao))
  $ajuda.TabIndex = 0; $botao.TabIndex = 1
  $grade.Controls.Add($painel)

  $k = [pscustomobject]@{
    Automacao = $a; Painel = $painel; Nome = $nome; Desc = $desc; Categoria = $categoria; Status = $status; Botao = $botao; Ajuda = $ajuda
    StatusTexto = ''; StatusTipo = 'suave'; StatusDetalhe = ''; Processo = $null; Inicio = $null; Abrindo = $false; Aberta = $false; FimRetorno = $null
  }
  $cartoes += $k
  foreach ($ctl in @($painel, $botao, $nome, $desc, $categoria, $status, $ajuda)) { $ctl.Tag = $k }
  $dica.SetToolTip($nome, $a.Nome)
  $dica.SetToolTip($desc, $a.Descricao)
  if ($a.Ajuda) { $dica.SetToolTip($ajuda, "$($a.Ajuda.resumo)`n`nClique (ou Enter) para ver as instruções completas.") }

  # Fundo arredondado, ícone num círculo, etiqueta da situação e borda de destaque com o foco do teclado.
  $painel.Add_Paint({
    param($s, $e)
    $kk = $s.Tag
    $gr = $e.Graphics; $gr.SmoothingMode = 'AntiAlias'
    $r = New-Object Drawing.RectangleF 1, 1, ($s.Width - 3), ($s.Height - 3)
    $caminho = Caminho-Arredondado $r ([float](S 12))
    $gr.FillPath((New-Object Drawing.SolidBrush $script:PAL.Cartao), $caminho)
    $focado = $kk.Botao.Focused -or $kk.Ajuda.Focused
    $sobre = (Mouse-Sobre $s) -or ($script:ajudaAberta -eq $kk)
    $corBorda = if ($focado) { $script:PAL.Foco } elseif ($sobre) { $script:PAL.Destaque } else { $script:PAL.Borda }
    $gr.DrawPath((New-Object Drawing.Pen($corBorda, $(if ($focado) { [float](S 2.5) } else { [float]1 }))), $caminho)
    # Ícone: círculo com o símbolo desenhado pelo GDI (nítido).
    $gr.FillEllipse((New-Object Drawing.SolidBrush $script:PAL.DestaqueFundo), $M, $M, (S 44), (S 44))
    $gr.SmoothingMode = 'None'
    [Windows.Forms.TextRenderer]::DrawText($gr, $kk.Automacao.Icone, $F.Icone, (New-Object Drawing.Rectangle ($M + (S 6)), ($M + (S 7)), (S 32), (S 31)), $script:PAL.Destaque, $script:PAL.DestaqueFundo, $CENTRO)
    # Etiqueta da situação: pílula com a cor do estado, um ponto e o texto curto.
    $yEtq = $ALTURA_CARTAO - $M - (S 40) - (S 14) - (S 26)
    $wEtq = $kk.Status.Width + (S 34)
    $gr.SmoothingMode = 'AntiAlias'
    $pilula = Caminho-Arredondado (New-Object Drawing.RectangleF $M, $yEtq, $wEtq, (S 26)) ([float](S 13))
    $gr.FillPath((New-Object Drawing.SolidBrush (Fundo-Status $kk.StatusTipo)), $pilula)
    $gr.FillEllipse((New-Object Drawing.SolidBrush (Cor-Status $kk.StatusTipo)), ($M + (S 11)), ($yEtq + (S 9)), (S 8), (S 8))
  })
  $painel.Add_MouseEnter({ param($s) $s.Invalidate() })
  $painel.Add_MouseLeave({ param($s) $s.Invalidate() })

  # Desenho do "?": círculo com contorno; preenchido ao passar o mouse, com a ajuda aberta ou com o foco.
  $ajuda.Add_Paint({
    param($s, $e)
    $kk = $s.Tag
    $gr = $e.Graphics
    $gr.Clear($script:PAL.Cartao)
    $gr.SmoothingMode = 'AntiAlias'
    $ativo = (Mouse-Sobre $s) -or ($script:ajudaAberta -eq $kk)
    $d = $s.Width - (S 5)
    if ($ativo -or $s.Focused) { $gr.FillEllipse((New-Object Drawing.SolidBrush $script:PAL.DestaqueFundo), (S 2), (S 2), $d, $d) }
    if ($s.Focused) { $gr.DrawEllipse((New-Object Drawing.Pen($script:PAL.Foco, [float](S 2.5))), (S 2), (S 2), $d, $d) }
    else { $gr.DrawEllipse((New-Object Drawing.Pen($(if ($ativo) { $script:PAL.Destaque } else { $script:PAL.Borda }), [float](S 1.5))), (S 2), (S 2), $d, $d) }
    $gr.SmoothingMode = 'None'
    $fundoQ = if ($ativo -or $s.Focused) { $script:PAL.DestaqueFundo } else { $script:PAL.Cartao }
    [Windows.Forms.TextRenderer]::DrawText($gr, '?', $F.Interrog, (New-Object Drawing.Rectangle 0, 0, $s.Width, $s.Height), $(if ($ativo -or $s.Focused) { $script:PAL.Destaque } else { $script:PAL.Suave }), $fundoQ, $CENTRO)
  })
  $ajuda.Add_MouseEnter({ param($s) $s.Invalidate(); $s.Tag.Painel.Invalidate() })
  $ajuda.Add_MouseLeave({ param($s) $s.Invalidate(); $s.Tag.Painel.Invalidate() })
  # Pelo teclado, ao chegar no "?", o resumo aparece como no mouse.
  $ajuda.Add_GotFocus({
    param($s)
    $s.Invalidate(); $s.Tag.Painel.Invalidate(); $grade.ScrollControlIntoView($s.Tag.Painel)
    $dica.Show($dica.GetToolTip($s), $s, 0, ($s.Height + (S 4)), 8000)
  })
  $ajuda.Add_LostFocus({ param($s) $s.Invalidate(); $s.Tag.Painel.Invalidate(); $dica.Hide($s) })
  $ajuda.Add_Click({ param($s) $dica.Hide($s); Mostrar-Ajuda $s.Tag })
  # Enter ou Espaço no "?" abrem a ajuda (garantido, sem depender do comportamento padrão do botão).
  $ajuda.Add_PreviewKeyDown({ param($s, $ev) if ($ev.KeyCode -eq 'Return') { $ev.IsInputKey = $true } })
  $ajuda.Add_KeyDown({ param($s, $ev) if ($ev.KeyCode -eq 'Return' -or $ev.KeyCode -eq 'Space') { $ev.SuppressKeyPress = $true; $dica.Hide($s); Mostrar-Ajuda $s.Tag } })

  # Botão principal desenhado pela central (azul; verde por instantes depois de abrir).
  $botao.Add_Paint({
    param($s, $e)
    $kk = $s.Tag
    $sobre = Mouse-Sobre $s
    $fundo = if ($kk.Aberta) { Cor '#138A4B' } elseif ($kk.Abrindo -or $sobre) { $script:PAL.AzulEscuro } else { $script:PAL.Azul }
    $texto = if ($kk.Abrindo) { 'Abrindo…' } elseif ($kk.Aberta) { 'Aberta' } else { 'Abrir automação' }
    $glifo = if ($kk.Aberta) { $G.Ok } else { $G.Abrir }
    Pintar-Botao $s $e $fundo ([Drawing.Color]::White) $(if ($s.Focused) { $script:PAL.Foco } else { $fundo }) $(if ($s.Focused) { [float](S 2.5) } else { [float]0 }) $glifo $texto $F.Botao $script:PAL.Cartao
  })
  $botao.Add_GotFocus({ param($s) $s.Invalidate(); $s.Tag.Painel.Invalidate(); $grade.ScrollControlIntoView($s.Tag.Painel) })
  $botao.Add_LostFocus({ param($s) $s.Invalidate(); $s.Tag.Painel.Invalidate() })
  $botao.Add_MouseEnter({ param($s) $s.Invalidate(); $s.Tag.Painel.Invalidate() })
  $botao.Add_MouseLeave({ param($s) $s.Invalidate(); $s.Tag.Painel.Invalidate() })

  $botao.Add_Click({
    param($s)
    $kk = $s.Tag
    # Cliques repetidos: ignorados enquanto abre e nos 3 s do retorno "Aberta" (evita abrir duas vezes).
    if ($kk.Abrindo -or $kk.Aberta) { return }
    $auto = $kk.Automacao
    # Retorno imediato do clique.
    $kk.Abrindo = $true; $s.Refresh()
    $form.Cursor = 'AppStarting'
    try {
      $conf = Conferir $auto (Extensoes-Carregadas) $chrome
      if (-not $conf.Ok) { throw (New-Object InvalidOperationException $conf.Motivo) }
      $novo = Iniciar $auto $chrome
      # Se a janela aberta antes continua rodando, a central segue acompanhando ela (a nova, de um
      # segundo clique, normalmente só reabre a interface e fecha sozinha).
      $anterior = $kk.Processo
      $anteriorViva = $false
      if ($anterior) { try { $anterior.Refresh(); $anteriorViva = -not $anterior.HasExited } catch { } }
      if (-not $anteriorViva) { $kk.Processo = $novo; $kk.Inicio = Get-Date }
      $kk.Aberta = $true; $kk.FimRetorno = (Get-Date).AddSeconds(3)
      $res = Resumo-Conferencia $conf
      if ($res[1] -eq 'aviso') { Status $kk $res[0] 'aviso' $res[2] } else { Status $kk "Aberta às $((Get-Date).ToString('HH:mm'))" 'ok' "Aberta às $((Get-Date).ToString('HH:mm')). $($auto.Dica)" }
      $rodape.Text = "$($auto.Nome) aberta. A central continua disponível para abrir outras automações."
    } catch {
      $motivo = $_.Exception.Message
      try { "$(Get-Date -Format s)  Não abriu $($auto.Nome): $motivo`r`n" | Add-Content -LiteralPath (Join-Path $AQUI 'central_erros.log') -Encoding UTF8 } catch { }
      Status $kk 'Não abriu' 'erro' "Não abriu: $motivo"
      $rodape.Text = "Falha ao abrir $($auto.Nome)."
      [Windows.Forms.MessageBox]::Show("Não foi possível abrir $($auto.Nome).`n`nMotivo: $motivo", 'Central de Automações', 'OK', 'Error') | Out-Null
    } finally {
      $kk.Abrindo = $false
      $form.Cursor = 'Default'
      $s.Invalidate()
    }
  })
}
$grade.Controls.Add($vazio)
$ordem = 0
foreach ($x in $chips) { $x.TabIndex = $ordem++ }
foreach ($k in $cartoes) { $k.Painel.TabIndex = $ordem++ }

# ---------------------------------------------------------------- aplicar o tema em toda a central
function Aplicar-Tema([string]$tema, [bool]$salvar = $false) {
  $script:tema = $tema
  Carregar-Paleta $tema
  if ($salvar) { Salvar-Tema $tema }
  $form.SuspendLayout()
  $form.BackColor = $script:PAL.Fundo
  foreach ($ctl in @($topo, $caixaLogo, $titulo, $subtitulo, $caixaBusca, $rotuloTema)) { $ctl.BackColor = $script:PAL.Cabecalho }
  $subtitulo.ForeColor = $script:PAL.CabecalhoTexto; $rotuloTema.ForeColor = $script:PAL.CabecalhoTexto
  $busca.BackColor = $script:PAL.Campo; $busca.ForeColor = $script:PAL.CampoTexto
  $lupa.BackColor = $script:PAL.Campo; $lupa.ForeColor = $script:PAL.CampoAjuda
  $ajudaBusca.BackColor = $script:PAL.Campo; $ajudaBusca.ForeColor = $script:PAL.CampoAjuda
  $barraFiltros.BackColor = $script:PAL.Fundo
  $grade.BackColor = $script:PAL.Fundo
  $vazio.ForeColor = $script:PAL.Suave; $vazio.BackColor = $script:PAL.Fundo
  $rodape.BackColor = $script:PAL.Rodape; $rodape.ForeColor = $script:PAL.Suave
  foreach ($cartao in $cartoes) {
    $cartao.Painel.BackColor = $script:PAL.Fundo
    foreach ($ctl in @($cartao.Nome, $cartao.Desc, $cartao.Categoria)) { $ctl.BackColor = $script:PAL.Cartao }
    $cartao.Nome.ForeColor = $script:PAL.Texto; $cartao.Desc.ForeColor = $script:PAL.Suave; $cartao.Categoria.ForeColor = $script:PAL.Destaque
    if ($cartao.StatusTexto) { Status $cartao $cartao.StatusTexto $cartao.StatusTipo $cartao.StatusDetalhe }
    $cartao.Painel.Invalidate(); $cartao.Ajuda.Invalidate(); $cartao.Botao.Invalidate()
  }
  foreach ($b in @($atualizar, $temaClaro, $temaEscuro) + $chips) { $b.Invalidate() }
  Colorir-Ajuda
  $form.ResumeLayout()
  $form.Refresh()
}
$temaClaro.Add_Click({ Aplicar-Tema 'Claro' $true; $rodape.Text = 'Tema claro aplicado e salvo para as próximas vezes.' })
$temaEscuro.Add_Click({ Aplicar-Tema 'Escuro' $true; $rodape.Text = 'Tema escuro aplicado e salvo para as próximas vezes.' })

# ---------------------------------------------------------------- layout responsivo
function Ajustar-Layout {
  $grade.SuspendLayout()
  $util = $grade.ClientSize.Width - $grade.Padding.Left - $grade.Padding.Right - [Windows.Forms.SystemInformation]::VerticalScrollBarWidth
  # Cada cartão ocupa a largura dele mais o espaço à direita (inclusive o último da linha).
  $porLinha = [Math]::Max(1, [Math]::Floor($util / ($LARGURA_MINIMA + $ESPACO)))
  $porLinha = [Math]::Min($porLinha, [Math]::Max(1, @($cartoes | Where-Object { $_.Painel.Visible }).Count))
  $largura = [Math]::Max((S 270), [Math]::Floor($util / $porLinha) - $ESPACO)
  $largura = [Math]::Min($largura, (S 620))
  foreach ($cartao in $cartoes) {
    $cartao.Painel.Width = $largura
    $cartao.Ajuda.Location = New-Object Drawing.Point(($largura - $M - (S 30) + (S 6)), ($M - (S 4)))
    $direitaNome = if ($cartao.Automacao.Ajuda) { $cartao.Ajuda.Left - (S 8) } else { $largura - $M }
    $cartao.Nome.Width = $direitaNome - $cartao.Nome.Left
    $cartao.Desc.Width = $largura - 2 * $M + (S 2)
    $cartao.Botao.Width = $largura - 2 * $M
    Posicionar-Status $cartao
  }
  $grade.ResumeLayout()
  # Cabeçalho: tema no canto superior direito; busca ocupa o espaço até o botão Atualizar (mesma altura).
  $direita = $topo.ClientSize.Width - (S 28)
  $temaEscuro.Location = New-Object Drawing.Point(($direita - $temaEscuro.Width), (S 26))
  $temaClaro.Location = New-Object Drawing.Point(($temaEscuro.Left - $temaClaro.Width - (S 6)), (S 26))
  $rotuloTema.Location = New-Object Drawing.Point(($temaClaro.Left - $rotuloTema.Width - (S 10)), ((S 26) + [int](((S 34) - $rotuloTema.Height) / 2)))
  $rotuloTema.Visible = ($rotuloTema.Left -gt ($subtitulo.Right + (S 12)))
  $atualizar.Location = New-Object Drawing.Point(($direita - $atualizar.Width), (S 94))
  $caixaBusca.Width = [Math]::Min((S 780), $atualizar.Left - (S 28) - (S 14))
  $busca.Location = New-Object Drawing.Point((S 44), [int](((S 46) - $busca.Height) / 2))
  $busca.Width = $caixaBusca.Width - (S 58)
  $ajudaBusca.Location = New-Object Drawing.Point(($busca.Left - (S 3)), [int](((S 46) - $ajudaBusca.Height) / 2))
  $caixaBusca.Invalidate()
}

# ---------------------------------------------------------------- busca e filtros
function Aplicar-Filtro {
  $termo = $busca.Text
  $ajudaBusca.Visible = -not $termo
  $grade.SuspendLayout()
  $n = 0
  foreach ($cartao in $cartoes) {
    $mostra = ((-not $script:categoriaAtual) -or $cartao.Automacao.Categoria -eq $script:categoriaAtual) -and (Combina $cartao.Automacao $termo)
    $cartao.Painel.Visible = $mostra
    if ($mostra) { $n++ }
  }
  $vazio.Visible = ($n -eq 0)
  if ($n -eq 0) {
    $partes = 'Nenhuma automação encontrada'
    if ($termo.Trim()) { $partes += ' para "' + $termo.Trim() + '"' }
    if ($script:categoriaAtual) { $partes += ' em ' + $script:categoriaAtual }
    $vazio.Text = $partes + '. Apague a busca ou escolha Todas.'
  }
  $grade.ResumeLayout()
  if ($painelAjuda.Visible) { }
  elseif ($termo.Trim() -or $script:categoriaAtual) { $rodape.Text = "Mostrando $n de $($cartoes.Count) automações.   Esc limpa a busca  ·  Tab navega  ·  Enter abre" }
  else { $rodape.Text = "$($cartoes.Count) automações.   Atalhos: Ctrl+F busca  ·  Tab navega  ·  Enter abre  ·  ? mostra a ajuda  ·  F5 atualiza" }
  Ajustar-Layout
}

$busca.Add_TextChanged({ Aplicar-Filtro })
$busca.Add_KeyDown({
  param($s, $e)
  $vis = @($cartoes | Where-Object { $_.Painel.Visible })
  if ($e.KeyCode -eq 'Return') { if ($vis.Count -eq 1) { $vis[0].Botao.PerformClick() }; $e.SuppressKeyPress = $true }
  elseif ($e.KeyCode -eq 'Down' -and $vis.Count) { $vis[0].Botao.Focus(); $e.SuppressKeyPress = $true }
  elseif ($e.KeyCode -eq 'Escape' -and -not $painelAjuda.Visible) { $busca.Clear() }
})
# Ctrl+F ou F3 voltam para a busca; F5 confere de novo; Esc fecha a ajuda aberta.
$form.Add_KeyDown({
  param($s, $e)
  if (($e.Control -and $e.KeyCode -eq 'F') -or $e.KeyCode -eq 'F3') { $busca.Focus(); $busca.SelectAll(); $e.SuppressKeyPress = $true }
  elseif ($e.KeyCode -eq 'F5') { Atualizar-Status; $e.SuppressKeyPress = $true }
  elseif ($e.KeyCode -eq 'Escape' -and $painelAjuda.Visible) { Fechar-Ajuda; $e.SuppressKeyPress = $true }
})

# ---------------------------------------------------------------- situação de cada automação
function Atualizar-Status {
  $ext = Extensoes-Carregadas
  foreach ($cartao in $cartoes) {
    if ($cartao.Processo -or $cartao.Abrindo) { continue }
    $res = Resumo-Conferencia (Conferir $cartao.Automacao $ext $chrome)
    $detalhe = if ($res[2]) { $res[2] } else { "Pronta  ·  $(Texto-Tipo $cartao.Automacao)" }
    Status $cartao $res[0] $res[1] $detalhe
  }
  if (-not $painelAjuda.Visible) { $rodape.Text = "Situação conferida às $((Get-Date).ToString('HH:mm:ss')).   Atalhos: Ctrl+F busca  ·  Tab navega  ·  Enter abre  ·  ? mostra a ajuda  ·  F5 atualiza" }
}
$atualizar.Add_Click({ Atualizar-Status })
$form.Add_Activated({ Atualizar-Status })

# Vigia: volta o botão ao normal depois do retorno "Aberta" e avisa se a automação fechou logo após abrir.
$vigia = New-Object Windows.Forms.Timer
$vigia.Interval = 700
$vigia.Add_Tick({
  foreach ($cartao in $cartoes) {
    if ($cartao.Aberta -and $cartao.FimRetorno -and (Get-Date) -ge $cartao.FimRetorno) {
      $cartao.Aberta = $false; $cartao.FimRetorno = $null; $cartao.Botao.Invalidate()
    }
    $proc = $cartao.Processo
    if (-not $proc) { continue }
    try { $proc.Refresh() } catch { }
    if ($proc.HasExited) {
      $segundos = ((Get-Date) - $cartao.Inicio).TotalSeconds
      $codigo = try { $proc.ExitCode } catch { $null }
      if ($cartao.Automacao.Tipo -ne 'chrome') {
        if ($segundos -lt 15 -and $codigo -and $codigo -ne 0) {
          try { "$(Get-Date -Format s)  $($cartao.Automacao.Nome) fechou logo depois de abrir (código $codigo)`r`n" | Add-Content -LiteralPath (Join-Path $AQUI 'central_erros.log') -Encoding UTF8 } catch { }
          Status $cartao 'Fechou logo depois de abrir' 'erro' "Fechou logo depois de abrir (código $codigo). Veja a mensagem na janela da automação ou a pasta $($cartao.Automacao.Pasta)"
        } else {
          Status $cartao "Janela fechada às $((Get-Date).ToString('HH:mm'))" 'suave' "Janela da automação fechada às $((Get-Date).ToString('HH:mm')). Clique em Abrir automação para abrir de novo."
        }
      }
      $cartao.Processo = $null
    }
  }
})
$vigia.Start()

$form.Add_Resize({ Ajustar-Layout })
# Garante que a janela apareça na frente ao abrir pelo atalho (o atalho abre o PowerShell escondido).
$form.Add_Shown({ $form.WindowState = 'Normal'; $form.TopMost = $true; $form.TopMost = $false; $form.Activate(); Aplicar-Filtro; $busca.Focus() })
Aplicar-Tema $script:tema
Atualizar-Status

# ---------------------------------------------------------------- autoteste (não inicia nenhuma automação)
if ($TesteJanela) {
  New-Item -ItemType Directory -Force -Path $TesteJanela | Out-Null
  $script:passo = 0
  $saida = New-Object Collections.Generic.List[string]
  $saida.Add("tema inicial=$($script:tema) (preferencias: $ARQ_PREF, existe=$(Test-Path -LiteralPath $ARQ_PREF))")
  $saida.Add("DPI do sistema=$dpiSistema, escala usada=$script:FATOR, consciencia de DPI do processo=$script:dpiConsciente (1=sistema, 2=por monitor)")
  function Capturar([string]$nome) {
    $form.TopMost = $true; $form.Activate(); $form.Refresh(); [Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 300
    $r = $form.Bounds
    $bmp = New-Object Drawing.Bitmap($r.Width, $r.Height)
    $gr = [Drawing.Graphics]::FromImage($bmp); $gr.CopyFromScreen($r.Location, [Drawing.Point]::Empty, $r.Size); $gr.Dispose()
    $bmp.Save((Join-Path $TesteJanela $nome), [Drawing.Imaging.ImageFormat]::Png); $bmp.Dispose()
    $form.TopMost = $false
  }
  # Tecla enviada direto para um controle da central (nunca para outra janela do computador).
  Add-Type -Namespace CentralTeste -Name Teclas -MemberDefinition '[DllImport("user32.dll")] public static extern bool PostMessage(System.IntPtr h, uint m, System.IntPtr w, System.IntPtr l);'
  function Tecla($ctl, [int]$vk) { [CentralTeste.Teclas]::PostMessage($ctl.Handle, 0x100, [IntPtr]$vk, [IntPtr]0) | Out-Null; [CentralTeste.Teclas]::PostMessage($ctl.Handle, 0x101, [IntPtr]$vk, [IntPtr]0) | Out-Null; for ($i = 0; $i -lt 10; $i++) { [Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 30 } }
  function Visiveis { return (($cartoes | Where-Object { $_.Painel.Visible } | ForEach-Object { $_.Automacao.Nome }) -join ' | ') }
  function Cartao([string]$nome) { return ($cartoes | Where-Object { $_.Automacao.Nome -eq $nome } | Select-Object -First 1) }
  # Confere se algum texto não cabe no espaço dele (nome, descrição, situação) e se algo sai do cartão.
  function Medir-Cortes {
    $problemas = @()
    foreach ($cartao in ($cartoes | Where-Object { $_.Painel.Visible })) {
      $fl = [Windows.Forms.TextFormatFlags]::WordBreak
      $hNome = [Windows.Forms.TextRenderer]::MeasureText($cartao.Nome.Text, $F.Nome, (New-Object Drawing.Size $cartao.Nome.Width, 0), $fl).Height
      if ($hNome -gt $cartao.Nome.Height) { $problemas += "nome '$($cartao.Automacao.Nome)' precisa de $hNome px e tem $($cartao.Nome.Height)" }
      $hDesc = [Windows.Forms.TextRenderer]::MeasureText($cartao.Desc.Text, $F.Desc, (New-Object Drawing.Size $cartao.Desc.Width, 0), $fl).Height
      if ($hDesc -gt $cartao.Desc.Height) { $problemas += "descricao de '$($cartao.Automacao.Nome)' cortada" }
      $wSt = [Windows.Forms.TextRenderer]::MeasureText($cartao.Status.Text, $F.Status).Width
      if ($wSt -gt $cartao.Status.Width + 2) { $problemas += "situacao de '$($cartao.Automacao.Nome)' abreviada" }
      foreach ($ctl in @($cartao.Nome, $cartao.Desc, $cartao.Status, $cartao.Botao, $cartao.Ajuda)) {
        if ($ctl.Visible -and ($ctl.Right -gt $cartao.Painel.Width - 4 -or $ctl.Bottom -gt $cartao.Painel.Height - 4)) { $problemas += "elemento sai do cartao '$($cartao.Automacao.Nome)'" }
      }
      if ($cartao.Desc.Bottom -gt $cartao.Status.Top - (S 4)) { $problemas += "descricao encosta na situacao em '$($cartao.Automacao.Nome)'" }
    }
    $tops = @($cartoes | Where-Object { $_.Painel.Visible } | ForEach-Object { $_.Painel.Top } | Sort-Object -Unique)
    $porLinha = @($cartoes | Where-Object { $_.Painel.Visible -and $_.Painel.Top -eq $tops[0] }).Count
    $alturas = @($cartoes | ForEach-Object { $_.Painel.Height } | Sort-Object -Unique)
    $filtrosCabem = -not @($chips | Where-Object { $_.Right -gt $barraFiltros.ClientSize.Width -or $_.Bottom -gt $barraFiltros.ClientSize.Height }).Count
    return "janela $($form.ClientSize.Width)x$($form.ClientSize.Height): $porLinha cartao(oes) por linha, largura $($cartoes[0].Painel.Width), alturas iguais=$($alturas.Count -eq 1), filtros cabem=$filtrosCabem, problemas=$(if ($problemas.Count) { $problemas -join '; ' } else { 'nenhum' })"
  }
  $teste = New-Object Windows.Forms.Timer
  $teste.Interval = 1100
  $teste.Add_Tick({
    $script:passo++
    switch ($script:passo) {
      1 {
        $saida.Add("botoes ? visiveis: " + (($cartoes | Where-Object { $_.Ajuda.Visible } | ForEach-Object { $_.Automacao.Nome }) -join ' | '))
        $saida.Add("situacoes: " + (($cartoes | ForEach-Object { "$($_.Automacao.Nome)=$($_.Status.Text)" }) -join ' ; '))
        Aplicar-Tema 'Claro' $true
        $saida.Add("tamanho inicial -> $(Medir-Cortes)")
        Capturar 'claro.png'
      }
      2 {
        foreach ($t in 'auto infracao', 'AUTO-INFRAÇÃO', 'infra', 'pgfn', 'xyz') { $busca.Text = $t; $saida.Add("busca[$t] => $(Visiveis)") }
        $busca.Text = ''
        foreach ($chip in $chips) { $chip.PerformClick(); $saida.Add("filtro[$(if ($chip.Tag.Categoria) { $chip.Tag.Categoria } else { 'Todas' })] => $(Visiveis)") }
        $chips[0].PerformClick()
      }
      3 {
        $alvo = Cartao 'RETIRAR AUTO-INFRAÇÃO'
        $antes = $script:iniciadas
        $alvo.Ajuda.PerformClick()
        $saida.Add("clique no ?: painel visivel=$($painelAjuda.Visible), titulo='$($ajudaTitulo.Text)', automacoes iniciadas=$($script:iniciadas - $antes)")
        Capturar 'claro_ajuda.png'
      }
      4 {
        Tecla $form.ActiveControl 27
        $saida.Add("Esc: painel visivel=$($painelAjuda.Visible), foco voltou ao ?=$((Cartao 'RETIRAR AUTO-INFRAÇÃO').Ajuda.Focused)")
        (Cartao 'PGFN – DOCUMENTOS DE ARRECADAÇÃO').Ajuda.Focus()
      }
      5 {
        $antes = $script:iniciadas
        Tecla (Cartao 'PGFN – DOCUMENTOS DE ARRECADAÇÃO').Ajuda 13
        $saida.Add("Enter no ? (teclado): painel visivel=$($painelAjuda.Visible), titulo='$($ajudaTitulo.Text)', automacoes iniciadas=$($script:iniciadas - $antes)")
        $saida.Add("com a ajuda aberta -> $(Medir-Cortes)")
        $temaEscuro.PerformClick()
        $saida.Add("tema escuro aplicado: tema=$($script:tema), salvo=" + ((Get-Content -LiteralPath $ARQ_PREF -Raw) -replace '\s+', ' '))
        Capturar 'escuro_ajuda.png'
      }
      6 {
        Tecla $form.ActiveControl 27
        $busca.Focus()
        Capturar 'escuro.png'
      }
      7 { $form.WindowState = 'Maximized' }
      8 { $saida.Add("maximizada -> $(Medir-Cortes)"); Capturar 'escuro_maximizada.png' }
      9 { $form.WindowState = 'Normal'; $form.Size = $form.MinimumSize }
      10 {
        $saida.Add("reduzida -> $(Medir-Cortes)"); Capturar 'escuro_reduzida.png'
        $saida.Add("total de automacoes iniciadas durante o teste=$($script:iniciadas)")
        [IO.File]::WriteAllLines((Join-Path $TesteJanela 'resultado.txt'), $saida, (New-Object Text.UTF8Encoding $false))
        $teste.Stop(); $form.Close()
      }
    }
  })
  $form.Add_Shown({ $teste.Start() })
}

[Windows.Forms.Application]::Run($form)
