// Fluxo da automação da CNDT. Roda na página do TST (ver manifest.json).
//
// Para cada empresa da lista (a fila fica no background.js; a janela é a interface.html):
// preenche o CNPJ/CPF, espera a PESSOA digitar o captcha e, quando ela termina, clica em
// "Emitir Certidão"; espera o PDF ser salvo na pasta da empresa; registra o resultado e
// recarrega a página para a próxima. NUNCA lê, escreve ou envia o captcha (a verificação é
// da pessoa) e NUNCA clica em "Emitir e Enviar", "Ouvir" ou outro botão.
//
// Só age quando a aba foi aberta pela automação: endereço com "#cndt_preencher". Abrir a
// página à mão não dispara nada.
//
// Sequência (uma empresa por carregamento da página):
//   0. Pergunta ao background qual é a empresa da vez (ou se a lista acabou / está pausada).
//   1. Confere que é a página de emissão e que não há verificação humana de terceiros.
//   2. Espera o campo CNPJ/CPF existir e estar utilizável (visível, habilitado, editável).
//   3. Espera o script do site terminar de iniciar (captcha carregado = página completa).
//   4. O cursor visual vai até o campo e clica nele (clique real, no ponto da seta); confere
//      que o campo está habilitado e com o foco; limpa (Ctrl+A, Backspace) e digita o
//      documento tecla a tecla, com intervalos variáveis. A máscara do site roda a cada tecla.
//   5. Confere o valor final; se a máscara do site não rodou, formata do mesmo jeito.
//   6. Leva o cursor ao campo do captcha (só foco) e prepara o salvamento do PDF.
//   7. Espera a PESSOA digitar o captcha; quando ela para de digitar, confere o CNPJ e o
//      botão, leva o cursor até "Emitir Certidão" e, depois de uma janela curta em que
//      digitar ou Esc cancela, clica. Lê a resposta do site: sucesso ou erro (ex.: verificação
//      incorreta: espera a pessoa digitar a nova; até 3 envios).
//   8. Sucesso: espera o PDF salvo e confirmado na pasta da empresa (só então "concluída").
//   9. Registra o resultado e segue para a próxima empresa (ou pausa, se pedido).
//
// Recuperação: se o campo não aparecer ou a página não terminar de carregar, recarrega a página
// no máximo CONFIG.MAX_RECARGAS vezes por empresa; passando disso, a empresa fica "com erro" e a
// automação segue para a próxima. Sem ciclos infinitos.

(function () {
  const { CONFIG, CNPJ, PAGINA, CURSOR } = globalThis.CNDT;
  const { log, aviso, esperar, utilizavel, campoDocumento, siteIniciado, desafioExterno, escreverNoCampo, mostrarAviso, dormir, clicar, apagarCampo, digitarHumanizado, esperarDigitacaoDoUsuario, botaoEmitir, esperarResultadoDaEmissao, estadoDoErro } = PAGINA;

  // Ao terminar (com sucesso ou erro), o cursor some depois de um tempo.
  function encerrarCursor() {
    const ms = CONFIG.CURSOR.esconderDepoisDe;
    if (ms > 0) setTimeout(() => CURSOR.esconder(), ms);
  }

  // Uma execução por carregamento de página.
  if (globalThis.CNDT.executando) return;

  const foiAbertaPelaAutomacao = location.hash.replace(/^#/, '').split('&').includes(CONFIG.MARCADOR);
  const naPaginaDeEmissao = CONFIG.CAMINHO_EMISSAO.test(location.pathname);
  if (!foiAbertaPelaAutomacao || !naPaginaDeEmissao) return;
  globalThis.CNDT.executando = true;

  class ErroEtapa extends Error {
    // recuperavel: vale a pena recarregar a página e tentar de novo
    // pausar: problema que precisa da pessoa (a empresa volta para a fila e a automação pausa)
    constructor(mensagem, recuperavel, pausar = false) {
      super(mensagem);
      this.recuperavel = recuperavel;
      this.pausar = pausar;
    }
  }
  class Parada extends Error {}

  // ---- conversa com o background.js -------------------------------------------------------
  async function pedir(tipo, dados) {
    try {
      return (await chrome.runtime.sendMessage({ tipo, dados })) || { ok: false, erro: 'sem resposta da extensão' };
    } catch (e) {
      return { ok: false, erro: `a extensão não respondeu (${e.message}); recarregue a página` };
    }
  }

  // "Parar" na janela: cancela as esperas na hora (a empresa atual continua pendente).
  let parado = false;
  const aoParar = [];
  chrome.storage.onChanged.addListener((mudancas, area) => {
    if (area !== 'local' || !mudancas.cndt_controle) return;
    const estado = mudancas.cndt_controle.newValue && mudancas.cndt_controle.newValue.estado;
    if (estado === 'parada' && !parado) {
      parado = true;
      aoParar.splice(0).forEach((f) => { try { f(); } catch (_) { /* ok */ } });
    }
  });
  const conferirParada = () => { if (parado) throw new Parada('parada pela janela'); };

  const chaveRecargas = (cnpj) => `cndt_recargas:${cnpj}`;
  const recargasFeitas = (cnpj) => Number(sessionStorage.getItem(chaveRecargas(cnpj)) || 0);

  async function preencherDocumento(documento) {
    const doc = CNPJ.validar(documento);
    if (!doc.normalizado) throw new ErroEtapa('Nenhum CNPJ/CPF informado.', false);
    if (!doc.ok) aviso(`Atenção: ${doc.formatado} - ${doc.motivo}. Preenchendo mesmo assim; o site fará a conferência.`);

    // 1. Verificação humana de terceiros: não contorna, deixa com a pessoa (pausa).
    if (desafioExterno()) {
      throw new ErroEtapa('A página pede uma verificação humana extra. Resolva-a manualmente e clique em Continuar na janela.', false, true);
    }

    // 2. Campo utilizável.
    mostrarAviso('Aguardando o campo CNPJ/CPF...');
    const campo = await esperar(() => {
      const c = campoDocumento();
      return c && utilizavel(c) ? c : null;
    }, CONFIG.TEMPOS.esperaCampo);
    if (!campo) {
      const existe = campoDocumento();
      throw new ErroEtapa(existe
        ? 'O campo CNPJ/CPF existe mas está desabilitado ou escondido.'
        : 'O campo "Informe o número do CNPJ / CPF" não foi encontrado (página incompleta ou alterada).', true);
    }

    // 3. Site iniciado (captcha carregado). Sem isso o formulário não funcionaria.
    mostrarAviso('Aguardando a página terminar de carregar...');
    if (!(await esperar(siteIniciado, CONFIG.TEMPOS.esperaSiteIniciado))) {
      throw new ErroEtapa('A página não terminou de carregar (a imagem de verificação não apareceu).', true);
    }
    conferirParada();

    // 4. O cursor vai até o campo e clica nele (clique real, no ponto da seta).
    mostrarAviso('Clicando no campo CNPJ/CPF...');
    const clique = await clicar(campo);
    if (!clique.ok) throw new ErroEtapa(`Não cliquei no campo CNPJ/CPF: ${clique.motivo}. Confira a página.`, false);
    if (!utilizavel(campo)) throw new ErroEtapa('O campo CNPJ/CPF ficou desabilitado depois do clique.', true);
    if (document.activeElement !== campo) {
      aviso('O campo não recebeu o foco com o clique; focando diretamente.');
      campo.focus();
      if (document.activeElement !== campo) throw new ErroEtapa('O campo CNPJ/CPF não aceita o cursor de digitação.', true);
    }

    // Limpa o que houver (Ctrl+A e Backspace).
    if (campo.value) log(`Limpando o valor anterior: "${campo.value}"`);
    if (!apagarCampo(campo)) throw new ErroEtapa('Não consegui limpar o campo CNPJ/CPF.', false);

    // Digita só letras e números, tecla a tecla; a máscara do próprio site (keyup) põe a
    // pontuação a cada tecla, garantindo o formato que o site aceita.
    mostrarAviso(`Digitando ${doc.formatado}...`);
    const digitacao = await digitarHumanizado(campo, doc.normalizado);
    if (!digitacao.ok) throw new ErroEtapa(`Digitação interrompida: ${digitacao.motivo}.`, false);
    await dormir(CONFIG.TEMPOS.esperaMascara);

    // 5. Conferência.
    if (campo.value !== doc.formatado && CNPJ.normalizar(campo.value) === doc.normalizado) {
      log('A máscara do site não formatou; aplicando a mesma formatação.');
      escreverNoCampo(campo, doc.formatado);
      await dormir(CONFIG.TEMPOS.esperaMascara);
    }
    if (campo.value !== doc.formatado) {
      throw new ErroEtapa(`O campo ficou com "${campo.value}" em vez de "${doc.formatado}".`, false);
    }
    const max = Number(campo.getAttribute('maxlength')) || 0;
    if (max && campo.value.length > max) throw new ErroEtapa(`O valor passa do limite do campo (${max}).`, false);

    return { campo, doc };
  }

  // O que impede o envio agora (lista vazia = pode emitir).
  function problemasAntesDeEmitir(campoCnpj, doc, captcha) {
    const problemas = [];
    if (campoCnpj.value !== doc.formatado) problemas.push(`o CNPJ/CPF está "${campoCnpj.value}" (esperado ${doc.formatado})`);
    if (captcha.value.trim().length < CONFIG.CAPTCHA_PELO_USUARIO.minimoCaracteres) problemas.push('a verificação está vazia ou incompleta');
    const botao = botaoEmitir();
    if (!botao || !utilizavel(botao)) problemas.push('o botão "Emitir Certidão" não está disponível');
    if (document.querySelector(CONFIG.SELETORES.secaoSucesso + ':not(.oculto)')) problemas.push('a certidão já foi emitida nesta tela');
    return problemas;
  }

  // 8. Depois de "Certidão EMITIDA": espera o background confirmar o PDF salvo, inteiro, na
  // pasta da empresa. Só então a empresa conta como concluída.
  async function aguardarPdfSalvo(empresa) {
    mostrarAviso(`Certidão emitida. Salvando o PDF na pasta da empresa...\n${empresa.nome}`, 'info');
    const fim = Date.now() + CONFIG.FILA.limiteDownload;
    while (Date.now() < fim) {
      conferirParada();
      const s = await pedir('cndt:status-download', { cnpj: empresa.cnpj });
      if (s.ok && s.estado === 'ok') return { ok: true, final: s.final, tamanho: s.tamanho };
      if (s.ok && s.estado === 'erro') return { ok: false, detalhe: s.detalhe };
      await dormir(500);
    }
    return { ok: false, detalhe: `o PDF não chegou em ${Math.round(CONFIG.FILA.limiteDownload / 1000)} s (o download não começou ou não terminou)` };
  }

  // ETAPA 2: espera a pessoa digitar o captcha; quando ela para de digitar, confere a página,
  // leva o cursor até "Emitir Certidão" e clica (com uma janela curta em que digitar no captcha
  // ou apertar Esc cancela o clique). Depois lê a resposta do site e espera o PDF.
  // A automação não lê, não escreve e não envia o captcha a lugar nenhum: só percebe que a
  // pessoa digitou algo e parou. Cada envio depende de a pessoa ter digitado.
  // Devolve { estado: 'concluida' | 'erro' | 'pendente', detalhe, arquivo }.
  async function aguardarCaptchaEEmitir(campoCnpj, doc, captcha, empresa) {
    const P = CONFIG.CAPTCHA_PELO_USUARIO;

    // Prepara o salvamento antes de qualquer envio (vale também se a pessoa clicar ela mesma).
    const armado = await pedir('cndt:armar-download', { cnpj: empresa.cnpj });
    if (!armado.ok) return { estado: 'erro', detalhe: `não consegui preparar o salvamento do PDF (${armado.erro})` };

    let ultimaDigitacao = 0;
    let escPressionado = false;
    const aoDigitar = (e) => { if (e.isTrusted) ultimaDigitacao = Date.now(); };
    const aoTeclar = (e) => { if (e.isTrusted && e.key === 'Escape') escPressionado = true; };
    captcha.addEventListener('input', aoDigitar, true);
    document.addEventListener('keydown', aoTeclar, true);

    // Resposta do site a um envio (da automação ou da pessoa).
    let envios = 0;
    let instrucao = `${empresa.nome}\n${doc.formatado} preenchido. Digite os caracteres da imagem. Quando você parar de digitar, eu clico em "Emitir Certidão".`;
    async function tratarResposta(erroAntes) {
      envios++;
      mostrarAviso('Aguardando a resposta do site...', 'info');
      const res = await esperarResultadoDaEmissao(P.limiteResposta, erroAntes);
      conferirParada();
      if (res.tipo === 'sucesso') {
        log(`Certidão emitida: ${res.texto}`);
        const pdf = await aguardarPdfSalvo(empresa);
        return pdf.ok
          ? { estado: 'concluida', arquivo: pdf.final, detalhe: `${res.texto || 'Certidão emitida'} (${Math.round(pdf.tamanho / 1024)} KB)` }
          : { estado: 'erro', detalhe: `a certidão foi emitida, mas ${pdf.detalhe}` };
      }
      if (res.tipo === 'tempo') return { estado: 'erro', detalhe: `o site não respondeu em ${Math.round(P.limiteResposta / 1000)} s` };
      log(`O site respondeu com erro: ${res.mensagem}`);
      if (envios >= P.maxTentativas) return { estado: 'erro', detalhe: `o site respondeu "${res.mensagem}" (${envios} envios)` };
      captcha.focus({ preventScroll: true });
      await CURSOR.moverPara(captcha);
      instrucao = `O site respondeu: "${res.mensagem}".\nA imagem foi trocada: apague e digite a nova verificação (envio ${envios + 1} de ${P.maxTentativas}).`;
      return null; // espera nova digitação
    }

    try {
      let jaDigitando = false;
      for (;;) {
        conferirParada();
        mostrarAviso(instrucao, 'info');
        const espera = esperarDigitacaoDoUsuario(captcha, {
          silencio: P.silencioParaConcluir, minimo: P.minimoCaracteres, limite: P.limiteEspera, jaDigitando,
        });
        aoParar.push(espera.cancelar);
        const r = await espera.promessa;
        conferirParada();
        jaDigitando = false;
        if (!r.ok) {
          if (r.motivo === 'enviado') { // a pessoa clicou em Emitir ela mesma: acompanha a resposta
            const fim = await tratarResposta('');
            if (fim) return fim;
            continue;
          }
          return { estado: 'pendente', detalhe: `ninguém digitou a verificação em ${Math.round(P.limiteEspera / 60000)} min` };
        }

        let problemas = problemasAntesDeEmitir(campoCnpj, doc, captcha);
        if (problemas.length) {
          instrucao = `Não enviei: ${problemas.join('; ')}.\nCorrija e digite a verificação de novo.`;
          continue;
        }

        // Cursor até o botão e janela de cancelamento.
        const inicio = Date.now();
        escPressionado = false;
        const botao = botaoEmitir();
        await CURSOR.moverPara(botao);
        if (!P.clicarEmitir) {
          instrucao = `Pronto para emitir: ${doc.formatado}.\nConfira e clique em "Emitir Certidão".`;
          continue; // a pessoa clica; a espera acima percebe o envio ("enviado")
        }
        mostrarAviso(`Emitindo a certidão de ${empresa.nome}...\n(digite na verificação ou aperte Esc para cancelar)`, 'info');
        await dormir(P.janelaCancelamento);
        conferirParada();
        if (escPressionado) return { estado: 'pendente', detalhe: 'clique em "Emitir Certidão" cancelado com Esc' };
        if (ultimaDigitacao > inicio) {
          instrucao = 'Você voltou a digitar; espero você terminar.';
          jaDigitando = true;
          continue;
        }
        problemas = problemasAntesDeEmitir(campoCnpj, doc, captcha);
        if (problemas.length) {
          instrucao = `Não enviei: ${problemas.join('; ')}.\nCorrija e digite a verificação de novo.`;
          continue;
        }

        // Clique real no ponto da seta. Guarda o erro que já está na tela (envio anterior),
        // para não confundi-lo com a resposta deste envio.
        const erroAntes = estadoDoErro();
        const clique = await clicar(botao);
        if (!clique.ok) return { estado: 'erro', detalhe: `não cliquei em "Emitir Certidão": ${clique.motivo}` };
        log(`"Emitir Certidão" clicado (envio ${envios + 1} de ${P.maxTentativas}).`);
        const fim = await tratarResposta(erroAntes);
        if (fim) return fim;
      }
    } finally {
      captcha.removeEventListener('input', aoDigitar, true);
      document.removeEventListener('keydown', aoTeclar, true);
    }
  }

  async function executar() {
    // 0. Empresa da vez.
    const resp = await pedir('cndt:proximo');
    if (!resp.ok) { mostrarAviso(`Não consegui falar com a extensão: ${resp.erro}`, 'erro'); return; }
    if (resp.fim) {
      const r = resp.resumo || {};
      mostrarAviso(`Lista concluída: ${r.concluidas || 0} certidão(ões) salva(s), ${r.erros || 0} com erro.\nVeja os detalhes na janela da automação.`, r.erros ? 'info' : 'ok');
      return;
    }
    if (resp.pausada) { mostrarAviso('Automação pausada. Clique em Continuar na janela da automação.', 'info'); return; }
    if (resp.nada) { mostrarAviso(resp.nada, 'info'); return; }

    const empresa = resp.empresa;
    const chave = chaveRecargas(empresa.cnpj);
    log(`Empresa ${resp.posicao}/${resp.total}: ${empresa.formatado} - ${empresa.nome} (recargas: ${recargasFeitas(empresa.cnpj)}).`);
    let resultado;
    try {
      mostrarAviso(`Empresa ${resp.posicao} de ${resp.total}: ${empresa.nome}\n${empresa.formatado}`, 'info');
      const { campo, doc } = await preencherDocumento(empresa.formatado);
      sessionStorage.removeItem(chave);
      conferirParada();

      // 6. Cursor no campo do captcha (só foco, sem clique e sem digitar).
      const captcha = document.querySelector(CONFIG.SELETORES.campoCaptcha);
      if (!captcha || !utilizavel(captcha)) throw new ErroEtapa('O campo da verificação não está disponível.', true);
      await CURSOR.moverPara(captcha);
      captcha.focus({ preventScroll: true });
      if (!doc.ok) aviso(`Atenção: ${doc.motivo}.`);

      // 7 e 8. Verificação pela pessoa, emissão e PDF salvo.
      resultado = await aguardarCaptchaEEmitir(campo, doc, captcha, empresa);
    } catch (e) {
      if (e instanceof Parada || parado) {
        encerrarCursor();
        mostrarAviso(`Automação parada pela janela. ${empresa.nome} continua pendente.`, 'info');
        return;
      }
      const mensagem = e instanceof ErroEtapa ? e.message : `Erro inesperado: ${e && e.message}`;
      const recuperavel = e instanceof ErroEtapa ? e.recuperavel : true;
      console.error(CONFIG.PREFIXO_LOG, mensagem, e);
      if (recuperavel && recargasFeitas(empresa.cnpj) < CONFIG.MAX_RECARGAS) {
        const n = recargasFeitas(empresa.cnpj) + 1;
        sessionStorage.setItem(chave, String(n));
        pedir('cndt:log', { texto: `${empresa.nome}: ${mensagem} Recarregando (tentativa ${n} de ${CONFIG.MAX_RECARGAS}).`, tipo: 'erro' });
        mostrarAviso(`${mensagem}\nRecarregando a página (tentativa ${n} de ${CONFIG.MAX_RECARGAS})...`, 'erro');
        await dormir(1500);
        location.reload();
        return;
      }
      sessionStorage.removeItem(chave);
      resultado = e instanceof ErroEtapa && e.pausar
        ? { estado: 'pendente', detalhe: mensagem }
        : { estado: 'erro', detalhe: mensagem };
    }
    if (parado) { encerrarCursor(); mostrarAviso(`Automação parada pela janela. ${empresa.nome} continua pendente.`, 'info'); return; }

    // 9. Registra e segue.
    encerrarCursor();
    const r = await pedir('cndt:resultado', { cnpj: empresa.cnpj, ...resultado });
    if (resultado.estado === 'concluida') {
      mostrarAviso(`${empresa.nome}: certidão salva.\n${resultado.arquivo}`, 'ok');
    } else if (resultado.estado === 'erro') {
      mostrarAviso(`${empresa.nome}: ${resultado.detalhe}.\nRegistrado como erro${r.continuar ? '; seguindo para a próxima empresa' : ''}.`, 'erro');
    } else {
      mostrarAviso(`Pausei: ${resultado.detalhe}.\n${empresa.nome} continua pendente. Clique em Continuar na janela da automação.`, 'info');
    }
    // A próxima empresa é carregada pelo background.js (F5 feito pelo navegador; ver lá o motivo).
    // Se a lista acabou, não há F5: a página fica como está, com o resumo.
    if (r.ok && r.continuar) {
      log(`Resultado registrado; F5 para a próxima empresa (${r.proxima}).`);
      mostrarAviso(`${resultado.estado === 'concluida' ? `${empresa.nome}: certidão salva.` : `${empresa.nome}: registrado como erro.`}\nPróxima empresa: ${r.proxima}. Recarregando a página...`, resultado.estado === 'concluida' ? 'ok' : 'info');
    } else if (r.ok && r.fim) {
      const s = r.resumo || {};
      mostrarAviso(`${resultado.estado === 'concluida' ? `${empresa.nome}: certidão salva.\n` : ''}Lista concluída: ${s.concluidas || 0} certidão(ões) salva(s), ${s.erros || 0} com erro. Fim da automação.`, s.erros ? 'info' : 'ok');
    }
  }

  executar()
    .catch((e) => { console.error(CONFIG.PREFIXO_LOG, e); mostrarAviso(`Erro inesperado: ${e.message}`, 'erro'); })
    .finally(() => { globalThis.CNDT.executando = false; });
})();
