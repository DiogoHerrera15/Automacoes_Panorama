'use strict';
/* Painel da extensão (aba própria): configuração, lista de documentos, controles e acompanhamento em tempo real. */
const NS = globalThis.EFiscoCRF;
const K = { job: 'efisco_job', joblog: 'efisco_joblog', log: 'efisco_log', rascunho: 'efisco_rascunho', velMouse: NS.CONFIG.storage.velMouse, velDig: NS.CONFIG.storage.velDigitacao };
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

let job = null;          // estado da execução (vem do background via chrome.storage)
let ajustes = { tipos: {}, forcar: {} };  // correções do usuário na classificação
let itensPrevia = [];

const ROTULO_STATUS = { pendente: 'Pendente', processando: 'Em processamento', aguardando_entrega: 'Aguardando arquivo', concluido: 'Concluído', erro: 'Erro', interrompido: 'Interrompido' };
const TIPO_NOME = { CPF: 'CPF', CNPJ: 'CNPJ', IE: 'Inscrição Estadual' };
const ocupado = () => !!job && ['executando', 'pausado'].includes(job.estado);

// ───────────── modo anônimo ─────────────
function mostrarAvisoAnonimo(texto) {
  $('aviso-incognito').hidden = !texto;
  $('aviso-incognito-txt').textContent = texto || '';
}
async function checarAnonimo() {
  const r = await enviar({ tipo: 'INCOGNITO_STATUS' });
  mostrarAvisoAnonimo(r && r.permitido === false
    ? '🕶 A automação SEMPRE abre o e-Fisco em janela anônima, mas esta extensão ainda não tem permissão para rodar no modo anônimo. Em chrome://extensions → Detalhes → ative "Permitir no modo anônimo".' : '');
  return !r || r.permitido !== false;
}
$('btn-config').addEventListener('click', () => enviar({ tipo: 'ABRIR_CONFIG' }));

// ───────────── envio de comandos ─────────────
const enviar = (msg) => new Promise((resolve) => {
  try { chrome.runtime.sendMessage(msg, (r) => { void chrome.runtime.lastError; resolve(r || { ok: false, erro: 'a extensão não respondeu' }); }); }
  catch (e) { resolve({ ok: false, erro: String(e) }); }
});

// ───────────── formulário / pré-visualização ─────────────
function salvarRascunho() {
  chrome.storage.local.set({ [K.rascunho]: { pasta: $('pasta').value, docs: $('docs').value, ajustes } });
}

function chip(texto, classe = '') { return `<span class="chip ${classe}">${esc(texto)}</span>`; }

function situacao(it) {
  if (it.duplicado) return chip(`Duplicado de ${it.duplicadoDe}`, 'aviso');
  if (it.ambiguo) return chip('Tipo não identificado', 'aviso') + `<div class="dica">${esc(it.motivo)}</div>`;
  if (!it.valido) return chip('Inválido', 'erro') + `<div class="dica erro">${esc(it.motivo)}</div>`;
  return chip('Válido', 'ok') + (it.avisos.length ? `<div class="dica">${esc(it.avisos.join(' '))}</div>` : '');
}

function recalcular() {
  itensPrevia = NS.lista.processar($('docs').value, ajustes);
  const r = NS.lista.resumo(itensPrevia);
  $('resumo-lista').innerHTML = itensPrevia.length
    ? [chip(`${r.total} linha(s)`), r.CPF && chip(`CPF ${r.CPF}`, 'ok'), r.CNPJ && chip(`CNPJ ${r.CNPJ}`, 'ok'), r.IE && chip(`IE ${r.IE}`, 'ok'),
       r.ambiguos && chip(`${r.ambiguos} ambíguo(s)`, 'aviso'), r.invalidos && chip(`${r.invalidos} inválido(s)`, 'erro'),
       r.duplicados && chip(`${r.duplicados} duplicado(s)`, 'aviso'), chip(`${r.executaveis} para executar`, r.executaveis ? 'ok' : 'erro')].filter(Boolean).join('')
    : '';
  $('tabela-previa').hidden = !itensPrevia.length;
  $('previa').innerHTML = itensPrevia.map((it) => {
    const opcoes = ['', 'CPF', 'CNPJ', 'IE'].map((t) => `<option value="${t}" ${(ajustes.tipos[it.id] || (it.manual ? it.tipo : '')) === t ? 'selected' : ''}>${t ? TIPO_NOME[t] : (it.tipo && !it.manual ? `Automático (${it.tipo})` : 'Automático')}</option>`).join('');
    const forcar = (!it.valido && !it.ambiguo && !it.duplicado && it.tipo)
      ? `<label class="inline"><input type="checkbox" data-forcar="${it.id}" ${it.forcar ? 'checked' : ''}> processar mesmo assim</label>` : '';
    return `<tr class="${it.duplicado ? 'dup' : ''}"><td>${it.linha}</td><td class="mono">${esc(it.formatado || it.original)}${it.formatado && it.formatado !== it.original ? `<div class="quebra">${esc(it.original)}</div>` : ''}</td>` +
      `<td><select data-tipo="${it.id}" ${ocupado() ? 'disabled' : ''}>${opcoes}</select></td><td>${situacao(it)}</td><td>${forcar}</td></tr>`;
  }).join('');
  atualizarPastaDica();
  atualizarBotoes();
  salvarRascunho();
}

function atualizarPastaDica() {
  const bruto = $('pasta').value;
  const p = NS.arquivos.sanitizarNomePasta(bruto);
  const el = $('pasta-dica');
  if (!bruto.trim()) { el.className = 'dica'; el.textContent = 'Informe o nome da pasta onde as certidões serão salvas.'; return; }
  if (!p.nome) { el.className = 'dica erro'; el.textContent = 'Nome de pasta inválido.'; return; }
  el.className = 'dica' + (p.alterado ? '' : ' ok');
  el.textContent = `Os arquivos serão salvos em: Downloads/${p.nome}` + (p.alterado ? `  (ajustado para o sistema operacional: ${p.motivos.join('; ')})` : '');
}

// ───────────── início ─────────────
function mostrarErroForm(msg) { const el = $('msg-form'); el.hidden = !msg; el.textContent = msg || ''; }

async function iniciar() {
  mostrarErroForm('');
  if (ocupado()) return;
  const pasta = NS.arquivos.sanitizarNomePasta($('pasta').value);
  if (!pasta.nome) return mostrarErroForm('Informe um nome de pasta válido.');
  if (!itensPrevia.length) return mostrarErroForm('Informe ao menos um documento.');
  const r = NS.lista.resumo(itensPrevia);
  if (r.ambiguos) return mostrarErroForm(`Há ${r.ambiguos} documento(s) com tipo não identificado. Escolha o tipo na coluna "Tipo" (ou apague a linha) antes de iniciar.`);
  const fila = NS.lista.paraFila(itensPrevia);
  if (!fila.length) return mostrarErroForm('Nenhum documento válido para executar. Corrija a lista ou marque "processar mesmo assim".');
  if (r.invalidos && !confirm(`${r.invalidos} documento(s) inválido(s) NÃO serão processados. Continuar com os ${fila.length} restante(s)?`)) return;
  await chrome.storage.local.set({ [K.velMouse]: Number($('velMouse').value), [K.velDig]: Number($('velDigit').value) });
  const resp = await enviar({ tipo: 'JOB_INICIAR', pasta: pasta.nome, pastaOriginal: $('pasta').value, itens: fila });
  if (!resp.ok) {
    mostrarErroForm(resp.erro || 'Não foi possível iniciar.');
    if (resp.codigo === 'incognito-nao-permitido') mostrarAvisoAnonimo('🕶 ' + resp.erro);
  }
}

$('btn-iniciar-auto').addEventListener('click', iniciar);
$('btn-iniciar').addEventListener('click', iniciar);
$('btn-pausar').addEventListener('click', async () => {
  const r = await enviar({ tipo: job && job.estado === 'pausado' ? 'JOB_CONTINUAR' : 'JOB_PAUSAR' });
  if (r && r.ok === false && r.erro) { mostrarErroForm(r.erro); if (r.codigo === 'incognito-nao-permitido') mostrarAvisoAnonimo('🕶 ' + r.erro); }
});
$('btn-parar').addEventListener('click', async () => {
  if (confirm('Parar a automação? Os resultados já obtidos serão preservados.')) await enviar({ tipo: 'JOB_PARAR' });
});

$('pasta').addEventListener('input', recalcular);
$('docs').addEventListener('input', () => { ajustes = { tipos: {}, forcar: {} }; recalcular(); });
$('previa').addEventListener('change', (e) => {
  const t = e.target;
  if (t.dataset.tipo) { if (t.value) ajustes.tipos[t.dataset.tipo] = t.value; else delete ajustes.tipos[t.dataset.tipo]; recalcular(); }
  if (t.dataset.forcar) { ajustes.forcar[t.dataset.forcar] = t.checked; recalcular(); }
});
['velMouse', 'velDigit'].forEach((id) => $(id).addEventListener('change', () => chrome.storage.local.set({ [K.velMouse]: Number($('velMouse').value), [K.velDig]: Number($('velDigit').value) })));
$('ver-detalhes').addEventListener('change', carregarHistorico);

// ───────────── acompanhamento ─────────────
function atualizarBotoes() {
  const emCurso = ocupado();
  $('btn-iniciar-auto').disabled = emCurso;
  $('btn-iniciar').disabled = emCurso;
  $('btn-pausar').disabled = !emCurso;
  $('btn-parar').disabled = !emCurso;
  $('btn-pausar').textContent = job && job.estado === 'pausado' ? '▶ CONTINUAR' : '⏸ PAUSAR';
  ['pasta', 'docs', 'velMouse', 'velDigit'].forEach((id) => { $(id).disabled = emCurso; });
  document.querySelectorAll('#previa select, #previa input').forEach((e) => { e.disabled = emCurso; });
}

function desenharJob() {
  const itens = job ? job.itens : [];
  const c = (s) => itens.filter((i) => i.status === s).length;
  const feitos = c('concluido') + c('erro');
  $('n-total').textContent = itens.length;
  $('n-ok').textContent = c('concluido');
  $('n-erro').textContent = c('erro');
  $('n-pend').textContent = c('pendente') + c('interrompido');
  $('barra-prog').style.width = itens.length ? `${Math.round((feitos / itens.length) * 100)}%` : '0%';

  const est = job ? job.estado : 'parado';
  const pil = $('estado');
  pil.className = `pilula ${est}`;
  pil.textContent = { executando: 'Executando', pausado: 'Pausado', parado: 'Parado', concluido: 'Concluído' }[est] || est;
  const aviso = $('aviso-pausa');
  const humano = itens.find((i) => i.humano);
  aviso.hidden = !(est === 'pausado' || humano);
  aviso.textContent = est === 'pausado' ? `⏸ ${job.motivoPausa || 'Execução pausada.'}` : humano ? `✋ Ação humana necessária: ${humano.humano}` : '';

  const atual = job && job.atual && itens.find((i) => i.id === job.atual);
  $('agora-doc').textContent = atual ? `${TIPO_NOME[atual.tipo]} · ${atual.formatado}` : (est === 'concluido' ? 'Fila concluída' : '—');
  $('agora-etapa').textContent = atual ? `${atual.etapa || ''} · tentativa ${atual.tentativas}` : '';

  $('itens').innerHTML = itens.length ? itens.map((i, n) =>
    `<tr class="${i.status === 'interrompido' ? 'ign' : ''}"><td>${n + 1}</td><td class="mono">${esc(i.formatado)}</td><td>${esc(i.tipo)}</td>` +
    `<td>${chip(ROTULO_STATUS[i.status] || i.status, { concluido: 'ok', erro: 'erro', processando: '', aguardando_entrega: '', pendente: 'aviso', interrompido: 'aviso' }[i.status] || '')}</td>` +
    `<td>${i.arquivo ? `<div class="quebra">${esc(i.arquivo)}</div>${i.validacao ? `<div class="dica ok">validado: ${esc(i.validacao)}</div>` : ''}` : esc(i.erro || (i.status === 'pendente' ? '' : i.etapa || ''))}</td></tr>`).join('')
    : '<tr><td colspan="5" class="vazio">Nenhuma execução ainda.</td></tr>';

  $('destino-info').textContent = job
    ? `Pasta de destino: Downloads/${job.pasta} — o Chrome só permite gravar dentro da pasta Downloads. Se a pasta já existir, ela é reutilizada e nenhum arquivo é sobrescrito (nomes repetidos recebem "(1)", "(2)"...).`
    : 'O Chrome só permite gravar arquivos dentro da pasta Downloads: a pasta informada será criada ali (ou reutilizada, sem sobrescrever nada).';
  atualizarBotoes();
}

async function carregarHistorico() {
  const d = await chrome.storage.local.get([K.joblog, K.log]);
  const detalhes = $('ver-detalhes').checked;
  const linhas = detalhes ? (d[K.log] || []).map((l) => ({ t: l.t, nivel: l.nivel, msg: l.msg })) : (d[K.joblog] || []).map((l) => ({ t: new Date(l.t).toLocaleTimeString('pt-BR', { hour12: false }), nivel: l.nivel, msg: l.msg }));
  const el = $('historico');
  const noFim = el.scrollTop + el.clientHeight >= el.scrollHeight - 30;
  el.innerHTML = linhas.map((l) => `<div class="${l.nivel}"><span class="h">${esc(l.t)}</span>${esc(l.msg)}</div>`).join('');
  if (noFim) el.scrollTop = el.scrollHeight;
}

chrome.storage.onChanged.addListener((mud, area) => {
  if (area !== 'local') return;
  if (mud[K.job]) { job = mud[K.job].newValue || null; desenharJob(); recalcular(); }
  if (mud[K.joblog] || mud[K.log]) carregarHistorico();
});

(async function iniciarPainel() {
  const d = await chrome.storage.local.get([K.job, K.rascunho, K.velMouse, K.velDig]);
  job = d[K.job] || null;
  const r = d[K.rascunho];
  if (r) { $('pasta').value = r.pasta || ''; $('docs').value = r.docs || ''; ajustes = r.ajustes || ajustes; }
  if (d[K.velMouse]) $('velMouse').value = String(d[K.velMouse]);
  if (d[K.velDig]) $('velDigit').value = String(d[K.velDig]);
  recalcular(); desenharJob(); carregarHistorico(); checarAnonimo();
})();
