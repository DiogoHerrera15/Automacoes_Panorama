@echo off
rem ============================================================================
rem  Automacao PGFN - INICIAR
rem  Processa os CNPJs de cnpjs.json, um por vez (e-CAC -> Regularize -> SISPAR),
rem  salvando tudo em Documentos_arrecadacao\<CNPJ>. Funciona sozinho: nao precisa
rem  do Claude nem de nenhum outro programa aberto alem do Chrome.
rem
rem  ATENCAO: fecha TODAS as janelas do Chrome a cada CNPJ.
rem  Para PARAR: feche a janela do Chrome (o CNPJ da vez volta a "pendente") ou esta janela.
rem  Para ver a situacao de cada CNPJ a qualquer momento: VER_ANDAMENTO.bat
rem ============================================================================
chcp 65001 >nul
title Automação PGFN
cd /d "%~dp0"
echo.
echo  Automação PGFN
echo  - Resolva o captcha quando aparecer; a automação continua sozinha depois.
echo  - Não mexa no mouse enquanto o certificado é escolhido.
echo  - Para parar: feche o Chrome (ou esta janela).
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0orquestrador\orquestrador.ps1" %*
echo.
echo  Registro completo: orquestrador\orquestrador.log
pause
