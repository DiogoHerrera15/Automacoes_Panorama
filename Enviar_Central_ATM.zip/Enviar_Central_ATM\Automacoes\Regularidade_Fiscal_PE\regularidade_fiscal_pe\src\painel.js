/* Painel de status discreto no canto inferior direito da página (registro visível). */
(function () {
  'use strict';
  const NS = (window.EFiscoCRF = window.EFiscoCRF || {});

  let raiz = null;
  let elLinhas = null;
  let ouvindo = false;

  const CSS = `
    .box { position: fixed; right: 14px; bottom: 14px; width: 340px; max-height: 230px; z-index: 2147483640;
      font: 12px/1.35 -apple-system, "Segoe UI", Arial, sans-serif; color: #1c2541; background: #fff;
      border: 1px solid #b8c2d6; border-radius: 8px; box-shadow: 0 4px 16px rgba(0,0,0,.18); overflow: hidden; }
    .tit { padding: 6px 10px; font-weight: 700; background: #5b2a86; color: #fff; display: flex; justify-content: space-between; }
    .tit button { all: unset; cursor: pointer; opacity: .8; }
    .linhas { padding: 6px 10px; overflow: auto; max-height: 180px; }
    .l { margin: 1px 0; } .l .h { color: #7a869a; margin-right: 6px; }
    .info { color: #1c2541; } .ok { color: #137333; font-weight: 600; } .aviso { color: #b06000; } .erro { color: #c5221f; font-weight: 600; }
  `;

  function montar() {
    if (raiz && raiz.host.isConnected) return;
    const host = document.createElement('div');
    host.id = 'efisco-painel-host';
    raiz = host.attachShadow({ mode: 'open' });
    raiz.innerHTML = `<style>${CSS}</style>
      <div class="box"><div class="tit"><span>e-Fisco PE · Certidões</span><button title="Fechar painel">✕</button></div>
      <div class="linhas"></div></div>`;
    (document.body || document.documentElement).appendChild(host);
    elLinhas = raiz.querySelector('.linhas');
    raiz.querySelector('button').addEventListener('click', () => host.remove());
  }

  function adicionar(linha) {
    montar();
    const d = document.createElement('div');
    d.className = 'l ' + linha.nivel;
    const h = document.createElement('span');
    h.className = 'h';
    h.textContent = linha.t;
    d.append(h, document.createTextNode(linha.msg));
    elLinhas.appendChild(d);
    while (elLinhas.childElementCount > 500) elLinhas.firstElementChild.remove();
    elLinhas.scrollTop = elLinhas.scrollHeight;
  }

  NS.painel = {
    iniciar() {
      montar();
      if (!ouvindo) { ouvindo = true; NS.log.aoRegistrar(adicionar); }
    },
    remover() { const h = document.getElementById('efisco-painel-host'); if (h) h.remove(); }
  };
})();
