# Executa a automacao RFB no Windows (equivalente ao iniciar.sh do Mac): le lista_cnpjs.txt, emite as
# certidoes da Receita, refaz uma vez as que deram erro e organiza tudo em resultado\<CNPJ>\.
# Dois cliques em iniciar.cmd, ou no PowerShell, dentro desta pasta:
#   .\iniciar.cmd                lote completo (continua de onde parou, sem baixar nada em duplicidade)
#   .\iniciar.cmd --teste        so 2 empresas, para conferir que esta tudo funcionando
#   .\iniciar.cmd --verificar    so confere a lista (nao abre o site)
#   .\iniciar.cmd --organizar    so reorganiza o que ja foi emitido (nao abre o site)
#   .\iniciar.cmd --novo-lote    guarda o lote atual em lotes_anteriores\ para comecar uma lista nova
# Parar: digite s e Enter (o que ja foi emitido fica salvo).
# Variaveis opcionais (antes do comando, no PowerShell): $env:LIMITE=n  $env:PAUSA_SEGUNDOS=n (padrao 15)
#   $env:TEMPO_MAX_EMPRESA_MIN=n (padrao 5)  $env:PASTA_SAIDA='D:\outra\pasta'
# Sem bloco param: assim "--teste" chega como texto (o PowerShell trataria "-..." como nome de parametro).
$Opcao = if ($args.Count) { [string]$args[0] } else { '' }

Set-Location -LiteralPath $PSScriptRoot
if (-not $env:TEMPO_MAX_EMPRESA_MIN) { $env:TEMPO_MAX_EMPRESA_MIN = '5' }   # minutos por tentativa
# Python escreve nomes com acento em UTF-8; a janela tambem mostra UTF-8.
$env:PYTHONUTF8 = '1'; $env:PYTHONIOENCODING = 'utf-8'
try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch {}

$PY = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
if (-not (Test-Path -LiteralPath $PY)) { $PY = 'python' }

switch ($Opcao) {
  { $_ -in '-h', '--ajuda', '--help' } { Get-Content -LiteralPath $PSCommandPath -TotalCount 12 | Select-Object -Skip 1 | ForEach-Object { $_ -replace '^# ?', '' }; exit 0 }
  '--novo-lote' {
    $destino = 'lotes_anteriores\' + (Get-Date -Format 'yyyy-MM-dd_HHmm')
    Write-Host "Isto guarda o lote atual em $destino\ (nada e apagado) e deixa a pasta pronta para uma lista nova."
    $r = Read-Host 'Continuar? (s/N)'
    if ($r -notmatch '^[sS]$') { Write-Host 'Cancelado.'; exit 0 }
    New-Item -ItemType Directory -Force -Path $destino | Out-Null
    foreach ($item in 'Controle.json', 'Relatorio.csv', 'empresas.csv', 'certidoes', 'resultado', 'lista_cnpjs.txt') {
      if (Test-Path -LiteralPath $item) { Move-Item -LiteralPath $item -Destination $destino }
    }
    Write-Host 'Pronto. Coloque a nova lista em lista_cnpjs.txt e rode: iniciar.cmd'
    exit 0
  }
}

Write-Host 'Automacao RFB - certidoes da Receita Federal'
if (-not (Get-Command node -ErrorAction SilentlyContinue)) { Write-Host 'Node.js nao encontrado. Rode primeiro: instalar.cmd'; exit 1 }
if (-not (Test-Path node_modules)) { Write-Host 'Dependencias nao instaladas. Rode primeiro: instalar.cmd'; exit 1 }
& $PY -c 'import PIL, openpyxl' *> $null
if ($LASTEXITCODE -ne 0) { Write-Host 'Falta Pillow/openpyxl. Rode primeiro: instalar.cmd'; exit 1 }
if (-not (Test-Path lista_cnpjs.txt)) { Write-Host 'Nao achei lista_cnpjs.txt nesta pasta. Veja lista_cnpjs.exemplo.txt e o README.'; exit 1 }

Write-Host ''; Write-Host '1/4 Lendo a lista e criando as pastas...'
& $PY ferramentas\lote.py preparar
if ($LASTEXITCODE -ne 0) { exit 1 }

switch ($Opcao) {
  '--verificar' { & node certidao-rfb.js --verificar; exit $LASTEXITCODE }
  '--organizar' { & $PY ferramentas\lote.py organizar; exit $LASTEXITCODE }
  '--teste' { if (-not $env:LIMITE) { $env:LIMITE = '2' }; Write-Host ''; Write-Host "MODO TESTE: so $env:LIMITE empresas." }
  '' { }
  default { Write-Host "Opcao desconhecida: $Opcao (veja: iniciar.cmd --ajuda)"; exit 1 }
}

Write-Host ''; Write-Host '2/4 Emitindo as certidoes (em cada aba o CNPJ entra sozinho; para parar: s e Enter)...'
& node certidao-rfb.js
$codigo = $LASTEXITCODE
if ($codigo -ne 0) {
  Write-Host ''; Write-Host "Execucao interrompida (codigo $codigo). Organizando o que ja foi feito..."
  & $PY ferramentas\lote.py organizar
  Write-Host 'Rode  iniciar.cmd  de novo para continuar.'
  exit $codigo
}

$erros = [int](& $PY ferramentas\lote.py contar-puladas)
if ($erros -gt 0) {
  Write-Host ''; Write-Host "3/4 $erros empresa(s) com erro: tentando de novo uma vez..."
  & node certidao-rfb.js --refazer-puladas
} else {
  Write-Host ''; Write-Host '3/4 Nenhum erro para refazer.'
}

Write-Host ''; Write-Host '4/4 Organizando os arquivos...'
& $PY ferramentas\lote.py organizar
$resultado = if ($env:PASTA_SAIDA) { $env:PASTA_SAIDA } else { Join-Path $PSScriptRoot 'resultado' }
Write-Host ''; Write-Host "Pronto. Resultado em: $resultado  (planilha Controle_Certidoes.xlsx dentro)"
exit 0
