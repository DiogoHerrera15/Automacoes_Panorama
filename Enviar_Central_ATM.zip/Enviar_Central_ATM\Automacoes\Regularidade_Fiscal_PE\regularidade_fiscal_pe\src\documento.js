/*
 * Documentos de identificação (CPF, CNPJ, Inscrição Estadual de PE): normalização, classificação e validação.
 * Funções puras (sem DOM), usadas no painel, no background e nos content scripts.
 *
 * Importante: IDENTIFICAR o tipo é diferente de VALIDAR o número.
 *  - tipo: decidido pelo tamanho/máscara (e nunca "por exclusão");
 *  - validade: dígitos verificadores, quando o algoritmo é conhecido.
 */
(function () {
  'use strict';
  const NS = (window.EFiscoCRF = window.EFiscoCRF || {});

  const soDigitos = (s) => String(s == null ? '' : s).replace(/\D+/g, '');
  const TIPOS = ['CPF', 'CNPJ', 'IE'];
  const ROTULO = { CPF: 'CPF', CNPJ: 'CNPJ', IE: 'INSCRIÇÃO ESTADUAL' };

  // ───────────── CNPJ ─────────────
  function validarCnpj(digitos) {
    const d = soDigitos(digitos);
    if (d.length !== 14 || /^(\d)\1{13}$/.test(d)) return false;
    const calc = (base) => {
      let soma = 0;
      let peso = base.length - 7;
      for (let i = 0; i < base.length; i++) {
        soma += Number(base[i]) * peso--;
        if (peso < 2) peso = 9;
      }
      const r = soma % 11;
      return r < 2 ? 0 : 11 - r;
    };
    const d1 = calc(d.slice(0, 12));
    const d2 = calc(d.slice(0, 12) + d1);
    return d1 === Number(d[12]) && d2 === Number(d[13]);
  }
  const formatarCnpj = (d) => soDigitos(d).replace(/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})$/, '$1.$2.$3/$4-$5');

  // ───────────── CPF ─────────────
  function validarCpf(digitos) {
    const d = soDigitos(digitos);
    if (d.length !== 11 || /^(\d)\1{10}$/.test(d)) return false;
    const dv = (n) => {
      let soma = 0;
      for (let i = 0; i < n; i++) soma += Number(d[i]) * (n + 1 - i);
      const r = (soma * 10) % 11;
      return r === 10 ? 0 : r;
    };
    return dv(9) === Number(d[9]) && dv(10) === Number(d[10]);
  }
  const formatarCpf = (d) => soDigitos(d).replace(/^(\d{3})(\d{3})(\d{3})(\d{2})$/, '$1.$2.$3-$4');

  // ───────────── Inscrição Estadual de Pernambuco ─────────────
  // Formato atual (e-Fisco): 9 dígitos NNNNNNN-DD. DV1: pesos 8..2 sobre os 7 primeiros; DV2: pesos 9..2 sobre os 8 primeiros.
  // Resto 0 ou 1 → DV 0; senão 11 − resto. (Conferido com a IE 0321418-40.)
  function validarIE9(digitos) {
    const d = soDigitos(digitos);
    if (d.length !== 9) return false;
    const dv = (base, pesoInicial) => {
      let soma = 0;
      for (let i = 0; i < base.length; i++) soma += Number(base[i]) * (pesoInicial - i);
      const r = soma % 11;
      return r < 2 ? 0 : 11 - r;
    };
    const d1 = dv(d.slice(0, 7), 8);
    const d2 = dv(d.slice(0, 7) + d1, 9);
    return d1 === Number(d[7]) && d2 === Number(d[8]);
  }
  /** Formato antigo, com máscara AA.B.CCC.NNNNNNN-D (14 dígitos). O DV do formato antigo NÃO é verificado aqui. */
  const MASCARA_IE_ANTIGA = /^\d{2}\.\d\.\d{3}\.\d{7}-\d$/;
  function formatarIE(d) {
    const x = soDigitos(d);
    if (x.length === 9) return x.replace(/^(\d{7})(\d{2})$/, '$1-$2');
    if (x.length === 14) return x.replace(/^(\d{2})(\d)(\d{3})(\d{7})(\d)$/, '$1.$2.$3.$4-$5');
    return x;
  }

  const FORMATAR = { CPF: formatarCpf, CNPJ: formatarCnpj, IE: formatarIE };

  /** Valida o número para um tipo já definido. @returns {{valido:boolean|null, erro?:string, aviso?:string}} */
  function validarComoTipo(tipo, d) {
    if (tipo === 'CPF') {
      if (d.length !== 11) return { valido: false, erro: `CPF deve ter 11 dígitos (tem ${d.length})` };
      return validarCpf(d) ? { valido: true } : { valido: false, erro: 'dígitos verificadores do CPF não conferem' };
    }
    if (tipo === 'CNPJ') {
      if (d.length !== 14) return { valido: false, erro: `CNPJ deve ter 14 dígitos (tem ${d.length})` };
      return validarCnpj(d) ? { valido: true } : { valido: false, erro: 'dígitos verificadores do CNPJ não conferem' };
    }
    if (tipo === 'IE') {
      if (d.length === 9) return validarIE9(d) ? { valido: true } : { valido: false, erro: 'dígito verificador da IE (9 dígitos) não confere' };
      if (d.length === 14) return { valido: true, aviso: 'IE no formato antigo (14 dígitos): dígito verificador não verificado' };
      return { valido: false, erro: `IE de PE tem 9 dígitos (ou 14 no formato antigo); informado: ${d.length}` };
    }
    return { valido: false, erro: 'tipo desconhecido' };
  }

  /**
   * Normaliza e classifica uma entrada.
   * @param {string} entrada   texto do documento, com ou sem pontuação
   * @param {string} [tipoManual]  'CPF' | 'CNPJ' | 'IE' (substitui a identificação automática)
   * @returns {{original,digitos,tipo,formatado,valido,ambiguo,motivo,avisos}}
   *   tipo=null  ⇒ não identificado com segurança (ambiguo=true: pedir o tipo ao usuário)
   *   valido=false ⇒ formato/dígitos inválidos (não é executado, salvo se o usuário forçar)
   */
  function classificar(entrada, tipoManual) {
    const original = String(entrada == null ? '' : entrada).trim().replace(/\s+/g, ' ');
    const base = { original, digitos: '', tipo: null, formatado: '', valido: false, ambiguo: false, motivo: '', avisos: [] };
    if (!original) return { ...base, motivo: 'vazio' };
    if (/[^\d.\-/\s]/.test(original)) return { ...base, motivo: 'contém caracteres que não são dígitos nem pontuação (. - /)' };
    const d = soDigitos(original);
    if (!d) return { ...base, motivo: 'sem dígitos' };
    base.digitos = d;

    let tipo = TIPOS.includes(tipoManual) ? tipoManual : null;
    let manual = !!tipo;
    if (!tipo) {
      if (d.length === 11) tipo = 'CPF';
      else if (d.length === 9) tipo = 'IE';
      else if (d.length === 14) {
        if (validarCnpj(d)) tipo = 'CNPJ';
        else if (MASCARA_IE_ANTIGA.test(original)) tipo = 'IE';
        else return { ...base, ambiguo: true, motivo: '14 dígitos que não formam um CNPJ válido: pode ser erro de digitação ou uma IE antiga. Escolha o tipo.' };
      } else {
        return { ...base, ambiguo: true, motivo: `${d.length} dígitos: não corresponde a CPF (11), CNPJ (14) nem IE (9). Escolha o tipo.` };
      }
    }
    const v = validarComoTipo(tipo, d);
    return {
      ...base, tipo, manual, formatado: (FORMATAR[tipo] || ((x) => x))(d), valido: !!v.valido,
      motivo: v.erro || '', avisos: v.aviso ? [v.aviso] : []
    };
  }

  /** Compatibilidade (Fase 1/2): analisa um CNPJ. */
  function analisar(bruto) {
    const c = classificar(bruto, 'CNPJ');
    if (!c.valido) return { ok: false, erro: `CNPJ inválido: "${c.original}" — ${c.motivo || 'formato inválido'}.` };
    return { ok: true, original: c.original, digitos: c.digitos, formatado: c.formatado };
  }

  NS.documento = { soDigitos, TIPOS, ROTULO, validarCnpj, formatarCnpj, validarCpf, formatarCpf, validarIE9, formatarIE, classificar, analisar };
})();
