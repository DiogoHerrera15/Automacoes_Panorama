/*
 * Cursor visual + réplica visual do dropdown.
 *
 * IMPORTANTE (honestidade técnica): o <select> do portal é nativo, e o popup nativo de
 * um <select> é desenhado pelo Chrome fora do DOM — scripts não conseguem abri-lo nem
 * clicar nas opções dele. Por isso:
 *   - o cursor vai até o <select> real (posição calculada pelo DOM, não por coordenadas fixas);
 *   - uma lista visual (réplica das opções reais lidas do <select>) é exibida para
 *     demonstrar a abertura e a escolha;
 *   - a seleção EFETIVA é feita no próprio <select> (selectedIndex + eventos input/change),
 *     e depois verificada lendo o estado real do elemento.
 * Ou seja: o visual acompanha a ação real, mas a ação real é a alteração do elemento.
 */
(function () {
  'use strict';
  const NS = (window.EFiscoCRF = window.EFiscoCRF || {});
  const { dormir } = NS.wait;

  let host = null;
  let raiz = null;
  let elCursor = null;
  let elDropdown = null;
  let pos = null; // {x, y} em coordenadas da viewport

  const CSS = `
    :host { all: initial; }
    .cursor {
      position: fixed; left: 0; top: 0; width: 28px; height: 28px; z-index: 2147483647;
      pointer-events: none; will-change: transform; transform: translate(-100px,-100px);
      filter: drop-shadow(0 2px 3px rgba(0,0,0,.45));
      transition: opacity .2s;
    }
    .cursor svg { width: 100%; height: 100%; transform-origin: 4px 3px; transition: transform .08s; }
    .cursor.pressionado svg { transform: scale(.82); }
    .ripple {
      position: fixed; z-index: 2147483646; pointer-events: none; width: 10px; height: 10px;
      margin: -5px 0 0 -5px; border-radius: 50%; border: 2px solid #0a7ae0;
      animation: ripple .55s ease-out forwards;
    }
    @keyframes ripple { from { opacity:.9; transform: scale(.6);} to { opacity:0; transform: scale(4.2);} }
    .dropdown {
      position: fixed; z-index: 2147483645; box-sizing: border-box; padding: 6px 0; border-radius: 10px;
      background: rgba(58,58,60,.96); color: #fff; font: 15px/1.2 -apple-system, "Segoe UI", Arial, sans-serif;
      box-shadow: 0 8px 28px rgba(0,0,0,.4); border: 1px solid rgba(255,255,255,.12);
      pointer-events: none; opacity: 0; transform: translateY(-4px);
      transition: opacity .12s, transform .12s;
      overflow-y: auto; overscroll-behavior: contain; scrollbar-width: none;
    }
    .dropdown::-webkit-scrollbar { display: none; }
    .dropdown.aberto { opacity: 1; transform: none; }
    .item { display: flex; align-items: center; height: 28px; padding: 0 14px 0 8px; white-space: nowrap; }
    .item .ck { width: 18px; font-size: 13px; }
    .item.hover { background: #0a64d8; border-radius: 5px; margin: 0 5px; padding: 0 9px 0 3px; }
  `;

  function garantirUI() {
    if (host && host.isConnected) return;
    host = document.createElement('div');
    host.id = 'efisco-cursor-host';
    host.style.cssText = 'all:initial;position:fixed;left:0;top:0;width:0;height:0;z-index:2147483647;';
    raiz = host.attachShadow({ mode: 'open' });
    raiz.innerHTML = `
      <style>${CSS}</style>
      <div class="cursor" style="opacity:0">
        <svg viewBox="0 0 24 24"><path d="M4 2 L4 19 L8.6 14.9 L11.7 21.8 L14.6 20.5 L11.5 13.7 L17.8 13.4 Z"
          fill="#111" stroke="#fff" stroke-width="1.6" stroke-linejoin="round"/></svg>
      </div>
      <div class="dropdown"></div>`;
    (document.body || document.documentElement).appendChild(host);
    elCursor = raiz.querySelector('.cursor');
    elDropdown = raiz.querySelector('.dropdown');
  }

  function aplicarPos() {
    // A ponta da seta está em (4,3) dentro do SVG de 28px.
    elCursor.style.transform = `translate(${pos.x - 4}px, ${pos.y - 3}px)`;
  }

  const aleatorio = (min, max) => min + Math.random() * (max - min);

  /** Aceleração e desaceleração suaves (curva "minimum jerk"), típica de movimentos humanos. */
  const suavizar = (t) => t * t * t * (t * (6 * t - 15) + 10);

  /** Ponto dentro do elemento; (fx, fy) são frações da largura/altura. */
  function pontoDe(el, fx, fy) {
    const r = el.getBoundingClientRect();
    return { x: r.left + r.width * fx, y: r.top + r.height * fy };
  }

  /** Bézier cúbica. */
  function bezier(p0, p1, p2, p3, t) {
    const u = 1 - t;
    return {
      x: u * u * u * p0.x + 3 * u * u * t * p1.x + 3 * u * t * t * p2.x + t * t * t * p3.x,
      y: u * u * u * p0.y + 3 * u * u * t * p1.y + 3 * u * t * t * p2.y + t * t * t * p3.y
    };
  }

  /**
   * Anima o cursor da posição atual até `obter()` (reavaliado a cada quadro).
   * Trajetória curva, velocidade variável e tremor leve que some ao chegar.
   */
  function animar(obter, dur, curvatura) {
    return new Promise((resolve) => {
      const ini = { ...pos };
      const f0 = obter();
      const dist = Math.hypot(f0.x - ini.x, f0.y - ini.y) || 1;
      const nx = -(f0.y - ini.y) / dist; // normal à reta ini→fim
      const ny = (f0.x - ini.x) / dist;
      const lado = Math.random() < 0.5 ? -1 : 1;
      const c1 = aleatorio(0.1, 0.5) * curvatura * lado;
      const c2 = aleatorio(-0.3, 0.4) * curvatura * lado;
      const fase = [aleatorio(0, 6.28), aleatorio(0, 6.28)];
      const t0 = performance.now();
      let encerrado = false;
      const concluir = () => {
        if (encerrado) return;
        encerrado = true;
        pos = obter();
        aplicarPos();
        resolve();
      };
      // Rede de segurança: aba em segundo plano (rAF pausado) não trava a automação.
      setTimeout(concluir, dur + 1000);
      (function quadro(agora) {
        if (encerrado) return;
        if (document.hidden) return concluir();
        const t = Math.min(1, (agora - t0) / dur);
        const e = suavizar(t);
        const fim = obter();
        const p1 = { x: ini.x + (fim.x - ini.x) * 0.3 + nx * c1, y: ini.y + (fim.y - ini.y) * 0.3 + ny * c1 };
        const p2 = { x: ini.x + (fim.x - ini.x) * 0.75 + nx * c2, y: ini.y + (fim.y - ini.y) * 0.75 + ny * c2 };
        const p = bezier(ini, p1, p2, fim, e);
        const amp = NS.CONFIG.cursor.tremor * Math.sin(Math.PI * t); // tremor some no início/fim
        pos = {
          x: p.x + Math.sin(agora / 37 + fase[0]) * amp,
          y: p.y + Math.sin(agora / 43 + fase[1]) * amp
        };
        aplicarPos();
        if (t < 1) requestAnimationFrame(quadro);
        else concluir();
      })(t0);
    });
  }

  /**
   * Move o cursor até um destino. `alvo` é um Element ou uma função () => {x,y}.
   * Em elementos, o ponto exato varia um pouco a cada movimento (nunca o centro matemático).
   * Duração proporcional à distância e ao tamanho do alvo (lei de Fitts), com variação aleatória.
   * Em trajetos longos, às vezes passa um pouco do alvo e corrige.
   */
  async function moverPara(alvo) {
    garantirUI();
    let obter;
    let larguraAlvo = 40;
    if (typeof alvo === 'function') {
      obter = alvo;
    } else {
      const r0 = alvo.getBoundingClientRect();
      if (r0.top < 40 || r0.bottom > innerHeight - 40) {
        alvo.scrollIntoView({ block: 'center', behavior: 'instant' });
        await dormir(60);
      }
      const fx = aleatorio(0.3, 0.7);
      const fy = aleatorio(0.35, 0.65);
      larguraAlvo = Math.max(20, Math.min(r0.width, r0.height * 2));
      obter = () => pontoDe(alvo, fx, fy);
    }
    elCursor.style.opacity = '1';
    const fim0 = obter();
    if (!pos) {
      pos = { x: Math.max(40, fim0.x - aleatorio(180, 320)), y: Math.max(40, fim0.y - aleatorio(100, 220)) };
      aplicarPos();
    }
    const { duracaoMin, duracaoMax, fatorVelocidade, overshoot } = NS.CONFIG.cursor;
    const dist = Math.hypot(fim0.x - pos.x, fim0.y - pos.y);
    const fitts = 380 + 190 * Math.log2(1 + dist / larguraAlvo);
    const vel = NS.CONFIG.velocidade.mouse;
    const dur = Math.max(duracaoMin * vel, Math.min(duracaoMax * vel, fitts * fatorVelocidade * vel * aleatorio(0.9, 1.18)));
    const curvatura = Math.min(90, dist * 0.18);

    if (dist > 220 && Math.random() < overshoot) {
      const dx = (fim0.x - pos.x) / dist;
      const dy = (fim0.y - pos.y) / dist;
      const passa = aleatorio(8, 18);
      await animar(() => { const f = obter(); return { x: f.x + dx * passa, y: f.y + dy * passa }; }, dur * 0.88, curvatura);
      await dormir(aleatorio(40, 110));
      await animar(obter, aleatorio(150, 260), 4);
    } else {
      await animar(obter, dur, curvatura);
    }
  }

  async function clicar() {
    garantirUI();
    await dormir(aleatorio(NS.CONFIG.cursor.pausaAntesClique * 0.6, NS.CONFIG.cursor.pausaAntesClique * 1.5));
    elCursor.classList.add('pressionado');
    const rip = document.createElement('div');
    rip.className = 'ripple';
    rip.style.left = pos.x + 'px';
    rip.style.top = pos.y + 'px';
    raiz.appendChild(rip);
    setTimeout(() => rip.remove(), 650);
    await dormir(aleatorio(80, 140));
    elCursor.classList.remove('pressionado');
    await dormir(aleatorio(NS.CONFIG.cursor.pausaDepoisClique * 0.7, NS.CONFIG.cursor.pausaDepoisClique * 1.4));
  }

  /**
   * Exibe a réplica visual do dropdown abaixo do <select>, com as opções REAIS dele.
   * @returns {{itens: Array<{indice:number,texto:string,ponto:()=>{x:number,y:number}}>, destacar:(i:number)=>void, fechar:()=>Promise<void>}}
   */
  async function abrirDropdownVisual(select) {
    garantirUI();
    const r = select.getBoundingClientRect();
    elDropdown.innerHTML = '';
    const elItens = Array.from(select.options).map((op, i) => {
      const d = document.createElement('div');
      d.className = 'item';
      d.innerHTML = `<span class="ck">${i === select.selectedIndex ? '✓' : ''}</span><span></span>`;
      d.lastChild.textContent = op.text.trim();
      elDropdown.appendChild(d);
      return d;
    });
    elDropdown.style.minWidth = Math.max(r.width, 120) + 'px';
    elDropdown.style.left = r.left + 'px';
    elDropdown.style.maxHeight = '';
    elDropdown.style.top = '0px';
    // Altura natural da lista: se não couber abaixo do campo, sobe (como o popup nativo);
    // se for maior que a janela, limita a altura e rola dentro da réplica.
    const altura = elDropdown.offsetHeight;
    const margem = 8;
    let topo = r.bottom + 4;
    if (topo + altura > innerHeight - margem) {
      topo = Math.max(margem, innerHeight - margem - altura);
      if (altura > innerHeight - 2 * margem) elDropdown.style.maxHeight = innerHeight - 2 * margem + 'px';
    }
    elDropdown.style.top = topo + 'px';
    elDropdown.getBoundingClientRect(); // força layout antes da transição
    elDropdown.classList.add('aberto');
    await dormir(180);

    // Em listas com rolagem, traz o item para a área visível da réplica.
    const revelar = (el) => {
      const ini = el.offsetTop;
      const fim = ini + el.offsetHeight;
      const visivel = elDropdown.clientHeight;
      if (ini < elDropdown.scrollTop + 6) elDropdown.scrollTop = Math.max(0, ini - 6);
      else if (fim > elDropdown.scrollTop + visivel - 6) elDropdown.scrollTop = fim - visivel + 6;
    };

    const itens = elItens.map((el, indice) => ({
      indice,
      texto: select.options[indice].text.trim(),
      ponto: () => {
        revelar(el);
        const b = el.getBoundingClientRect();
        return { x: b.left + 40, y: b.top + b.height / 2 };
      }
    }));
    return {
      itens,
      destacar(i) {
        elItens.forEach((el, k) => el.classList.toggle('hover', k === i));
      },
      async fechar() {
        elDropdown.classList.remove('aberto');
        await dormir(150);
        elDropdown.innerHTML = '';
      }
    };
  }

  function ocultar() {
    if (elCursor) elCursor.style.opacity = '0';
  }

  NS.cursor = { moverPara, clicar, abrirDropdownVisual, ocultar, posicao: () => (pos ? { ...pos } : null) };
})();
