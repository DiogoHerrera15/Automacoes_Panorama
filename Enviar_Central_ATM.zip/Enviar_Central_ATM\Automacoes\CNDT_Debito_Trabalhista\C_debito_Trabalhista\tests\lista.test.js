// Lista CNPJ;NOME, pastas, nomes de arquivo e fila. Rodar na pasta da extensão: node --test tests/
const assert = require('node:assert/strict');
const { test } = require('node:test');
const L = require('../lista.js');

test('separa CNPJ e nome, formata e preserva a associação', () => {
  const r = L.lerLista('11.222.333/0001-81;EMPRESA UM LTDA\n11444777000161;EMPRESA DOIS LTDA\n');
  assert.equal(r.itens.length, 2);
  assert.deepEqual(r.itens.map((i) => [i.formatado, i.nome]), [
    ['11.222.333/0001-81', 'EMPRESA UM LTDA'],
    ['11.444.777/0001-61', 'EMPRESA DOIS LTDA'],
  ]);
  assert.equal(r.itens[0].arquivo, 'CNDT_EMPRESA UM LTDA.pdf');
  assert.equal(L.caminhoDoArquivo('CERTIDOES_CNDT', r.itens[1]), 'CERTIDOES_CNDT/EMPRESA DOIS LTDA/CNDT_EMPRESA DOIS LTDA.pdf');
});

test('linhas vazias, sem ";", sem nome, CNPJ inválido e repetido', () => {
  const r = L.lerLista([
    '11.222.333/0001-81;EMPRESA UM',
    '',
    '   ',
    '11222333000181 EMPRESA SEM PONTO E VIRGULA',
    '11.444.777/0001-61;',
    '48.291.735/0001-09;EMPRESA TESTE LTDA', // dígitos verificadores errados
    'abc;EMPRESA',
    '11.222.333/0001-81;EMPRESA UM DE NOVO', // repetido
    ';SEM CNPJ',
  ].join('\n'));
  assert.equal(r.itens.length, 1);
  assert.equal(r.vazias, 2);
  assert.equal(r.repetidos, 1);
  assert.deepEqual(r.rejeitadas.map((x) => x.linha), [4, 5, 6, 7, 9]);
  assert.match(r.erros[0], /Linha 4: falta o ";"/);
  assert.match(r.erros[1], /Linha 5: falta o nome/);
  assert.match(r.erros[2], /Linha 6: .*dígitos verificadores/);
});

test('aceita TAB do Excel, completa zeros perdidos, CPF e CNPJ alfanumérico', () => {
  // 00.445.000/0001-03 colado do Excel sem os dois zeros: 445000000103
  const r = L.lerLista('445000000103\tEMPRESA EXCEL\n123.456.789-09;PESSOA FISICA\n12.ABC.345/01DE-35;ALFA LTDA');
  assert.deepEqual(r.itens.map((i) => i.formatado), ['00.445.000/0001-03', '123.456.789-09', '12.ABC.345/01DE-35']);
  assert.equal(r.ajustados, 1);
  assert.deepEqual(r.itens.map((i) => i.tipo), ['CNPJ', 'CPF', 'CNPJ']);
});

test('nomes iguais ganham o CNPJ na pasta e no arquivo (sem misturar empresas)', () => {
  const r = L.lerLista('11.222.333/0001-81;MESMO NOME LTDA\n11.444.777/0001-61;Mesmo Nome Ltda\n');
  assert.deepEqual(r.itens.map((i) => i.pasta), ['MESMO NOME LTDA - 11222333000181', 'Mesmo Nome Ltda - 11444777000161']);
  assert.deepEqual(r.itens.map((i) => i.arquivo), ['CNDT_MESMO NOME LTDA - 11222333000181.pdf', 'CNDT_Mesmo Nome Ltda - 11444777000161.pdf']);
  const caminhos = r.itens.map((i) => L.caminhoDoArquivo('X', i).toLowerCase());
  assert.equal(new Set(caminhos).size, 2);
});

test('nomes com caracteres que o Windows recusa', () => {
  const r = L.lerLista('11.222.333/0001-81;EMPRESA S/A: "TESTE" <1>?*|.');
  assert.equal(r.itens[0].pasta, 'EMPRESA S-A_ _TESTE_ _1____');
  assert.ok(L.caminhoValido(L.caminhoDoArquivo('CERTIDOES', r.itens[0])));
  assert.equal(L.limparNome('CON'), 'CON_');
  assert.equal(L.limparPastaPrincipal('..\\CERTIDOES//NOV 2026/../'), 'CERTIDOES/NOV 2026');
  assert.ok(!L.caminhoValido('../fora/arquivo.pdf'));
  assert.ok(!L.caminhoValido('C:/Windows/x.pdf'));
});

test('fila: ordem da lista, depois os com erro (uma vez por rodada); resumo', () => {
  const { itens } = L.lerLista('11.222.333/0001-81;A\n11.444.777/0001-61;B\n123.456.789-09;C');
  const a = {};
  assert.equal(L.proximaEmpresa(itens, a).nome, 'A');
  a['11222333000181'] = { estado: 'erro' };
  assert.equal(L.proximaEmpresa(itens, a).nome, 'B');
  a['11444777000161'] = { estado: 'concluida' };
  a['12345678909'] = { estado: 'concluida' };
  assert.equal(L.proximaEmpresa(itens, a), null);
  assert.equal(L.proximaEmpresa(itens, a, { refazerErros: true }).nome, 'A');
  assert.equal(L.proximaEmpresa(itens, a, { refazerErros: true, jaRefeitas: ['11222333000181'] }), null);
  assert.deepEqual(L.resumo(itens, a), { total: 3, concluidas: 2, erros: 1, pendentes: 0 });
});

test('relatório lista erros, concluídas e linhas ignoradas', () => {
  const r = L.lerLista('11.222.333/0001-81;A\n11.444.777/0001-61;B\nlixo');
  const txt = L.textoRelatorio({ pasta: 'CNDT/NOV', itens: r.itens, rejeitadas: r.rejeitadas,
    andamento: { '11222333000181': { estado: 'erro', detalhe: 'verificação incorreta 3 vezes' }, '11444777000161': { estado: 'concluida', arquivo: 'C:/x/CNDT_B.pdf' } } });
  assert.match(txt, /Concluídas: 1 \| Com erro: 1 \| Pendentes: 0/);
  assert.match(txt, /verificação incorreta 3 vezes/);
  assert.match(txt, /CNDT_B\.pdf/);
  assert.match(txt, /Linha 3: lixo/);
});
