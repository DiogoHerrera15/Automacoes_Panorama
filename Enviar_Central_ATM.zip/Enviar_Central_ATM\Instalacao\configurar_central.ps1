﻿# Configura a Central de Automações já copiada para a pasta de instalação:
#   - ajusta a pasta da PGFN na lista (só se não for a padrão Downloads\Auto_PGFN);
#   - libera os arquivos baixados da internet (Unblock-File);
#   - cria o atalho "Central de Automações" na Área de Trabalho;
#   - roda a conferência da própria Central (-Validar).
# Pode rodar de novo quando quiser. Não precisa de administrador.
#   powershell -NoProfile -ExecutionPolicy Bypass -File configurar_central.ps1 [-Destino <pasta>] [-SemAtalho]
param(
  [string]$Destino = (Join-Path $env:USERPROFILE 'Central_ATM'),
  [string]$PastaPGFN = (Join-Path $env:USERPROFILE 'Downloads\Auto_PGFN'),
  [switch]$SemAtalho,
  [string]$PastaAtalho = ([Environment]::GetFolderPath('Desktop')),
  [string]$Log = ''
)
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'comum.ps1')
if ($Log) { $script:LOG = $Log }

$central = Join-Path $Destino 'Central_de_Automacoes'
Titulo 'Configurar a Central de Automações'
Info "Pasta da Central: $central"
foreach ($f in 'Central.ps1', 'Abrir Central.vbs', 'automacoes.json', 'ajuda.json') {
  if (-not (Test-Path -LiteralPath (Join-Path $central $f))) { Erro "falta $f em $central (rode o instalar.ps1 primeiro)"; exit 1 }
}

# PGFN fora do lugar padrão: troca o caminho na lista e na ajuda (o padrão fica como %USERPROFILE%\Downloads\Auto_PGFN).
$padrao = Join-Path $env:USERPROFILE 'Downloads\Auto_PGFN'
if ($PastaPGFN.TrimEnd('\') -ine $padrao) {
  foreach ($f in 'automacoes.json', 'ajuda.json') {
    $arq = Join-Path $central $f
    $t = [IO.File]::ReadAllText($arq, [Text.Encoding]::UTF8)
    $novo = $t.Replace('%USERPROFILE%\\Downloads\\Auto_PGFN', $PastaPGFN.TrimEnd('\').Replace('\', '\\'))
    if ($novo -ne $t) { [IO.File]::WriteAllText($arq, $novo, (New-Object Text.UTF8Encoding $false)); Ok "$f aponta a PGFN para $PastaPGFN" }
  }
  Aviso "a PGFN foi configurada em $PastaPGFN, fora de Downloads\Auto_PGFN: o instalador dela vai recusar (use só para teste)"
}
try { (Get-Content -LiteralPath (Join-Path $central 'automacoes.json') -Raw -Encoding UTF8 | ConvertFrom-Json) | Out-Null; Ok 'automacoes.json válido' } catch { Erro "automacoes.json com erro: $($_.Exception.Message)" }
try { (Get-Content -LiteralPath (Join-Path $central 'ajuda.json') -Raw -Encoding UTF8 | ConvertFrom-Json) | Out-Null; Ok 'ajuda.json válido' } catch { Erro "ajuda.json com erro: $($_.Exception.Message)" }

# Arquivos vindos de outro computador/ZIP ganham a marca "baixado da internet": o Windows pode bloquear .ps1/.cmd/.exe.
foreach ($p in @($Destino, $PastaPGFN)) {
  if (Test-Path -LiteralPath $p) {
    Get-ChildItem -LiteralPath $p -Recurse -File -ErrorAction SilentlyContinue |
      Where-Object { $_.FullName -notmatch '\\(node_modules|\.venv)\\' } | Unblock-File -ErrorAction SilentlyContinue
  }
}
Ok 'arquivos liberados (Unblock-File)'

if (-not $SemAtalho) {
  try {
    $lnk = Join-Path $PastaAtalho 'Central de Automações.lnk'
    Criar-Atalho $lnk $central
    Ok "atalho criado: $lnk"
  } catch { Erro "não consegui criar o atalho: $($_.Exception.Message)" }
}

Titulo 'Conferência da Central (-Validar)'
$antes = [Console]::OutputEncoding
try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch { }
$saida = & powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $central 'Central.ps1') -Validar 2>&1 | Out-String
try { [Console]::OutputEncoding = $antes } catch { }
$saida -split "`r?`n" | Where-Object { $_.Trim() } | ForEach-Object { Info $_ }
if ($saida -match 'ERRO:' -or $saida -match 'pronto : N') { Erro 'a Central apontou automações que não podem ser abertas (veja acima)' }
else { Ok 'a Central encontrou todas as automações (os avisos de extensão somem depois de carregá-las no Chrome)' }
if ($script:ERROS) { exit 1 } else { exit 0 }
