@echo off
rem Automacao PGFN - instalacao guiada (usuario atual do Windows; nao precisa de administrador). Pode rodar de novo.
chcp 65001 >nul
title Automação PGFN - instalação
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalacao\instalar.ps1" %*
pause
