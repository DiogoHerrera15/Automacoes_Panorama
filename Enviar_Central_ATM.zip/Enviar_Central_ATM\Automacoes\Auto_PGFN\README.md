# Automação_PGFN

Automação nova do e-CAC e do Regularize, separada da extensão `parcelamento_simplificado` (`Documents\simplificado`). O caminho dela é outro: a antiga serve só de consulta.

## Como usar
1. Em `chrome://extensions`, ative o "Modo do desenvolvedor" e use "Carregar sem compactação" na pasta `Automação_PGFN` daqui.
2. Desative a extensão antiga (`parcelamento_simplificado`) enquanto testa.
3. Se usa janela anônima, ligue "Permitir no modo anônimo" em Detalhes.
4. Aperte F5 na tela inicial do e-CAC: na primeira vez em cada aba, a automação começa sozinha.
5. Depois que ela terminar (com sucesso, erro ou parada), só recomeça pelo ícone. Clicar no ícone durante a execução para a automação.

Para nunca começar sozinha, troque `INICIAR_NA_TELA_INICIAL` para `false` em `content.js`.

Depois de mudar o código: recarregue a extensão em `chrome://extensions` e aperte F5 no e-CAC.

## Vários CNPJs em sequência
Ao terminar um CNPJ na aba do SISPAR, a automação segue para o próximo de `CNPJS_TESTE`. Vale para os casos "sem parcelamento", "sem deferida" e "negociações analisadas":
1. a aba do e-CAC recebe o próximo CNPJ e recarrega;
2. as abas do Regularize e do SISPAR desse CNPJ são fechadas;
3. o fluxo recomeça na troca de perfil.

Os CNPJs já terminados nesta execução não são repetidos. Se a automação parar com erro, ela não avança para o próximo.

## Onde os arquivos ficam (uma pasta por CNPJ)
Diretório principal: `Downloads\Auto_PGFN\Documentos_arrecadacao\`. Dentro dele, uma pasta para cada CNPJ, com o nome formado só pelos dígitos. A pasta é criada sozinha no primeiro arquivo. Tudo o que o CNPJ gera vai para ela:
```r
Documentos_arrecadacao\
├── 21179250000100\
│   ├── Sem_Deferido_21179250000100.pdf        (sem "Deferida e consolidada")
│   ├── 21179250000100;NOME.pdf                (sem parcelamento)
│   ├── 21179250000100;NOME;MM-AAAA.pdf        (documento de cada prestação pendente)
│   ├── sem_cadastro_regularize.pdf            (sem cadastro no Regularize)
│   ├── print_confirmacao.pdf                  (situação final da tela "Prestação")
│   └── 21179250000100;NOME;relatorio AAAA-MM-DD HHhMM.csv
└── 14056350000184\
    └── ...
```r
**Print de confirmação** (`print_confirmacao.pdf`): é tirado ao terminar cada negociação "DEFERIDA E CONSOLIDADA", depois de todas as emissões, também quando nada precisou ser emitido.
1. A automação está de volta à tela "Prestação" da negociação (o "Voltar" da página do PDF leva a ela) e espera ela carregar.
2. Lê a tabela de novo e decide pelo que o sistema mostra, não pelo clique. Até o mês atual, cada prestação fica em um destes estados:
   - "verificado";
   - "documento NNN válido até dd/mm/aaaa": a "Data Vencimento Doc. Arrec." é de hoje em diante;
   - **"PENDENTE na tela final"**.
3. Tira o print da página inteira, de cima para baixo e em partes, juntadas numa imagem só. A seta, o aviso da automação e a faixa de cookies ficam escondidos durante o print. A faixa de cookies não é clicada.
4. Salva na pasta do CNPJ. É um PDF com a página inteira numa só página, legível. Com uma negociação, o nome é `print_confirmacao.pdf`. Com várias, é um print por negociação: `print_confirmacao_conta_<conta>.pdf`.
5. A conferência final vai para a mensagem de fim e para a coluna "Situação na tela final" do relatório. Uma pendência que continua na tela aparece como pendência.

Antes de salvar qualquer arquivo, a automação confere o CNPJ em processamento. Ele precisa ter 14 dígitos e ser o mesmo da linha "Usuário:" da tela. Se não bater, ela não salva e avisa.

**Correção de 06/11/2026:** o print "Sem_Deferido" e os relatórios tinham caído em `Downloads` com o nome "download". O motivo: o ouvinte que renomeia os downloads do site respondia sem nome aos downloads da própria extensão, e o Chrome então ignorava o nome pedido. Agora ele devolve o nome pedido. Os arquivos foram movidos para as pastas certas.

## O que faz hoje (versão 0.28.0)
No e-CAC:
0. Se aparecer o aviso "Prepare-se para a evolução dos serviços digitais da RFB", clica em "Continuar no e-CAC por enquanto" (nunca em "Acessar o portal..."). Confere de novo depois da troca de perfil, quando a página recarrega.
1. Analisa a página e lê no cabeçalho em qual CNPJ/empresa está ("Procurador de:", se houver; senão, "Titular").
2. Com a seta desenhada, clica em "Alterar perfil de acesso" (até 3 tentativas).
3. Confere a janela que abre, pela frase de cima ou por pelo menos 3 das 5 opções.
4. Clica no campo "Procurador de pessoa jurídica - CNPJ" e digita o CNPJ tecla a tecla. A colagem só entra se a digitação não deixar o valor certo no campo.
5. Clica no botão "Alterar" da mesma linha do campo.
6. Espera a tela carregar (até 45 s) e confere se o CNPJ no topo é o esperado. Se travar (ex.: "Aguarde a validação dos dados…" sem fim), recarrega a página (F5) e refaz a troca com o mesmo CNPJ, até 2 vezes. Se depois do F5 o topo já mostrar o CNPJ, segue sem trocar de novo.
7. Clica no bloco "Dívida Ativa da União" (até 3 tentativas) e confere se as opções dele apareceram.
8. Clica em "PGFN - Todos os serviços do Regularize". Se o painel da Dívida Ativa abriu e essa opção não aparece em 8 s, o CNPJ não tem acesso à PGFN. A automação pula esse CNPJ sem salvar nada, recarrega a página e segue com o próximo da lista. Se não houver próximo, termina normalmente.
9. Espera a nova janela chegar ao Regularize (até 60 s).

No Regularize (`www.regularize.pgfn.gov.br`; o Chrome esconde o "www." na barra):
1. Espera a página inicial carregar (até 45 s).
   **Sem cadastro:** se aparecer "Você ainda não está cadastrado no REGULARIZE. Para acessar os serviços, efetue seu cadastro.", a automação **não** segue o fluxo e não mexe no cadastro. Tira o print da tela, salva em `Documentos_arrecadacao\<CNPJ>\sem_cadastro_regularize.pdf` e segue para o próximo CNPJ da lista. A mensagem final registra esse status.
2. Espera até 10 s pelo aviso "Atenção!". Se ele aparecer, clica em "CIENTE"; se não, segue.
   Aviso "Atenção! Fique atento: você tem novas notificações na caixa de mensagens da PGFN!":
   - **Quando confere:** depois do "CIENTE" (ou sem ele), a automação espera até 5 s pelo aviso. Ele também é conferido antes de cada clique nas duas páginas, para não ficar por cima.
   - **O que clica:** se o aviso estiver visível, clica em "FECHAR" e espera ele fechar (até 3 tentativas). Nunca clica em "VER AGORA".
   - **Sem aviso:** segue direto.
3. Clica em "NEGOCIAR DÍVIDA" (até 3 tentativas) e espera a tela carregar. Nessa segunda página, espera de novo até 5 s pelo aviso de notificações e fecha se aparecer.
4. No bloco "Acesso ao Sistema de Negociações - Parcelamento ou Acordo de Transação", clica em "ACESSAR". Só aceita o botão desse bloco.
5. Espera 3 s e anota se a página tentou uma janela que o Chrome bloqueou (sem reabrir nada).
6. Espera o Sistema de Negociações carregar (reconhece pelo título ou por pelo menos 3 das opções), clica em "CONSULTAR" (até 3 tentativas) e confere se o aviso do SISPAR apareceu.
7. Analisa o aviso e clica em "CONTINUAR" (até 3 tentativas, só enquanto o aviso continua aberto). Nunca clica em "DESISTIR". Como no uso manual, o SISPAR abre numa **aba nova**, e a automação continua nela (ver "Causa encontrada" abaixo).
8. Na tela da PGFN, passa a seta sobre o menu "Emissão de Documento" (sem clicar), espera as opções aparecerem, desce em linha reta até "Documento de arrecadação" (sem sair de cima do menu) e clica nela (não em "...Avulso").
9. Na tela "Emissão de documento de arrecadação", se aparecer "Não foram encontradas solicitações de negociação para este contribuinte", tira print da tela (sem a seta e o aviso) e salva em PDF em `Downloads\Auto_PGFN\Documentos_arrecadacao\<CNPJ>\<CNPJ>;<NOME DA EMPRESA>.pdf`. Se aparecer a **tabela de negociações**, clica no título "Situação da conta" para ordenar (só se ainda não estiver em ordem; confere a ordem lendo a coluna, e clica de novo se ficar ao contrário) e segue para as negociações:
10. Lê a tabela e guarda o **Número da Conta** de cada linha "DEFERIDA E CONSOLIDADA" (a posição na tabela muda quando a página recarrega; a conta não). Para cada conta, uma por vez:
    1. clica na linha e confere que ficou selecionada e que o botão de baixo habilitou;
    2. clica em **"Documento de Arrecadação" abaixo da tabela**. Ele tem o mesmo texto da opção do menu e é distinguido por ficar fora do menu e depois da tabela;
    3. espera a página "EMISSÃO DE DOCUMENTO DE ARRECADAÇÃO - INTERNET" e confere que o "Nr. Referência Conta" é a conta selecionada;
    4. **analisa a tabela "Prestação"** (ver abaixo);
    5. anota a conta como feita, rola de volta ao topo e volta à lista pelo menu ("Emissão de Documento" > "Documento de arrecadação");
    6. na lista, clica de novo em "Situação da conta" para ordenar (se ela não estiver em ordem) e segue para a próxima conta.

    **Nenhuma "DEFERIDA E CONSOLIDADA" na tabela:**
    1. a automação espera a página e a tabela carregarem;
    2. confere na linha "Usuário:" que a tela é do CNPJ em processamento;
    3. rola até o topo e tira o print da tela;
    4. salva em PDF em `Downloads\Auto_PGFN\Documentos_arrecadacao\<CNPJ>\Sem_Deferido_<CNPJ>.pdf`.

    Com alguma "DEFERIDA E CONSOLIDADA" na tabela, esse PDF não é gerado.

    As contas feitas ficam no estado, então nenhuma é pulada ou repetida, mesmo com a página recarregando. Só a 1ª página da tabela de negociações é lida.

### Tabela "Prestação" (coluna "Emissão")
- A seta vai para cima da tabela, e a página desce com a "roda do mouse": 2 a 4 dentes de cada vez, com pausa para os registros renderizarem. Cada linha é conferida quando aparece inteira na tela, até o fim da tabela. O aviso de cookies fixo embaixo é descontado da área visível. A automação não clica nele.
- **Competência** = mês/ano da "Data Vencimento Prestação", comparada com o mês atual do relógio do computador. Meses futuros são só anotados e nunca contam como pendência.
- **Ícone azul de verificado:** regular, nenhuma ação.
- **Ícone laranja de exclamação:** o documento já foi emitido e não é emitido de novo. Se o nome do ícone não disser isso, vale a própria linha: com "Nr. Documento Cobrança" preenchido e saldo devedor, a prestação conta como já emitida, e não como paga. A data do documento é conferida na tela final. Vencido, aparece como pendente.
- **Impressora** (ou outro ícone clicável com saldo devedor), até o mês atual: pendência. A automação traz a linha para a tela e emite o documento:
  1. clica no ícone e espera a janela "Cálculo e demonstrativo de emissão de Documento de Arrecadação";
  2. confere que "Parcela para emissão" é a prestação clicada. Se não for, clica em "Voltar" da janela e para, sem emitir;
  3. clica em "Emitir" e espera a página do PDF (`resultadoDarfInternet`);
  4. clica no link do PDF (o número ao lado do ícone de PDF) e espera o download (até 45 s);
  5. confere o download: completo, `.pdf` e não vazio. Só então clica em "Voltar" e continua a coluna "Emissão" de onde parou.
- **Onde o PDF fica:** `Downloads\Auto_PGFN\Documentos_arrecadacao\<CNPJ só dígitos>\CNPJ;NOME;MM-AAAA.pdf`. Se a mesma competência já tiver sido salva nesta execução, o nome ganha `;conta X;prest Y`. O Chrome nunca sobrescreve: um nome repetido ganha "(1)".
- **Janela "Salvar como" do Chrome:** aparece quando a opção "Perguntar onde salvar cada arquivo antes de fazer download" está ligada. Ela é do Windows, não da página, por isso quem confirma é o **ajudante do Windows** (`Downloads\Auto_PGFN\ajudante_salvar_como`, ver "Ajudante Salvar como" abaixo). Ele só clica em "Salvar" se três coisas baterem: a pasta é `...\Auto_PGFN\Documentos_arrecadacao\<CNPJ em processamento>`, o nome é o esperado e o tipo é PDF. Se algo não bater, não clica. Faz até 2 tentativas. Sem o ajudante instalado, ou se ele não confirmar, a automação mostra um aviso vermelho e espera até 3 min a pessoa clicar em "Salvar". Depois do download, ela confere que o arquivo existe no disco, na pasta do CNPJ, e começa com "%PDF". Fechar a janela não conta como salvo. O mais simples é desligar essa opção em `chrome://settings/downloads`, e aí a janela nem aparece.
- **Vários downloads seguidos:** o Chrome bloqueia o 2º download automático de um site e pergunta "quer fazer o download de vários arquivos". A extensão não clica nesse aviso, porque ele é da janela do Chrome. Em vez disso, antes de cada documento, ela libera a permissão "Downloads automáticos" **só para `https://sisparnet.pgfn.fazenda.gov.br`**, com a permissão `contentSettings`. Na janela anônima, a liberação vale até a janela ser fechada. Se a extensão for removida, a permissão some.
- **PDF de verdade, não página:** um download que chega como página (HTML) é cancelado antes de ser salvo e não conta como documento. O atalho "baixar o endereço do link" só vale para o endereço de outro arquivo, nunca para a própria página. Em 06/11/2026 esse atalho baixou a página `resultadoDarfInternet.jsf#` e salvou um `.htm` no lugar do PDF.
- **Nova tentativa controlada:** se nenhum download chegar ou chegar uma página no lugar do PDF, a automação clica no link do PDF mais uma vez, no máximo 2 vezes. Isso não emite um documento novo, porque o "Emitir" já foi feito; só baixa o mesmo PDF. Se continuar falhando, para e registra o CNPJ, a conta e a prestação.- **Registro entre execuções:** cada PDF salvo fica anotado na extensão (CNPJ, conta, prestação e mês da emissão). Numa nova execução no mesmo mês, a prestação já salva não é emitida de novo e aparece no relatório como "já salvo antes". No mês seguinte, ela é emitida de novo, porque o documento vence no último dia útil do mês da emissão.
- **Cliente certo:** antes de emitir, a automação lê a linha "Contribuinte:" da negociação. Se o CNPJ não for o ativo, ela para.
- **Página que muda no meio:** cada passo da emissão fica gravado. A página nova continua do ponto certo, e a automação nunca clica em "Emitir" duas vezes para a mesma prestação.
- **Ícone não reconhecido ou sem clique:** não clica; anota como "VERIFICAR" no relatório, com o HTML do ícone.
- **Downloads repetidos:** cada prestação é baixada uma vez por execução. Se a página recarregar logo depois do clique, a automação confere se o documento chegou, sem clicar de novo. Se nada chegar, ela para e explica, também sem clicar de novo.
- **Como o PDF é capturado depois do clique no link:**
  - **download do site:** o service worker renomeia só o primeiro download que chega logo depois do clique;
  - **aba nova:** baixa o endereço dela, fecha essa aba e volta à aba da automação;
  - **janela bloqueada pelo Chrome:** baixa o mesmo endereço;
  - **link com endereço comum e nada chegou em 8 s:** baixa o endereço do link.
- **Paginação:** se a tabela tiver botão de próxima página, a automação passa para ela.
- **Relatório:** `Downloads\Auto_PGFN\Documentos_arrecadacao\<CNPJ>\CNPJ;NOME;relatorio AAAA-MM-DD HHhMM.csv`, abre no Excel. Tem uma linha por prestação (conta, competência, vencimento, valores, ícone, resultado e arquivo). Se a automação parar no meio, salva o relatório "(parcial)".

A espera pelo resultado acaba assim que a mensagem ou a tabela aparece (máximo 15 s).

**Seta e menus de "hover":** ao passar de um elemento para outro, a seta avisa a página como um mouse de verdade (de onde saiu e para onde foi, e entra/sai de cada elemento por onde realmente passou). Sem isso, o menu "Emissão de Documento" achava que a seta tinha saído dele ao descer para "Documento de arrecadação", e fechava.

Nome dos arquivos: sempre `CNPJ;NOME DA EMPRESA.pdf` (o nome vem do topo do e-CAC; se não houver, da linha "Usuário:" da tela da PGFN). Cada caso vai para a sua pasta. Arquivo repetido ganha "(1)", "(2)"... Se o Chrome recusar o ";", salva com "_" e avisa.

O aviso da automação fica no canto inferior esquerdo da tela.

A aba precisa estar em primeiro plano na hora do print (o Chrome só fotografa a aba visível).

**Janela anônima:** a tela da PGFN fica num quadro de outro domínio (`pgfn.fazenda.gov.br` dentro de `pgfn.gov.br`). A janela anônima bloqueia os cookies de terceiros desse quadro: a primeira tela abre, mas o clique seguinte dá "Você não tem permissão de acesso ou ele expirou". Rode numa janela normal, ou permita cookies de terceiros no site (ícone do olho riscado na barra de endereço). A automação reconhece essa mensagem e para explicando isso.

**Causa encontrada (05/11/2026):** o erro "Sessão encerrada: Você não tem permissão de acesso ou ele expirou" vem do jeito como o simulador do SISPAR trata o "CONTINUAR". O código dele faz `window.open(url, "_blank") || window.location.replace(url)`, com `url = sisparnet.pgfn.fazenda.gov.br/sisparInternet/autenticacao.jsf?token=...&simulador=true`.
- **Clique manual:** a aba nova abre, e o SISPAR roda nela como site principal. Funciona.
- **Clique simulado:** o Chrome bloqueia a aba, e o simulador carrega o SISPAR **dentro do quadro** do Regularize. Ali a sessão do SISPAR é cookie de terceiros e não fica guardada. A primeira tela abre, mas o clique seguinte dá "Sessão encerrada". Reabrir o endereço numa aba extra também não salva, porque o token é de uso único.

**Solução (0.12.0):** `pagina.js` intercepta essa abertura, só logo depois de a automação clicar em "CONTINUAR" (marca `data-pgfn-auto`). Ele entrega o endereço à extensão, que abre a aba nova **uma vez** (como no manual), e devolve ao simulador uma "janela" de mentira, para ele não carregar o endereço também no quadro. O andamento passa para a aba nova (transferência com `destino: 'sisparnet'`), onde rodam o menu "Emissão de Documento", o "Documento de arrecadação" e o PDF. Fora da automação, o "CONTINUAR" funciona normalmente.

`CLIQUE_MANUAL_NO_DOCUMENTO` (em `content.js`, hoje `false`) é o modo de diagnóstico: com `true`, a automação para na tela da PGFN para a pessoa clicar em "Documento de arrecadação" com o mouse.

**Movimento da seta:** cada deslocamento sorteia a forma (direto, passa do ponto e volta, desvia por um ponto no caminho ou freia perto do alvo), a curva de aceleração, o arco, o tremor e as pausas. Às vezes termina com um micro ajuste. O ritmo geral também muda a cada carregamento da página.

Para aí. A automação nunca digita login nem senha: se o Regularize pedir login, ela para e avisa.

CNPJ de teste atual: só `32466313000126`. Se ele já estiver ativo no topo, a automação segue sem trocar de perfil. Com mais de um na lista, usa o primeiro que não seja o perfil já ativo. Se o e-CAC responder "Não existe procuração eletrônica…", recarrega a página e tenta o próximo; se nenhum servir, para e avisa. Ficam em `CNPJS_TESTE`, no início de `content.js`, junto com os tempos limite e as velocidades da seta e da digitação.

## Mudança de página e de janela
O andamento fica no service worker, por aba. Se a página mudar no meio, a automação retoma sozinha na página nova, com o mesmo CNPJ e a seta na mesma posição. Depois de 5 mudanças seguidas, ela para e avisa.

Ao abrir o Regularize, a aba do e-CAC registra uma transferência (válida por 2 min), e a primeira página do Regularize que carregar assume o andamento.

Pop-up bloqueado: um clique simulado pode ser bloqueado pelo Chrome. Se a janela não abrir em 5 s, a extensão abre o mesmo endereço por conta própria. Sem endereço conhecido, ela para e pede para permitir pop-ups no site.

Para acrescentar um passo: escreva a função em `content.js` e inclua-a na lista `ETAPAS` da página certa.

**Clique que recarrega a página:** antes dele, grave em `estado.etapa` a etapa seguinte (`antesDoClique`), senão a página nova repete o clique. Foi o que aconteceu com "Documento de arrecadação" na 0.13.0: a página recarregava, a automação clicava de novo e parava em "A página mudou 12 vezes seguidas". Cada etapa concluída zera o contador de recargas.

## Quadro do SISPAR
A página `/sispar/sisparnet` só exibe um `<iframe id="sisparFrame">` de outro endereço (`pro-frontend-simulador-sispar.estaleiro.serpro.gov.br`), gerado pelo servidor. A página de fora não enxerga o conteúdo, então este mesmo script roda dentro do quadro como "agente": ele diz onde estão os alvos e clica neles. A seta continua desenhada na página de fora. Todo alvo novo dentro do quadro precisa entrar em `ALVOS` (e em `CLICAVEIS`, se for clicado).

O script carrega em todos os quadros dos sites do manifest e sai na primeira verificação em qualquer lugar que não seja o e-CAC, o Regularize ou um quadro dentro do Regularize.

## Vários CNPJs e certificados (orquestrador)
Para processar uma lista de CNPJs, cada um num Chrome novo:
1. **Configure** `Downloads\Auto_PGFN\cnpjs.json`. Cada certificado leva a sua lista de CNPJs. `certificado` é o nome do titular como aparece na janela "Selecione um certificado" do Chrome; basta um trecho único, por exemplo `AUDI3 CONTABILIDADE E AUDITORIA`.
2. **Rode** `Downloads\Auto_PGFN\orquestrador\iniciar_orquestrador.bat` e deixe a janela aberta. Para parar, feche essa janela.

**O que acontece a cada CNPJ:**
1. **Fecha o Chrome:** o orquestrador espera não haver download em andamento (`.crdownload`) e **fecha TODO o Chrome**, todas as janelas e perfis, sem confirmação.
2. **Abre o Chrome anônimo** em `https://cav.receita.fazenda.gov.br/autenticacao`.
3. **Login:** a extensão clica em "Entrar com gov.br" e depois em "Seu certificado digital", com a seta e pausas.
4. **Escolhe o certificado:** o ajudante do Windows move o **mouse de verdade** até o certificado configurado na janela do Chrome e clica. Confere que o foco ficou nesse certificado e só então clica em OK. Se não achar exatamente um com esse nome, **não escolhe outro** e pausa. Pela acessibilidade, "selecionar" a linha fecha a janela; por isso o clique é com o mouse.
5. **Fluxo de sempre:** na tela inicial do e-CAC, a automação começa como antes (perfil, Regularize, SISPAR, emissões, prints). O salvamento não muda: mesmas pastas, nomes e PDFs. Ela usa **só** o CNPJ da vez; se aparecer outro, para.
6. **Aviso de fim:** ao terminar (todos os arquivos salvos e conferidos), a extensão avisa "concluido" ou "erro" e o orquestrador passa ao próximo CNPJ.

**Pausa para você:** captcha, PIN, senha, autorização ou uma tela desconhecida no login fazem a automação pausar e mostrar o motivo. O orquestrador fica esperando sem prazo. Quando você resolve e a página muda, o fluxo continua sozinho, sem reiniciar.

**Andamento:**
- **`orquestrador\andamento.json`:** a situação de cada CNPJ (em andamento, concluído ou erro, com a mensagem). Um CNPJ concluído não se repete nas próximas execuções; os com erro são tentados de novo.
- **`orquestrador\orquestrador.log`:** o histórico de cada execução.
- **Sem sinal:** se a extensão ficar 30 min sem dar sinal (fora de pausa), aquele CNPJ fica com erro e o orquestrador segue para o próximo.
- **Ver a lista sem rodar:** `orquestrador.ps1 -SoMostrar` mostra a lista e a situação de cada CNPJ.

**Como as partes conversam:**
- **orquestrador → extensão:** o orquestrador grava `atual.json` (CNPJ da vez, certificado e sessão), e a extensão lê por meio do ajudante.
- **extensão → orquestrador:** a extensão avisa pelo ajudante, que grava `sinal.json`, e o orquestrador acompanha esse arquivo.
- **Segurança:** o ajudante só aceita aviso do CNPJ e da sessão definidos pelo orquestrador.
- **Sem orquestrador rodando:** a extensão volta ao modo manual, com `CNPJS_TESTE` e login feito por você.
## Ajudante "Salvar como" (Windows)
Pasta `Downloads\Auto_PGFN\ajudante_salvar_como\`. É um script do PowerShell que o Chrome chama (native messaging) apenas quando a extensão pede.
- **Instalar (uma vez):** dê dois cliques em `instalar_ajudante.bat`. Ele faz três coisas:
  - acha o ID da extensão Automação_PGFN no Chrome (só lê);
  - grava `com_auto_pgfn_salvar_como.json`;
  - registra esse arquivo em `HKCU\Software\Google\Chrome\NativeMessagingHosts\com.auto_pgfn.salvar_como`, só para o usuário atual e sem precisar de administrador.
  Depois, recarregue a extensão.
- **Remover:** `desinstalar_ajudante.bat`.
- **O que ele faz:** só age em janelas "Salvar como"/"Save As" do próprio Chrome. Lê a pasta (barra de endereço), o nome e o tipo, e clica em "Salvar" só se baterem. Nunca substitui arquivo: se o Windows perguntar, responde "Não" e cancela. Só lê arquivos dentro de uma pasta `Auto_PGFN`.
- **Quando a janela aparece:** só na janela **anônima**. No perfil normal ("Suporte Panorama Fiscal"), a opção "Perguntar onde salvar" está desligada e a janela nem abre. Conferido em 06/11/2026.
- **Diagnóstico:** cada chamada fica anotada em `ajudante_salvar_como\ajudante.log` (pedido, o que a janela mostrava e a resposta). No começo de cada CNPJ, a extensão confere se o ajudante responde e avisa se não responder.
- **Correção de 06/11/2026:** na janela do Chrome, a caixa "Tipo" não é legível pela acessibilidade, e o ajudante recusava clicar. Agora vale o tipo que a extensão recebeu do site (PDF), e depois o "%PDF" é conferido no disco.
- **Se o ID da extensão mudar** (ex.: pasta da extensão movida): rode `instalar_ajudante.bat` de novo.

## Arquivos
- `manifest.json`: Manifest V3; carrega em `cav.receita.fazenda.gov.br`, `*.regularize.pgfn.gov.br`, `*.estaleiro.serpro.gov.br` e `*.pgfn.fazenda.gov.br`. O script só age no e-CAC, no Regularize e em quadros dentro do Regularize.
- `background.js`: clique no ícone, andamento por aba, passagem entre janelas, print da tela em PDF (permissões `downloads` e `<all_urls>`, esta última exigida pelo Chrome para fotografar a aba), nome dos documentos baixados pelo site e relatório .csv.
- `content.js`: seta, buscas na página, digitação e etapas.
- `offscreen.html` / `offscreen.js`: documento invisível da extensão que junta as partes do print de confirmação num PDF (permissão `offscreen`).
- `pagina.js`: anota o endereço que o e-CAC ou o Regularize tenta abrir em janela nova. No "CONTINUAR" da automação, entrega a abertura do SISPAR à extensão.
