/*
 * Verificação Cloudflare (Turnstile) — SOMENTE LEITURA.
 * Esta automação não clica, não resolve, não simula e não contorna a verificação.
 * Ela apenas lê se o token de conclusão já foi gerado (campo cf-turnstile-response):
 *   concluída  → segue;  em processamento → aguarda (tempo limitado);
 *   pendente/interativa → PAUSA, avisa o usuário e só retoma depois da conclusão legítima.
 */
(function () {
  'use strict';
  const NS = (window.EFiscoCRF = window.EFiscoCRF || {});
  const { dormir, esperarOuNulo } = NS.wait;
  const entre = ([a, b]) => a + Math.random() * (b - a);

  const widget = () => document.querySelector('.cf-turnstile, [id*="turnstile" i]');
  const campoToken = () => document.querySelector('input[name="cf-turnstile-response"]');

  /** "Impressão" curta do token atual (tamanho + início), para saber se é o MESMO token já rejeitado. */
  function impressao() {
    const t = campoToken();
    return t && t.value ? `${t.value.length}:${t.value.slice(0, 16)}` : '';
  }

  /**
   * Estado atual (síncrono, só leitura). Se `rejeitado` for informado, um token idêntico ao rejeitado
   * NÃO conta como concluído: é preciso uma verificação NOVA.
   */
  function estado(rejeitado) {
    const w = widget();
    const t = campoToken();
    if (!w && !t) return { presente: false, concluida: false };
    const temToken = !!(t && t.value && t.value.length > 10);
    const mesmoRejeitado = !!(rejeitado && temToken && impressao() === rejeitado);
    return { presente: true, concluida: temToken && !mesmoRejeitado, mesmoRejeitado };
  }

  /**
   * Garante que a verificação permite prosseguir. Lança erro se não concluir no prazo.
   * @returns {Promise<{status:'ausente'|'concluida'|'concluida-apos-espera'|'concluida-por-humano'}>}
   */
  async function garantirLiberada({ rejeitado } = {}) {
    const cfg = NS.CONFIG.cloudflare;
    let e = estado(rejeitado);
    if (!e.presente) {
      NS.log.info('Nenhuma verificação Cloudflare detectada na página — seguindo.');
      return { status: 'ausente' };
    }
    if (e.concluida) {
      NS.log.ok('Verificação Cloudflare já concluída (token presente) — a página permite prosseguir.');
      return { status: 'concluida', impressao: impressao() };
    }
    if (e.mesmoRejeitado) {
      NS.log.aviso('O token de verificação presente é o MESMO que o site rejeitou. Não será reutilizado: aguardando uma verificação NOVA.');
    }

    NS.log.info(`Verificação Cloudflare ainda em processamento. Aguardando até ${Math.round(cfg.processamento / 1000)} s...`);
    if (await esperarOuNulo(() => estado(rejeitado).concluida, { timeout: cfg.processamento, intervalo: 500, descricao: 'conclusão da verificação Cloudflare' })) {
      NS.log.ok('Verificação Cloudflare concluída.');
      await dormir(entre(cfg.pausaAposLiberar));
      return { status: 'concluida-apos-espera', impressao: impressao() };
    }

    NS.log.aviso('A verificação Cloudflare NÃO foi concluída sozinha e pode exigir ação humana. ' +
      'Conclua-a manualmente na página. A automação está PAUSADA e não interage com ela.');
    NS.log.resultado({ sucesso: null, aguardandoHumano: true, motivo: 'verificação Cloudflare pendente' });
    let ultimoLembrete = Date.now();
    const concluiu = await esperarOuNulo(() => {
      if (Date.now() - ultimoLembrete >= cfg.lembreteACada) {
        ultimoLembrete = Date.now();
        NS.log.aviso('Ainda aguardando a conclusão manual da verificação Cloudflare...');
      }
      return estado(rejeitado).concluida;
    }, { timeout: cfg.esperaHumana, intervalo: 1000, descricao: 'conclusão manual da verificação Cloudflare' });
    if (!concluiu) {
      throw new Error(`a verificação Cloudflare não foi concluída em ${Math.round(cfg.esperaHumana / 1000)} s. ` +
        'Conclua-a na página e execute novamente.');
    }
    NS.log.ok('Verificação Cloudflare concluída pelo usuário — retomando.');
    await dormir(entre(cfg.pausaAposLiberar));
    return { status: 'concluida-por-humano', impressao: impressao() };
  }

  NS.cloudflare = { estado, impressao, garantirLiberada };
})();
