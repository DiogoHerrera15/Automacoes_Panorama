/*
 * Botão "Emitir (e)" — o ÚNICO botão acionado pela automação.
 * Identificação específica: id real (#btt_emitir) + conferência de identidade. Jamais aceita o "Localizar".
 */
(function () {
  'use strict';
  const NS = (window.EFiscoCRF = window.EFiscoCRF || {});
  const { dormir, tentar, esperarPor } = NS.wait;
  const { norm } = NS.dom;

  const textoDe = (el) => norm(el.tagName === 'INPUT' ? el.value : el.textContent);

  /** É inequivocamente o botão Emitir? (e NÃO o Localizar) */
  function ehEmitir(el) {
    if (!el) return false;
    const t = textoDe(el);
    if (el.id === 'btt_localizar' || t.includes('localizar')) return false;
    if (el.matches('input[type=submit], button[type=submit]')) return false; // Emitir é type=button; submit = Localizar
    return t === 'emitir' || t.startsWith('emitir ');
  }

  /** Localiza o botão Emitir pelo id real; só recorre ao texto exato "Emitir". Nunca devolve outro botão. */
  function localizarBotao() {
    const { seletor, texto } = NS.CONFIG.emitir;
    const porId = seletor && document.querySelector(seletor);
    if (porId) return ehEmitir(porId) ? porId : null;
    return NS.dom.clicaveisPorTexto(texto).find(ehEmitir) || null;
  }

  const bloqueado = (b) => b.disabled || b.getAttribute('aria-disabled') === 'true' || /\bdisabled\b/.test(b.className);

  /** Visível, habilitado e sem nada sobreposto (ex.: aviso/overlay) no ponto do botão? */
  function liberado(b) {
    if (!NS.wait.estaVisivel(b) || bloqueado(b)) return false;
    const r = b.getBoundingClientRect();
    const topo = document.elementFromPoint(r.left + r.width / 2, Math.min(r.top + r.height / 2, innerHeight - 2));
    return !topo || topo === b || b.contains(topo);
  }

  /** O ponto onde o cursor está cai sobre o botão? */
  function cursorSobre(botao) {
    const p = NS.cursor.posicao();
    if (!p) return false;
    const el = document.elementFromPoint(p.x, p.y);
    return !!el && (el === botao || botao.contains(el));
  }

  /** Aguarda a interface permitir a emissão (com limite). */
  async function aguardarLiberado() {
    const { tentativas, timeouts } = NS.CONFIG;
    const b = await tentar('Localizar botão Emitir', async () => {
      const el = localizarBotao();
      if (!el || !NS.wait.estaVisivel(el)) throw new Error('botão "Emitir (e)" não encontrado/visível');
      return el;
    }, tentativas.localizar, tentativas.intervalo);
    b.scrollIntoView({ block: 'center', behavior: 'instant' });
    await esperarPor(() => liberado(b), { timeout: timeouts.habilitar, descricao: 'botão Emitir liberado (habilitado e sem sobreposição)' });
    return b;
  }

  /**
   * Leva o cursor DIRETAMENTE ao Emitir, confirma que está sobre ele e clica uma única vez.
   * @returns {Promise<{clicado:boolean}>}
   */
  async function clicar(botao) {
    if (!ehEmitir(botao)) throw new Error('o elemento selecionado não é o botão "Emitir (e)" — clique cancelado');
    await NS.aviso.fecharSePresente({ janela: 0 });
    await NS.cursor.moverPara(botao);
    await dormir(150);
    if (!cursorSobre(botao)) throw new Error('o cursor não ficou sobre o botão Emitir — clique cancelado');
    if (NS.CONFIG.emitir.acao === 'posicionar') {
      NS.log.info('Ação "posicionar": cursor sobre Emitir (e); clique NÃO realizado.');
      return { clicado: false };
    }
    await NS.cursor.clicar();
    if (!liberado(botao) || !ehEmitir(botao)) throw new Error('o botão Emitir deixou de estar liberado imediatamente antes do clique');
    NS.dom.dispararClique(botao);
    return { clicado: true };
  }

  NS.botaoEmitir = { ehEmitir, localizarBotao, aguardarLiberado, clicar };
})();
