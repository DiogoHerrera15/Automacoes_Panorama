@echo off
rem Instala a Central de Automacoes e todas as automacoes (usuario atual; nao precisa de administrador).
rem Pode rodar de novo: atualiza os programas e preserva dados e configuracoes.
chcp 65001 >nul
title Central de Automacoes - instalacao
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Instalacao\instalar.ps1" %*
echo.
pause
