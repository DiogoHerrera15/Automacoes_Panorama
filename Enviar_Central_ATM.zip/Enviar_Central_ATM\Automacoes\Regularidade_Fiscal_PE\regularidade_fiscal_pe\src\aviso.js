/*
 * Aviso inicial da SEFAZ-PE (modal "Atenção! Extrato Fronteiras ... Fechar").
 * Pode aparecer ou não: a detecção tem janela de tempo limitada e nunca bloqueia a automação.
 */
(function () {
  'use strict';
  const NS = (window.EFiscoCRF = window.EFiscoCRF || {});
  const { dormir, esperarOuNulo } = NS.wait;
  const { norm } = NS.dom;

  /**
   * Procura um botão "Fechar" visível que pertença a um contêiner de aviso
   * (contêiner = ancestral cujo texto contém uma das frases configuradas).
   * @returns {{botao:Element, container:Element}|null}
   */
  function localizar() {
    const { textoBotao, textosDoAviso } = NS.CONFIG.aviso;
    for (const botao of NS.dom.clicaveisPorTexto(textoBotao)) {
      let el = botao.parentElement;
      for (let nivel = 0; nivel < 12 && el && el !== document.body && el !== document.documentElement; nivel++, el = el.parentElement) {
        const t = norm(el.textContent);
        if (t.length > 3000) break; // chegou a um bloco grande demais para ser o aviso
        if (textosDoAviso.some((frase) => t.includes(frase))) return { botao, container: el };
      }
    }
    return null;
  }

  const desapareceu = (a) => !a.container.isConnected || !NS.wait.estaVisivel(a.container) || !NS.wait.estaVisivel(a.botao);

  /**
   * Fecha o aviso se ele existir.
   * @param {{janela?:number}} opcoes  janela = ms a aguardar o aparecimento (0 = só verifica agora)
   * @returns {Promise<{presente:boolean, fechado:boolean, quantidade:number}>}
   */
  async function fecharSePresente({ janela } = {}) {
    const cfg = NS.CONFIG.aviso;
    const espera = janela === undefined ? cfg.janelaDeteccao : janela;
    let quantidade = 0;

    for (let rodada = 0; rodada < 3; rodada++) { // até 3 avisos em sequência
      let aviso = localizar();
      if (!aviso && espera > 0) {
        aviso = await esperarOuNulo(localizar, { timeout: rodada === 0 ? espera : 700, descricao: 'aviso inicial' });
      }
      if (!aviso) break;

      NS.log.info(`Aviso inicial detectado: "${norm(aviso.container.textContent).slice(0, 70)}..."`);
      let fechado = false;
      for (let t = 1; t <= cfg.tentativasFechar && !fechado; t++) {
        if (desapareceu(aviso)) { fechado = true; break; } // confirma ANTES de repetir o clique
        await NS.cursor.moverPara(aviso.botao);
        await NS.cursor.clicar();
        NS.dom.dispararClique(aviso.botao);
        NS.log.info(`Clique em "${cfg.textoBotao}" realizado (tentativa ${t}/${cfg.tentativasFechar}). Verificando...`);
        fechado = !!(await esperarOuNulo(() => desapareceu(aviso), { timeout: NS.CONFIG.timeouts.confirmacao, descricao: 'fechamento do aviso' }));
        if (!fechado) NS.log.aviso('O aviso ainda está visível após o clique.');
      }
      if (!fechado) throw new Error('Não foi possível fechar o aviso inicial após ' + cfg.tentativasFechar + ' tentativa(s).');
      quantidade++;
      NS.log.ok('Aviso inicial fechado e confirmado (não está mais visível).');
      await dormir(350); // pequena pausa natural; a página principal é validada em seguida
    }
    if (quantidade === 0) NS.log.info('Nenhum aviso inicial presente — seguindo normalmente.');
    return { presente: quantidade > 0, fechado: true, quantidade };
  }

  NS.aviso = { localizar, fecharSePresente };
})();
