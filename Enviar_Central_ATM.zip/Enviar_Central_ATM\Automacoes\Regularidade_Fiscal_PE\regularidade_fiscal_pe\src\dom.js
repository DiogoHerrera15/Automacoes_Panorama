/*
 * Utilitários de DOM: localização de campos pelo RÓTULO visível (estável) e clique "de verdade"
 * (sequência completa de eventos de ponteiro + click).
 */
(function () {
  'use strict';
  const NS = (window.EFiscoCRF = window.EFiscoCRF || {});

  /** minúsculas, sem acentos, sem "*", sem ":" e com espaços colapsados. */
  const norm = (s) => String(s == null ? '' : s)
    .normalize('NFD').replace(/[̀-ͯ]/g, '')
    .toLowerCase().replace(/[*:]/g, ' ').replace(/\s+/g, ' ').trim();

  const visivel = (el) => NS.wait.estaVisivel(el);

  /**
   * Nós (elementos "folha" ou nós de texto soltos) cujo conteúdo normalizado é exatamente `texto`.
   * Nós de texto cobrem páginas em que o rótulo não tem elemento próprio (ex.: "Rótulo:<br><select>").
   */
  function rotulosPorTexto(texto) {
    const alvo = norm(texto);
    const achados = [];
    const candidatos = document.querySelectorAll('label, legend, th, td, span, div, p, b, strong, font');
    for (const el of candidatos) {
      if (el.closest('#efisco-cursor-host, #efisco-painel-host')) continue;
      if (norm(el.textContent) !== alvo) continue;
      if ([...el.children].some((f) => norm(f.textContent) === alvo)) continue; // só o mais interno
      achados.push(el);
    }
    const caminhante = document.createTreeWalker(document.body || document.documentElement, NodeFilter.SHOW_TEXT);
    for (let n = caminhante.nextNode(); n; n = caminhante.nextNode()) {
      if (norm(n.nodeValue) !== alvo) continue;
      const pai = n.parentElement;
      if (!pai || pai.closest('#efisco-cursor-host, #efisco-painel-host, script, style')) continue;
      if (achados.includes(pai)) continue;
      achados.push(n);
    }
    return achados;
  }

  /**
   * Localiza o controle (select/input) associado ao rótulo `texto`.
   * Estratégias, em ordem: label.control → for= → aria-labelledby → 1º controle que
   * SEGUE o rótulo no mesmo bloco (subindo até 5 níveis).
   * @param {string} texto  rótulo visível
   * @param {'select'|'input'} tipo
   */
  function controlePorRotulo(texto, tipo) {
    const ehTipo = (el) => el && el.matches && (tipo === 'select'
      ? el.matches('select')
      : el.matches('input:not([type=hidden]):not([type=button]):not([type=submit]):not([type=checkbox]):not([type=radio]), textarea'));

    for (const r of rotulosPorTexto(texto)) {
      if (r.nodeType === 1) {
        if (r.control && ehTipo(r.control)) return r.control;
        const por = r.getAttribute('for');
        if (por) { const el = document.getElementById(por); if (ehTipo(el)) return el; }
        if (r.id) {
          const el = document.querySelector(`[aria-labelledby~="${CSS.escape(r.id)}"]`);
          if (ehTipo(el)) return el;
        }
      }
      let bloco = r.nodeType === 1 ? r : r.parentElement;
      for (let nivel = 0; nivel < 5 && bloco; nivel++) {
        if (r.nodeType === 1) bloco = bloco.parentElement; // elemento: começa pelo pai; texto: já parte do pai
        if (!bloco || bloco === document.documentElement) break;
        const lista = [...bloco.querySelectorAll(tipo === 'select' ? 'select' : 'input, textarea')].filter(ehTipo);
        const depois = lista.find((c) => r.compareDocumentPosition(c) & Node.DOCUMENT_POSITION_FOLLOWING);
        if (depois) return depois;
        if (r.nodeType !== 1) bloco = bloco.parentElement;
      }
    }
    return null;
  }

  /** Controle por seletor CSS (se configurado) ou pelo rótulo. */
  function localizarControle({ seletor, rotulo, tipo }) {
    if (seletor) {
      const el = document.querySelector(seletor);
      if (el) return el;
    }
    return controlePorRotulo(rotulo, tipo);
  }

  /**
   * Elementos clicáveis visíveis cujo texto é `texto` (ou "texto (x)", padrão de atalho do e-Fisco,
   * ex.: "Fechar (r)").
   */
  function clicaveisPorTexto(texto, raiz = document) {
    const alvo = norm(texto);
    const sel = 'button, a, input[type=button], input[type=submit], [role=button], [onclick], span, div, td';
    const out = [];
    for (const el of raiz.querySelectorAll(sel)) {
      if (el.closest('#efisco-cursor-host, #efisco-painel-host')) continue;
      const t = el.tagName === 'INPUT' ? el.value : el.textContent;
      const nt = norm(t);
      if ((nt !== alvo && !(nt.startsWith(alvo + ' (') && nt.length <= alvo.length + 5)) || !visivel(el)) continue;
      if ([...el.children].some((f) => norm(f.textContent) === nt && visivel(f))) continue; // só o mais interno
      out.push(el);
    }
    return out;
  }

  /** Sequência de eventos de um clique real. Dispara o clique UMA única vez. */
  function dispararClique(el) {
    const r = el.getBoundingClientRect();
    const base = { bubbles: true, cancelable: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2, button: 0 };
    try { el.dispatchEvent(new PointerEvent('pointerdown', { ...base, pointerType: 'mouse', isPrimary: true })); } catch (_) {}
    el.dispatchEvent(new MouseEvent('mousedown', base));
    if (el.focus) el.focus({ preventScroll: true });
    try { el.dispatchEvent(new PointerEvent('pointerup', { ...base, pointerType: 'mouse', isPrimary: true })); } catch (_) {}
    el.dispatchEvent(new MouseEvent('mouseup', base));
    el.click(); // gera o evento 'click' (e aciona o comportamento padrão de links/botões)
  }

  NS.dom = { norm, visivel, rotulosPorTexto, controlePorRotulo, localizarControle, clicaveisPorTexto, dispararClique };
})();
