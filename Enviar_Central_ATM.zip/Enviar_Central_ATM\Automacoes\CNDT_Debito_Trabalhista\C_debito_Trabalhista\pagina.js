// Interação com a página do TST: localizar elementos, esperar com limite de tempo,
// clicar (com o cursor visual), digitar de forma humanizada, escrever em campos e mostrar
// o aviso na tela. Não decide o fluxo (isso é o content.js).

(function (raiz) {
  const { CONFIG } = raiz.CNDT;
  const S = CONFIG.SELETORES;

  const log = (...a) => console.log(CONFIG.PREFIXO_LOG, ...a);
  const aviso = (...a) => console.warn(CONFIG.PREFIXO_LOG, ...a);
  const dormir = (ms) => new Promise((r) => setTimeout(r, ms));

  // Repete `teste` até devolver algo verdadeiro ou estourar `limite`. Devolve o valor ou null.
  async function esperar(teste, limite, intervalo = CONFIG.TEMPOS.intervaloVerificacao) {
    const fim = Date.now() + limite;
    for (;;) {
      try {
        const r = teste();
        if (r) return r;
      } catch (e) {
        aviso('Erro durante a espera (segue tentando):', e);
      }
      if (Date.now() >= fim) return null;
      await dormir(intervalo);
    }
  }

  function visivel(el) {
    if (!el || !el.isConnected) return false;
    const st = getComputedStyle(el);
    return st.display !== 'none' && st.visibility !== 'hidden' && el.getClientRects().length > 0;
  }

  // Pode receber digitação: visível, habilitado e não somente-leitura.
  function utilizavel(el) {
    return visivel(el) && !el.disabled && !el.readOnly && el.getAttribute('aria-disabled') !== 'true';
  }

  // O campo "Informe o número do CNPJ / CPF": pelo id; se o id mudar, pelos seletores de
  // reserva; por último, pelo texto do rótulo (label for=... ou o input logo depois dele).
  function campoDocumento() {
    for (const sel of S.campoDocumento) {
      const el = document.querySelector(sel);
      if (el) return el;
    }
    for (const label of document.querySelectorAll('label')) {
      if (!S.textoRotuloDocumento.test(label.textContent)) continue;
      const alvo = label.htmlFor ? document.getElementById(label.htmlFor) : label.querySelector('input');
      if (alvo) return alvo;
      const prox = label.parentElement && label.parentElement.querySelector('input[type="text"], input:not([type])');
      if (prox) return prox;
    }
    return null;
  }

  // O script do site (/js/app.js) só termina de iniciar o formulário depois de buscar o
  // captcha em /api/captcha; a imagem vira "data:image/...". Isso indica página completa.
  function siteIniciado() {
    const img = document.querySelector(S.imagemCaptcha);
    return !!(img && /^data:image\//.test(img.getAttribute('src') || ''));
  }

  function desafioExterno() {
    return document.querySelector(S.desafioExterno);
  }

  // Escreve o valor pelo "setter" nativo (funciona mesmo se algum framework vigiar o campo)
  // e dispara os eventos de digitação. A máscara do site roda no "keyup".
  function escreverNoCampo(campo, valor) {
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
    setter.call(campo, valor);
    campo.dispatchEvent(new Event('input', { bubbles: true }));
    const ultimo = valor.slice(-1) || 'Backspace';
    const tecla = { key: ultimo, bubbles: true, cancelable: true };
    campo.dispatchEvent(new KeyboardEvent('keydown', tecla));
    campo.dispatchEvent(new KeyboardEvent('keyup', tecla));
    campo.dispatchEvent(new Event('change', { bubbles: true }));
  }

  // ---- Clique real, acompanhado pelo cursor visual -------------------------------------
  //
  // O cursor vai até o elemento (rolando a página se preciso), para sobre ele e o clique é
  // disparado exatamente no ponto onde a seta está, com a sequência de eventos de um mouse
  // de verdade. Antes, confere que nada cobre o elemento nesse ponto (um aviso ou janela
  // do site por cima): nesse caso não clica e devolve { ok: false }.
  async function clicar(el) {
    const CURSOR = raiz.CNDT.CURSOR;
    const p = await CURSOR.moverPara(el);
    await dormir(aleatorio(CONFIG.CURSOR.paradaAntesDoCliqueMin, CONFIG.CURSOR.paradaAntesDoCliqueMax));

    // Nada no ponto = ponto fora da tela: não clica "no escuro".
    const atingido = document.elementFromPoint(p.x, p.y);
    if (!atingido) return { ok: false, motivo: 'o elemento ficou fora da área visível da página' };
    if (atingido !== el && !el.contains(atingido)) {
      return { ok: false, motivo: `outro elemento cobre o alvo (${atingido.tagName.toLowerCase()}${atingido.id ? '#' + atingido.id : ''})` };
    }

    const base = { bubbles: true, cancelable: true, composed: true, view: window, clientX: p.x, clientY: p.y, button: 0 };
    const ponteiro = { ...base, pointerId: 1, pointerType: 'mouse', isPrimary: true };
    el.dispatchEvent(new PointerEvent('pointerover', ponteiro));
    el.dispatchEvent(new MouseEvent('mouseover', base));
    el.dispatchEvent(new PointerEvent('pointerdown', { ...ponteiro, buttons: 1 }));
    el.dispatchEvent(new MouseEvent('mousedown', { ...base, buttons: 1 }));
    CURSOR.animarClique(p.x, p.y);
    if (typeof el.focus === 'function') el.focus({ preventScroll: true });
    await dormir(aleatorio(CONFIG.CURSOR.botaoApertadoMin, CONFIG.CURSOR.botaoApertadoMax)); // botão apertado
    el.dispatchEvent(new PointerEvent('pointerup', ponteiro));
    el.dispatchEvent(new MouseEvent('mouseup', base));
    el.dispatchEvent(new MouseEvent('click', base));
    return { ok: true, ponto: p };
  }

  // ---- Digitação humanizada --------------------------------------------------------------

  const D = CONFIG.DIGITACAO;
  const aleatorio = (min, max) => min + Math.random() * (max - min);

  function codigoDaTecla(ch) {
    if (/[0-9]/.test(ch)) return `Digit${ch}`;
    if (/[a-z]/i.test(ch)) return `Key${ch.toUpperCase()}`;
    return { '.': 'Period', '/': 'Slash', '-': 'Minus' }[ch] || '';
  }

  const setterValor = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;

  // Uma tecla, com os eventos na ordem do navegador: keydown > keypress > beforeinput >
  // (valor muda) > input > [tecla apertada 70-130 ms] > keyup. A máscara do site roda no
  // keyup, a cada tecla, como faria com uma pessoa digitando. Respeita o maxlength e um
  // preventDefault do site. Devolve quanto tempo a tecla ficou apertada.
  async function pressionar(campo, ch) {
    const tecla = { key: ch, code: codigoDaTecla(ch), bubbles: true, cancelable: true, composed: true };
    const naoBloqueada = campo.dispatchEvent(new KeyboardEvent('keydown', tecla));
    if (naoBloqueada && campo.dispatchEvent(new KeyboardEvent('keypress', { ...tecla, charCode: ch.charCodeAt(0) }))) {
      const max = campo.maxLength > 0 ? campo.maxLength : Infinity;
      if (campo.value.length < max &&
          campo.dispatchEvent(new InputEvent('beforeinput', { inputType: 'insertText', data: ch, bubbles: true, cancelable: true, composed: true }))) {
        setterValor.call(campo, campo.value + ch);
        campo.dispatchEvent(new InputEvent('input', { inputType: 'insertText', data: ch, bubbles: true, composed: true }));
      }
    }
    const apertada = aleatorio(D.teclaApertadaMin, D.teclaApertadaMax);
    await dormir(apertada);
    campo.dispatchEvent(new KeyboardEvent('keyup', tecla));
    return apertada;
  }

  // Onde terminam os blocos do número, para a pausa de "leitura": CNPJ 2.3.3/4-2, CPF 3.3.3-2.
  function fimDosBlocos(tamanho) {
    if (tamanho === 14) return [2, 5, 8, 12];
    if (tamanho === 11) return [3, 6, 9];
    return [];
  }

  // Limpa como uma pessoa: Ctrl+A e Backspace. Devolve true se o campo ficou vazio.
  function apagarCampo(campo) {
    if (!campo.value) return true;
    const ctrlA = { key: 'a', code: 'KeyA', ctrlKey: true, bubbles: true, cancelable: true, composed: true };
    campo.dispatchEvent(new KeyboardEvent('keydown', ctrlA));
    campo.select();
    campo.dispatchEvent(new KeyboardEvent('keyup', ctrlA));
    const bs = { key: 'Backspace', code: 'Backspace', bubbles: true, cancelable: true, composed: true };
    campo.dispatchEvent(new KeyboardEvent('keydown', bs));
    setterValor.call(campo, '');
    campo.dispatchEvent(new InputEvent('input', { inputType: 'deleteContentBackward', bubbles: true, composed: true }));
    campo.dispatchEvent(new KeyboardEvent('keyup', bs));
    return campo.value === '';
  }

  // Digita o texto caractere por caractere, com intervalos variáveis. Se o campo perder o
  // foco no meio (a pessoa clicou em outro lugar), para e devolve { ok: false } em vez de
  // digitar no lugar errado.
  // O intervalo é contado de uma tecla apertada até a próxima (como nos estudos), por isso
  // desconta o tempo em que a tecla ficou apertada.
  async function digitarHumanizado(campo, texto) {
    const caracteres = [...String(texto)];
    const blocos = fimDosBlocos(caracteres.length);
    await dormir(D.esperaAntesDeDigitar * aleatorio(0.8, 1.4));
    for (let i = 0; i < caracteres.length; i++) {
      if (document.activeElement !== campo) {
        return { ok: false, motivo: 'o campo perdeu o foco durante a digitação' };
      }
      const apertada = await pressionar(campo, caracteres[i]);
      if (i === caracteres.length - 1) break;
      let espera = aleatorio(D.intervaloMin, D.intervaloMax) - apertada;
      if (blocos.includes(i + 1)) espera += aleatorio(D.pausaEntreBlocosMin, D.pausaEntreBlocosMax);
      else if (Math.random() < D.chancePausa) espera += aleatorio(D.pausaMin, D.pausaMax);
      await dormir(Math.max(30, espera));
    }
    campo.dispatchEvent(new Event('change', { bubbles: true }));
    return { ok: true };
  }

  // ---- Espera a pessoa digitar (captcha) --------------------------------------------------
  //
  // Só observa: considera apenas eventos com isTrusted = true (teclado/mouse da pessoa) e
  // nunca altera o campo. Resolve quando a pessoa fica `silencio` ms sem digitar com pelo
  // menos `minimo` caracteres no campo. Também termina (sem esperar para sempre) se:
  // a pessoa enviar o formulário ela mesma, o tempo `limite` acabar ou `cancelar()` for chamado.
  // Devolve { ok: true, valor } ou { ok: false, motivo: 'enviado' | 'tempo' | 'cancelado' }.
  // jaDigitando: a pessoa acabou de digitar (ex.: cancelou o clique digitando); a contagem
  // do silêncio começa já, sem esperar uma nova tecla.
  function esperarDigitacaoDoUsuario(campo, { silencio, minimo, limite, jaDigitando = false }, aoDigitar) {
    let cancelar;
    const promessa = new Promise((resolver) => {
      let timerSilencio = null;
      const form = campo.form;
      const terminar = (resultado) => {
        clearTimeout(timerSilencio);
        clearTimeout(timerLimite);
        campo.removeEventListener('input', aoEvento, true);
        campo.removeEventListener('keyup', aoEvento, true);
        if (form) form.removeEventListener('submit', aoEnviar, true);
        resolver(resultado);
      };
      const conferir = () => {
        const valor = campo.value.trim();
        if (valor.length >= minimo) terminar({ ok: true, valor });
      };
      function aoEvento(e) {
        if (!e.isTrusted) return; // só a digitação da pessoa conta
        clearTimeout(timerSilencio);
        if (aoDigitar) aoDigitar(campo.value.trim().length);
        timerSilencio = setTimeout(conferir, silencio);
      }
      function aoEnviar(e) {
        if (e.isTrusted) terminar({ ok: false, motivo: 'enviado' });
      }
      const timerLimite = setTimeout(() => terminar({ ok: false, motivo: 'tempo' }), limite);
      campo.addEventListener('input', aoEvento, true);
      campo.addEventListener('keyup', aoEvento, true);
      if (form) form.addEventListener('submit', aoEnviar, true);
      cancelar = () => terminar({ ok: false, motivo: 'cancelado' });
      if (jaDigitando) timerSilencio = setTimeout(conferir, silencio);
    });
    return { promessa, cancelar };
  }

  // Depois do clique em "Emitir Certidão", espera a resposta do site:
  // - sucesso: o site mostra #secao-sucesso ("Certidão EMITIDA com sucesso.") e baixa o PDF;
  // - erro: o site mostra a mensagem em #mensagens (ex.: verificação incorreta) e troca a imagem.
  // Devolve { tipo: 'sucesso', texto } | { tipo: 'erro', mensagem } | { tipo: 'tempo' }.
  //
  // Uma mensagem de erro que já estava na tela antes do clique (do envio anterior) não conta:
  // só vale um erro novo (texto diferente) ou que reapareceu depois de sumir. Chame
  // estadoDoErro() ANTES do clique e passe o resultado em `erroAntes`.
  function aparente(sel) {
    const el = document.querySelector(sel);
    return el && !el.classList.contains('oculto') && visivel(el) ? el : null;
  }
  function estadoDoErro() {
    const el = aparente(S.mensagensErro);
    return el ? el.textContent.trim() : '';
  }
  async function esperarResultadoDaEmissao(limite, erroAntes = '') {
    let sumiu = !erroAntes;
    const r = await esperar(() => {
      if (aparente(S.secaoSucesso)) {
        return { tipo: 'sucesso', texto: (document.querySelector(S.textoSucesso)?.textContent || '').trim() };
      }
      const texto = estadoDoErro();
      if (!texto) { sumiu = true; return null; }
      if (sumiu || texto !== erroAntes) return { tipo: 'erro', mensagem: texto };
      return null;
    }, limite);
    return r || { tipo: 'tempo' };
  }

  // Botão "Emitir Certidão": pelo id; se mudar, pelo texto do botão.
  function botaoEmitir() {
    const porId = document.querySelector(S.botaoEmitir);
    if (porId) return porId;
    return [...document.querySelectorAll('input[type="submit"], input[type="button"], button')]
      .find((b) => S.textoBotaoEmitir.test(b.value || b.textContent || '')) || null;
  }

  // Aviso fixo no canto superior direito, para a pessoa saber o que a automação fez.
  // tipo: 'info' | 'ok' | 'erro'
  function mostrarAviso(texto, tipo = 'info') {
    const cores = { info: '#1f5fa8', ok: '#1e7b45', erro: '#b3261e' };
    let caixa = document.getElementById('cndt-aviso');
    if (!caixa) {
      caixa = document.createElement('div');
      caixa.id = 'cndt-aviso';
      caixa.setAttribute('role', 'status');
      Object.assign(caixa.style, {
        position: 'fixed', top: '12px', right: '12px', zIndex: 2147483647, maxWidth: '380px',
        padding: '10px 14px', borderRadius: '6px', color: '#fff', font: '13px/1.4 Arial, sans-serif',
        boxShadow: '0 2px 8px rgba(0,0,0,.3)', whiteSpace: 'pre-line', cursor: 'pointer',
      });
      caixa.title = 'Clique para esconder';
      caixa.addEventListener('click', () => caixa.remove());
      document.body.appendChild(caixa);
    }
    caixa.style.background = cores[tipo] || cores.info;
    caixa.textContent = `CNDT (automação)\n${texto}`;
  }

  raiz.CNDT.PAGINA = {
    log, aviso, dormir, esperar, visivel, utilizavel,
    campoDocumento, siteIniciado, desafioExterno, escreverNoCampo, mostrarAviso,
    clicar, apagarCampo, digitarHumanizado, esperarDigitacaoDoUsuario, botaoEmitir, esperarResultadoDaEmissao, estadoDoErro,
  };
})(globalThis);
