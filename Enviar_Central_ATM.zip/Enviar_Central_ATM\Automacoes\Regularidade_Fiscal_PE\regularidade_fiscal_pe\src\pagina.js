/* Identificação da página "Emissão de Certidão de Regularidade Fiscal" e verificação de estabilidade. */
(function () {
  'use strict';
  const NS = (window.EFiscoCRF = window.EFiscoCRF || {});
  const { esperarPor, esperarDocumentoCarregado } = NS.wait;
  const { norm } = NS.dom;

  function hostPermitido() {
    return location.protocol === 'https:' && NS.CONFIG.pagina.hosts.includes(location.hostname);
  }

  /** Existe um botão "Localizar" (ex.: "Localizar (l)")? */
  function temBotaoLocalizar() {
    const alvo = NS.CONFIG.pagina.botaoLocalizar;
    return [...document.querySelectorAll('button, input[type=button], input[type=submit], a, [role=button]')]
      .some((el) => norm(el.tagName === 'INPUT' ? el.value : el.textContent).startsWith(alvo));
  }

  /** Instantâneo (síncrono): o conteúdo atual corresponde à funcionalidade esperada? */
  function inspecionar() {
    const p = NS.CONFIG.pagina;
    const texto = norm(document.body ? document.body.innerText : '');
    const titulo = texto.includes(p.titulo);
    const rotuloTipo = !!NS.dom.controlePorRotulo(p.rotuloTipo, 'select') ||
      !!(NS.CONFIG.seletores.tipoDocumento && document.querySelector(NS.CONFIG.seletores.tipoDocumento));
    const rotuloNumero = !!NS.dom.controlePorRotulo(p.rotuloNumero, 'input') ||
      !!(NS.CONFIG.seletores.numeroDocumento && document.querySelector(NS.CONFIG.seletores.numeroDocumento));
    const localizar = temBotaoLocalizar();
    return { titulo, rotuloTipo, rotuloNumero, localizar, ok: titulo && rotuloTipo && rotuloNumero && localizar };
  }

  /** O caminho da URL sugere a funcionalidade? (apenas para decidir a execução automática) */
  function caminhoProvavel() {
    return norm(decodeURIComponent(location.pathname)).replace(/[^a-z]/g, '').includes(NS.CONFIG.pagina.caminhoProvavel);
  }

  /** Sinais de verificação de segurança (ex.: Cloudflare) ocupando a página. Apenas detecta; nunca interage. */
  function verificacaoDeSegurancaVisivel() {
    const t = norm(document.title);
    if (t.includes('just a moment') || t.includes('um momento') || t.includes('verificando se voce')) return true;
    return !!document.querySelector('#challenge-form, #challenge-running, #cf-challenge-running');
  }

  /**
   * Aguarda a página ficar identificável e ESTÁVEL (as condições se mantêm por 400 ms).
   * Em caso de falha, a mensagem diz exatamente o que faltou.
   */
  async function aguardarPronta() {
    const { timeouts } = NS.CONFIG;
    await esperarDocumentoCarregado(timeouts.paginaPronta);
    let avisouSeguranca = false;
    try {
      await esperarPor(() => {
        if (verificacaoDeSegurancaVisivel() && !avisouSeguranca) {
          avisouSeguranca = true;
          NS.log.aviso('Verificação de segurança detectada na página. Conclua-a manualmente; a automação aguarda e não a contorna.');
        }
        return inspecionar().ok;
      }, { timeout: timeouts.paginaPronta, descricao: 'identificação da página de Emissão de Certidão de Regularidade Fiscal' });
    } catch (e) {
      const i = inspecionar();
      const faltando = [
        !i.titulo && 'título "Emissão de Certidão de Regularidade Fiscal"',
        !i.rotuloTipo && 'campo "Tipo de Documento de Identificação"',
        !i.rotuloNumero && 'campo "Número do Documento de Identificação"',
        !i.localizar && 'botão "Localizar"'
      ].filter(Boolean);
      if (e.message === NS.wait.ERRO_CANCELADO) throw e;
      throw new Error('Página inesperada ou ainda não disponível. Não foram encontrados: ' + (faltando.join('; ') || '—') +
        `. URL: ${location.href} | título: "${document.title}". ` +
        'Se o e-Fisco pediu login gov.br ou uma verificação de segurança, conclua-os manualmente e execute novamente.');
    }
    // estabilidade: a página não pode ter mudado de estado logo em seguida (ex.: recarga parcial)
    await NS.wait.dormir(400);
    if (!inspecionar().ok) {
      await esperarPor(() => inspecionar().ok, { timeout: timeouts.elemento, descricao: 'estabilização da página' });
    }
    return inspecionar();
  }

  NS.pagina = { hostPermitido, inspecionar, caminhoProvavel, aguardarPronta, verificacaoDeSegurancaVisivel };
})();
