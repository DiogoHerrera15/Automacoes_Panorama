/* Campo 1 — "Tipo de Documento de Identificação" (INSCRIÇÃO ESTADUAL / CNPJ / CPF). */
(function () {
  'use strict';
  const NS = (window.EFiscoCRF = window.EFiscoCRF || {});
  const { dormir, esperarPor, tentar } = NS.wait;
  const { norm } = NS.dom;

  const localizarSelect = () => NS.dom.localizarControle({
    seletor: NS.CONFIG.seletores.tipoDocumento, rotulo: NS.CONFIG.pagina.rotuloTipo, tipo: 'select'
  });

  /** Localiza o <select> com novas verificações limitadas; aguarda visível e habilitado. */
  async function localizar() {
    const { tentativas, timeouts } = NS.CONFIG;
    return tentar('Localizar campo "Tipo de Documento"', async () => {
      const sel = localizarSelect();
      if (!sel || !NS.wait.estaVisivel(sel)) throw new Error('campo "Tipo de Documento de Identificação" não encontrado/visível');
      if (sel.disabled) {
        await esperarPor(() => !sel.disabled, { timeout: timeouts.habilitar, descricao: 'habilitação do campo Tipo de Documento' });
      }
      await esperarPor(() => sel.options.length >= 2, { timeout: timeouts.elemento, descricao: 'opções do campo Tipo de Documento' });
      return sel;
    }, tentativas.localizar, tentativas.intervalo);
  }

  const textoAtual = (sel) => { const op = sel.options[sel.selectedIndex]; return op ? norm(op.text) : null; };
  const indiceDe = (sel, tipo) => Array.from(sel.options).findIndex((o) => norm(o.text) === norm(tipo));

  function aplicar(sel, indice) {
    sel.focus({ preventScroll: true });
    sel.selectedIndex = indice;
    sel.dispatchEvent(new Event('input', { bubbles: true }));
    sel.dispatchEvent(new Event('change', { bubbles: true }));
  }

  /**
   * Garante que o <select> esteja em `tipo` (ex.: "CNPJ"), confirmando pelo estado real do elemento.
   * @returns {Promise<{alterado:boolean, tipoFinal:string}>}
   */
  async function selecionar(tipo) {
    const { tentativas, timeouts } = NS.CONFIG;
    let alterado = false;

    await tentar('Selecionar tipo de documento', async (n) => {
      const sel = await localizar(); // re-localiza a cada tentativa (a página pode ter se redesenhado)
      const opcoes = Array.from(sel.options).map((o) => o.text.trim());
      if (n === 1) NS.log.info(`Opções encontradas: ${opcoes.join(' | ')}.`);

      const indice = indiceDe(sel, tipo);
      if (indice < 0) throw new Error(`a opção "${tipo}" não existe (opções: ${opcoes.join(', ')})`);

      const atual = textoAtual(sel);
      NS.log.info(`Opção atualmente selecionada: "${atual}".`);
      if (atual === norm(tipo)) {
        NS.log.ok(`"${tipo}" já está selecionado — nenhuma alteração necessária.`);
        await NS.cursor.moverPara(sel);
        await dormir(400);
        return;
      }

      NS.log.info(`Alterando "${atual}" → "${tipo}"...`);
      await NS.cursor.moverPara(sel);
      await NS.cursor.clicar();
      sel.focus({ preventScroll: true });

      const dropdown = await NS.cursor.abrirDropdownVisual(sel); // réplica visual (o popup nativo não é acessível a scripts)
      const item = dropdown.itens[indice];
      await NS.cursor.moverPara(item.ponto);
      dropdown.destacar(indice);
      await NS.cursor.clicar();
      aplicar(sel, indice);                                       // ação efetiva, no elemento real
      await dropdown.fechar();

      await esperarPor(() => textoAtual(sel) === norm(tipo), { timeout: timeouts.confirmacao, descricao: `confirmação da opção ${tipo}` });
      await dormir(300);
      const fim = textoAtual(localizarSelect() || sel);
      if (fim !== norm(tipo)) throw new Error(`a página reverteu a seleção (esperado ${tipo}, atual ${fim})`);
      alterado = true;
    }, tentativas.selecionar, tentativas.intervalo);

    const sel = await localizar();
    return { alterado, tipoFinal: sel.options[sel.selectedIndex].text.trim(), select: sel };
  }

  /** Leitura de estado (para validação final). */
  function tipoSelecionado() {
    const sel = localizarSelect();
    return sel ? textoAtual(sel) : null;
  }

  NS.campoTipoDocumento = { localizar, selecionar, tipoSelecionado };
})();
