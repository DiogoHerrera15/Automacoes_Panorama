/*
 * Carrega os content scripts DENTRO de uma página de teste (mock em localhost) com um shim mínimo de
 * chrome.storage (persistente em sessionStorage, para sobreviver à recarga de página) e chrome.runtime.
 * Uso (console do navegador, na página do mock):
 *   const r = await (await fetch('/testes/e2e-loader.js')).text(); await (0, eval)(r);  → window.__e2e()
 * Serve só para teste local: a extensão real não usa este arquivo.
 * Configurações de teste (ex.: tempos menores) ficam em sessionStorage['testcfg'] (JSON, mesclado ao CONFIG).
 */
(async () => {
  const ARQUIVOS = ['ponte-dialogos', 'config', 'logger', 'wait', 'dom', 'estado', 'documento', 'arquivos', 'cursor', 'painel', 'pagina', 'aviso',
    'campo-tipo-documento', 'campo-numero-documento', 'job', 'cloudflare', 'guarda-localizar', 'botao-localizar', 'tela-captcha', 'resultado', 'botao-emitir', 'observador', 'entrega', 'main'];
  const ler = () => JSON.parse(sessionStorage.getItem('mem') || '{}');
  const gravar = (m) => sessionStorage.setItem('mem', JSON.stringify(m));
  window.__mem = new Proxy({}, { get: (_, k) => ler()[k] });
  window.chrome = {
    storage: { onChanged: { addListener() {} }, local: {
      get(k, cb) { const m = ler(); const ks = Array.isArray(k) ? k : [k]; const o = {}; ks.forEach((x) => { if (x in m) o[x] = m[x]; }); (cb || (() => {}))(o); },
      set(o, cb) { const m = ler(); Object.assign(m, o); gravar(m); cb && cb(); },
      remove(k, cb) { const m = ler(); (Array.isArray(k) ? k : [k]).forEach((x) => delete m[x]); gravar(m); cb && cb(); }
    } },
    runtime: {
      onMessage: { addListener() {} },
      getManifest: () => ({ version: 'teste' }),
      lastError: undefined,
      // Simula o background: ITEM_HELLO devolve o item de teste (sessionStorage 'helloItem'); registra o que o content script envia.
      sendMessage(msg, cb) {
        const reg = JSON.parse(sessionStorage.getItem('msgs') || '[]'); reg.push(msg); sessionStorage.setItem('msgs', JSON.stringify(reg));
        let r = {};
        if (msg.tipo === 'ITEM_HELLO') { const it = sessionStorage.getItem('helloItem'); r = it ? { item: JSON.parse(it), pasta: 'P' } : {}; }
        cb && cb(r);
      }
    },
    // onChanged: sem eventos neste shim
    __x: 0
  };
  const mesclar = (a, b) => { for (const k in b) { if (b[k] && typeof b[k] === 'object' && !Array.isArray(b[k])) mesclar(a[k] = a[k] || {}, b[k]); else a[k] = b[k]; } };
  for (const a of ARQUIVOS) {
    if (a === 'main') {
      const NS = window.EFiscoCRF;
      NS.CONFIG.pagina.hosts.push(location.hostname);
      if (location.protocol !== 'https:') NS.pagina.hostPermitido = () => true; // só no mock local (http)
    }
    const codigo = await (await fetch(`${window.__BASE || ''}/src/${a}.js`)).text();
    (0, eval)(codigo + `\n//# sourceURL=ext/${a}.js`);
    if (a === 'config') mesclar(window.EFiscoCRF.CONFIG, JSON.parse(sessionStorage.getItem('testcfg') || '{}'));
  }
  window.__e2e = () => window.EFiscoCRF.executar('teste');
  return 'carregado';
})();
