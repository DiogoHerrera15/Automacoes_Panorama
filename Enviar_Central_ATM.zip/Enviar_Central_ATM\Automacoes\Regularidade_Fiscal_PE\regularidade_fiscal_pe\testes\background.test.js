/* Carrega o background.js REAL num ambiente de service worker simulado e exercita as mensagens. Execute: node testes/background.test.js */
'use strict';
const fs = require('fs'); const path = require('path'); const vm = require('vm'); const assert = require('assert');
const raiz = path.join(__dirname, '..');
const mem = {}; const ouvintes = {}; const chamadas = { tabs: [], janelas: [], downloads: [] }; let anonimo = true;
const ev = (nome) => ({ addListener: (f) => { (ouvintes[nome] = ouvintes[nome] || []).push(f); } });
const chromeFalso = {
  storage: { local: {
    get: async (k) => { const ks = Array.isArray(k) ? k : [k]; const o = {}; ks.forEach((x) => { if (x in mem) o[x] = JSON.parse(JSON.stringify(mem[x])); }); return o; },
    set: async (o) => Object.entries(o).forEach(([k, v]) => { mem[k] = JSON.parse(JSON.stringify(v)); }),
    remove: async (k) => (Array.isArray(k) ? k : [k]).forEach((x) => delete mem[x]) } },
  tabs: { onCreated: ev('tabs.onCreated'), onUpdated: ev('tabs.onUpdated'), onRemoved: ev('tabs.onRemoved'),
    get: async (id) => ({ id, incognito: true }), query: async () => [], create: async (o) => { chamadas.tabs.push(o.url); return { id: 8 }; }, update: async () => ({}), remove: async () => {} },
  extension: { isAllowedIncognitoAccess: (cb) => cb(anonimo) },
  windows: { onCreated: ev('windows.onCreated'), update: async () => {}, create: async (o) => { chamadas.janelas.push(o); return { id: 70, tabs: [{ id: 7 }] }; } },
  downloads: { onCreated: ev('downloads.onCreated'), onChanged: ev('downloads.onChanged'), onDeterminingFilename: ev('downloads.onDeterminingFilename'),
    download: async (o) => { chamadas.downloads.push(o); return 1; }, search: async () => [] },
  alarms: { onAlarm: ev('alarms.onAlarm'), create: async () => {}, clear: async () => {} },
  runtime: { id: 'abc', onMessage: ev('runtime.onMessage'), getURL: (p) => 'chrome-extension://abc/' + p },
  action: { onClicked: ev('action.onClicked') }
};
const sandbox = { chrome: chromeFalso, console, setTimeout, clearTimeout, fetch: async () => ({ ok: true, arrayBuffer: async () => new ArrayBuffer(0) }), btoa, Uint8Array, JSON, Promise, Date, Math };
sandbox.self = sandbox; sandbox.globalThis = sandbox;
sandbox.importScripts = (...arqs) => arqs.forEach((a) => vm.runInContext(fs.readFileSync(path.join(raiz, a), 'utf8'), ctx, { filename: a }));
const ctx = vm.createContext(sandbox);
const msg = (m, sender = {}) => new Promise((res) => { const f = ouvintes['runtime.onMessage'][0]; const manteve = f(m, sender, res); if (!manteve) res('(sem resposta)'); });

(async () => {
  let ok = 0; const t = async (n, fn) => { try { await fn(); ok++; console.log('  ✔', n); } catch (e) { console.error('  ✘', n, '\n    ', e.message); process.exitCode = 1; } };
  vm.runInContext(fs.readFileSync(path.join(raiz, 'background.js'), 'utf8'), ctx, { filename: 'background.js' });
  await t('carrega sem erros e registra todos os ouvintes do MV3', async () => {
    ['runtime.onMessage', 'downloads.onDeterminingFilename', 'downloads.onChanged', 'alarms.onAlarm', 'tabs.onRemoved', 'tabs.onUpdated', 'action.onClicked'].forEach((n) => assert.ok(ouvintes[n] && ouvintes[n].length, n));
  });
  await t('sem "Permitir no modo anônimo": JOB_INICIAR é recusado e nada é aberto', async () => {
    anonimo = false;
    const r = await msg({ tipo: 'JOB_INICIAR', pasta: 'P', itens: [{ id: 'L1', original: '12345678909', tipo: 'CPF', digitos: '12345678909', formatado: '123.456.789-09' }] });
    assert.ok(!r.ok); assert.strictEqual(r.codigo, 'incognito-nao-permitido');
    assert.strictEqual(chamadas.janelas.length + chamadas.tabs.length, 0);
    assert.strictEqual((await msg({ tipo: 'INCOGNITO_STATUS' })).permitido, false);
    anonimo = true; assert.strictEqual((await msg({ tipo: 'INCOGNITO_STATUS' })).permitido, true);
  });
  await t('JOB_INICIAR pela mensagem real abre o e-Fisco SEMPRE em janela anônima e ITEM_HELLO só atende a aba do job', async () => {
    const itens = [{ id: 'L1', original: '12345678909', tipo: 'CPF', digitos: '12345678909', formatado: '123.456.789-09' }];
    const r = await msg({ tipo: 'JOB_INICIAR', pasta: 'PASTA/TESTE', itens });
    assert.ok(r.ok, JSON.stringify(r)); assert.strictEqual(chamadas.janelas.length, 1); assert.strictEqual(chamadas.janelas[0].incognito, true);
    assert.strictEqual(chamadas.janelas[0].url, 'https://efisco.sefaz.pe.gov.br/sfi_trb_gcc/PREmitirCertidaoRegularidadeFiscalMovel'); assert.strictEqual(chamadas.tabs.length, 0, 'nenhuma aba comum');
    assert.strictEqual(mem.efisco_job.pasta, 'PASTA_TESTE');
    assert.strictEqual(Object.keys(await msg({ tipo: 'ITEM_HELLO' }, { tab: { id: 99 } })).length, 0, 'aba que não é do job não recebe documento');
    const h = await msg({ tipo: 'ITEM_HELLO' }, { tab: { id: 7 } }); assert.strictEqual(h.item.tipo, 'CPF');
  });
  await t('ITEM_FINAL → entrega-url → download usa Downloads/PASTA_TESTE/CPF_..._CERTIDAO.pdf (uniquify)', async () => {
    const pdf = Buffer.from('%PDF-1.4\n' + 'x'.repeat(400));
    sandbox.fetch = async () => ({ ok: true, status: 200, arrayBuffer: async () => pdf.buffer.slice(pdf.byteOffset, pdf.byteOffset + pdf.length) });
    await msg({ tipo: 'ITEM_FINAL', itemId: 'L1', status: 'entrega-url', urlPdf: 'https://efisco.sefaz.pe.gov.br/c.pdf' });
    assert.strictEqual(chamadas.downloads.length, 1); assert.strictEqual(chamadas.downloads[0].filename, 'PASTA_TESTE/CPF_12345678909_CERTIDAO.pdf'); assert.strictEqual(chamadas.downloads[0].conflictAction, 'uniquify');
  });
  await t('onDeterminingFilename devolve a resposta assíncrona (return true) e chama suggest', async () => {
    let sugerido = 'nada'; const f = ouvintes['downloads.onDeterminingFilename'][0];
    const r = f({ id: 5, url: 'https://exemplo.com/x.zip', mime: 'application/zip' }, (s) => { sugerido = s; });
    assert.strictEqual(r, true); await new Promise((x) => setTimeout(x, 30)); assert.strictEqual(sugerido, undefined);
  });
  await t('ABRIR_CONFIG abre a página de configurações desta extensão', async () => {
    const antes = chamadas.tabs.length; await msg({ tipo: 'ABRIR_CONFIG' }); assert.strictEqual(chamadas.tabs[antes], 'chrome://extensions/?id=abc');
  });
  await t('PARAR pela mensagem real encerra a execução', async () => {
    await msg({ tipo: 'JOB_PARAR' }); assert.strictEqual(mem.efisco_job.estado, 'parado');
  });
  console.log(`\n${ok} teste(s) ok`);
})();
