/*
 * Orquestrador de UM documento (16 etapas). A página recarrega no Localizar/Prosseguir/Emitir; o progresso fica em
 * chrome.storage (estado.js) e cada página nova retoma do ponto certo. A fila de documentos é do background (fila.js).
 *
 *   FORMULÁRIO     1 Aviso · 2 Página · 3 Tipo do documento (CPF/CNPJ/IE) · 4 Número · 5 Validação   (Fase 1)
 *                  6 Segurança (Cloudflare, só leitura) · 7 LOCALIZAR (1 clique autorizado)
 *   TELA CAPTCHA   8 Identificar a tela intermediária · 9 PROSSEGUIR (1 clique; só volta, não resolve o CAPTCHA)
 *   RETORNO        10 Voltou à página inicial · 11 Reverificar/refazer campos · 12 Segurança NOVA (token novo)
 *   EMITIR         13 EMITIR (1 clique) · 14 Observar o comportamento · 15 Entrega do PDF (observa; não confirma nada)
 *
 * Ao final, o resultado vai para a fila (job.final): entrega-download | entrega-url | sem_certidao | captcha | erro.
 */
(function () {
  'use strict';
  const NS = (window.EFiscoCRF = window.EFiscoCRF || {});
  if (NS.iniciado) return; // evita dupla injeção
  NS.iniciado = true;

  const TOTAL = 15;
  const entre = ([a, b]) => a + Math.random() * (b - a);

  /** Erro com destino conhecido na fila. status: 'erro' | 'sem_certidao' | 'captcha'; recuperavel ⇒ nova tentativa. */
  class FluxoErro extends Error {
    constructor(msg, status = 'erro', recuperavel = false) { super(msg); this.status = status; this.recuperavel = recuperavel; }
  }
  const definitivo = (msg) => new FluxoErro(msg, 'sem_certidao', false);
  const captcha = (msg) => new FluxoErro(msg, 'captcha', false);

  function lerChave(chave, padrao) {
    return new Promise((resolve) => {
      try { chrome.storage.local.get(chave, (d) => resolve((d && d[chave]) || padrao)); }
      catch (_) { resolve(padrao); }
    });
  }

  /** Executa uma etapa com mensagens padronizadas; falhas indicam o número e o nome da etapa. */
  async function etapa(n, nome, fn) {
    await NS.job.verificarPausa();                                          // PAUSAR segura o avanço entre etapas
    if (n > 1) await NS.wait.dormir(entre(NS.CONFIG.pausaEntreEtapas));     // pausa natural entre etapas
    NS.log.info(`[Etapa ${n}/${TOTAL}] ${nome}...`);
    NS.job.status({ etapa: `${n}/${TOTAL} ${nome}` });
    try {
      return await fn();
    } catch (e) {
      if (e.message === NS.wait.ERRO_CANCELADO) throw e;
      const msg = `Falha na etapa ${n}/${TOTAL} (${nome}): ${e.message}`;
      throw e instanceof FluxoErro ? new FluxoErro(msg, e.status, e.recuperavel) : new FluxoErro(msg, 'erro', true);
    }
  }

  /** Velocidades escolhidas no painel (se houver) sobrepõem as de config.js. */
  async function aplicarVelocidades() {
    const st = NS.CONFIG.storage;
    const m = Number(await lerChave(st.velMouse, 0));
    const d = Number(await lerChave(st.velDigitacao, 0));
    if (m > 0) NS.CONFIG.velocidade.mouse = m;
    if (d > 0) NS.CONFIG.velocidade.digitacao = d;
    NS.log.info(`Velocidade — mouse ×${NS.CONFIG.velocidade.mouse} · digitação ×${NS.CONFIG.velocidade.digitacao} (maior = mais lento).`);
  }

  /** Documento do item da fila (ou o CNPJ de teste, em execução avulsa). */
  async function prepararDocumento(item) {
    const bruto = item ? item.digitos : await lerChave(NS.CONFIG.storage.cnpj, NS.CONFIG.cnpjTeste);
    const c = NS.documento.classificar(bruto, item ? item.tipo : 'CNPJ');
    if (!c.tipo) throw new FluxoErro('documento sem tipo definido', 'erro', false);
    if (!c.valido && !(item && item.forcado)) throw new FluxoErro(`documento inválido: ${c.motivo}`, 'erro', false);
    if (!c.valido) NS.log.aviso(`Documento com formato inválido (${c.motivo}) — processado a pedido do usuário.`);
    const doc = { tipo: c.tipo, digitos: c.digitos, formatado: c.formatado, rotulo: NS.documento.ROTULO[c.tipo] };
    NS.log.ok(`Documento: ${doc.rotulo} ${doc.formatado} (${doc.digitos}).`);
    return doc;
  }

  /** Envolve um fluxo: exclusão mútua, cancelamento, relato à fila e limpeza de estado em falha. */
  async function rodar(nome, fn) {
    if (NS.ocupado) {
      NS.log.aviso('Já existe uma execução em andamento — ignorando novo pedido.');
      return { ok: false, erro: 'execução em andamento' };
    }
    NS.ocupado = true;
    NS.ultimoSucesso = false;
    NS.wait.novoToken();
    try {
      NS.painel.iniciar();
      NS.log.info(`Início: ${nome} em ${location.href}`);
      if (!NS.pagina.hostPermitido()) {
        throw new FluxoErro(`Domínio inesperado: ${location.hostname}. Esperado: ${NS.CONFIG.pagina.hosts.join(', ')}.`, 'erro', false);
      }
      await aplicarVelocidades();
      NS.guarda.ativar();
      const r = await fn();
      NS.ultimoSucesso = true;
      return { ok: true, ...r };
    } catch (e) {
      const msg = e.message || String(e);
      const cancelado = msg === NS.wait.ERRO_CANCELADO;
      if (cancelado) NS.log.aviso('Execução interrompida pelo usuário.');
      else NS.log.erro(msg);
      await NS.estado.limpar();
      NS.log.resultado({ sucesso: false, erro: msg });
      if (!cancelado) {
        const st = e instanceof FluxoErro ? e : new FluxoErro(msg, 'erro', true); // erro inesperado ⇒ recuperável (tentativas limitadas)
        await NS.job.final({ status: st.status, recuperavel: st.recuperavel, mensagem: msg });
      }
      return { ok: false, erro: msg };
    } finally {
      NS.guarda.desativar();
      NS.ocupado = false;
      setTimeout(() => { try { NS.cursor.ocultar(); } catch (_) {} }, 2500);
    }
  }

  // ───────────────────────── Fase 1 (etapas 1–5) — lógica preservada, agora por tipo de documento ─────────────────────────
  async function preencherFormulario(doc) {
    await etapa(1, 'Aviso inicial', async () => {
      await NS.wait.esperarDocumentoCarregado(NS.CONFIG.timeouts.paginaPronta);
      const r = await NS.aviso.fecharSePresente();
      NS.log.ok(r.presente ? `Aviso(s) fechado(s): ${r.quantidade}.` : 'Sem aviso inicial.');
    });

    await etapa(2, 'Identificar a página de Certidão de Regularidade Fiscal', async () => {
      await NS.pagina.aguardarPronta();
      NS.log.ok('Página "Emissão de Certidão de Regularidade Fiscal" identificada e estável.');
      await NS.aviso.fecharSePresente({ janela: 0 }); // um aviso tardio não pode bloquear os campos
    });

    const tipo = await etapa(3, `Selecionar "${doc.rotulo}" em Tipo de Documento`, async () => {
      const r = await NS.campoTipoDocumento.selecionar(doc.rotulo);
      NS.log.ok(r.alterado ? `Tipo de Documento: "${r.tipoFinal}" selecionado e confirmado.`
                           : `Tipo de Documento: "${r.tipoFinal}" já estava selecionado.`);
      return r;
    });

    const num = await etapa(4, 'Preencher Número do Documento', async () => {
      await NS.aviso.fecharSePresente({ janela: 0 });
      const r = await NS.campoNumeroDocumento.preencher(doc);
      NS.log.ok(`Número do Documento: "${r.valorFinal}" ${r.alterado ? 'digitado e confirmado' : 'já estava preenchido'}.`);
      return r;
    });

    await etapa(5, 'Validação dos campos', async () => {
      await NS.wait.dormir(300);
      const tipoFinal = NS.campoTipoDocumento.tipoSelecionado();
      const valorFinal = NS.campoNumeroDocumento.valorAtual();
      if (tipoFinal !== NS.dom.norm(doc.rotulo)) {
        throw new Error(`o Tipo de Documento não está mais em "${doc.rotulo}" (atual: "${tipoFinal}")`);
      }
      if (NS.documento.soDigitos(valorFinal) !== doc.digitos) {
        throw new Error(`o Número do Documento não confere (esperado ${doc.digitos}, atual "${valorFinal}")`);
      }
      if (!NS.pagina.inspecionar().ok) throw new Error('a página mudou de estado durante a validação');
      NS.log.ok(`Validado: Tipo = ${doc.rotulo}; Número = ${valorFinal}.`);
    });
    return { tipo: tipo.tipoFinal, valorCampo: num.valorFinal };
  }

  // ───────────────────────── Localizar / tela CAPTCHA / retorno / Emitir ─────────────────────────
  const apos = (est, extra) => NS.estado.salvar({
    itemId: est.itemId, doc: est.doc, ciclos: est.ciclos || 0, tokenUsado: est.tokenUsado || '',
    localizarCliques: est.localizarCliques || 0, razao: est.razao || '', ...extra, retomadas: 0
  });

  /** Etapas 6–7 (na página do formulário): segurança e clique em Localizar. */
  async function localizar(doc, itemId) {
    const seg = await etapa(6, '[Segurança] Verificação Cloudflare permite prosseguir', async () => NS.cloudflare.garantirLiberada());
    const nav = await etapa(7, '[Localizar] Clicar em "Localizar (l)"', async () => {
      await NS.estado.salvar({ fase: 'pos_localizar', itemId, doc, ciclos: 0, tokenUsado: seg.impressao || NS.cloudflare.impressao(), localizarCliques: 1, retomadas: 0 });
      const r = await NS.botaoLocalizar.acionar();
      NS.log.ok(r.navegou ? '[Localizar] Acionado — a página está recarregando; a execução continua sozinha na página nova.'
                          : '[Localizar] Acionado (sem recarga de página).');
      return r;
    });
    if (nav.navegou) {
      await NS.wait.dormir(NS.CONFIG.localizar.aguardarRecarga); // esta página será substituída
      throw new FluxoErro('a página não terminou de recarregar após Localizar', 'erro', true);
    }
    return posLocalizar(await NS.estado.ler());
  }

  /** Página que voltou do Localizar (sem tela de CAPTCHA): há registros? */
  async function posLocalizar(est) {
    const doc = est.doc;
    const r = await etapa(8, '[Tela intermediária] Identificar a página após Localizar', async () => {
      await NS.wait.esperarDocumentoCarregado(NS.CONFIG.timeouts.paginaPronta);
      await NS.aviso.fecharSePresente();
      if (NS.telaCaptcha.detectar()) return { captcha: true };
      return NS.resultado.aguardar();
    });
    if (r.captcha) return tratarTelaCaptcha(est);
    if (!r.linhas.length) {
      NS.log.aviso('[Localizar] A página voltou SEM a tela intermediária de CAPTCHA e SEM registros na tabela' +
        (r.mensagens.length ? ` (mensagem: ${r.mensagens.join(' | ')})` : '') + '.');
      throw definitivo(`a consulta não devolveu registros para ${doc.rotulo} ${doc.formatado} — não há o que emitir` +
        (r.mensagens.length ? ` (${r.mensagens.join(' | ')})` : ''));
    }
    NS.log.ok(`[Localizar] A consulta devolveu ${r.linhas.length} registro(s).`);
    let reg;
    try { reg = NS.resultado.conferir(r.linhas, doc); } catch (e) { throw definitivo(e.message); }
    const razao = reg.nome || '';
    if (razao) NS.log.info(`Razão social obtida no sistema: ${razao}`);
    await NS.resultado.selecionar(reg);
    return retornoEEmitir({ ...est, razao, fase: 'pos_prosseguir' });
  }

  /** Etapas 8–9: tela "Não foi possível concluir a verificação de segurança (CAPTCHA)". */
  async function tratarTelaCaptcha(est) {
    const max = NS.CONFIG.telaCaptcha.maxCiclos;
    await NS.wait.esperarDocumentoCarregado(NS.CONFIG.timeouts.paginaPronta);
    const tela = await etapa(8, '[Tela intermediária] Identificar a mensagem e o botão', async () => {
      const t = NS.telaCaptcha.detectar();
      if (!t) throw new Error('a tela de verificação de segurança não está mais presente');
      NS.log.aviso(`[Tela intermediária] ${t.mensagem}`);
      t.linhas.slice(1, 4).forEach((l) => NS.log.info('[Tela intermediária] ' + l));
      NS.log.info('[Tela intermediária] "Prosseguir" apenas volta à tela anterior; NÃO conclui o CAPTCHA. Uma verificação nova será exigida.');
      return t;
    });

    if (est.fase === 'pos_emitir') {
      throw captcha('o site recusou a emissão: a verificação de segurança (CAPTCHA) não foi concluída. ' +
        'Conclua-a manualmente e continue. (Parado: sem novas tentativas automáticas nesta página.)');
    }
    if ((est.ciclos || 0) >= max) {
      throw captcha('a verificação de segurança (CAPTCHA) falhou novamente. Para evitar bloqueios, a automação PAROU: conclua a verificação manualmente na página.');
    }

    const r = await etapa(9, '[Prosseguir] Clicar em "Clique aqui para prosseguir (p)"', async () => {
      await apos(est, { fase: 'pos_prosseguir', ciclos: (est.ciclos || 0) + 1 });
      return NS.telaCaptcha.prosseguir(tela);
    });
    if (r.saiuSemRecarga) return retornoEEmitir(await NS.estado.ler());   // saiu da tela sem recarregar: segue aqui
    await NS.wait.dormir(NS.CONFIG.localizar.aguardarRecarga);            // a nova página retoma (fase pos_prosseguir)
    throw new FluxoErro('a página não terminou de recarregar após Prosseguir', 'erro', true);
  }

  /** Etapas 10–15: retorno à página inicial, reverificação, segurança nova, Emitir, observação e entrega. */
  async function retornoEEmitir(est) {
    const doc = est.doc;

    await etapa(10, '[Retorno] Confirmar o retorno à página inicial', async () => {
      await NS.wait.esperarDocumentoCarregado(NS.CONFIG.timeouts.paginaPronta);
      await NS.aviso.fecharSePresente();
      await NS.pagina.aguardarPronta();
      NS.log.ok('[Retorno] Página "Emissão de Certidão de Regularidade Fiscal" confirmada.');
    });

    await etapa(11, '[Retorno] Reverificar os campos (não presumir que continuam preenchidos)', async () => {
      const tipo = NS.campoTipoDocumento.tipoSelecionado();
      const valor = NS.campoNumeroDocumento.valorAtual();
      NS.log.info(`[Retorno] Tipo = "${tipo || '—'}"; Número = "${valor || '(vazio)'}".`);
      if (tipo === NS.dom.norm(doc.rotulo) && NS.documento.soDigitos(valor) === doc.digitos) {
        NS.log.ok(`[Retorno] Tipo ${doc.rotulo} e número continuam preenchidos corretamente.`);
        return;
      }
      NS.log.aviso('[Retorno] Os campos foram limpos ou alterados — preenchendo novamente.');
      await NS.campoTipoDocumento.selecionar(doc.rotulo);
      await NS.campoNumeroDocumento.preencher(doc);
      await NS.wait.dormir(300);
      if (NS.campoTipoDocumento.tipoSelecionado() !== NS.dom.norm(doc.rotulo) ||
          NS.documento.soDigitos(NS.campoNumeroDocumento.valorAtual()) !== doc.digitos) {
        throw new Error('não foi possível confirmar os campos após preencher novamente');
      }
      NS.log.ok(`[Retorno] Campos refeitos e confirmados: ${doc.rotulo}, ${NS.campoNumeroDocumento.valorAtual()}.`);
    });

    await etapa(12, '[Segurança] Verificação de segurança NOVA e concluída', async () => {
      const r = await NS.cloudflare.garantirLiberada({ rejeitado: est.tokenUsado || '' });
      await apos(est, { fase: 'pos_prosseguir', tokenUsado: r.impressao || '' });
      return r;
    });

    return emitirEObservar(doc, est);
  }

  /** Etapas 13–15: Emitir (um clique), observação e entrega. */
  async function emitirEObservar(doc, est) {
    const base = await etapa(13, '[Emitir] Clicar em "Emitir (e)"', async () => {
      const botao = await NS.botaoEmitir.aguardarLiberado();
      NS.log.ok('[Emitir] Botão identificado (#btt_emitir) e liberado (visível, habilitado, sem sobreposição).');
      const antes = NS.observador.capturar();
      await apos(est, { fase: 'pos_emitir', t0: antes.t0, urlAntes: antes.url });
      const r = await NS.botaoEmitir.clicar(botao);
      if (!r.clicado) throw new FluxoErro('o clique em Emitir não foi realizado (ação configurada: "' + NS.CONFIG.emitir.acao + '")', 'erro', false);
      NS.log.ok('[Emitir] Clique realizado. Nenhuma confirmação adicional será acionada.');
      NS.job.status({ emitirClicado: true, etapa: 'Emitir clicado', razao: est.razao || '' });
      return antes;
    });

    const obs = await etapa(14, '[Emitir] Observar o comportamento da página', async () => {
      NS.log.info(`Observando a página por até ${Math.round(NS.CONFIG.observacao.janela / 1000)} s...`);
      const r = await NS.observador.observar(base);
      return { r, tipos: NS.observador.relatar(r) };
    });

    return entregar(doc, { ...est, urlFinal: obs.r.urlFinal, observacao: obs.tipos.join(', ') }, base);
  }

  /** Etapa 15: aguarda o arquivo e relata o desfecho à fila. */
  async function entregar(doc, est, base) {
    const e = await etapa(15, '[Entrega] Aguardar o arquivo da certidão', async () => NS.entrega.aguardar(base));
    const g = NS.guarda.resumo();
    const nLoc = est.localizarCliques || g.autorizados;
    NS.log.ok(`Verificação: "Localizar" clicado pela automação ${nLoc}x (autorizado); tentativas NÃO autorizadas bloqueadas nesta página: ${g.bloqueados}.`);
    await NS.estado.limpar();

    const comum = { razao: est.razao || '' };
    const resultado = {
      sucesso: e.via === 'download' || e.via === 'pdf-pagina' || e.via === 'aba', cnpj: doc.digitos, documento: `${doc.rotulo} ${doc.formatado}`, emitirClicado: true,
      localizarClicadoPelaAutomacao: nLoc, entrega: e.via, observacao: est.observacao || '', urlFinal: est.urlFinal || location.href
    };
    if (e.via === 'download') { NS.log.ok('[Entrega] O site iniciou um download — a extensão define a pasta/nome e valida o PDF.'); await NS.job.final({ status: 'entrega-download', ...comum }); }
    else if (e.via === 'pdf-pagina' || e.via === 'aba') {
      NS.log.ok(`[Entrega] PDF disponível em ${e.url}`);
      try {
        const dataUrl = await NS.entrega.obterPdf(e.url); // dentro da janela anônima: cookies da sessão anônima
        NS.log.ok('[Entrega] PDF obtido e conferido (cabeçalho %PDF-). Enviando para gravação.');
        await NS.job.final({ status: 'entrega-pdf', dataUrl, tabIdEntrega: e.tabId, ...comum });
      } catch (err) {
        NS.log.aviso(`[Entrega] Não foi possível obter o PDF pela página (${err.message}); tentando pelo background.`);
        await NS.job.final({ status: 'entrega-url', urlPdf: e.url, tabIdEntrega: e.tabId, ...comum });
      }
    }
    else if (e.via === 'sem_certidao') { NS.log.aviso(`[Entrega] Certidão indisponível: ${e.mensagem}`); await NS.job.final({ status: 'sem_certidao', mensagem: e.mensagem, ...comum }); }
    else if (e.via === 'captcha') { NS.log.aviso('[Entrega] O site recusou por CAPTCHA.'); await NS.job.final({ status: 'captcha', mensagem: 'verificação de segurança não concluída', ...comum }); }
    else { NS.log.aviso(`[Entrega] Nenhum arquivo foi entregue no tempo limite. ${e.mensagem || ''}`); await NS.job.final({ status: 'nenhuma-entrega', mensagem: e.mensagem || '', ...comum }); }

    NS.log.resultado({ ...resultado, sucesso: resultado.sucesso });
    return { emitirClicado: true, entrega: e.via };
  }

  /** Execução completa de UM documento, a partir do formulário. */
  function executar(origem, item) {
    return rodar(`execução (${origem})`, async () => {
      await NS.estado.limpar();
      const doc = await prepararDocumento(item);
      const campos = await preencherFormulario(doc);
      const r = await localizar(doc, item ? item.id : '');
      return { documento: doc.digitos, ...campos, ...r };
    });
  }

  /** Página que surgiu depois de um clique da automação (Localizar/Prosseguir/Emitir). */
  function retomar(est) {
    return rodar(`retomada (${est.fase})`, async () => {
      await NS.estado.salvar({ ...est, retomadas: (est.retomadas || 0) + 1 });
      if (NS.telaCaptcha.detectar()) return tratarTelaCaptcha(est);
      if (est.fase === 'pos_localizar') return posLocalizar(est);
      if (est.fase === 'pos_prosseguir') return retornoEEmitir(est);
      if (est.fase === 'pos_emitir') return observarAposEmitir(est);
      throw new FluxoErro('fase desconhecida: ' + est.fase, 'erro', true);
    });
  }

  /** O clique em Emitir substituiu a página: descreve o que ela mostra e segue para a entrega (sem clicar em nada). */
  async function observarAposEmitir(est) {
    NS.log.info('[Emitir] A página foi substituída após o clique. Descrevendo o que está na tela (sem clicar em nada)...');
    await NS.wait.esperarDocumentoCarregado(NS.CONFIG.timeouts.paginaPronta);
    await NS.wait.dormir(1500);
    const r = await NS.observador.descreverPaginaAtual(est.t0);
    const tipos = NS.observador.relatar(r);
    return entregar(est.doc, { ...est, urlFinal: r.urlFinal, observacao: tipos.join(', ') }, NS.observador.baseVazia(est.t0));
  }

  chrome.runtime.onMessage.addListener((msg, _sender, responder) => {
    if (!msg) return false;
    if (msg.tipo === 'EFISCO_EXECUTAR') { executar('manual').then(responder); return true; }
    if (msg.tipo === 'EFISCO_PARAR') { NS.wait.cancelar(); NS.estado.limpar(); responder({ ok: true }); return false; }
    return false;
  });

  /**
   * Ao carregar uma página do e-Fisco:
   *  - a fila (background) tem um documento em curso nesta aba → executa/retoma esse documento;
   *  - sem fila: retoma uma execução avulsa em andamento ou apenas avisa que a extensão está pronta.
   */
  async function iniciar() {
    if (!NS.pagina.hostPermitido()) return;
    const hello = await NS.job.hello();
    NS.job.observarComandos();
    const est = await NS.estado.ler();
    if (est && est.retomadas > NS.CONFIG.retomada.maxRetomadas) { await NS.estado.limpar(); return; }

    if (hello) {
      NS.job.ativar(hello.item);
      if (est && est.fase && est.itemId === hello.item.id) { retomar(est); return; }
      executar('fila', hello.item);
      return;
    }
    if (est && est.fase) { retomar(est); return; }
    const ehPagina = NS.pagina.caminhoProvavel() || NS.pagina.inspecionar().ok;
    if (!ehPagina) return;
    NS.painel.iniciar();
    NS.log.info(`Extensão v${chrome.runtime.getManifest().version} carregada nesta página. Abra o painel da extensão (ícone) e use INICIAR AUTOMAÇÃO.`);
  }
  NS.executar = executar;
  iniciar();
})();
