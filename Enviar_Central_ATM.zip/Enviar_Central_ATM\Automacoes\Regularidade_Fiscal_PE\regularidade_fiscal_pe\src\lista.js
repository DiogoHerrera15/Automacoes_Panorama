/* Lista de documentos: leitura (um por linha), classificação, duplicidades e fila executável. Puro (sem DOM). */
(function () {
  'use strict';
  const NS = (window.EFiscoCRF = window.EFiscoCRF || {});

  /**
   * @param {string} texto  conteúdo do campo "Documentos para emissão"
   * @param {{tipos?:Object<string,string>, forcar?:Object<string,boolean>}} [ajustes]
   *        tipos: id da linha → tipo escolhido pelo usuário; forcar: id → processar mesmo se inválido
   */
  function processar(texto, ajustes = {}) {
    const tipos = ajustes.tipos || {};
    const forcar = ajustes.forcar || {};
    const itens = [];
    const vistos = new Map();
    String(texto || '').split(/\r?\n/).forEach((linhaBruta, i) => {
      // aceita também ; , ou tab como separadores (planilhas coladas)
      linhaBruta.split(/[;,\t]+/).forEach((parte, j) => {
        const txt = parte.trim();
        if (!txt) return;
        const id = `L${i + 1}${j ? '_' + (j + 1) : ''}`;
        const c = NS.documento.classificar(txt, tipos[id]);
        const item = { id, linha: i + 1, ...c, forcar: !!forcar[id], duplicado: false, duplicadoDe: null };
        const chave = (item.tipo || '?') + ':' + item.digitos;
        if (item.digitos && vistos.has(chave)) { item.duplicado = true; item.duplicadoDe = vistos.get(chave); }
        else if (item.digitos) vistos.set(chave, id);
        itens.push(item);
      });
    });
    return itens;
  }

  /** Item pode entrar na fila? (não duplicado, tipo definido, e válido — ou forçado pelo usuário) */
  const executavel = (it) => !it.duplicado && !it.ambiguo && !!it.tipo && (it.valido || it.forcar);

  function resumo(itens) {
    const r = { total: itens.length, CPF: 0, CNPJ: 0, IE: 0, ambiguos: 0, invalidos: 0, duplicados: 0, executaveis: 0 };
    itens.forEach((it) => {
      if (it.duplicado) { r.duplicados++; return; }
      if (it.ambiguo) { r.ambiguos++; return; }
      if (it.tipo) r[it.tipo]++;
      if (!it.valido && !it.forcar) r.invalidos++;
      if (executavel(it)) r.executaveis++;
    });
    return r;
  }

  /** Itens prontos para a fila, na ordem de entrada. */
  const paraFila = (itens) => itens.filter(executavel).map((it) => ({
    id: it.id, original: it.original, tipo: it.tipo, digitos: it.digitos, formatado: it.formatado, forcado: !!(it.forcar && !it.valido)
  }));

  NS.lista = { processar, executavel, resumo, paraFila };
})();
