# Solução de problemas

Primeiro passo sempre: rode **`VERIFICAR.cmd`** (ou `Instalacao\verificar_ambiente.ps1`) e leia as linhas `[ERRO]` e
`[AVISO]`. O registro da instalação fica em `Instalacao\logs\` e em `%USERPROFILE%\Central_ATM\instalacao_ultima.txt`.
Falhas ao abrir automações pela Central ficam em `Central_ATM\Central_de_Automacoes\central_erros.log`.

## Instalação

| Sintoma | Causa provável | Solução |
|---|---|---|
| "a execução de scripts foi desabilitada" | política do PowerShell | use `INSTALAR.cmd`/`VERIFICAR.cmd` (já passam `-ExecutionPolicy Bypass`) |
| `.cmd`/`.ps1` bloqueado ("arquivo baixado da internet") | marca de download do ZIP | o instalador roda `Unblock-File`; ou: `Get-ChildItem -Recurse <pasta> \| Unblock-File` |
| "Node.js não encontrado" logo depois de instalar | PATH antigo nesta janela | feche a janela, abra outra e rode de novo |
| "Node.js vN é antigo" | Node < 20 | `winget upgrade OpenJS.NodeJS.LTS` |
| winget pede administrador para o Node | MSI por máquina | aprove o UAC, ou instale o Node pelo nodejs.org |
| `npm ci` falha | sem internet / proxy | confira a internet; rode `INSTALAR.cmd` de novo (ele tenta `npm install` em seguida) |
| `python` abre a Microsoft Store | atalho da loja, não é Python | `winget install Python.Python.3.12 --scope user`; desative o atalho em Configurações > Aplicativos > Aliases de execução |
| ATM RFB: "Falha ao instalar Pillow/openpyxl" | pip sem internet | rode `Automacoes\ATM_RFB\instalar.cmd` |
| "o pacote está incompleto" | ZIP extraído pela metade | extraia o ZIP inteiro de novo |

## Central

| Sintoma | Causa provável | Solução |
|---|---|---|
| Cartão "Extensão não carregada no Chrome" | extensão não carregada desta pasta | carregue a pasta indicada em `chrome://extensions` (README, seção 5) e clique em **Atualizar** (F5) na Central |
| Cartão "Extensão desligada" | botão da extensão desligado | ligue em `chrome://extensions` |
| Cartão "Node.js não encontrado" | Node fora do PATH | instale o Node 20+ e reabra a Central |
| "a pasta do projeto não existe" | instalada em outra pasta ou movida | rode `INSTALAR.cmd` (ou `-Destino` com a pasta certa); não mova `Automacoes` para longe de `Central_de_Automacoes` |
| Erro ao abrir a Central | veja a caixa de mensagem e `central_erros.log` | `Central.ps1 -Validar` mostra o problema sem abrir a janela |
| Letras borradas | escala do Windows | a Central já declara DPI; teste com `-TesteJanela <pasta> -Escala 1.5` |
| "Fechou logo depois de abrir (código N)" | a automação saiu com erro em até 15 s | abra o `.cmd` da automação com dois cliques para ver a mensagem |

## Automações

| Sintoma | Automação | Solução |
|---|---|---|
| "A interface já está aberta" e a janela fecha sozinha | Retirar | normal: só reabriu o navegador na janela que já estava aberta (código 10) |
| "Extensão: sem contato" | Retirar | extensão desligada, versão antiga ligada junto ou aba do site não abriu; confira `chrome://extensions` |
| Porta 47330/47331 ocupada | ATM RFB / Retirar | feche a outra janela preta dessa automação |
| A automação não inicia em janela anônima | Parcelamento, Regularidade PE, PGFN, ATM RFB | ligue **Permitir no modo anônimo** nos Detalhes da extensão |
| Não consigo trocar de certificado | Parcelamento Simplificado | feche **todas** as janelas anônimas e abra de novo pela Central |
| Placar zerado ao continuar | Parcelamento / Situação Fiscal | use exatamente o mesmo nome de pasta da execução anterior; não clique em "Zerar andamento" |
| "ajudante não registrado" / "Salvar como" não confirma | PGFN | com a extensão `Automação_PGFN` carregada, rode `Downloads\Auto_PGFN\INSTALAR.bat` (registra com o ID dela) |
| "a pasta precisa ficar em Downloads\Auto_PGFN" | PGFN | não mova a PGFN; reinstale com `INSTALAR.cmd` |
| Certificado não encontrado / vencido | PGFN | instale/renove o certificado no Windows; o nome tem que ser igual ao da janela do Chrome |
| CAPTCHA / verificação Cloudflare | Regularidade PE, PGFN, Retirar | resolva na página; a automação espera e continua (nunca resolve sozinha) |
| PDFs indo para `Downloads\download.pdf` ou pedindo "Salvar como" | todas | desligue "Perguntar onde salvar cada arquivo"; não mude a pasta padrão de downloads |
| Duas extensões iguais disputando a página | todas | deixe só uma cópia de cada ligada |
| Depois de atualizar arquivos a extensão continua antiga | todas | clique em **Recarregar** (seta) na extensão; **não remova** (remover apaga o andamento) |

## Desfazer a instalação

1. `chrome://extensions`: remova as 7 extensões (isso apaga os andamentos guardados no Chrome).
2. PGFN: `Downloads\Auto_PGFN\ajudante_salvar_como\desinstalar_ajudante.bat`.
3. Apague `%USERPROFILE%\Central_ATM` e o atalho **Central de Automações** da Área de Trabalho.
4. `Downloads\Auto_PGFN`: apague só se não precisar dos documentos em `Documentos_arrecadacao`.
