/*
 * Ponte entre o content script e a fila (background): recebe o documento atual, envia andamento/resultado
 * e respeita PAUSAR/PARAR (lidos de chrome.storage).
 */
(function () {
  'use strict';
  const NS = (window.EFiscoCRF = window.EFiscoCRF || {});
  const K_JOB = 'efisco_job';

  function enviar(msg) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(msg, (r) => { void chrome.runtime.lastError; resolve(r); });
      } catch (_) { resolve(undefined); }
    });
  }
  function lerJob() {
    return new Promise((resolve) => {
      try { chrome.storage.local.get(K_JOB, (d) => resolve((d && d[K_JOB]) || null)); } catch (_) { resolve(null); }
    });
  }

  let observando = false;
  const job = {
    ativo: false,
    item: null,

    /** Pede ao background o documento em processamento nesta aba (ou null: execução avulsa, sem fila). */
    async hello() {
      const r = await enviar({ tipo: 'ITEM_HELLO' });
      return r && r.item ? r : null;
    },
    ativar(item) { job.ativo = true; job.item = item; },
    status(dados) { return job.ativo ? enviar({ tipo: 'ITEM_STATUS', itemId: job.item.id, ...dados }) : Promise.resolve(); },
    final(dados) { return job.ativo ? enviar({ tipo: 'ITEM_FINAL', itemId: job.item.id, ...dados }) : Promise.resolve(); },

    /** PARAR no painel cancela as esperas em andamento. */
    observarComandos() {
      if (observando) return;
      observando = true;
      try {
        chrome.storage.onChanged.addListener((mud, area) => {
          if (area !== 'local' || !mud[K_JOB] || !job.ativo) return;
          const novo = mud[K_JOB].newValue;
          if (!novo || novo.estado === 'parado') NS.wait.cancelar();
        });
      } catch (_) { /* sem API de storage (teste): ignora */ }
    },

    /** Chamada entre as etapas: PAUSAR segura o avanço; PARAR interrompe. */
    async verificarPausa() {
      if (!job.ativo) return;
      let avisou = false;
      for (;;) {
        const j = await lerJob();
        if (!j || j.estado === 'parado') throw new Error(NS.wait.ERRO_CANCELADO);
        if (j.estado !== 'pausado') return;
        if (!avisou) { avisou = true; NS.log.aviso('Execução PAUSADA — aguardando CONTINUAR no painel.'); }
        await new Promise((r) => setTimeout(r, 700));
      }
    }
  };
  NS.job = job;
})();
