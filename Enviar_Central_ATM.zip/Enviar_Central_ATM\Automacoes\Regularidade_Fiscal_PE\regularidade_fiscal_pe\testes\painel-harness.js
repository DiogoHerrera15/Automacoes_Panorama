/*
 * Ambiente de TESTE do painel: um Chrome simulado (storage, tabs, downloads, alarms, fetch) + o controlador REAL da fila
 * (src/fila.js) + um "e-Fisco simulado" que responde aos documentos. Não faz parte da extensão.
 * Cenários (?cenario=): ok | erro-recuperavel | captcha | lento (cada documento demora, para testar pausar/parar).
 */
(function () {
  'use strict';
  const q = new URLSearchParams(location.search);
  const cenario = q.get('cenario') || 'ok';
  const mem = JSON.parse(sessionStorage.getItem('pmem') || '{}');
  const ouvintes = [];
  const persistir = () => sessionStorage.setItem('pmem', JSON.stringify(mem));
  const notificar = (mud) => ouvintes.forEach((f) => f(mud, 'local'));

  const storage = {
    get: async (k) => { const ks = Array.isArray(k) ? k : [k]; const o = {}; ks.forEach((x) => { if (x in mem) o[x] = JSON.parse(JSON.stringify(mem[x])); }); return o; },
    set: async (o) => { const mud = {}; Object.entries(o).forEach(([k, v]) => { mud[k] = { oldValue: mem[k], newValue: JSON.parse(JSON.stringify(v)) }; mem[k] = JSON.parse(JSON.stringify(v)); }); persistir(); notificar(mud); },
    remove: async (k) => { const mud = {}; (Array.isArray(k) ? k : [k]).forEach((x) => { mud[x] = { oldValue: mem[x] }; delete mem[x]; }); persistir(); notificar(mud); }
  };
  window.__reg = { tabs: [], downloads: [], mensagens: [] };
  const abas = new Set(); let idTab = 50; let idDl = 500; const dls = {};
  const PDF = Uint8Array.from('%PDF-1.4\n' + 'conteudo da certidao '.repeat(60) + '\n%%EOF', (c) => c.charCodeAt(0));
  const api = {
    storage,
    incognitoPermitido: async () => q.get('anonimo') !== 'nao',
    windows: {
      create: async (o) => { const id = idTab++; abas.add(id); window.__reg.tabs.push(`janela ${o.incognito ? 'ANÔNIMA' : 'comum'} ${o.url}`); setTimeout(() => simular(id), 500); return { id: 900 + id, tabs: [{ id }] }; }
    },
    tabs: {
      get: async (id) => { if (!abas.has(id)) throw new Error('sem aba'); return { id, incognito: true }; },
      query: async () => [...abas].map((id) => ({ id })),
      create: async (o) => { window.__reg.tabs.push('ABA COMUM ' + o.url); throw new Error('não deveria criar aba comum'); },
      update: async (id, o) => { window.__reg.tabs.push('update ' + o.url); setTimeout(() => simular(id), 500); return { id }; },
      remove: async (id) => abas.delete(id)
    },
    downloads: {
      download: async (o) => { const id = idDl++; dls[id] = { id, state: 'in_progress', filename: '/Users/teste/Downloads/' + o.filename, mime: 'application/pdf', fileSize: PDF.length, exists: true }; window.__reg.downloads.push(o.filename); setTimeout(() => { dls[id].state = 'complete'; fila.aoDownloadMudou({ id, state: { current: 'complete' } }); }, 400); return id; },
      search: async ({ id }) => [dls[id]].filter(Boolean)
    },
    alarms: { create: async () => {}, clear: async () => {} },
    fetch: async () => ({ ok: true, status: 200, arrayBuffer: async () => PDF.buffer.slice(0) }),
    agora: () => Date.now(), espera: (ms) => new Promise((r) => setTimeout(r, Math.min(ms, 400)))
  };
  let fila = null;

  /** "e-Fisco simulado": o que o content script faria para o documento atual. */
  async function simular(tabId) {
    const h = await fila.aoHello(tabId);
    if (!h) return;
    const id = h.item.id;
    const espera = (ms) => new Promise((r) => setTimeout(r, ms));
    const etapas = ['3/15 Selecionar tipo ' + h.item.tipo, '4/15 Preencher número', '7/15 Localizar', '9/15 Prosseguir', '13/15 Emitir'];
    for (const e of etapas) { await fila.aoStatus({ itemId: id, etapa: e }); await espera(cenario === 'lento' ? 1500 : 350); }
    const job = await fila.lerJob();
    if (!job || job.atual !== id) return; // parado/pausado: o content script desiste
    if (job.estado === 'pausado') { // PAUSAR: segura até continuar
      for (let i = 0; i < 60; i++) { await espera(300); const j = await fila.lerJob(); if (j.estado !== 'pausado') break; }
    }
    const jx = await fila.lerJob(); if (!jx || jx.estado === 'parado' || jx.atual !== id) return;
    await fila.aoStatus({ itemId: id, emitirClicado: true });
    const n = jx.itens.findIndex((i) => i.id === id);
    if (cenario === 'erro-recuperavel' && n === 1) return void fila.aoFinal({ itemId: id, status: 'erro', recuperavel: true, mensagem: 'campo não recebeu o valor' });
    if (cenario === 'captcha' && n === 1 && jx.itens[n].tentativas === 1) return void fila.aoFinal({ itemId: id, status: 'captcha' });
    if (n === 2 && cenario === 'ok') return void fila.aoFinal({ itemId: id, status: 'sem_certidao', mensagem: 'contribuinte com pendências' });
    return void fila.aoFinal({ itemId: id, status: 'entrega-url', urlPdf: 'https://efisco.sefaz.pe.gov.br/certidao.pdf', razao: n === 0 ? 'Empresa Exemplo Ltda' : '' });
  }

  window.chrome = {
    storage: { local: storage, onChanged: { addListener: (f) => ouvintes.push(f) } },
    runtime: {
      lastError: undefined,
      sendMessage: (msg, cb) => {
        window.__reg.mensagens.push(msg.tipo);
        const mapa = { INCOGNITO_STATUS: async () => ({ ok: true, permitido: await api.incognitoPermitido() }), ABRIR_CONFIG: async () => { window.__reg.tabs.push('abrir chrome://extensions'); return { ok: true }; }, JOB_INICIAR: () => fila.iniciar(msg), JOB_PAUSAR: () => fila.pausar(), JOB_CONTINUAR: () => fila.continuar(), JOB_PARAR: () => fila.parar() };
        Promise.resolve(mapa[msg.tipo] && mapa[msg.tipo]()).then((r) => cb && cb(r));
      }
    }
  };
  window.__montarFila = () => { fila = window.EFiscoCRF.criarFila(api); window.__fila = fila; };
})();
