/*
 * Observador pós-clique em "Emitir (e)". SOMENTE OBSERVA e registra: navegação, janela/aba nova,
 * download iniciado, diálogo/mensagem. Nunca clica em nada (confirmações ficam para análise).
 */
(function () {
  'use strict';
  const NS = (window.EFiscoCRF = window.EFiscoCRF || {});
  const { esperarOuNulo } = NS.wait;
  const { norm } = NS.dom;

  const SEL_DIALOGO = '[role=dialog], [role=alertdialog], dialog[open], .modal, .ui-dialog, [class*="dialog" i], ' +
    '[class*="modal" i], [class*="popup" i], [class*="overlay" i], [id*="dialog" i], [id*="modal" i], [id*="confirm" i], [id*="popup" i]';

  const assinatura = (el) => `${el.tagName}#${el.id}.${String(el.className).slice(0, 40)}|${norm(el.textContent).slice(0, 80)}`;
  const limpo = (s) => String(s).replace(/\s+/g, ' ').trim();

  function dialogosVisiveis() {
    const lista = [...document.querySelectorAll(SEL_DIALOGO)].filter((el) => {
      if (el.closest('#efisco-painel-host, #efisco-cursor-host')) return false;
      if (!NS.wait.estaVisivel(el)) return false;
      const r = el.getBoundingClientRect();
      return r.width >= 120 && r.height >= 60 && norm(el.textContent).length > 0;
    });
    return lista.filter((el) => !lista.some((o) => o !== el && o.contains(el))); // só os mais externos
  }

  const linhasDoTexto = () => new Set(String(document.body ? document.body.innerText : '')
    .split('\n').map(limpo).filter((l) => l.length > 3));

  /** Diálogos nativos (alert/confirm/prompt) registrados pela ponte desde `desde` (ms epoch). */
  function dialogosNativos(desde) {
    try {
      return JSON.parse(sessionStorage.getItem('efisco_dialogos') || '[]').filter((d) => d.t >= (desde || 0) - 500);
    } catch (_) { return []; }
  }

  function capturar() {
    return {
      t0: Date.now(), url: location.href, titulo: document.title,
      dialogos: new Set(dialogosVisiveis().map(assinatura)),
      linhas: linhasDoTexto(), iframes: document.querySelectorAll('iframe').length
    };
  }

  function lerEventos(desde) {
    return new Promise((resolve) => {
      try {
        chrome.storage.local.get(NS.CONFIG.storage.eventos, (d) => {
          resolve(((d && d[NS.CONFIG.storage.eventos]) || []).filter((e) => e.t >= desde - 500));
        });
      } catch (_) { resolve([]); }
    });
  }

  function diferencas(base) {
    const novosDialogos = dialogosVisiveis().filter((el) => !base.dialogos.has(assinatura(el)));
    const textoNovo = [...linhasDoTexto()].filter((l) => !base.linhas.has(l) && !/^\d{2}:\d{2}:\d{2}/.test(l)).slice(0, 8);
    return {
      urlMudou: location.href !== base.url,
      novosDialogos, textoNovo,
      iframesNovos: Math.max(0, document.querySelectorAll('iframe').length - base.iframes)
    };
  }

  /** Observa por uma janela de tempo limitada e devolve o que ocorreu. */
  async function observar(base) {
    const cfg = NS.CONFIG.observacao;
    let primeira = 0;
    await esperarOuNulo(() => {
      const d = diferencas(base);
      const houve = d.urlMudou || d.novosDialogos.length || d.textoNovo.length || d.iframesNovos;
      if (houve && !primeira) primeira = Date.now();
      return primeira && Date.now() - primeira >= cfg.estabilizar;
    }, { timeout: cfg.janela, intervalo: cfg.intervalo, descricao: 'observação pós-Emitir' });

    const d = diferencas(base);
    const eventos = await lerEventos(base.t0);
    const dialogos = d.novosDialogos.map((el) => ({
      texto: limpo(el.textContent).slice(0, 500),
      botoes: [...el.querySelectorAll('button, input[type=button], input[type=submit], a, [role=button]')]
        .filter((b) => NS.wait.estaVisivel(b)).map((b) => limpo(b.tagName === 'INPUT' ? b.value : b.textContent)).filter(Boolean).slice(0, 6)
    }));
    const nativos = dialogosNativos(base.t0);
    return { ...d, dialogos, nativos, eventos, urlFinal: location.href, tituloFinal: document.title, segundos: ((Date.now() - base.t0) / 1000).toFixed(1) };
  }

  /** Escreve o resultado no registro e devolve uma classificação curta. */
  function relatar(r) {
    const tipos = [];
    if (r.urlMudou) { tipos.push('navegacao'); NS.log.ok(`Navegação detectada → ${r.urlFinal} (título: "${r.tituloFinal}").`); }
    r.eventos.forEach((e) => {
      if (e.tipo === 'aba-criada') { tipos.push('nova-aba'); NS.log.ok(`Nova aba aberta: ${e.url || '(url pendente)'}.`); }
      else if (e.tipo === 'janela-criada') { tipos.push('nova-janela'); NS.log.ok(`Nova janela aberta (${e.janela || '?'}).`); }
      else if (e.tipo === 'download-iniciado') { tipos.push('download'); NS.log.ok(`Download iniciado: ${e.arquivo || e.url} (${e.mime || 'tipo ?'}).`); }
    });
    r.dialogos.forEach((d, i) => {
      tipos.push('dialogo');
      NS.log.ok(`Diálogo/mensagem ${i + 1} exibido: "${d.texto}"`);
      if (d.botoes.length) NS.log.info(`Botões do diálogo (NÃO acionados): ${d.botoes.join(' | ')}`);
    });
    (r.nativos || []).forEach((d) => {
      tipos.push('dialogo-nativo');
      NS.log.ok(`Diálogo nativo (${d.tipo}) exibido pelo site: "${d.msg}" — nada foi respondido pela automação.`);
    });
    if (!r.dialogos.length && r.textoNovo.length) {
      tipos.push('texto');
      NS.log.ok('Texto novo na página: ' + r.textoNovo.join(' | '));
    }
    if (r.iframesNovos) { tipos.push('iframe'); NS.log.ok(`${r.iframesNovos} iframe(s) novo(s) na página.`); }
    if (!tipos.length) NS.log.aviso(`Nenhuma mudança observável em ${r.segundos} s após o clique em Emitir.`);
    return [...new Set(tipos)];
  }

  /** Para quando a página foi substituída após o clique: descreve o que está na tela agora. */
  async function descreverPaginaAtual(t0) {
    const dialogos = dialogosVisiveis();
    const eventos = await lerEventos(t0);
    const texto = limpo(document.body ? document.body.innerText : '').slice(0, 400);
    return {
      urlMudou: true, urlFinal: location.href, tituloFinal: document.title, eventos, textoNovo: [texto], iframesNovos: 0,
      nativos: dialogosNativos(t0),
      segundos: ((Date.now() - t0) / 1000).toFixed(1),
      dialogos: dialogos.map((el) => ({
        texto: limpo(el.textContent).slice(0, 500),
        botoes: [...el.querySelectorAll('button, input[type=button], input[type=submit], a')].filter((b) => NS.wait.estaVisivel(b))
          .map((b) => limpo(b.tagName === 'INPUT' ? b.value : b.textContent)).filter(Boolean).slice(0, 6)
      }))
    };
  }

  /** Base "vazia" para quando a página foi substituída: tudo o que aparecer conta como novo. */
  const baseVazia = (t0) => ({ t0, url: '', titulo: '', dialogos: new Set(), linhas: new Set(), iframes: 0 });

  NS.observador = { capturar, baseVazia, observar, relatar, descreverPaginaAtual, diferencas, dialogosVisiveis, dialogosNativos, lerEventos, limpo };
})();
