/*
 * Roda no "mundo" da PÁGINA (world: MAIN, document_start). Apenas REGISTRA o texto de alert/confirm/prompt
 * nativos em sessionStorage (visível ao content script) e repassa a chamada original SEM alterar o
 * comportamento nem a resposta. Serve para saber o que o e-Fisco avisou/perguntou.
 */
(function () {
  'use strict';
  if (window.__efiscoPonte) return;
  window.__efiscoPonte = true;
  const K = 'efisco_dialogos';
  function anotar(tipo, msg) {
    try {
      const lista = JSON.parse(sessionStorage.getItem(K) || '[]').slice(-19);
      lista.push({ t: Date.now(), tipo, msg: String(msg == null ? '' : msg).slice(0, 600) });
      sessionStorage.setItem(K, JSON.stringify(lista));
    } catch (_) { /* sessionStorage indisponível: ignora */ }
  }
  ['alert', 'confirm', 'prompt'].forEach((nome) => {
    const original = window[nome];
    if (typeof original !== 'function') return;
    window[nome] = function (msg) {
      anotar(nome, msg);
      return original.apply(this, arguments);
    };
  });
})();
