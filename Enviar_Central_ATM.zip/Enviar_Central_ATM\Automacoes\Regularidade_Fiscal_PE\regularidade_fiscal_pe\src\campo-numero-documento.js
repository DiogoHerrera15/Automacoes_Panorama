/* Campo 2 — "Número do Documento de Identificação" (CNPJ, com ou sem máscara). */
(function () {
  'use strict';
  const NS = (window.EFiscoCRF = window.EFiscoCRF || {});
  const { dormir, esperarPor, tentar } = NS.wait;

  const fv = () => NS.CONFIG.digitacao.fatorVelocidade * NS.CONFIG.velocidade.digitacao;
  const aleatorio = (min, max) => min + Math.random() * (max - min);
  const entre = ([min, max]) => aleatorio(min, max);
  const setterValor = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;

  const localizarInput = () => NS.dom.localizarControle({
    seletor: NS.CONFIG.seletores.numeroDocumento, rotulo: NS.CONFIG.pagina.rotuloNumero, tipo: 'input'
  });

  /** Localiza o input, aguarda visível e HABILITADO (ele costuma liberar só depois de escolher o tipo). */
  async function localizar() {
    const { tentativas, timeouts } = NS.CONFIG;
    return tentar('Localizar campo "Número do Documento"', async () => {
      let input = localizarInput();
      if (!input || !NS.wait.estaVisivel(input)) throw new Error('campo "Número do Documento de Identificação" não encontrado/visível');
      if (input.disabled || input.readOnly) {
        NS.log.info('Campo "Número do Documento" bloqueado — aguardando habilitação...');
        await esperarPor(() => { const i = localizarInput(); return i && !i.disabled && !i.readOnly; },
          { timeout: timeouts.habilitar, descricao: 'habilitação do campo Número do Documento' });
      }
      // Estabilização: a página pode trocar o elemento ao reagir ao tipo escolhido.
      await dormir(300);
      input = localizarInput();
      if (!input || input.disabled || input.readOnly) throw new Error('campo "Número do Documento" instável/bloqueado');
      return input;
    }, tentativas.localizar, tentativas.intervalo);
  }

  function atrasoTecla() {
    const c = NS.CONFIG.digitacao;
    const u1 = Math.random() || 1e-9;
    const normal = Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * Math.random());
    return Math.max(c.atrasoMin, Math.min(c.atrasoMax * Math.max(1, fv()), c.atrasoMedio * Math.exp(0.32 * normal) * fv()));
  }

  function teclar(input, ch) {
    const opc = { key: ch, code: /\d/.test(ch) ? `Digit${ch}` : '', bubbles: true, cancelable: true };
    if (input.dispatchEvent(new KeyboardEvent('keydown', opc))) {
      try { input.dispatchEvent(new InputEvent('beforeinput', { data: ch, inputType: 'insertText', bubbles: true, cancelable: true })); } catch (_) {}
      setterValor.call(input, input.value + ch);
      try { input.dispatchEvent(new InputEvent('input', { data: ch, inputType: 'insertText', bubbles: true })); }
      catch (_) { input.dispatchEvent(new Event('input', { bubbles: true })); }
    }
    input.dispatchEvent(new KeyboardEvent('keyup', opc));
  }

  function limpar(input) {
    input.select();
    setterValor.call(input, '');
    try { input.dispatchEvent(new InputEvent('input', { inputType: 'deleteContentBackward', bubbles: true })); }
    catch (_) { input.dispatchEvent(new Event('input', { bubbles: true })); }
    input.dispatchEvent(new KeyboardEvent('keyup', { key: 'Backspace', code: 'Backspace', bubbles: true }));
  }

  async function digitar(input, texto) {
    const c = NS.CONFIG.digitacao;
    let ate = 2 + Math.floor(Math.random() * 3);
    for (let i = 0; i < texto.length; i++) {
      if (input.maxLength > 0 && input.value.length >= input.maxLength) {
        NS.log.aviso(`O campo atingiu o limite de ${input.maxLength} caracteres antes do fim da digitação.`);
        break;
      }
      teclar(input, texto[i]);
      if (i === texto.length - 1) break;
      let espera = atrasoTecla();
      if (--ate <= 0) { espera += entre(c.pausaGrupo) * fv(); ate = 2 + Math.floor(Math.random() * 3); }
      else if (Math.random() < c.chanceHesitacao) espera += entre(c.pausaHesitacao) * fv();
      await dormir(espera);
    }
  }

  /** Decide se o campo espera o CNPJ com máscara (pela dica do próprio campo). Em dúvida: só dígitos. */
  function esperaMascara(input) {
    return input.maxLength === 18 || /\d{2}\.\d{3}\.\d{3}\/\d{4}-\d{2}|00\.000\.000\/0000-00/.test(input.placeholder || '');
  }

  const digitosDe = (input) => NS.documento.soDigitos(input.value);

  /**
   * Preenche o campo com o CNPJ e confirma pelo valor real (ignorando a máscara).
   * Tentativa 1: formato indicado pelo campo (ou só dígitos). Tentativas seguintes alternam o formato.
   * @returns {Promise<{alterado:boolean, valorFinal:string, formato:string}>}
   */
  async function preencher(doc) {
    const { tentativas, timeouts } = NS.CONFIG;
    let alterado = false;
    let formatoUsado = 'só dígitos';

    await tentar('Preencher número do documento', async (n) => {
      const input = await localizar();
      if (digitosDe(input) === doc.digitos) {
        NS.log.ok(`O campo já contém o CNPJ (${input.value}) — nenhuma digitação necessária.`);
        await NS.cursor.moverPara(input);
        return;
      }

      const mascarado = (n % 2 === 1) ? esperaMascara(input) : !esperaMascara(input);
      const texto = mascarado ? doc.formatado : doc.digitos;
      formatoUsado = mascarado ? 'com máscara' : 'só dígitos';

      await NS.cursor.moverPara(input);
      await NS.cursor.clicar();
      NS.dom.dispararClique(input);
      input.focus({ preventScroll: true });
      if (document.activeElement !== input) throw new Error('o clique não colocou o foco no campo');

      if (input.value !== '') {
        NS.log.aviso(`O campo continha "${input.value}"; limpando antes de digitar.`);
        limpar(input);
        await dormir(entre([180, 320]));
        if (input.value !== '') throw new Error(`não foi possível limpar o campo (valor atual "${input.value}")`);
      }

      await dormir(entre(NS.CONFIG.digitacao.pausaInicial));
      NS.log.info(`Digitando o CNPJ (${formatoUsado}, ${texto.length} caracteres)...`);
      await digitar(input, texto);
      await dormir(entre(NS.CONFIG.digitacao.pausaFinal));
      input.dispatchEvent(new Event('change', { bubbles: true }));

      await esperarPor(() => digitosDe(input) === doc.digitos,
        { timeout: timeouts.confirmacao, descricao: `valor do campo igual ao CNPJ (atual: "${input.value}")` });
      await dormir(300);
      const atual = localizarInput();
      if (!atual || digitosDe(atual) !== doc.digitos) {
        throw new Error(`o valor mudou após a digitação (atual: "${atual ? atual.value : '—'}")`);
      }
      alterado = true;
    }, tentativas.preencher, tentativas.intervalo);

    const final = localizarInput();
    return { alterado, valorFinal: final.value, formato: formatoUsado };
  }

  function valorAtual() {
    const i = localizarInput();
    return i ? i.value : null;
  }

  NS.campoNumeroDocumento = { localizar, preencher, valorAtual };
})();
