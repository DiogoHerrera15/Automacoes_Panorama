// Cursor visual: uma seta desenhada por cima da página que mostra onde a automação está
// agindo. É só a parte visual; quem dispara o clique real é o pagina.js (clicar), que
// primeiro chama moverPara() e depois animarClique() no mesmo ponto do clique.
//
// - pointer-events: none: o cursor nunca recebe cliques nem atrapalha a pessoa ou o site.
// - O movimento usa o relógio (não requestAnimationFrame): mesmo com a aba em segundo
//   plano a animação termina no tempo previsto e a automação não trava.
// - Se a página rolar, o cursor acompanha o elemento sobre o qual está parado.
// - Qualquer falha do cursor é só registrada: nunca interrompe a automação.

(function (raiz) {
  const { CONFIG } = raiz.CNDT;
  const C = CONFIG.CURSOR;
  const ID = 'cndt-cursor';

  let caixa = null; // elemento do cursor
  let x = 0;
  let y = 0;
  let alvoParado = null; // { el, dx, dy }: elemento e ponto relativo onde o cursor está
  let movendo = false;

  const dormir = (ms) => new Promise((r) => setTimeout(r, ms));
  const suavizar = (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2); // ease-in-out

  function falha(onde, e) {
    console.warn(CONFIG.PREFIXO_LOG, `Cursor visual (${onde}) falhou; a automação segue sem ele.`, e);
  }

  function posicionar(nx, ny) {
    x = nx;
    y = ny;
    if (caixa) caixa.style.transform = `translate(${Math.round(x)}px, ${Math.round(y)}px)`;
  }

  // Mantém o cursor sobre o elemento quando a página rola ou muda de tamanho.
  function acompanhar() {
    if (movendo || !alvoParado || !alvoParado.el.isConnected) return;
    const r = alvoParado.el.getBoundingClientRect();
    posicionar(r.left + alvoParado.dx, r.top + alvoParado.dy);
  }

  function criar() {
    if (caixa && caixa.isConnected) return caixa;
    caixa = document.createElement('div');
    caixa.id = ID;
    caixa.setAttribute('aria-hidden', 'true');
    Object.assign(caixa.style, {
      position: 'fixed', left: '0', top: '0', width: '0', height: '0',
      zIndex: '2147483646', pointerEvents: 'none', transition: 'opacity .25s', opacity: '0',
    });
    // Seta (a ponta fica exatamente no ponto (0,0) do elemento = ponto do clique).
    caixa.innerHTML = `
      <svg width="26" height="30" viewBox="0 0 26 30" style="position:absolute;left:-3px;top:-2px;overflow:visible;filter:drop-shadow(1px 2px 2px rgba(0,0,0,.35))">
        <path d="M3 2 L3 24 L9 18.5 L13 27.5 L17 25.8 L13 17 L21 17 Z" fill="${C.cor}" stroke="#fff" stroke-width="1.6" stroke-linejoin="round"/>
      </svg>`;
    (document.body || document.documentElement).appendChild(caixa);
    window.addEventListener('scroll', acompanhar, { passive: true, capture: true });
    window.addEventListener('resize', acompanhar, { passive: true });
    return caixa;
  }

  // Aparece num ponto inicial (canto superior direito do formulário, longe do alvo),
  // para que o deslocamento até o primeiro elemento seja visível.
  function mostrar() {
    if (!C.ativo) return;
    try {
      const novo = !caixa || !caixa.isConnected;
      criar();
      if (novo) posicionar(Math.min(window.innerWidth - 40, 520), 60);
      caixa.style.opacity = '1';
    } catch (e) {
      falha('mostrar', e);
    }
  }

  function esconder() {
    try {
      if (caixa) caixa.style.opacity = '0';
      alvoParado = null;
    } catch (e) {
      falha('esconder', e);
    }
  }

  // Ponto do elemento onde o cursor para (e onde o clique acontece): em campos de texto,
  // um pouco à esquerda (como uma pessoa clicando para digitar); nos demais, o centro.
  function pontoDoElemento(el) {
    const r = el.getBoundingClientRect();
    const campoTexto = el.tagName === 'INPUT' && /^(text|tel|search|email|)$/i.test(el.getAttribute('type') || '');
    const dx = campoTexto ? Math.min(24, r.width / 2) : r.width / 2;
    return { dx, dy: r.height / 2, x: r.left + dx, y: r.top + r.height / 2 };
  }

  // Lei de Fitts: alvo longe ou pequeno = movimento mais demorado. Com uma variação de
  // ±10%, porque uma pessoa nunca repete o mesmo tempo.
  function duracaoDoMovimento(distancia, larguraAlvo) {
    const bits = Math.log2(distancia / Math.max(8, larguraAlvo) + 1);
    const t = (C.fittsA + C.fittsB * bits) * (0.9 + Math.random() * 0.2);
    return Math.min(C.duracaoMax, Math.max(C.duracaoMin, t));
  }

  function dentroDaTela(el) {
    const r = el.getBoundingClientRect();
    return r.top >= 0 && r.left >= 0 && r.bottom <= window.innerHeight && r.right <= window.innerWidth;
  }

  // Rola até o elemento (se preciso) e espera ele estar na tela e parado, com limite de
  // tempo. A rolagem suave pode demorar a começar (ou nem rodar, com a aba em segundo
  // plano): só conta como "parada" depois que o elemento entrou na tela. Se o limite
  // estourar, rola de uma vez. Devolve true se o elemento terminou dentro da tela.
  async function rolarAte(el) {
    if (dentroDaTela(el)) return true;
    el.scrollIntoView({ block: 'center', inline: 'nearest', behavior: 'smooth' });
    const fim = Date.now() + C.limiteRolagem;
    let anterior = null;
    let estavel = 0;
    while (Date.now() < fim && estavel < 3) {
      await dormir(50);
      const topo = el.getBoundingClientRect().top;
      estavel = dentroDaTela(el) && anterior !== null && Math.abs(topo - anterior) < 0.5 ? estavel + 1 : 0;
      anterior = topo;
    }
    if (!dentroDaTela(el)) el.scrollIntoView({ block: 'center', inline: 'nearest', behavior: 'instant' });
    return dentroDaTela(el);
  }

  // Leva o cursor suavemente até o elemento. Devolve o ponto final {x, y} (coordenadas da
  // janela), usado para o clique real. Mesmo com o cursor desligado ou com falha, rola até
  // o elemento e devolve o ponto, para o clique acontecer no lugar certo.
  async function moverPara(el) {
    await rolarAte(el);
    if (!C.ativo) return pontoDoElemento(el);
    try {
      mostrar();
      alvoParado = null;
      movendo = true;
      const x0 = x;
      const y0 = y;
      let destino = pontoDoElemento(el);
      const distancia = Math.hypot(destino.x - x0, destino.y - y0);
      const duracao = duracaoDoMovimento(distancia, el.getBoundingClientRect().width);
      // Leve curva no trajeto, como a mão de uma pessoa (nunca uma linha reta perfeita).
      const curva = Math.min(60, distancia * 0.15) * (Math.random() < 0.5 ? -1 : 1);
      const inicio = Date.now();
      for (;;) {
        destino = pontoDoElemento(el); // o elemento pode se mover durante a animação
        const t = Math.min(1, (Date.now() - inicio) / duracao);
        const k = suavizar(t);
        const arco = Math.sin(Math.PI * t) * curva;
        const nx = x0 + (destino.x - x0) * k;
        const ny = y0 + (destino.y - y0) * k;
        // deslocamento perpendicular ao trajeto
        const len = Math.hypot(destino.x - x0, destino.y - y0) || 1;
        posicionar(nx + (-(destino.y - y0) / len) * arco, ny + ((destino.x - x0) / len) * arco);
        if (t >= 1) break;
        await dormir(16);
      }
      posicionar(destino.x, destino.y);
      alvoParado = { el, dx: destino.dx, dy: destino.dy };
      return destino;
    } catch (e) {
      falha('mover', e);
      return pontoDoElemento(el);
    } finally {
      movendo = false;
    }
  }

  // Animação do clique: a seta "afunda" e sai uma onda no ponto (x, y).
  function animarClique(px = x, py = y) {
    if (!C.ativo) return;
    try {
      const onda = document.createElement('div');
      onda.setAttribute('aria-hidden', 'true');
      Object.assign(onda.style, {
        position: 'fixed', left: `${px - 14}px`, top: `${py - 14}px`, width: '28px', height: '28px',
        borderRadius: '50%', border: `3px solid ${C.cor}`, pointerEvents: 'none', zIndex: '2147483645',
        opacity: '0.9', transform: 'scale(0.3)', transition: 'transform .45s ease-out, opacity .45s ease-out',
      });
      (document.body || document.documentElement).appendChild(onda);
      requestAnimationFrame(() => {
        onda.style.transform = 'scale(1.6)';
        onda.style.opacity = '0';
      });
      setTimeout(() => onda.remove(), 600);
      if (caixa) {
        const svg = caixa.firstElementChild;
        svg.style.transition = 'transform .09s';
        svg.style.transform = 'scale(0.82)';
        setTimeout(() => { svg.style.transform = ''; }, 140);
      }
    } catch (e) {
      falha('clique', e);
    }
  }

  raiz.CNDT.CURSOR = { mostrar, esconder, moverPara, animarClique, rolarAte, pontoDoElemento, duracaoDoMovimento };
})(globalThis);
