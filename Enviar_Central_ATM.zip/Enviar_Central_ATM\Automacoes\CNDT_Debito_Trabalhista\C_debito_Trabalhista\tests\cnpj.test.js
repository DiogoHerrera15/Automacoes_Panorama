// Testes das funções puras e do manifest. Rodar na pasta cndt_certidao: node --test tests/
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { test } = require('node:test');

const raiz = path.join(__dirname, '..');
const CNPJ = require('../cnpj.js');
const CONFIG = require('../config.js');

test('formata como a máscara do site', () => {
  assert.equal(CNPJ.formatar('48291735000109'), '48.291.735/0001-09');
  assert.equal(CNPJ.formatar('48.291.735/0001-09'), '48.291.735/0001-09');
  assert.equal(CNPJ.formatar('12345678909'), '123.456.789-09');
  assert.equal(CNPJ.formatar('12abc34'), '12ABC34');
});

// O CNPJ de teste informado tem dígitos verificadores que não conferem (para a raiz
// 48.291.735/0001 o correto seria -48). A etapa 1 preenche mesmo assim, com aviso.
test('CNPJ de teste da etapa 1: formato aceito pelo site, DV não confere', () => {
  const r = CNPJ.validar(CONFIG.CNPJ_TESTE);
  assert.equal(r.ok, false);
  assert.equal(CNPJ.validar('48.291.735/0001-48').ok, true);
  assert.equal(r.tipo, 'CNPJ');
  assert.equal(r.formatado, '48.291.735/0001-09');
  assert.ok(r.formatado.length <= 18); // maxlength do campo no site
});

test('valida dígitos verificadores', () => {
  assert.equal(CNPJ.validar('11.222.333/0001-81').ok, true);
  assert.equal(CNPJ.validar('11.222.333/0001-82').ok, false);
  assert.equal(CNPJ.validar('11111111111111').ok, false);
  assert.equal(CNPJ.validar('12ABC34501DE35').ok, true); // exemplo oficial do CNPJ alfanumérico
  assert.equal(CNPJ.validar('123.456.789-09').ok, true);
  assert.equal(CNPJ.validar('123.456.789-00').ok, false);
  assert.equal(CNPJ.validar('123').ok, false);
  assert.equal(CNPJ.validar('').normalizado, '');
});

test('manifest MV3 e arquivos referenciados existem', () => {
  const m = JSON.parse(fs.readFileSync(path.join(raiz, 'manifest.json'), 'utf8'));
  assert.equal(m.manifest_version, 3);
  assert.equal(m.name, 'C_debito_Trabalhista');
  assert.ok(fs.existsSync(path.join(raiz, m.background.service_worker)));
  for (const cs of m.content_scripts) {
    assert.deepEqual(cs.matches, ['https://cndt-certidao.tst.jus.br/*']);
    assert.deepEqual(cs.js, ['config.js', 'cnpj.js', 'cursor.js', 'pagina.js', 'content.js']);
    for (const js of cs.js) assert.ok(fs.existsSync(path.join(raiz, js)), js);
  }
});

test('nenhum envio direto do formulário nem botões fixos no código (só via config)', () => {
  const codigo = ['content.js', 'pagina.js', 'cursor.js'].map((f) => fs.readFileSync(path.join(raiz, f), 'utf8')).join('\n');
  assert.ok(!/botao-emitir|botao-enviar|botao-ouvir|\.submit\(|requestSubmit/.test(codigo));
});

test('cursor visual nunca recebe cliques (pointer-events: none) e não usa requestAnimationFrame no movimento', () => {
  const cursor = fs.readFileSync(path.join(raiz, 'cursor.js'), 'utf8');
  const blocos = cursor.match(/pointerEvents:\s*'none'/g) || [];
  assert.ok(blocos.length >= 2, 'seta e onda do clique precisam de pointer-events: none');
  const mover = cursor.slice(cursor.indexOf('async function moverPara'), cursor.indexOf('function animarClique'));
  assert.ok(!/requestAnimationFrame/.test(mover), 'movimento deve usar o relógio (aba em segundo plano não trava)');
});

test('etapa 2: só observa o captcha (isTrusted), nunca escreve nele; só clica no campo e em Emitir', () => {
  const content = fs.readFileSync(path.join(raiz, 'content.js'), 'utf8');
  const pagina = fs.readFileSync(path.join(raiz, 'pagina.js'), 'utf8');
  // os únicos cliques da automação: o campo CNPJ/CPF e o botão "Emitir Certidão"
  assert.deepEqual(content.match(/clicar\([^)]*\)/g), ['clicar(campo)', 'clicar(botao)']);
  assert.ok(!/\.click\(\)/.test(content));
  // o clique em Emitir só acontece depois da espera pela digitação da pessoa
  const etapa2 = content.slice(content.indexOf('async function aguardarCaptchaEEmitir'));
  assert.ok(etapa2.indexOf('esperarDigitacaoDoUsuario') < etapa2.indexOf('clicar(botao)'));
  assert.ok(etapa2.indexOf('if (!P.clicarEmitir)') < etapa2.indexOf('clicar(botao)'));
  // o botão é o "Emitir Certidão", nunca o "Emitir e Enviar" nem "Emitir Nova"
  assert.equal(CONFIG.SELETORES.botaoEmitir, '#botao-emitir');
  assert.ok(CONFIG.SELETORES.textoBotaoEmitir.test('Emitir Certidão'));
  assert.ok(!CONFIG.SELETORES.textoBotaoEmitir.test('Emitir e Enviar Certidão por e-mail'));
  assert.ok(!CONFIG.SELETORES.textoBotaoEmitir.test('Emitir Nova Certidão'));
  assert.ok(CONFIG.CAPTCHA_PELO_USUARIO.maxTentativas >= 1 && CONFIG.CAPTCHA_PELO_USUARIO.maxTentativas <= 5);
  // nada escreve no captcha
  assert.ok(!/(digitarHumanizado|escreverNoCampo|apagarCampo|pressionar)\(captcha/.test(content));
  // a espera ignora eventos que não vêm da pessoa
  const espera = pagina.slice(pagina.indexOf('function esperarDigitacaoDoUsuario'), pagina.indexOf('function botaoEmitir'));
  assert.ok(/if \(!e\.isTrusted\) return;/.test(espera));
  assert.ok(!/setterValor|\.value\s*=/.test(espera), 'a espera não pode alterar o campo');
  const P = CONFIG.CAPTCHA_PELO_USUARIO;
  assert.ok(P.limiteEspera > 0 && P.silencioParaConcluir > 0, 'a espera precisa de limite');
});

test('digitação humanizada: intervalos variáveis configurados', () => {
  const D = CONFIG.DIGITACAO;
  assert.ok(D.intervaloMin > 0 && D.intervaloMax > D.intervaloMin);
  assert.ok(D.chancePausa >= 0 && D.chancePausa < 1);
});
