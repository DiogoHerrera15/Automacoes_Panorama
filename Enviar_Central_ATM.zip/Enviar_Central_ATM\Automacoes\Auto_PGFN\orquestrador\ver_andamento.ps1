﻿# Mostra a situação de cada CNPJ de cnpjs.json (pendente | em_andamento | concluido | erro) e as últimas linhas do
# registro do orquestrador. Só lê: não muda nada e pode ser usado com a automação rodando.
$ErrorActionPreference = 'Stop'
$AQUI = $PSScriptRoot
$BASE = Split-Path $AQUI -Parent
$ler = { param($arq) if (Test-Path -LiteralPath $arq) { Get-Content -LiteralPath $arq -Raw -Encoding UTF8 | ConvertFrom-Json } }
$cfg = & $ler (Join-Path $BASE 'cnpjs.json')
$and = & $ler (Join-Path $AQUI 'andamento.json')
if (-not $cfg) { Write-Host 'cnpjs.json não encontrado.'; exit 1 }
$rodando = [bool](Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -like '*orquestrador.ps1*' })
Write-Host ''
Write-Host ("  Automação PGFN - {0}   (orquestrador {1})" -f (Get-Date -Format 'dd/MM/yyyy HH:mm'), $(if ($rodando) { 'RODANDO' } else { 'parado' }))
Write-Host ''
$cont = @{}
$n = 0
foreach ($g in $cfg.certificados) {
  Write-Host "  Certificado: $($g.certificado)"
  foreach ($c in $g.cnpjs) {
    $n++
    $d = ([string]$c) -replace '\D', ''
    $a = if ($and) { $and.$d } else { $null }
    $sit = if ($a) { [string]$a.situacao } else { 'pendente' }
    $cont[$sit] = 1 + [int]$cont[$sit]
    $motivo = if ($a -and $sit -ne 'concluido') { ([string]$a.mensagem -split "`n")[0] } else { '' }
    if ($motivo.Length -gt 90) { $motivo = $motivo.Substring(0, 90) + '…' }
    $cor = @{ concluido = 'Green'; erro = 'Red'; em_andamento = 'Yellow' }[$sit]
    if (-not $cor) { $cor = 'Gray' }
    Write-Host ("   {0,3}  {1}  {2,-12} {3}" -f $n, $d, $sit, $motivo) -ForegroundColor $cor
  }
}
Write-Host ''
Write-Host ('  Total: ' + (($cont.GetEnumerator() | Sort-Object Name | ForEach-Object { "$($_.Name) $($_.Value)" }) -join ' | '))
$log = Join-Path $AQUI 'orquestrador.log'
if (Test-Path -LiteralPath $log) {
  Write-Host ''
  Write-Host '  Últimas linhas do registro (orquestrador\orquestrador.log):'
  Get-Content -LiteralPath $log -Tail 12 -Encoding UTF8 | ForEach-Object { Write-Host "   $_" }
}
Write-Host ''
