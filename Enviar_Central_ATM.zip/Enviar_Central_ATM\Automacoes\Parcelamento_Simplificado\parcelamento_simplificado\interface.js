// Parcelamento Simplificado - interface (janela da extensão).
// Esta tela só CONTROLA a automação: guarda a pasta e a lista (chrome.storage.local) e manda iniciar/parar.
// Quem consulta, navega e salva é o content.js, que lê o que está guardado aqui e devolve o andamento (ps_status).
// Chaves: ps_rascunho (o que foi digitado), ps_config (pasta + empresas ao iniciar), ps_comando (ativa/parar),
// ps_status (andamento, escrito pelo content.js) e parcelamento_simplificado_fila (empresas já feitas).
'use strict';

const L = self.ParcelamentoLista;
const K = { rascunho: 'ps_rascunho', config: 'ps_config', cmd: 'ps_comando', status: 'ps_status' };
// O andamento é guardado por pasta de destino (mesma regra do content.js: CHAVE_FILA + ":" + ID_LOTE).
const chaveFilaDe = (pasta) => `parcelamento_simplificado_fila:interface:${pasta}`;
const ESTADOS_FEITOS = ['sem negociação', 'sem negociação ativa', 'DARF salvo'];
const URL_ECAC = 'https://cav.receita.fazenda.gov.br/autenticacao/login';
const PADROES_ECAC = ['https://cav.receita.fazenda.gov.br/*', 'https://*.cav.receita.fazenda.gov.br/*'];
const SEM_SINAL_MS = 180000; // sem notícias da página por 3 min: considera parada
const $ = (id) => document.getElementById(id);

let lido = { itens: [], erros: [], repetidos: 0, ajustados: 0 };
let status = null, fila = null;
const pastaDigitada = () => L.limparPastaPrincipal($('pasta').value);

// ---------------- estado da execução ----------------
function estadoEfetivo() {
  if (!status) return 'inativo';
  if ((status.estado === 'processando' || status.estado === 'parando') && Date.now() - (status.t || 0) > SEM_SINAL_MS) return 'inativo';
  return status.estado || 'inativo';
}
const rodando = () => ['processando', 'parando'].includes(estadoEfetivo());

// ---------------- mensagens da própria tela ----------------
function mensagem(texto, tipo = '') { $('msg').className = `msg ${tipo}`; $('msg').textContent = texto; }

// ---------------- lista e pasta ----------------
function atualizarLista() {
  lido = L.lerLista($('lista').value);
  const { itens, erros, repetidos, ajustados } = lido;
  const c = $('contagem');
  c.replaceChildren();
  const bom = document.createElement('span');
  bom.className = 'bom';
  bom.textContent = `${itens.length} empresa(s) válida(s)`;
  c.append(bom);
  if (repetidos) c.append(` · ${repetidos} repetida(s) ignorada(s)`);
  if (ajustados) c.append(` · ${ajustados} CNPJ(s) com zeros à esquerda completados`);
  if (erros.length) {
    const ruim = document.createElement('span');
    ruim.className = 'ruim';
    ruim.textContent = ` · ${erros.length} linha(s) com problema (serão ignoradas)`;
    c.append(ruim);
  }
  const dif = itens.filter((i) => i.diferenciada).length;
  if (dif) c.append(` · ${dif} com nome de pasta repetido (o CNPJ foi somado ao nome)`);
  $('ignoradas').hidden = !erros.length;
  $('erros').replaceChildren(...erros.slice(0, 100).map((e) => { const li = document.createElement('li'); li.textContent = e; return li; }));
}

function atualizarCaminho(real) {
  const pasta = pastaDigitada();
  $('caminhoPrevisto').textContent = real ? `Pasta de resultados: ${real}` :
    pasta ? `Os arquivos vão para: Downloads\\${pasta.replace(/\//g, '\\')}\\<NOME DA EMPRESA>\\` :
      'Criada dentro da pasta Downloads do Chrome, com uma subpasta para cada empresa.';
}

// ---------------- andamento ----------------
function contar() {
  const f = fila || { feitos: {} };
  let sucesso = 0;
  for (const it of lido.itens) {
    const e = (f.feitos || {})[it.cnpj];
    if (e && ESTADOS_FEITOS.includes(e.estado)) sucesso += 1;
  }
  const problemas = L.problemasDaFila(lido.itens, f.feitos);
  const pulados = L.puladosCaixa(lido.itens, f.feitos); // pulados pelo aviso da Caixa Postal
  const erros = problemas.length;
  const total = lido.itens.length, feitas = sucesso + erros + pulados.length;
  return { total, sucesso, erros, feitas, faltam: total - feitas, problemas, pulados };
}

function horaDe(t) { return new Date(t).toLocaleTimeString('pt-BR'); }

const ROTULO = { inativo: 'Parada', aguardando: 'Aguardando o e-CAC', processando: 'Processando…', parando: 'Parando…', parado: 'Parada', concluido: 'Concluída', erro: 'Parada com erro' };

function desenhar() {
  const n = contar();
  $('nTotal').textContent = n.total; $('nFeitas').textContent = n.feitas; $('nFaltam').textContent = n.faltam;
  $('nOk').textContent = n.sucesso; $('nErros').textContent = n.erros; $('nPulados').textContent = n.pulados.length;
  const pct = n.total ? Math.floor((n.feitas / n.total) * 100) : 0;
  $('barra').style.width = `${pct}%`;
  $('barraGeral').setAttribute('aria-valuenow', String(pct));
  $('legendaBarra').textContent = n.total ? `${n.feitas} de ${n.total} empresas processadas (${pct}%) · faltam ${n.faltam}` : 'Nenhuma empresa informada.';

  const est = estadoEfetivo();
  const selo = $('selo');
  selo.textContent = ROTULO[est] || 'Parada';
  selo.className = `selo ${est}`;
  const s = status || {};
  const ativa = rodando() || est === 'parado' || est === 'erro';
  $('empresaAtual').textContent = (ativa || est === 'concluido') && s.atual ? s.atual.nome : '—';
  $('cnpjAtual').textContent = (ativa || est === 'concluido') && s.atual ? L.formatarCnpj(s.atual.cnpj) : '—';
  $('etapa').textContent = s.mensagem ? `· ${s.mensagem.replace(/\s*\n\s*/g, ' · ').slice(0, 160)}` : '';

  const log = $('log');
  const msgs = (s.msgs || []);
  const perto = log.scrollHeight - log.scrollTop - log.clientHeight < 40;
  log.replaceChildren(...(msgs.length ? msgs.map((m) => {
    const li = document.createElement('li');
    if (m.tipo === 'erro') li.className = 'erro'; else if (m.tipo === 'ok') li.className = 'ok';
    const t = document.createElement('time'); t.textContent = horaDe(m.t);
    li.append(t, m.texto);
    return li;
  }) : [Object.assign(document.createElement('li'), { className: 'vazio', textContent: 'As mensagens aparecem aqui quando a automação começar.' })]));
  if (perto) log.scrollTop = log.scrollHeight;

  desenharRelatorio(n);

  const r = rodando();
  const pronto = pastaDigitada() && lido.itens.length; // linhas com problema NÃO impedem o início: são ignoradas e listadas
  $('btnIniciar').disabled = r || !pronto;
  $('btnParar').disabled = !r || est === 'parando';
  $('btnLimpar').disabled = r;
  $('btnZerar').disabled = r || !pastaDigitada();
  // "Continuar" também quando só restam empresas com problema: o clique refaz todas elas, uma vez cada.
  $('btnIniciar').textContent = n.feitas > 0 && (n.faltam > 0 || n.erros > 0) ? '▶ Continuar automação' : '▶ Iniciar automação';
}

// ---------------- relatório de problemas ----------------
// Mostra, ao vivo, as empresas que deram problema (com o motivo) e as linhas da lista que foram ignoradas.
function desenharRelatorio(n) {
  const rej = lido.rejeitadas || [];
  const algum = n.problemas.length || rej.length || n.pulados.length;
  $('relatorio').hidden = !algum;
  if (!algum) return;
  $('relatorioResumo').textContent = `${n.problemas.length} empresa(s) com problema` +
    (n.pulados.length ? ` · ${n.pulados.length} pulada(s) por aviso da Caixa Postal` : '') +
    (rej.length ? ` · ${rej.length} linha(s) da lista ignorada(s)` : '') + ' · a automação não parou por causa deles.';
  $('btnRefazerCaixa').hidden = !n.pulados.length;
  $('btnRefazerCaixa').disabled = rodando();
  const itens = n.pulados.map((p) => {
    const li = document.createElement('li');
    const b = document.createElement('b'); b.textContent = `${L.formatarCnpj(p.cnpj)} - ${p.nome}`;
    const s = document.createElement('span'); s.textContent = 'Pulado - Aviso de Caixa Postal: leia as mensagens importantes na Caixa Postal do e-CAC deste CNPJ (a automação não abre a Caixa Postal).';
    li.append(b, s); return li;
  }).concat(n.problemas.map((p) => {
    const li = document.createElement('li');
    const b = document.createElement('b'); b.textContent = `${L.formatarCnpj(p.cnpj)} - ${p.nome}`;
    const s = document.createElement('span'); s.textContent = p.motivo;
    li.append(b, s); return li;
  })).concat(rej.map((r) => {
    const li = document.createElement('li');
    const b = document.createElement('b'); b.textContent = `Linha ${r.linha}: ${r.texto}`;
    const s = document.createElement('span'); s.textContent = `Ignorada: ${r.motivo}`;
    li.append(b, s); return li;
  }));
  $('problemas').replaceChildren(...itens);
}

async function salvarRelatorio() {
  const pasta = pastaDigitada();
  if (!pasta) return mensagem('Informe a pasta de destino.', 'erro');
  const n = contar();
  const texto = L.textoRelatorio({ pasta, total: n.total, sucesso: n.sucesso, problemas: n.problemas, pulados: n.pulados, rejeitadas: lido.rejeitadas, pendentes: Math.max(0, n.faltam), quando: new Date().toLocaleString('pt-BR') });
  // quem grava é o service worker (ele confirma o nome e a pasta e espera o arquivo ser salvo por inteiro)
  const r = await chrome.runtime.sendMessage({ ps: 'salvar-relatorio-janela', dados: { pasta, texto } });
  if (!r || !r.ok) return mensagem(`Não consegui salvar o relatório: ${r ? r.erro : 'sem resposta da extensão'}`, 'erro');
  mensagem(`Relatório salvo em ${r.caminho}`, 'ok');
}

// Depois de ler as mensagens na Caixa Postal do e-CAC: devolve as empresas puladas por esse aviso para a fila.
// (Só apaga o registro delas no andamento desta pasta; "Continuar automação" as processa.)
async function refazerPuladas() {
  const pasta = pastaDigitada();
  const k = chaveFilaDe(pasta);
  const o = await chrome.storage.local.get(k);
  const f = o[k];
  if (!f || !f.feitos) return mensagem('Não há empresas puladas nesta pasta.', 'erro');
  let n = 0;
  for (const cnpj of Object.keys(f.feitos)) if (f.feitos[cnpj].estado === L.ESTADO_CAIXA) { delete f.feitos[cnpj]; n += 1; }
  await chrome.storage.local.set({ [k]: f });
  fila = f;
  desenhar();
  mensagem(`${n} empresa(s) voltaram para a fila. Clique em "Continuar automação" para processá-las (confirme antes que as mensagens da Caixa Postal foram lidas).`, 'ok');
}

function atualizarTudo() { atualizarLista(); atualizarCaminho(); desarmar(); desenhar(); }

// Abre o e-CAC numa janela ANÔNIMA (cada sessão anônima nova pede o certificado de novo, o que permite trocar de
// certificado). Usa uma janela anônima já aberta, se houver; se o Chrome não deixar (extensão sem "Permitir no modo
// anônimo"), abre numa aba comum como antes.
async function abrirEcac() {
  try {
    const anonimas = (await chrome.windows.getAll({ windowTypes: ['normal'] })).filter((w) => w.incognito);
    if (anonimas.length) {
      await chrome.tabs.create({ windowId: anonimas[0].id, url: URL_ECAC, active: true });
      await chrome.windows.update(anonimas[0].id, { focused: true }).catch(() => {});
    } else {
      await chrome.windows.create({ url: URL_ECAC, incognito: true, focused: true });
    }
  } catch (e) {
    console.warn('não consegui abrir o e-CAC em janela anônima:', e.message);
    chrome.tabs.create({ url: URL_ECAC });
  }
}

// ---------------- e-CAC aberto? ----------------
async function acharAbaEcac() {
  const abas = await chrome.tabs.query({ url: PADROES_ECAC }).catch(() => []);
  const dentro = abas.filter((a) => !/\/autenticacao\//i.test(a.url || ''));
  // com e-CAC aberto na janela comum e na anônima, vale o da anônima (é onde a Central abre)
  const anon = dentro.filter((a) => a.incognito);
  return anon.find((a) => a.active) || anon[0] || dentro.find((a) => a.active) || dentro[0] ||
    abas.find((a) => a.incognito) || abas[0] || null;
}

async function mostrarEstadoEcac() {
  const aba = await acharAbaEcac();
  const dentro = aba && !/\/autenticacao\//i.test(aba.url || '');
  $('estadoEcac').className = `estado ${dentro ? 'ok' : 'nao'}`;
  $('estadoEcac').textContent = dentro ? '✔ e-CAC aberto e pronto.' :
    aba ? '✖ O e-CAC está na tela de login: entre com o certificado.' : '✖ O e-CAC não está aberto no Chrome.';
  $('btnAbrirEcac').hidden = !!aba;
  return aba;
}

// ---------------- botões ----------------
async function iniciar() {
  const pasta = pastaDigitada();
  const r = L.lerLista($('lista').value);
  if (!pasta) return mensagem('Informe o nome da pasta de destino.', 'erro');
  if (!r.itens.length) return mensagem('Cole pelo menos uma empresa no formato cnpj;nome_da_empresa.', 'erro');
  if (rodando()) return mensagem('A automação já está em andamento.', 'erro');
  $('pasta').value = pasta;
  // linhas com problema (CNPJ inválido, sem nome...) não impedem nada: ficam de fora e vão para o relatório
  const ignoradas = r.rejeitadas.length ? ` ${r.rejeitadas.length} linha(s) com problema foram ignoradas (veja o relatório).` : '';
  await chrome.storage.local.set({
    [K.config]: { pasta, itens: r.itens.map(({ cnpj, nome, pasta: p }) => ({ cnpj, nome, pasta: p })), rejeitadas: r.rejeitadas, continuar: true, t: Date.now() },
    [K.cmd]: { ativa: true, parar: false, t: Date.now() },
    [K.rascunho]: { pasta, lista: $('lista').value },
  });
  const aba = await mostrarEstadoEcac();
  const noLogin = !aba || /\/autenticacao\//i.test(aba.url || '');
  if (noLogin) {
    if (!aba) abrirEcac();
    mensagem(`Configuração salva (${r.itens.length} empresa(s)).${ignoradas} Entre no e-CAC e abra Pagamento e Parcelamento > Parcelamento - Solicitar e acompanhar: a automação começa sozinha.`, 'ok');
    return;
  }
  await chrome.tabs.update(aba.id, { active: true }).catch(() => {});
  await chrome.windows.update(aba.windowId, { focused: true }).catch(() => {});
  try {
    await chrome.tabs.sendMessage(aba.id, { tipo: 'iniciar' }, { frameId: 0 });
    mensagem(`Iniciado: ${r.itens.length} empresa(s).${ignoradas} Acompanhe aqui e no aviso do canto superior direito do e-CAC.`, 'ok');
  } catch (e) {
    mensagem('Configuração salva, mas a página do e-CAC não respondeu. Aperte F5 nela (a extensão foi recarregada) e clique em Iniciar de novo.', 'erro');
  }
}

async function parar() {
  await chrome.storage.local.set({ [K.cmd]: { ativa: false, parar: true, t: Date.now() } });
  mensagem('Pedido de parada enviado. A automação termina a etapa em andamento (para não deixar um DARF pela metade) e para. A empresa atual continua pendente.', 'ok');
}

// Limpar e Zerar pedem dois cliques (o 2º confirma).
let armado = null;
function desarmar() {
  if (!armado) return;
  clearTimeout(armado.timer);
  armado.botao.classList.remove('confirmar');
  armado.botao.textContent = armado.texto;
  armado = null;
}
function confirmarDuasVezes(botao, aviso, acao) {
  if (armado && armado.botao === botao) { desarmar(); return acao(); }
  desarmar();
  armado = { botao, texto: botao.textContent, timer: setTimeout(desarmar, 6000) };
  botao.classList.add('confirmar');
  botao.textContent = 'Clique de novo para confirmar';
  mensagem(aviso, 'erro');
}

async function limpar() {
  $('lista').value = '';
  await chrome.storage.local.remove([K.config]);
  await chrome.storage.local.set({ [K.rascunho]: { pasta: $('pasta').value, lista: '' }, [K.cmd]: { ativa: false, parar: false, t: Date.now() } });
  atualizarTudo();
  mensagem('Lista limpa. O que já foi salvo em Downloads não foi apagado.', 'ok');
}

async function zerar() {
  const pasta = pastaDigitada();
  await chrome.storage.local.remove(chaveFilaDe(pasta));
  fila = null;
  desenhar();
  mensagem(`Andamento de "${pasta}" zerado: todas as empresas serão refeitas. Os arquivos já salvos continuam em Downloads.`, 'ok');
}

// Mostra a pasta no Explorador: o mais recente arquivo salvo dentro da pasta principal.
async function achaPastaReal() {
  const pasta = pastaDigitada();
  if (!pasta) return null;
  const ultimo = pasta.split('/').pop();
  const itens = await chrome.downloads.search({ query: [ultimo], orderBy: ['-startTime'] }).catch(() => []);
  const alvo = pasta.replace(/\//g, '\\');
  for (const it of itens) {
    const f = (it.filename || '').replace(/\//g, '\\');
    const i = f.toLowerCase().indexOf(`\\${alvo.toLowerCase()}\\`);
    if (i >= 0 && it.exists !== false) return { id: it.id, caminho: f.slice(0, i + 1 + alvo.length) };
  }
  return null;
}

async function abrirPasta() {
  const achada = await achaPastaReal();
  if (achada) {
    chrome.downloads.show(achada.id);
    mensagem(`Aberta a pasta do último arquivo salvo. A pasta principal é ${achada.caminho}`, 'ok');
  } else {
    chrome.downloads.showDefaultFolder();
    mensagem('Ainda não há arquivos nesta pasta. Abri a pasta Downloads; a pasta de resultados será criada dentro dela quando o primeiro arquivo for salvo.', '');
  }
}

async function mostrarCaminhoReal() {
  const achada = await achaPastaReal().catch(() => null);
  atualizarCaminho(achada && achada.caminho);
}

// ---------------- início ----------------
async function carregarFila() {
  const pasta = pastaDigitada();
  if (!pasta) { fila = null; return; }
  const k = chaveFilaDe(pasta);
  const o = await chrome.storage.local.get(k).catch(() => ({}));
  if (pastaDigitada() === pasta) fila = o[k] || null; // o usuário pode ter digitado mais enquanto lia
}

let adiarRascunho = null;
function guardarRascunho() {
  clearTimeout(adiarRascunho);
  adiarRascunho = setTimeout(() => chrome.storage.local.set({ [K.rascunho]: { pasta: $('pasta').value, lista: $('lista').value } }).catch(() => {}), 300);
}

// A janela abre encostada na direita da tela, para não cobrir o e-CAC por inteiro.
async function posicionarJanela() {
  try {
    if (sessionStorage.getItem('posicionada')) return;
    sessionStorage.setItem('posicionada', '1');
    const w = await chrome.windows.getCurrent();
    if (w.type !== 'popup') return;
    const largura = Math.min(680, screen.availWidth);
    await chrome.windows.update(w.id, { left: screen.availLeft + screen.availWidth - largura, top: screen.availTop, width: largura, height: screen.availHeight });
  } catch (_) { /* sem permissão ou janela comum: deixa como está */ }
}

async function iniciarTela() {
  $('versao').textContent = `v${chrome.runtime.getManifest().version}`;
  const o = await chrome.storage.local.get([K.rascunho, K.config, K.status]);
  const rascunho = o[K.rascunho], cfg = o[K.config];
  if (rascunho) { $('pasta').value = rascunho.pasta || ''; $('lista').value = rascunho.lista || ''; }
  else if (cfg) { $('pasta').value = cfg.pasta || ''; $('lista').value = (cfg.itens || []).map((i) => `${i.cnpj};${i.nome}`).join('\n'); }
  status = o[K.status] || null;
  await carregarFila();
  atualizarTudo();
  mostrarEstadoEcac();
  mostrarCaminhoReal();

  $('pasta').addEventListener('input', () => { atualizarTudo(); guardarRascunho(); carregarFila().then(desenhar); });
  $('lista').addEventListener('input', () => { atualizarTudo(); guardarRascunho(); });
  $('btnIniciar').addEventListener('click', () => iniciar().catch((e) => mensagem(`Erro: ${e.message}`, 'erro')));
  $('btnParar').addEventListener('click', () => parar().catch((e) => mensagem(`Erro: ${e.message}`, 'erro')));
  $('btnLimpar').addEventListener('click', () => confirmarDuasVezes($('btnLimpar'),
    'Limpar apaga a lista digitada (não apaga arquivos já salvos). Clique de novo para confirmar.', limpar).catch((e) => mensagem(`Erro: ${e.message}`, 'erro')));
  $('btnZerar').addEventListener('click', () => confirmarDuasVezes($('btnZerar'),
    'Zerar esquece o que já foi feito nesta pasta e a lista recomeça do 1º CNPJ (os arquivos ficam). Clique de novo para confirmar.', zerar).catch((e) => mensagem(`Erro: ${e.message}`, 'erro')));
  $('btnRefazerCaixa').addEventListener('click', () => refazerPuladas().catch((e) => mensagem(`Erro: ${e.message}`, 'erro')));
  $('btnRelatorio').addEventListener('click', () => salvarRelatorio().catch((e) => mensagem(`Erro: ${e.message}`, 'erro')));
  $('btnPasta').addEventListener('click', () => abrirPasta().catch((e) => mensagem(`Erro: ${e.message}`, 'erro')));
  $('btnAbrirEcac').addEventListener('click', () => abrirEcac());

  chrome.storage.onChanged.addListener((mud, area) => {
    if (area !== 'local') return;
    if (mud[K.status]) { status = mud[K.status].newValue || null; mostrarCaminhoReal(); }
    const kf = chaveFilaDe(pastaDigitada());
    if (mud[kf]) fila = mud[kf].newValue || null;
    if (mud[K.status] || mud[kf]) desenhar();
  });
  chrome.tabs.onUpdated.addListener((_id, info) => { if (info.url || info.status === 'complete') mostrarEstadoEcac(); });
  chrome.tabs.onRemoved.addListener(() => mostrarEstadoEcac());
  setInterval(() => { desenhar(); }, 15000); // reavalia "sem sinal da página"
  posicionarJanela();
}

iniciarTela().catch((e) => mensagem(`Erro: ${e.message}`, 'erro'));
