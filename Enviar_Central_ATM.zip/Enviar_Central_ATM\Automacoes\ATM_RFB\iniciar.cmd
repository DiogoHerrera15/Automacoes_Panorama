@echo off
rem Roda a automacao RFB pela janela de comando (sem a interface). Ex.: iniciar.cmd --teste
rem Opcoes: --teste  --verificar  --organizar  --novo-lote  --ajuda
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0iniciar.ps1" %*
set CODIGO=%ERRORLEVEL%
echo.
pause
exit /b %CODIGO%
