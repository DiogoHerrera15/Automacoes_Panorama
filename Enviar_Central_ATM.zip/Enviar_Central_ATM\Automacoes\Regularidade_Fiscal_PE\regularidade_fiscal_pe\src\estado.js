/*
 * Estado da execução entre recargas de página.
 * Se o clique em "Emitir" substituir a página, os scripts reiniciam; a fase em andamento fica gravada em
 * chrome.storage para a página nova descrever o que aconteceu (sem clicar em nada).
 */
(function () {
  'use strict';
  const NS = (window.EFiscoCRF = window.EFiscoCRF || {});
  const chave = () => NS.CONFIG.storage.estado;

  function salvar(obj) {
    return new Promise((resolve) => {
      try { chrome.storage.local.set({ [chave()]: { ...obj, ts: Date.now() } }, () => resolve()); } catch (_) { resolve(); }
    });
  }

  function ler() {
    return new Promise((resolve) => {
      try {
        chrome.storage.local.get(chave(), (d) => {
          const e = d && d[chave()];
          resolve(e && Date.now() - e.ts <= NS.CONFIG.retomada.validadeMs ? e : null);
        });
      } catch (_) { resolve(null); }
    });
  }

  function limpar() {
    return new Promise((resolve) => {
      try { chrome.storage.local.remove(chave(), () => resolve()); } catch (_) { resolve(); }
    });
  }

  NS.estado = { salvar, ler, limpar };
})();
