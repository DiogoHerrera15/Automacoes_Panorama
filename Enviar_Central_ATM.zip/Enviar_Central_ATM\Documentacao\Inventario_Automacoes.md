# Inventário das automações

Levantamento feito em 17/11/2026 na máquina de origem, a partir de `Documents\Central_Automacoes\automacoes.json`
(a lista que a Central usa) e dos caminhos **reais** de cada projeto. Cópias duplicadas foram comparadas arquivo por
arquivo (hash MD5) antes de escolher qual entra no pacote.

**Resumo:** 6 automações cadastradas na Central → **6 incluídas**, cada uma na sua pasta em `Automacoes\`.

Legenda da situação:
- **Verificado aqui** = conferido na máquina de origem (instalação de teste completa numa pasta temporária: cópia,
  `npm ci`, `.venv`, Central `-Validar` e autoteste da janela).
- **Depende do destino** = só dá para confirmar no computador novo (extensões carregadas, certificado, sites reais).

---

## 1. RETIRAR AUTO-INFRAÇÃO

| Item | Valor |
|---|---|
| Finalidade | Certidão de Débitos Trabalhistas (MTE) em lote, por CPF/CNPJ |
| Origem | `%USERPROFILE%\Downloads\Retirar_Auto_Infracao` (versão com "pasta de destino", 16/11/2026) |
| Pasta no pacote | `Automacoes\Retirar_Auto_Infracao` |
| Instalada em | `%CENTRAL_ATM%\Automacoes\Retirar_Auto_Infracao` |
| Tipo na Central | `terminal` |
| Ponto de entrada | `ABRIR_INTERFACE.cmd` → `node src\interface\iniciar.js` (interface em `http://127.0.0.1:47331`, token) |
| Outros | `INICIAR.cmd` (modo linha de comando, `src\cli.js`), `.command` (Mac, sem uso no Windows) |
| Dependências | Node.js ≥ 20; `pdfjs-dist` 4.10.38 (+ `@napi-rs/canvas`), travadas em `package-lock.json` → `npm ci` |
| Extensão Chrome | `extensao-chrome` ("Retirar_Auto_Infracao" v1.12); fala com o assistente na porta **47321** (`GET /cnpj`) |
| Modo anônimo | não exigido |
| Dados do usuário (não vão no pacote) | `dados\` (vai vazia), PDFs, `Relatorio.csv`; `COLE_OS_CNPJS_AQUI.txt` vai só com o cabeçalho |
| Saída | `Downloads\<NOME DA PASTA>\<CNPJ>;<NOME>.pdf` (padrão `Downloads\Lote_...`) |
| Testes | `npm test` (45 testes, sem Chrome e sem site) |
| Situação | **Verificado aqui**: cópia completa, `npm ci` OK, Central encontra o ponto de entrada. **Depende do destino**: extensão carregada; site do MTE |

## 2. CERTIDÃO RECEITA FEDERAL (ATM RFB)

| Item | Valor |
|---|---|
| Finalidade | Certidão de Débitos Relativos a Créditos Tributários Federais e à Dívida Ativa da União, em lote |
| Origem | `%USERPROFILE%\Downloads\ATM_RFB` (idêntica a `Desktop\ATM_RFB`, conferido por hash) |
| Pasta no pacote | `Automacoes\ATM_RFB` |
| Tipo na Central | `terminal` |
| Ponto de entrada | `INTERFACE RFB EMISSAO.cmd` → `node interface\servidor.js` (porta **47330**); na 1ª vez roda `instalar.ps1 -SemPerguntas` |
| Outros | `instalar.cmd/.ps1` (instalador próprio), `iniciar.cmd/.ps1` (linha de comando), `ferramentas\lote.py`, `entrega_nomeada.py` |
| Dependências | Node.js ≥ 18 + `pdfjs-dist` 4.10.38 (`npm ci`); Python 3.8+ com Pillow e openpyxl em `.venv` própria (`requirements.txt`) |
| Extensão Chrome | `extensao-chrome` ("Automacao_RFB" v1.8) — ligar **Permitir no modo anônimo** |
| Dados do usuário (não vão) | `empresas.csv`, `Controle.json`, `Relatorio.csv`, `certidoes\`, `*.pdf`, `interface\config.json`, `lista_cnpjs.txt` (regra do `.gitignore` dele) |
| Modelo | `lista_cnpjs.exemplo.txt` |
| Saída | `Downloads\<pasta do lote>\<CNPJ>\NOME - CNPJ - Certidao Regularidade Fiscal RFB - AAAA-MM-DD.pdf` |
| Situação | **Verificado aqui**: `instalar.ps1` dele rodou na instalação de teste (npm ci + `.venv` com Pillow/openpyxl). **Depende do destino**: extensão; site da Receita |

## 3. PGFN – DOCUMENTOS DE ARRECADAÇÃO

| Item | Valor |
|---|---|
| Finalidade | e-CAC → Regularize → SISPAR: emite os documentos de arrecadação das negociações "DEFERIDA E CONSOLIDADA" por CNPJ |
| Origem | `%USERPROFILE%\Downloads\Auto_PGFN` (cópia ativa; `Downloads\ATM_PGFN` é uma cópia antiga empacotada) |
| Pasta no pacote | `Automacoes\Auto_PGFN` — mesma lista de arquivos do `instalacao\gerar_pacote.ps1` do próprio projeto + `README.md` |
| Instalada em | **`%USERPROFILE%\Downloads\Auto_PGFN` (obrigatório)** |
| Tipo na Central | `janela` |
| Ponto de entrada | `Automacao_PGFN.exe` (interface C#; fonte em `interface\AutomacaoPGFN.cs`, recompila com `interface\compilar.bat`) |
| Outros | `INICIAR_AUTOMACAO.bat` (modo antigo com `cnpjs.json`), `VER_ANDAMENTO.bat`, `orquestrador\orquestrador.ps1` |
| Dependências | só Chrome e Windows (.NET Framework 4 já vem no Windows) |
| Extensão Chrome | `Automação_PGFN` (v0.39.0) — ligar **Permitir no modo anônimo** |
| Ajudante do Windows | `ajudante_salvar_como\` registrado como native messaging host `com.auto_pgfn.salvar_como` (HKCU) pelo `INSTALAR.bat` **depois** de carregar a extensão (usa o ID dela). O manifesto do ajudante desta máquina NÃO vai no pacote |
| Dados do usuário (não vão) | `configuracoes\*.json` (listas e andamentos por certificado), `cnpjs.json`, `Documentos_arrecadacao\`, `orquestrador\*.json/*.log`, `_recuperacao\`, `PGFN_11-2026*`, `pacotes\`, `CONTINUIDADE_AUTOMACAO_PGFN.md` (documento interno com CNPJs) |
| Modelo | `instalacao\cnpjs.exemplo.json` |
| Atenção | fecha **todas** as janelas do Chrome a cada CNPJ; usa o mouse por alguns segundos ao escolher o certificado |
| Situação | **Verificado aqui**: arquivos completos (lista do próprio empacotador), Central encontra o `.exe`. **Depende do destino**: extensão + `INSTALAR.bat` (ajudante), certificado instalado, e-CAC |

## 4. SITUAÇÃO FISCAL

| Item | Valor |
|---|---|
| Finalidade | Minhas Dívidas e Pendências (e-CAC): certidão e relatório da situação fiscal por CNPJ |
| Origem | extensão ativa `Desktop\ATM_SIT_FISCAL\Situacao_Fiscal` (idêntica à de `Documents\Autom_Situacao_Fiscal`, conferido) + `ferramentas\` e `README.md` do projeto completo `Documents\Autom_Situacao_Fiscal` |
| Pasta no pacote | `Automacoes\Situacao_Fiscal` (`Situacao_Fiscal\` = extensão; `ferramentas\`; `README_projeto.md`; `COMO_FUNCIONA.html`; `LEIA-ME_PRIMEIRO.txt`) |
| Tipo na Central | `chrome` (abre `https://cav.receita.fazenda.gov.br/autenticacao/login`; inicia pelo ícone da extensão) |
| Dependências | só Chrome (as `ferramentas\*.js` opcionais usam Node.js) |
| Extensão Chrome | `Situacao_Fiscal` (v1.1.1) |
| Dados do usuário (não vão) | `progresso_situacao_fiscal.csv`, `lista_cnpjs.txt`; `HISTORICO.md` e `CODIGO_COMPLETO.md` ficaram de fora (contêm CNPJs de clientes) |
| **Alterado no pacote** | o `content.js` original traz embutida uma lista padrão de ~200 clientes (`DOCUMENTOS`), gravada como configuração na primeira vez que a extensão roda. Na cópia do pacote ela foi **esvaziada** (`const DOCUMENTOS = [];`) e a `PASTA_RAIZ` padrão virou `Situacao_Fiscal`; os exemplos de `popup.html`, `LEIA-ME.md` e `COMO_FUNCIONA.html` viraram fictícios. Uso: informe a pasta e a lista pela janela da extensão (como já era o uso normal). O resto do código é idêntico (conferido por hash) |
| Saída | `Downloads\<pasta>\<empresa>\RFB_<CNPJ>.pdf`, relatório, `Com_Pendencia_<CNPJ>.pdf`, `Erro_de_Procuracao_<CNPJ>.pdf` |
| Situação | **Verificado aqui**: arquivos completos, Central OK. **Depende do destino**: extensão, certificado, e-CAC |

## 5. PARCELAMENTO SIMPLIFICADO

| Item | Valor |
|---|---|
| Finalidade | Por `cnpj;nome`: troca o perfil no e-CAC, consulta o Parcelamento Simplificado e salva o PDF da consulta ou do DARF |
| Origem | `Desktop\ATM_simplicado_1\parcelamento_simplificado` (v1.8.5) + `README.md` |
| Pasta no pacote | `Automacoes\Parcelamento_Simplificado` |
| Tipo na Central | `chrome`, `"anonima": true` (abre `...autenticacao/login#ps_abrir_interface` em janela anônima; a extensão abre a janela dela sozinha) |
| Dependências | só Chrome |
| Extensão Chrome | `parcelamento_simplificado` (v1.8.5) — ligar **Permitir no modo anônimo** |
| Não incluídos | `_backup_*` (versões antigas) e a cópia duplicada `ATM_simplicado_1\Retirar_Auto_Infracao` (não usada pela Central) |
| Saída | `Downloads\<pasta>\<empresa>\<CNPJ>.pdf`; `RELATORIO_PROBLEMAS_<data-hora>.txt` |
| Situação | **Verificado aqui**: arquivos completos, Central OK. **Depende do destino**: extensão + anônimo, certificado, e-CAC |

## 6. REGULARIDADE FISCAL PE (E-FISCO)

| Item | Valor |
|---|---|
| Finalidade | Certidão de Regularidade Fiscal estadual (SEFAZ-PE, e-Fisco) para CPF, CNPJ e IE, em lote |
| Origem | `Desktop\ATM_REGULARIDADE_FISCAL_PE\regularidade_fiscal_pe` (v0.7.0, do repositório; ajuste de caminho Windows no `background.js`) |
| Pasta no pacote | `Automacoes\Regularidade_Fiscal_PE` |
| Tipo na Central | `chrome` com `"painel": "painel/painel.html"` (abre o painel da extensão; sem extensão, abre o site) |
| Dependências | só Chrome (testes com Node.js: `testes\unit.js`, `fila.test.js`, `background.test.js`) |
| Extensão Chrome | `EFisco_PE_Certidao_Regularidade_Fiscal` (v0.7.0) — ligar **Permitir no modo anônimo** (sem isso não inicia) |
| Saída | `Downloads\<PASTA>\CNPJ_<n>_CERTIDAO.pdf` (CPF_/IE_) |
| Situação | **Verificado aqui**: 52 testes da extensão passaram (17/11), Central OK. **Depende do destino**: extensão + anônimo; ainda não rodou no site real (CAPTCHA/Cloudflare exigem pessoa) |

---

## Central de Automações

| Item | Valor |
|---|---|
| Origem | `%USERPROFILE%\Documents\Central_Automacoes` |
| Pasta no pacote | `Central_de_Automacoes` |
| Incluído | `Central.ps1` (portátil: `%CENTRAL_ATM%`), `Abrir Central.vbs`, `automacoes.json` e `ajuda.json` (caminhos relativos), `LEIA-ME.txt`, `README.md` |
| Não incluído | `backup_*`, `capturas\` (imagens de teste), `central_erros.log`, `preferencias.json` (tema; criado sozinho) |
| Situação | **Verificado aqui**: instalação de teste → `-Validar` com 6 `pronto : sim`; autoteste da janela: 6 botões "?", busca, 4 filtros, ajuda por clique e teclado, temas claro/escuro, 3 tamanhos de janela, 0 automações iniciadas |

## Encontradas na máquina e NÃO incluídas (com motivo)

| Pasta | Motivo |
|---|---|
| `Downloads\ATM_PGFN` | cópia antiga/empacotada da PGFN (a ativa é `Downloads\Auto_PGFN`) |
| `Desktop\ATM_RFB` | idêntica a `Downloads\ATM_RFB` (hash) |
| `Desktop\Autom_Situacao_Fiscal`, `Documents\Autom_Situacao_Fiscal` | projeto completo da Situação Fiscal; extensão idêntica à incluída; ferramentas e README incluídos |
| `Desktop\ATM_SIT_FISCAL\Situacao_Fiscal_envio_ATM` (+ .zip) | pacote de envio antigo; extensão idêntica; `COMO_FUNCIONA.html` e `LEIA-ME_PRIMEIRO.txt` incluídos |
| `Desktop\ATM_simplificado`, `Documents\ATM_simplificado`, `Downloads\Auto_Simplificado`, `Downloads\Automacao_Simplificado`, `Documents\Codigo_ATT` | versões antigas/variantes do Parcelamento Simplificado (a Central usa `Desktop\ATM_simplicado_1`) |
| `Desktop\ATM_simplicado_1\Retirar_Auto_Infracao` | cópia duplicada do Retirar, não usada pela Central |
| `Downloads\Retirar_Auto_Infracao_backup_*`, `*\_backup_*`, `Central_Automacoes\backup_*` | backups |
| `Documents\robo` | robô Java antigo, excluído da Central por escolha do usuário (os `.bat` apontam para `C:\robo\executavel`, que não existe) |
| `Downloads\AGM_PARCELAMENTO_SIMPLIFICADO*`, `PARCELAMENTOS`, `Situacao_Fiscal_Assecon`, `teste_novembro` | pastas de **resultados** (PDFs de clientes), não são automações |
