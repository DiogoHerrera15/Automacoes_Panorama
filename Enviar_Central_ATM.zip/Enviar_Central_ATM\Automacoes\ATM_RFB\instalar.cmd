@echo off
rem Instala o que falta para a automacao RFB neste Windows. Dois cliques neste arquivo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalar.ps1" %*
set CODIGO=%ERRORLEVEL%
echo.
pause
exit /b %CODIGO%
