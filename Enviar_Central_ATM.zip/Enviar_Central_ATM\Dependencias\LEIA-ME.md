# Dependências

Nenhum instalador ou biblioteca binária vai dentro do pacote: eles dependem da versão do Windows e ficam
desatualizados. O `Instalacao\instalar.ps1` baixa tudo de **fontes oficiais** na hora de instalar.

## Programas (instalados pelo winget, só se faltarem; o instalador pergunta antes)

| Programa | ID no winget | Escopo | Site oficial |
|---|---|---|---|
| Google Chrome | `Google.Chrome` | padrão do pacote | https://www.google.com/chrome/ |
| Node.js LTS (≥ 20) | `OpenJS.NodeJS.LTS` | por máquina (pode pedir UAC) | https://nodejs.org |
| Python 3.12 | `Python.Python.3.12` | `--scope user` | https://www.python.org |

## Bibliotecas (isoladas dentro de cada projeto)

| Projeto | Arquivo | Conteúdo | Comando (feito pelo instalador) |
|---|---|---|---|
| Retirar_Auto_Infracao | `package.json` + `package-lock.json` | `pdfjs-dist` 4.10.38 (+ `@napi-rs/canvas`, opcional dele) | `npm ci --no-audit --no-fund` |
| ATM_RFB | `package.json` + `package-lock.json` | `pdfjs-dist` 4.10.38 | `npm ci` (pelo `instalar.ps1` do projeto) |
| ATM_RFB | `requirements.txt` | `pillow`, `openpyxl` | `.venv\Scripts\python.exe -m pip install -r requirements.txt` (pelo `instalar.ps1` do projeto) |

As extensões do Chrome (7) não têm dependências: são JavaScript puro carregado pelo Chrome.
A interface da PGFN (`Automacao_PGFN.exe`) vem pronta; se precisar recompilar, `interface\compilar.bat` usa o
compilador do .NET Framework 4 que já vem no Windows.
