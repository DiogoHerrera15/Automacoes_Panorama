# Prepara este Windows para rodar a automacao RFB (equivalente ao instalar.sh do Mac).
# Rode UMA vez: dois cliques em instalar.cmd, ou no PowerShell, dentro desta pasta:
#   powershell -NoProfile -ExecutionPolicy Bypass -File .\instalar.ps1
# Pode rodar de novo quando quiser: so instala o que falta.
param([switch]$SemPerguntas)

$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$AQUI = $PSScriptRoot

function Ok($t)   { Write-Host "  [OK] $t" }
function Erro($t) { Write-Host "  [ERRO] $t" -ForegroundColor Red; exit 1 }

# Ve se um comando existe e funciona de verdade (o "python" da Microsoft Store e so um atalho que abre a loja).
function Funciona($exe, [string[]]$argumentos) {
  try { & $exe @argumentos *> $null; return ($LASTEXITCODE -eq 0) } catch { return $false }
}

function Achar-Chrome {
  $candidatos = @($env:CHROME_PATH)
  foreach ($base in @($env:ProgramFiles, ${env:ProgramFiles(x86)}, $env:LOCALAPPDATA)) {
    if ($base) { $candidatos += (Join-Path $base 'Google\Chrome\Application\chrome.exe') }
  }
  foreach ($c in $candidatos) { if ($c -and (Test-Path -LiteralPath $c)) { return $c } }
  return $null
}

Write-Host 'Instalacao - Automacao RFB (certidoes da Receita Federal)'
Write-Host "Pasta: $AQUI"
Write-Host ''

Write-Host '1/5 Google Chrome'
$chrome = Achar-Chrome
if ($chrome) { Ok "Google Chrome encontrado: $chrome" }
else { Erro 'Google Chrome nao encontrado. Instale em https://www.google.com/chrome/ (ou: winget install Google.Chrome), abra uma vez e rode este instalador de novo. Chrome em outro lugar: defina CHROME_PATH com o caminho do chrome.exe.' }

Write-Host '2/5 Node.js (versao 18 ou mais nova)'
if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
  Erro 'Node.js nao encontrado. Instale a versao LTS com:  winget install OpenJS.NodeJS.LTS  (ou em https://nodejs.org), FECHE e abra a janela de novo e rode este instalador outra vez.'
}
$versaoNode = [int](& node -p "process.versions.node.split('.')[0]")
if ($versaoNode -lt 18) { Erro "Node.js $(& node -v) e antigo demais. Instale a versao 18 ou mais nova (winget install OpenJS.NodeJS.LTS)." }
Ok "Node.js $(& node -v), npm $(& npm -v)"

Write-Host '3/5 Dependencias do programa (pdfjs-dist, via npm)'
$ErrorActionPreference = 'Continue'
if (Test-Path package-lock.json) { & npm ci --no-fund --no-audit; if ($LASTEXITCODE -ne 0) { & npm install --no-fund --no-audit } }
else { & npm install --no-fund --no-audit }
$ErrorActionPreference = 'Stop'
if (-not (Test-Path 'node_modules\pdfjs-dist')) { Erro 'Falha no npm. Confira a internet e rode de novo.' }
Ok 'node_modules instalado'

Write-Host '4/5 Python 3 e bibliotecas (Pillow, openpyxl) em ambiente proprio (.venv)'
$venvPy = Join-Path $AQUI '.venv\Scripts\python.exe'
if (-not (Test-Path -LiteralPath $venvPy)) {
  $base = $null
  if (Funciona 'py' @('-3', '-c', 'import sys')) { $base = @('py', '-3') }
  elseif (Funciona 'python' @('-c', 'import sys; assert sys.version_info >= (3, 8)')) { $base = @('python') }
  elseif (Funciona 'python3' @('-c', 'import sys; assert sys.version_info >= (3, 8)')) { $base = @('python3') }
  if (-not $base) { Erro 'Python 3 nao encontrado. Instale com:  winget install Python.Python.3.12  (ou em https://www.python.org, marcando "Add python.exe to PATH"), feche e abra a janela de novo e rode este instalador outra vez.' }
  $exe = $base[0]; $resto = @($base | Select-Object -Skip 1)
  & $exe @resto -m venv .venv
  if (-not (Test-Path -LiteralPath $venvPy)) { Erro 'Nao consegui criar o ambiente .venv.' }
}
$ErrorActionPreference = 'Continue'
& $venvPy -m pip install --quiet --disable-pip-version-check --upgrade pip *> $null
& $venvPy -m pip install --quiet --disable-pip-version-check -r requirements.txt
$ErrorActionPreference = 'Stop'
if (-not (Funciona $venvPy @('-c', 'import PIL, openpyxl'))) { Erro 'Falha ao instalar Pillow/openpyxl (confira a internet e rode de novo).' }
Ok "$(& $venvPy -V) com Pillow e openpyxl"

Write-Host '5/5 Liberando os arquivos baixados da internet'
# Equivalente ao "xattr -dr com.apple.quarantine" do Mac: tira a marca "baixado da internet" dos arquivos.
Get-ChildItem -LiteralPath $AQUI -Recurse -File -ErrorAction SilentlyContinue |
  Where-Object { $_.FullName -notmatch '\\(node_modules|\.venv)\\' } |
  Unblock-File -ErrorAction SilentlyContinue
Ok 'arquivos liberados'

Write-Host ''
Write-Host 'Instalacao concluida.'
Write-Host ''
Write-Host 'FALTA UM PASSO MANUAL: carregar a extensao no Chrome (so uma vez):'
Write-Host "  1. No Chrome, abra  chrome://extensions  e ligue 'Modo do desenvolvedor' (canto superior direito)."
Write-Host "  2. Clique em 'Carregar sem compactacao' e escolha a pasta:"
Write-Host "       $AQUI\extensao-chrome"
Write-Host "  3. Em 'Detalhes' da extensao 'Automacao_RFB', ligue 'Permitir na navegacao anonima'."
Write-Host '  (passo a passo com detalhes no README.md)'
Write-Host ''
if (-not $SemPerguntas -and [Environment]::UserInteractive) {
  $r = Read-Host 'Abrir agora o chrome://extensions e a pasta da extensao? (s/N)'
  if ($r -match '^[sS]$') {
    Start-Process -FilePath $chrome -ArgumentList 'chrome://extensions'
    Start-Process -FilePath explorer.exe -ArgumentList "`"$AQUI\extensao-chrome`""
  }
}
Write-Host 'Depois: abra a interface com dois cliques em "INTERFACE RFB EMISSAO.cmd" (ou use lista_cnpjs.txt + iniciar.cmd --teste).'
exit 0
