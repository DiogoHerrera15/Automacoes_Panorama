@echo off
rem Gera o .zip para instalar a Automacao PGFN em outro computador (sem dados de clientes). Saida: pasta "pacotes".
chcp 65001 >nul
title Automação PGFN - gerar pacote
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0gerar_pacote.ps1"
pause
