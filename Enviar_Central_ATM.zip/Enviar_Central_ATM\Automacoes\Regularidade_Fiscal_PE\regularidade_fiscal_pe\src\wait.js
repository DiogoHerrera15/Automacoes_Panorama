/* Esperas inteligentes: baseadas em condição (MutationObserver + polling), sempre com timeout. */
(function () {
  'use strict';
  const NS = (window.EFiscoCRF = window.EFiscoCRF || {});

  // Token de cancelamento cooperativo (botão "Parar").
  let token = { cancelado: false };
  const ERRO_CANCELADO = 'Operação cancelada';
  const novoToken = () => { token = { cancelado: false }; return token; };
  const cancelar = () => { token.cancelado = true; };

  const dormir = (ms) => {
    const tk = token;
    return new Promise((resolve, reject) => {
      if (tk.cancelado) return reject(new Error(ERRO_CANCELADO));
      setTimeout(() => (tk.cancelado ? reject(new Error(ERRO_CANCELADO)) : resolve()), ms);
    });
  };

  /** Resolve com o valor truthy de `condicao()`; rejeita no timeout. */
  function esperarPor(condicao, { timeout = 10000, intervalo = 100, descricao = 'condição' } = {}) {
    const tk = token;
    return new Promise((resolve, reject) => {
      let finalizado = false;
      let obs = null;
      let timer = null;
      let limite = null;
      const limpar = () => {
        finalizado = true;
        if (obs) obs.disconnect();
        clearInterval(timer);
        clearTimeout(limite);
      };
      const checar = () => {
        if (finalizado) return;
        if (tk.cancelado) { limpar(); reject(new Error(ERRO_CANCELADO)); return; }
        let v;
        try { v = condicao(); } catch (_) { v = null; }
        if (v) { limpar(); resolve(v); }
      };
      checar();
      if (finalizado) return;
      obs = new MutationObserver(checar);
      obs.observe(document.documentElement, { childList: true, subtree: true, attributes: true, characterData: true });
      timer = setInterval(checar, intervalo);
      limite = setTimeout(() => {
        if (finalizado) return;
        limpar();
        reject(new Error(`Tempo esgotado (${timeout} ms) aguardando: ${descricao}`));
      }, timeout);
    });
  }

  /** Como esperarPor, mas devolve null (sem erro) no timeout. Cancelamento ainda rejeita. */
  async function esperarOuNulo(condicao, opcoes) {
    try { return await esperarPor(condicao, opcoes); } catch (e) {
      if (e.message === ERRO_CANCELADO) throw e;
      return null;
    }
  }

  function estaVisivel(el) {
    if (!el || !el.isConnected) return false;
    const r = el.getBoundingClientRect();
    const cs = getComputedStyle(el);
    return r.width > 0 && r.height > 0 && cs.visibility !== 'hidden' && cs.display !== 'none';
  }

  const esperarDocumentoCarregado = (timeout) =>
    esperarPor(() => document.readyState === 'complete', { timeout, descricao: 'carregamento completo do documento' });

  /**
   * Executa `fn(tentativa)` até `max` vezes. Entre as tentativas espera `intervalo` ms.
   * O cancelamento nunca é repetido. Lança o último erro se todas falharem.
   */
  async function tentar(nome, fn, max, intervalo) {
    let ultimo = null;
    for (let i = 1; i <= max; i++) {
      try { return await fn(i); } catch (e) {
        if (e.message === ERRO_CANCELADO) throw e;
        ultimo = e;
        if (i < max) {
          NS.log && NS.log.aviso(`${nome}: tentativa ${i}/${max} falhou (${e.message}). Verificando novamente...`);
          await dormir(intervalo);
        }
      }
    }
    throw ultimo;
  }

  NS.wait = { tentar, dormir, esperarPor, esperarOuNulo, estaVisivel, esperarDocumentoCarregado, novoToken, cancelar, ERRO_CANCELADO };
})();
