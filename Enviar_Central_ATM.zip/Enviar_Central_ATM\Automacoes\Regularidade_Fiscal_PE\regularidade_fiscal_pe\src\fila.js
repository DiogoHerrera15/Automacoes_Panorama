/*
 * Controlador da fila de documentos (roda no service worker / background).
 * - Estado ÚNICO em chrome.storage (efisco_job): sobrevive à suspensão do service worker.
 * - Toda mutação é serializada (sem corridas entre eventos).
 * - Dependências injetadas (api) ⇒ testável em Node com um Chrome simulado.
 * Responsabilidades: avançar item a item, tentativas limitadas, pausa/parada, abrir/navegar a aba do e-Fisco,
 * receber resultados dos content scripts e cuidar dos downloads (nome, pasta, validação do PDF).
 */
(function (raiz) {
  'use strict';
  const NS = (raiz.EFiscoCRF = raiz.EFiscoCRF || {});
  const K = { job: 'efisco_job', log: 'efisco_joblog', estado: 'efisco_estado', eventos: 'efisco_eventos' };
  const ATIVOS = ['processando', 'aguardando_entrega'];

  function criarFila(api) {
    const cfg = () => NS.CONFIG.fila;
    let cadeia = Promise.resolve();
    const serial = (fn) => { const p = cadeia.then(fn, fn); cadeia = p.catch(() => {}); return p; };

    // ───────── persistência ─────────
    const lerJob = async () => ((await api.storage.get(K.job))[K.job]) || null;
    const salvarJob = (job) => api.storage.set({ [K.job]: job });
    async function logar(msg, nivel = 'info') {
      const d = await api.storage.get(K.log);
      const l = (d[K.log] || []).slice(-499);
      l.push({ t: api.agora(), nivel, msg });
      await api.storage.set({ [K.log]: l });
    }
    const item = (job, id) => job.itens.find((i) => i.id === id);
    const rotulo = (it) => `${it.tipo} ${it.formatado || it.digitos}`;

    // ───────── aba do e-Fisco (SEMPRE em janela anônima) ─────────
    const MSG_INCOGNITO = 'Ative "Permitir no modo anônimo" para esta extensão: chrome://extensions → Detalhes da extensão → "Permitir no modo anônimo". Depois, inicie novamente.';

    /** A extensão só funciona em janela anônima se o usuário a autorizar no Chrome (não dá para ativar por código). */
    async function incognitoPermitido() {
      try { return !!(await api.incognitoPermitido()); } catch (_) { return false; }
    }

    /**
     * Reutiliza a aba do job SOMENTE se for anônima; caso contrário abre uma NOVA janela anônima.
     * Nunca usa uma aba comum e nunca recorre a aba normal se a janela anônima falhar.
     */
    async function garantirAba(job) {
      if (job.tabId != null) {
        try { const t = await api.tabs.get(job.tabId); if (t && t.incognito) return { tabId: job.tabId, novo: false }; } catch (_) { /* aba fechada */ }
      }
      let w;
      try { w = await api.windows.create({ url: NS.CONFIG.urlSistema, incognito: true, focused: true }); }
      catch (e) { throw new Error(`Não foi possível abrir a janela anônima (${e.message}). ${MSG_INCOGNITO}`); }
      const tab = w && w.tabs && w.tabs[0];
      if (!tab) throw new Error('A janela anônima foi criada, mas sem aba utilizável.');
      job.janelaId = w.id;
      return { tabId: tab.id, novo: true };
    }

    // ───────── avanço ─────────
    async function avancar() {
      const job = await lerJob();
      if (!job || job.estado !== 'executando') return;
      const atual = job.atual && item(job, job.atual);
      if (atual && ATIVOS.includes(atual.status)) return; // já há um documento em curso

      const prox = job.itens.find((i) => i.status === 'pendente');
      if (!prox) {
        job.estado = 'concluido'; job.atual = null; job.fim = api.agora();
        await salvarJob(job);
        await api.alarms.clear('efisco-watchdog');
        const r = resumo(job);
        await logar(`Fila concluída: ${r.concluidos} emitido(s), ${r.erros} com erro, ${r.ignorados} não processado(s).`, r.erros ? 'aviso' : 'ok');
        return;
      }
      prox.status = 'processando'; prox.tentativas = (prox.tentativas || 0) + 1; prox.ultimoSinal = api.agora();
      prox.etapa = 'abrindo o e-Fisco'; prox.erro = ''; prox.humano = ''; prox.baixando = false; prox.downloadId = null;
      job.atual = prox.id;
      let tabId; let novo;
      try { ({ tabId, novo } = await garantirAba(job)); }
      catch (e) {
        prox.status = 'pendente'; prox.tentativas = Math.max(0, prox.tentativas - 1); prox.etapa = ''; job.atual = null;
        job.estado = 'pausado'; job.motivoPausa = e.message;
        await salvarJob(job); await logar(`⏸ ${e.message}`, 'erro');
        return;
      }
      job.tabId = tabId;
      await api.storage.remove([K.estado, K.eventos]); // começa o documento do zero
      await salvarJob(job);
      const n = job.itens.indexOf(prox) + 1;
      await logar(`Documento ${n}/${job.itens.length}: ${rotulo(prox)} — tentativa ${prox.tentativas}/${cfg().maxTentativas}.`);
      if (!novo) await api.tabs.update(tabId, { url: NS.CONFIG.urlSistema, active: true });
      await api.alarms.create('efisco-watchdog', { periodInMinutes: 0.5 });
    }

    const resumo = (job) => {
      const c = (s) => job.itens.filter((i) => i.status === s).length;
      return { total: job.itens.length, concluidos: c('concluido'), erros: c('erro'), pendentes: c('pendente'),
        emCurso: job.itens.filter((i) => ATIVOS.includes(i.status)).length, ignorados: c('interrompido') };
    };

    /** Agenda o próximo avanço SEM bloquear a fila de eventos (PARAR/PAUSAR continuam respondendo na hora). */
    function proximoDepois(ms) {
      api.espera(ms).then(() => serial(avancar)).catch(() => {});
    }

    async function concluir(job, it, arquivo, extra = {}) {
      it.status = 'concluido'; it.arquivo = arquivo; it.etapa = 'concluído'; Object.assign(it, extra); job.atual = null;
      await salvarJob(job);
      await logar(`✔ ${rotulo(it)} — salvo em ${arquivo}`, 'ok');
      proximoDepois(cfg().pausaEntreItensMs);
    }
    async function falhar(job, it, msg) {
      it.status = 'erro'; it.erro = msg; it.etapa = 'erro'; job.atual = null;
      await salvarJob(job);
      await logar(`✘ ${rotulo(it)} — ${msg}`, 'erro');
      proximoDepois(cfg().pausaEntreItensMs);
    }
    /** Erro recuperável: nova tentativa limitada; esgotadas, registra e segue. */
    async function recuperar(job, it, msg) {
      if ((it.tentativas || 0) < cfg().maxTentativas) {
        it.status = 'pendente'; it.etapa = 'nova tentativa'; it.erro = msg; job.atual = null;
        await salvarJob(job);
        await logar(`↻ ${rotulo(it)} — ${msg}. Nova tentativa (${it.tentativas}/${cfg().maxTentativas} usadas).`, 'aviso');
        proximoDepois(cfg().esperaEntreTentativasMs * (it.tentativas || 1));
      } else {
        await falhar(job, it, `${msg} (após ${cfg().maxTentativas} tentativas)`);
      }
    }

    // ───────── comandos do painel ─────────
    function iniciar({ pasta, pastaOriginal, itens }) {
      return serial(async () => {
        const atual = await lerJob();
        if (atual && (atual.estado === 'executando' || atual.estado === 'pausado')) return { ok: false, erro: 'Já existe uma execução em andamento. Pare-a antes de iniciar outra.' };
        if (!(await incognitoPermitido())) return { ok: false, codigo: 'incognito-nao-permitido', erro: MSG_INCOGNITO };
        const p = NS.arquivos.sanitizarNomePasta(pasta || '').nome;
        if (!p) return { ok: false, erro: 'Informe um nome de pasta válido.' };
        if (!Array.isArray(itens) || !itens.length) return { ok: false, erro: 'Não há documentos válidos para processar.' };
        const ruim = itens.find((i) => !NS.documento.TIPOS.includes(i.tipo) || !/^\d+$/.test(i.digitos || ''));
        if (ruim) return { ok: false, erro: `Documento sem tipo/dígitos válidos: ${ruim.original || ruim.digitos}` };
        const job = {
          id: 'j' + api.agora(), pasta: p, pastaOriginal: pastaOriginal || pasta, estado: 'executando', motivoPausa: '', tabId: null, atual: null,
          inicio: api.agora(), fim: null,
          itens: itens.map((i) => ({ id: i.id, original: i.original, tipo: i.tipo, digitos: i.digitos, formatado: i.formatado || i.digitos, forcado: !!i.forcado,
            status: 'pendente', tentativas: 0, erro: '', arquivo: '', razao: '', etapa: '', ultimoSinal: 0 }))
        };
        await salvarJob(job);
        await api.storage.set({ [K.log]: [] });
        await logar(`Execução iniciada: ${job.itens.length} documento(s). Pasta: Downloads/${p}`);
        await avancar();
        return { ok: true };
      });
    }
    function pausar(motivo = 'Pausado pelo usuário.') {
      return serial(async () => {
        const job = await lerJob();
        if (!job || job.estado !== 'executando') return { ok: false };
        job.estado = 'pausado'; job.motivoPausa = motivo; await salvarJob(job);
        await logar(`⏸ ${motivo}`, 'aviso');
        return { ok: true };
      });
    }
    function continuar() {
      return serial(async () => {
        const job = await lerJob();
        if (!job || job.estado !== 'pausado') return { ok: false };
        if (!(await incognitoPermitido())) return { ok: false, codigo: 'incognito-nao-permitido', erro: MSG_INCOGNITO };
        job.estado = 'executando'; job.motivoPausa = '';
        const it = job.atual && item(job, job.atual);
        if (it && it.status === 'processando') { // a aba pode ter sido fechada durante a pausa
          let viva = false;
          try { const t = await api.tabs.get(job.tabId); viva = !!(t && t.incognito); } catch (_) { viva = false; }
          if (!viva) { it.status = 'pendente'; it.tentativas = Math.max(0, (it.tentativas || 1) - 1); job.atual = null; job.tabId = null; }
          else it.ultimoSinal = api.agora();
        }
        await salvarJob(job);
        await logar('▶ Execução retomada.', 'ok');
        await avancar();
        return { ok: true };
      });
    }
    function parar() {
      return serial(async () => {
        const job = await lerJob();
        if (!job || !['executando', 'pausado'].includes(job.estado)) return { ok: false };
        job.estado = 'parado'; job.fim = api.agora(); job.atual = null;
        job.itens.forEach((i) => { if (ATIVOS.includes(i.status) && !i.downloadId) { i.status = 'interrompido'; i.etapa = 'interrompido'; } });
        await salvarJob(job);
        await api.storage.remove([K.estado]);
        await api.alarms.clear('efisco-watchdog');
        await logar('⏹ Automação parada. Resultados já obtidos foram preservados.', 'aviso');
        return { ok: true };
      });
    }

    // ───────── mensagens do content script ─────────
    function aoHello(tabId) {
      return serial(async () => {
        const job = await lerJob();
        if (!job || !['executando', 'pausado'].includes(job.estado) || !job.atual || job.tabId !== tabId) return null;
        const it = item(job, job.atual);
        if (!it || it.status !== 'processando') return null;
        it.ultimoSinal = api.agora(); it.etapa = 'página carregada'; await salvarJob(job);
        return { item: { id: it.id, tipo: it.tipo, digitos: it.digitos, formatado: it.formatado, original: it.original }, pasta: job.pasta, estadoJob: job.estado };
      });
    }
    function aoStatus(m) {
      return serial(async () => {
        const job = await lerJob();
        const it = job && job.atual === m.itemId && item(job, m.itemId);
        if (!it) return { ok: false };
        it.ultimoSinal = api.agora();
        if (m.etapa) it.etapa = m.etapa;
        if (m.razao) it.razao = m.razao;
        it.humano = m.humano || '';
        if (m.emitirClicado && it.status === 'processando') { it.status = 'aguardando_entrega'; it.tEmitir = api.agora(); }
        await salvarJob(job);
        if (m.humano) await logar(`✋ ${rotulo(it)} — ação humana necessária: ${m.humano}`, 'aviso');
        return { ok: true, estadoJob: job.estado };
      });
    }
    function aoFinal(m) {
      return serial(async () => {
        const job = await lerJob();
        const it = job && job.atual === m.itemId && item(job, m.itemId);
        if (!it) return { ok: false, motivo: 'item não está em curso' };
        if (m.razao) it.razao = m.razao;
        it.humano = '';
        const msg = m.mensagem || '';
        switch (m.status) {
          case 'entrega-pdf': await salvarPdfPronto(job, it, m.dataUrl, m.tabIdEntrega); break;
          case 'entrega-url': await salvarPdfDaUrl(job, it, m.urlPdf, m.tabIdEntrega); break;
          case 'entrega-download':
            it.status = 'aguardando_entrega'; it.etapa = 'download do site em andamento'; it.tEmitir = it.tEmitir || api.agora(); await salvarJob(job);
            if (it.downloadId != null) await validarDownload(job, it);
            break;
          case 'sem_certidao': await falhar(job, it, `Certidão indisponível: ${msg}`); break;
          case 'nenhuma-entrega': await falhar(job, it, `O site não entregou arquivo após o Emitir. ${msg}`); break;
          case 'captcha': {
            // Esgotadas as tentativas: registra o erro e SEGUE (não pausa para sempre). Senão, pausa e pede ação humana.
            if ((it.tentativas || 0) >= cfg().maxTentativas) { await falhar(job, it, `CAPTCHA não concluído após ${cfg().maxTentativas} tentativas`); return { ok: true }; }
            it.status = 'pendente'; job.atual = null; job.estado = 'pausado';
            job.motivoPausa = `Verificação de segurança (CAPTCHA) não concluída para ${rotulo(it)}. Conclua-a manualmente e clique em CONTINUAR.`;
            await salvarJob(job);
            await logar(`⏸ ${job.motivoPausa}`, 'aviso');
            break;
          }
          case 'erro': if (m.recuperavel) await recuperar(job, it, msg); else await falhar(job, it, msg); break;
          default: await falhar(job, it, `resultado desconhecido do e-Fisco: ${m.status}`);
        }
        return { ok: true };
      });
    }

    // ───────── downloads ─────────
    async function salvarPdfDaUrl(job, it, url, tabIdEntrega) {
      if (it.baixando || it.downloadId != null) return; // já está sendo salvo por outro caminho
      if (!url) return falhar(job, it, 'URL do PDF não informada');
      it.status = 'aguardando_entrega'; it.etapa = 'baixando o PDF'; await salvarJob(job);
      let bytes;
      try {
        const r = await api.fetch(url, { credentials: 'include' });
        if (!r.ok) throw new Error(`HTTP ${r.status}`);
        bytes = new Uint8Array(await r.arrayBuffer());
      } catch (e) { return recuperar(job, it, `falha ao obter o PDF (${e.message})`); }
      if (!NS.arquivos.ehPdf(bytes)) return falhar(job, it, 'o conteúdo recebido não é um PDF válido (cabeçalho %PDF- ausente)');
      const nome = NS.arquivos.nomeArquivo({ tipo: it.tipo, digitos: it.digitos, razao: it.razao });
      it.baixando = true; it.bytesEsperados = bytes.length; await salvarJob(job);
      try {
        const id = await api.downloads.download({ url: NS.arquivos.paraDataUrl(bytes), filename: `${job.pasta}/${nome}`, conflictAction: 'uniquify', saveAs: false });
        it.downloadId = id; await salvarJob(job);
        if (tabIdEntrega != null && tabIdEntrega !== job.tabId) { try { await api.tabs.remove(tabIdEntrega); } catch (_) {} }
        await validarDownload(job, it);
      } catch (e) { it.baixando = false; return recuperar(job, it, `erro no download (${e.message})`); }
    }

    /**
     * PDF já obtido pela página anônima (fetch com os cookies DA SESSÃO ANÔNIMA — o background usa os cookies da janela
     * comum e não conseguiria buscá-lo). O background só confere o cabeçalho e grava.
     */
    async function salvarPdfPronto(job, it, dataUrl, tabIdEntrega) {
      if (it.baixando || it.downloadId != null) return;
      if (!NS.arquivos.ehPdfDataUrl(dataUrl)) return falhar(job, it, 'o conteúdo recebido não é um PDF válido (cabeçalho %PDF- ausente)');
      const nome = NS.arquivos.nomeArquivo({ tipo: it.tipo, digitos: it.digitos, razao: it.razao });
      it.status = 'aguardando_entrega'; it.etapa = 'salvando o PDF'; it.baixando = true; it.bytesEsperados = NS.arquivos.tamanhoDataUrl(dataUrl); await salvarJob(job);
      try {
        const id = await api.downloads.download({ url: dataUrl, filename: `${job.pasta}/${nome}`, conflictAction: 'uniquify', saveAs: false });
        it.downloadId = id; await salvarJob(job);
        if (tabIdEntrega != null && tabIdEntrega !== job.tabId) { try { await api.tabs.remove(tabIdEntrega); } catch (_) {} }
        await validarDownload(job, it);
      } catch (e) { it.baixando = false; return recuperar(job, it, `erro no download (${e.message})`); }
    }

    /** O site iniciou um download: decide nome e pasta (sem sobrescrever). Retorna o nome sugerido ou null. */
    function aoDeterminarNome(dl) {
      return serial(async () => {
        const job = await lerJob();
        const it = job && job.estado === 'executando' && job.atual && item(job, job.atual);
        if (!it || !ATIVOS.includes(it.status) || it.baixando || it.downloadId != null) return null;
        const origem = `${dl.finalUrl || ''} ${dl.url || ''} ${dl.referrer || ''}`;
        if (!/efisco\.sefaz\.pe\.gov\.br/i.test(origem) && !/pdf/i.test(dl.mime || '')) return null;
        it.downloadId = dl.id; it.etapa = 'download do site iniciado'; await salvarJob(job);
        const nome = NS.arquivos.nomeArquivo({ tipo: it.tipo, digitos: it.digitos, razao: it.razao });
        await logar(`⬇ Download iniciado pelo site para ${rotulo(it)} → ${job.pasta}/${nome}`);
        return { filename: `${job.pasta}/${nome}`, conflictAction: 'uniquify' };
      });
    }
    function aoDownloadMudou(delta) {
      return serial(async () => {
        const job = await lerJob();
        const it = job && job.itens.find((i) => i.downloadId === delta.id && ATIVOS.includes(i.status));
        if (!it) return;
        if (delta.error || (delta.state && delta.state.current === 'interrupted')) {
          it.downloadId = null; it.baixando = false; return recuperar(job, it, `download interrompido (${(delta.error && delta.error.current) || 'erro'})`);
        }
        if (delta.state && delta.state.current === 'complete') await validarDownload(job, it);
      });
    }
    /** Confirma que o arquivo existe, tem tamanho plausível e é PDF (mime; e cabeçalho, se o Chrome permitir ler o arquivo). */
    async function validarDownload(job, it) {
      const [d] = (await api.downloads.search({ id: it.downloadId })) || [];
      if (!d) return;
      if (d.state === 'in_progress') return; // aguarda o evento de conclusão
      if (d.state !== 'complete') return recuperar(job, it, `download não concluído (estado: ${d.state})`);
      if (d.exists === false) return falhar(job, it, 'o arquivo baixado não existe mais no disco');
      if (!(d.fileSize >= 500)) return falhar(job, it, `arquivo baixado vazio ou pequeno demais (${d.fileSize} bytes)`);
      if (d.mime && !/pdf|octet-stream/i.test(d.mime)) return falhar(job, it, `o arquivo baixado não é PDF (tipo ${d.mime})`);
      let validacao = 'tipo e tamanho';
      if (it.bytesEsperados) validacao = 'bytes conferidos com o PDF obtido';
      else if (api.lerCabecalho) {
        const cab = await api.lerCabecalho(d.filename);
        if (cab) { if (!NS.arquivos.ehPdf(cab)) return falhar(job, it, 'o arquivo baixado não tem cabeçalho de PDF'); validacao = 'cabeçalho %PDF- confirmado'; }
      }
      it.baixando = false;
      await concluir(job, it, d.filename, { validacao });
    }

    // ───────── eventos do navegador ─────────
    /** A aba do e-Fisco (ou uma aberta por ela) foi para uma URL que parece um PDF: obtém e salva. */
    function aoAbaAtualizada(tabId, url, openerTabId) {
      return serial(async () => {
        const job = await lerJob();
        const it = job && job.estado === 'executando' && job.atual && item(job, job.atual);
        if (!it || it.status !== 'aguardando_entrega' || it.baixando || it.downloadId != null) return;
        if (tabId !== job.tabId && openerTabId !== job.tabId) return;
        // Atenção: o background busca com os cookies da janela COMUM; numa sessão anônima isso pode falhar (é tratado como erro).
        if (!/\.pdf([?#]|$)|[?&](tipo|formato|output)=pdf/i.test(url || '')) return;
        await logar(`📄 PDF detectado na aba (${url})`);
        await salvarPdfDaUrl(job, it, url, tabId);
      });
    }
    function aoAlarme() {
      return serial(async () => {
        const job = await lerJob();
        if (!job || job.estado !== 'executando') return;
        if (!job.atual) { await avancar(); return; } // rede de segurança: o service worker pode ter dormido antes de agendar o avanço
        const it = item(job, job.atual);
        if (!it) return;
        const agora = api.agora();
        if (it.status === 'processando' && !it.humano && agora - it.ultimoSinal > cfg().timeoutItemMs) await recuperar(job, it, 'sem resposta do e-Fisco (tempo esgotado)');
        else if (it.status === 'aguardando_entrega' && !it.baixando && !it.humano && agora - (it.tEmitir || it.ultimoSinal) > cfg().timeoutEntregaMs) await falhar(job, it, 'Emitir clicado, mas nenhum arquivo foi entregue no tempo limite');
      });
    }
    function aoAbaRemovida(tabId) {
      return serial(async () => {
        const job = await lerJob();
        if (!job || job.estado !== 'executando' || job.tabId !== tabId) return;
        job.estado = 'pausado'; job.motivoPausa = 'A aba do e-Fisco foi fechada. Clique em CONTINUAR para reabrir e retomar este documento.';
        await salvarJob(job);
        await logar('⏸ ' + job.motivoPausa, 'aviso');
      });
    }

    return { incognitoPermitido, iniciar, pausar, continuar, parar, aoHello, aoStatus, aoFinal, aoDeterminarNome, aoDownloadMudou, aoAlarme, aoAbaRemovida, aoAbaAtualizada, avancar: () => serial(avancar), lerJob, K };
  }

  NS.criarFila = criarFila;
  if (typeof module !== 'undefined') module.exports = { criarFila };
})(typeof window !== 'undefined' ? window : globalThis);
