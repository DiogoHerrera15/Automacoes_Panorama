// Abre a interface gráfica: node src/interface/iniciar.js [--sem-abrir]
// A porta é a 47331 (PORTA_INTERFACE no ambiente muda). Se a interface já estiver aberta
// nessa porta, só abre o navegador nela.

import { criarConfig, PORTA_INTERFACE } from '../config.js';
import { abrirNavegador as abrirNoNavegadorPadrao } from '../sistema.js';
import { iniciarInterface, NOME_APP } from './servidor.js';

const porta = Number(process.env.PORTA_INTERFACE ?? PORTA_INTERFACE);
const abrir = !process.argv.includes('--sem-abrir');

function abrirNavegador(url) {
  if (!abrir) return;
  abrirNoNavegadorPadrao(url).on('error', () => console.log(`Abra ${url} no navegador.`));
}

// Código de saída quando a interface já estava aberta (clique repetido no atalho ou na Central):
// o ABRIR_INTERFACE.cmd usa para fechar esta janela extra sozinho, sem "pause".
const SAIDA_JA_ABERTA = 10;

async function jaEstaAberta() {
  try {
    const resposta = await fetch(`http://127.0.0.1:${porta}/api/ping`, { signal: AbortSignal.timeout(1500) });
    return (await resposta.json()).app === NOME_APP;
  } catch {
    return false;
  }
}

// Dois cliques seguidos: a outra janela pode ter acabado de ocupar a porta e ainda não responder.
// Tenta por alguns segundos antes de concluir que a porta é de outro programa.
async function esperarJaAberta(tentativas = 8) {
  for (let i = 0; i < tentativas; i++) {
    if (await jaEstaAberta()) return true;
    await new Promise((r) => setTimeout(r, 500));
  }
  return false;
}

try {
  const interfaceGrafica = await iniciarInterface({ cfg: criarConfig(), porta, aoEncerrar: () => process.exit(0) });
  console.log(`Retirar_Auto_Infracao - interface aberta em ${interfaceGrafica.url}`);
  console.log('Deixe esta janela aberta enquanto usa a interface. Para fechar: botão "Fechar interface" ou Ctrl+C.');
  abrirNavegador(interfaceGrafica.url);
  const sair = () => interfaceGrafica.fechar().finally(() => process.exit(0));
  process.on('SIGINT', sair);
  process.on('SIGTERM', sair);
} catch (e) {
  if (e.code === 'EADDRINUSE' && (await esperarJaAberta())) {
    console.log(`A interface já está aberta em http://127.0.0.1:${porta}/ - abrindo no navegador.`);
    console.log('Nada foi iniciado de novo: continue na janela que já estava aberta.');
    abrirNavegador(`http://127.0.0.1:${porta}/`);
    process.exitCode = SAIDA_JA_ABERTA;
  } else {
    console.error(e.code === 'EADDRINUSE' ? `A porta ${porta} está em uso por outro programa. Use PORTA_INTERFACE=<outra porta>.` : e);
    process.exitCode = 1;
  }
}
