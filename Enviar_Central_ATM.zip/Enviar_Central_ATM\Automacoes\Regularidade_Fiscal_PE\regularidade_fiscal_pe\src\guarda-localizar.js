/*
 * Guarda do botão "Localizar". Enquanto a automação roda, qualquer clique/envio/tecla SINTÉTICO que alcance o
 * Localizar é BLOQUEADO e registrado — EXCETO o único clique que a própria automação autoriza, de propósito,
 * por uma janela curta (NS.guarda.autorizar()). Assim, Enter, atalho (Alt+L), requestSubmit, cliques repetidos
 * ou chamadas indiretas nunca acionam o Localizar por acidente.
 */
(function () {
  'use strict';
  const NS = (window.EFiscoCRF = window.EFiscoCRF || {});
  const EVENTOS = ['click', 'mousedown', 'mouseup', 'pointerdown', 'pointerup', 'submit', 'keydown', 'keyup', 'keypress'];
  const GESTO = ['mousedown', 'mouseup', 'pointerdown', 'pointerup'];

  const estado = {
    ativa: false, bloqueados: 0, autorizados: 0, doUsuario: 0, detalhes: [], ultimaAcaoReal: 0,
    autorizadoAte: 0, cliquesPermitidos: 0, enviosPermitidos: 0
  };

  const ehLocalizar = (el) => {
    if (!el || !el.closest) return false;
    const b = el.closest('#btt_localizar, input[type=submit], button[type=submit]');
    return !!b && (b.id === 'btt_localizar' || NS.dom.norm(b.value || b.textContent).startsWith('localizar'));
  };

  function aoEvento(e) {
    if (e.isTrusted && e.type !== 'submit') estado.ultimaAcaoReal = Date.now(); // última interação REAL do usuário
    if (!estado.ativa) return;
    let alvoLocalizar = false;
    let motivo = '';
    if (e.type === 'submit') {
      alvoLocalizar = ehLocalizar(e.submitter) || !e.submitter; // Localizar é o único submit do formulário
      motivo = 'envio do formulário';
    } else if (e.type.startsWith('key')) {
      const atalho = (e.altKey || e.ctrlKey) && String(e.key).toLowerCase() === 'l';
      alvoLocalizar = (atalho || e.key === 'Enter') && !e.isTrusted;
      motivo = atalho ? 'atalho de teclado (Localizar)' : 'tecla Enter';
    } else {
      alvoLocalizar = ehLocalizar(e.target);
      motivo = `evento ${e.type} no botão Localizar`;
    }
    if (!alvoLocalizar) return;

    // Envios via script são "trusted" no navegador: só vale como do usuário se houve interação real há <1,5 s.
    const doUsuario = e.type === 'submit' ? Date.now() - estado.ultimaAcaoReal < 1500 : e.isTrusted;
    if (doUsuario) { estado.doUsuario++; return; }

    // Clique AUTORIZADO pela automação: janela curta e UM único clique / UM único envio.
    if (Date.now() < estado.autorizadoAte && !e.type.startsWith('key')) {
      if (GESTO.includes(e.type)) return;
      if (e.type === 'click' && estado.cliquesPermitidos > 0) { estado.cliquesPermitidos--; estado.autorizados++; return; }
      if (e.type === 'submit' && estado.enviosPermitidos > 0) { estado.enviosPermitidos--; return; }
    }

    estado.bloqueados++;
    if (estado.detalhes.length < 10) estado.detalhes.push(motivo);
    e.preventDefault();
    e.stopImmediatePropagation();
    NS.log.aviso(`BLOQUEADO: tentativa não autorizada de acionar "Localizar" (${motivo}).`);
  }

  let instalada = false;
  function instalar() {
    if (instalada) return;
    instalada = true;
    EVENTOS.forEach((tipo) => window.addEventListener(tipo, aoEvento, true));
  }

  NS.guarda = {
    ativar() {
      instalar(); estado.ativa = true; estado.bloqueados = 0; estado.autorizados = 0; estado.doUsuario = 0; estado.detalhes = [];
      estado.autorizadoAte = 0; estado.cliquesPermitidos = 0; estado.enviosPermitidos = 0;
    },
    desativar() { estado.ativa = false; },
    /** Autoriza UM clique (e o envio resultante) no Localizar pelos próximos `ms`. */
    autorizar(ms = 1500) { estado.autorizadoAte = Date.now() + ms; estado.cliquesPermitidos = 1; estado.enviosPermitidos = 1; },
    revogar() { estado.autorizadoAte = 0; estado.cliquesPermitidos = 0; estado.enviosPermitidos = 0; },
    resumo: () => ({ bloqueados: estado.bloqueados, autorizados: estado.autorizados, doUsuario: estado.doUsuario, detalhes: [...estado.detalhes] })
  };
})();
