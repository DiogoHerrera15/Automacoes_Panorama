﻿# Instalação guiada da Automação PGFN neste computador (usuário atual do Windows; não precisa de administrador).
# Confere e prepara tudo o que a automação precisa para rodar sozinha (sem o Claude):
#   1. a pasta do projeto em  <Downloads>\Auto_PGFN  (é onde o Chrome salva os arquivos de cada CNPJ);
#   2. o Chrome instalado e a pasta de downloads dele;
#   3. a extensão Automação_PGFN carregada no Chrome, com "Permitir no modo anônimo";
#   4. o ajudante do Windows registrado e respondendo (a extensão conversa com ele pelo próprio Chrome);
#   5. cnpjs.json, a pasta Documentos_arrecadacao e um atalho na Área de Trabalho.
# Pode ser rodado de novo quando quiser: não apaga nada. -SoVerificar: só confere (sem perguntas nem mudanças).
param([switch]$SoVerificar)
$ErrorActionPreference = 'Stop'
$INST = $PSScriptRoot
$BASE = Split-Path $INST -Parent
$PASTA_EXT = Join-Path $BASE 'Automação_PGFN'
$PASTA_AJ = Join-Path $BASE 'ajudante_salvar_como'
$problemas = 0

function Titulo($t) { Write-Host ''; Write-Host "== $t" -ForegroundColor Cyan }
function Ok($t) { Write-Host "   OK  $t" -ForegroundColor Green }
function Aviso($t) { Write-Host "   !!  $t" -ForegroundColor Yellow; $script:problemas++ }
function Erro($t) { Write-Host "   XX  $t" -ForegroundColor Red; $script:problemas++ }
function Esperar($t) { if (-not $SoVerificar) { Write-Host ''; Read-Host "   $t (Enter para continuar)" | Out-Null } }

Write-Host ''
Write-Host '  Instalação da Automação PGFN' -ForegroundColor Cyan
Write-Host "  Pasta: $BASE"

# ---- 1. pasta ----
Titulo '1. Pasta do projeto'
$downloads = Join-Path $env:USERPROFILE 'Downloads'
$esperada = Join-Path $downloads 'Auto_PGFN'
if ($BASE.TrimEnd('\') -ieq $esperada) { Ok "a pasta está em $esperada" }
else {
  Erro "a pasta precisa ficar em $esperada"
  Write-Host '        O Chrome salva os documentos em Downloads\Auto_PGFN\Documentos_arrecadacao\<CNPJ>, e o ajudante'
  Write-Host '        só confirma a janela "Salvar como" dentro dessa pasta. Mova a pasta inteira para lá e rode de novo.'
  if (-not $SoVerificar) { Read-Host '   Enter para sair' | Out-Null }
  exit 1
}
foreach ($p in @($PASTA_EXT, $PASTA_AJ, (Join-Path $BASE 'orquestrador'))) {
  if (-not (Test-Path -LiteralPath $p)) { Erro "falta a pasta $p (copie o pacote inteiro)"; exit 1 }
}

# ---- 2. Chrome ----
Titulo '2. Google Chrome'
$chrome = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe' -ErrorAction SilentlyContinue).'(default)'
if (-not $chrome) { $chrome = (Get-ItemProperty 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe' -ErrorAction SilentlyContinue).'(default)' }
if ($chrome -and (Test-Path -LiteralPath $chrome)) { Ok "Chrome: $chrome" } else { Erro 'Google Chrome não encontrado: instale o Chrome e rode de novo'; exit 1 }
$dadosChrome = Join-Path $env:LOCALAPPDATA 'Google\Chrome\User Data'
$prefsPadrao = Join-Path $dadosChrome 'Default\Preferences'
if (Test-Path -LiteralPath $prefsPadrao) {
  try {
    $pr = Get-Content -LiteralPath $prefsPadrao -Raw -Encoding UTF8 | ConvertFrom-Json
    $dir = [string]$pr.download.default_directory
    if (-not $dir -or $dir.TrimEnd('\') -ieq $downloads) { Ok 'o Chrome salva os downloads na pasta Downloads' }
    else { Aviso "o Chrome salva os downloads em ""$dir"". Em Configurações > Downloads, volte para $downloads" }
  } catch { Aviso 'não consegui ler as configurações do Chrome (confira se os downloads vão para a pasta Downloads)' }
}

# ---- 3. extensão ----
Titulo '3. Extensão Automação_PGFN no Chrome'
function Achar-Extensao {
  $achados = @()
  foreach ($arq in (Get-ChildItem -Path $dadosChrome -Recurse -Depth 1 -Include 'Secure Preferences', 'Preferences' -File -ErrorAction SilentlyContinue)) {
    try { $prefs = Get-Content -LiteralPath $arq.FullName -Raw -Encoding UTF8 | ConvertFrom-Json } catch { continue }
    $ext = $prefs.extensions.settings
    if (-not $ext) { continue }
    foreach ($p in $ext.PSObject.Properties) {
      $caminho = [string]$p.Value.path
      if ($caminho -and ($caminho.TrimEnd('\') -ieq $PASTA_EXT.TrimEnd('\'))) {
        $achados += [pscustomobject]@{ id = $p.Name; anonimo = [bool]$p.Value.incognito; perfil = $arq.Directory.Name }
      }
    }
  }
  return @($achados | Sort-Object id, anonimo -Unique)
}
$ext = @(Achar-Extensao)
for ($volta = 0; -not $ext.Count -and -not $SoVerificar -and $volta -lt 3; $volta++) {
  Write-Host '   A extensão ainda não está carregada. Vou abrir o Chrome e a pasta dela. No Chrome:'
  Write-Host '     1) em chrome://extensions, ligue "Modo do desenvolvedor" (canto superior direito);'
  Write-Host '     2) clique em "Carregar sem compactação" e escolha a pasta:'
  Write-Host "        $PASTA_EXT"
  Write-Host '     3) na extensão, clique em "Detalhes" e ligue "Permitir no modo anônimo".'
  try { Start-Process -FilePath $chrome -ArgumentList 'chrome://extensions' } catch { }
  try { Start-Process explorer.exe -ArgumentList "`"$PASTA_EXT`"" } catch { }
  Esperar 'Quando terminar'
  Start-Sleep -Seconds 3 # o Chrome grava as configurações em seguida
  $ext = @(Achar-Extensao)
}
if (-not $ext.Count) { Erro 'extensão não encontrada no Chrome (carregue a pasta Automação_PGFN em chrome://extensions)'; $ids = @() }
else {
  $ids = @($ext.id | Sort-Object -Unique)
  Ok "extensão carregada (ID $($ids -join ', '))"
  if (@($ext | Where-Object { $_.anonimo }).Count) { Ok '"Permitir no modo anônimo" ligado' }
  else { Aviso 'ligue "Permitir no modo anônimo" (chrome://extensions > Automação_PGFN > Detalhes): a automação abre o Chrome anônimo' }
}

# ---- 4. ajudante ----
Titulo '4. Ajudante do Windows (janela "Salvar como", certificado e orquestrador)'
if ($ids.Count -and -not $SoVerificar) {
  & (Join-Path $PASTA_AJ 'instalar_ajudante.ps1') -IdExtensao $ids[0] | Out-Host
}
$chave = 'HKCU:\Software\Google\Chrome\NativeMessagingHosts\com.auto_pgfn.salvar_como'
$manif = (Get-ItemProperty $chave -ErrorAction SilentlyContinue).'(default)'
if (-not $manif -or -not (Test-Path -LiteralPath $manif)) { Erro 'ajudante não registrado no Windows' }
else {
  $m = Get-Content -LiteralPath $manif -Raw -Encoding UTF8 | ConvertFrom-Json
  if ($ids.Count -and -not (@($m.allowed_origins) -contains "chrome-extension://$($ids[0])/")) { Aviso 'o ajudante está registrado para outra extensão: rode este instalador de novo' }
  if (-not (Test-Path -LiteralPath $m.path)) { Erro "o ajudante aponta para um arquivo que não existe: $($m.path)" }
  else {
    # conversa com o ajudante exatamente como o Chrome faz (4 bytes de tamanho + JSON, com "--parent-window=0")
    $msg = Join-Path $env:TEMP ("pgfn_teste_" + [guid]::NewGuid().ToString('N') + '.bin')
    try {
      $corpo = [Text.Encoding]::UTF8.GetBytes('{"acao":"versao"}')
      [IO.File]::WriteAllBytes($msg, [byte[]]([BitConverter]::GetBytes([int]$corpo.Length) + $corpo))
      $psi = New-Object Diagnostics.ProcessStartInfo 'cmd.exe', ("/d /s /c `"`"$($m.path)`" chrome-extension://teste/ --parent-window=0 < `"$msg`"`"")
      $psi.UseShellExecute = $false; $psi.RedirectStandardOutput = $true; $psi.CreateNoWindow = $true
      $p = [Diagnostics.Process]::Start($psi)
      $ms = New-Object IO.MemoryStream; $p.StandardOutput.BaseStream.CopyTo($ms); [void]$p.WaitForExit(20000)
      $b = $ms.ToArray()
      $n = if ($b.Length -ge 4) { [BitConverter]::ToInt32($b, 0) } else { -1 }
      if ($n -eq $b.Length - 4) { Ok ("ajudante respondeu: " + [Text.Encoding]::UTF8.GetString($b, 4, $n)) }
      else { Erro 'o ajudante respondeu fora do formato que o Chrome entende (algo escreveu na saída antes dele)' }
    } catch { Erro "não consegui testar o ajudante: $($_.Exception.Message)" }
    finally { Remove-Item -LiteralPath $msg -ErrorAction SilentlyContinue }
  }
}

# ---- 5. arquivos de trabalho e atalho ----
Titulo '5. Interface, pasta dos documentos e atalho'
$docs = Join-Path $BASE 'Documentos_arrecadacao'
if (-not (Test-Path -LiteralPath $docs)) { if (-not $SoVerificar) { New-Item -ItemType Directory -Path $docs | Out-Null }; Ok 'pasta Documentos_arrecadacao criada' } else { Ok 'pasta Documentos_arrecadacao existe' }
# interface (Automacao_PGFN.exe): vem pronta no pacote; se faltar, é compilada aqui com o .NET Framework do Windows
$exe = Join-Path $BASE 'Automacao_PGFN.exe'
if (-not (Test-Path -LiteralPath $exe) -and -not $SoVerificar) { & cmd /c "`"$(Join-Path $BASE 'interface\compilar.bat')`"" | Out-Null }
if (Test-Path -LiteralPath $exe) { Ok 'interface Automacao_PGFN.exe pronta (certificado + CNPJs + Iniciar)' } else { Erro 'faltou Automacao_PGFN.exe (rode interface\compilar.bat)' }
$cfg = Join-Path $BASE 'cnpjs.json'
if (-not (Test-Path -LiteralPath $cfg)) {
  Ok 'configurações pela interface (cnpjs.json não é mais necessário)'
} else {
  try {
    $c = Get-Content -LiteralPath $cfg -Raw -Encoding UTF8 | ConvertFrom-Json
    $total = (@($c.certificados | ForEach-Object { @($_.cnpjs).Count }) | Measure-Object -Sum).Sum
    Ok "cnpjs.json: $(@($c.certificados).Count) certificado(s), $total CNPJ(s)"
  } catch { Erro "cnpjs.json com erro de digitação (vírgula ou aspas): $($_.Exception.Message)" }
}
if (-not $SoVerificar) {
  $resp = Read-Host '   Criar o atalho "Automação PGFN" na Área de Trabalho? (S/N)'
  if ($resp -match '^[sS]') {
    $ws = New-Object -ComObject WScript.Shell
    $lnk = $ws.CreateShortcut((Join-Path ([Environment]::GetFolderPath('Desktop')) 'Automação PGFN.lnk'))
    $alvo = if (Test-Path -LiteralPath $exe) { $exe } else { Join-Path $BASE 'INICIAR_AUTOMACAO.bat' }
    $lnk.TargetPath = $alvo; $lnk.WorkingDirectory = $BASE
    $lnk.IconLocation = "$chrome,0"; $lnk.Save()
    Ok 'atalho criado na Área de Trabalho'
  }
}

Write-Host ''
if ($problemas) { Write-Host "  Terminado com $problemas ponto(s) para conferir (acima, em amarelo/vermelho)." -ForegroundColor Yellow }
else { Write-Host '  Tudo pronto. Para rodar: Automacao_PGFN.exe (ou o atalho na Área de Trabalho): escolha o certificado, cole os CNPJs e clique em Iniciar.' -ForegroundColor Green }
Write-Host '  Depois de instalar ou atualizar a extensão, clique em "Recarregar" nela em chrome://extensions.'
