// Funções puras de CPF/CNPJ (sem acesso à página), testadas no Node (tests/cnpj.test.js).
//
// - normalizar: só letras e números, em maiúsculas (o CNPJ alfanumérico vale desde
//   julho/2026, e o site do TST já o aceita).
// - formatar: igual à máscara do site (formataCPFCNPJ em /js/funcoes.js): pontua com 11
//   (CPF) ou 14 (CNPJ) caracteres; com outro tamanho, devolve sem pontuação.
// - validar: confere tamanho e dígitos verificadores (CPF numérico; CNPJ numérico ou
//   alfanumérico).

(function (raiz) {
  function normalizar(documento) {
    return String(documento ?? '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  }

  function formatar(documento) {
    const d = normalizar(documento);
    if (d.length === 11) return `${d.slice(0, 3)}.${d.slice(3, 6)}.${d.slice(6, 9)}-${d.slice(9, 11)}`;
    if (d.length === 14) return `${d.slice(0, 2)}.${d.slice(2, 5)}.${d.slice(5, 8)}/${d.slice(8, 12)}-${d.slice(12, 14)}`;
    return d;
  }

  // Valor de cada caractere no cálculo do CNPJ alfanumérico: código ASCII - 48
  // ("0".."9" = 0..9, "A" = 17, ...). Para CNPJ só numérico dá o cálculo de sempre.
  function digitoCnpj(base) {
    let peso = 2;
    let soma = 0;
    for (let i = base.length - 1; i >= 0; i--) {
      soma += (base.charCodeAt(i) - 48) * peso;
      peso = peso === 9 ? 2 : peso + 1;
    }
    const resto = soma % 11;
    return resto < 2 ? 0 : 11 - resto;
  }

  function cnpjValido(d) {
    if (!/^[A-Z0-9]{12}[0-9]{2}$/.test(d)) return false;
    if (/^(\d)\1{13}$/.test(d)) return false;
    const dv1 = digitoCnpj(d.slice(0, 12));
    const dv2 = digitoCnpj(d.slice(0, 12) + dv1);
    return d.endsWith(`${dv1}${dv2}`);
  }

  function cpfValido(d) {
    if (!/^\d{11}$/.test(d) || /^(\d)\1{10}$/.test(d)) return false;
    const dv = (n) => {
      let soma = 0;
      for (let i = 0; i < n; i++) soma += Number(d[i]) * (n + 1 - i);
      const r = (soma * 10) % 11;
      return r === 10 ? 0 : r;
    };
    return dv(9) === Number(d[9]) && dv(10) === Number(d[10]);
  }

  // { ok, tipo: 'CNPJ'|'CPF'|null, normalizado, formatado, motivo }
  function validar(documento) {
    const normalizado = normalizar(documento);
    const formatado = formatar(normalizado);
    if (normalizado.length === 14) {
      return cnpjValido(normalizado)
        ? { ok: true, tipo: 'CNPJ', normalizado, formatado, motivo: '' }
        : { ok: false, tipo: 'CNPJ', normalizado, formatado, motivo: 'dígitos verificadores do CNPJ não conferem' };
    }
    if (normalizado.length === 11) {
      return cpfValido(normalizado)
        ? { ok: true, tipo: 'CPF', normalizado, formatado, motivo: '' }
        : { ok: false, tipo: 'CPF', normalizado, formatado, motivo: 'dígitos verificadores do CPF não conferem' };
    }
    return { ok: false, tipo: null, normalizado, formatado, motivo: `tamanho inválido (${normalizado.length} caracteres; esperado 11 ou 14)` };
  }

  const CNPJ = { normalizar, formatar, validar };
  raiz.CNDT = raiz.CNDT || {};
  raiz.CNDT.CNPJ = CNPJ;
  if (typeof module !== 'undefined' && module.exports) module.exports = CNPJ;
})(typeof globalThis !== 'undefined' ? globalThis : self);
