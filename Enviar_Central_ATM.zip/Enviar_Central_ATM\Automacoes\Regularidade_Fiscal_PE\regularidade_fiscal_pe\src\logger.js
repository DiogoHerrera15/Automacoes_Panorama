/* Registro: console + painel na página + chrome.storage (lido pelo popup). */
(function () {
  'use strict';
  const NS = (window.EFiscoCRF = window.EFiscoCRF || {});
  const MAX_LINHAS = 400;
  const buffer = [];
  const ouvintes = [];

  const hora = () => new Date().toLocaleTimeString('pt-BR', { hour12: false });

  function persistir() {
    try {
      chrome.storage.local.set({ [NS.CONFIG.storage.log]: buffer.slice(-MAX_LINHAS) });
    } catch (_) { /* contexto da extensão invalidado (recarga): ignorar */ }
  }

  function registrar(nivel, msg) {
    const linha = { t: hora(), nivel, msg };
    buffer.push(linha);
    if (buffer.length > MAX_LINHAS) buffer.shift();
    const fn = nivel === 'erro' ? 'error' : nivel === 'aviso' ? 'warn' : 'log';
    console[fn](`[EFisco-CRF] ${linha.t} ${nivel.toUpperCase()}: ${msg}`);
    ouvintes.forEach((f) => { try { f(linha); } catch (_) {} });
    persistir();
  }

  NS.log = {
    info: (m) => registrar('info', m),
    ok: (m) => registrar('ok', m),
    aviso: (m) => registrar('aviso', m),
    erro: (m) => registrar('erro', m),
    limpar() { buffer.length = 0; persistir(); },
    aoRegistrar(f) { ouvintes.push(f); },
    resultado(obj) {
      const r = Object.assign({ quando: new Date().toISOString() }, obj);
      try { chrome.storage.local.set({ [NS.CONFIG.storage.resultado]: r }); } catch (_) {}
      return r;
    }
  };
})();
