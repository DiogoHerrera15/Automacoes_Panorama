# Central de Automações (versão portátil)

Janela do Windows que reúne as automações do escritório: um cartão por automação, com **Abrir automação**, ajuda
**?**, situação (pasta, Node.js, extensão do Chrome), busca, filtros por categoria e tema Claro/Escuro.

- **Abrir:** atalho "Central de Automações" na Área de Trabalho, ou dois cliques em `Abrir Central.vbs`.
- **Conferir sem abrir:** `powershell -NoProfile -ExecutionPolicy Bypass -File Central.ps1 -Validar`
- **Abrir uma automação pela linha de comando:** `... -File Central.ps1 -Abrir "RETIRAR AUTO-INFRAÇÃO"`
- **Autoteste da janela** (não inicia nada): `... -STA -File Central.ps1 -TesteJanela <pasta> [-Escala 1.5]`

Esta pasta precisa ficar **ao lado** da pasta `Automacoes` (a Central usa `%CENTRAL_ATM%` = a pasta que contém as duas).
Detalhes: `LEIA-ME.txt` e, na raiz do pacote, `README_INSTALACAO_COMPLETA.md`.

| Arquivo | O que é |
|---|---|
| `Central.ps1` | o programa (código-fonte) |
| `Abrir Central.vbs` | inicializador sem janela de comando |
| `automacoes.json` | configuração: a lista de automações |
| `ajuda.json` | recursos: textos da ajuda "?" |
| `preferencias.json` | criado sozinho (tema) |

Diferença para o original da máquina de origem: só a função `Expandir` (aceita `%CENTRAL_ATM%`) e os caminhos de
`automacoes.json`/`ajuda.json`. Interface, temas, cartões, busca, filtros e ajuda estão idênticos.
