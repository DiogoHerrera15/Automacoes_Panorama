// Lista de empresas, nomes de pastas/arquivos e regras da fila. Só funções puras (sem acesso
// ao navegador): usadas pela janela (interface.js), pelo background.js e pelos testes do Node.
//
// Lista: uma empresa por linha, no formato CNPJ;NOME_EMPRESA (o TAB do Excel também vale).
//  - CNPJ com ou sem pontuação; CNPJ alfanumérico (2026) e CPF também são aceitos (o site aceita);
//  - CNPJ numérico com 12 ou 13 dígitos (Excel tirou os zeros) é completado SE os dígitos verificadores baterem;
//  - dígitos verificadores errados, falta de ";" ou de nome: a linha é apontada e ignorada (não impede o resto);
//  - CNPJ repetido: vale a primeira linha.
// Pastas: compatíveis com o Windows; empresas com o mesmo nome ganham " - <CNPJ>" na pasta e no arquivo.
// Arquivo: CNDT_<NOME DA EMPRESA>.pdf, dentro da pasta da empresa.

(function (raiz) {
  'use strict';
  const CNPJ = (raiz.CNDT && raiz.CNDT.CNPJ) || (typeof require === 'function' ? require('./cnpj.js') : null);

  const RESERVADOS = /^(con|prn|aux|nul|com[1-9]|lpt[1-9])$/i;

  // Trecho de nome aceito pelo Windows: sem < > : " / \ | ? * nem caracteres de controle, sem espaços
  // repetidos, sem ponto/espaço nas pontas, sem nomes reservados (CON, NUL...), no máximo `max` letras.
  function limparNome(texto, max = 100) {
    let t = String(texto || '')
      .replace(/[\u0000-\u001f\u007f]/g, ' ')
      .replace(/[\\/]+/g, '-')
      .replace(/[<>:"|?*]/g, '_')
      .replace(/\s+/g, ' ')
      .trim();
    if (t.length > max) t = t.slice(0, max);
    t = t.replace(/[. ]+$/, '').replace(/^[. ]+/, '');
    if (RESERVADOS.test(t)) t += '_';
    return t;
  }

  // Pasta principal (dentro de Downloads): pode ter subpastas com "/" ou "\"; cada parte é limpa.
  function limparPastaPrincipal(texto) {
    return String(texto || '').split(/[\\/]+/)
      .map((p) => limparNome(p, 80))
      .filter((p) => p && p !== '.' && p !== '..')
      .join('/');
  }

  function lerLista(texto) {
    const itens = [], erros = [], rejeitadas = [], vistos = new Set();
    let repetidos = 0, ajustados = 0, vazias = 0;
    const rejeitar = (n, linha, motivo) => {
      erros.push(`Linha ${n}: ${motivo}`);
      rejeitadas.push({ linha: n, texto: String(linha).trim().slice(0, 200), motivo });
    };
    String(texto || '').split(/\r?\n/).forEach((linha, i) => {
      const n = i + 1;
      if (!linha.trim()) { vazias += 1; return; }
      const corte = linha.search(/[;\t]/);
      if (corte < 0) { rejeitar(n, linha, 'falta o ";" e o nome da empresa (use CNPJ;NOME_EMPRESA)'); return; }
      const bruto = linha.slice(0, corte).trim();
      const nome = linha.slice(corte + 1).replace(/[;\t]+/g, ' ').replace(/\s+/g, ' ').trim()
        .replace(/^"+|"+$/g, '').trim();
      if (!bruto) { rejeitar(n, linha, 'falta o CNPJ antes do ";"'); return; }
      if (!/^[0-9A-Za-z.\-/\s]+$/.test(bruto)) { rejeitar(n, linha, `"${bruto}" tem caracteres que não fazem parte de um CNPJ/CPF`); return; }
      let doc = CNPJ.validar(bruto);
      let completou = false;
      if (!doc.ok && /^\d{12,13}$/.test(doc.normalizado)) {
        const tentativa = CNPJ.validar(doc.normalizado.padStart(14, '0'));
        if (tentativa.ok) { doc = tentativa; completou = true; }
      }
      if (!doc.ok) { rejeitar(n, linha, `"${bruto}" não é um CNPJ/CPF válido (${doc.motivo})`); return; }
      if (!limparNome(nome)) { rejeitar(n, linha, `falta o nome da empresa depois do ";" (${doc.formatado})`); return; }
      if (vistos.has(doc.normalizado)) { repetidos += 1; return; }
      vistos.add(doc.normalizado);
      if (completou) ajustados += 1;
      itens.push({ cnpj: doc.normalizado, formatado: doc.formatado, tipo: doc.tipo, nome, pasta: '', arquivo: '', linha: n, completou });
    });
    atribuirPastas(itens);
    return { itens, erros, rejeitadas, repetidos, ajustados, vazias };
  }

  // Pasta e arquivo de cada empresa. Nomes iguais (sem diferenciar maiúsculas, como o Windows):
  // todas as do grupo ganham " - <CNPJ>", na pasta e no arquivo.
  function atribuirPastas(itens) {
    const grupos = new Map();
    for (const it of itens) {
      it.pasta = limparNome(it.nome);
      const chave = it.pasta.toLowerCase();
      if (!grupos.has(chave)) grupos.set(chave, []);
      grupos.get(chave).push(it);
    }
    for (const g of grupos.values()) {
      if (g.length > 1) g.forEach((it) => { it.pasta = limparNome(`${it.pasta} - ${it.cnpj}`, 130); it.diferenciada = true; });
    }
    for (const it of itens) it.arquivo = `CNDT_${it.pasta}.pdf`;
    return itens;
  }

  // Caminho dentro de Downloads: <pasta principal>/<pasta da empresa>/CNDT_<nome>.pdf
  const caminhoDoArquivo = (pastaPrincipal, item) => `${pastaPrincipal}/${item.pasta}/${item.arquivo}`;

  // Segunda barreira (background): só caminhos relativos, sem "..", sem caracteres recusados pelo Windows.
  const NOMES_RESERVADOS = /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(\..*)?$/i;
  const caminhoValido = (p) => typeof p === 'string' && p.length > 0 && p.length <= 400 &&
    p.split('/').every((s) => s.length > 0 && s.length <= 140 && !/[<>:"|?*\\\u0000-\u001f]/.test(s) &&
      !/^\.+$/.test(s) && !/^\s|[\s.]$/.test(s) && !NOMES_RESERVADOS.test(s));

  // ---------------- fila ----------------
  // andamento: { [cnpj]: { estado: 'concluida' | 'erro', detalhe, arquivo, quando } }
  // Próxima empresa, na ordem da lista: primeiro as nunca processadas; quando só restam as com
  // erro e `refazerErros` = true, a primeira com erro (cada uma é refeita uma vez por rodada:
  // `jaRefeitas` guarda as refeitas nesta rodada).
  function proximaEmpresa(itens, andamento, { refazerErros = false, jaRefeitas = [] } = {}) {
    const a = andamento || {};
    const nova = itens.find((it) => !a[it.cnpj]);
    if (nova) return nova;
    if (!refazerErros) return null;
    return itens.find((it) => a[it.cnpj] && a[it.cnpj].estado === 'erro' && !jaRefeitas.includes(it.cnpj)) || null;
  }

  function resumo(itens, andamento) {
    const a = andamento || {};
    let concluidas = 0, erros = 0;
    for (const it of itens) {
      const e = a[it.cnpj] && a[it.cnpj].estado;
      if (e === 'concluida') concluidas += 1; else if (e === 'erro') erros += 1;
    }
    return { total: itens.length, concluidas, erros, pendentes: itens.length - concluidas - erros };
  }

  function textoRelatorio({ pasta, itens, andamento, rejeitadas, quando }) {
    const a = andamento || {};
    const r = resumo(itens, a);
    const L = [];
    L.push('RELATÓRIO - EMISSÃO DE CNDT (TST)');
    L.push(`Pasta: Downloads\\${String(pasta || '').replace(/\//g, '\\')}`);
    L.push(`Gerado em: ${quando || new Date().toLocaleString('pt-BR')}`);
    L.push(`Empresas: ${r.total} | Concluídas: ${r.concluidas} | Com erro: ${r.erros} | Pendentes: ${r.pendentes}`);
    L.push('');
    const comErro = itens.filter((it) => a[it.cnpj] && a[it.cnpj].estado === 'erro');
    const ok = itens.filter((it) => a[it.cnpj] && a[it.cnpj].estado === 'concluida');
    if (comErro.length) {
      L.push(`COM ERRO (${comErro.length})`);
      comErro.forEach((it, i) => { L.push(`${i + 1}. ${it.formatado} - ${it.nome}`); L.push(`   Motivo: ${a[it.cnpj].detalhe || '-'}`); });
      L.push('');
    }
    if (ok.length) {
      L.push(`CONCLUÍDAS (${ok.length})`);
      ok.forEach((it, i) => L.push(`${i + 1}. ${it.formatado} - ${it.nome} -> ${a[it.cnpj].arquivo || it.arquivo}`));
      L.push('');
    }
    if (rejeitadas && rejeitadas.length) {
      L.push(`LINHAS DA LISTA IGNORADAS (${rejeitadas.length})`);
      rejeitadas.forEach((x) => { L.push(`Linha ${x.linha}: ${x.texto}`); L.push(`   Motivo: ${x.motivo}`); });
    }
    return L.join('\r\n');
  }

  const api = { limparNome, limparPastaPrincipal, lerLista, atribuirPastas, caminhoDoArquivo, caminhoValido, proximaEmpresa, resumo, textoRelatorio };
  raiz.CNDT = raiz.CNDT || {};
  raiz.CNDT.LISTA = api;
  if (typeof module === 'object' && module.exports) module.exports = api;
})(typeof self !== 'undefined' ? self : globalThis);
