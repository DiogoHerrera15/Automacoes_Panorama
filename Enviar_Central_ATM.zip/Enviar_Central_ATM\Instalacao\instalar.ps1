﻿# Instala a Central de Automações e todas as automações deste pacote no usuário atual do Windows.
# Não precisa de administrador (exceto se o próprio instalador do Node.js pedir). Pode rodar de novo: atualiza os
# programas e preserva dados, configurações e documentos já gerados.
#
#   Dois cliques em INSTALAR.cmd (na raiz do pacote), ou:
#   powershell -NoProfile -ExecutionPolicy Bypass -File Instalacao\instalar.ps1 [opções]
#
# Opções:
#   -Destino <pasta>          onde instalar a Central e as automações (padrão: %USERPROFILE%\Central_ATM)
#   -InstalarDependencias     instala Chrome/Node.js/Python que faltarem pelo winget sem perguntar
#   -SemPerguntas             não pergunta nada (não abre o Chrome nem roda o instalador interativo da PGFN)
#   -SemAtalho                não cria o atalho na Área de Trabalho
#   -PularDependenciasProjetos não roda npm/pip nas automações (só copia e configura)
#   -PastaPGFN / -PastaAtalho  só para testes (a PGFN precisa ficar em Downloads\Auto_PGFN)
param(
  [string]$Destino = (Join-Path $env:USERPROFILE 'Central_ATM'),
  [string]$PastaPGFN = (Join-Path $env:USERPROFILE 'Downloads\Auto_PGFN'),
  [switch]$InstalarDependencias,
  [switch]$SemPerguntas,
  [switch]$SemAtalho,
  [string]$PastaAtalho = ([Environment]::GetFolderPath('Desktop')),
  [switch]$PularDependenciasProjetos
)
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'comum.ps1')
$Destino = [IO.Path]::GetFullPath($Destino).TrimEnd('\')
$PastaPGFN = [IO.Path]::GetFullPath($PastaPGFN).TrimEnd('\')

$pastaLogs = Join-Path $PSScriptRoot 'logs'
try { New-Item -ItemType Directory -Force -Path $pastaLogs | Out-Null; $script:LOG = Join-Path $pastaLogs ("instalacao_{0}.txt" -f (Get-Date -Format 'yyyy-MM-dd_HH-mm-ss')) }
catch { $script:LOG = Join-Path $env:TEMP ("Central_ATM_instalacao_{0}.txt" -f (Get-Date -Format 'yyyy-MM-dd_HH-mm-ss')) }

function Perguntar([string]$texto) {
  if ($SemPerguntas) { return $false }
  return ((Read-Host "  $texto (S/N)") -match '^[sS]')
}
function Copiar-Pasta($de, $para, [string[]]$semPastas = @(), [string[]]$semArquivos = @()) {
  $ra = @($de, $para, '/E', '/R:1', '/W:1', '/NFL', '/NDL', '/NJH', '/NJS', '/NP')
  if ($semPastas.Count) { $ra += '/XD'; $ra += $semPastas }
  if ($semArquivos.Count) { $ra += '/XF'; $ra += $semArquivos }
  & robocopy @ra | Out-Null
  if ($LASTEXITCODE -ge 8) { throw "falha ao copiar $de para $para (robocopy $LASTEXITCODE)" }
}
function Instalar-Winget([string]$id, [string]$nome, [string[]]$extra = @()) {
  if (-not (Get-Command winget -ErrorAction SilentlyContinue)) { Erro "winget não disponível: instale $nome pelo site oficial e rode de novo"; return }
  if (-not $InstalarDependencias -and -not (Perguntar "Instalar $nome agora pelo winget (fonte oficial)?")) { Aviso "$nome não instalado (escolha sua)"; return }
  Info "winget install --id $id -e $($extra -join ' ')"
  & winget install --id $id -e --accept-package-agreements --accept-source-agreements @extra
  Atualizar-Path
}

Write-Host ''
Write-Host '  Instalação da Central de Automações' -ForegroundColor Cyan
Info "Pacote:              $PACOTE"
Info "Pasta de instalação: $Destino"
Info "Pasta da PGFN:       $PastaPGFN"
Info "Registro:            $($script:LOG)"
foreach ($p in 'Central_de_Automacoes', 'Automacoes', 'Automacoes\Auto_PGFN') {
  if (-not (Test-Path -LiteralPath (Join-Path $PACOTE $p))) { Erro "o pacote está incompleto: falta $p. Extraia o ZIP inteiro e rode de novo."; exit 1 }
}
if ($Destino -ieq $PACOTE) { Erro 'a pasta de instalação não pode ser a própria pasta do pacote'; exit 1 }

# ------------------------------------------------------------------ 1. requisitos
Titulo '1/7 Requisitos (Chrome, Node.js 20+, Python 3.8+)'
if (-not (Achar-Chrome)) { Instalar-Winget 'Google.Chrome' 'Google Chrome' }
if (Achar-Chrome) { Ok "Google Chrome: $(Achar-Chrome)" } else { Erro 'Google Chrome é obrigatório: instale e rode de novo'; exit 1 }
if ((Versao-Node) -lt 20) { Instalar-Winget 'OpenJS.NodeJS.LTS' 'Node.js LTS' }
if ((Versao-Node) -ge 20) { Ok "Node.js v$(Versao-Node)" } else { Erro 'Node.js 20+ não disponível: RETIRAR AUTO-INFRAÇÃO e ATM RFB não vão funcionar. Feche esta janela e rode de novo depois de instalar.' }
if (-not (Achar-Python)) { Instalar-Winget 'Python.Python.3.12' 'Python 3.12' @('--scope', 'user') }
$py = Achar-Python
if ($py) { Ok "Python $($py.Versao)" } else { Erro 'Python 3.8+ não disponível: o ATM RFB não vai funcionar' }

# ------------------------------------------------------------------ 2. Central e automações
Titulo '2/7 Copiando a Central e as automações'
New-Item -ItemType Directory -Force -Path $Destino | Out-Null
$centralDest = Join-Path $Destino 'Central_de_Automacoes'
if (Test-Path -LiteralPath (Join-Path $centralDest 'automacoes.json')) {
  $bk = Join-Path $Destino ("_backup_central_{0}" -f (Get-Date -Format 'yyyy-MM-dd_HH-mm-ss'))
  New-Item -ItemType Directory -Force -Path $bk | Out-Null
  Get-ChildItem -LiteralPath $centralDest -File | Copy-Item -Destination $bk
  Ok "Central anterior guardada em $bk"
}
Copiar-Pasta (Join-Path $PACOTE 'Central_de_Automacoes') $centralDest
Ok "Central em $centralDest"
foreach ($pasta in Get-ChildItem -LiteralPath (Join-Path $PACOTE 'Automacoes') -Directory) {
  if ($pasta.Name -eq 'Auto_PGFN') { continue }
  Copiar-Pasta $pasta.FullName (Join-Path $Destino "Automacoes\$($pasta.Name)")
  Ok "$($pasta.Name) em $Destino\Automacoes\$($pasta.Name)"
}

Titulo '3/7 Automação PGFN (precisa ficar em Downloads\Auto_PGFN)'
if (Test-Path -LiteralPath $PastaPGFN) { Aviso "a pasta já existe: os programas serão atualizados; configurações, andamento e documentos são preservados" }
# configuracoes, Documentos_arrecadacao e cnpjs.json são dados do usuário: nunca sobrescritos
Copiar-Pasta (Join-Path $PACOTE 'Automacoes\Auto_PGFN') $PastaPGFN @('configuracoes', 'Documentos_arrecadacao') @('cnpjs.json')
New-Item -ItemType Directory -Force -Path (Join-Path $PastaPGFN 'configuracoes'), (Join-Path $PastaPGFN 'Documentos_arrecadacao') | Out-Null
Ok "PGFN em $PastaPGFN"

# ------------------------------------------------------------------ 4. dependências de cada projeto
Titulo '4/7 Dependências das automações (npm e Python, isoladas em cada pasta)'
if ($PularDependenciasProjetos) { Aviso 'pulado (-PularDependenciasProjetos)' }
else {
  $ErrorActionPreference = 'Continue'
  $rai = Join-Path $Destino 'Automacoes\Retirar_Auto_Infracao'
  if ((Versao-Node) -ge 20) {
    Push-Location -LiteralPath $rai
    & npm ci --no-audit --no-fund; if ($LASTEXITCODE -ne 0) { & npm install --no-audit --no-fund }
    Pop-Location
    if (Test-Path -LiteralPath (Join-Path $rai 'node_modules\pdfjs-dist')) { Ok 'RETIRAR AUTO-INFRAÇÃO: node_modules instalado' } else { Erro 'RETIRAR AUTO-INFRAÇÃO: npm falhou (confira a internet e rode de novo)' }
  } else { Erro 'RETIRAR AUTO-INFRAÇÃO: sem Node.js 20+, dependências não instaladas' }
  # O ATM RFB tem instalador próprio: npm ci + .venv com Pillow e openpyxl
  $rfb = Join-Path $Destino 'Automacoes\ATM_RFB'
  & powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $rfb 'instalar.ps1') -SemPerguntas
  if ($LASTEXITCODE -eq 0) { Ok 'ATM RFB: node_modules e .venv (Pillow, openpyxl) prontos' } else { Erro 'ATM RFB: o instalar.ps1 dele falhou (veja a mensagem acima)' }
  $ErrorActionPreference = 'Stop'
}
Info 'As demais automações são extensões do Chrome ou programas prontos: não têm dependências para instalar.'

# ------------------------------------------------------------------ 5. Central
Titulo '5/7 Configurando a Central'
$argsCfg = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', (Join-Path $PSScriptRoot 'configurar_central.ps1'), '-Destino', $Destino, '-PastaPGFN', $PastaPGFN, '-PastaAtalho', $PastaAtalho, '-Log', $script:LOG)
if ($SemAtalho) { $argsCfg += '-SemAtalho' }
& powershell.exe @argsCfg
if ($LASTEXITCODE -ne 0) { Erro 'a configuração da Central apontou erros (veja acima)' }

# ------------------------------------------------------------------ 6. extensões do Chrome
Titulo '6/7 Extensões do Chrome (passo manual: o Chrome não deixa instalar extensões sem você)'
Info 'Em chrome://extensions: ligue "Modo do desenvolvedor", clique em "Carregar sem compactação" e escolha CADA pasta abaixo.'
Info 'Onde estiver marcado [anônimo], abra "Detalhes" da extensão e ligue "Permitir no modo anônimo".'
foreach ($a in (Catalogo $Destino $PastaPGFN)) { Info ("{0,-36} {1}{2}" -f $a.Nome, $a.Extensao, $(if ($a.Anonimo) { '   [anônimo]' } else { '' })) }
Info 'Depois, em chrome://settings/downloads, desligue "Perguntar onde salvar cada arquivo".'
if (Perguntar 'Abrir agora o chrome://extensions e a pasta das automações?') {
  try { Start-Process -FilePath (Achar-Chrome) -ArgumentList 'chrome://extensions' } catch { }
  try { Start-Process explorer.exe -ArgumentList ('"' + (Join-Path $Destino 'Automacoes') + '"') } catch { }
  Read-Host '  Carregue as extensões e tecle Enter para continuar' | Out-Null
  Start-Sleep -Seconds 3
}
if (Perguntar 'Rodar agora o instalador da PGFN (registra o ajudante do Windows; precisa da extensão Automação_PGFN já carregada)?') {
  & powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $PastaPGFN 'instalacao\instalar.ps1')
} else { Info "Quando a extensão Automação_PGFN estiver carregada, rode: $PastaPGFN\INSTALAR.bat" }

# ------------------------------------------------------------------ 7. verificação final
Titulo '7/7 Verificação final'
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot 'verificar_ambiente.ps1') -Destino $Destino -PastaPGFN $PastaPGFN -Log $script:LOG
$final = $LASTEXITCODE
try { Copy-Item -LiteralPath $script:LOG -Destination (Join-Path $Destino 'instalacao_ultima.txt') -Force } catch { }

Write-Host ''
if ($script:ERROS -or $final) { Write-Host '  Instalação terminada COM PENDÊNCIAS: veja as linhas [ERRO]/[AVISO] acima e Documentacao\Solucao_Problemas.md.' -ForegroundColor Yellow }
else {
  Write-Host '  Instalação concluída. Abra pelo atalho "Central de Automações" da Área de Trabalho.' -ForegroundColor Green
  Write-Host '  Os [AVISO] acima costumam ser só as extensões que ainda faltam carregar no Chrome (passo 6/7) e o ajudante da PGFN.'
  Write-Host '  Depois de carregá-las, confira de novo com VERIFICAR.cmd.'
}
Write-Host "  Registro completo: $($script:LOG)"
if ($script:ERROS -or $final) { exit 1 } else { exit 0 }
