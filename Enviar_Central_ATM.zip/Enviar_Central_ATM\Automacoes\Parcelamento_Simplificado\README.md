# Parcelamento Simplificado: automação do e-CAC (extensão do Chrome)

Extensão do Google Chrome que, para cada empresa de uma lista, troca o perfil de acesso do e-CAC para o CNPJ da empresa
(perfil "Procurador de pessoa jurídica"), consulta o **Parcelamento Simplificado** e guarda em PDF o resultado da
consulta ou o DARF emitido, **numa pasta para cada empresa**.

Versão: **1.8.5** (16/11/2026), com a **janela de controle** (interface), o **relatório de problemas** e o tratamento do
**aviso da Caixa Postal**: erros isolados (CNPJ inválido na lista, falha numa empresa, empresa com mensagens importantes
não lidas na Caixa Postal) não param mais a automação. Esta pasta não tem dados de nenhuma empresa:
você informa a pasta de destino e cola a lista de empresas na própria janela.

> 1.8.5 = 1.8.4 + o e-CAC abre em **janela anônima** (pela Central e pelos botões da janela da automação), para
> permitir trocar de certificado: feche todas as janelas anônimas e abra de novo. Exige "Permitir no modo anônimo"
> ligado nos Detalhes da extensão. A 1.8.4 está em `_backup_2026-11-16_v1.8.4_antes_anonima`.
>
> 1.8.4 = 1.8.3 + ao clicar em Iniciar/Continuar, as "voltas à página inicial" por causa do aviso da Caixa Postal
> recomeçam (antes, depois de "Parei: o aviso continua bloqueando", o Continuar parava de novo na hora, sem tentar). A
> 1.8.3 original está em `_backup_2026-11-16_v1.8.3_antes_ajustes`.
>
> 1.8.3 = 1.8.2 + tratamento automático do aviso "mensagens importantes não lidas na Caixa Postal" (seção 5).
>
> 1.8.2 = 1.8.1 com dois ajustes: ao clicar em Iniciar/Continuar, a contagem de "falhas seguidas" recomeça (antes, a
> nova tentativa podia parar logo na primeira empresa com problema); e o botão mostra **Continuar automação** também
> quando só restam empresas com problema. A 1.8.1 original está em `_backup_2026-11-16_v1.8.1_antes_ajustes`.

---

## 1. Como usar (resumo)

1. Na **Central de Automações**, clique em **PARCELAMENTO SIMPLIFICADO > Abrir automação**.
   O Chrome abre no e-CAC e **a janela da automação abre sozinha** (se não abrir, clique no ícone da extensão).
2. Entre no e-CAC com o certificado digital.
3. Na janela, escreva o **nome da pasta de destino** (ex.: `PARCELAMENTOS NOVEMBRO 2026`).
4. Cole as empresas, **uma por linha**, no formato `cnpj;nome_da_empresa`:
   ```
   11222333000181;EMPRESA EXEMPLO UM LTDA
   11444777000161;EMPRESA EXEMPLO DOIS SERVICOS LTDA
   ```
5. Clique em **Iniciar automação** e acompanhe pelo placar e pelas mensagens da janela (e pelo aviso azul no canto
   superior direito do e-CAC). Não mexa na aba do e-CAC enquanto ela trabalha.

### Os botões da janela

| Botão | O que faz |
|---|---|
| **Iniciar automação** (vira **Continuar automação** quando já há empresas feitas) | Salva a pasta e a lista, e começa (ou segue de onde parou). Quando só restam empresas com problema, refaz **todas** elas, uma vez cada. |
| **Parar automação** | Pede a parada **segura**: a automação termina a etapa em andamento (nunca deixa um DARF pela metade) e para. A empresa atual continua pendente, com as negociações já feitas guardadas. |
| **Limpar lista** | Apaga a lista digitada, depois de um segundo clique de confirmação. Não apaga arquivos já salvos. |
| **Abrir pasta de resultados** | Abre no Explorador a pasta do arquivo mais recente salvo (a pasta da última empresa) e mostra o caminho da pasta principal. Sem arquivos ainda, abre a pasta Downloads. |
| **Zerar andamento** | Esquece o que já foi feito **nesta pasta de destino**, para refazer todas as empresas (segundo clique confirma). Os arquivos salvos ficam. |
| **Refazer as puladas (Caixa Postal)** (aparece no relatório, quando há empresas puladas pelo aviso da Caixa Postal) | Devolve essas empresas para a fila. Use **depois de ler as mensagens** delas na Caixa Postal do e-CAC; em seguida, **Continuar automação**. |

### O que a janela mostra

Total de empresas, processadas, restantes, concluídas com sucesso, com erro e puladas por aviso da Caixa Postal; barra de progresso; empresa e CNPJ em
processamento; status (Parada, Processando, Parando, Concluída, Parada com erro); as últimas mensagens da automação; e,
quando há problemas, o **Relatório de problemas** (ver seção 5).
A janela não trava a automação: ela só mostra o que a automação grava e envia os pedidos de iniciar e parar.

---

## 2. O formato `cnpj;nome_da_empresa`

- Uma empresa por linha. O `;` separa o CNPJ do nome (o que vem do Excel, separado por TAB, também funciona).
- O CNPJ pode ter ou não pontos, barra e traço. Os zeros à esquerda são preservados. Se o Excel tirou zeros (12 ou 13
  dígitos), a janela completa e avisa, mas **só se os dígitos verificadores baterem**.
- O CNPJ precisa ter 14 dígitos e ser válido (conferência dos dois dígitos verificadores). Linhas com problema (CNPJ
  inválido, sem `;` ou sem nome) aparecem em um aviso amarelo, com o número da linha e o motivo, e **não impedem o
  início**: a automação ignora essas linhas, segue com as válidas e as lista no relatório. Corrija e rode de novo só essas.
- CNPJ repetido na lista é ignorado (vale a primeira linha).
- **Só o CNPJ é usado na consulta e na navegação.** O nome serve apenas para dar nome à pasta da empresa.
- O nome é obrigatório (é ele que dá nome à pasta). Caracteres que o Windows não aceita (`< > : " / \ | ? *`) são
  trocados (`S/A` vira `S-A`); acentos, espaços e `+` são mantidos.
- **Duas empresas com o mesmo nome** ganham o CNPJ no nome da pasta: `MESMO NOME LTDA - 11222333000181`.

---

## 3. Onde ficam os arquivos

Dentro da pasta **Downloads** do Chrome (a extensão não consegue salvar fora dela; na janela anônima também é a mesma):

```
Downloads\
└── PARCELAMENTOS NOVEMBRO 2026\                      <- o nome que você escolheu (criada sozinha)
    ├── EMPRESA EXEMPLO UM LTDA\               <- uma subpasta por empresa
    │   └── 11222333000181.pdf                        <- DARF (ou 11222333000181_1.pdf, _2.pdf... se tem várias negociações)
    ├── EMPRESA EXEMPLO DOIS SERVICOS LTDA\
    │   ├── 11444777000161_1.pdf
    │   └── 11444777000161_2.pdf
    └── EMPRESA EXEMPLO TRES\
        └── 22333444000155_2026-11-16_14-30-05.pdf    <- empresa sem negociação: print da consulta (CNPJ_data-hora.pdf)
```

- Os **nomes dos arquivos continuam os de antes** (`CNPJ.pdf`, `CNPJ_n.pdf`, `CNPJ_data-hora.pdf`).
- Todos os arquivos de uma empresa vão **só** para a pasta dela (o DARF e o print "sem negociação" ficam juntos).
- Se a pasta já existe, ela é reaproveitada, **sem apagar nada**. Se o Chrome precisar gravar um arquivo com nome já
  existente, ele cria uma cópia numerada (`CNPJ (1).pdf`) em vez de sobrescrever.
- A automação só passa para a próxima empresa depois que o Chrome confirma que o arquivo foi **salvo por inteiro**.
  Se o download for interrompido, a empresa vira "com problema" (com o motivo, no relatório) e a automação segue para a próxima.

---

## 4. Instalar a extensão no Chrome

1. Abra `chrome://extensions` e ligue o **Modo do desenvolvedor**.
2. **Carregar sem compactação** e escolha a pasta **`parcelamento_simplificado`** (a que tem o `manifest.json`).
3. Confira o cartão: `parcelamento_simplificado`, versão **1.8.5**. Em **Detalhes**, ligue (obrigatório: a Central abre o e-CAC em janela anônima)
   **Permitir no modo anônimo**.
4. Em `chrome://settings/downloads`, deixe **"Perguntar onde salvar cada arquivo"** desligado.

Ao receber uma versão nova dos arquivos: em `chrome://extensions`, clique na **setinha de recarregar** da extensão (não
remova) e aperte **F5** na aba do e-CAC.

Cuidados:
- **Só UMA cópia da extensão ligada.** Duas cópias clicam em duplicidade na mesma tela.
- O andamento fica guardado no Chrome, **por pasta de destino**. Remover a extensão ou carregá-la de outra pasta apaga o
  andamento (os arquivos salvos ficam). Para atualizar, use só a setinha de recarregar.
- Se a janela não abrir sozinha, clique no ícone da extensão (quebra-cabeça do Chrome > fixar para deixá-lo à vista).

---

## 5. O que a automação faz (inalterado)

Para cada empresa, uma por vez:

1. **Troca o perfil**: "Alterar perfil de acesso" > campo "Procurador de pessoa jurídica - CNPJ" (digita tecla a tecla)
   > "Alterar". A página recarrega.
2. Abre **Consultar informações de seus parcelamentos** e clica em **Consultar**.
3. Conforme o resultado:
   - **"Não existem negociações com os critérios informados"**: tira um print da tela e salva como PDF na pasta da
     empresa. Empresa concluída.
   - **Tabela de negociações**: lê a coluna **Situação** e, para cada negociação em `Ativo` ou
     `Requerimento em análise`, na ordem da tabela: menu **Ações > Emitir Documento de Arrecadação**; escolhe **Parcela**
     (ou **Primeira parcela**) e **Confirmar**; marca as parcelas **"A vencer" do mês atual e do mês anterior** e as
     **"Devedora"** (se não houver nenhuma, a negociação está em dia e é anotada); **Emitir DARF de parcela** >
     **Imprimir DARF**; guarda o PDF gerado pelo e-CAC na pasta da empresa.

**Nunca** clica em "Pagar DARF online" e **nunca** digita login ou senha.

### Quando algo dá errado: a automação NÃO para

Um problema isolado (uma empresa, uma linha da lista) é **registrado com o motivo** e a automação **segue para a próxima**:

| Situação | O que ela faz |
|---|---|
| Linha da lista com CNPJ inválido, sem `;` ou sem nome | Ignora a linha, avisa na janela e segue com as válidas. Vai para o relatório. |
| "Não foi possível prosseguir. Tente mais tarde (Erro N)" | Pula a empresa, marca "com problema" e segue. |
| "Não foi possível concluir a ação..." ao emitir o DARF | Tenta mais uma vez após uma pausa. Se repetir, pula só essa negociação e marca a empresa para voltar depois. |
| Tela "carregando" sem fim ou página de erro do servidor | Atualiza a página (F5) sozinha e continua de onde parou (até 4 vezes por empresa); passando disso, marca "com problema" e segue. |
| "Alterar perfil de acesso" cinza ou janela que não abre | Só clica quando o botão está utilizável; espera 45 s (90, 135, 180 s nas recargas seguintes) e atualiza a página. |
| **Aviso da Caixa Postal**: janela "Atenção: Você possui mensagens importantes (com o indicativo "!") ainda não lidas na sua Caixa Postal..." (veja abaixo) | **Nunca clica em "Ir para a Caixa Postal".** Pula a empresa dona do aviso, anota **"Pulado - Aviso de Caixa Postal"** (motivo e hora) e segue para a próxima. |
| Qualquer outra falha ou resultado desconhecido numa empresa (etapa que não deu certo, PDF não salvo por inteiro...) | Marca a empresa "com problema", com o motivo, e segue para a próxima. As negociações dela que já deram certo ficam guardadas. |
| **5 empresas seguidas** com falha desse tipo | Isso quase sempre é um problema geral (sessão do e-CAC expirada, página travada), não das empresas: **para** e avisa, para você conferir o e-CAC e clicar em **Continuar automação**. |
| Nada acontece (a página não é a tela do Parcelamento) | Mostra na tela e na janela o que fazer, em vez de ficar parada em silêncio. |

Todas as esperas têm tempo limite: a automação não fica aguardando indefinidamente.

### Aviso de mensagens importantes não lidas na Caixa Postal

Esse aviso **cobre a tela do perfil que está ativo** e bloqueia tudo, inclusive o botão "Alterar perfil de acesso" (por
isso ele ficava cinza e o F5 não resolvia: o aviso volta). A automação o procura **o tempo todo**: no início de cada
empresa, depois da troca de perfil e em toda espera. Quando aparece:

1. **De quem é o aviso?** Vale o perfil que está ativo ("Procurador de: ..." no cabeçalho do e-CAC).
   - **É da empresa em processamento** (acabou de trocar para ela): ela é **pulada**, com o estado
     **"Pulado - Aviso de Caixa Postal"** e o motivo. Não é refeita por "Continuar automação" (o aviso voltaria).
   - **É do perfil anterior** (ainda cobrindo a tela): a empresa atual não tem culpa. A automação vai para a **página
     inicial do e-CAC**, de onde dá para trocar de perfil sem ler as mensagens, e segue com ela (até 2 voltas por empresa).
2. **Se nem assim der** (o aviso bloqueia também a página inicial), a automação **para** e explica o que fazer (trocar o
   perfil à mão ou ler as mensagens daquele perfil e clicar em **Continuar automação**). Não fica esperando para sempre.
3. No **relatório** (janela e arquivo `.txt`) há uma seção **"Pulada - Aviso de Caixa Postal"** com todos os CNPJs pulados.
   Depois de ler as mensagens na Caixa Postal do e-CAC, use **Refazer as puladas (Caixa Postal)** e **Continuar automação**.

### Relatório de problemas

- **Ao vivo**, na janela, seção "Relatório de problemas": cada empresa com problema (CNPJ, nome e motivo) e cada linha da
  lista ignorada.
- **Ao terminar** (ou ao parar por falhas seguidas), a automação escreve o relatório nas mensagens da janela e, havendo
  problemas, salva `RELATORIO_PROBLEMAS_<data-hora>.txt` na pasta principal (nunca sobrescreve um relatório anterior). O
  botão **Salvar relatório (.txt)** da janela salva um relatório a qualquer momento.
- Para refazer as empresas com problema: **Continuar automação**. Quando só restam elas, a automação tenta cada uma
  mais uma vez, em sequência.

---

## 6. Estrutura e como funciona por dentro

```
ATM_simplicado_1/
├── README.md                          Este documento
├── _backup_2026-11-16_antes_interface/   Cópia da versão 1.7.8 (sem a janela), feita antes desta mudança
└── parcelamento_simplificado/         A extensão (é esta pasta que o Chrome carrega)
    ├── manifest.json                  Versão, permissões, onde cada script roda
    ├── interface.html / .css / .js    A janela de controle (pasta, lista, botões, andamento)
    ├── lista_parser.js                Leitura e validação de "cnpj;nome" e dos nomes de pasta (funções puras)
    ├── lista_cnpjs.js                 Configurações fixas (situações aceitas, devedoras); e o modo antigo, se quiser
    ├── content.js                     Todo o fluxo da automação (roda dentro das páginas do e-CAC)
    └── background.js                  Abre a janela, salva os PDFs e faz a ponte entre as partes da página
```

- A janela grava a configuração em `chrome.storage.local` (`ps_config`: pasta e empresas; `ps_comando`: iniciar/parar).
  O `content.js` lê isso e **preenche as mesmas variáveis que o código já usava** (`LISTA_CNPJS`, `ID_LOTE`...), então a
  consulta, a navegação e os tratamentos de erro não mudaram. Ele devolve o andamento em `ps_status` (empresa, estado,
  mensagens), que a janela mostra na hora.
- O andamento por empresa fica em `parcelamento_simplificado_fila:interface:<pasta>`: pastas diferentes têm andamentos
  separados, e repetir a mesma pasta continua de onde parou.
- **Parar** só vale entre duas negociações ou duas empresas, para nunca deixar um DARF pela metade.
- A Central de Automações abre o e-CAC com `#ps_abrir_interface` no endereço (o que vem depois do `#` não é enviado à
  Receita); a extensão vê esse marcador e abre a janela. Abrir o e-CAC sem o marcador (como a Central faz com as outras
  automações) não abre a janela.
- `background.js`: abre a janela, captura a tela da aba e a transforma em PDF, renomeia/salva o PDF do DARF na pasta
  da empresa e só aceita pastas dentro de Downloads (sem `..`, sem caminho absoluto, sem caracteres que o Windows recusa).
- O conteúdo do Parcelamento fica num **iframe de outro subdomínio** do e-CAC; por isso o `content.js` roda em todos os
  quadros e a janela principal conversa com o quadro pelo `background.js`.
- Permissões: `downloads`, `storage`, `webNavigation` (só para abrir a janela quando a Central abre o e-CAC), acesso ao
  e-CAC e `<all_urls>` (exigido pelo Chrome para capturar a imagem da aba). Nenhum dado sai do computador.

### Modo antigo (sem a janela)

Em `lista_cnpjs.js`, `MODO_INTERFACE = false` volta ao funcionamento anterior: lista, `ID_LOTE` e pastas definidos no
arquivo, início automático ao abrir o Parcelamento e clique no ícone para iniciar... exceto que o ícone agora abre a janela.

---

## 7. Limitações e cuidados

- Depende dos textos e da estrutura das telas do e-CAC. Se a Receita mudar as telas, a busca por texto precisa de ajuste.
- A aba do e-CAC precisa estar em primeiro plano (e a janela do Chrome não pode estar minimizada) durante a captura.
- O PDF "sem negociação" é uma imagem da tela. O PDF do DARF é o do próprio e-CAC.
- "Abrir pasta de resultados" abre a pasta do último arquivo salvo: o Chrome não permite à extensão abrir uma pasta
  qualquer. O caminho da pasta principal aparece na janela.
- Uso apenas para as empresas em que você tem procuração/autorização de acesso no e-CAC.
- Testado: leitura da lista (24 casos), o fluxo de pastas/parar/continuar/falha de PDF com as telas do e-CAC
  **simuladas** (28 verificações), o tratamento de erros isolados, relatório, nova tentativa e parada por falhas seguidas
  (20 verificações, também simuladas), a janela (linhas inválidas não bloqueiam, relatório, salvar .txt), e a extensão
  carregada num Chrome 157 de teste (abre a janela pelo marcador, não abre sem ele, o `content.js` carrega sem erro,
  iniciar e parar respondem). O aviso da Caixa Postal foi testado com a tela simulada (18 verificações: pular, voltar à
  página inicial, parar se o aviso bloquear até lá, nunca clicar no botão) e num Chrome de teste com o aviso injetado na
  página do e-CAC (detectado na hora, vai para a página inicial, sem clicar). **Ainda não foi visto no e-CAC real:** a
  emissão de DARF, o salvamento dos PDFs nas novas pastas por empresa e, principalmente, **se a página inicial do e-CAC
  deixa trocar de perfil com o aviso ativo** (é o que a volta à página inicial supõe; se não deixar, a automação para e
  avisa).

---

## 8. Manutenção

- Verificação de sintaxe (precisa do Node): `node --check content.js` (e o mesmo para `background.js`, `interface.js`,
  `lista_parser.js`, `lista_cnpjs.js`).
- Ao mudar o código, suba a versão no `manifest.json` para conferir em `chrome://extensions` que recarregou.
- Versão anterior (1.7.8, sem a janela): pasta `_backup_2026-11-16_antes_interface`.
