// Janela da automação (interface.html). Só mostra o estado e envia pedidos ao background.js;
// quem processa é a página do TST (content.js) e quem salva os PDFs é o background.js.
// O estado vem do chrome.storage (atualizado ao vivo); o texto digitado fica salvo como rascunho.

(function () {
  'use strict';
  const LISTA = globalThis.CNDT.LISTA;
  const $ = (id) => document.getElementById(id);
  const K = { config: 'cndt_config', controle: 'cndt_controle', log: 'cndt_log', rascunho: 'cndt_rascunho' };
  const ESTADOS = {
    parada: 'Parada', processando: 'Processando', pausando: 'Pausando após a empresa atual',
    pausada: 'Pausada', concluida: 'Concluída',
  };

  let estado = { config: null, controle: { estado: 'parada' }, log: [], andamento: {} };

  // ---------------- conversa com o background ----------------
  async function pedir(tipo, dados) {
    try {
      const r = await chrome.runtime.sendMessage({ tipo, dados });
      return r || { ok: false, erro: 'sem resposta' };
    } catch (e) {
      return { ok: false, erro: e.message };
    }
  }
  function mensagem(texto, tipo = '') {
    $('msg').textContent = texto;
    $('msg').className = `msg ${tipo}`;
  }

  // ---------------- leitura da lista (ao vivo) ----------------
  function lerFormulario() {
    const pasta = LISTA.limparPastaPrincipal($('pasta').value);
    const lida = LISTA.lerLista($('lista').value);
    return { pasta, lida };
  }

  function mostrarLeitura() {
    const { pasta, lida } = lerFormulario();
    const n = lida.itens.length;
    const partes = [];
    partes.push(n ? `<span class="bom">${n} empresa${n > 1 ? 's' : ''} válida${n > 1 ? 's' : ''}</span>` : '<span>Nenhuma empresa válida ainda.</span>');
    if (lida.rejeitadas.length) partes.push(`<span class="ruim">${lida.rejeitadas.length} linha${lida.rejeitadas.length > 1 ? 's' : ''} com problema</span>`);
    if (lida.repetidos) partes.push(`${lida.repetidos} CNPJ repetido${lida.repetidos > 1 ? 's' : ''} ignorado${lida.repetidos > 1 ? 's' : ''}`);
    if (lida.ajustados) partes.push(`${lida.ajustados} CNPJ com zeros à esquerda completados`);
    const iguais = lida.itens.filter((i) => i.diferenciada).length;
    if (iguais) partes.push(`${iguais} empresas com nomes iguais: o CNPJ entra no nome da pasta`);
    $('contagem').innerHTML = partes.join(' · ');

    $('ignoradas').hidden = !lida.erros.length;
    $('erros').replaceChildren(...lida.erros.slice(0, 200).map((t) => Object.assign(document.createElement('li'), { textContent: t })));

    const ex = lida.itens[0];
    const caminho = $('caminhoPrevisto');
    caminho.replaceChildren();
    if (!pasta) { caminho.textContent = 'Informe o nome da pasta.'; return; }
    caminho.append('Downloads\\');
    caminho.append(Object.assign(document.createElement('b'), { textContent: pasta.replace(/\//g, '\\') }));
    caminho.append(ex ? `\\${ex.pasta}\\${ex.arquivo}` : '\\<empresa>\\CNDT_<empresa>.pdf');
  }

  let timerRascunho = null;
  function guardarRascunho() {
    clearTimeout(timerRascunho);
    timerRascunho = setTimeout(() => chrome.storage.local.set({ [K.rascunho]: { pasta: $('pasta').value, texto: $('lista').value } }), 400);
  }

  // ---------------- andamento ----------------
  function itensAtuais() { return (estado.config && estado.config.itens) || []; }

  function render() {
    const c = estado.controle || { estado: 'parada' };
    const e = c.estado || 'parada';
    const itens = itensAtuais();
    const r = LISTA.resumo(itens, estado.andamento);

    // botões
    const rodando = e === 'processando' || e === 'pausando';
    $('btnIniciar').disabled = rodando || e === 'pausada';
    $('btnIniciar').textContent = r.concluidas && r.pendentes ? '▶ Continuar a lista (Iniciar)' : '▶ Iniciar automação';
    $('btnPausar').disabled = e !== 'processando';
    $('btnContinuar').disabled = !(e === 'pausada' || e === 'pausando' || (e === 'parada' && itens.length && r.pendentes));
    $('btnContinuar').textContent = e === 'pausando' ? '▶ Não pausar' : '▶ Continuar';
    $('btnParar').disabled = !(rodando || e === 'pausada');
    $('btnRelatorio').disabled = !itens.length;
    $('btnZerar').disabled = rodando;
    $('pasta').disabled = rodando || e === 'pausada';
    $('lista').disabled = rodando || e === 'pausada';

    // placar
    $('nTotal').textContent = r.total;
    $('nOk').textContent = r.concluidas;
    $('nPendentes').textContent = r.pendentes;
    $('nErros').textContent = r.erros;
    const feitas = r.concluidas + r.erros;
    const pct = r.total ? Math.round((feitas / r.total) * 100) : 0;
    $('barra').style.width = `${pct}%`;
    $('barraGeral').setAttribute('aria-valuenow', String(pct));
    $('legendaBarra').textContent = r.total
      ? `${feitas} de ${r.total} processadas (${pct}%)${estado.config ? ` · pasta Downloads\\${estado.config.pasta.replace(/\//g, '\\')}` : ''}`
      : 'Nenhuma empresa informada.';

    // status e empresa atual
    $('selo').textContent = ESTADOS[e] || e;
    $('selo').className = `selo ${e}`;
    const atual = c.atual && itens.find((i) => i.cnpj === c.atual);
    $('empresaAtual').textContent = atual ? atual.nome : '—';
    $('cnpjAtual').textContent = atual ? atual.formatado : '—';
    $('arquivoAtual').textContent = atual && estado.config ? `${estado.config.pasta}/${atual.pasta}/${atual.arquivo}`.replace(/\//g, '\\') : '—';
    $('caminhoBase').textContent = c.caminhoBase ? `Pasta principal no disco: ${c.caminhoBase}` : '';

    // log
    const log = estado.log || [];
    const lista = $('log');
    const noFim = lista.scrollTop + lista.clientHeight >= lista.scrollHeight - 20;
    if (!log.length) {
      lista.replaceChildren(Object.assign(document.createElement('li'), { className: 'vazio', textContent: 'As mensagens aparecem aqui quando a automação começar.' }));
    } else {
      lista.replaceChildren(...log.slice(-150).map((m) => {
        const li = document.createElement('li');
        li.className = m.tipo === 'erro' ? 'erro' : m.tipo === 'ok' ? 'ok' : '';
        const t = document.createElement('time');
        t.textContent = new Date(m.t).toLocaleTimeString('pt-BR');
        li.append(t, m.texto);
        return li;
      }));
      if (noFim) lista.scrollTop = lista.scrollHeight;
    }

    // empresas com erro
    const comErro = itens.filter((i) => estado.andamento[i.cnpj] && estado.andamento[i.cnpj].estado === 'erro');
    $('blocoErros').hidden = !comErro.length;
    $('problemas').replaceChildren(...comErro.map((i) => {
      const li = document.createElement('li');
      li.append(Object.assign(document.createElement('b'), { textContent: `${i.formatado} - ${i.nome}` }),
        Object.assign(document.createElement('span'), { textContent: estado.andamento[i.cnpj].detalhe || 'erro' }));
      return li;
    }));
  }

  async function carregar() {
    const dados = await chrome.storage.local.get([K.config, K.controle, K.log, K.rascunho]);
    estado.config = dados[K.config] || null;
    estado.controle = dados[K.controle] || { estado: 'parada' };
    estado.log = dados[K.log] || [];
    estado.andamento = estado.config ? ((await chrome.storage.local.get(`cndt_andamento:${estado.config.pasta}`))[`cndt_andamento:${estado.config.pasta}`] || {}) : {};
    return dados[K.rascunho];
  }

  chrome.storage.onChanged.addListener(async (mud, area) => {
    if (area !== 'local') return;
    if (Object.keys(mud).some((k) => k === K.config || k === K.controle || k === K.log || k.startsWith('cndt_andamento:'))) {
      await carregar();
      render();
    }
  });

  // ---------------- botões ----------------
  // Ações perigosas pedem um segundo clique em 4 s.
  function comConfirmacao(botao, textoConfirmar, acao) {
    let armado = null;
    const original = botao.textContent;
    botao.addEventListener('click', () => {
      if (!armado) {
        botao.textContent = textoConfirmar;
        botao.classList.add('confirmar');
        armado = setTimeout(() => { armado = null; botao.textContent = original; botao.classList.remove('confirmar'); }, 4000);
        return;
      }
      clearTimeout(armado);
      armado = null;
      botao.textContent = original;
      botao.classList.remove('confirmar');
      acao();
    });
  }

  $('btnIniciar').addEventListener('click', async () => {
    const { pasta, lida } = lerFormulario();
    if (!pasta) { mensagem('Informe o nome da pasta principal.', 'erro'); $('pasta').focus(); return; }
    if (!lida.itens.length) { mensagem('A lista não tem nenhuma empresa válida.', 'erro'); $('lista').focus(); return; }
    mensagem('Iniciando...');
    const r = await pedir('cndt:iniciar', { pasta: $('pasta').value, texto: $('lista').value });
    mensagem(r.ok ? 'Automação iniciada: a página do TST foi aberta. Digite a verificação quando o CNPJ estiver preenchido.' : `Não iniciei: ${r.erro}.`, r.ok ? 'ok' : 'erro');
  });
  $('btnPausar').addEventListener('click', async () => {
    const r = await pedir('cndt:pausar');
    mensagem(r.ok ? 'Pausa pedida: a empresa em andamento termina e a automação pausa.' : r.erro, r.ok ? '' : 'erro');
  });
  $('btnContinuar').addEventListener('click', async () => {
    const r = await pedir('cndt:continuar');
    mensagem(r.ok ? 'Continuando.' : r.erro, r.ok ? 'ok' : 'erro');
  });
  comConfirmacao($('btnParar'), 'Clique de novo para parar', async () => {
    const r = await pedir('cndt:parar');
    mensagem(r.ok ? 'Automação parada. A empresa em andamento continua pendente.' : r.erro, r.ok ? '' : 'erro');
  });
  comConfirmacao($('btnZerar'), 'Clique de novo para zerar', async () => {
    const r = await pedir('cndt:zerar');
    mensagem(r.ok ? 'Andamento zerado. Os arquivos já salvos continuam na pasta.' : r.erro, r.ok ? '' : 'erro');
  });
  $('btnPasta').addEventListener('click', async () => {
    const r = await pedir('cndt:abrir-pasta');
    if (!r.ok) mensagem(r.erro, 'erro');
    else if (r.semArquivos) mensagem('Ainda não há certidão salva: abri a pasta de downloads do Chrome. A pasta principal é criada quando a primeira certidão for salva.');
    else mensagem('Abri a pasta da última certidão salva.', 'ok');
  });
  $('btnLocal').addEventListener('click', () => pedir('cndt:alterar-local'));
  $('btnRelatorio').addEventListener('click', async () => {
    const r = await pedir('cndt:salvar-relatorio');
    mensagem(r.ok ? 'Relatório salvo na pasta principal.' : `Não salvei o relatório: ${r.erro}`, r.ok ? 'ok' : 'erro');
  });
  $('btnLimparLog').addEventListener('click', () => pedir('cndt:limpar-log'));

  $('pasta').addEventListener('input', () => { mostrarLeitura(); guardarRascunho(); });
  $('lista').addEventListener('input', () => { mostrarLeitura(); guardarRascunho(); });

  // ---------------- início ----------------
  $('versao').textContent = `v${chrome.runtime.getManifest().version}`;
  carregar().then((rascunho) => {
    $('pasta').value = (rascunho && rascunho.pasta) || (estado.config && estado.config.pasta) || '';
    $('lista').value = (rascunho && rascunho.texto) || '';
    mostrarLeitura();
    render();
  });
})();
