# Central de Automações — pacote de transferência e instalação completa

> **Para o Claude que recebeu esta pasta:** este documento é autossuficiente. Você não precisa do histórico da conversa
> em que o pacote foi montado. Leia-o inteiro antes de executar qualquer coisa e siga a seção
> **[INSTRUÇÕES PARA O CLAUDE NO COMPUTADOR DE DESTINO](#instruções-para-o-claude-no-computador-de-destino)**.

Pacote montado em **17/11/2026** a partir das cópias **ativas** (as que a Central usava) da máquina de origem.
Os projetos originais não foram alterados: tudo aqui é cópia.

---

## 1. O que é a Central de Automações

A **Central de Automações** é um programa de janela do Windows (PowerShell + Windows Forms, sem instalar nada) que
mostra um **cartão para cada automação** do escritório. Cada cartão tem:

- **Abrir automação**: inicia a automação pelo **mesmo ponto de entrada** usado ao abri-la sozinha (o mesmo `.cmd`,
  `.exe` ou site), na pasta do projeto. A Central não altera nada nas automações: só as inicia.
- **?**: ajuda (resumo ao passar o mouse; instruções completas num painel à direita).
- **Situação**: confere se a pasta existe, se o Chrome e o Node.js estão instalados e se a extensão do Chrome daquela
  automação está carregada e ligada.

Também tem **busca** (com ou sem acentos), **filtros por categoria**, **tema Claro/Escuro** (salvo em
`preferencias.json`), suporte a DPI/ClearType e atalhos de teclado. Ela evita abrir a mesma automação duas vezes por
cliques repetidos e registra falhas em `central_erros.log`.

Arquivos da Central (pasta `Central_de_Automacoes\`):

| Arquivo | Função |
|---|---|
| `Central.ps1` | o programa (≈1.100 linhas). Modos: janela (padrão), `-Validar`, `-Abrir "<nome>"`, `-TesteJanela <pasta>` |
| `Abrir Central.vbs` | abre a Central sem mostrar a janela do PowerShell (é o alvo do atalho da Área de Trabalho) |
| `automacoes.json` | **a lista de automações** (nome, categoria, ícone, tipo, ponto de entrada, pasta, extensão, dica) |
| `ajuda.json` | os textos do botão **?** de cada automação (resumo, preparar, passos, resultado, arquivos, fonte) |
| `LEIA-ME.txt` / `README.md` | documentação da Central |

### Como a Central inicia cada automação (`tipo` em `automacoes.json`)

| tipo | O que a Central faz |
|---|---|
| `terminal` | `cmd.exe /c "<arquivo>.cmd"` numa janela de comando visível, na pasta do projeto (as interfaces Node.js precisam da janela aberta) |
| `janela` | inicia o `.exe` diretamente |
| `chrome` | abre o Chrome no `url` (com `--incognito` se `"anonima": true`). Se houver `"painel"`, procura o ID da extensão nas preferências do Chrome e abre `chrome-extension://<ID>/<painel>` |

### Caminhos portáteis

Nesta versão do pacote a Central **não usa caminhos absolutos**. Em `automacoes.json` e `ajuda.json`:

- `%CENTRAL_ATM%` = a **pasta de instalação** (a pasta que contém `Central_de_Automacoes` e `Automacoes`). A Central
  calcula isso sozinha a partir da própria localização (`Split-Path $PSScriptRoot -Parent`).
- `%USERPROFILE%` e outras variáveis do Windows são resolvidas normalmente.
- **Exceção:** a **PGFN** precisa ficar em `%USERPROFILE%\Downloads\Auto_PGFN` (exigência do próprio projeto: o ajudante
  do Windows só confirma a janela "Salvar como" dentro dessa pasta, e o instalador dela recusa outra pasta).

Esta é a **única alteração de código** feita na Central para o pacote (função `Expandir` em `Central.ps1`); o resto é
idêntico ao original.

---

## 2. Finalidade do pacote

Levar a Central e **todas as automações cadastradas nela** para outro computador Windows, com:

- uma pasta por automação, com tudo o que ela precisa para funcionar;
- scripts que instalam e conferem tudo (`INSTALAR.cmd`, `VERIFICAR.cmd`);
- documentação para uma pessoa ou para outra instância do Claude terminar a instalação.

**Não vão no pacote** (de propósito): certificados digitais, senhas, PINs, tokens, cookies, perfis do Chrome, listas
de CNPJs de clientes, andamentos, relatórios e PDFs gerados, `node_modules`, `.venv`, backups e registros (logs).

---

## 3. Automações incluídas (6, todas as cadastradas na Central)

| # | Nome na Central | Pasta no pacote | Tecnologia | Ponto de entrada |
|---|---|---|---|---|
| 1 | RETIRAR AUTO-INFRAÇÃO | `Automacoes\Retirar_Auto_Infracao` | Node.js 20+ (interface web local) + extensão Chrome | `ABRIR_INTERFACE.cmd` |
| 2 | CERTIDÃO RECEITA FEDERAL (ATM RFB) | `Automacoes\ATM_RFB` | Node.js 18+ + Python 3 (.venv) + extensão Chrome | `INTERFACE RFB EMISSAO.cmd` |
| 3 | PGFN – DOCUMENTOS DE ARRECADAÇÃO | `Automacoes\Auto_PGFN` → instala em `Downloads\Auto_PGFN` | .exe (C#/.NET 4) + PowerShell + extensão Chrome + native messaging | `Automacao_PGFN.exe` |
| 4 | SITUAÇÃO FISCAL | `Automacoes\Situacao_Fiscal` | extensão Chrome | Chrome no e-CAC + ícone da extensão |
| 5 | PARCELAMENTO SIMPLIFICADO | `Automacoes\Parcelamento_Simplificado` | extensão Chrome | Chrome **anônimo** no e-CAC (a janela da extensão abre sozinha) |
| 6 | REGULARIDADE FISCAL PE (E-FISCO) | `Automacoes\Regularidade_Fiscal_PE` | extensão Chrome | painel da extensão |

Detalhes de cada uma (versões, dependências, arquivos de dados, portas): **`Documentacao\Inventario_Automacoes.md`**.

### Como cada automação funciona (resumo)

1. **RETIRAR AUTO-INFRAÇÃO** — Certidão de Débitos Trabalhistas (MTE) em lote. `ABRIR_INTERFACE.cmd` sobe um servidor
   Node.js local (interface em `http://127.0.0.1:47331`, com token) e abre o navegador. Para cada CPF/CNPJ, abre o site
   do MTE no Chrome; a extensão `extensao-chrome` (fala com o assistente pela porta **47321**) preenche o documento e
   baixa o PDF; o assistente confere se o documento dentro do PDF bate e salva como `<CNPJ>;<NOME>.pdf` em
   `Downloads\<NOME DA PASTA>` (opcional; padrão `Downloads\Lote_...`). Se a interface já estiver aberta, a segunda
   janela sai com código 10 e só reabre o navegador.
2. **ATM RFB** — Certidão de Débitos Relativos a Créditos Tributários Federais e à Dívida Ativa da União (Receita
   Federal). `INTERFACE RFB EMISSAO.cmd` (instala o que faltar na primeira vez) sobe `interface\servidor.js` (porta
   **47330**). A extensão `Automacao_RFB` intercepta o PDF; o script confere o CNPJ dentro dele e organiza em
   `Downloads\<pasta do lote>\<CNPJ>\`. Usa Python (Pillow, openpyxl) para lotes e planilhas.
3. **PGFN** — entra no e-CAC com o certificado digital, troca o perfil para cada CNPJ, abre Regularize/SISPAR, emite os
   documentos de arrecadação das negociações "DEFERIDA E CONSOLIDADA" e salva em
   `Downloads\Auto_PGFN\Documentos_arrecadacao\<CERTIFICADO>\<CNPJ>\`. **Fecha todas as janelas do Chrome a cada CNPJ**
   e usa janela anônima. Tem interface própria (`Automacao_PGFN.exe`), orquestrador PowerShell e um **ajudante do
   Windows** registrado como *native messaging host* do Chrome (`com.auto_pgfn.salvar_como`, em `HKCU`).
4. **SITUAÇÃO FISCAL** — no e-CAC (Minhas Dívidas e Pendências), representa cada CNPJ como Procurador, lê o resultado
   e baixa certidão e relatório em `Downloads\<pasta>\<empresa>\`. Tudo pela extensão (popup).
5. **PARCELAMENTO SIMPLIFICADO** — no e-CAC, para cada `cnpj;nome`, troca o perfil, consulta o Parcelamento
   Simplificado e salva em PDF a consulta (sem negociação) ou o DARF emitido em `Downloads\<pasta>\<empresa>\`.
   Abre em **janela anônima** (permite trocar de certificado fechando todas as janelas anônimas). Continua de onde
   parou se usar o mesmo nome de pasta (andamento em `chrome.storage`).
6. **REGULARIDADE FISCAL PE** — e-Fisco SEFAZ-PE, sem login: certidão estadual para CPF, CNPJ ou IE, um por vez, em
   janela anônima, salvando em `Downloads\<pasta>\`. **Nunca resolve CAPTCHA**: pausa e espera a pessoa.

---

## 4. Tecnologias e dependências

| Componente | Quem usa | Versão | Como é instalado |
|---|---|---|---|
| Windows 10/11 + PowerShell 5.1 | todas | já vem no Windows | — |
| Google Chrome | todas | atual | `winget install Google.Chrome` |
| Node.js + npm | Retirar (≥ 20), ATM RFB (≥ 18) | LTS (testado com v26) | `winget install OpenJS.NodeJS.LTS` |
| `pdfjs-dist` 4.10.38 (+ `@napi-rs/canvas`) | Retirar, ATM RFB | travado no `package-lock.json` | `npm ci` **dentro da pasta de cada projeto** (isolado) |
| Python 3.8+ | ATM RFB | testado com 3.15 | `winget install Python.Python.3.12 --scope user` |
| Pillow, openpyxl | ATM RFB | `requirements.txt` | `.venv` própria em `ATM_RFB\.venv` (isolada) |
| .NET Framework 4 (`csc.exe`) | PGFN | já vem no Windows | só se `Automacao_PGFN.exe` precisar ser recompilado (`interface\compilar.bat`) |

Nada é instalado globalmente além de Chrome/Node/Python (e só se faltarem). Nenhuma configuração do Windows é alterada,
exceto: o atalho na Área de Trabalho e a chave `HKCU\Software\Google\Chrome\NativeMessagingHosts\com.auto_pgfn.salvar_como`
(registrada pelo instalador da própria PGFN, no usuário atual).

---

## 5. Extensões do Chrome

O Chrome **não permite** instalar extensões fora da loja por script. Cada extensão é carregada **uma vez, à mão**:

1. Abra `chrome://extensions` e ligue **Modo do desenvolvedor** (canto superior direito).
2. Clique em **Carregar sem compactação** e escolha a pasta da extensão (tabela abaixo, já na pasta de instalação).
3. Nas marcadas com **anônimo**: **Detalhes** → ligue **Permitir no modo anônimo**.
4. Em `chrome://settings/downloads`, desligue **Perguntar onde salvar cada arquivo**.

| Automação | Pasta da extensão (após instalar em `%USERPROFILE%\Central_ATM`) | Anônimo |
|---|---|---|
| Retirar Auto-Infração | `Central_ATM\Automacoes\Retirar_Auto_Infracao\extensao-chrome` | não |
| ATM RFB | `Central_ATM\Automacoes\ATM_RFB\extensao-chrome` | **sim** |
| PGFN | `Downloads\Auto_PGFN\Automação_PGFN` | **sim** |
| Situação Fiscal | `Central_ATM\Automacoes\Situacao_Fiscal\Situacao_Fiscal` | não |
| Parcelamento Simplificado | `Central_ATM\Automacoes\Parcelamento_Simplificado\parcelamento_simplificado` | **sim** |
| Regularidade Fiscal PE | `Central_ATM\Automacoes\Regularidade_Fiscal_PE\regularidade_fiscal_pe` | **sim** |

Importante:
- Carregue as extensões **a partir da pasta de instalação**, não da pasta do pacote: se a pasta mudar depois, o Chrome
  perde a extensão (e o andamento guardado nela).
- **Uma cópia de cada** extensão ligada. Duas cópias da mesma extensão disputam a página.
- Depois de atualizar arquivos de uma extensão, clique em **Recarregar** (seta) nela. **Não remova**: remover apaga o
  andamento guardado no Chrome.
- A PGFN precisa, **depois** de carregar a extensão, rodar `Downloads\Auto_PGFN\INSTALAR.bat` (registra o ajudante com
  o ID da extensão e testa).

---

## 6. Certificados digitais e credenciais (sem expor nada)

- **Nenhuma** automação guarda senha, PIN ou chave privada, e o pacote não contém nenhuma.
- As automações do e-CAC (PGFN, Situação Fiscal, Parcelamento Simplificado) usam o **certificado digital instalado no
  Windows** (repositório do usuário: `certmgr.msc` → Pessoal). Instale o certificado A1 (.pfx) com dois cliques no
  arquivo, **no computador de destino, pela própria pessoa**; para A3 (token/cartão), instale o driver do fabricante.
- O login no e-CAC é feito **pela pessoa**, escolhendo o certificado na janela do Chrome. A PGFN só escolhe pelo
  **nome** do certificado (configurado na interface dela) e nunca digita PIN.
- **Claude: não peça, não digite e não copie** senha, PIN ou arquivo .pfx. Oriente a pessoa a fazer essa parte.
- Listas de CNPJs: cada automação recebe a lista na própria interface (colar). Modelos sem dados reais:
  `Retirar_Auto_Infracao\COLE_OS_CNPJS_AQUI.txt`, `ATM_RFB\lista_cnpjs.exemplo.txt`,
  `Auto_PGFN\instalacao\cnpjs.exemplo.json`.

---

## 7. Instalação

### 7.1 Caminho rápido (pessoa)

1. Copie a pasta `Enviar_Central_ATM` (ou extraia `Enviar_Central_ATM.zip`) para o computador novo, por exemplo na
   Área de Trabalho.
2. Dois cliques em **`INSTALAR.cmd`**. Ele:
   1. confere Chrome, Node.js 20+ e Python 3.8+ e oferece instalar o que faltar pelo **winget** (fontes oficiais);
   2. copia a Central e as automações para **`%USERPROFILE%\Central_ATM`** (e a PGFN para `Downloads\Auto_PGFN`);
   3. instala as dependências **dentro de cada projeto** (`npm ci`; `.venv` do ATM RFB);
   4. configura a Central, libera os arquivos (Unblock-File) e cria o atalho **Central de Automações**;
   5. mostra as pastas das extensões, abre `chrome://extensions` e espera você carregá-las;
   6. oferece rodar o instalador da PGFN (ajudante do Windows);
   7. roda a verificação final e grava o registro em `Instalacao\logs\` e `Central_ATM\instalacao_ultima.txt`.
3. Carregue as extensões (seção 5) se ainda não carregou e rode **`VERIFICAR.cmd`**.

Pode rodar `INSTALAR.cmd` de novo a qualquer momento: atualiza os programas e **preserva** preferências, andamentos,
configurações e documentos (a Central anterior é guardada em `Central_ATM\_backup_central_<data>`).

### 7.2 Opções (PowerShell)

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Instalacao\instalar.ps1 `
  [-Destino <pasta>] [-InstalarDependencias] [-SemPerguntas] [-SemAtalho] [-PularDependenciasProjetos]
powershell -NoProfile -ExecutionPolicy Bypass -File .\Instalacao\verificar_ambiente.ps1 [-Destino <pasta>] [-SoRequisitos]
powershell -NoProfile -ExecutionPolicy Bypass -File .\Instalacao\configurar_central.ps1 [-Destino <pasta>] [-SemAtalho]
```

- `-InstalarDependencias`: instala pelo winget sem perguntar. `-SemPerguntas`: não pergunta nada (útil para o Claude;
  aí os passos interativos — extensões e instalador da PGFN — ficam como instrução no final).
- `-PastaPGFN` e `-PastaAtalho` existem **só para testes** (a PGFN real precisa ficar em `Downloads\Auto_PGFN`).
- Saída `0` = sem erros; `1` = há linhas `[ERRO]`. `[AVISO]` não impede o uso.

### 7.3 Estrutura depois de instalar

```
%USERPROFILE%\Central_ATM\
  Central_de_Automacoes\        Central.ps1, Abrir Central.vbs, automacoes.json, ajuda.json, preferencias.json (criado)
  Automacoes\
    Retirar_Auto_Infracao\      + node_modules (npm ci)
    ATM_RFB\                    + node_modules, .venv
    Situacao_Fiscal\
    Parcelamento_Simplificado\
    Regularidade_Fiscal_PE\
  instalacao_ultima.txt
%USERPROFILE%\Downloads\Auto_PGFN\   (PGFN: lugar obrigatório)
Área de Trabalho\Central de Automações.lnk  →  wscript.exe "...\Central_de_Automacoes\Abrir Central.vbs"
```

---

## 8. Testar o funcionamento

Sem rodar nenhuma automação real:

1. `VERIFICAR.cmd` — deve terminar com **nenhum erro**. Avisos esperados até carregar as extensões.
2. `powershell -NoProfile -ExecutionPolicy Bypass -File "%USERPROFILE%\Central_ATM\Central_de_Automacoes\Central.ps1" -Validar`
   — lista as 6 automações com `pronto : sim`.
3. Autoteste da janela (não inicia nenhuma automação; gera capturas e `resultado.txt`):
   `... -STA -File "...\Central.ps1" -TesteJanela "%TEMP%\teste_central"` — confira `resultado.txt`: 6 botões "?",
   busca, filtros (PGFN, Receita Federal, SEFAZ-PE, Trabalhista), temas e "automacoes iniciadas=0".
4. Testes automáticos dos projetos (não acessam os sites):
   - `cd %USERPROFILE%\Central_ATM\Automacoes\Retirar_Auto_Infracao` → `npm test` (45 testes);
   - `node %USERPROFILE%\Central_ATM\Automacoes\Regularidade_Fiscal_PE\regularidade_fiscal_pe\testes\unit.js`
     (e `fila.test.js`, `background.test.js`).
5. Abra a Central pelo atalho e clique em **Abrir automação** de cada cartão: confirme que a janela/site certo abre.
   Feche sem iniciar lotes.
6. Primeiro uso real: **um ou dois CNPJs** por automação, com a pessoa acompanhando (certificado, CAPTCHA, e-CAC).

---

## 9. Organização de pastas e downloads

- Todas as automações salvam **dentro da pasta Downloads do Chrome**, numa pasta com o nome que a pessoa digitar
  (Chrome só grava dentro de Downloads). Não mude a pasta de downloads do Chrome.
- Nada é sobrescrito: arquivos repetidos ganham `(1)`, `(2)`, ` (2)` etc.
- PGFN: sempre em `Downloads\Auto_PGFN\Documentos_arrecadacao\<CERTIFICADO>\<CNPJ>\`.
- Não guarde resultados dentro de `Central_ATM` nem do pacote.

---

## 10. Problemas comuns

Veja **`Documentacao\Solucao_Problemas.md`** (extensão "não carregada", Node antigo, npm sem internet, PowerShell
bloqueado, ajudante da PGFN, janela anônima, porta ocupada, PDFs fora da pasta, etc.).

---

## INSTRUÇÕES PARA O CLAUDE NO COMPUTADOR DE DESTINO

Você está num computador Windows **diferente** do de origem. O usuário quer a Central e as 6 automações funcionando com
o mínimo de intervenção. Siga este roteiro, nesta ordem, e **relate o que fez em cada passo**.

**Regras de segurança (obrigatórias):**
- Não peça, não digite e não copie senhas, PINs, certificados (.pfx) ou tokens. Instalar o certificado e fazer login no
  e-CAC/gov.br é tarefa da pessoa.
- Não rode lotes reais de CNPJs nem emita certidões/DARFs para testar. Teste só abertura, interfaces e testes
  automáticos. Uso real só com autorização expressa da pessoa e com 1 ou 2 documentos.
- Não carregue extensões nem mude configurações do Chrome por conta própria: oriente a pessoa (o Chrome exige isso).
- Não apague nada do usuário. Ao reinstalar, use o próprio `instalar.ps1` (ele preserva dados).
- Trabalhe a partir de cópias: não edite os arquivos dentro do pacote; ajuste os arquivos já instalados.

1. **Analise o conteúdo da pasta recebida.** Liste a raiz e confira que existem `Central_de_Automacoes\`,
   `Automacoes\` (6 pastas: `Retirar_Auto_Infracao`, `ATM_RFB`, `Auto_PGFN`, `Situacao_Fiscal`,
   `Parcelamento_Simplificado`, `Regularidade_Fiscal_PE`), `Instalacao\` (`instalar.ps1`, `verificar_ambiente.ps1`,
   `configurar_central.ps1`, `comum.ps1`), `Documentacao\`, `INSTALAR.cmd`, `VERIFICAR.cmd`. Se o pacote veio em ZIP,
   extraia inteiro (com `Expand-Archive`) e confirme os 6 `manifest.json` de extensão.
2. **Leia o inventário:** `Documentacao\Inventario_Automacoes.md` (pontos de entrada, dependências, versões,
   situação) e `Documentacao\Requisitos_Sistema.md`.
3. **Verifique o ambiente:**
   `powershell -NoProfile -ExecutionPolicy Bypass -File .\Instalacao\verificar_ambiente.ps1 -SoRequisitos`.
   Anote o que falta (Chrome, Node 20+, Python 3.8+, winget).
4. **Instale as dependências** que faltarem. Prefira o próprio instalador:
   `powershell -NoProfile -ExecutionPolicy Bypass -File .\Instalacao\instalar.ps1 -SemPerguntas -InstalarDependencias`
   (usa winget, fontes oficiais; Python com `--scope user`). Se o Node.js pedir permissão de administrador (UAC), peça
   à pessoa para aprovar. Depois de instalar Node/Python, **abra um terminal novo** (PATH) e rode o instalador de novo.
   Rode comandos longos em segundo plano (npm ci + pip levam ~1 a 3 min).
5. **Configure cada automação:** o `instalar.ps1` já roda `npm ci` em `Retirar_Auto_Infracao` e o `instalar.ps1` do
   `ATM_RFB` (npm + `.venv`). Confirme `node_modules\pdfjs-dist` nas duas e `ATM_RFB\.venv\Scripts\python.exe -c "import PIL, openpyxl"`.
6. **Extensões do Chrome:** mostre à pessoa a tabela da seção 5 com os caminhos **reais** desta máquina e peça para
   carregá-las (Modo do desenvolvedor → Carregar sem compactação) e ligar "Permitir no modo anônimo" nas 4 marcadas.
   Peça também para desligar "Perguntar onde salvar cada arquivo". Depois, confira com `verificar_ambiente.ps1`
   (ele lê as preferências do Chrome e mostra o ID de cada extensão carregada). Em seguida a pessoa (ou você, com o
   consentimento dela) roda `%USERPROFILE%\Downloads\Auto_PGFN\INSTALAR.bat` — é interativo (pede Enter e S/N).
7. **Configure a Central:** já feito pelo instalador. Para refazer:
   `powershell -NoProfile -ExecutionPolicy Bypass -File .\Instalacao\configurar_central.ps1`.
8. **Ajuste os caminhos:** a Central resolve `%CENTRAL_ATM%` sozinha. Só edite `automacoes.json` se a pessoa quiser
   outra pasta de instalação (rode o instalador com `-Destino`) ou outra pasta de projeto. Não troque a PGFN de lugar.
   Confira com `Central.ps1 -Validar` (todas `pronto : sim`).
9. **Atalho:** confirme `Área de Trabalho\Central de Automações.lnk` → `wscript.exe "<Destino>\Central_de_Automacoes\Abrir Central.vbs"`.
   Se o Windows usar Área de Trabalho no OneDrive, o instalador usa a pasta certa via `[Environment]::GetFolderPath('Desktop')`.
10. **Teste a abertura:** siga a seção 8 (itens 1 a 5). Para abrir uma automação pela linha de comando:
    `Central.ps1 -Abrir "RETIRAR AUTO-INFRAÇÃO"`. As interfaces Node (Retirar, ATM RFB) abrem uma janela de comando
    e o navegador; feche-as depois (Ctrl+C ou fechar a janela).
11. **Corrija incompatibilidades:** use `Documentacao\Solucao_Problemas.md`. Ajustes de código só nos arquivos
    instalados, com backup antes, e explique cada mudança à pessoa.
12. **Relatório final** para a pessoa, separando:
    - **instalado e verificado** (requisitos, cópias, dependências, Central `-Validar`, autoteste da janela, testes npm);
    - **depende da pessoa** (extensões carregadas, modo anônimo, ajudante da PGFN, certificado instalado, login no e-CAC);
    - **não testado** (execução real nos sites: e-CAC, MTE, Receita, e-Fisco — exigem certificado, login e/ou CAPTCHA).

---

## Mapa do pacote

```
Enviar_Central_ATM\
  README_INSTALACAO_COMPLETA.md   este documento
  INSTALAR.cmd                    instala tudo (chama Instalacao\instalar.ps1)
  VERIFICAR.cmd                   confere (chama Instalacao\verificar_ambiente.ps1)
  Central_de_Automacoes\          a Central (versão portátil) + README.md
  Automacoes\                     uma pasta por automação (cada uma com seu README/LEIA-ME)
  Dependencias\LEIA-ME.md         o que é baixado na instalação e de onde
  Instalacao\                     instalar.ps1, verificar_ambiente.ps1, configurar_central.ps1, comum.ps1
  Documentacao\                   Inventario_Automacoes.md, Estrutura_Projeto.md, Requisitos_Sistema.md, Solucao_Problemas.md
```
