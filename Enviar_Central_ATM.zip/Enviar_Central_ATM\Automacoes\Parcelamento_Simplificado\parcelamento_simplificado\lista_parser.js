// Leitura e validação da lista "cnpj;nome_da_empresa" e dos nomes de pasta (usado pela interface.html).
// Só funções puras, sem acesso ao navegador: dá para testar com "node" (ver README).
//
// Regras:
//  - uma empresa por linha: CNPJ;NOME (o ";" separa; o Excel, que cola com TAB, também é aceito);
//  - CNPJ com ou sem máscara; só o CNPJ vai para a consulta, o nome só dá nome à pasta;
//  - CNPJ com 12 ou 13 dígitos (o Excel tira os zeros à esquerda) é completado com zeros SE os dígitos verificadores baterem;
//  - CNPJ repetido na lista é ignorado (vale a 1ª linha);
//  - nomes de pasta compatíveis com o Windows; empresas com o mesmo nome de pasta ganham o CNPJ no nome.
(function (raiz) {
  'use strict';

  const soDigitos = (s) => String(s || '').replace(/\D/g, '');

  function cnpjValido(d) {
    if (!/^\d{14}$/.test(d) || /^(\d)\1{13}$/.test(d)) return false;
    const dv = (base) => {
      let soma = 0, peso = base.length - 7;
      for (const c of base) { soma += Number(c) * peso; peso = peso === 2 ? 9 : peso - 1; }
      const r = soma % 11;
      return r < 2 ? 0 : 11 - r;
    };
    const d1 = dv(d.slice(0, 12));
    const d2 = dv(d.slice(0, 12) + d1);
    return d.endsWith(`${d1}${d2}`);
  }

  const formatarCnpj = (d) => `${d.slice(0, 2)}.${d.slice(2, 5)}.${d.slice(5, 8)}/${d.slice(8, 12)}-${d.slice(12)}`;

  const RESERVADOS = /^(con|prn|aux|nul|com[1-9]|lpt[1-9])$/i;

  // Um trecho de nome de pasta/arquivo aceito pelo Windows: sem < > : " / \ | ? * nem caracteres de controle,
  // sem espaços repetidos, sem ponto ou espaço no fim, sem nomes reservados (CON, NUL...), no máximo `max` letras.
  function limparNomePasta(texto, max = 100) {
    let t = String(texto || '')
      .replace(/[\u0000-\u001f]/g, ' ')
      .replace(/[\\/]+/g, '-')
      .replace(/[<>:"|?*]/g, '_')
      .replace(/\s+/g, ' ')
      .trim();
    if (t.length > max) t = t.slice(0, max);
    t = t.replace(/[. ]+$/, '').replace(/^[. ]+/, '');
    if (RESERVADOS.test(t)) t += '_';
    return t;
  }

  // Pasta principal: pode ter subpastas separadas por "/" (ou "\"); cada parte é limpa como acima.
  function limparPastaPrincipal(texto) {
    return String(texto || '').split(/[\\/]+/)
      .map((p) => limparNomePasta(p))
      .filter((p) => p && p !== '.' && p !== '..')
      .join('/');
  }

  // Cada linha: "CNPJ;NOME" (ou "CNPJ<TAB>NOME"). Devolve:
  //  itens   [{ cnpj, nome, pasta, completou }]  (pasta = nome da subpasta da empresa)
  //  erros   ["Linha 3: ...", ...]
  //  repetidos  quantas linhas repetiam um CNPJ já lido
  //  ajustados  quantos CNPJs tiveram zeros à esquerda completados
  //  rejeitadas [{ linha, texto, motivo }]  as mesmas linhas com erro, em forma de dados (para o relatório)
  // Linhas com erro NÃO impedem o resto: a interface ignora essas linhas, segue com as válidas e as lista no relatório.
  function lerLista(texto) {
    const itens = [], erros = [], rejeitadas = [], vistos = new Set();
    let repetidos = 0, ajustados = 0;
    const rejeitar = (n, linha, motivo, mensagem) => {
      erros.push(`Linha ${n}: ${mensagem}`);
      rejeitadas.push({ linha: n, texto: String(linha).trim().slice(0, 200), motivo });
    };
    String(texto || '').split(/\r?\n/).forEach((linha, i) => {
      if (!linha.trim()) return;
      const n = i + 1;
      const corte = linha.search(/[;\t]/);
      if (corte < 0) {
        rejeitar(n, linha, 'formato inválido: faltou o ";" e o nome da empresa (use CNPJ;NOME DA EMPRESA)', 'use o formato CNPJ;NOME DA EMPRESA (faltou o ";" e o nome)');
        return;
      }
      const bruto = linha.slice(0, corte).trim();
      const nome = linha.slice(corte + 1).replace(/[;\t]+/g, ' ').replace(/\s+/g, ' ').trim()
        .replace(/^"+|"+$/g, '').trim();
      let d = soDigitos(bruto);
      let completou = false;
      if (d.length >= 12 && d.length < 14) { d = d.padStart(14, '0'); completou = true; }
      if (!/^[\d.\-/\s]+$/.test(bruto) || !cnpjValido(d)) {
        rejeitar(n, linha, `CNPJ inválido ("${bruto || '(vazio)'}": não tem 14 dígitos ou os dígitos verificadores não conferem)`, `"${bruto || '(vazio)'}" não é um CNPJ válido`);
        return;
      }
      if (!limparNomePasta(nome)) {
        rejeitar(n, linha, `falta o nome da empresa depois do ";" (CNPJ ${formatarCnpj(d)})`, `falta o nome da empresa depois do ";" (CNPJ ${formatarCnpj(d)})`);
        return;
      }
      if (vistos.has(d)) { repetidos += 1; return; }
      vistos.add(d);
      if (completou) ajustados += 1;
      itens.push({ cnpj: d, nome, pasta: '', completou });
    });
    atribuirPastas(itens);
    return { itens, erros, rejeitadas, repetidos, ajustados };
  }

  // Dá a cada empresa o nome da subpasta: o nome limpo; se duas empresas ficarem com o mesmo nome
  // (sem diferenciar maiúsculas/minúsculas, como o Windows), todas as do grupo ganham " - <CNPJ>".
  function atribuirPastas(itens) {
    const grupos = new Map();
    for (const it of itens) {
      it.pasta = limparNomePasta(it.nome);
      const chave = it.pasta.toLowerCase();
      if (!grupos.has(chave)) grupos.set(chave, []);
      grupos.get(chave).push(it);
    }
    for (const g of grupos.values()) {
      if (g.length > 1) g.forEach((it) => { it.pasta = limparNomePasta(`${it.pasta} - ${it.cnpj}`, 130); it.diferenciada = true; });
    }
    return itens;
  }

  // ---------------- relatório de problemas ----------------
  // Empresas da lista que tiveram problema (erro do sistema, falha na consulta, PDF não salvo, resultado desconhecido...),
  // com o motivo. NÃO conta como problema: empresa concluída, parada a pedido do usuário ou ainda em andamento.
  // `feitos` = o andamento guardado pela automação (fila.feitos).
  const ESTADOS_FEITOS = ['sem negociação', 'sem negociação ativa', 'DARF salvo'];
  function problemasDaFila(itens, feitos) {
    const out = [];
    for (const it of itens || []) {
      const f = (feitos || {})[it.cnpj];
      if (!f || ESTADOS_FEITOS.includes(f.estado)) continue;
      if (f.estado === 'erro do sistema' || (f.estado === 'parou' && !/em andamento|interrompida/.test(f.detalhe || ''))) {
        out.push({ cnpj: it.cnpj, nome: it.nome, motivo: String(f.detalhe || f.estado).replace(/\s+/g, ' ').trim(), quando: f.quando || '' });
      }
    }
    return out;
  }

  // Empresas puladas por causa do aviso "mensagens importantes não lidas na Caixa Postal" (a automação não abre a Caixa Postal).
  const ESTADO_CAIXA = 'Pulado - Aviso de Caixa Postal';
  function puladosCaixa(itens, feitos) {
    const out = [];
    for (const it of itens || []) {
      const f = (feitos || {})[it.cnpj];
      if (f && f.estado === ESTADO_CAIXA) out.push({ cnpj: it.cnpj, nome: it.nome, motivo: String(f.detalhe || ESTADO_CAIXA).replace(/\s+/g, ' ').trim(), quando: f.quando || '' });
    }
    return out;
  }

  function textoRelatorio({ pasta, total, sucesso, problemas, pulados, rejeitadas, pendentes, quando }) {
    pulados = pulados || [];
    const L = [];
    L.push('RELATÓRIO - PARCELAMENTO SIMPLIFICADO');
    L.push(`Pasta de resultados: Downloads\\${String(pasta || '').replace(/\//g, '\\')}`);
    L.push(`Gerado em: ${quando || new Date().toLocaleString('pt-BR')}`);
    L.push(`Empresas na lista: ${total} | Concluídas com sucesso: ${sucesso} | Com problema: ${problemas.length}${pulados.length ? ` | Puladas (Caixa Postal): ${pulados.length}` : ''} | Ainda pendentes: ${pendentes}`);
    if (rejeitadas && rejeitadas.length) L.push(`Linhas da lista ignoradas por erro: ${rejeitadas.length}`);
    L.push('');
    if (!problemas.length && !pulados.length && !(rejeitadas && rejeitadas.length)) L.push('Nenhum problema registrado.');
    if (pulados.length) {
      L.push(`PULADAS - AVISO DE CAIXA POSTAL (${pulados.length})`);
      L.push('O e-CAC bloqueia estas empresas até as mensagens importantes da Caixa Postal serem lidas. A automação não abre a Caixa Postal.');
      pulados.forEach((p, i) => {
        L.push(`${i + 1}. ${formatarCnpj(p.cnpj)} - ${p.nome}`);
        if (p.quando) L.push(`   Quando: ${p.quando}`);
      });
      L.push('Depois de ler as mensagens, use "Refazer as puladas (Caixa Postal)" na janela da extensão e clique em Continuar automação.');
      L.push('');
    }
    if (problemas.length) {
      L.push(`EMPRESAS COM PROBLEMA (${problemas.length})`);
      problemas.forEach((p, i) => {
        L.push(`${i + 1}. ${formatarCnpj(p.cnpj)} - ${p.nome}`);
        L.push(`   Motivo: ${p.motivo}`);
        if (p.quando) L.push(`   Quando: ${p.quando}`);
      });
      L.push('');
    }
    if (rejeitadas && rejeitadas.length) {
      L.push(`LINHAS DA LISTA IGNORADAS (${rejeitadas.length})`);
      rejeitadas.forEach((r) => { L.push(`Linha ${r.linha}: ${r.texto}`); L.push(`   Motivo: ${r.motivo}`); });
      L.push('');
    }
    if (problemas.length) L.push('Para tentar de novo as empresas com problema: clique em "Continuar automação" na janela da extensão.');
    return L.join('\r\n');
  }

  const api = { soDigitos, cnpjValido, formatarCnpj, limparNomePasta, limparPastaPrincipal, lerLista, atribuirPastas, problemasDaFila, puladosCaixa, textoRelatorio, ESTADO_CAIXA };
  if (typeof module === 'object' && module.exports) module.exports = api;
  else raiz.ParcelamentoLista = api;
})(typeof self !== 'undefined' ? self : globalThis);
