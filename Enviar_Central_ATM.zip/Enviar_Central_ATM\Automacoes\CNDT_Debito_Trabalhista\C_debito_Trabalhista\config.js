// Configurações fixas da automação da CNDT. Tudo o que depende do site do TST fica aqui,
// para que uma mudança no site exija ajuste em um lugar só.
//
// Carregado como content script (antes dos demais) e também pelo background.js
// (importScripts) e pelos testes do Node (require).

(function (raiz) {
  const CONFIG = {
    // Página de emissão. O marcador depois do "#" não é enviado ao TST: só diz à extensão
    // que esta aba foi aberta pela automação (abrir a página à mão não dispara nada).
    URL_EMISSAO: 'https://cndt-certidao.tst.jus.br/gerarCertidao',
    MARCADOR: 'cndt_preencher',
    CAMINHO_EMISSAO: /^\/gerarCertidao\/?$/i,

    // CNPJ usado só nos testes automáticos (tests/). As empresas vêm da lista da janela.
    CNPJ_TESTE: '48.291.735/0001-09',

    // Seletores. O id é o principal; os demais são reserva caso o id mude.
    SELETORES: {
      formulario: '#form-gerar-certidao',
      campoDocumento: [
        '#cpfCnpj',
        'input[name="cpfCnpj"]',
        'input.campo-cpf-cnpj',
      ],
      // Rótulo "Informe o número do CNPJ / CPF": última reserva, acha o campo pelo texto.
      textoRotuloDocumento: /informe\s+o\s+n[uú]mero\s+do\s+cnpj/i,
      imagemCaptcha: '#captcha-imagem',
      campoCaptcha: '#captcha-resposta',
      // Botão "Emitir Certidão": o cursor só é levado até ele (não clica). Reserva pelo texto.
      botaoEmitir: '#botao-emitir',
      textoBotaoEmitir: /^\s*emitir\s+certid[aã]o\s*$/i,
      secaoSucesso: '#secao-sucesso',
      textoSucesso: '#texto-sucesso',
      mensagensErro: '#mensagens', // o site mostra aqui o erro (ex.: verificação incorreta)
      mensagemAguarde: '#mensagem-aguarde',
      // Verificações humanas de terceiros: se aparecerem, a automação para e deixa com a pessoa.
      desafioExterno: 'iframe[src*="recaptcha"], iframe[src*="hcaptcha"], iframe[src*="challenges.cloudflare"], #challenge-form, .cf-turnstile',
    },

    // Esperas (ms). Todas com limite: nada fica esperando para sempre.
    TEMPOS: {
      esperaCampo: 20000, // até o campo CNPJ/CPF existir e estar utilizável
      esperaSiteIniciado: 20000, // até o script do site carregar o captcha (= página completa)
      intervaloVerificacao: 250,
      esperaMascara: 300, // depois do keyup, para a máscara do site formatar
    },

    // Digitação em ritmo humano (valores de estudos de digitação, ver README):
    // - intervalo entre teclas: média de ~240 ms em texto corrido (Dhakal et al., CHI 2018,
    //   136 milhões de teclas); números copiados de outro lugar saem mais devagar. Usamos
    //   220 a 420 ms (média ~320 ms, cerca de 37 palavras por minuto).
    // - tempo com a tecla apertada (keydown até keyup): 70 a 130 ms nos mesmos estudos.
    // - pausas maiores entre os blocos do número (48 . 291 . 735 / 0001 - 09), como quem
    //   lê o CNPJ em partes, e de vez em quando uma hesitação fora dos blocos.
    DIGITACAO: {
      intervaloMin: 220,
      intervaloMax: 420,
      teclaApertadaMin: 70,
      teclaApertadaMax: 130,
      pausaEntreBlocosMin: 350,
      pausaEntreBlocosMax: 750,
      chancePausa: 0.1,
      pausaMin: 300,
      pausaMax: 650,
      esperaAntesDeDigitar: 500, // depois do clique, antes da primeira tecla (400-700 ms)
    },

    // Cursor visual (ver cursor.js). ativo: false desliga o desenho; os cliques e a
    // digitação continuam iguais.
    //
    // Tempo do movimento pela Lei de Fitts (MacKenzie, 1992): T = a + b * log2(D/L + 1),
    // D = distância até o alvo e L = largura do alvo. Com a = 400 ms e b = 230 ms/bit, ir
    // ~500 px até um campo de 175 px leva ~0,9 s, e até um botão pequeno, ~1,3 s, dentro
    // do que se mede em pessoas usando mouse. Antes de clicar, a pessoa para sobre o alvo
    // 250-500 ms, e o botão fica apertado 80-140 ms.
    CURSOR: {
      ativo: true,
      cor: '#1f5fa8',
      fittsA: 400,
      fittsB: 230,
      duracaoMin: 700,
      duracaoMax: 2000,
      limiteRolagem: 2000, // máximo esperando a rolagem até o elemento terminar
      paradaAntesDoCliqueMin: 250, // cursor parado sobre o elemento antes de clicar
      paradaAntesDoCliqueMax: 500,
      botaoApertadoMin: 80, // mousedown até mouseup
      botaoApertadoMax: 140,
      esconderDepoisDe: 2500, // ao terminar, some depois deste tempo (0 = fica visível)
    },

    // Recuperação: quantas vezes recarregar a página se ela vier incompleta ou travada.
    MAX_RECARGAS: 2,

    // Lista de empresas (janela da automação).
    FILA: {
      maxFalhasSeguidas: 5, // tantas empresas seguidas com erro = problema geral: pausa
      // espera pelo PDF depois de a página dizer "Certidão EMITIDA" (download + confirmação do arquivo)
      limiteDownload: 45000,
      // validade da "espera armada" pelo download (da espera pela verificação até o arquivo salvo)
      validadeEsperaDownload: 8 * 60 * 1000,
      pausaEntreEmpresas: 1500, // depois de salvar o PDF, antes do F5 para a próxima
      // Se o limite acima estourou mas o download ainda está em andamento, espera mais até
      // ele terminar antes do F5 (o F5 cortaria o download).
      esperaExtraDownload: 60000,
      // Vigia do F5: a página precisa voltar à emissão e pedir a próxima empresa neste tempo
      // (mínimo 30 s: limite do chrome.alarms). Senão, nova tentativa.
      vigiaRecargaSegundos: 45,
      maxTentativasRecarga: 3, // depois disso, pausa e avisa
    },

    // Depois de preencher, deixa o cursor no campo do captcha (para a pessoa digitar).
    FOCAR_CAPTCHA_DEPOIS: true,

    // Espera a PESSOA digitar o captcha. A automação nunca escreve nele: só observa a
    // digitação (eventos marcados pelo navegador como vindos do usuário). Quando a pessoa
    // para de digitar, confere a página, leva o cursor até "Emitir Certidão" e clica.
    CAPTCHA_PELO_USUARIO: {
      ativo: true,
      silencioParaConcluir: 1500, // ms sem digitar = a pessoa terminou
      minimoCaracteres: 4, // menos que isso: ainda digitando (ou apagou)
      limiteEspera: 5 * 60 * 1000, // depois de 5 min sem terminar, para de esperar e avisa
      clicarEmitir: true, // false: só leva o cursor até o botão (o clique fica com a pessoa)
      janelaCancelamento: 1500, // cursor sobre o botão antes do clique; digitar ou Esc cancela
      limiteResposta: 60000, // espera pela resposta do site depois do clique
      maxTentativas: 3, // envios por página (ex.: verificação incorreta); depois para
    },

    PREFIXO_LOG: '[CNDT]',
  };

  raiz.CNDT = raiz.CNDT || {};
  raiz.CNDT.CONFIG = CONFIG;
  if (typeof module !== 'undefined' && module.exports) module.exports = CONFIG;
})(typeof globalThis !== 'undefined' ? globalThis : self);
