@echo off
rem Orquestrador da Automacao_PGFN: processa os CNPJs de ..\cnpjs.json, um por vez, fechando e reabrindo o Chrome.
rem ATENCAO: fecha TODAS as janelas do Chrome a cada CNPJ. Para parar: feche esta janela (ou Ctrl+C).
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0orquestrador.ps1" %*
pause