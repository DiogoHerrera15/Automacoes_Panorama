﻿# Gera o pacote para instalar a Automação PGFN em outro computador: um .zip com a pasta Auto_PGFN pronta, SEM dados
# de clientes (cnpjs.json, Documentos_arrecadacao, registros, andamento, documento interno de desenvolvimento) e sem o
# manifesto do ajudante deste computador (o INSTALAR.bat gera outro lá). Quem recebe: extrai em Downloads e roda INSTALAR.bat.
$ErrorActionPreference = 'Stop'
$BASE = Split-Path $PSScriptRoot -Parent
$versao = (Get-Content -LiteralPath (Join-Path $BASE 'Automação_PGFN\manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json).version
$saida = Join-Path $BASE 'pacotes'
$tmp = Join-Path $env:TEMP ("pacote_pgfn_" + [guid]::NewGuid().ToString('N'))
$raiz = Join-Path $tmp 'Auto_PGFN'
New-Item -ItemType Directory -Force -Path $raiz, $saida | Out-Null
try {
  # o que vai no pacote (caminhos relativos à pasta do projeto)
  $itens = @(
    'Automação_PGFN',
    'ajudante_salvar_como\salvar_como.bat', 'ajudante_salvar_como\salvar_como.ps1',
    'ajudante_salvar_como\instalar_ajudante.bat', 'ajudante_salvar_como\instalar_ajudante.ps1', 'ajudante_salvar_como\desinstalar_ajudante.bat',
    'orquestrador\orquestrador.ps1', 'orquestrador\iniciar_orquestrador.bat', 'orquestrador\ver_andamento.ps1',
    'instalacao\instalar.ps1', 'instalacao\cnpjs.exemplo.json',
    'INSTALAR.bat', 'INICIAR_AUTOMACAO.bat', 'VER_ANDAMENTO.bat', 'LEIA-ME.txt',
    'Automacao_PGFN.exe', 'interface\AutomacaoPGFN.cs', 'interface\compilar.bat' # interface (configurações ficam fora: são dados do usuário)
  )
  foreach ($i in $itens) {
    $de = Join-Path $BASE $i
    if (-not (Test-Path -LiteralPath $de)) { throw "faltou no projeto: $i" }
    $para = Join-Path $raiz $i
    New-Item -ItemType Directory -Force -Path (Split-Path $para -Parent) | Out-Null
    Copy-Item -LiteralPath $de -Destination $para -Recurse -Force
  }
  New-Item -ItemType Directory -Force -Path (Join-Path $raiz 'Documentos_arrecadacao') | Out-Null
  $zip = Join-Path $saida ("Automacao_PGFN_v{0}_{1}.zip" -f $versao, (Get-Date -Format 'yyyy-MM-dd'))
  if (Test-Path -LiteralPath $zip) { Remove-Item -LiteralPath $zip -Force }
  Add-Type -AssemblyName System.IO.Compression.FileSystem
  [IO.Compression.ZipFile]::CreateFromDirectory($raiz, $zip, [IO.Compression.CompressionLevel]::Optimal, $true, [Text.Encoding]::UTF8)
  $qtd = @(Get-ChildItem -LiteralPath $raiz -Recurse -File).Count
  Write-Host ''
  Write-Host "  Pacote gerado ($qtd arquivos, versão $versao):" -ForegroundColor Green
  Write-Host "  $zip"
  Write-Host '  Quem recebe: extrai em Downloads (fica Downloads\Auto_PGFN) e roda INSTALAR.bat.'
} finally {
  Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue
}
