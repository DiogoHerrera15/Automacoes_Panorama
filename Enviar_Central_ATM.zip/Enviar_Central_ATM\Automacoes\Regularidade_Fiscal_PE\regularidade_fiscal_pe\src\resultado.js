/* Tabela "Resultado da consulta": só é usada se o Localizar devolver registros (conferir CNPJ e selecionar). */
(function () {
  'use strict';
  const NS = (window.EFiscoCRF = window.EFiscoCRF || {});
  const { dormir, esperarPor, esperarOuNulo, tentar } = NS.wait;
  const { norm } = NS.dom;

  function tabela() {
    const c = NS.CONFIG.resultado;
    return (c.seletorTabela && document.querySelector(c.seletorTabela)) ||
      [...document.querySelectorAll('table')].find((t) => {
        const x = norm(t.textContent);
        return x.includes('cnpj/cpf') && x.includes('irregularidade');
      }) || null;
  }

  function cabecalhoDe(t) {
    const linha = (t.tHead && t.tHead.rows[0]) || t.rows[0];
    return { linha, nomes: linha ? [...linha.cells].map((c) => norm(c.textContent)) : [] };
  }

  const VAZIO = /nenhum (registro|resultado)|n[aã]o (h[aá]|foram?|foi) (registro|resultado|encontrad|localizad)|sem registros?/;

  /** Linhas de DADOS (ignora cabeçalho, linhas de detalhe do footable e a linha "nenhum registro"). */
  function linhasDados() {
    const t = tabela();
    if (!t) return [];
    const { linha } = cabecalhoDe(t);
    return [...t.rows].filter((r) => {
      if (r === linha || r.closest('thead') || /detail/i.test(r.className)) return false;
      const celulas = [...r.cells];
      if (!celulas.length) return false;
      const texto = norm(r.textContent);
      if (!texto && !r.querySelector('input')) return false;
      if (celulas.length <= 2 && VAZIO.test(texto)) return false;
      return true;
    });
  }

  /** Mensagens visíveis do sistema fora da tabela. */
  function mensagens() {
    const sel = '[role=alert], [class*="mensagem" i], [class*="msg" i], [id*="mensagem" i], [id*="msg" i], .erro, .error, .alert';
    const t = tabela();
    const textos = new Set();
    for (const el of document.querySelectorAll(sel)) {
      if (el.closest('#efisco-painel-host, #efisco-cursor-host') || (t && t.contains(el))) continue;
      if (!NS.wait.estaVisivel(el)) continue;
      const txt = el.textContent.replace(/\s+/g, ' ').trim();
      if (txt && txt.length <= 400) textos.add(txt);
    }
    return [...textos].slice(0, 4);
  }

  /** Aguarda (limite curto) linhas ou mensagem. Linhas vazias NÃO são erro aqui: quem chama decide. */
  async function aguardar() {
    const c = NS.CONFIG.resultado;
    NS.log.info(`[Localizar] Verificando se a consulta devolveu registros (até ${Math.round(c.timeout / 1000)} s)...`);
    const inicio = Date.now();
    let proximo = inicio + 5000;
    await esperarOuNulo(() => {
      if (Date.now() >= proximo) { proximo += 5000; NS.log.info(`Ainda aguardando (${Math.round((Date.now() - inicio) / 1000)} s)...`); }
      return linhasDados().length > 0 || mensagens().length > 0;
    }, { timeout: c.timeout, intervalo: 300, descricao: 'resultado da consulta' });
    let n = linhasDados().length;
    let semMudanca = Date.now();
    await esperarOuNulo(() => {
      const atual = linhasDados().length;
      if (atual !== n) { n = atual; semMudanca = Date.now(); }
      return Date.now() - semMudanca >= c.estabilidade;
    }, { timeout: c.timeout, intervalo: 150, descricao: 'estabilização da tabela' });
    return { linhas: linhasDados(), mensagens: mensagens() };
  }

  function interpretar(linhas) {
    const t = tabela();
    const { nomes } = cabecalhoDe(t);
    const col = NS.CONFIG.resultado.colunas;
    const idx = (nome, exato) => nomes.findIndex((h) => (exato ? h === norm(nome) : h.includes(norm(nome))));
    const i = { cnpj: idx(col.cnpj), ie: idx(col.ie), nome: idx(col.nome), irreg: idx(col.irregularidade), x: idx(col.selecao, true) };
    return linhas.map((tr, n) => {
      const cel = [...tr.cells].map((c) => c.textContent.replace(/\s+/g, ' ').trim());
      const dig = (s) => NS.documento.soDigitos(s);
      let cnpj = i.cnpj >= 0 ? dig(cel[i.cnpj]) : '';
      if (cnpj.length !== 14) cnpj = cel.map(dig).find((d) => d.length === 14) || cnpj;
      return {
        n: n + 1, tr, cnpj, ie: i.ie >= 0 ? cel[i.ie] : '', ieDigitos: i.ie >= 0 ? dig(cel[i.ie]) : '', nome: i.nome >= 0 ? cel[i.nome] : '',
        irregularidade: i.irreg >= 0 ? cel[i.irreg] : '',
        controle: (i.x >= 0 && tr.cells[i.x] && tr.cells[i.x].querySelector('input[type=radio], input[type=checkbox]')) ||
          tr.querySelector('input[type=radio], input[type=checkbox]')
      };
    });
  }

  /** Confere que o resultado é do CNPJ pesquisado; interrompe se não for inequívoco. */
  function conferir(linhas, doc) {
    const regs = interpretar(linhas);
    regs.slice(0, 6).forEach((r) => NS.log.info(`Registro ${r.n}: CNPJ ${r.cnpj || '—'} | IE ${r.ie || '—'} | ${r.nome || '—'} | Irregularidade: ${r.irregularidade || '(vazio)'}`));
    // CPF/CNPJ: compara a coluna CNPJ/CPF. Inscrição Estadual: compara a coluna I. Estadual (a outra mostra o CNPJ da empresa).
    const chave = (r) => (doc.tipo === 'IE' ? r.ieDigitos : r.cnpj);
    const iguais = regs.filter((r) => chave(r) === doc.digitos);
    if (!iguais.length) throw new Error(`nenhum registro corresponde ao ${doc.rotulo || 'documento'} pesquisado ${doc.digitos} (encontrados: ${regs.map((r) => chave(r) || '?').join(', ')})`);
    if (iguais.length > 1 && !NS.CONFIG.resultado.permitirMultiplos) {
      throw new Error(`${iguais.length} registros com o mesmo CNPJ (IEs: ${iguais.map((r) => r.ie || '?').join(', ')}). A escolha exige análise — execução interrompida.`);
    }
    NS.log.ok(`Resultado confere com o ${doc.rotulo || 'documento'} pesquisado (${doc.formatado}) — registro ${iguais[0].n}${iguais[0].nome ? ': ' + iguais[0].nome : ''}.`);
    return iguais[0];
  }

  /** Seleciona o registro (radio/checkbox), confirmando o estado real do controle. */
  async function selecionar(registro) {
    const ctrl = registro.controle;
    if (!ctrl) { NS.log.info('O registro não tem controle de seleção — nenhuma seleção necessária.'); return { selecionado: false }; }
    if (ctrl.checked) { NS.log.ok('O registro já está selecionado.'); return { selecionado: true }; }
    await tentar('Selecionar registro', async () => {
      await NS.cursor.moverPara(ctrl);
      await NS.cursor.clicar();
      NS.dom.dispararClique(ctrl);
      await esperarPor(() => ctrl.checked, { timeout: NS.CONFIG.timeouts.confirmacao, descricao: 'registro marcado' });
    }, NS.CONFIG.tentativas.selecionar, NS.CONFIG.tentativas.intervalo);
    await dormir(300);
    if (!ctrl.checked) throw new Error('a seleção do registro foi desfeita pela página');
    NS.log.ok('Registro selecionado e confirmado.');
    return { selecionado: true };
  }

  NS.resultado = { tabela, linhasDados, mensagens, aguardar, conferir, selecionar };
})();
