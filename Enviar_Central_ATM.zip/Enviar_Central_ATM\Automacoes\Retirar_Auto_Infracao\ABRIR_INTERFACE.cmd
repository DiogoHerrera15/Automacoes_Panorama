@echo off
rem Abre a interface grafica do Retirar_Auto_Infracao no Windows (dois cliques neste arquivo).
rem Equivale ao ABRIR_INTERFACE.command do Mac. Deixe esta janela aberta enquanto usa a interface.
chcp 65001 >nul
title Retirar_Auto_Infracao - NAO FECHE ESTA JANELA (pode minimizar)
cd /d "%~dp0"
echo Retirar_Auto_Infracao - interface grafica
where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo O Node.js nao esta instalado. Instale a versao LTS com:  winget install OpenJS.NodeJS.LTS
  echo ou em https://nodejs.org , feche e abra esta janela de novo.
  pause
  exit /b 1
)
rem Instala as dependencias na primeira vez (o leitor de PDF usa um componente nativo do Windows).
node --input-type=module -e "await import('pdfjs-dist/legacy/build/pdf.mjs'); await import('@napi-rs/canvas')" >nul 2>nul
if errorlevel 1 (
  echo Instalando dependencias (so na primeira vez^)...
  call npm install --no-audit --no-fund
  if errorlevel 1 (
    echo Falhou. Confira a internet e rode de novo.
    pause
    exit /b 1
  )
)
echo ============================================================
echo  NAO FECHE ESTA JANELA enquanto usa a interface (pode minimizar).
echo ============================================================
node src\interface\iniciar.js %*
rem Codigo 10 = a interface ja estava aberta em outra janela: so reabriu o navegador.
rem Esta janela extra fecha sozinha (sem pause) e devolve 0 para a Central.
if errorlevel 10 (
  echo Esta janela fecha sozinha em 5 segundos.
  timeout /t 5 /nobreak >nul
  exit /b 0
)
echo.
echo Interface encerrada.
pause
