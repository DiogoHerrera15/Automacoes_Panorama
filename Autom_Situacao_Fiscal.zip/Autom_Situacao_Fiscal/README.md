# Autom_Situacao_Fiscal

Extensão do Chrome (Manifest V3) **Situacao_Fiscal**, versão **1.3.1**. Ela automatiza a consulta de situação
fiscal no portal da Receita Federal (**Minhas Dívidas e Pendências**, acessado pelo e-CAC), para uma lista de CNPJs
representados pela Assecon como **Procurador**.

Para cada CNPJ da lista, a extensão:

1. abre o perfil e representa o CNPJ (Trocar Representação → CNPJ → perfil **Procurador** → **Representar**);
2. confere o CNPJ em **Representação Atual** e em **Dados Cadastrais**;
3. lê o **Resultado da Análise**. Se for **Com pendência**, salva a captura da tela em PDF;
4. rola até o rodapé e baixa, um por vez, **Baixar Certidão** e **Baixar Relatório**;
5. se o portal recusar a procuração, salva o recorte da mensagem como evidência em PDF;
6. passa para o próximo CNPJ, com pelo menos 5 s de intervalo.

Não usa Playwright nem Selenium. É JavaScript de extensão, com uma seta visível que mostra cada ação.

---

## Estrutura

```
Autom_Situacao_Fiscal/
├── README.md                    ← este arquivo
├── CODIGO_COMPLETO.md           ← todos os arquivos do projeto, com o código integral (para reconstruir)
├── HISTORICO.md                 ← histórico da criação: decisões, problemas, soluções, regras, pendências
├── CLAUDE.md                    ← instruções para o Claude continuar o projeto num chat novo
├── Situacao_Fiscal/             ← A EXTENSÃO (pasta carregada no Chrome)
│   ├── manifest.json            ← nome, versão, permissões
│   ├── background.js            ← service worker: captura em PDF, downloads, pastas, permissões
│   ├── content.js               ← fluxo da automação, seta, status e histórico para o painel
│   ├── comum.js                 ← regras comuns: validação da lista, chaves do storage, classificação
│   ├── painel/                  ← PAINEL externo (aberto pela Central): configuração, comandos, acompanhamento
│   ├── popup.html / popup.js    ← janela do ícone: resumo e botão "Abrir painel"
│   └── LEIA-ME.md               ← manual detalhado de cada etapa e regra
└── ferramentas/                 ← auxiliares (Node.js), opcionais
    ├── lista_cnpjs.txt          ← a lista de CNPJs (CNPJ;NOME), uma por linha
    ├── validar_lista.js         ← confere formato, dígitos verificadores, repetidos e nomes de pasta iguais
    ├── aplicar_lista.js         ← grava a lista do .txt dentro do content.js
    └── analisar_progresso.js    ← cruza a lista com as pastas salvas e gera uma planilha do que falta
```

> **Onde o Chrome executa a extensão hoje:** `C:\Users\PANORAMA-PC\Desktop\ATM_SIT_FISCAL\Situacao_Fiscal`.
> Esta pasta de Documentos é a cópia de referência do projeto, e as duas devem ficar iguais. Não troque a pasta
> carregada no Chrome no meio de uma lista: o Chrome trataria a extensão como nova e o registro de progresso
> (CNPJs concluídos/pendentes) começaria do zero.

---

## Instalar

1. Abra `chrome://extensions` e ligue o **Modo do desenvolvedor**, no canto superior direito.
2. Clique em **Carregar sem compactação** e escolha a pasta `Situacao_Fiscal`.
3. Confira se o card mostra **Situacao_Fiscal 1.3.1**.
4. Em `chrome://settings/downloads`, deixe **desligado** "Perguntar onde salvar cada arquivo".
5. A permissão "Downloads automáticos", só para `servicos.receitafederal.gov.br`, é aplicada pela própria extensão.
   Para conferir: `chrome://settings/content/automaticDownloads`.

Depois de alterar qualquer arquivo, clique em **↻** no card da extensão e recarregue a página do portal.

## Executar

1. Abra a **Central de Automações** e clique em **Abrir automação** no cartão **SITUAÇÃO FISCAL**. Abre o
   **painel** da automação (`painel/painel.html`). Pelo Chrome, também se chega a ele pelo ícone da extensão →
   **Abrir painel**.
2. Em **Nome da pasta de destino**, informe a pasta (dentro de Downloads).
3. Em **CNPJs e empresas**, cole `cnpj;nome_empresa`, um por linha. Registros inválidos (CPF, dígitos errados,
   repetidos) são **ignorados e listados à parte**, sem travar os válidos.
4. Clique em **Salvar e preparar execução**. O e-CAC abre: entre com o certificado ou o gov.br (login, captcha e
   verificações são manuais).
5. Com o e-CAC autenticado, a extensão abre **Minhas Dívidas e Pendências** e começa sozinha. Acompanhe no painel:
   status, empresa e CNPJ atuais, etapa, concluídas e restantes, tabela das empresas e histórico. Os controles são
   **Iniciar / Continuar**, **Pausar**, **Parar com segurança** (esses dois valem ao terminar a empresa atual),
   **Abrir pasta de resultados** e **Zerar progresso**.
6. Enquanto roda:
   - deixe a **aba visível** e o Chrome sem minimizar, porque as capturas dependem disso;
   - não deixe o computador entrar em suspensão;
   - se a sessão do e-CAC expirar, faça login de novo e volte à página. A extensão continua de onde parou.

O aviso no canto inferior esquerdo mostra no topo o **placar** (analisados, faltam e pendentes, com uma barra de
progresso) e, embaixo, a etapa: azul para andamento, verde para concluído e vermelho para erro,
com a etapa e o motivo. Detalhes no console (F12), com o prefixo `[Situacao_Fiscal]`.

## Onde os resultados ficam

O Chrome só permite que extensões gravem dentro da pasta de Downloads:

```
C:\Users\PANORAMA-PC\Downloads\Situacao_Fiscal_Assecon\PRISCILLA_ASSECON\<NOME DA EMPRESA>\
    Certidao_<EMPRESA>.pdf                                   certidão (quando o portal oferece)
    Com_Pendencia_<EMPRESA>.pdf                              captura da tela (só "Com pendência")
    situação fiscal\Relatorio_<EMPRESA>.pdf                  relatório oficial (extensão original)
    Erro_de_Procuracao\Erro_de_Procuracao_<EMPRESA>.pdf      evidência quando o portal recusa a procuração
```

`<EMPRESA>` é o nome da lista (depois do `;`), o mesmo na pasta e nos arquivos (v1.3.0). Quando o nome se repete
na lista (ex.: filiais "… LTDA PE"), o número da filial é acrescentado no fim (`… PE 0002`). Nada é sobrescrito: um
arquivo que já exista faz o novo ganhar `(1)`. Os arquivos de versões anteriores (`RFB_<CNPJ>.pdf`…) ficam como
estão. O CNPJ continua sendo usado nas consultas e no registro interno.

## Configurar

Tudo fica no bloco **CONFIGURAÇÃO**, no início de `Situacao_Fiscal/content.js`:

| Constante | Para que serve | Valor |
|---|---|---|
| `DOCUMENTOS` | lista de CNPJs, `'CNPJ;NOME'` | 208 itens |
| `PASTA_RAIZ` | pasta dentro de Downloads (cada raiz tem o próprio progresso) | `Situacao_Fiscal_Assecon/PRISCILLA_ASSECON` (2ª rodada; a 1ª está em `ASSECON HUB CONTABILIDADE`) |
| `PERFIL` | opção escolhida no seletor | `Procurador` |
| `LENTIDAO_MOUSE` / `LENTIDAO_DIGITACAO` | velocidade da seta e da digitação | `1.0` |
| `INTERVALO_ENTRE_EMPRESAS_MS` | intervalo mínimo entre empresas | 5 s |
| `ESPERA_PROCESSANDO_NA_PAGINA_MS` | tempo esperando "Estamos processando…" antes de marcar pendente | 60 s |
| `RODADAS_PENDENTES` | novas tentativas dos pendentes no fim da lista | 1 |
| `MAX_TENTATIVAS_REPRESENTAR` | repetições quando a página volta com a empresa anterior | 3 |
| `MAX_RECARGAS_POR_CNPJ` | recargas automáticas em falha temporária do portal | 3 |
| `MAX_RECARGAS_DOWNLOAD` / `ESPERA_DOWNLOAD_1A_MS` | falha no download (ex.: erro 043): recargas e espera da 1ª (depois, 2 min) | 4 / 15 s |
| `TIMEOUT_INICIO_DOWNLOAD_MS` | tempo para o download começar após o clique | 30 s |
| `TIMEOUT_CARREGANDO_MS` / `ESPERA_FALHA_PORTAL_MS` / `ESPERA_CARREGAMENTO_MS` | tempos da recuperação | 60 s / 2 min / 15 s |

## Trocar a lista de CNPJs (com as ferramentas)

Requer o Node.js instalado. Na pasta `Autom_Situacao_Fiscal`:

```
node ferramentas\validar_lista.js ferramentas\lista_cnpjs.txt
node ferramentas\aplicar_lista.js ferramentas\lista_cnpjs.txt Situacao_Fiscal\content.js
```

A primeira confere a lista e a segunda grava a lista no `content.js`. Depois, clique em ↻ na extensão. Para começar
do zero numa pasta nova, troque também `PASTA_RAIZ`.

## Ver o que falta

```
node ferramentas\analisar_progresso.js Situacao_Fiscal\content.js "C:\Users\PANORAMA-PC\Downloads\Situacao_Fiscal_Assecon" progresso.csv
```

Mostra quantos estão concluídos (e de que tipo), onde parou, os pulados e o próximo da fila, e gera `progresso.csv`,
que abre no Excel.
