# Autom_Situacao_Fiscal — instruções para o Claude

Este projeto é a extensão do Chrome **Situacao_Fiscal**, que automatiza a situação fiscal no portal da Receita
Federal para a Assecon. Antes de qualquer ajuste:

1. Leia `HISTORICO.md` (decisões, regras de cada situação, o que falta) e `README.md`.
2. Leia a versão atual do código em `Situacao_Fiscal/` (`content.js`, `background.js`, `comum.js`, `painel/`, `manifest.json`).
3. O Chrome executa a cópia em `C:\Users\PANORAMA-PC\Desktop\ATM_SIT_FISCAL\Situacao_Fiscal`. Faça cada ajuste nas
   **duas** pastas, que devem ficar idênticas (confira por hash). Não mude a pasta carregada no Chrome: o ID da
   extensão mudaria e o progresso dos CNPJs seria perdido.

Depois de cada ajuste:

- aumente `version` no `manifest.json` e o título do `LEIA-ME.md`;
- valide com `node --check` e, para mudanças de fluxo, numa página que imita o portal (carregando o `content.js`
  real com `URL_ALVO` trocada e `chrome.*` simulado). Apague a página de teste ao terminar;
- regenere `CODIGO_COMPLETO.md`: `node ferramentas\gerar_codigo_completo.js`;
- acrescente uma linha na tabela "Linha do tempo" do `HISTORICO.md` (versão, o que mudou, por quê) e atualize
  "Regras" e "O que ainda precisa de ajuste";
- lembre o usuário de clicar em ↻ na extensão. Desde a v1.2.0 a interface é o PAINEL (`painel/painel.html`), aberto pela
  Central de Automações (`Documents\Central_Automacoes`: `automacoes.json` com `painel`, `ajuda.json`). Mudanças no fluxo de uso
  pedem atualizar também a ajuda da Central e o pacote `Desktop\Enviar_Central_ATM\Automacoes\Situacao_Fiscal` (sem dados de
  clientes: `DOCUMENTOS = []`).

Respostas ao usuário em português do Brasil.
