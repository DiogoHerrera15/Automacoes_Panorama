// Situacao_Fiscal — janela do ícone: resumo da execução e atalho para o painel (painel/painel.html).
'use strict';
const SF = self.SF;
const C = SF.CHAVES;
const $ = (id) => document.getElementById(id);
const URL_PAINEL = chrome.runtime.getURL('painel/painel.html');

async function mostrar() {
  $('versao').textContent = `v${chrome.runtime.getManifest().version}`;
  const r = await chrome.storage.local.get([C.config, C.controle, C.status]);
  const cfg = r[C.config], status = r[C.status], cmd = (r[C.controle] || {}).comando || 'executar';
  if (!cfg || !cfg.preparada) {
    $('estado').textContent = 'Nenhuma execução preparada';
    $('linha').textContent = 'Abra o painel, informe a pasta e os CNPJs e clique em "Salvar e preparar execução".';
    $('contagem').textContent = '—';
    return;
  }
  const vivo = status && Date.now() - (status.t || 0) < SF.PULSO_VALIDO_MS;
  const p = (await chrome.storage.local.get(SF.chaveProgresso(cfg.pasta)))[SF.chaveProgresso(cfg.pasta)] || {};
  const itens = cfg.documentos.map((x) => ({ digitos: SF.soDigitos(String(x).split(';')[0]) }));
  const n = SF.contar(itens, p, vivo ? status : null);
  const pct = itens.length ? Math.floor((n.feitos / itens.length) * 100) : 0;
  const nomes = { executando: 'Em execução', recuperando: 'Recuperando falha do portal', pausado: 'Pausada', parado: 'Parada',
    concluido: 'Concluída', 'concluido-pendentes': 'Concluída com pendentes', intervencao: 'Aguardando intervenção manual' };
  $('estado').textContent = vivo && nomes[status.estado] ? nomes[status.estado]
    : cmd === 'pausar' ? 'Pausada' : cmd === 'parar' ? 'Parada' : n.restantes ? 'Preparada — aguardando o e-CAC' : 'Concluída';
  $('linha').textContent = vivo && status.cnpj ? `${status.nome || ''} (${status.cnpj})` : `Pasta: ${cfg.pasta}`;
  $('contagem').textContent = `Analisados: ${n.feitos} de ${itens.length} (${pct}%) · faltam ${n.restantes}`;
  $('barra').style.width = `${pct}%`;
}

$('abrir').addEventListener('click', async () => {
  // painel já aberto numa aba? (runtime.getContexts lista as páginas da própria extensão) → só traz para a frente
  let ctx = [];
  try { ctx = await chrome.runtime.getContexts({ contextTypes: ['TAB'], documentUrls: [URL_PAINEL] }); } catch (_) { /* Chrome antigo */ }
  if (ctx.length && ctx[0].tabId >= 0) {
    await chrome.tabs.update(ctx[0].tabId, { active: true });
    if (ctx[0].windowId >= 0) await chrome.windows.update(ctx[0].windowId, { focused: true }).catch(() => {});
  } else await chrome.tabs.create({ url: URL_PAINEL });
  window.close();
});
mostrar().catch((e) => { $('estado').textContent = `Erro: ${e.message}`; });
