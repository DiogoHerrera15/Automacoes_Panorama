// Situação Fiscal — painel externo (página da própria extensão, aberta pela Central de Automações).
// Grava: config (pasta + lista preparada), controle (executar/pausar/parar), rascunho e tema.
// Lê em tempo real (storage.onChanged): status e histórico publicados pela página do portal e pelo service worker.
'use strict';

const SF = self.SF;
const C = SF.CHAVES;
const CHAVE_RASCUNHO = 'situacao_fiscal_rascunho';
const $ = (id) => document.getElementById(id);

const estado = {
  cfg: null, controle: { comando: 'executar' }, status: null, eventos: [], bg: null, progresso: {}, rascunho: null,
  filtro: 'todos', diretorio: '',
};

// ---------------------------------------------------------------- utilidades
const hora = (t) => new Date(t).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
const dataHora = (t) => new Date(t).toLocaleString('pt-BR');
function el(tag, attrs = {}, ...filhos) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === 'class') e.className = v; else if (k === 'text') e.textContent = v; else e.setAttribute(k, v);
  }
  for (const f of filhos) if (f != null) e.append(f);
  return e;
}
function mensagem(id, texto, tipo = '') { $(id).className = `dica ${tipo}`; $(id).textContent = texto; }
const statusVivo = () => !!(estado.status && Date.now() - (estado.status.t || 0) < SF.PULSO_VALIDO_MS);
const executando = () => statusVivo() && ['executando', 'recuperando', 'pausado'].includes(estado.status.estado);
const itensPreparados = () => (estado.cfg && estado.cfg.preparada && Array.isArray(estado.cfg.documentos) ? estado.cfg.documentos : [])
  .map((linha) => { const [doc, ...nome] = String(linha).split(';'); return { documento: doc.trim(), nome: nome.join(';').trim(), digitos: SF.soDigitos(doc) }; });

async function enviarBg(tipo, dados = {}) {
  try { return await chrome.runtime.sendMessage({ origem: 'Situacao_Fiscal_painel', tipo, ...dados }); }
  catch (e) { return { ok: false, erro: e.message }; }
}

// ---------------------------------------------------------------- leitura
async function carregar() {
  const r = await chrome.storage.local.get([C.config, C.controle, C.status, C.eventos, C.bg, C.tema, CHAVE_RASCUNHO]);
  estado.cfg = r[C.config] || null;
  estado.controle = r[C.controle] || { comando: 'executar' };
  estado.status = r[C.status] || null;
  estado.eventos = r[C.eventos] || [];
  estado.bg = r[C.bg] || null;
  estado.rascunho = r[CHAVE_RASCUNHO] || null;
  aplicarTema(r[C.tema] || 'auto');
  await carregarProgresso();
}
async function carregarProgresso() {
  const pasta = estado.cfg && estado.cfg.pasta;
  estado.progresso = pasta ? ((await chrome.storage.local.get(SF.chaveProgresso(pasta)))[SF.chaveProgresso(pasta)] || {}) : {};
}

// Caminho real da pasta de destino no Windows, descoberto pelos downloads já feitos nela (quando houver).
async function descobrirDiretorio(pasta) {
  if (!pasta || !chrome.downloads) return '';
  try {
    const ultimo = pasta.split('/').pop();
    const itens = await chrome.downloads.search({ query: [ultimo], limit: 300, orderBy: ['-startTime'] });
    const alvo = `\\${pasta.replace(/\//g, '\\')}\\`.toLowerCase();
    for (const it of itens) {
      const f = String(it.filename || '');
      const i = f.toLowerCase().indexOf(alvo);
      if (i >= 0) return f.slice(0, i + alvo.length - 1);
    }
  } catch (_) { /* sem downloads ainda */ }
  return '';
}

// ---------------------------------------------------------------- tema
function aplicarTema(tema) {
  if (tema === 'auto') document.documentElement.removeAttribute('data-tema');
  else document.documentElement.setAttribute('data-tema', tema);
  document.querySelectorAll('.tema button').forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.tema === tema)));
}

// ---------------------------------------------------------------- 1 · configuração
function analisarCampos() {
  const pasta = SF.limparPasta($('pasta').value);
  const lista = SF.analisarLista($('lista').value);
  return { pasta, lista };
}

function renderConfig() {
  const { pasta, lista } = analisarCampos();
  $('pasta-dica').textContent = pasta
    ? `Os arquivos vão para: Downloads\\${pasta.replace(/\//g, '\\')}\\<NOME DA EMPRESA>\\`
    : 'Fica dentro da pasta Downloads do Chrome. Use "/" para subpastas. Cada empresa ganha a própria subpasta.';
  const chips = $('resumo-lista');
  chips.replaceChildren();
  if (lista.total) {
    chips.append(el('span', { class: 'chip', text: `Total de registros: ${lista.total}` }));
    chips.append(el('span', { class: 'chip ok', text: `CNPJs válidos: ${lista.validos.length}` }));
    if (lista.ignorados.length) chips.append(el('span', { class: 'chip erro', text: `Inválidos ignorados: ${lista.ignorados.length}` }));
    if (lista.duplicados.length) chips.append(el('span', { class: 'chip aviso', text: `Repetidos ignorados: ${lista.duplicados.length}` }));
  }
  const ign = [...lista.ignorados, ...lista.duplicados].sort((a, b) => a.linha - b.linha);
  $('det-ignorados').hidden = !ign.length;
  $('ignorados-titulo').textContent = `Registros ignorados automaticamente (${ign.length}) — não serão processados`;
  $('ignorados').replaceChildren(...ign.map((x) => el('tr', {},
    el('td', { text: String(x.linha) }), el('td', { class: 'mono', text: x.texto }), el('td', { text: x.motivo }))));

  // botão e mensagens: inválidos NUNCA bloqueiam; só falta de pasta ou de CNPJ válido
  const ocupado = executando() && estado.status.estado !== 'pausado';
  const btn = $('btn-preparar');
  btn.disabled = !pasta || !lista.validos.length || ocupado;
  if (ocupado) mensagem('msg-cfg', 'A automação está executando. Para trocar a lista ou a pasta, clique em "Parar com segurança" e aguarde a empresa atual terminar.', 'aviso-txt');
  else if (!lista.total) mensagem('msg-cfg', 'Cole a lista de empresas (cnpj;nome_empresa).');
  else if (!lista.validos.length) mensagem('msg-cfg', `Nenhuma empresa apta para processamento: os ${lista.total} registro(s) são inválidos ou repetidos.`, 'erro');
  else if (!pasta) mensagem('msg-cfg', 'Informe o nome da pasta de destino.', 'erro');
  else {
    const ign2 = lista.ignorados.length + lista.duplicados.length;
    mensagem('msg-cfg', `${lista.validos.length} empresa(s) disponível(is) para processamento.` +
      (ign2 ? ` ${ign2} registro(s) ignorado(s) automaticamente; a automação continua com os ${lista.validos.length} válidos.` : ''), 'ok');
  }
  // rascunho diferente do que está preparado
  const cfg = estado.cfg;
  const diferente = !cfg || !cfg.preparada || cfg.pasta !== pasta || (cfg.original || '').trim() !== $('lista').value.trim();
  $('rascunho').hidden = !(diferente && lista.validos.length && pasta && cfg && cfg.preparada);
}

let tRascunho = null;
function salvarRascunho() {
  clearTimeout(tRascunho);
  tRascunho = setTimeout(() => {
    chrome.storage.local.set({ [CHAVE_RASCUNHO]: { pasta: $('pasta').value, lista: $('lista').value, t: Date.now() } }).catch(() => {});
  }, 400);
}

async function preparar() {
  const { pasta, lista } = analisarCampos();
  if (!pasta) return mensagem('msg-cfg', 'Informe o nome da pasta de destino.', 'erro');
  if (!lista.validos.length) return mensagem('msg-cfg', 'Nenhuma empresa apta para processamento.', 'erro');
  if (executando() && estado.status.estado !== 'pausado') return mensagem('msg-cfg', 'Pare a execução antes de preparar outra lista.', 'erro');
  const cfg = {
    versao: 2, pasta, original: $('lista').value, documentos: lista.validos.map((v) => v.item),
    ignorados: lista.ignorados, duplicados: lista.duplicados, total: lista.total,
    diretorio: await descobrirDiretorio(pasta), preparada: true, t: Date.now(),
  };
  await chrome.storage.local.set({ [C.config]: cfg, [C.controle]: { comando: 'executar', t: Date.now() } });
  $('pasta').value = pasta;
  await enviarBg('registrar', { estado: 'preparada', texto: `Execução preparada: ${cfg.documentos.length} CNPJ(s) válidos em "${pasta}"` +
    ((lista.ignorados.length + lista.duplicados.length) ? `; ${lista.ignorados.length + lista.duplicados.length} registro(s) ignorado(s)` : '') + '.', nivel: 'ok' });
  const r = await enviarBg('abrir-portal');
  const onde = r && r.onde === 'pagina' ? 'A página Minhas Dívidas e Pendências já está aberta: a automação começa agora.'
    : r && r.onde === 'ecac' ? 'e-CAC já autenticado: abrindo Minhas Dívidas e Pendências.'
      : 'O e-CAC foi aberto numa aba do Chrome: entre com o certificado. A automação começa sozinha depois do login.';
  mensagem('msg-cfg', `Execução preparada (${cfg.documentos.length} CNPJ(s)). ${onde}`, 'ok');
}

// ---------------------------------------------------------------- 2 · acompanhamento
function descreverEstado() {
  const s = estado.status, cfg = estado.cfg, vivo = statusVivo(), cmd = estado.controle.comando;
  const bgVivo = estado.bg && Date.now() - (estado.bg.t || 0) < 10 * 60000;
  if (!cfg || !cfg.preparada) return ['NÃO PREPARADA', 'neutro', 'Preencha a pasta e a lista e clique em "Salvar e preparar execução".'];
  if (vivo) {
    switch (s.estado) {
      case 'executando': return ['AUTOMAÇÃO EM EXECUÇÃO', 'ok', cmd === 'pausar' ? 'Pausa pedida: pausa ao terminar a empresa atual.' : cmd === 'parar' ? 'Parada pedida: encerra ao terminar a empresa atual.' : (s.aviso || '').split('\n')[0]];
      case 'recuperando': return ['RECUPERANDO FALHA DO PORTAL', 'aviso', (s.aviso || '').replace(/\n/g, ' · ')];
      case 'pausado': return ['PAUSADA', 'aviso', 'Clique em "Iniciar / Continuar" para seguir.'];
      case 'parado': return ['PARADA', 'neutro', 'Clique em "Iniciar / Continuar" para continuar de onde parou.'];
      case 'concluido':
        // depois de "Zerar progresso" (ou de preparar outra lista) a página ainda diz "concluído": vale o progresso
        if (SF.contar(itensPreparados(), estado.progresso, null).restantes > 0) return ['PRONTA PARA CONTINUAR', 'azul', 'Há empresas a processar. Clique em "Iniciar / Continuar".'];
        return ['CONCLUÍDA', 'ok', 'Todas as empresas válidas foram analisadas.'];
      case 'concluido-pendentes': return ['CONCLUÍDA COM PENDENTES', 'aviso', 'Algumas empresas tiveram falha do portal. "Iniciar / Continuar" tenta de novo só essas.'];
      case 'intervencao': return ['AGUARDANDO INTERVENÇÃO MANUAL', 'erro', `${s.motivo || s.aviso || ''} — resolva e aperte F5 na página do portal (continua de onde parou).`];
      case 'sem-execucao': return ['PÁGINA ABERTA', 'neutro', 'A página do portal está aberta, mas não havia execução preparada.'];
      default: break;
    }
  }
  if (cmd === 'pausar') return ['PAUSADA', 'aviso', 'Clique em "Iniciar / Continuar" para seguir.'];
  if (cmd === 'parar') return ['PARADA', 'neutro', 'Clique em "Iniciar / Continuar" para continuar de onde parou.'];
  const n = SF.contar(itensPreparados(), estado.progresso, null);
  if (n.restantes === 0) return ['CONCLUÍDA', 'ok', 'Todas as empresas válidas foram analisadas.'];
  if (bgVivo && estado.bg.estado === 'aguardando-login') return ['AGUARDANDO LOGIN NO e-CAC', 'azul', 'Entre no e-CAC com o certificado (ou gov.br). Captcha e verificações são manuais. A automação começa sozinha depois.'];
  if (bgVivo && estado.bg.estado === 'abrindo-pagina') return ['ABRINDO MINHAS DÍVIDAS E PENDÊNCIAS', 'azul', estado.bg.texto];
  if (bgVivo && estado.bg.estado === 'intervencao') return ['AGUARDANDO INTERVENÇÃO MANUAL', 'erro', estado.bg.texto];
  return ['PREPARADA — AGUARDANDO O e-CAC', 'azul', 'Entre no e-CAC (o painel abre a tela de login em "Iniciar / Continuar"). Quando o e-CAC estiver autenticado, a automação começa sozinha.'];
}

function renderAcompanhamento() {
  const [titulo, cor, detalhe] = descreverEstado();
  $('estado-pilula').className = `pilula ${cor}`;
  $('estado-pilula').textContent = titulo.split(' ')[0] === 'AUTOMAÇÃO' ? 'EM EXECUÇÃO' : titulo.split(' —')[0];
  $('estado-titulo').textContent = `Status: ${titulo}`;
  $('estado-detalhe').textContent = detalhe || '';
  const vivo = statusVivo();
  $('conexao').className = `conexao${vivo ? ' on' : ''}`;
  $('conexao-txt').textContent = vivo
    ? `Extensão ativa na página do portal (atualizado há ${Math.max(0, Math.round((Date.now() - estado.status.t) / 1000))} s)`
    : 'Página Minhas Dívidas e Pendências não está aberta';

  const cfg = estado.cfg;
  const itens = itensPreparados();
  const n = SF.contar(itens, estado.progresso, vivo ? estado.status : null);
  const ignorados = cfg && cfg.preparada ? (cfg.ignorados || []).length + (cfg.duplicados || []).length : 0;
  $('destino-pasta').textContent = cfg && cfg.preparada ? cfg.pasta : '—';
  $('destino-dir').textContent = cfg && cfg.preparada
    ? (estado.diretorio || cfg.diretorio ? `No Windows: ${estado.diretorio || cfg.diretorio}` : `Dentro de Downloads: Downloads\\${cfg.pasta.replace(/\//g, '\\')}`)
    : '';
  $('n-registros').textContent = cfg && cfg.preparada ? (cfg.total || itens.length + ignorados) : 0;
  $('n-validos').textContent = itens.length;
  $('n-ignorados').textContent = ignorados;
  $('n-concluidos').textContent = n.concluido;
  $('n-restantes').textContent = n.restantes;
  $('n-procuracao').textContent = n.procuracao;
  $('n-falhas').textContent = n.falha;
  const pct = itens.length ? Math.floor((n.feitos / itens.length) * 100) : 0;
  $('n-pct').textContent = `${pct}%`;
  $('barra-prog').style.width = `${pct}%`;
  document.querySelector('.barra').setAttribute('aria-valuenow', String(pct));

  const s = estado.status;
  const atual = vivo && s && s.cnpj && ['executando', 'recuperando'].includes(s.estado);
  $('agora-nome').textContent = atual ? (s.nome || '(sem nome na lista)') : '—';
  $('agora-cnpj').textContent = atual ? s.cnpj : '—';
  $('agora-pos').textContent = atual && s.indice ? `(${s.indice} de ${s.total})` : '';
  $('agora-etapa').textContent = atual ? ((s.aviso || '').split('\n')[0] || s.etapa || '—') : '—';
  $('agora-ultimo').textContent = s && s.ultimo ? `Último concluído: ${s.ultimo.nome || s.ultimo.documento} (${s.ultimo.documento}) — ${s.ultimo.status || ''} · ${dataHora(s.ultimo.t)}` : '';

  // botões refletem o estado real
  const preparada = !!(cfg && cfg.preparada);
  const rodando = executando();
  const cmd = estado.controle.comando;
  $('btn-iniciar').disabled = !preparada || (rodando && estado.status.estado !== 'pausado' && cmd === 'executar');
  $('btn-pausar').disabled = !preparada || cmd === 'pausar' || (!rodando && cmd !== 'executar');
  $('btn-parar').disabled = !preparada || cmd === 'parar';
  $('btn-pasta').disabled = !preparada;
  $('btn-zerar').disabled = !preparada || rodando;
}

// ---------------------------------------------------------------- 3 · empresas
const FILTROS = [['todos', 'Todas'], ['concluido', 'Concluídas'], ['procuracao', 'Erro de procuração'], ['falha', 'Falha de navegação'], ['aguardando', 'Pendentes'], ['ignorado', 'Ignoradas']];
function renderFiltros() {
  $('filtros').replaceChildren(...FILTROS.map(([k, t]) => {
    const b = el('button', { type: 'button', 'aria-pressed': String(estado.filtro === k), text: t });
    b.addEventListener('click', () => { estado.filtro = k; renderFiltros(); renderEmpresas(); });
    return b;
  }));
}
function linhasEmpresas() {
  const vivo = statusVivo();
  const linhas = itensPreparados().map((it, i) => ({ n: i + 1, ...it, ...SF.situacaoDoCnpj(it.digitos, estado.progresso, vivo ? estado.status : null) }));
  const cfg = estado.cfg;
  const ign = cfg && cfg.preparada ? [...(cfg.ignorados || []), ...(cfg.duplicados || [])] : [];
  for (const x of ign) {
    const [doc, ...nome] = String(x.texto).split(/[;\t]/);
    linhas.push({ n: `L${x.linha}`, documento: doc.trim(), nome: nome.join(' ').trim(), situacao: 'ignorado', texto: 'Ignorado (dados inválidos)', detalhe: x.motivo });
  }
  return linhas;
}
function renderEmpresas() {
  const linhas = linhasEmpresas().filter((l) => estado.filtro === 'todos' || l.situacao === estado.filtro ||
    (estado.filtro === 'aguardando' && l.situacao === 'atual'));
  if (!linhas.length) {
    $('itens').replaceChildren(el('tr', {}, el('td', { colspan: '5', class: 'vazio', text: estado.cfg && estado.cfg.preparada ? 'Nenhuma empresa neste filtro.' : 'Nenhuma execução preparada.' })));
    return;
  }
  $('itens').replaceChildren(...linhas.map((l) => el('tr', { class: l.situacao === 'atual' ? 'atual' : '' },
    el('td', { text: String(l.n) }),
    el('td', { class: 'mono', text: l.documento }),
    el('td', { text: l.nome || '—' }),
    el('td', {}, el('span', { class: `sit ${l.situacao}`, text: l.texto })),
    el('td', { text: l.detalhe || '' }))));
}

// ---------------------------------------------------------------- 4 · histórico
function renderHistorico() {
  const evs = [
    ...(estado.eventos || []).map((e) => ({ ...e, origem: 'pagina' })),
    ...((estado.bg && estado.bg.eventos) || []).map((e) => ({ ...e, origem: 'bg' })),
  ].sort((a, b) => b.t - a.t).slice(0, 120);
  if (!evs.length) { $('historico').replaceChildren(el('div', { class: 'leve', text: 'Sem eventos ainda.' })); return; }
  $('historico').replaceChildren(...evs.map((e) => el('div', { class: e.tipo === 'erro' ? 'erro' : e.tipo === 'ok' ? 'ok' : e.origem === 'bg' ? 'bg' : '' },
    el('span', { class: 'h', text: hora(e.t) }), `${e.origem === 'bg' ? '[navegador] ' : ''}${String(e.texto).replace(/\n/g, ' · ')}`)));
}

function renderTudo() { renderConfig(); renderAcompanhamento(); renderEmpresas(); renderHistorico(); }

// ---------------------------------------------------------------- comandos
async function comando(c) {
  await chrome.storage.local.set({ [C.controle]: { comando: c, t: Date.now() } });
}
async function iniciarContinuar() {
  if (!estado.cfg || !estado.cfg.preparada) return mensagem('msg-ctl', 'Prepare a execução primeiro (Salvar e preparar execução).', 'erro');
  await comando('executar');
  const r = await enviarBg('abrir-portal');
  mensagem('msg-ctl', r && r.onde === 'pagina' ? 'Continuando na página Minhas Dívidas e Pendências.'
    : r && r.onde === 'ecac' ? 'Abrindo Minhas Dívidas e Pendências no e-CAC autenticado.'
      : 'Entre no e-CAC na aba aberta: a automação começa sozinha depois do login.', 'ok');
}
async function pausar() { await comando('pausar'); mensagem('msg-ctl', 'Pausa pedida: vale ao terminar a empresa atual.', 'ok'); }
async function parar() { await comando('parar'); mensagem('msg-ctl', 'Parada pedida: a automação encerra ao terminar a empresa atual (nenhum documento fica pela metade).', 'ok'); }

let zerarArmado = null;
function desarmarZerar() { clearTimeout(zerarArmado); zerarArmado = null; $('btn-zerar').classList.remove('confirmar'); $('btn-zerar').textContent = '↺ Zerar progresso'; }
async function zerar() {
  const cfg = estado.cfg;
  if (!cfg || !cfg.preparada) return;
  if (executando()) return mensagem('msg-ctl', 'Pare a execução antes de zerar o progresso.', 'erro');
  if (!zerarArmado) {
    $('btn-zerar').classList.add('confirmar');
    $('btn-zerar').textContent = 'Confirmar: zerar?';
    mensagem('msg-ctl', `Clique de novo em 5 s para zerar o progresso de "${cfg.pasta}". A lista recomeça do 1º CNPJ; os arquivos já salvos continuam na pasta.`, 'erro');
    zerarArmado = setTimeout(() => { desarmarZerar(); mensagem('msg-ctl', ''); }, 5000);
    return;
  }
  desarmarZerar();
  await chrome.storage.local.set({ [SF.chaveProgresso(cfg.pasta)]: { concluidos: {} } });
  await enviarBg('registrar', { estado: 'preparada', texto: `Progresso de "${cfg.pasta}" zerado no painel.`, nivel: 'info' });
  mensagem('msg-ctl', `Progresso de "${cfg.pasta}" zerado.`, 'ok');
}

function csvResumo() {
  const q = (s) => `"${String(s == null ? '' : s).replace(/"/g, '""')}"`;
  const linhas = [['#', 'CNPJ', 'Empresa', 'Situação', 'Detalhe'].map(q).join(';')];
  for (const l of linhasEmpresas()) linhas.push([l.n, l.documento, l.nome, l.texto, l.detalhe].map(q).join(';'));
  linhas.push('', q(`Gerado em ${dataHora(Date.now())} — pasta ${estado.cfg.pasta}`));
  return linhas.join('\r\n');
}
async function abrirPasta() {
  const cfg = estado.cfg;
  if (!cfg || !cfg.preparada) return;
  const r = await enviarBg('abrir-pasta', { pasta: cfg.pasta, csv: csvResumo() });
  if (r && r.ok) {
    estado.diretorio = String(r.filename || '').replace(/[\\/][^\\/]+$/, '');
    mensagem('msg-ctl', `Pasta aberta no Explorador (com o resumo Resumo_Situacao_Fiscal.csv): ${estado.diretorio}`, 'ok');
  } else mensagem('msg-ctl', `Não consegui abrir a pasta: ${(r && r.erro) || 'sem resposta da extensão'}`, 'erro');
}

// ---------------------------------------------------------------- início
async function iniciarPainel() {
  $('versao').textContent = `v${chrome.runtime.getManifest().version}`;
  await carregar();
  // campos: rascunho (o que a pessoa digitou por último) ou a execução preparada
  const cfg = estado.cfg, ras = estado.rascunho;
  const usaRascunho = ras && (!cfg || (ras.t || 0) > (cfg.t || 0));
  $('pasta').value = usaRascunho ? ras.pasta : (cfg ? cfg.pasta || '' : '');
  $('lista').value = usaRascunho ? ras.lista : (cfg ? cfg.original || (cfg.documentos || []).join('\n') : '');
  if (cfg && cfg.pasta) estado.diretorio = cfg.diretorio || await descobrirDiretorio(cfg.pasta);
  renderFiltros();
  renderTudo();

  $('pasta').addEventListener('input', () => { salvarRascunho(); renderConfig(); });
  $('lista').addEventListener('input', () => { salvarRascunho(); renderConfig(); });
  $('btn-preparar').addEventListener('click', () => preparar().catch((e) => mensagem('msg-cfg', `Erro: ${e.message}`, 'erro')));
  $('btn-iniciar').addEventListener('click', () => iniciarContinuar().catch((e) => mensagem('msg-ctl', `Erro: ${e.message}`, 'erro')));
  $('btn-pausar').addEventListener('click', () => pausar().catch((e) => mensagem('msg-ctl', `Erro: ${e.message}`, 'erro')));
  $('btn-parar').addEventListener('click', () => parar().catch((e) => mensagem('msg-ctl', `Erro: ${e.message}`, 'erro')));
  $('btn-pasta').addEventListener('click', () => abrirPasta().catch((e) => mensagem('msg-ctl', `Erro: ${e.message}`, 'erro')));
  $('btn-zerar').addEventListener('click', () => zerar().catch((e) => mensagem('msg-ctl', `Erro: ${e.message}`, 'erro')));
  document.querySelectorAll('.tema button').forEach((b) => b.addEventListener('click', () => {
    aplicarTema(b.dataset.tema);
    chrome.storage.local.set({ [C.tema]: b.dataset.tema }).catch(() => {});
  }));

  // tempo real: qualquer mudança no storage (status, histórico, progresso, comandos) redesenha o painel
  let tRender = null;
  chrome.storage.onChanged.addListener(async (mudou, area) => {
    if (area !== 'local') return;
    if (mudou[C.config]) estado.cfg = mudou[C.config].newValue || null;
    if (mudou[C.controle]) estado.controle = mudou[C.controle].newValue || { comando: 'executar' };
    if (mudou[C.status]) estado.status = mudou[C.status].newValue || null;
    if (mudou[C.eventos]) estado.eventos = mudou[C.eventos].newValue || [];
    if (mudou[C.bg]) estado.bg = mudou[C.bg].newValue || null;
    if (mudou[C.tema]) aplicarTema(mudou[C.tema].newValue || 'auto');
    const chaveProg = estado.cfg && SF.chaveProgresso(estado.cfg.pasta);
    if (chaveProg && mudou[chaveProg]) estado.progresso = mudou[chaveProg].newValue || {};
    else if (mudou[C.config]) await carregarProgresso();
    clearTimeout(tRender);
    tRender = setTimeout(renderTudo, 120);
  });
  // relógio da conexão ("atualizado há X s") e reconexão: sem pulsação, o painel mostra a página como fechada
  setInterval(renderAcompanhamento, 2000);
}

iniciarPainel().catch((e) => { document.body.prepend(el('p', { class: 'dica erro', text: `Erro ao abrir o painel: ${e.message}` })); });
