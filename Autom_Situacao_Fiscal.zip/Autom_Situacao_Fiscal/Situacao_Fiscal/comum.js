// Situacao_Fiscal — regras comuns ao painel, à janela do ícone, ao service worker e à página do portal.
// Uma só fonte para: validação da lista (CNPJ;NOME), chaves do chrome.storage e classificação de cada CNPJ.
// Carregado como script comum (sem módulos): define self.SF.
(function (raiz) {
  'use strict';
  if (raiz.SF) return;

  // ---------------- chaves do chrome.storage.local ----------------
  // Cada chave tem UM escritor, para não haver gravação cruzada:
  //   config  → painel       (pasta, lista original, válidos, ignorados, preparada)
  //   controle→ painel       ({ comando: 'executar' | 'pausar' | 'parar', t })
  //   status  → página (content.js) (estado, CNPJ atual, etapa, pulsação)
  //   eventos → página        (histórico)
  //   bg      → service worker (login, abertura automática, eventos do navegador)
  //   progresso:<pasta> → página (concluídos, pendentes, parciais); o painel só zera com a execução parada
  const CHAVES = {
    config: 'situacao_fiscal_config',
    controle: 'situacao_fiscal_controle',
    status: 'situacao_fiscal_status',
    eventos: 'situacao_fiscal_eventos',
    bg: 'situacao_fiscal_bg',
    tema: 'situacao_fiscal_tema',
  };
  const chaveProgresso = (pasta) => (pasta === 'RFB_CNPJ' ? 'situacao_fiscal_progresso' : `situacao_fiscal_progresso:${pasta}`);

  const URL_PENDENCIAS = 'https://servicos.receitafederal.gov.br/servico/pendencias/#/analise-pendencias';
  const URL_LOGIN = 'https://cav.receita.fazenda.gov.br/autenticacao/login';
  const PULSO_MS = 4000;         // a página publica o status a cada 4 s
  const PULSO_VALIDO_MS = 15000; // sem pulsação há mais que isso = página do portal fechada/recarregando

  // ---------------- validação ----------------
  const soDigitos = (s) => String(s || '').replace(/\D/g, '');

  function cnpjValido(d) {
    if (!/^\d{14}$/.test(d) || /^(\d)\1{13}$/.test(d)) return false;
    const dv = (base) => {
      let soma = 0, peso = base.length - 7;
      for (const c of base) { soma += Number(c) * peso; peso = peso === 2 ? 9 : peso - 1; }
      const r = soma % 11;
      return r < 2 ? 0 : 11 - r;
    };
    const d1 = dv(d.slice(0, 12));
    const d2 = dv(d.slice(0, 12) + d1);
    return d.endsWith(`${d1}${d2}`);
  }

  function cpfValido(d) {
    if (!/^\d{11}$/.test(d) || /^(\d)\1{10}$/.test(d)) return false;
    const dv = (n) => {
      let soma = 0;
      for (let i = 0; i < n; i++) soma += Number(d[i]) * (n + 1 - i);
      const r = (soma * 10) % 11;
      return r === 10 ? 0 : r;
    };
    return dv(9) === Number(d[9]) && dv(10) === Number(d[10]);
  }

  const formatarCnpj = (d) => `${d.slice(0, 2)}.${d.slice(2, 5)}.${d.slice(5, 8)}/${d.slice(8, 12)}-${d.slice(12)}`;
  const formatarCpf = (d) => `${d.slice(0, 3)}.${d.slice(3, 6)}.${d.slice(6, 9)}-${d.slice(9)}`;

  // Nome de pasta aceito pelo Windows: sem <>:"|?*, sem "." ou ".." e sem ponto/espaço no fim de cada parte.
  function limparPasta(texto) {
    return String(texto || '').split(/[\\/]+/)
      .map((p) => p.replace(/[<>:"|?*\u0000-\u001f]/g, '_').replace(/\s+/g, ' ').trim().replace(/[. ]+$/, ''))
      .filter((p) => p && p !== '.' && p !== '..')
      .join('/');
  }

  // Classifica UM documento (só a parte antes do ";").
  // Devolve { ok, digitos, motivo }. CNPJ com ou sem máscara; zeros à esquerda preservados; se o Excel tirou
  // os zeros (12 ou 13 dígitos), completa e aceita quando os dígitos verificadores batem.
  function analisarDocumento(bruto) {
    const texto = String(bruto || '').trim();
    if (!texto) return { ok: false, digitos: '', motivo: 'linha sem CNPJ' };
    if (/[a-z]/i.test(texto)) return { ok: false, digitos: soDigitos(texto), motivo: 'contém letras: não é um CNPJ' };
    let d = soDigitos(texto);
    const mascaraCpf = /^\d{3}\.\d{3}\.\d{3}-\d{2}$/.test(texto);
    if (mascaraCpf || d.length === 11) {
      if (cpfValido(d)) return { ok: false, digitos: d, motivo: `CPF (${formatarCpf(d)}): esta automação consulta só CNPJ` };
      if (mascaraCpf) return { ok: false, digitos: d, motivo: 'CPF com dígitos verificadores inválidos' };
    }
    if (d.length >= 11 && d.length < 14) {
      const completo = d.padStart(14, '0');
      if (cnpjValido(completo)) return { ok: true, digitos: completo, motivo: `zeros à esquerda repostos (${d.length} dígitos)` };
    }
    if (d.length !== 14) return { ok: false, digitos: d, motivo: `quantidade de dígitos incorreta (${d.length}; um CNPJ tem 14)` };
    if (!cnpjValido(d)) return { ok: false, digitos: d, motivo: 'CNPJ com dígitos verificadores inválidos' };
    return { ok: true, digitos: d, motivo: '' };
  }

  // Lê a lista colada: "CNPJ", "CNPJ;NOME" ou "CNPJ<TAB>NOME" (Excel). Nunca bloqueia: separa válidos e ignorados.
  // Devolve { total, validos: [{ linha, documento, digitos, nome, item: 'CNPJ;NOME', obs }],
  //           ignorados: [{ linha, texto, motivo }], duplicados: [{ linha, texto, motivo }] }
  function analisarLista(texto) {
    const validos = [], ignorados = [], duplicados = [], vistos = new Map();
    let total = 0;
    String(texto || '').split(/\r?\n/).forEach((linhaTxt, i) => {
      if (!linhaTxt.trim()) return;
      total += 1;
      const linha = i + 1;
      const m = linhaTxt.match(/^\s*([^;\t]*)[;\t]?(.*)$/);
      const bruto = m[1].trim();
      const nome = m[2].replace(/[;\t]+/g, ' ').replace(/\s+/g, ' ').trim();
      const r = analisarDocumento(bruto);
      if (!r.ok) { ignorados.push({ linha, texto: linhaTxt.trim(), motivo: r.motivo }); return; }
      if (vistos.has(r.digitos)) {
        duplicados.push({ linha, texto: linhaTxt.trim(), motivo: `repetido (igual à linha ${vistos.get(r.digitos)})` });
        return;
      }
      vistos.set(r.digitos, linha);
      const documento = formatarCnpj(r.digitos);
      validos.push({ linha, documento, digitos: r.digitos, nome, item: nome ? `${documento};${nome}` : documento, obs: r.motivo });
    });
    return { total, validos, ignorados, duplicados };
  }

  // ---------------- conferência do arquivo salvo ----------------
  // O arquivo terminou NA pasta pedida e com o nome pedido? Aceita a numeração que o Chrome acrescenta quando já
  // existe um arquivo igual ("Certidao_EMPRESA (1).pdf") — os documentos anteriores nunca são sobrescritos.
  // nomeSemExt: nome sem a extensão ("Certidao_EMPRESA LTDA"); vazio = aceita qualquer nome dentro da pasta.
  function arquivoConfere(caminhoFinal, pasta, nomeSemExt) {
    const f = String(caminhoFinal || '').replace(/\\/g, '/');
    const i = f.lastIndexOf('/');
    const dir = f.slice(0, i).toLowerCase(), base = f.slice(i + 1);
    const p = String(pasta || '').replace(/\\/g, '/').replace(/\/+$/, '').toLowerCase();
    if (!(dir === p || dir.endsWith(`/${p}`))) return false;
    if (!nomeSemExt) return true;
    const semExt = base.replace(/\.[^.\s]{1,5}$/, '');
    const esc = String(nomeSemExt).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    return new RegExp(`^${esc}( \\(\\d+\\))?$`, 'i').test(semExt);
  }

  // ---------------- classificação de cada CNPJ (painel, janela e placar) ----------------
  // Mesma regra do content.js: conclusões antigas sem documento conferido não valem.
  const concluidoValido = (c) => !!c && (c.versao >= 2 || c.status === 'Erro de procuração' || !!c.relatorio || !!c.certidao);

  // situacao: 'concluido' | 'procuracao' | 'falha' | 'atual' | 'aguardando'
  function situacaoDoCnpj(digitos, progresso, status) {
    const p = progresso || {};
    const c = (p.concluidos || {})[digitos];
    if (concluidoValido(c)) {
      if (c.status === 'Erro de procuração') return { situacao: 'procuracao', texto: 'Erro de procuração', detalhe: c.mensagem || 'portal recusou a procuração; evidência salva' };
      return { situacao: 'concluido', texto: 'Concluído', detalhe: [c.status, c.mensagem].filter(Boolean).join(' — ') };
    }
    const pend = (p.pendentes || {})[digitos] || (p.pendentesFinal || {})[digitos];
    if (status && status.estado === 'executando' && soDigitos(status.cnpj) === digitos) {
      return { situacao: 'atual', texto: 'Em processamento', detalhe: status.etapa || '' };
    }
    if (pend) return { situacao: 'falha', texto: 'Falha de navegação/portal', detalhe: `${pend.etapa ? `${pend.etapa}: ` : ''}${pend.motivo || ''} — nova tentativa no fim da lista ou no próximo início` };
    return { situacao: 'aguardando', texto: 'Pendente de processamento', detalhe: '' };
  }

  function contar(itens, progresso, status) {
    const n = { total: itens.length, concluido: 0, procuracao: 0, falha: 0, atual: 0, aguardando: 0 };
    for (const it of itens) n[situacaoDoCnpj(it.digitos || soDigitos(it.documento || it), progresso, status).situacao] += 1;
    n.feitos = n.concluido + n.procuracao;
    n.restantes = n.total - n.feitos;
    return n;
  }

  raiz.SF = {
    CHAVES, chaveProgresso, URL_PENDENCIAS, URL_LOGIN, PULSO_MS, PULSO_VALIDO_MS,
    soDigitos, cnpjValido, cpfValido, formatarCnpj, limparPasta, analisarDocumento, analisarLista, arquivoConfere,
    concluidoValido, situacaoDoCnpj, contar,
  };
})(typeof self !== 'undefined' ? self : globalThis);
