# Autom_Situacao_Fiscal — histórico de criação

Registro de como a extensão **Situacao_Fiscal** foi construída, entre 11/11/2026 e 13/11/2026: decisões e motivos,
problemas encontrados, soluções, regras de cada situação e o que ainda precisa de ajuste. Versão atual: **1.3.1**.

## Contexto

- Usuário: escritório contábil **Assecon Hub Contabilidade** (CNPJ titular `10.754.473/0001-38`). Ele acessa o
  e-CAC como **Procurador** de clientes e precisa da situação fiscal de cada um.
- Portal: `https://servicos.receitafederal.gov.br/servico/pendencias/#/analise-pendencias`
  (**Minhas Dívidas e Pendências**). É uma SPA em Angular, com componentes do padrão gov.br.
- Projeto irmão de referência: `C:\Users\PANORAMA-PC\Downloads\Auto_PGFN` (extensão Automação_PGFN). Copiamos o
  estilo: bloco CONFIGURAÇÃO no topo, seta animada, aviso no canto inferior esquerdo e prefixo no console.
- Pastas: o Chrome executa `C:\Users\PANORAMA-PC\Desktop\ATM_SIT_FISCAL\Situacao_Fiscal`. A cópia de referência
  (página do projeto) fica em `C:\Users\PANORAMA-PC\Documents\Autom_Situacao_Fiscal`. As duas devem ficar iguais.
- Resultados: `C:\Users\PANORAMA-PC\Downloads\Situacao_Fiscal_Assecon\<EMPRESA>\…`.

## Decisões de base (e por quê)

- **Extensão MV3 com JavaScript puro**, sem Playwright nem Selenium: pedido do usuário; roda no Chrome já logado.
- **Seta visual** com `pointer-events:none`, movimento contínuo com aceleração e desaceleração e pausa antes do
  clique. O destino é calculado por `getBoundingClientRect` no momento do clique, o que funciona com qualquer
  resolução e zoom. O clique é feito com eventos sintéticos (pointerdown, mousedown, pointerup, mouseup, click), uma
  única vez, no elemento real.
- **Detecção da página pela URL completa**, incluindo o trecho após `#`. O content script roda em todo o host, e o
  service worker avisa as mudanças de SPA (`webNavigation.onHistoryStateUpdated` e `onReferenceFragmentUpdated`). Há
  também um vigia da URL a cada 400 ms.
- **Leitura do DOM por texto e posição na tela**, não por classes do Angular, que mudam. Exemplos: o painel é o
  contêiner à direita com "Representar" e "Representações Recentes"; o perfil é o controle no canto superior direito
  com avatar, CNPJ e seta.
- **Downloads só dentro da pasta de Downloads**, porque é uma limitação do Chrome. A pasta raiz é configurável.
- **A captura da tela vira PDF dentro da própria extensão:** `captureVisibleTab` gera um JPEG e um gerador de PDF
  mínimo, escrito à mão, monta o arquivo. Exige `<all_urls>` em `host_permissions`.
- **O relatório e a certidão do portal** são redirecionados com `downloads.onDeterminingFilename`, um download por
  vez. A "espera" do download fica guardada em `storage.session`, porque o service worker pode reiniciar.
- **Progresso em `chrome.storage.local`**, numa chave por pasta raiz (`situacao_fiscal_progresso:<PASTA_RAIZ>`):
  concluídos, parciais (arquivos já salvos), pendentes, recuperação e rodada de pendentes.

## Linha do tempo (versão → o que mudou → por quê)

| Versão | Mudança | Motivo / problema |
|---|---|---|
| 0.1.0 | Reconhece a página, aceita cookies, abre o perfil e para com o painel aberto | 1ª etapa pedida |
| — | `quadro()` com timer de reserva | `requestAnimationFrame` pausa em aba oculta e a seta travava |
| 0.2.0 | Preenche o CNPJ (só dígitos, a máscara do portal formata), escolhe Procurador e clica em Representar | 2ª etapa |
| 0.2.1 | Seletor de perfil achado por placeholder, nome acessível, texto visível ou posição; seta azul como 2ª tentativa; velocidades separadas | O seletor não é um `<input placeholder>` simples (estilo ng-select) |
| 0.2.2 | Lista de perfis reconhecida pela **posição na tela** e por `elementFromPoint` | A lista fica dentro do componente do campo e era descartada como "parte do campo" |
| 0.2.3 | Botão Representar = o mais próximo **abaixo do seletor**; o painel nunca conta como "mensagem do portal" | O título "^ Representar" também é botão e era clicado por engano; o texto do painel virava "resposta" falsa |
| 0.3.0 | Confirma a Representação Atual; fecha o painel pelo fundo escurecido (ou ×); captura em PDF; baixa o relatório | Etapas 8 a 11 |
| 0.4.0 | Lista de CNPJs com registro de progresso; troca por Trocar Representação; espera a Representação Atual mudar | Processar vários CNPJs |
| — | Correção: o ouvinte `onDeterminingFilename` precisa confirmar também os downloads da própria extensão | A captura saía como `download (3).pdf` |
| 0.5.0 | Recusa de procuração: recorte da seção Trocar Representação até o campo Procurador, salvo em `Erro_de_Procuracao/`; a fila continua | "Sua autorização como procurador não permite acesso a este serviço." |
| — | Mensagem de recusa considerada "desta tentativa" só se sumir e voltar, ou se aparecer num elemento novo | Recusas seguidas reutilizam o mesmo elemento com o mesmo texto |
| 0.6.0 | Em **qualquer** status, rola até o rodapé e baixa **Baixar Certidão** (`RFB_<CNPJ>.pdf`) e **Baixar Relatório** (nome original), um por vez; parciais permitem retomar sem duplicar | "Sem pendência" encerrava sem baixar os documentos |
| 0.7.0 | Pasta com o **nome da empresa**, e não com o CNPJ | Pedido do usuário |
| 0.8.0 | Falha temporária ("Não foi possível concluir a ação…", carregamento travado, sem confirmação): guarda o estado, espera, F5, retoma o mesmo CNPJ (até 3 vezes; depois pendente); intervalo de 5 s entre empresas; downloads múltiplos permitidos só no portal (`contentSettings.automaticDownloads`) | A página falhava ou travava; o Chrome bloqueava o 2º download |
| — | A Representação Atual é lida mesmo com indicador de carregamento visível | Um spinner preso impedia a leitura e dava "sem confirmação" |
| 0.9.0 | Lista ampliada; o CNPJ do titular tentava encerrar a representação | A Assecon está na lista |
| 0.9.1 | Diálogo "Encerrar representação" → sempre **Cancelar** e seguir; o titular passa pelo fluxo normal | Pedido do usuário: nunca encerrar uma representação |
| 1.0.0 | Lista oficial de **208 CNPJs**; raiz `Situacao_Fiscal_Assecon` com progresso próprio; filiais com o mesmo nome ganham o nº da filial na pasta | Execução de produção; seis filiais "FERNANDO … LTDA PE" com o mesmo nome |
| 1.0.1 | "Estamos processando sua solicitação. Tente novamente em instantes." reconhecida pelo texto, em toda espera | A etapa 9 parava aos 30 s: o texto não estava na lista de falhas e não havia spinner, então virava erro comum |
| 1.0.2 | A tela "processando" vale como página na etapa 1; se passar de 60 s, o CNPJ fica pendente e a fila segue **sem F5**; no fim, 1 nova rodada dos pendentes | Pedido do usuário: "se demorar muito, segue para o próximo" |
| 1.0.3 | Página recarregada após Representar e voltando com a **empresa anterior** → repete o **mesmo CNPJ** (até 3 vezes; depois pendente) | Antes, a extensão parava com "Representação solicitada, sem confirmação do portal" |
| 1.0.4 (13/11) | Falha de download vira recuperação **automática**: o aviso de falha do portal (ex.: 043 "Não foi possível emitir a certidão. Tente novamente daqui alguns minutos"), visto antes de o download começar, ou o download que não começa em 30 s → salva o estado, **uma** recarga e tenta de novo só o documento que falta. Espera de 15 s na 1ª vez e de 2 min depois; até 4 recargas; depois, pendente com o motivo | Etapa 11 parava em "Aperte F5". Causas: (1) o texto 043 não estava em `RE_FALHA_TEMPORARIA`; (2) a espera do download não olhava a tela; (3) o laço de downloads transformava todo erro comum em parada com "Aperte F5" |
| 1.0.5 (13/11) | **Placar** no topo de todo aviso: "Analisados: X de 208 (N%) · Faltam: Y (Z pendentes)", com uma barra de 20 blocos. Vem do registro de progresso (`atualizarPlacar`, chamado a cada leitura e gravação). "Analisado" = concluído, inclusive erro de procuração. A barra só fica cheia em 100% | Pedido do usuário: ver quantos CNPJs já foram analisados e quantos faltam, "para ter um norte" |
| 1.0.6 (13/11) | `PASTA_RAIZ` = `Situacao_Fiscal_Assecon/PRISCILLA_ASSECON`: a lista inteira roda de novo com o certificado da Priscilla, com registro de progresso novo (a chave depende da raiz) | O usuário moveu a 1ª rodada (Assecon) para `Situacao_Fiscal_Assecon\ASSECON HUB CONTABILIDADE`, criou `PRISCILLA_ASSECON` e pediu para rodar todos os CNPJs de novo |
| 1.1.0 (13/11) | **Janela no ícone** (`popup.html`/`popup.js`): aviso de que o e-CAC e a página precisam estar abertos (e se a página está aberta, com botão para abrir), campo da **pasta de destino** (dentro de Downloads; subpastas com `/`), campo dos **CNPJs** (`CNPJ` ou `CNPJ;NOME`, colar do Excel; dígitos verificadores conferidos; repetidos ignorados; zeros à esquerda repostos), placar da pasta, **Salvar e iniciar** (grava `situacao_fiscal_config` e recarrega a aba do portal) e **Zerar progresso** (dois cliques). O `content.js` lê a configuração antes de começar (`carregarConfig`; sem ela, grava o padrão do arquivo) e ignora a marca de "Representar já clicado" de CNPJ fora da lista. O ícone não recomeça mais a lista | Pedido do usuário: uma interface para escolher a pasta e os CNPJs, com o aviso do e-CAC aberto. Evita editar o código a cada nova lista ou certificado |
| 1.1.1 (13/11) | Os avisos da tela vão só para o console comum (`console.log`), nunca para `console.error`; a contagem regressiva da recuperação ("recarregando em 1:38…") é registrada uma vez, não a cada segundo | O botão **Erros** do card ficou cheio de mensagens repetidas, como o 035 da Nova Marca Portas (51.406.327/0001-07) a cada segundo. Não eram falhas de código: o Chrome copia todo `console.error` de extensão para essa lista |
| 1.2.0 (17/11) | **Painel externo** `painel/painel.html`, aberto pela Central (campo `painel` em `automacoes.json`), com configuração, comandos (Iniciar/Continuar, Pausar, Parar com segurança, Abrir pasta, Zerar), acompanhamento em tempo real, tabela das empresas e histórico. **CNPJs inválidos não bloqueiam mais**: são ignorados e listados à parte, com o motivo (CPF, dígitos, DV, letras, repetidos). **Início automático** depois do login: o service worker leva o e-CAC autenticado (`/ecac/`) até Minhas Dívidas, só com execução preparada. Execução só roda se preparada no painel. Trava contra duas abas (dono + pulsação). Pausa/parada entre empresas. `pendentesFinal` guarda os pendentes do fim da lista para o painel. Pasta com CNPJ inteiro quando duas empresas diferentes têm o mesmo nome e a mesma filial. `comum.js` concentra validação, chaves e classificação. A janela do ícone virou resumo + "Abrir painel" | Pedido do usuário, com foto: 24 válidos + 3 CPFs travavam "Salvar e iniciar". **Causa:** a janela da 1.1.x desabilitava o botão quando havia qualquer linha com erro (`btnIniciar.disabled = … || erros.length > 0`). O usuário pediu também uma interface externa integrada à Central, o início automático depois do login no e-CAC e o acompanhamento em tempo real |
| 1.3.0 (17/11) | **Arquivos com o nome da empresa:** `Certidao_<EMPRESA>.pdf`, `situação fiscal/Relatorio_<EMPRESA>.<ext original>`, `Com_Pendencia_<EMPRESA>.pdf`, `Erro_de_Procuracao/Erro_de_Procuracao_<EMPRESA>.pdf`. `<EMPRESA>` é o mesmo nome da pasta (`nomeArquivo` no `content.js`), já com a filial ou o CNPJ quando há nomes iguais. **Nada é sobrescrito** (`conflictAction: 'uniquify'`, o Chrome numera "(1)"); a conferência `SF.arquivoConfere` aceita a numeração e exige a pasta da empresa. Caminho relativo limitado a 215 caracteres (só o nome do arquivo é encurtado). O resumo CSV continua sobrescrito. O CNPJ segue nas consultas e no registro | Pedido do usuário: identificar cada documento pela empresa, sem consultar o CNPJ; não sobrescrever; não misturar empresas. Pontos alterados: o certificado era `RFB_<CNPJ>`, o relatório tinha o nome original, a captura era `Com_Pendencia_<CNPJ>` e a evidência era `Erro_de_Procuracao_<CNPJ>`, tudo com `overwrite` |
| 1.3.1 (17/11) | **Leitura do CNPJ corrigida** (`escolherDocumento` no `content.js`): quando a linha tem mais de um número, vale o CNPJ pedido; senão, o último CNPJ com pontuação. Isso vale em "Representação Atual", em Dados Cadastrais (o número depois do rótulo "CNPJ") e no titular do painel. **Divergência na etapa 8 não para mais a execução**: vira falha temporária (`tipoFalha 'divergencia'`), sem salvar nada. A página recarrega e repete o mesmo CNPJ até 3 vezes; se persistir, o CNPJ fica PENDENTE e a fila segue (com nova tentativa no fim da lista) | Print do usuário, nº 18/36: "Etapa 8 — divergência: solicitado 31.780.581/0001-55, o portal mostra 03979335500". Era um MEI cujo NOME termina com o CPF do titular. A leitura antiga pegava o **primeiro** número da linha "Procurador de:" (o CPF do nome), e não o CNPJ, que estava certo; o mesmo erro aconteceria em Dados Cadastrais. O usuário pediu também para pular para o próximo CNPJ se o erro persistir |

## Regras de cada situação (comportamento atual)

- **Cookies:** se o aviso estiver visível, clica uma vez em Aceitar.
- **Painel já aberto:** não clica no perfil de novo.
- **CNPJ já no campo:** aproveita o valor e não digita de novo.
- **Lista de perfis já aberta:** vai direto à opção (outro clique fecharia a lista).
- **Empresa já em Representação Atual** (retomada): não representa de novo e vai à análise.
- **Representação Atual ainda com a empresa anterior:** aguarda. Se aparecer uma 3ª empresa, há divergência: nada é
  salvo, a página recarrega e o mesmo CNPJ é repetido (até 3 vezes); depois, fica pendente e a fila segue (v1.3.1).
- **Documento na tela com mais de um número** (ex.: MEI com o CPF no nome): vale o CNPJ pedido; senão, o CNPJ com
  pontuação (v1.3.1).
- **Recusa de procuração:** confere o CNPJ no campo, salva o recorte em PDF e segue para o próximo CNPJ.
- **Diálogo "Encerrar representação":** sempre Cancelar e continuar.
- **Com pendência:** salva a captura antes de rolar a página.
- **Qualquer status:** baixa a certidão e depois o relatório, os que existirem, um por vez, e confere a pasta.
- **Download que falha** (aviso do portal antes de começar, como o 043, ou nada em 30 s): uma única recarga
  automática e nova tentativa só do documento que falta. Espera de 15 s e depois de 2 min, até 4 recargas; depois,
  pendente com o motivo. Um documento só conta como salvo quando o download termina. Só um arquivo salvo fora da
  pasta esperada para a execução e pede F5 manual.
- **"Processando…":** acompanha a página por até 60 s; depois, o CNPJ fica pendente e a fila segue.
- **"Não foi possível concluir…", carregamento > 60 s ou sem confirmação:** espera, recarrega a página e retoma (até
  3 vezes); depois, pendente.
- **Recarga após Representar com a empresa anterior:** repete o mesmo CNPJ (até 3 vezes); depois, pendente.
- **Pendentes:** 1 nova rodada no fim da lista. Os que sobrarem são listados no aviso final; um F5 tenta só esses.
- **Entre empresas:** espera pelo menos 5 s depois de concluir, e só segue com a página parada.
- **Placar:** todo aviso mostra no topo quantos CNPJs foram analisados, quantos faltam e quantos estão pendentes.
- **Painel (v1.2.0):** é a interface principal, aberta pela Central. O ícone da extensão só mostra o resumo e o
  botão "Abrir painel".
- **Registros inválidos:** são ignorados, listados à parte com o motivo e entram no CSV de resumo como "Ignorado".
  Nunca travam os válidos. Sem nenhum válido, o painel avisa "Nenhuma empresa apta para processamento".
- **Início:** só com execução preparada no painel e comando "executar". Abrir o portal sem preparação não inicia
  nada. Depois do login, o e-CAC autenticado é levado sozinho até Minhas Dívidas (no máximo 1 vez a cada 60 s por
  aba).
- **Pausar / Parar com segurança:** valem entre uma empresa e outra.
- **Duas abas na página:** só a primeira executa; a outra mostra o aviso e não grava status.
- **Nomes dos arquivos (v1.3.0):** `<Tipo>_<EMPRESA>`, sem sobrescrever (numeração "(1)"). Os arquivos antigos ficam
  como estão.

## Como testamos

Não há como automatizar o portal real daqui, porque o login é manual. Cada mudança foi validada numa **página que
imita o portal**, servida localmente, que carrega o `content.js` real com a URL alvo trocada e o `chrome.*`
simulado. A página reproduzia cada problema relatado pelo usuário (seletor estilo ng-select, lista absoluta, título
"Representar" clicável, `role=dialog`, recusa repetida, "processando", F5, downloads). As páginas de teste foram
apagadas depois de cada validação, a pedido do usuário. O teste no portal real é feito pelo usuário, com prints.

## Estado em 13/11/2026

- Lista: 208 CNPJs. Na análise das pastas, **126 concluídos** (50 com pendência, 39 com certidão + relatório e 37 com
  erro de procuração) e **82 faltando**: nº 129 a 208, mais a nº 29 (Pernambuco Piso, "processando") e a nº 43 (Ana
  Maria da Silva), sem arquivos. A execução parou na nº 128 (DBG Empreendimentos), em 12/11 às 11:12.
- A Downloads\RFB_CNPJ, com os testes, foi apagada a pedido do usuário.
- Ainda em 13/11, às 10:18, a lista terminou: **207 de 208 concluídos** (82 com pendência, 68 com certidão +
  relatório e 57 com erro de procuração). Falta só a nº 202, EA Consultoria e Treinamentos (63.986.506/0001-31),
  pendente porque o portal ficou em "Estamos processando".
- Às 10:31, o usuário moveu esses resultados para `Situacao_Fiscal_Assecon\ASSECON HUB CONTABILIDADE` (e um .zip) e
  pediu uma 2ª rodada com o certificado da **Priscilla**: v1.0.6, raiz `Situacao_Fiscal_Assecon\PRISCILLA_ASSECON`,
  lista inteira do zero.
- Pacote para envio à equipe ATM: `Desktop\ATM_SIT_FISCAL\Situacao_Fiscal_envio_ATM\` e o `.zip` ao lado (v1.1.1).
  Contém a extensão, o guia visual `COMO_FUNCIONA.html` (com a réplica numerada da janela), o
  `LEIA-ME_PRIMEIRO.txt`, a `lista_cnpjs.txt`, a `documentacao\` e as `ferramentas\`. A cada nova versão, refazer a
  cópia e o zip.

## Estado em 17/11/2026 (v1.2.0)

- Painel testado em páginas simuladas: o painel e a "página do portal" conversam de verdade, em abas separadas,
  pelo mesmo armazenamento. Itens testados:
  - 27 registros (24 válidos e 3 CPFs) não travam;
  - sem preparação, a página não inicia; com preparação, começa sozinha;
  - acompanhamento em tempo real;
  - Pausar, Continuar e Parar entre empresas;
  - recarga no meio de uma empresa retoma a mesma empresa;
  - segunda aba bloqueada;
  - painel recarregado mantém a pasta, a lista e o histórico;
  - CSV de resumo, Zerar com confirmação e o caso de todos os registros inválidos.
- Service worker testado no Node com `chrome.*` simulado, em 9 casos de início automático e classificação.
- Central: `-Validar` OK. O ID da extensão é encontrado nas preferências do Chrome, e `-Abrir "SITUAÇÃO FISCAL"`
  foi aceito.
- Backups: `Desktop\ATM_SIT_FISCAL\backup_2026-11-17_*_v1.1.1` e `Central_Automacoes\backup_2026-11-17_*_antes_situacao_fiscal_painel`.

## O que ainda precisa de ajuste ou atenção

- **v1.2.0 não testada no portal real.** Falta confirmar no Chrome do usuário:
  - o caminho do login até `cav.receita.fazenda.gov.br/ecac/` e a abertura automática de Minhas Dívidas (se o
    e-CAC usar outro endereço na página inicial, ajustar `ehInicioEcac` no `background.js`);
  - o painel aberto pela Central;
  - o "Abrir pasta de resultados" no Windows.
- "Caixa postal pendente" não se aplica a esta automação: ela não lê a Caixa Postal do e-CAC. Também não há "print de
  confirmação": os tipos de arquivo são certidão, relatório, captura "Com pendência" e evidência de procuração.
- **v1.3.0 (nomes) testada no Node**, com o código real: os 4 tipos, filiais, nomes iguais, caracteres do Windows,
  nome longo, conferência com "(1)" e o redirecionamento do service worker (extensão original, `uniquify`,
  confirmação só depois do download completo). Falta ver no portal real que o Chrome grava os nomes assim.
- **v1.3.1 testada no Node** com a função real `escolherDocumento` (7 casos, incluindo o texto do print do MEI).
  Falta confirmar no portal real que o MEI passa da etapa 8 e que uma divergência verdadeira pula para o próximo.

- **Não testado no portal real:** a v1.0.3 (repetir o mesmo CNPJ quando a recarga mostra a empresa anterior), o
  caminho "pendente sem F5" da v1.0.2 e a recuperação de download da v1.0.4 (testada na página simulada nos gatilhos
  "aviso 043", "sem início em 30 s" e "043 persistente até o limite") só foram validados na página que imita o portal.
- Se o portal começar o download **depois** que a extensão desistiu da tentativa, o arquivo cai na raiz de Downloads
  com o nome original. A espera no service worker já foi cancelada; a nova tentativa baixa o documento no lugar certo.
- O registro de progresso fica no Chrome e não pode ser lido de fora; a análise do que falta é feita pelas pastas
  (`ferramentas/analisar_progresso.js`).
- Trocar a pasta carregada no Chrome muda o ID da extensão e zera o progresso.
- O recorte da recusa e o gerador de PDF dependem de `captureVisibleTab`, com a aba visível.
- Se o portal mudar textos ("Representação Atual", "Trocar Representação", "Procurador de:", "Baixar Certidão",
  "Baixar Relatório", as mensagens de falha), os seletores por texto precisam de ajuste.
